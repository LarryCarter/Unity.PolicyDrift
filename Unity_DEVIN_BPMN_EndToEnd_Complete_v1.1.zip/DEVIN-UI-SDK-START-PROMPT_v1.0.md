# DEVIN v1.0 - Initial Task Dispatch (Copy into DEVIN)

We are continuing Unity, a configuration-first platform built from Blazor Business Enablement (BE), a shared central/embedded BOB BPMN 2.0 runtime, the **existing AMIE implementation**, Kafka, independently owned capability services, MSSQL BOB persistence and reconstructable audit. Do not start from scratch. The November 30, 2026 goal is an actual verified DEV/UAT-ready demo, not feature-complete BPMN or unapproved PROD activation.

Read `AGENTS.md`, `INDEX.md`, `docs/00-START-HERE.md`, and original `jobs/JOB-00-reconcile-repository.md`. Then read `docs/sdk/00-SDK-PURPOSE-SERVICE-BOUNDARIES.md` through `docs/sdk/08-SDK-API-REGRESSION-SUITE.md`, `docs/ui/07-SCREEN-BY-SCREEN-WIREFRAMES.md` through `12-PREVIOUS-PROTOTYPE-CONTROL-CROSSWALK.md`, and `jobs/interaction/INDEX.md`. Use the repository Skills under `.agents/skills/`.

## First assignment - read only

Execute original JOB-00 + detailed SDK-10. Inspect actual Unity source and current AMIE, BOB, CyberArk, Kafka and Blazor interfaces; inventory approved libraries and existing operation handlers. Produce exact source file mapping, a P0 compatibility and gap report, and the proposed contract diffs (OperationDescriptor/Invocation/Outcome, AMIE rule descriptor, BOB service task binding, Kafka envelope, audit events and UI API). Do not scaffold duplicate AMIE or rewrite existing services. Present real evidence, uncertainties and safe PR boundaries.

## After contract gate (JOB-01), distribute branches

- SDK/Registry lane: SDK-11, SDK-12, SDK-17 (typed handlers, trusted manifest, registry API, common service template).
- Rule/engine lane: SDK-13, SDK-14 (existing AMIE adapter, shared BPMN execution and central/embedded hosts).
- Kafka/audit lane: SDK-15, SDK-16 (outbox/inbox, correlated outcomes, MSSQL immutable audit, authorization and run controls).
- Blazor lane: UI-10 through UI-14 (screen shell, catalog/inspector, application/library, BPMN canvas, typed AMIE binding and triggers).
- Operations lane: UI-15 through UI-17 (business progress, technical monitor, audit/operator controls, release and API regression).
- Pilot lane: SDK-18 (DCMS CSV -> batch+row GUIDs -> sequential CyberArk -> existing AMIE mappings -> report/email; second Hygiene configuration proves reuse if time permits).

For the UI, the source of truth for proposed action selectors is `wireframes/UI_CONTROL_REGISTRY_v1.0.json`: 19 screens and 107 controls with roles, APIs, expected results, denied paths and audit. `wireframes/Unity_BE_Clickable_Wireframes_v1.0.html` is a **simulation only**, not a Blazor implementation. Map current routes/components before replacing anything. For each control, implement a real secured API and test it directly. Local editor-only controls are covered by component tests and persisted through draft API.

For every PR provide actual files with paths `/Project/Folder/File.cs`, New/Updated/Deleted/No Change, input/output schema diff, tests and CI logs, error and security negative tests, screenshots of actual DEV UI, and blockers. Never claim bank-approved library/control or real CyberArk integration from fixtures. Do not deploy to PROD. Pause/stop/retry must be safe and audited.

## Earliest vertical slice to prove

Approved compiled safe handler -> startup DI -> manifest -> registry -> BE typed inspector -> BPMN service task + pinned AMIE rule -> central/embedded BOB -> Kafka command/outcome as required -> durable MSSQL run/audit -> BE business and technical status. Then implement DCMS with a five-row fixture and side-effect reconciliation. Avoid broad UI polishing before this loop executes.
