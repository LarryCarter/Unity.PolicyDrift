# Copy-ready DEVIN Dispatch Prompts and Merge Protocol

This repo handoff gives DEVIN repeatable context. **Before asking for implementation, copy into the actual Unity repo and commit via review**: `AGENTS.md`, `.agents/skills/*`, `docs/*`, and `jobs/*`. Do not commit `history/` if bank policy prohibits attaching prior artifacts; preserve it in an approved knowledge area instead. The current files are proposals, not verified enterprise deployment instructions.

## Session A — Immediate inventory (run first, read-only)

> Read `AGENTS.md`, `docs/00-START-HERE.md`, and `jobs/JOB-00-reconcile-repository.md`. Inventory current Unity, AMIE, BOB, CyberArk, Kafka, MSSQL and BE Blazor code, naming real file paths and existing tests. Do not modify source. Output the REAL-REPOSITORY-MAP, actual approved dependencies, exact AMIE interface contracts and blockers. Never claim a proposed class already exists unless source proves it. Stop at a recommended minimal contract freeze.

Review findings with architect/owner. Resolve discrepancies via ADRs and then authorize Session B. Do not ask multiple sessions to invent their own conflicting SDK contracts.

## Session B — Contract freeze (after A)

> Implement `JOB-01-freeze-contracts.md` using the actual existing AMIE and service code. Produce versioned shared operation/AMIE/BPMN/Kafka/audit/release contracts and failing negative tests. Keep names compatible with current namespaces. No major runtime implementation. Return changed files and API test evidence.

## Session C — SDK and Registry (parallel once B is merged)

> @skills:unity-capability-service Implement JOB-02 and, in a separate PR after contract tests, JOB-03. Reuse current hosting/DI conventions. Make a safe compiled test handler appear in authorized BE registry schema APIs through trusted manifest publication. No dynamic user code, no unapproved Kafka topics. Prove operation can be referenced twice without new handler code.

## Session D — AMIE adapter (parallel)

> @skills:unity-amie-bindings Implement JOB-04 using existing AMIE evaluator and rule serializer. Show one real rule decision with typed inputs, version pin, schema mismatch rejection and local embedded execution. Do not write a replacement rule engine. Submit tested adapter contract and metadata APIs.

## Session E — BOB Core + Hosts (two PRs, parallel with C/D)

> @skills:unity-bob-bpmn Implement JOB-05 parser/compiler and BPMN semantic fixtures using approved existing dependencies. Then implement JOB-06 common interpreter with central and embedded hosts against frozen SDK/AMIE contracts. Reject unsupported BPMN at publish. Demonstrate sequential multi-instance and durable Kafka wait without DCMS-specific engine logic.

## Session F — Messaging and SQL (parallel)

> Implement JOB-07 and JOB-08 in separate PRs using the enterprise's current Kafka and MSSQL conventions. Supply inbox/outbox deduplication, correlation, durable checkpoints, append-only safe audit and status projections. Test broker outage and worker restart, do not claim exactly-once external CyberArk writes.

## Session G — BE design and composition (after contracts, can mock APIs briefly)

> @skills:unity-be-blazor Implement JOB-09 and JOB-10 using existing Blazor project and approved UI libraries. Create Workflow Library, SVG BPMN canvas, registry-backed typed operation inspector and AMIE rule picker, with actual backend validation and XML/DI persistence. Use v0.7 HTML as visual reference only. Remove mocks before demo and keep features accessible to role-scoped users only.

## Session H — DCMS capabilities (parallel with G)

> @skills:unity-capability-service Implement JOB-11, JOB-12 and JOB-13 in separate code ownership branches. Map the existing DCMS database tables, CyberArk adapter operations and corporate email. Ensure batch number + row GUID staging, sequential account processing, AMIE mapping, in-memory patch, confirmed add/update, persisted reason, Reporting/Email via Kafka. Mark any unapproved integration mock truthfully.

## Session I — Operations, controls and regression (start early, integrate continuously)

> @skills:unity-release-regression Implement JOB-14 through JOB-17 as isolated PRs. Every BE function needs secured API; enforce role scopes and operator safe controls. Create immutable release package and bank approval gates without pretending a ServiceNow ID proves approval. Execute P0 tests R01-R18 and failure injection, store redacted evidence with exact run and package version.

## Session J — Integration and demo

> Integrate JOB-18 DCMS against real accepted contracts and tests; then attempt JOB-19 second reuse workload without modifying BOB Core. Complete JOB-20 with clean-environment build, BE clickthrough demo, API regression and an audit timeline. Explicitly separate **DEV demonstration**, **UAT tested**, and **bank PROD approved** states; record release blockers.

## PR merge protocol

- Freeze contracts and generate implementation fixtures first; API/DTO changes require owner review and updating all consumers + tests.
- Use separate worktrees/branches per lane; no parallel edits to the same shared contract file without coordinated merge.
- A test-only stub must be named as such and removed or explicitly marked before real integration demo.
- After each PR, re-run contract + namespace/manifest tests and update roadmap status ledger.
- Every PR includes actual project/folder/file summary, unit/contract/integration tests, unauthorized cases, audit sample, known limits and next dependent job.
- No direct developer PROD access, uncontrolled third-party package, blind retry of uncertain CyberArk update or unreviewed signed release bypass.

## Distinct artifacts

The `.agents/skills` files teach DEVIN repeatable engineering procedures. They do **not** automatically install or implement the runtime Unity Capability SDK. `JOB-02` creates/adapts that SDK; each future service then consumes the approved SDK NuGet/project package.
