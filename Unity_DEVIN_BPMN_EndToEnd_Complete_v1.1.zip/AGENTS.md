# Unity — Repository Instructions for DEVIN and Coding Agents

**Scope:** all Unity development performed with this handoff. Read `README.md`, `docs/00-START-HERE.md`, and relevant `.agents/skills/` before edits. Repository code overrides proposed example names. Existing AMIE logic and prior working services must be inventoried and preserved.

## Invariants (do not violate)

1. No DCMS, Onboarding, Hygiene, Policy Drift, or PAM-specific cases in BOB Core or AMIE Core.
2. No second AMIE engine. Adapt through a tested adapter to the existing AMIE contracts.
3. Capabilities expose reusable, permissioned, versioned operations; only compiled approved handlers run. No arbitrary CLR class names, dynamic C#, raw SQL or direct arbitrary HTTP from workflow configuration.
4. Keep BOB Core independent of Blazor, Kafka transport, MSSQL provider, and capability adapters. Central/embedded are host variants of the same interpreter.
5. BPMN 2.0 XML + BPMN DI is the interchange format. Explicitly reject unsupported executable constructs at publish time.
6. Local embedded execution stays local; Kafka crosses capability boundaries. Services do not query another service's private tables.
7. BOB persistence is MSSQL-only. Other capability data ownership remains independent.
8. All BE actions use authenticated backend APIs; security checks are also enforced at dispatch. Never trust browser-only authorization.
9. Signed immutable packages, pinned versions, actor/UTC/change-request metadata, protected audit, and Operations-only PROD activation subject to actual bank controls.
10. No new unapproved third-party dependencies; inventory existing approved libraries first.

## Required job procedure

1. Declare the chosen JOB-ID, worktree/repo, scope, prior relevant commits, dependencies and blockers.
2. Locate real namespaces and paths; map conceptual paths in the handoff to actual files before changes.
3. Write or update contract tests and negative authorization tests **first**, then implement the smallest vertical slice.
4. Publish OpenAPI for each new BE function; configure stable JSON schemas for each operation/event; add correlation and sensitive-data redaction.
5. Verify unit, integration, API regression, failure/restart/idempotency, role-deny, and UI tests appropriate to the change.
6. Record evidence: command, exit status, sample request/response (redacted), screenshots, and link to CI build.
7. Return **Files and Structure Summary**: New / Updated / Deleted / No Change with actual `/Project/Folder/File.cs` paths.
8. Present uncertain assumptions and risks. Do not claim tested, approved, deployed, or PROD-ready when not verified.

## Skills

- New service or operation: `.agents/skills/unity-capability-service/SKILL.md`
- BPMN and BOB engine: `.agents/skills/unity-bob-bpmn/SKILL.md`
- Rules and bindings: `.agents/skills/unity-amie-bindings/SKILL.md`
- BE Blazor screens and UI testing: `.agents/skills/unity-be-blazor/SKILL.md`
- QA, releases, controls: `.agents/skills/unity-release-regression/SKILL.md`

## Hard stops

- Unknown AMIE contract or conflicts with existing code -> stop speculative implementation; document exact mismatch.
- An operation not approved for a service identity -> fail closed.
- Uncertain CyberArk write outcome -> reconcile before retry; never blind replay.
- Workflow referencing unsupported BPMN element -> reject publication rather than silently alter behavior.
- Missing PROD bank approval -> stop activation, regardless of demo quality.

## v1.0 screen/SDK implementation rules

- Read the new `INDEX.md`, `docs/ui/07-SCREEN-BY-SCREEN-WIREFRAMES.md`, `docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md`, and `docs/sdk/00-SDK-PURPOSE-SERVICE-BOUNDARIES.md` before modifying BE or a capability.
- Each BE action has stable `data-control-id` with proposed API, role/scope, state/error and audit; implement API first and include a direct negative authorization test. Do not copy wireframe's fake state into production.
- Read `jobs/interaction/INDEX.md` for 17 detailed subtasks mapped to JOB-00..20. Use the `wireframes/UI_CONTROL_REGISTRY_v1.0.json` to generate UI test IDs and owner matrices.
- Distinguish compiled local handler registration, trusted manifest publication, operational availability and workflow publication. A service scan cannot grant production permission.
- Existing AMIE interfaces and the current CyberArk service MUST be inspected before creating new SDK types. A rule-passed state is not a CyberArk-write-succeeded state.
- Any proposed endpoint/handler name in this pack may be changed during JOB-01 only through a reviewed contract decision and updated fixtures/tests.

## v1.1 BPMN UI and cross-service extensions

- For designer work, read `docs/ui/13-*.md` through `18-*.md`, `docs/diagrams/DIAGRAMS.md`, and `jobs/bpmn/INDEX.md`. For any new BE control map stable CMP-* ID to approved API, auth, audit, error and test.
- UI components are reusable by design: `SchemaField`, `TypedBindingPicker`, `BpmnCanvas`, `BpmnNodeInspector`, `AmieRulePicker`, `TriggerTypePicker`, `BatchStatusCard`, and `RunControlPanel`; never hardcode DCMS or CyberArk-specific Razor fields.
- New workflow use cases (NAS EF/API, DCMS, Account Delete, AutoSys Policy Drift and hygiene) are **test configurations**, not BOB-core branches. Do not conflate Policy Drift ZIP/INI baseline comparisons with hygiene safe moves.
- `NAS` meaning/EF owner and endpoints, original Policy Drift queries/sanitizer, AutoSys version and CyberArk delete scope require source verification. Never create generic SQL or unapproved destructive operations.
- BPMN XML+DI is canonical; imported unsupported executable elements must remain visible but blocked from publish. A wireframe passing browser QA does not mean runtime conformance or bank release approval.
