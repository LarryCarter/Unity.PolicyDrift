# BE-26 - Triggers and input forms builder

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-21, SDK-32, SDK-35

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Manual CSV, form, authenticated API, Kafka, AutoSys job-type configuration.

## Implementation actions

Implement trigger picker with schema hints. CSV upload uses managed fileRef; API outputs 202 runId; AutoSys job allowlist and sourceRunId mapping. Timer mode visually deferred unless implemented.

## API / message contracts

GET /trigger-types; PUT draft trigger; POST /uploads; POST /workflow-starts. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Invalid CSV rejected, API unauth denied, duplicate scheduler sourceRunId maps to same run, secrets hidden.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.
