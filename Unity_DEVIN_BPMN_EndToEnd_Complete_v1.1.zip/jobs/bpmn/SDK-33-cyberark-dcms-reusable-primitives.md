# SDK-33 - CyberArk DCMS reusable primitives

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** SDK-31, BOB-38, JOB-12

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Expose GetAccount/ApplyCustomAttributes/AddOrUpdate with verified handler contracts.

## Implementation actions

Inventory existing CyberArk client; build typed versioned operations and side-effect/reconciliation policy; AMIE maps custom fields; preserve in-memory update before API.

## API / message contracts

CyberArk operation manifest + local dispatcher. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

5-row DCMS passes; timeout marks UNKNOWN; account write confirmed separately from rule pass; no DCMS conditionals inside generic service.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.
