# SDK-36 - Policy Drift reusable ZIP/INI/EF operations

**Priority:** P1 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** SDK-32, SDK-35, BOB-38

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Preserve Policy Drift existing logic behind registered operations.

## Implementation actions

Find legacy parser, real PolicyId sanitizer, original SQL baseline query; wrap nested ZIP extraction/INI parse, normalize, compare, EF result save and reasons. Do not invent new policy model; compare original SQL to proposed EF logic.

## API / message contracts

Policy capability manifest, rule definitions and scheduled workflow binding. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

NO_DRIFT, DRIFT, MISSING_BASELINE, invalid INI, nested ZIP, duplicate and failure tests; no silent exclusion.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.
