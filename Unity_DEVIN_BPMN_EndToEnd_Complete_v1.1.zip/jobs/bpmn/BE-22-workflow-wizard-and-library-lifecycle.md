# BE-22 - Workflow wizard and library lifecycle

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-21, JOB-01, UI-12

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

New/clone/save/revision/compare/library owner and workflow lifecycle.

## Implementation actions

Create scoped new workflow wizard; application/owner/purpose/template; draft creation; ETag edits; immutable version listing; handling of unsaved changes, revision conflicts and no permission.

## API / message contracts

POST/PUT /workflow-drafts; GET /workflows /versions /diff. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Save/reload roundtrip; duplicate name 409; conflict 412 preserves client edits; only authorized authors can edit.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.
