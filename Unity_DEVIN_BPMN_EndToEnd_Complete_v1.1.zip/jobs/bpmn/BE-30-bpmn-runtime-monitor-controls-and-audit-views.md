# BE-30 - BPMN runtime monitor, controls and audit views

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-23, BOB-37, JOB-08, JOB-15

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Pinned BPMN diagram overlay, activity event timeline, pause/resume/cancel/restart, audit search.

## Implementation actions

Render status by BPMN node ID; query timeline with correlation; safe command dialogs with reason/runbook; show uncertain writes and distinct restart run; audit export masks secrets.

## API / message contracts

GET /runs snapshots /audit; POST /runs commands/restart. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Pause at checkpoints, not midwrite; 202 pending not success; unauthorized command denied; audit reconstructs actor/versions/ticket.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.
