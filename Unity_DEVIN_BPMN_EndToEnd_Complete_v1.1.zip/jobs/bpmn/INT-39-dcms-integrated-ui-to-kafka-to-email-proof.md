# INT-39 - DCMS integrated UI-to-Kafka-to-email proof

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-26, BE-27, BE-29, SDK-32, SDK-33, BOB-37, BOB-38

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

One real vertical slice from CSV to dashboard and report.

## Implementation actions

Wire BE upload to data staging and central BOB, Kafka to embedded CyberArk BOB, AMIE mappings, rows/outcome/audit, report/email capability and progress projections. Start with 5-row fixture; mark mock EPV effects.

## API / message contracts

POST upload/start; run progress/event/report APIs. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

All 5 row cases, batch count equality, Kafka idempotence, report/email separate, audit reconstruction, role-denial regression.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.
