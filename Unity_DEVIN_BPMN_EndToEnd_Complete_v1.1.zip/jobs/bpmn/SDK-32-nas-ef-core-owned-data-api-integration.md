# SDK-32 - NAS EF Core owned-data API integration

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** JOB-00, SDK-31

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Find actual NAS API EF models and publish typed data operations.

## Implementation actions

Audit NAS code/Swagger/DbContext/owner; reuse existing EF API operations; add StageBatch/GetRowsPage/MarkOutcome only where missing/authorized; concurrency and pagination; avoid cross-service DbContext.

## API / message contracts

Typed NAS capability endpoints and operation manifest. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

One BE-configured service task roundtrips real DEV API/EF; auth failure; repeat outcome idempotent; no raw SQL API.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.
