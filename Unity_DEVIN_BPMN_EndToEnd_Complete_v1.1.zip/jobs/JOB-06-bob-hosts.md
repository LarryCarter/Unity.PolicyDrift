# JOB-06 — Implement shared BOB execution core with central/embedded hosts

**Priority:** P0  
**Dependencies:** JOB-01, JOB-02, JOB-04, JOB-05  
**Suggested lane:** BOB Runtime  
**Planning target:** Nov 15–20 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Create common interpreter token/state transition and dispatch abstraction. Embedded uses DI for local handlers and existing AMIE; central uses persistent command wait/outcome mapping. Include process version pinning, status event emission, run controls at safe points and durable local sequential batch mode as required. Write host parity tests.

## Proposed target file groups (validate actual repo names first)

/Unity.BOB.Core/Execution/; /Unity.BOB.Embedded/; /Unity.BOB.Central/; /Unity.BOB.Tests/

## Definition of done / acceptance evidence

Same compiled workflow executes under both hosts with identical business step decisions; central returns to durable wait after Kafka dispatch; local run avoids per-operation Kafka; restart resumes pinned process.

## Functional, API and negative regression

Double result, pause during write, cancellation, missing version, timeout, worker crash and concurrent advancement pass tests.

## Guardrails / explicitly out of scope

Never add DCMS-specific branches or hardwire CyberArk into BOB.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-06: Implement shared BOB execution core with central/embedded hosts. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
