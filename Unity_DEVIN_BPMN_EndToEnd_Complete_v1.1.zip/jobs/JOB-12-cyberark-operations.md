# JOB-12 — Reconcile CyberArk primitives and implement missing reusable handlers

**Priority:** P0  
**Dependencies:** JOB-00, JOB-02, JOB-04  
**Suggested lane:** CyberArk capability  
**Planning target:** Nov 15–22 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Inventory existing real CyberArk integration. Expose vetted GetAccount, in-memory custom attribute patch, and AddOrUpdateAccount as registered handlers where missing. Require platform-supported attribute validation, revision checks, privileges, structured failures, reconciliation when API response lost. Host embedded sequential BOB subworkflow or adapt existing worker to shared interpreter.

## Proposed target file groups (validate actual repo names first)

/Unity.Capability.CyberArk/Operations/; /Unity.Capability.CyberArk/Runtime/; /Unity.Capability.CyberArk.Tests/

## Definition of done / acceptance evidence

A test row reads account, AMIE maps attributes, in-memory patch is validated, authorized add/update occurs and outcome carries external reference; primitives appear in registry and are reusable by another workflow.

## Functional, API and negative regression

No account found, forbidden safe, unsupported custom attribute, revision conflict, timeout after possible write, duplicate batch row and permission denied handled.

## Guardrails / explicitly out of scope

Do not hardcode DCMS process order or AMIE decisions in CyberArk service; no PROD account mutation without approval.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-12: Reconcile CyberArk primitives and implement missing reusable handlers. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
