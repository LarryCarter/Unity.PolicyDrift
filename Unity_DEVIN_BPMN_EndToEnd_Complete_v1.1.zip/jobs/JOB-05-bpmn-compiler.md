# JOB-05 — Build BPMN 2.0 XML parser/compiler with explicit MVP semantics

**Priority:** P0  
**Dependencies:** JOB-01  
**Suggested lane:** BOB Core  
**Planning target:** Nov 13–18 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Implement BPMN 2.0 XML+DI import/serialize, secure XML parsing, stable node IDs, supported element graph compiler, node-to-registered-operation/rule binding validation. P0 start/end, service task, business-rule task, exclusive gateway, flow, call/subprocess, sequential multi-instance and Kafka wait; reject unsupported elements. Add fixtures per actual semantic behavior.

## Proposed target file groups (validate actual repo names first)

/Unity.BOB.Core/Bpmn/; /Unity.BOB.Core/Compilation/; /Unity.BOB.Core.Tests/

## Definition of done / acceptance evidence

Real BPMN fixture roundtrips and compiles to tested graph; gateway picks right branch; call activity passes outputs; sequential rows execute in order; unsupported element rejected with node ID.

## Functional, API and negative regression

XXE/DTD, invalid graph, ambiguous gateway, missing default, invalid rule or handler, unsupported boundary/parallel cases rejected.

## Guardrails / explicitly out of scope

Do not claim full BPMN 2.0 conformance from XML parsing.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-05: Build BPMN 2.0 XML parser/compiler with explicit MVP semantics. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
