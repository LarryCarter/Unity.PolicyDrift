# JOB-16 — Build immutable config package, approval and Operations promotion gates

**Priority:** P0 design / PROD gated  
**Dependencies:** JOB-01, JOB-08, JOB-09  
**Suggested lane:** Release / Compliance  
**Planning target:** Nov 20–26 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Package BPMN, AMIE rule versions, operation/message dependency locks, logical bindings, owner/runbook refs and test evidence into immutable signed digest. Add draft/review/approve/publish/activate/retire APIs and BE Release Center. Integrate bank's existing change/approval process when available; role-separated Operations promotion, not developer PROD login.

## Proposed target file groups (validate actual repo names first)

/Unity.Release/; /Unity.BE/Components/Pages/ReleaseCenter.razor; /Unity.Release.Tests/

## Definition of done / acceptance evidence

Exact package bytes have same digest DEV and UAT; only approved environment bindings differ; unauthorized or unsigned PROD activation is blocked and audited; rollback selects previous version for new runs.

## Functional, API and negative regression

Tampered manifest, missing AMIE/capability version, fake ServiceNow ticket, wrong deployer, missing UAT evidence, inaccessible secrets/bindings and self-approval fail preflight.

## Guardrails / explicitly out of scope

Do not claim automatic production deployment before actual Wells Fargo controls and CI/CD integrations exist.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-16: Build immutable config package, approval and Operations promotion gates. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
