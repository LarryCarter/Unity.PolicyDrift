# JOB-13 — Connect reporting aggregation and independent Email Capability

**Priority:** P0  
**Dependencies:** JOB-02, JOB-07, JOB-11  
**Suggested lane:** Reporting / Email  
**Planning target:** Nov 18–23 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Inventory existing Email capability; implement or adapt typed `Reporting.GenerateBatchReport` and `Email.RequestNotification` operation descriptors and Kafka contracts. Report reads persisted batch row states through owner API, includes success/failure/no-change/skipped/unknown plus reason. AMIE picks approved template/recipients; email outcome independent from CyberArk updates.

## Proposed target file groups (validate actual repo names first)

/Unity.Capability.Reporting/; /Unity.Capability.Email/; /Unity.Reporting.Tests/; /Unity.Email.Tests/

## Definition of done / acceptance evidence

Five-row DCMS test generates report identical to stored results; Kafka email command accepted and outcome recorded with correlation; no SMTP/email handling in BOB.

## Functional, API and negative regression

Unknown row outcomes, restricted data in report, recipient policy denial, duplicate notification request, SMTP failure and email late completion tested.

## Guardrails / explicitly out of scope

Do not assume actual corporate email adapter or transport is approved; use marked simulator if not.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-13: Connect reporting aggregation and independent Email Capability. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
