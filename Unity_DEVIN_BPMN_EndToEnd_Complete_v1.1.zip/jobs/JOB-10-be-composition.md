# JOB-10 — Implement BE capability inspector, AMIE binding and schema-driven forms

**Priority:** P0  
**Dependencies:** JOB-03, JOB-04, JOB-05, JOB-09  
**Suggested lane:** BE composition  
**Planning target:** Nov 16–22 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Consume real registry and AMIE metadata APIs; render operation inputs/outputs, source picker (workflow/current row/prior step/AMIE/approved bindings), inspect version, permission, side effects, retry and audit. On save call backend binding compiler and expose actionable field/node diagnostics. Reuse AMIE rule editing if it exists.

## Proposed target file groups (validate actual repo names first)

/Unity.BE/Components/Workflow/OperationInspector.razor; /Unity.BE/Components/Workflow/AmieRulePicker.razor; /Unity.BE/Services/CapabilityCatalogApiClient.cs

## Definition of done / acceptance evidence

Drag an approved CyberArk operation, render required fields, select AMIE rule and wire output into next operation, validate and save without changing capability code.

## Functional, API and negative regression

Wrong source type, missing rule, forbidden operation, missing environment binding, secret field leak, stale descriptor tested.

## Guardrails / explicitly out of scope

Do not make mock arrays look like real registry or duplicate AMIE designer implementation.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-10: Implement BE capability inspector, AMIE binding and schema-driven forms. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
