# JOB-04 — Integrate existing AMIE rule evaluation and metadata into Unity

**Priority:** P0  
**Dependencies:** JOB-00, JOB-01  
**Suggested lane:** AMIE bridge  
**Planning target:** Nov 13–17 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Map existing AMIE evaluate/version/serialization/dependency APIs to the typed BOB adapter, exposing rule descriptor, input/output schema, validated data binding and safe decision result. Integrate embedded host and BE rule picker. Ensure no network roundtrip per local row and no second evaluator. Add rule version pin tests.

## Proposed target file groups (validate actual repo names first)

/Unity.Capabilities.AMIE/; /Unity.BOB.Contracts/Rules/; /Unity.AMIE.Integration.Tests/

## Definition of done / acceptance evidence

Real existing AMIE rule evaluates under local capability context; output feeds typed operation; rule version and safe decision audit recorded; new config can be published without changing operation handler.

## Functional, API and negative regression

Missing input, wrong type, unauthorized data, missing pinned version, incompatible rule output and privilege escalation through rule are rejected.

## Guardrails / explicitly out of scope

No new rule language or compile-from-UI arbitrary C#.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-04: Integrate existing AMIE rule evaluation and metadata into Unity. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
