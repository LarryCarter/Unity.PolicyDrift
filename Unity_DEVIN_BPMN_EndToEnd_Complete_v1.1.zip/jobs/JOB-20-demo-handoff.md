# JOB-20 — Perform integrated demo, review readiness, record gaps and owners

**Priority:** P0  
**Dependencies:** JOB-17, JOB-18; JOB-19 optional  
**Suggested lane:** Integration / Program  
**Planning target:** Nov 27–30 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Execute agreed UI/API demonstration script, rerun P0 regressions against exact demo package, reconcile docs with actual codepaths, collect bank control blockers, prepare clean build instructions and rollback/runbook. Mark which integrations are real, simulated, or future. Deliver evidence/known defects and next-step priority with owners.

## Proposed target file groups (validate actual repo names first)

/docs/testing/DEMO-EVIDENCE.md; /docs/roadmap/KNOWN-GAPS.md; /docs/decisions/REAL-REPOSITORY-MAP.md

## Definition of done / acceptance evidence

An authorized tester can build/run demo from clean instructions, show real package digest, automated results and audit, validate DCMS scenarios, and explain bank PROD gates honestly.

## Functional, API and negative regression

Cold-start run, missing service, expired identity, UI auth denial, lost Kafka and replay/run-control data correctness tested.

## Guardrails / explicitly out of scope

Do not describe a mock as release-ready or a pending CA as approved.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-20: Perform integrated demo, review readiness, record gaps and owners. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
