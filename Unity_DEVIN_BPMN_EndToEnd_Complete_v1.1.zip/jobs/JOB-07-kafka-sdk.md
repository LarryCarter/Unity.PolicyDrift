# JOB-07 — Implement Kafka command/outcome, outbox/inbox, correlation and dedupe

**Priority:** P0  
**Dependencies:** JOB-01, JOB-02  
**Suggested lane:** Messaging  
**Planning target:** Nov 14–20 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Adapt existing approved Kafka library. Serialize versioned envelope; route by approved logical bindings, map to allowed physical broker topics via environment config. Implement SQL transactional outbox with owning state, consumer inbox dedupe, completion correlation, DLQ policy, traceparent propagation and worker authorization. Integrate with BOB host and SDK.

## Proposed target file groups (validate actual repo names first)

/Unity.Capabilities.Kafka/; /Unity.BOB.Central/Messaging/; /Unity.Messaging.Tests/

## Definition of done / acceptance evidence

Central BOB command reaches test capability; outcome resumes correct run/activity once; duplicate command/outcome causes no duplicate state; broker outage can be recovered without losing committed command.

## Functional, API and negative regression

Wrong producer identity, malformed schema, unauthorized operation, old schema, poison message, late cancel, crash-after-write/unknown outcome handled.

## Guardrails / explicitly out of scope

Do not assert exactly-once external CyberArk writes; no full CSV on Kafka.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-07: Implement Kafka command/outcome, outbox/inbox, correlation and dedupe. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
