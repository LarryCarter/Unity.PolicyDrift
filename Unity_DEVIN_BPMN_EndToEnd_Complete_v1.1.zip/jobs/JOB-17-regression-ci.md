# JOB-17 — Build full API, BPMN, role-denial and fault-injection regression

**Priority:** P0  
**Dependencies:** JOB-01, JOB-02, JOB-05; integrate others as arrive  
**Suggested lane:** QA / Integration  
**Planning target:** Nov 14–29 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Create CI test projects for R01–R18 from regression matrix: manifest+schema+policy, parser semantics, AMIE adapter, Kafka duplicate, SQL restart, auth, controls, DCMS 5-row fixture, report/email. Publish OpenAPI and test results. Add browser Playwright-equivalent using already approved tools; screenshots and audit evidence.

## Proposed target file groups (validate actual repo names first)

/Unity.Tests.Contracts/; /Unity.Tests.Integration/; /Unity.Tests.E2E/; /.github/workflows/ or bank-approved CI pipeline

## Definition of done / acceptance evidence

All implemented BE actions are exercised through API; test evidence includes fixture/version/commit/digest/UTC; CI fails contract drift and known unsafe cases; no silent mock behavior.

## Functional, API and negative regression

Run fault injection, unauthorized APIs, broker outage, crash-after-write, cross-scope reads, unsupported BPMN, missing rule and release-gate checks.

## Guardrails / explicitly out of scope

Avoid introducing unapproved CI plugins or writing secrets to build logs.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-17: Build full API, BPMN, role-denial and fault-injection regression. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
