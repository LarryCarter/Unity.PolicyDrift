# JOB-18 — Integrate and validate real DCMS end-to-end vertical slice

**Priority:** P0  
**Dependencies:** JOB-02 through JOB-15 as relevant  
**Suggested lane:** DCMS pilot / Integration  
**Planning target:** Nov 21–27 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Configure DCMS in BE from registered primitives; upload CSV, stage batch and row GUIDs, start central BOB, run sequential embedded CyberArk BOB with existing AMIE mapping, persist confirmed row results, publish progress, generate report and send via Email capability through Kafka. Label simulator vs actual integration.

## Proposed target file groups (validate actual repo names first)

/Unity.DCMS/Configurations/; /Unity.DCMS.Tests/; /docs/testing/DCMS-RUN-EVIDENCE.md

## Definition of done / acceptance evidence

Five-row fixture produces correct audit, counts, per-row reasons and report; one safe actual approved nonprod CyberArk update if available; no modification required in BOB Core for DCMS.

## Functional, API and negative regression

Unknown external write does not blindly retry; failure report accurate; role/cancel/restart/concurrent batch tests pass; email failure separate.

## Guardrails / explicitly out of scope

No implicit promise of PROD release or access to live PAM accounts.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-18: Integrate and validate real DCMS end-to-end vertical slice. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
