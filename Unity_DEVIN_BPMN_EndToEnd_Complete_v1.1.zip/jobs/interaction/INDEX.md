# UI + SDK v1.0 Detailed DEVIN Job Index

These are **subtask refinements** of existing JOB-00..JOB-20, not a competing roadmap. Actual source paths and namespaces must be confirmed during SDK-10/JOB-00. Do not run all tickets in parallel before JOB-01 contract freeze.

| Ticket | Priority | Existing jobs | Dependencies | Goal |
|---|---|---|---|---|
| [SDK-10](SDK-10-repo-and-contract-seam-audit.md) | P0 | JOB-00, JOB-01 | None | Repo and contract seam audit |
| [SDK-11](SDK-11-trusted-handler-registration-and-di-sdk.md) | P0 | JOB-02 | SDK-10 | Trusted handler registration and DI SDK |
| [SDK-12](SDK-12-capability-registry-and-trusted-publication.md) | P0 | JOB-03 | SDK-11 | Capability registry and trusted publication |
| [SDK-13](SDK-13-existing-amie-adapter-and-rule-metadata.md) | P0 | JOB-04 | SDK-10, SDK-11 | Existing AMIE adapter and rule metadata |
| [SDK-14](SDK-14-shared-bob-operation-dispatcher-and-host-modes.md) | P0 | JOB-05, JOB-06 | SDK-11, SDK-13 | Shared BOB operation dispatcher and host modes |
| [SDK-15](SDK-15-kafka-inbox-outbox-and-command-contracts.md) | P0 | JOB-07 | SDK-11, SDK-14 | Kafka inbox/outbox and command contracts |
| [SDK-16](SDK-16-audit,-authorization-and-operational-controls.md) | P0 | JOB-08, JOB-15 | SDK-11, SDK-14 | Audit, authorization and operational controls |
| [SDK-17](SDK-17-capability-service-template-and-reusable-skill-update.md) | P0 | JOB-02, JOB-12, JOB-13 | SDK-11, SDK-12 | Capability service template and reusable skill update |
| [SDK-18](SDK-18-dcms-vertical-slice-plus-second-workload-reuse-proof.md) | P0 | JOB-11..JOB-13, JOB-18, JOB-19 | SDK-12, SDK-13, SDK-14, SDK-15, SDK-16, UI-15 | DCMS vertical slice plus second-workload reuse proof |
| [UI-10](UI-10-be-shell,-screen-routing-and-role-scoped-api-clients.md) | P0 | JOB-09, JOB-15 | SDK-10 | BE shell, screen routing and role-scoped API clients |
| [UI-11](UI-11-capability-catalog,-inspector-and-onboarding-wizard.md) | P0 | JOB-03, JOB-10 | UI-10, SDK-12 | Capability Catalog, inspector and onboarding wizard |
| [UI-12](UI-12-application-studio-and-workflow-library-lifecycle.md) | P0 | JOB-10, JOB-16 | UI-10, SDK-12 | Application Studio and Workflow Library lifecycle |
| [UI-13](UI-13-blazor-bpmn-2.0-canvas-and-typed-operation-inspector.md) | P0 | JOB-09, JOB-05 | UI-10, SDK-14 | Blazor BPMN 2.0 canvas and typed operation inspector |
| [UI-14](UI-14-amie-binding-picker-and-trigger-forms-editor.md) | P0 | JOB-04, JOB-10, JOB-11 | UI-10, SDK-13, UI-13 | AMIE binding picker and trigger/forms editor |
| [UI-15](UI-15-business-work-queue-and-bpmn-run-monitor.md) | P0 | JOB-14, JOB-18 | UI-10, SDK-14, SDK-16 | Business Work Queue and BPMN Run Monitor |
| [UI-16](UI-16-operator-controls,-runbooks-and-audit-screens.md) | P0 | JOB-15, JOB-08 | UI-10, SDK-16 | Operator controls, runbooks and audit screens |
| [UI-17](UI-17-environment-release-regression-+-107-control-proof.md) | P0 | JOB-16, JOB-17, JOB-20 | UI-10, SDK-12, SDK-16 | Environment/Release/Regression + 107-control proof |

## Parallel delivery lanes

- Lane 0 (gate): SDK-10/JOB-00 source audit -> JOB-01 contract freeze.
- Lane 1 (SDK): SDK-11 -> SDK-12; in parallel SDK-13 after source audit; SDK-14 after SDK-11/13; SDK-15/16 after host model.
- Lane 2 (Blazor): UI-10 -> UI-11/12/13; UI-14 after rule and designer contracts; UI-15/16 after real read/control APIs.
- Lane 3 (pilot): SDK-18 only after registry, BOB host, Kafka, audit and data/handlers viable; five-row fixture first.
- Lane 4 (QA/release): UI-17 and JOB-17 continuous, no late-stage bolt-on.

## Priority cuts under deadline pressure

P0: typed operation registration -> registry -> AMIE/BOB binding -> Kafka -> durable audit -> BE minimal designer and business dashboard -> DCMS five-row fixture. Keep RBAC, safe side effects, API regression and real control gate nonnegotiable.

P1 later: full designer gestures/custom rendering polish, advanced BPMN gateways, parallel batch processing, version migration in-flight, AutoSys ingestion, live ServiceNow integration and generic human forms.

