# SDK-13 - Existing AMIE adapter and rule metadata

**Priority:** P0. **Refines original jobs:** JOB-04. **Dependencies:** SDK-10, SDK-11. **Status:** Proposed / repository verification required.

## Purpose and scope

Thin wrapper around existing AMIE rules, metadata and schema; typed fact binding; exact rule version.

## Engineering implementation instructions

Read existing AMIE API; implement adapter to evaluate typed facts locally; publish rule descriptor; compile type validation; pinned version and reason output; tests for false/skip/NoChange.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.AMIE/AmieRuntimeAdapter.cs; docs/contracts/AMIE-RULE-DESCRIPTOR.md

## Definition of done / measurable proof

DCMS.AttributeMap rule fixture maps source row to approved typed patch via existing evaluator; embedded host has no central per-row roundtrip.

## Negative / security / recovery criteria

Do not build second AMIE runtime; missing facts/version or illegal field rejects publish; rule pass not treated as side-effect success.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-13: Existing AMIE adapter and rule metadata. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
