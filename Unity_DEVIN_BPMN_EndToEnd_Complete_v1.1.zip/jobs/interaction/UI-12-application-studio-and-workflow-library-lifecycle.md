# UI-12 - Application Studio and Workflow Library lifecycle

**Priority:** P0. **Refines original jobs:** JOB-10, JOB-16. **Dependencies:** UI-10, SDK-12. **Status:** Proposed / repository verification required.

## Purpose and scope

APP-01..04 LIB-01..08; app composition, version diff, immutable lifecycle, ServiceNow metadata.

## Engineering implementation instructions

Build scoped application blueprint UI, library filters, draft clone/import, reviewer diff, submit/approve/publish/retire with separate identity and ETags.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Applications/ApplicationStudio.razor; /BusinessEnablement/Components/Workflows/WorkflowLibrary.razor

## Definition of done / measurable proof

Published version immutable, exact dependency lock displayed, new draft from clone.

## Negative / security / recovery criteria

Cannot self-approve, edit published, publish invalid, or bind unavailable version.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-12: Application Studio and Workflow Library lifecycle. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
