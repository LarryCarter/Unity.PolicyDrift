# SDK-12 - Capability registry and trusted publication

**Priority:** P0. **Refines original jobs:** JOB-03. **Dependencies:** SDK-11. **Status:** Proposed / repository verification required.

## Purpose and scope

Versioned manifest publisher/registry admission/readiness and secure discovery APIs.

## Engineering implementation instructions

Implement manifest validation/publisher identity, code-release provenance/digest, register vs available states; GET capability/operation/version/schema/readiness with role and scope filtering; provide diagnostics.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.Registry/ManifestController.cs; /Unity.Capabilities.Registry/ManifestAdmissionService.cs

## Definition of done / measurable proof

An approved deployed service is discoverable with schemas, correct readiness and stable contract version.

## Negative / security / recovery criteria

Unapproved manifest or unhealthy deployment not executable; missing policy blocks publication; no auto-prod authorization.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-12: Capability registry and trusted publication. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
