# UI-17 - Environment/Release/Regression + 107-control proof

**Priority:** P0. **Refines original jobs:** JOB-16, JOB-17, JOB-20. **Dependencies:** UI-10, SDK-12, SDK-16. **Status:** Proposed / repository verification required.

## Purpose and scope

ENV-01..04 REL-01..06 TST-01..05 plus all 107 control API tests.

## Engineering implementation instructions

Implement redacted environment refs, digest dependency preflight, controlled UAT request, PROD auth gate, regression suite evidence; automated Playwright and API tests from JSON registry.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Release/ReleaseCenter.razor; /BusinessEnablement.Tests/Functional/

## Definition of done / measurable proof

All 107 controls have screen/API ownership and test, release blocked without real bank approvals, no inert buttons.

## Negative / security / recovery criteria

Manifest forged/ETag conflict/approval missing, offline monitor, wrong role all safe.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-17: Environment/Release/Regression + 107-control proof. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
