# UI-10 - BE shell, screen routing and role-scoped API clients

**Priority:** P0. **Refines original jobs:** JOB-09, JOB-15. **Dependencies:** SDK-10. **Status:** Proposed / repository verification required.

## Purpose and scope

Blazor nav/app context, typed API clients, busy/error/empty states, security checks, action IDs.

## Engineering implementation instructions

Build layout and route pages from UI-07; role/scope policy from backend; live region status with correlation; global env selection safe; action test selectors; no direct Kafka/SQL in browser.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Layout/UnityShell.razor; /BusinessEnablement/Services/UnityApiClient.cs

## Definition of done / measurable proof

19 route shells load scoped data and show denied state, proper keyboard/focus; real API behind each control.

## Negative / security / recovery criteria

Persona switcher wireframe never becomes auth bypass; direct unauthorized API is 403.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-10: BE shell, screen routing and role-scoped API clients. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
