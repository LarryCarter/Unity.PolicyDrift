# SDK-15 - Kafka inbox/outbox and command contracts

**Priority:** P0. **Refines original jobs:** JOB-07. **Dependencies:** SDK-11, SDK-14. **Status:** Proposed / repository verification required.

## Purpose and scope

Transport for cross-service BOB tasks: logical topic contract, auth, correlation, idempotency, retry/reconcile and DLQ.

## Engineering implementation instructions

Integrate approved broker library; envelope schema; outbox with BOB waiting state; worker consumer verifies identity/permission/version; inbox dedup; correlated outcome; partitioning and trace; broker test harness.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.Kafka/CommandConsumer.cs; /BOB.Central/Messaging/OutcomeConsumer.cs

## Definition of done / measurable proof

Crash/retry fixture eventually completes exactly one workflow activity from a duplicated command; no duplicate side-effect invocation.

## Negative / security / recovery criteria

Cross-run correlation mismatch, poison message, topic ACL denial, unknown outcome and out-of-order events rejected/held.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-15: Kafka inbox/outbox and command contracts. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
