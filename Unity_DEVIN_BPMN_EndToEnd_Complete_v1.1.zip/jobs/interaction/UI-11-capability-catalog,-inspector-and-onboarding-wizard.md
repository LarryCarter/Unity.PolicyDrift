# UI-11 - Capability Catalog, inspector and onboarding wizard

**Priority:** P0. **Refines original jobs:** JOB-03, JOB-10. **Dependencies:** UI-10, SDK-12. **Status:** Proposed / repository verification required.

## Purpose and scope

CAT-01..04 OP-01..05 ON-01..06; searchable operations, schema/host/policy and approval/health distinction.

## Engineering implementation instructions

Implement registry querying, paging, manifest draft wizard, rule/operation schema renderer, safe DEV fixture test, request-new-primitive workflow.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Capabilities/CapabilityCatalog.razor; /BusinessEnablement/Components/Capabilities/OperationInspector.razor

## Definition of done / measurable proof

Published operation appears dynamically and insert service task reference; approved vs available shown separately.

## Negative / security / recovery criteria

Unapproved operation cannot bind; unknown side-effect/reconcile policy flagged; forbidden API denies.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-11: Capability Catalog, inspector and onboarding wizard. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
