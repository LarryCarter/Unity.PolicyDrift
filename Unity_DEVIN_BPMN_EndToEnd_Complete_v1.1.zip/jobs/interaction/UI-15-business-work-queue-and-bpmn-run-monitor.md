# UI-15 - Business Work Queue and BPMN Run Monitor

**Priority:** P0. **Refines original jobs:** JOB-14, JOB-18. **Dependencies:** UI-10, SDK-14, SDK-16. **Status:** Proposed / repository verification required.

## Purpose and scope

BUS-01..07 RUN-01..06; business aggregate view vs technical overlay, scoped live status.

## Engineering implementation instructions

Implement read APIs, paged row reasons, terminal count logic, report link; authorized technical BPMN overlay from published version and event timeline; SignalR or approved push plus GET refresh on reconnect.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Business/BatchQueue.razor; /BusinessEnablement/Components/Monitoring/RunMonitor.razor

## Definition of done / measurable proof

Business sees progress and reasons without technical details; Operators see exact activity/correlation; no fake percent.

## Negative / security / recovery criteria

Cross-user batch and sensitive payload redacted; reconnect corrects missed events.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-15: Business Work Queue and BPMN Run Monitor. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
