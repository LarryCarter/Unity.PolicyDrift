# SDK-17 - Capability service template and reusable skill update

**Priority:** P0. **Refines original jobs:** JOB-02, JOB-12, JOB-13. **Dependencies:** SDK-11, SDK-12. **Status:** Proposed / repository verification required.

## Purpose and scope

Reusable new service archetype/template and updated repository Skill for CyberArk, Email, Data, Reporting, Identity and Legacy.

## Engineering implementation instructions

Provide approved project scaffold with handler, DTO, manifest, Kafka wiring, AMIE/BOB adapters, health/audit tests and README; update .agents/skills/unity-capability-service with exact repo-validated conventions.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capability.Template/; /.agents/skills/unity-capability-service/SKILL.md

## Definition of done / measurable proof

Generate sample safe capability, compile/tests pass, manifest auto-discovers, BE inspector can bind with no special Razor code.

## Negative / security / recovery criteria

Template never generates PROD secret, arbitrary SQL/REST operation, unbounded broker subscription or assumed CA approval.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-17: Capability service template and reusable skill update. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
