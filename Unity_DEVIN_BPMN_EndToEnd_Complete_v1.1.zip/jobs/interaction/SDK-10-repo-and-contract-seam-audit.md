# SDK-10 - Repo and contract seam audit

**Priority:** P0. **Refines original jobs:** JOB-00, JOB-01. **Dependencies:** None. **Status:** Proposed / repository verification required.

## Purpose and scope

Read-only repo map; crosswalk v0.9 proposed IUnityOperationHandler / actual AMIE, BOB, Kafka and CVIS services.

## Engineering implementation instructions

Inspect root AGENTS and actual solution, codebase references; map existing AMIE API/methods and data access patterns; inventory CyberArk operations and approved libraries; propose exact DTO and namespaces; identify duplicate abstractions to avoid.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.Contracts (actual path discovered); docs/decisions/OPEN-REPOSITORY-QUESTIONS.md

## Definition of done / measurable proof

A source-cited mapping exists for every proposed interface; maintain a gap list with owner and PR dependencies.

## Negative / security / recovery criteria

No source edits; reject claims that proposed SDK APIs already exist.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-10: Repo and contract seam audit. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
