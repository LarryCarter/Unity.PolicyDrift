# SDK-14 - Shared BOB operation dispatcher and host modes

**Priority:** P0. **Refines original jobs:** JOB-05, JOB-06. **Dependencies:** SDK-11, SDK-13. **Status:** Proposed / repository verification required.

## Purpose and scope

One interpreter, local DI and central Kafka dispatch adapters; typed context and safe checkpoints.

## Engineering implementation instructions

Wire compiler operation binding to registry resolution, pinned version and host; local handler execution; durable central wait; sequential multi-instance and child workflow; pause/resume/cancel contract; schema mapping and optimistic concurrency.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BOB.Core/Runtime/WorkflowExecutor.cs; /BOB.Embedded/Execution/LocalOperationDispatcher.cs

## Definition of done / measurable proof

3-row sequential BPMN fixture follows same token semantics embedded and central; service task reaches registered handler and returns outcome.

## Negative / security / recovery criteria

Unsupported BPMN, missing rule/handler, duplicate outcome, pause-in-write and stale revision all safe.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-14: Shared BOB operation dispatcher and host modes. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
