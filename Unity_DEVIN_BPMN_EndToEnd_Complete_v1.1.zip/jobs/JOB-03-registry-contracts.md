# JOB-03 — Create trusted registry, approval/health view and operation descriptor APIs

**Priority:** P0  
**Dependencies:** JOB-01, JOB-02  
**Suggested lane:** Platform Registry / BE API  
**Planning target:** Nov 14–18 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Receive trusted published manifest from capability deploy identity; validate signature/attestation and contract compatibility; store version + owner + availability state, separate from permission/health. Expose paginated authorized APIs to enumerate capability, operations, input/output schemas, AMIE dependencies, messaging declarations. Reject conflicting manifests.

## Proposed target file groups (validate actual repo names first)

/Unity.Registry/; /Unity.Registry.API/; /Unity.Registry.Tests/

## Definition of done / acceptance evidence

BE/API can list `CyberArk.GetAccount@1.0` with correct schema after approved nonproduction publication; unavailable/unapproved entries cannot be invoked; registry accepts multiple capability services.

## Functional, API and negative regression

Unsigned publisher, wrong owner, duplicate version/content conflict, incompatible upgrade, stale health and forbidden scope rejected or correctly marked.

## Guardrails / explicitly out of scope

Do not provision enterprise Kafka topics or ACLs merely because manifest requests them.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-03: Create trusted registry, approval/health view and operation descriptor APIs. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
