# JOB-11 — Build CSV/API trigger and DCMS batch/row staging interface

**Priority:** P0  
**Dependencies:** JOB-01, JOB-08  
**Suggested lane:** Ingestion / Data Owner  
**Planning target:** Nov 15–21 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Determine actual DCMS data owner/schema and approved upload/storage. Implement secure CSV validation/import, batch number allocation, GUID per row, transactionally staged row states, paged authorized read and outcome update APIs, idempotent upload. Generalize trigger envelope for manual and API initiation; leave AutoSys/DB polling as future adapter.

## Proposed target file groups (validate actual repo names first)

/Unity.Capability.Data/; /Unity.DCMS/Import/; /Unity.DCMS/Storage/; /Unity.DCMS.Tests/

## Definition of done / acceptance evidence

BE or API uploads safe CSV; DB stores batch+unique row IDs; queried status matches row outcomes; duplicate upload policy is deterministic; no CSV body shipped over Kafka.

## Functional, API and negative regression

Malformed headers/quotes, encoding, duplicate account keys, oversized upload, unauthorized data access, partially staged batch tested.

## Guardrails / explicitly out of scope

No arbitrary SQL capability and no unapproved production file import.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-11: Build CSV/API trigger and DCMS batch/row staging interface. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
