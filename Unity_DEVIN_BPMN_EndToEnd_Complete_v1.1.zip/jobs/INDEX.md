# DEVIN Job Index — Independent, Mergeable Work Packets

Every job is a PR-sized scope or a clearly separable Epic. Distinct owners/worktrees; do not assign one giant all-platform task. Dependencies require reviewed contracts/fixtures, not just an open PR. Refer to `docs/roadmap/DELIVERY-PLAN.md` for gates and staffing.

| Job | Priority | Lane | Depends on | Proposed target |
|---|---|---|---|---|
| [JOB-00 — Reconcile actual repo, working code, approved dependencies](JOB-00-reconcile-repository.md) | P0 | Platform architecture | None | Nov 11–12 |
| [JOB-01 — Freeze minimum cross-team contracts and acceptance fixtures](JOB-01-freeze-contracts.md) | P0 | Platform / SDK / BOB owners | JOB-00 | Nov 12–13 |
| [JOB-02 — Implement common capability SDK and DI operation registration](JOB-02-capability-sdk.md) | P0 | Capability SDK | JOB-01 | Nov 13–17 |
| [JOB-03 — Create trusted registry, approval/health view and operation descriptor APIs](JOB-03-registry-contracts.md) | P0 | Platform Registry / BE API | JOB-01, JOB-02 | Nov 14–18 |
| [JOB-04 — Integrate existing AMIE rule evaluation and metadata into Unity](JOB-04-amie-adapter.md) | P0 | AMIE bridge | JOB-00, JOB-01 | Nov 13–17 |
| [JOB-05 — Build BPMN 2.0 XML parser/compiler with explicit MVP semantics](JOB-05-bpmn-compiler.md) | P0 | BOB Core | JOB-01 | Nov 13–18 |
| [JOB-06 — Implement shared BOB execution core with central/embedded hosts](JOB-06-bob-hosts.md) | P0 | BOB Runtime | JOB-01, JOB-02, JOB-04, JOB-05 | Nov 15–20 |
| [JOB-07 — Implement Kafka command/outcome, outbox/inbox, correlation and dedupe](JOB-07-kafka-sdk.md) | P0 | Messaging | JOB-01, JOB-02 | Nov 14–20 |
| [JOB-08 — Implement MSSQL workflow state, audit timeline and projections](JOB-08-sql-audit.md) | P0 | Persistence / Audit | JOB-01, JOB-05 | Nov 14–20 |
| [JOB-09 — Implement Blazor Workflow Library and BPMN canvas](JOB-09-be-designer.md) | P0 | BE UX | JOB-01, JOB-05 | Nov 14–22 |
| [JOB-10 — Implement BE capability inspector, AMIE binding and schema-driven forms](JOB-10-be-composition.md) | P0 | BE composition | JOB-03, JOB-04, JOB-05, JOB-09 | Nov 16–22 |
| [JOB-11 — Build CSV/API trigger and DCMS batch/row staging interface](JOB-11-input-trigger-staging.md) | P0 | Ingestion / Data Owner | JOB-01, JOB-08 | Nov 15–21 |
| [JOB-12 — Reconcile CyberArk primitives and implement missing reusable handlers](JOB-12-cyberark-operations.md) | P0 | CyberArk capability | JOB-00, JOB-02, JOB-04 | Nov 15–22 |
| [JOB-13 — Connect reporting aggregation and independent Email Capability](JOB-13-reporting-email.md) | P0 | Reporting / Email | JOB-02, JOB-07, JOB-11 | Nov 18–23 |
| [JOB-14 — Implement business progress, BPMN run monitor and near-real-time updates](JOB-14-be-monitor.md) | P0 | BE monitoring | JOB-07, JOB-08, JOB-09 | Nov 19–24 |
| [JOB-15 — Implement policy enforcement, run controls and runbooks](JOB-15-rbac-operator.md) | P0 | Security / Operations | JOB-06, JOB-08, JOB-14 | Nov 19–25 |
| [JOB-16 — Build immutable config package, approval and Operations promotion gates](JOB-16-release-package.md) | P0 design / PROD gated | Release / Compliance | JOB-01, JOB-08, JOB-09 | Nov 20–26 |
| [JOB-17 — Build full API, BPMN, role-denial and fault-injection regression](JOB-17-regression-ci.md) | P0 | QA / Integration | JOB-01, JOB-02, JOB-05; integrate others as arrive | Nov 14–29 |
| [JOB-18 — Integrate and validate real DCMS end-to-end vertical slice](JOB-18-dcms-e2e.md) | P0 | DCMS pilot / Integration | JOB-02 through JOB-15 as relevant | Nov 21–27 |
| [JOB-19 — Prove configuration reuse with Hygiene or Onboarding](JOB-19-second-workload.md) | P1 target | Application / Reuse | JOB-18 | Nov 24–29 |
| [JOB-20 — Perform integrated demo, review readiness, record gaps and owners](JOB-20-demo-handoff.md) | P0 | Integration / Program | JOB-17, JOB-18; JOB-19 optional | Nov 27–30 |

## Parallelization and coordination

JOB-00 and JOB-01 precede broad writes. SDK/registry, BOB, AMIE, Kafka, SQL and BE teams can work in separate worktrees after the contract gate. Reserve one integration owner for cross-service fixtures and merging. API and contract tests start with the first PR; JOB-17 is continuous, not a final-week afterthought.

## Acceptance and triage

P0 first: a truthful single DCMS demonstration beats multiple disconnected mock screens. If capacity falls short, defer P1 and UI polish rather than weaken authorization, audit, idempotency, versioning, safety or contract tests. PROD depends on actual bank controls.


## UI + SDK v1.0 detailed subtasks

See [17 scoped interaction and SDK task packets](interaction/INDEX.md). They expand original jobs rather than duplicating project ownership. Complete JOB-00 and JOB-01 before parallel code generation.

## v1.1 detailed designer/workflow tasks

See [jobs/bpmn/INDEX.md](bpmn/INDEX.md) for 20 actionable design/execution/fixture tasks BE-21 through QA-40. They refine existing jobs rather than creating another BOB or AMIE engine. Original 21 jobs and earlier interaction subtasks remain valid unless a reviewed contract decision supersedes one.
