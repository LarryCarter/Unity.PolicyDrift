# JOB-14 — Implement business progress, BPMN run monitor and near-real-time updates

**Priority:** P0  
**Dependencies:** JOB-07, JOB-08, JOB-09  
**Suggested lane:** BE monitoring  
**Planning target:** Nov 19–24 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Create authorized read APIs/projection for batch/row counts and technical run/activity/correlation timeline. Implement role-specific Business Work Queue and BPMN Run Monitor; integrate SignalR/SSE only to push changes, reload authoritative SQL-backed state after reconnect. Mask privileged data and paginate row results.

## Proposed target file groups (validate actual repo names first)

/Unity.BE/Components/Pages/BusinessWorkQueue.razor; /Unity.BE/Components/Pages/RunMonitor.razor; /Unity.BE/Services/RunMonitorApiClient.cs

## Definition of done / acceptance evidence

Business user sees meaningful batch counts/percent/reasons without workflow graph; support sees same process on BPMN overlay with accurate Kafka/AMIE/handler evidence; status remains correct after reconnect.

## Functional, API and negative regression

Other user's batch read denied, lagged projection timestamp clear, duplicate live update, reconnect and 1000-row pagination tested.

## Guardrails / explicitly out of scope

Do not subscribe browser directly to Kafka or treat SignalR as audit store.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-14: Implement business progress, BPMN run monitor and near-real-time updates. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
