# JOB-01 — Freeze minimum cross-team contracts and acceptance fixtures

**Priority:** P0  
**Dependencies:** JOB-00  
**Suggested lane:** Platform / SDK / BOB owners  
**Planning target:** Nov 12–13 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Reconcile proposed `OperationDescriptor`, invocation context, outcome/error taxonomy, AMIE adapter, BPMN extension, Kafka envelope, release lock, audit event and API route families against real code. Establish schema version conventions, unambiguous operation key resolution and approved host modes. Record ADRs for conflicts. Commit fixture + contract test project before parallel implementation.

## Proposed target file groups (validate actual repo names first)

/Unity.Capabilities.Contracts/Descriptors/*.cs; /Unity.BOB.Contracts/Bindings/*.cs; /Unity.Contracts.Tests/*.cs; /docs/decisions/CONTRACT-LOCK.md

## Definition of done / acceptance evidence

A sample safe test operation resolves through a descriptor and a typed sample AMIE output feeds its input; broker envelope schema and run context are approved by owners; contract tests fail incompatibility.

## Functional, API and negative regression

Duplicate operation key, missing required field, downgraded version and unauthorized caller rejected; reconcile v0.7 fixture names to actual code.

## Guardrails / explicitly out of scope

Don't freeze a duplicate AMIE DSL; don't build a registry application before the data contracts are stable.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-01: Freeze minimum cross-team contracts and acceptance fixtures. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
