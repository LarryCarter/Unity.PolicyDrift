# JOB-02 — Implement common capability SDK and DI operation registration

**Priority:** P0  
**Dependencies:** JOB-01  
**Suggested lane:** Capability SDK  
**Planning target:** Nov 13–17 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Implement typed handler interface and registration extension integrated with existing DI. Discover vetted compiled handlers by explicit registration/approved assembly only. Build immutable manifest from descriptors; expose health/manifest endpoint; enforce duplicate/key/schema/policy checks at startup. Implement handler dispatch with execution context and cancellation. Add registration and auth tests.

## Proposed target file groups (validate actual repo names first)

/Unity.Capabilities.Contracts/; /Unity.Capabilities.Hosting/; /Unity.Capabilities.Tests/

## Definition of done / acceptance evidence

A real safe handler registers once; descriptor, input schema, output schema, required permission, execution host and side-effect policy are discoverable; same key can be bound by two test workflows without code changes.

## Functional, API and negative regression

Unknown handler, duplicate key, bad schema, missing permission, unauthorized direct dispatch and unsupported version fail deterministically.

## Guardrails / explicitly out of scope

No network-based dynamic code loading; no arbitrary C# class names in published configuration.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-02: Implement common capability SDK and DI operation registration. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
