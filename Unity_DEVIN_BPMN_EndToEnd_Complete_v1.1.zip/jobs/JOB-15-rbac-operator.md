# JOB-15 — Implement policy enforcement, run controls and runbooks

**Priority:** P0  
**Dependencies:** JOB-06, JOB-08, JOB-14  
**Suggested lane:** Security / Operations  
**Planning target:** Nov 19–25 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Map real SSO roles to resource-scoped action permissions; protect all API/microservice dispatches. Add Operator Console with PauseRequested/Paused, Resume, Cancel, guarded Retry/Restart; compare-and-swap revision, command ID dedupe, actor/reason/change metadata, runbook version and audit. Add read-only audit view.

## Proposed target file groups (validate actual repo names first)

/Unity.BE/Components/Pages/OperationsConsole.razor; /Unity.BOB.Central/Controls/; /Unity.Security/Policies/; /Unity.Controls/Runbooks/

## Definition of done / acceptance evidence

End user cannot operate or view unauthorized scopes; operator controls reflect actual safe transitions; restart creates linked run; all actions leave audit event with actor and time.

## Functional, API and negative regression

Pause in-flight CyberArk write, forged role, stale ETag, double-click, retry uncertain write, self-approval and auditor mutation denied.

## Guardrails / explicitly out of scope

Actual bank control IDs and runbook authority must be obtained; not fabricated.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-15: Implement policy enforcement, run controls and runbooks. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
