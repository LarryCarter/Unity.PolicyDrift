# JOB-00 — Reconcile actual repo, working code, approved dependencies

**Priority:** P0  
**Dependencies:** None  
**Suggested lane:** Platform architecture  
**Planning target:** Nov 11–12 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Read-only inventory first. Locate real solution/projects, entrypoints, AMIE interfaces and rule format, any existing BOB parser/engine, Kafka producers/consumers, Blazor BE pages, CyberArk operations, existing SQL schemas, CI pipeline and approved UI libraries. Trace at least one real invocation end-to-end. Mark each proposed concept Existing / Adapt / Build / Unknown. Publish a single source-of-truth current-to-proposed contract map and blockers.

## Proposed target file groups (validate actual repo names first)

/docs/decisions/REAL-REPOSITORY-MAP.md; /docs/decisions/DEPENDENCY-APPROVALS.md; /docs/decisions/AMIE-INTERFACE-MAP.md

## Definition of done / acceptance evidence

Actual namespaces, file paths, tests, build commands, API definitions, package versions, Kafka topic conventions, CyberArk auth boundaries and control owners recorded with file evidence; no code invented or overwritten.

## Functional, API and negative regression

Run existing build and tests without altering PROD. Demonstrate a real existing AMIE evaluation or mark unavailable; verify every claimed implemented operation against source.

## Guardrails / explicitly out of scope

No speculative new engine or SDK scaffolding in this job.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-00: Reconcile actual repo, working code, approved dependencies. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
