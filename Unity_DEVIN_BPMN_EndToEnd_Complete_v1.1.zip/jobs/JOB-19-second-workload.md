# JOB-19 — Prove configuration reuse with Hygiene or Onboarding

**Priority:** P1 target  
**Dependencies:** JOB-18  
**Suggested lane:** Application / Reuse  
**Planning target:** Nov 24–29 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Pick second workload matching existing capability data and approvals. Configure different AMIE rule and BPMN flow that reuses `CyberArk.GetAccount` or another primitive. For Policy Drift moving accounts to safes, use read-only finding until `MoveAccount` exists and authorization/reconcile policy is approved.

## Proposed target file groups (validate actual repo names first)

/Unity.Hygiene/Configurations/ or /Unity.Onboarding/Configurations/; /Unity.Reuse.Tests/

## Definition of done / acceptance evidence

Second end-to-end workflow built through BE by reusing exact handler/service versions; zero app-specific BOB Core change and zero required CyberArk handler change; separate business summary and audit.

## Functional, API and negative regression

Unauthorized remediation, missing operation, wrong safe, rule denial, new app data scope and audit visibility tested.

## Guardrails / explicitly out of scope

No rushed high-risk privileged mutations solely to claim a second demo.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-19: Prove configuration reuse with Hygiene or Onboarding. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
