# JOB-08 — Implement MSSQL workflow state, audit timeline and projections

**Priority:** P0  
**Dependencies:** JOB-01, JOB-05  
**Suggested lane:** Persistence / Audit  
**Planning target:** Nov 14–20 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Map existing SQL conventions; build workflow definitions/versions/runs/tokens/activity/command state tables, outbox/inbox if not owned by messaging, append-only audit schema, current status projection, optimistic concurrency/lease. Add migrations and audit read APIs. Enforce redaction/classification and actor/ServiceNow fields.

## Proposed target file groups (validate actual repo names first)

/Unity.BOB.Persistence.MSSQL/; /DatabaseScripts/; /Unity.Audit/; /Unity.Persistence.Tests/

## Definition of done / acceptance evidence

Run starts, checkpoints, survives service restart and reconstructs actor/rule/version/message/correlation/ticket/outcome; projections reproduce state after rebuild; restricted exports redacted.

## Functional, API and negative regression

Audit down, rollback state, concurrent lease, duplicate events, stale version, missing evidence and unauthorized writes tested.

## Guardrails / explicitly out of scope

No new non-MSSQL BOB provider; don't move DCMS row payload to engine database.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-08: Implement MSSQL workflow state, audit timeline and projections. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
