# JOB-09 — Implement Blazor Workflow Library and BPMN canvas

**Priority:** P0  
**Dependencies:** JOB-01, JOB-05  
**Suggested lane:** BE UX  
**Planning target:** Nov 14–22 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Reuse existing Blazor project, nav/layout and approved controls. Implement Workflow Library draft/version/status, a usable supported-BPMN SVG canvas, task palette, connections, property panel shell, save/import/export BPMN XML+DI, validation diagnostics, version lifecycle API bindings. Use approved designer library only if already permitted; otherwise first-party SVG+small JS module.

## Proposed target file groups (validate actual repo names first)

/Unity.BE/Components/Pages/WorkflowLibrary.razor; /Unity.BE/Components/Pages/BpmnDesigner.razor; /Unity.BE/wwwroot/js/workflowCanvas.js; /Unity.BE/Services/WorkflowApiClient.cs

## Definition of done / acceptance evidence

Designer can create BPMN supported graph, persist draft via real API, roundtrip XML+DI, reload intact, display backend errors and prepare publish; no fake save buttons.

## Functional, API and negative regression

Dangling flows, unsupported elements, stale draft ETag, unauthorized editing, XSS in labels, zoom/drag and API failures tested.

## Guardrails / explicitly out of scope

Avoid unapproved new UI NuGet/npm libraries and building a full diagramming engine before vertical slice.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-09: Implement Blazor Workflow Library and BPMN canvas. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.
