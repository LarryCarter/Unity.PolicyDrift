# BPMN UI end-to-end

Use UI 13-18 and the v1.1 clickable composer. Confirm catalog discovery -> typed input renderer -> BPMN XML/DI draft -> AMIE binding -> compiler validation -> fixture test -> immutable review/publish -> central/embedded runtime -> scoped business dashboard + technical audit. Every visible action has a backend API, all RBAC enforced server-side, no false success from 202.
