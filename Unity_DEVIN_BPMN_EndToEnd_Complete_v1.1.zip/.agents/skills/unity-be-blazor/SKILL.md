---
name: unity-be-blazor
description: Create or modify Unity Business Enablement Blazor screens for BPMN workflow design, capability catalog, operation schema/AMIE binding inspectors, business dashboards, operator controls, audit, and workflow library. Use when DEVIN implements BE functionality, configuration UI, or UI-to-API regression.
---


# Blazor BE Feature Development

1. Read `AGENTS.md`, `docs/architecture/07-BE-BLAZOR-DESIGN.md`, `docs/ui/` and job acceptance criteria. Inspect actual Blazor host type, components/routes and approved UI dependencies. v0.7 HTML is a **mock visual reference**, not real API code.
2. Ensure every action maps to an authenticated backend API, with explicit error/permission/status handling; test authorization on backend. Do not insert fake demo-only save/publish success in production components.
3. For designer, preserve BPMN 2.0 XML+DI IDs. Render supported nodes/connections, palette, selection, property inspector, validation, status overlay. Reject unsupported executable node publication.
4. Populate operation inspector dynamically from registry descriptor; render required input/output schema, version, host, policy, side effects and AMIE rule requirements. Provide typed binding selectors. Use existing AMIE editor where possible.
5. Prefer approved UI components. Without an approved diagramming library, use Blazor SVG + small local JS for drag/zoom gesture handling, sending gesture commits to Blazor; avoid high-frequency server roundtrips and conflicting DOM ownership.
6. Separate Business Queue (counts/row reasons/report) and Run Monitor (BPMN and correlated technical events). Use authorized API query on reconnect; SignalR/SSE is an update hint, not history.
7. Operator Console submits guarded pause/resume/cancel/retry/restart commands with reason and revision. Show `PauseRequested` until confirmed, not immediate paused.
8. Test browser success/negative flows, role scoping, keyboard/accessibility, schema errors, stale revisions, secure data masking, network errors, screenshots and API regression.
9. Return actual routes/component paths, API contracts, tests and Files and Structure Summary.

## References

- [UI screen acceptance](references/screen-acceptance.md)

## v1.0 click contract and wireframe source

- Read `docs/ui/07-SCREEN-BY-SCREEN-WIREFRAMES.md`, `08-CLICK-BY-CLICK-ACTION-CATALOG.md`, `09-USER-JOURNEYS-AND-STATE-MACHINES.md`, `10-BLAZOR-WIREFRAME-IMPLEMENTATION.md`, and `11-UI-API-ACCEPTANCE-SCRIPTS.md`.
- Treat `wireframes/UI_CONTROL_REGISTRY_v1.0.json` as proposed control identifiers and tests: 19 routes and 107 click controls. Wireframe HTML is simulation, not a production UI.
- For each implemented control, preserve stable ID, backend API, role+scope guard, expected state transition, structured denial/validation, audit event, and positive/negative regression.
- Never equate a UI 202 response to durable completion. For pause, show PauseRequested until checkpoint. For PROD release, require authoritative approval backend.
- Build the schema-driven inspector so one handler can be reused across DCMS and Hygiene without new Razor code.

## v1.1 complete BPMN authoring and reusable UI

- Read `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md` through `docs/ui/18-FULL-BPMN-DESIGNER-UI-CONFIGURATION-AND-TEST-RUNBOOK.md` and `docs/diagrams/DIAGRAMS.md` before adding a new BPMN screen.
- Map reusable components from UI 15; never write a CyberArk- or DCMS-specific property editor. Support start/trigger, BPMN graph, node inspector, typed binding, rule configuration, validation, test, versioning and runtime overlay.
- Show the entire BPMN palette with honest executable-support badges; block unsupported elements in backend compile/publish. Import/export BPMN XML+DI without losing unknown nodes.
- Treat NAS EF/API as a typed approved Data Capability, and AutoSys as a trusted external scheduler trigger; both require source code/contract verification.
- For all new buttons use `CMP-*` IDs from UI 16 and attach positive/negative API regression; do not equate simulated HTML with backend proof.
- [Detailed BPMN UI flow](references/bpmn-end-to-end.md).
