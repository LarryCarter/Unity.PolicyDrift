---
name: unity-amie-bindings
description: Integrate existing AMIE rules, data mappings, validation, and decision outputs with BOB BPMN tasks and registered Unity capability operations, using schema-driven BE bindings. Use when creating configuration-driven business logic, rule descriptors, AMIE adapters, or debugging rule-to-capability wiring.
---


# AMIE Integration and Binding Procedure

1. Read `AGENTS.md`, `docs/architecture/04-AMIE-BINDINGS.md`, `docs/contracts/AMIE-RULE-DESCRIPTOR.md`, `jobs/JOB-04-amie-adapter.md`. Locate the **already implemented** AMIE evaluator, serializer, rule versioning and tests; make a real interface map first.
2. For each requested rule, identify its *approved* key/version, required facts, output type, safe decision summary, classification and test fixture. Do not invent unverified AMIE DSL syntax as real project code.
3. Build a narrow adapter to the existing AMIE API for rule metadata, typed binding validation and evaluation under execution context. BOB rule task invokes adapter, not a duplicate engine.
4. Map BE source bindings from initial workflow input, current record, preceding operation/rule outputs, allowlisted constants, approved environment refs, or protected server-side secret refs. The browser never receives credentials.
5. Compile/check schema and authorization before publish; perform server-side checks again at execution. Reject missing fact, forbidden data classification, incompatible type or absent pinned version.
6. Run AMIE locally within embedded capability where work is local; avoid remote calls per DCMS row.
7. Test rule output drives the correct BOB gateway; correct patch feeds handler; rule pass and external API write success are separate outcomes.
8. Publish new rule configuration through immutable package and CI evidence, preserving previous pinned versions for active runs.
9. Return tests, audit sample and actual file-path summary, explicitly identifying changes vs already-written AMIE code.

## References

- [Binding source rules and DCMS acceptance](references/binding-and-dcms.md)

## v1.0 schema and UI interaction

- Read `docs/sdk/04-DATA-SCHEMAS-AND-UI-BINDINGS.md` and `docs/sdk/06-DCMS-EXAMPLE-END-TO-END.md`.
- Drive AMIE picker/control IDs AMI-01..AMI-04 from existing AMIE rule descriptors and typed facts, not a second rule engine.
- Pin exact rule versions, check fact/output schemas at compile and runtime, distinguish AMIE decision from actual CyberArk write outcome.
