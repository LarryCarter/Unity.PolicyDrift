# Binding Acceptance

Typed binding has kind + source path + target schema path + classification + nullable/default policy. Sources: WorkflowInput, CurrentItem, OperationOutput, RuleOutput, ApprovedConstant, EnvironmentBinding and server-only SecretReference.

DCMS example rule categories: eligibility of current row vs CyberArk metadata, mapping CSV fields to platform-supported custom attributes, no-change decision. The data format must align to existing AMIE. A successful AMIE mapping never automatically implies a successful CyberArk write; use structured audit reason and actual confirmation.

Negative: wrong source type, missing platform field, missing rule version, forbidden write even when rule returns allow, secret leakage in UI, replay rule drift.
