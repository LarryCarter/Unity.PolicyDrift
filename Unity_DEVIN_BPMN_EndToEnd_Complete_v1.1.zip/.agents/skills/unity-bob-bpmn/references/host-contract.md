# Central and Embedded Hosts

Common core = graph, tokens, decision, variables, state transitions. Central = MSSQL persistence, Kafka command/outcome and audit; Embedded = compiled local DI dispatcher, existing AMIE and optional durable state when business transaction requires. Cross-service await requires durable pending command and correlation. On partial failure: separate actual external side effect from BOB bookkeeping. No DCMS-specific code in engine.
