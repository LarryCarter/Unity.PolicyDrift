# BPMN Validity is not Execution Support

P0 exact semantics tests: exclusive gateway chooses one route/default; subprocess receives typed variables and emits output; sequential multi-instance prevents two active row calls in same batch; pause stops future steps at checkpoint; late Kafka outcome does not resurrect cancelled run; unsupported nodes are blocked in authoring and publishing.

Require standards-valid BPMN XML with secure parser and DI; compare element semantics to OMG BPMN 2.0.2. Do not blindly adopt OptimaJet plugin supported elements from class names. Reference https://www.omg.org/spec/BPMN/2.0.2 .
