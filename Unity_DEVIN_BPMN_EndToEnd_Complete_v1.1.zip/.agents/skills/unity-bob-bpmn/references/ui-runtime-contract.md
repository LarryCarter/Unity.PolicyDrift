# Runtime conformance

Read v1.1 diagrams and workflows. Test actual BPMN token semantics, not only XML parse. Reject unsupported executable event/gateway/user tasks; support declared P0 subset only after conformance tests. For dispatch, durable outbox + waiting correlation before publish; handle late/repeated outcomes, safe pause/stop/restart, account-delete reconciliation.
