---
name: unity-bob-bpmn
description: Implement, extend, or verify the Unity BOB BPMN 2.0 runtime, parser/compiler, central/embedded host execution, state persistence, subprocess behavior, Kafka waits, and operator pause/resume/cancel semantics. Use for BOB engine tasks, BPMN definition tests, or when troubleshooting workflow execution.
---


# BOB BPMN Engineering Workflow

1. Read repository `AGENTS.md`, `docs/architecture/03-BOB-BPMN-RUNTIME.md`, `docs/contracts/BPMN-WORKFLOW-BINDING.md`, `jobs/JOB-05-bpmn-compiler.md` and `jobs/JOB-06-bob-hosts.md`. Inspect existing BOB code and installed approved libraries.
2. Use OMG BPMN 2.0.2 XML and BPMN DI as interchange; preserve node IDs/diagram geometry. Treat XML parse, graph validation, executable semantics and UI visual support as **separate tests**.
3. Implement the minimum currently approved subset: start/end, service task, business-rule task (existing AMIE), exclusive gateway, sequence flow, call/subprocess, sequential multi-instance, and durable Kafka outcome wait (as selected by current pilot). Reject unsupported executable nodes before publish.
4. Compile typed binding graph with pinned operation/rule/subprocess versions, allowed execution host, permission, input/output type and retry policy. Never run user-supplied C# or named CLR type from BPMN extension.
5. Implement **one** interpreter/token machine shared by central and embedded hosts; host adapters supply persistence and dispatch. Embedded local handler+AMIE should not call central BOB per step.
6. Treat external write outcome as separate from rule-pass outcome. Checkpoint pending command + outbox before publishing; duplicate event cannot advance token twice.
7. Implement cooperative pause/resume/cancel and distinct restart ID, preserving exact pinned versions and audit. Use safe checkpoints and optimistic concurrency.
8. Add unit tests for token branching, call argument propagation, 3-row ordered execution, unsupported node rejection, restart, duplicate/lost outcome, pause during write.
9. Report exact supported BPMN constructs and failing elements without overstating BPMN 2.0 conformance.
10. Provide PR, test evidence and actual file summary. Full details: `docs/testing/REGRESSION-MATRIX.md`.

## References

- [BPMN semantics and runtime proof](references/semantics.md)
- [Host and state boundaries](references/host-contract.md)

## v1.0 interaction and SDK integration

- Read `docs/sdk/03-BOB-AMIE-KAFKA-EXECUTION.md` and `docs/sdk/04-DATA-SCHEMAS-AND-UI-BINDINGS.md`; binding from BE designer must compile from exact descriptor/rule versions.
- Implement UI control semantics for DES-01..DES-13, LIB-01..LIB-08 and CTL-01..CTL-07 described in `docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md`.
- Validate BPMN XML + DI, executable subset, rule/handler graph, cancellation and outbox state separately.

## v1.1 authoring-to-execution integration

- Use `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, and `docs/diagrams/DIAGRAMS.md` to confirm every designer action compiles to a real runtime behavior.
- Implement full BPMN 2.0.2 XML/DI interchange but only claim executable semantics for verified elements; model unsupported nodes as blocked.
- For Account Delete, approve/wait must be a real durable correlation; unsupported UserTask requires explicit block or approved external wait substitute.
- For AutoSys, use authenticated normalized trigger to published workflow; do not embed scheduler-specific logic in interpreter.
- Regression with `examples/AccountDelete_Guarded_Illustrative_v1.1.bpmn`, `examples/NAS_Data_Query_Illustrative_v1.1.bpmn`, `examples/PolicyDrift_AutoSys_Illustrative_v1.1.bpmn`, noting that XML well formed is not executable proof.
- [Designer/runtime conformance](references/ui-runtime-contract.md).
