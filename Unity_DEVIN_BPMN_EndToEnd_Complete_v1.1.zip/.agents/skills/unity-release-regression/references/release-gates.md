# DEV/UAT/PROD Gate Checklist

Check real identity and scope; bank control owner approval; immutable package digest; operation/rule compatibility; nonproduction E2E evidence; ServiceNow change ID plus authoritative status; segregation of duties; logical binding resolution; no embedded secrets; broker ACL; audit & SIEM requirements; retention; expected rollback; cold-start deployment; no unsafe API writes.

Demo gate is separate from Production gate. A fake/stale ticket, modified digest, unauthorized release operator, missing UAT evidence or unapproved library must block PROD activation and generate audit. Rollback switches new run package, not external CyberArk effects.
