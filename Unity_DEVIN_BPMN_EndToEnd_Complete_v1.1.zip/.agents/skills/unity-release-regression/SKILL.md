---
name: unity-release-regression
description: Implement or review Unity platform regression tests, access policies, audit controls, immutable configuration packages and DEV/UAT/PROD Operations-only promotion. Use for release pipelines, ServiceNow change evidence, API tests, failure injection, runbooks and production readiness review.
---


# Unity Regression and Release Control Workflow

1. Read `AGENTS.md`, `docs/architecture/08-ACCESS-RUNBOOKS.md`, `docs/architecture/09-RELEASE-PACKAGES.md`, `docs/testing/REGRESSION-MATRIX.md` and `docs/ui/05-RELEASE-PROMOTION.md`.
2. Inspect actual bank SSO, controls/CA/ServiceNow process, CI/CD and approved SDKs. Never fabricate control IDs, release permissions or approval state. If authority missing, restrict to DEV/UAT design and mark blocked.
3. Verify every BE action has authenticated API, resource-scoped policy, OpenAPI schema, audit emission and automated test, including direct negative auth attempts.
4. Ensure configured package includes BPMN+DI, pinned AMIE/operation/message contracts, logical bindings, runbook/control refs and evidence; produce immutable digest/signature using an approved pipeline.
5. Enforce separate author/reviewer/release operator where bank policy requires; ServiceNow ticket reference is not approval by itself.
6. Promote same package bytes/digest DEV->UAT->PROD; resolve only approved environment bindings (not secrets in package). Activation requires authoritative approval and compatible deployed service versions.
7. Test duplicates, crash/restart, unknown CyberArk write, pause-in-flight, cancellation, untrusted Kafka, stale role, missing audit, modified digest and denied PROD activation.
8. Provide QA evidence for each P0 R01–R18; preserve versioned package, UTC, CI run, test fixtures and sanitized audit query.
9. Report demo readiness separately from bank PROD authorization; never claim release approval based on green tests alone.

## References

- [Release gate checklist](references/release-gates.md)

## v1.0 action and regression coverage

- Read `docs/ui/11-UI-API-ACCEPTANCE-SCRIPTS.md`, `docs/sdk/08-SDK-API-REGRESSION-SUITE.md`, and `docs/sdk/05-SECURITY-AUDIT-PROMOTION.md`.
- Enforce backend for all `wireframes/UI_CONTROL_REGISTRY_v1.0.json` actions, plus SDK-01..SDK-28 unit/API tests. HTML wireframe tests prove only mock click handling.
- Block production activation without actual bank-approved CAs/change evidence, even if ticket text and test screenshot exist.
