# NAS CyberArk AutoSys operation reference

NAS is a named EF-backed API from the user, actual entities/endpoints not verified. Data owner enforces EF and typed API, other capabilities use API not tables. CyberArk DCMS: GetAccount -> AMIE MapAttributes -> in-memory apply -> AddOrUpdate -> confirmed outcome, row GUID result. Account Delete guarded and verified. AutoSys triggers Policy Drift via approved job identity/sourceRunId; ZIP/INI baseline comparison, status DRIFT/NO_DRIFT/MISSING_BASELINE.
