# Capability Archetypes

- **CyberArk/PAM:** get/search account, in-memory attribute patch, add/update, safe movement only with explicit permissions/revision/reconciliation; never directly expose all CyberArk REST APIs.
- **Data/CSV:** secure upload, schema validation, batch number/row GUID, bounded paging, row status; own data; no unrestricted database access.
- **Email:** approved recipient/template policy via existing AMIE; Kafka command; return accepted/sent/failed; never embed SMTP in BOB.
- **Reporting:** aggregate persisted authorized outcomes and output secure artifact ref; no report payload in Kafka.
- **Identity:** scope-group lookups via approved IAM; no default permission grant due to group string.
- **Legacy:** wrap stable vetted existing APIs in typed operation; no workflow arbitrary reflection or dynamic SQL.

For each archetype implement normal API+contract unit and end-to-end negative tests. Application-specific flow remains in BOB/AMIE configs.
