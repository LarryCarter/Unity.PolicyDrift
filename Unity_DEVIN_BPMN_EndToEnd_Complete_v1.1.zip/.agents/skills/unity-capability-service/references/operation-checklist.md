# Operation Admission Checklist

Contract key/version; approved source owner; compiled implementation handler; input/output JSON schema and examples; permission/scope; data classification/redaction; execution modes (EmbeddedLocal/KafkaCommand); side effect (Read/LocalTransform/ExternalWrite); idempotency strategy (Safe/RequiresKey/Reconcile/NeverAutoRetry); timeout and retry limits; logical subscription/publication; correlation/trace; AMIE dependencies pinned; audit category, evidence refs, reason codes; mocks/real test targets; approved code release evidence. Validate every field by tests, not only JSON presence.

**Registration handshake:** DI register -> manifest compile/validate -> authorized publisher verify -> registry persisted with version -> health/compatibility -> BE discovery -> BOB compiler binding -> execution-time auth and version check. On missing approval, stay non-callable.
