---
name: unity-capability-service
description: Build or extend a Unity .NET capability microservice with automatic approved handler registration, typed operation manifests, Kafka command/outcome contracts, BOB embedded hosting, existing AMIE integration, audit, and API regression. Use whenever implementing a new CyberArk, Data, Email, Reporting, Identity, Legacy, or other capability service or adding a reusable operation.
---


# Implement a Unity Capability Service

## Input required

A requested business primitive/service; existing Unity repository and solution; approved service owner, access scope and environments. Find existing AMIE/BOB/Kafka patterns rather than assuming new interfaces. If code repository or approval metadata is missing, provide a precise source audit and implementation PR plan without claiming implementation.

## Procedure

1. Read repo root `AGENTS.md`, `docs/00-START-HERE.md`, `docs/architecture/02-CAPABILITY-SDK-REGISTRY.md`, `docs/contracts/OPERATION-CONTRACT.md`; inspect actual service paths and already available capability operations.
2. List requested primitives with input/output schema, source data owner, classification, permission, side effect, external API/version, timeout, idempotency/reconciliation and required AMIE facts. Break one-off business workflows out of service code.
3. Reuse existing `IUnityOperationHandler` or closest current registration API; preserve namespaces and DI style. If absent, implement only approved SDK contracts from JOB-01. Never instantiate arbitrary class names supplied by BE.
4. Build typed DTO, compiled handler, deterministic validation, safe outcome taxonomy and test fixtures. Implement `Read` or `LocalTransform` before `ExternalWrite` when possible.
5. Register compiled handlers through trusted startup/DI registration. Validate unique `operationKey@contractVersion`, schema and policy at startup; publish manifest via trusted deploy identity **only after approved service release**, not due to scan alone.
6. Declare logical inbound and outbound Kafka message contracts, partition key, consumer group binding, idempotency key and permission scope. Use existing approved broker SDK and outbox/inbox code.
7. Expose locally usable handler to embedded BOB. Bridge to the **existing** AMIE engine via adapter; do not duplicate AMIE evaluator or add per-step remote calls.
8. Add unit, component, API, broker, authorization, crash/restart, duplicate command, sensitive-data redaction, audit and version-compatibility tests.
9. Show BE operation registry + inspector integration via published descriptor and typed input bindings; demonstrate reusing the handler in a second unrelated workflow.
10. Submit focused PR with actual `/Project/Folder/File.cs` paths, tests/evidence, behavior before/after, unverified bank approvals and Files and Structure Summary.

## Never

No application-specific DCMS/Hygiene logic inside generic handlers, broad dynamic REST, arbitrary SQL, arbitrary code from rules, secret-bearing manifests, unchecked broker subscriptions, production credentials, or blind retry of uncertain CyberArk writes. Discovery never grants authorization.

## References

- [Operation checklist](references/operation-checklist.md)
- [Archetypes and data ownership](references/capability-archetypes.md)
- Full handoff repo: `docs/architecture/02-CAPABILITY-SDK-REGISTRY.md`, `docs/contracts/OPERATION-CONTRACT.md`, `jobs/JOB-02-capability-sdk.md`, `jobs/JOB-12-cyberark-operations.md`.

## v1.0 build recipe (read when new service/handler is requested)

- Before coding, read `docs/sdk/00-SDK-PURPOSE-SERVICE-BOUNDARIES.md`, `01-SDK-CONTRACTS-AND-STATES.md`, `02-AUTOMATIC-REGISTRATION-AND-NEW-SERVICE.md`, `03-BOB-AMIE-KAFKA-EXECUTION.md`, and `07-DEVIN-SERVICE-CONSTRUCTION-RECIPE.md`.
- Follow `jobs/interaction/SDK-10-...` through `SDK-18-...` assignments via `jobs/interaction/INDEX.md` and preserve existing AMIE implementation.
- For a new operation, require `OperationDescriptor`, DTO/JSON Schema, `UnityExecutionContext`, `OperationOutcome`, auth, side-effect/idempotency, logical Kafka subscriptions and publications, AMIE fact needs, audit category, fixtures.
- Local handler registration is not enterprise publication. Do not expose an operation as Available before deployment provenance, registry owner and environment readiness are verified.
- Demonstrate dynamic BE schema rendering through `docs/ui/07-SCREEN-BY-SCREEN-WIREFRAMES.md`, control IDs `CAT`, `OP`, `ON`; complete SDK-01..28 regression in `docs/sdk/08-SDK-API-REGRESSION-SUITE.md`.

## v1.1 NAS/EPV/AutoSys examples and BE wiring

- Read `docs/workflows/00-REUSABLE-WORKFLOW-PATTERNS.md` through `docs/workflows/05-HYGIENE-SAFE-MOVE-SEPARATE-EXAMPLE.md` and `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`.
- NAS EF Core remains behind its owning API; inspect actual NAS identity, DbContext, controllers and DTOs before writing code. Never generate arbitrary SQL endpoints.
- Account Delete requires high-impact side-effect classification, approved authorization/approval, expected state and reconciliation. Mock destructive paths absent explicit DEV authorization.
- AutoSys job trigger is a distinct approved adapter; normalize sourceRunId, caller identity, replay/overlap policy and job allowlist. Do not assume AEWS API access.
- Policy Drift is ZIP/INI/PolicyId baseline comparison, distinct from PAM safe-move hygiene; retain original SQL acceptance oracle and real PolicyId sanitizer.
- [Capability integration examples](references/nas-cyberark-autosys.md).
