"""Validate that each wireframe action ID is present and produces visible behavior.
Does NOT test a Unity backend. Requires Playwright with local Chromium.
"""
from pathlib import Path
from model import SCREENS,ACTIONS
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
(root/'screenshots').mkdir(exist_ok=True)
html=(root/'Unity_BE_Clickable_Wireframes_v1.0.html').read_text()
roles=['Designer','Capability Owner','Rule Maintainer','Reviewer','Business User','Operations','Release Operator','Auditor']
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1510,'height':960},accept_downloads=True)
    errors=[];page.on('pageerror',lambda x:errors.append(str(x)))
    page.set_content(html,wait_until='domcontentloaded')
    assert page.locator('[data-nav]').count()==len(SCREENS)
    counts={}
    for a in ACTIONS:
        role=next((x for x in roles if x in a['roles'].split(',') or a['roles']=='All authenticated users'),None)
        assert role,a
        page.locator('#role').select_option(role)
        if page.locator('[data-nav="'+a['page']+'"]').count()!=1:
            raise AssertionError('Missing nav '+a['page'])
        page.locator('[data-nav="'+a['page']+'"]').click()
        button=page.locator('[data-control-id="'+a['id']+'"]')
        assert button.count()==1,a['id']
        assert button.is_enabled(),a['id']
        button.click()
        assert page.locator('#status').count()==1,a['id']
        assert len(page.locator('#status').inner_text().strip())>0,a['id']
        if page.locator('[data-close-modal]').count():page.locator('[data-close-modal]').click()
        counts[a['page']]=counts.get(a['page'],0)+1
    assert not errors,errors
    print('PASS: nav',len(SCREENS),'button actions',len(ACTIONS),'screens touched',len(counts),'JS exceptions',len(errors))
    # Key scenario: binding and validation with default visible binding.
    page.locator('#role').select_option('Designer');page.locator('[data-nav="designer"]').click()
    page.locator('[data-control-id="LIB-01"]').count()==0
    page.locator('[data-control-id="DES-05"]').click()
    page.locator('[data-control-id="DES-07"]').click()
    # may still be blocked due earlier publish; this is a wireframe state, not a backend test.
    for screen,out in [('workbench','wireframe_workbench.png'),('designer','wireframe_designer.png'),('business','wireframe_business.png'),('operators','wireframe_operations.png'),('releases','wireframe_release.png')]:
        role='Operations' if screen=='operators' else 'Release Operator' if screen=='releases' else 'Designer'
        page.locator('#role').select_option(role)
        page.locator('[data-nav="'+screen+'"]').click()
        page.screenshot(path=str(root/'screenshots'/out),full_page=False)
    browser.close()
