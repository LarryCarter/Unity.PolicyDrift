from model import SCREENS,ACTIONS
from pathlib import Path
import json
root=Path(__file__).resolve().parent
src=(root/'Unity_BE_Clickable_Wireframes_v1.0.template.html').read_text()
model={'screens':list(SCREENS.values()),'actions':ACTIONS}
out=src.replace('__MODEL_JSON__',json.dumps(model,ensure_ascii=False,separators=(',',':')))
(root/'Unity_BE_Clickable_Wireframes_v1.0.html').write_text(out)
print('wrote html length',len(out))
