"""Design-only control registry for Unity BE v1.0 interactive wireframes.
This is not a production API implementation. Kept as a reproducible source of truth.
"""
from collections import OrderedDict

SCREENS=OrderedDict()
ACTIONS=[]

def screen(id,title,purpose,data,fields="",roles="All authenticated users",empty="No matching or available records",error="Show structured API error with correlation ID",loading="Skeleton/list loading state"):
    SCREENS[id]={"id":id,"title":title,"purpose":purpose,"data":data,"fields":fields,"roles":roles,"empty":empty,"error":error,"loading":loading}

def action(page,key,label,kind,endpoint,roles,success,rejection,audit="Read view only",priority="P0",next_page=None):
    item={"id":key,"page":page,"label":label,"kind":kind,"endpoint":endpoint,"roles":roles,"success":success,"rejection":rejection,"audit":audit,"priority":priority,"nextPage":next_page}
    ACTIONS.append(item)

screen('workbench','Unity Workbench','Find assigned applications, actions and runs','GET /api/v1/me/dashboard','application selector; favorite filter','All authenticated users','No applications in scope')
action('workbench','WB-01','Browse capabilities','navigate','GET /api/v1/capabilities','Designer,Capability Owner,Operations,Auditor','Open registry scoped to current role','403 or no authorized capabilities',next_page='catalog')
action('workbench','WB-02','Open Application Studio','navigate','GET /api/v1/applications','Designer,Reviewer,Operations','Open assigned application configurations','403 if not owner or delegated',next_page='apps')
action('workbench','WB-03','My work','navigate','GET /api/v1/batches?scope=mine','All authenticated users','Open authorized batch list','No work in permitted scope',next_page='business')
action('workbench','WB-04','Refresh status','refresh','GET /api/v1/me/dashboard','All authenticated users','Reload counts and last-updated time','Retain stale-data warning and correlation ID')

screen('catalog','Capability Registry','Discover approved operations and service health','GET /api/v1/capabilities; GET /api/v1/operations','search query; capability filter; availability filter','Designer,Capability Owner,Operations,Auditor','No operations available in scope')
action('catalog','CAT-01','Search / filter','filter','GET /api/v1/capabilities?q=&status=','Designer,Capability Owner,Operations,Auditor','Table is filtered without altering registry','Return empty state with clear filters')
action('catalog','CAT-02','Inspect operation','navigate','GET /api/v1/operations/{key}/versions/{version}','Designer,Capability Owner,Operations,Auditor','Open descriptor inspector at exact contract version','Unavailable/unauthorized contract shows status',next_page='operation')
action('catalog','CAT-03','Use in workflow','navigate','POST /api/v1/workflow-drafts/{id}/activities','Designer','Insert bound service task with stable key/version','No writable draft or unavailable op -> block', 'WorkflowDraftActivityAdded',next_page='designer')
action('catalog','CAT-04','Refresh health','refresh','GET /api/v1/capabilities/{key}/readiness','Designer,Capability Owner,Operations,Auditor','Fetch current readiness and compatibility','Mark unknown/unavailable, never assume available')

screen('operation','Operation Inspector','Inspect versioned schema and prepare reusable binding','GET /api/v1/operations/{key}/versions/{version}','operation selector; contract version; test fixture','Designer,Capability Owner,Operations,Auditor','Operation removed or not in scope')
action('operation','OP-01','Back to Registry','navigate','GET /api/v1/capabilities','Designer,Capability Owner,Operations,Auditor','Return to same catalog filters','Retain prior selection',next_page='catalog')
action('operation','OP-02','View input/output schemas','inspect','GET /api/v1/operations/{key}/schemas','Designer,Capability Owner,Operations,Auditor','Show required inputs, outputs, permissions and side effects','Missing schema blocks binding')
action('operation','OP-03','Test with DEV fixture','test','POST /api/v1/operation-tests/{key}/execute','Capability Owner,Designer','Non-PROD fixture result with reason/correlation shown','PROD/live writes forbidden; invalid fixture rejected','OperationTestAttempt')
action('operation','OP-04','Add to BOB workflow','navigate','POST /api/v1/workflow-drafts/{id}/activities','Designer','Append service task using selected descriptor','Draft not owned/contract unavailable', 'WorkflowDraftActivityAdded',next_page='designer')
action('operation','OP-06','Download contract manifest','export','GET /api/v1/operations/{key}/manifest','Designer,Capability Owner,Operations,Auditor','Download approved manifest with schema refs but no secrets','Unknown/unapproved contract -> deny export','OperationManifestDownloaded')
action('operation','OP-05','Request missing primitive','dialog','POST /api/v1/operation-development-requests','Designer,Capability Owner','Generate typed DEVIN operation request, not code execution','Missing owner/schema or permission blocks submit','OperationDevelopmentRequested')

screen('onboarding','Capability Onboarding','Review and publish typed compiled operations','GET /api/v1/capability-manifests/drafts','capability key; operation key; owner; input schema ref; permission; side effect','Capability Owner,Reviewer,Operations','No manifest drafts')
action('onboarding','ON-01','Create manifest draft','create','POST /api/v1/capability-manifests/drafts','Capability Owner','Create local metadata draft; no executable registration yet','Missing service owner/key -> 422','ManifestDraftCreated')
action('onboarding','ON-02','Add operation declaration','create','POST /api/v1/capability-manifests/drafts/{id}/operations','Capability Owner','Attach typed operation metadata to draft','Duplicate key/version or schema missing','ManifestDraftChanged')
action('onboarding','ON-03','Validate manifest','validate','POST /api/v1/capability-manifests/drafts/{id}/validate','Capability Owner,Reviewer','Display schema/security/version checks','Invalid input/scope fails with field code','ManifestValidation')
action('onboarding','ON-04','Submit service release evidence','submit','POST /api/v1/capability-manifests/drafts/{id}/submit','Capability Owner','Send draft for privileged review, not auto-approve','CI digest/code-release evidence missing','ManifestSubmitted')
action('onboarding','ON-05','Approve registry publication','approve','POST /api/v1/capability-manifests/{id}/approve','Reviewer','Approve compatible manifest; no auto handler creation','Cannot self-approve; missing release proof','ManifestApproved')
action('onboarding','ON-06','Check deployed readiness','refresh','GET /api/v1/capability-manifests/{id}/readiness','Capability Owner,Reviewer,Operations','Show registered vs actually available separately','Unhealthy/unapproved still blocked')

screen('apps','Application Studio','Compose application from workflows/capabilities','GET /api/v1/applications','application name; owner; scope; selected modules','Designer,Reviewer,Operations','No assigned applications')
action('apps','APP-01','Create application draft','create','POST /api/v1/applications','Designer','New app blueprint with owner and scope','Owner/scope required','ApplicationDraftCreated')
action('apps','APP-02','Add capability dependency','create','POST /api/v1/applications/{id}/capabilities','Designer','Add stable approved contract dependency','Unavailable contract or incompatible version','ApplicationDependencyAdded')
action('apps','APP-03','Save configuration','save','PUT /api/v1/applications/{id}/draft','Designer','Persist revision and ETag','409 on concurrent edit','ApplicationDraftSaved')
action('apps','APP-05','Select application module','select','GET /api/v1/applications/{id}/modules/{key}','Designer,Reviewer,Operations','Switch composition tab with selected workflow and capability dependencies','Unknown or unauthorized module -> clear empty state')
action('apps','APP-04','Open workflow library','navigate','GET /api/v1/workflow-definitions?application=','Designer,Reviewer,Operations','Show workflows for selected app','Missing app scope -> 403',next_page='library')

screen('library','Workflow Library','Manage immutable definitions and lifecycle','GET /api/v1/workflow-definitions','search; application; lifecycle filter; selected definition','Designer,Reviewer,Operations,Auditor','No definitions in filter')
action('library','LIB-01','New draft from template','create','POST /api/v1/workflow-drafts','Designer','Create draft and initial BPMN IDs','No template permission','WorkflowDraftCreated')
action('library','LIB-02','Open selected version','navigate','GET /api/v1/workflow-definitions/{key}/versions/{version}','Designer,Reviewer,Operations,Auditor','Open editor if draft or read-only if published','Definition not visible or immutable',next_page='designer')
action('library','LIB-03','Compare versions','inspect','GET /api/v1/workflow-definitions/{key}/diff?from=&to=','Designer,Reviewer,Operations,Auditor','Show BPMN/rules/contracts/change diff','Missing comparison version')
action('library','LIB-04','Clone as new draft','create','POST /api/v1/workflow-definitions/{key}/clone','Designer','New editable version referencing parent','Retired source allowed only under policy','WorkflowDraftCloned')
action('library','LIB-05','Submit for review','submit','POST /api/v1/workflow-drafts/{id}/review','Designer','Draft moves to InReview with ticket and evidence','Validation errors or no change request','WorkflowReviewRequested')
action('library','LIB-06','Approve version','approve','POST /api/v1/workflow-reviews/{id}/approve','Reviewer','Independently approve candidate','Maker/checker or missing tests','WorkflowApproved')
action('library','LIB-07','Publish immutable version','publish','POST /api/v1/workflow-definitions/{key}/publish','Reviewer','Published with digest and pinned dependencies','Unapproved or missing capabilities','WorkflowPublished')
action('library','LIB-08','Retire selected version','retire','POST /api/v1/workflow-definitions/{key}/retire','Operations','Prevent new runs but retain evidence','Active dependency/runs require policy check','WorkflowRetired')

screen('designer','BOB BPMN Designer','Edit standard BPMN and type-safe Unity bindings','GET/PUT /api/v1/workflow-drafts/{id}/bpmn','node selection; operation; input binding; rule; host; flow path','Designer,Reviewer,Operations','Empty BPMN canvas with Start and End')
action('designer','DES-01','Add service task','create','POST /api/v1/workflow-drafts/{id}/activities','Designer','New BPMN service task with stable node ID','No approved operation available','DraftActivityAdded')
action('designer','DES-02','Add business rule task','create','POST /api/v1/workflow-drafts/{id}/activities','Designer','New BPMN business-rule task','No AMIE descriptor available','DraftActivityAdded')
action('designer','DES-03','Add exclusive gateway','create','POST /api/v1/workflow-drafts/{id}/elements','Designer','BPMN XOR gateway with branch conditions','Unsupported element/invalid graph','DraftElementAdded')
action('designer','DES-04','Connect selected nodes','connect','PUT /api/v1/workflow-drafts/{id}/bpmn','Designer','Directed sequence flow with new ID','Cycle/invalid branch rejected','DraftFlowChanged')
action('designer','DES-05','Bind selected task input','bind','PUT /api/v1/workflow-drafts/{id}/bindings','Designer','Typed mapping to input/current row/prior output','Missing source or wrong schema','DraftBindingChanged')
action('designer','DES-06','Save draft','save','PUT /api/v1/workflow-drafts/{id}','Designer','Persist BPMN XML + DI + inspector data with ETag','409 stale revision, preserve local edits','WorkflowDraftSaved')
action('designer','DES-07','Validate BPMN and contracts','validate','POST /api/v1/workflow-drafts/{id}/validate','Designer,Reviewer','Highlight node errors and publish readiness','Unsupported BPMN/AMIE/operation denies publish','WorkflowValidation')
action('designer','DES-08','Preview safe execution','test','POST /api/v1/workflow-drafts/{id}/simulate','Designer','DEV fixture preview with explicit mock label','Real external writes forbidden in preview','WorkflowSimulationRequested')
action('designer','DES-09','Submit workflow review','submit','POST /api/v1/workflow-drafts/{id}/review','Designer','Submit validated draft to reviewer','Required ticket/digest/tests missing','WorkflowReviewRequested')
action('designer','DES-10','Import BPMN XML','import','POST /api/v1/workflow-drafts/{id}/import','Designer','Parse BPMN XML + DI and show unsupported elements','Invalid XML or unsupported semantics fail','WorkflowDraftImported')
action('designer','DES-11','Export BPMN XML','export','GET /api/v1/workflow-drafts/{id}/export','Designer,Reviewer,Operations','Download BPMN 2.0 XML with DI/extension refs','Draft not accessible')
action('designer','DES-12','Undo edit','undo','local editor; persist on Save','Designer','Revert most recent uncommitted canvas edit','Nothing to undo')
action('designer','DES-14','Switch central / embedded workflow','select','GET /api/v1/workflow-definitions/{key}/execution-contexts','Designer,Reviewer,Operations','Change designer context, loading pinned central or CyberArk embedded subworkflow','Unavailable embedded definition or host compatibility rejected')
action('designer','DES-13','Redo edit','redo','local editor; persist on Save','Designer','Reapply reverted canvas edit','Nothing to redo')

screen('amie','AMIE Rule Picker and Binding','Reuse existing typed rules without rebuilding AMIE','GET /api/v1/amie/rules','rule key/version; fact binding; output binding; safe fixture','Designer,Rule Maintainer,Reviewer','No compatible AMIE rules')
action('amie','AMI-01','Select rule version','inspect','GET /api/v1/amie/rules/{key}/versions/{version}','Designer,Rule Maintainer,Reviewer','Show required facts/decision types','Unavailable version, no implicit latest')
action('amie','AMI-02','Map required facts','bind','PUT /api/v1/workflow-drafts/{id}/rule-bindings','Designer,Rule Maintainer','Bind typed input facts and output references','Mismatch/missing fact or unauthorized scope','RuleBindingChanged')
action('amie','AMI-03','Preview rule with fixture','test','POST /api/v1/amie/rules/{key}/preview','Designer,Rule Maintainer','Existing AMIE evaluator returns typed safe result','Missing facts or unsafe fixture','RulePreviewed')
action('amie','AMI-04','Save rule binding','save','PUT /api/v1/workflow-drafts/{id}/rule-bindings','Designer,Rule Maintainer','Persist pinned rule version and ETag','Conflict or unpublished rule','RuleBindingSaved')

screen('triggers','Triggers and Forms','Declare validated manual/API/schedule inputs','GET /api/v1/triggers','trigger type; CSV input; required column schema; application scope','Designer,Business User,Operations','No configured trigger')
action('triggers','TRI-01','Choose trigger type','select','GET /api/v1/triggers/types','Designer,Operations','Display manual CSV/API/schedule capabilities and readiness','AutoSys/API not yet implemented -> planned')
action('triggers','TRI-02','Add required input field','create','PUT /api/v1/workflow-drafts/{id}/trigger-schema','Designer','New typed schema field for BE form','Unsupported data type/duplicate field','TriggerSchemaChanged')
action('triggers','TRI-03','Validate sample CSV','validate','POST /api/v1/ingestion/validate','Designer,Business User','Return schema/row errors, no live write','Bad extension, oversize, missing cols','UploadValidation')
action('triggers','TRI-04','Save trigger mapping','save','PUT /api/v1/workflow-drafts/{id}/trigger','Designer','Persist trigger schema and source adapter ref','Missing owner/scope and unmapped data','TriggerMappingSaved')
action('triggers','TRI-05','Open business start form','navigate','GET /api/v1/workflows/{key}/start-form','Business User,Designer','Open role-scoped start UI','No execute permission',next_page='business')

screen('contracts','Kafka Contract Explorer','Inspect logical message contracts and mappings','GET /api/v1/messaging/contracts','message search; schema version; logical topic','Designer,Capability Owner,Operations,Auditor','No declared messages')
action('contracts','KAF-01','Inspect message schema','inspect','GET /api/v1/messaging/contracts/{key}','Designer,Capability Owner,Operations,Auditor','Show producer/consumer/required fields/versions','Unknown logical message')
action('contracts','KAF-02','Validate correlation envelope','validate','POST /api/v1/messaging/contracts/validate','Designer,Capability Owner,Operations','Check commandId/runId/activityId/idempotency/partition','Missing required IDs or unapproved schema','MessageContractValidated')
action('contracts','KAF-03','Check environment bindings','navigate','GET /api/v1/environment-bindings','Designer,Capability Owner,Operations','Show approved logical-to-physical resolutions','No approved topic ACL',next_page='bindings')

screen('bindings','Environment Bindings','Resolve approved logical endpoint/topic/secret references','GET /api/v1/environment-bindings','environment DEV/UAT/PROD; selected logical reference','Designer,Operations,Release Operator,Auditor','No approved bindings')
action('bindings','ENV-01','Select target environment','select','GET /api/v1/environment-bindings?env=','Designer,Operations,Release Operator,Auditor','Show redacted refs for selected environment','PROD sensitive values never shown')
action('bindings','ENV-02','Inspect binding dependency','inspect','GET /api/v1/environment-bindings/{key}','Designer,Operations,Release Operator,Auditor','Show reference/type/version/owner not secret value','Unauthorized value access denied')
action('bindings','ENV-03','Validate readiness','validate','POST /api/v1/environment-bindings/validate','Operations,Release Operator','Report unresolved refs, ACL/health incompatibility','Missing binding fails preflight','EnvironmentReadinessChecked')
action('bindings','ENV-04','Request binding change','submit','POST /api/v1/environment-bindings/change-requests','Operations','Create controlled binding change request','Direct PROD edit denied','EnvironmentChangeRequested')

screen('releases','Release Center','Review signed package and operations-controlled promotion','GET /api/v1/releases','candidate version; target environment; change ticket; approval refs','Reviewer,Operations,Release Operator,Auditor','No release candidates')
action('releases','REL-01','Inspect candidate digest','inspect','GET /api/v1/releases/{id}','Reviewer,Operations,Release Operator,Auditor','Show diff, exact package digest and pinned deps','Tampered/missing package -> reject')
action('releases','REL-02','Run preflight','validate','POST /api/v1/releases/{id}/preflight','Reviewer,Operations,Release Operator','Show signed evidence, approvals, bindings, health and tests','Any control missing => Blocked','ReleasePreflightChecked')
action('releases','REL-03','Request UAT promotion','submit','POST /api/v1/releases/{id}/promote?target=UAT','Release Operator','Stage exact digest for approved UAT pipeline','No DEV validation/owner approval','ReleasePromotionRequested')
action('releases','REL-04','Inspect approvals','inspect','GET /api/v1/releases/{id}/approvals','Reviewer,Operations,Release Operator,Auditor','Show authoritative approval evidence, not ticket string only','Missing approval explicitly shown')
action('releases','REL-05','Activate PROD (gated)','blocked','POST /api/v1/releases/{id}/activate?target=PROD','Release Operator','Only real backend controls can authorize; demo always blocked','No real bank CA/approval; no operation in prototype','ReleaseActivationAttempt')
action('releases','REL-07','Build immutable release candidate','create','POST /api/v1/releases/candidates','Reviewer,Operations','Bundle published BPMN, AMIE and operation lock into signed candidate digest','Unpublished workflow or missing dependency blocks build','ReleaseCandidateCreated')
action('releases','REL-06','Rollback for NEW runs (gated)','blocked','POST /api/v1/releases/{id}/rollback','Release Operator','Select previously approved digest for future runs only','No hidden rollback of CyberArk side effects','ReleaseRollbackAttempt')

screen('business','Business Work Queue','User-scoped batch counts and outcome reports','GET /api/v1/batches?scope=mine','batch selection; CSV fixture; status filter','Business User,Designer,Operations,Auditor','No authorized batches')
action('business','BUS-01','Start CSV request (mock)','start','POST /api/v1/workflows/DCMS.Batch/runs','Business User,Designer','Create mock batch with batch number, row GUIDs and queued state','Invalid upload/permission or missing input contract','WorkflowStartRequested')
action('business','BUS-02','Select batch','select','GET /api/v1/batches/{id}/summary','Business User,Designer,Operations,Auditor','Show selected batch counts by status','Out-of-scope batch invisible')
action('business','BUS-03','Refresh progress','refresh','GET /api/v1/batches/{id}/summary','Business User,Designer,Operations,Auditor','Refresh from source; show last-updated timestamp','Disconnected stream shows stale status')
action('business','BUS-04','View outcome reasons','inspect','GET /api/v1/batches/{id}/rows','Business User,Designer,Operations,Auditor','Show paged per-row reason codes with classification mask','No sensitive raw account fields')
action('business','BUS-05','Open report','inspect','GET /api/v1/batches/{id}/reports','Business User,Designer,Operations,Auditor','Show generated secure report refs only when terminal','Nonterminal batch shows pending report')
action('business','BUS-06','Advance fixture 5 rows','advance','mock only (no production API)','Business User,Designer,Operations','Advance simulated queue safely and counts reconcile','Never claim real operation success','DemoFixtureAdvanced')
action('business','BUS-07','Technical run (authorized)','navigate','GET /api/v1/runs/{runId}','Operations,Designer,Auditor','Open BPMN overlay and correlation evidence','Business-only user denied',next_page='runs')

screen('runs','BPMN Run Monitor','Near-real-time task overlay and correlated timeline','GET /api/v1/runs/{id}; GET /api/v1/runs/{id}/events','run selector; event filter; activity ID','Operations,Designer,Auditor','No run in permitted scope')
action('runs','RUN-01','Choose run','select','GET /api/v1/runs/{id}','Operations,Designer,Auditor','Load pinned BPMN version and activity states','Unavailable run denied')
action('runs','RUN-02','Inspect activity','inspect','GET /api/v1/runs/{id}/activities/{activityId}','Operations,Designer,Auditor','Show task inputs redacted, handler/rule/correlation/outcome','Protected fields masked')
action('runs','RUN-03','Filter event timeline','filter','GET /api/v1/runs/{id}/events?type=','Operations,Designer,Auditor','Filter event types while preserving sequence','Empty filter state')
action('runs','RUN-04','Refresh now','refresh','GET /api/v1/runs/{id}/events?after=','Operations,Designer,Auditor','Query authoritative state after push/reconnect','Show stale indicator when unavailable')
action('runs','RUN-05','Open Operator Console','navigate','GET /api/v1/runs/{id}/controls','Operations','Show authorized state transitions','Insufficient control permission',next_page='operators')
action('runs','RUN-07','Inspect correlated Kafka event','inspect','GET /api/v1/runs/{id}/events/{eventId}','Operations,Designer,Auditor','Show command/outcome envelope metadata, message IDs and safe result','Missing event or sensitive payload masked')
action('runs','RUN-06','Open audit history','navigate','GET /api/v1/audit?runId=','Operations,Designer,Auditor','Open filtered immutable evidence','Scope-restricted events masked',next_page='audit')

screen('operators','Operator Console','Privileged checkpoint-safe process controls','GET /api/v1/runs/{id}/controls','run selector; reason; expected run revision','Operations','No operable runs')
action('operators','CTL-01','Select run','select','GET /api/v1/runs/{id}/controls','Operations','Show current state, revision and allowed actions','Unknown run/role denied')
action('operators','CTL-02','Pause','pause','POST /api/v1/runs/{id}/pause','Operations','Running -> PauseRequested -> Paused at safe checkpoint','Not running, missing reason or stale revision','RunPauseRequested')
action('operators','CTL-03','Resume','resume','POST /api/v1/runs/{id}/resume','Operations','Paused -> Running, pins checked','Not paused or missing dependencies','RunResumeRequested')
action('operators','CTL-04','Cancel','cancel','POST /api/v1/runs/{id}/cancel','Operations','Request cooperative cancellation with linked evidence','Missing reason; may require reconciliation','RunCancelRequested')
action('operators','CTL-05','Retry failed step','retry','POST /api/v1/runs/{id}/retry','Operations','Reconcile before retry; increment attempt','Unknown write outcome or incorrect state','RunRetryRequested')
action('operators','CTL-06','Restart as new run','restart','POST /api/v1/runs/{id}/restart','Operations','New linked run ID; old run remains intact','Missing authorization/terminal status','RunRestartRequested')
action('operators','CTL-07','Read controlling runbook','navigate','GET /api/v1/runbooks/by-run/{id}','Operations','Open procedures and control owner','No applicable runbook => block command if required',next_page='runbooks')

screen('runbooks','Controls and Runbooks','Read operational procedures and evidence requirements','GET /api/v1/runbooks','runbook selection; control ID; version','Operations,Auditor,Reviewer','No runbooks assigned')
action('runbooks','RB-01','Select runbook','select','GET /api/v1/runbooks/{id}/versions/{v}','Operations,Auditor,Reviewer','Open read-only procedure and version','Retired version remains readable for history')
action('runbooks','RB-02','View procedure and exceptions','inspect','GET /api/v1/runbooks/{id}','Operations,Auditor,Reviewer','Show what to do, when to stop, escalation, owner','Missing real CA/control clearly marked')
action('runbooks','RB-03','Acknowledge procedure','submit','POST /api/v1/runbooks/{id}/ack','Operations','Record operator acknowledgement when required','Wrong version or role rejected','RunbookAcknowledged')
action('runbooks','RB-04','View related control evidence','navigate','GET /api/v1/audit?controlId=','Operations,Auditor,Reviewer','Open control-specific audit events','Scope denied',next_page='audit')

screen('access','Role and Scope Policies','View permissions and test actual denial paths','GET /api/v1/access/policies','selected application; permission query','Operations,Reviewer,Auditor','No policies in scope')
action('access','ACC-01','Inspect role-policy matrix','inspect','GET /api/v1/access/policies','Operations,Reviewer,Auditor','Show action, role, scope, separation requirements','No global bypass roles')
action('access','ACC-02','Test denied API fixture','test','POST /api/v1/test/authorization/denial','Operations,Reviewer','Show isolated negative API test contract','Never use PROD write endpoints','SecurityTestExecuted')
action('access','ACC-03','Request policy change','submit','POST /api/v1/access/change-requests','Operations','Open controlled policy change request','No direct role grant in UI','SecurityChangeRequested')

screen('audit','Audit and Traceability','Reconstruct what ran and who changed it','GET /api/v1/audit','runId; batchId; changeId; actor; timeframe','Operations,Auditor,Reviewer','No events in scope')
action('audit','AUD-01','Search evidence','filter','GET /api/v1/audit?run=&batch=&change=','Operations,Auditor,Reviewer','Filtered append-only timeline, stable order','Missing filter returns authorized scope only')
action('audit','AUD-02','Inspect event detail','inspect','GET /api/v1/audit/{eventId}','Operations,Auditor,Reviewer','Show actor, versions, UTC, correlation, safe result','Sensitive payloads masked')
action('audit','AUD-03','Export scoped evidence (mock)','export','POST /api/v1/audit/exports','Auditor','Create redacted, traceable export request','Unauthorized caller denied; no raw secrets','AuditExportRequested')
action('audit','AUD-04','Follow run correlation','navigate','GET /api/v1/runs/{id}','Operations,Auditor','Open technical run view at matching correlation','Dangling run reference shown',next_page='runs')

screen('apitests','API Functional Regression','Plan and review API-first test gates','GET /api/v1/regression/suites','suite selector; environment; fixture','Designer,Capability Owner,Operations,Reviewer,Auditor','No test suites available')
action('apitests','TST-01','Select suite','select','GET /api/v1/regression/suites/{id}','Designer,Capability Owner,Operations,Reviewer,Auditor','Show cases and required environment/fixture','Unknown suite')
action('apitests','TST-02','Preview test plan','inspect','GET /api/v1/regression/suites/{id}/cases','Designer,Capability Owner,Operations,Reviewer,Auditor','Show positive, denied, failure injection cases','No production test execution')
action('apitests','TST-03','Run mock fixture test','test','POST /api/v1/regression/runs (nonprod only)','Designer,Capability Owner,Operations','Simulate test results with explicit MOCK marker','No live run, unknown env, or unsafe scenario','RegressionFixtureRun')
action('apitests','TST-04','Inspect failed case','inspect','GET /api/v1/regression/runs/{id}/cases/{caseId}','Designer,Capability Owner,Operations,Reviewer,Auditor','Show assertion, expected and actual, evidence ref','No result yet')
action('apitests','TST-05','Open DEVIN job index','inspect','local docs/jobs/INDEX.md','Designer,Capability Owner,Operations,Reviewer,Auditor','Show relevant workstream and acceptance mapping','Document missing -> provide path')

assert len(set(x['id'] for x in ACTIONS))==len(ACTIONS)
