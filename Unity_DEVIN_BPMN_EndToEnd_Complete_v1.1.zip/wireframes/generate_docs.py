from model import SCREENS,ACTIONS
from pathlib import Path
import json
R=Path(__file__).resolve().parent.parent
REG=R/'wireframes/UI_CONTROL_REGISTRY_v1.0.json'
REG.write_text(json.dumps({'version':'1.0','status':'Proposed','screens':list(SCREENS.values()),'actions':ACTIONS},indent=2)+'\n')

def slug(s):return s.replace('|','\\|').replace('\n',' ')

lines=['# UI 07 - BE Screen-by-Screen Wireframe Specification','',
'> Canonical interaction source: `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. This specification is a **proposal grounded in v0.9 architecture**, not evidence that the Blazor app implements these screens.',
'', '## Global UI shell and behavior','',
'```text','+--------------------------------------------------------------------------+',
'| UNITY BE     Application [scope]    Environment [DEV/UAT/PROD]   [role]   |',
'+---------------------+----------------------------------------------------+',
'| Workbench           | Breadcrumb / page title / status of last fetch    |',
'| Registry            | Contextual actions and global validation/errors   |',
'| Onboarding          | ------------------------------------------------  |',
'| Studio / Library    | Search/list / visual work surface / detail panel  |',
'| BOB / AMIE          | (responsive, role-filtered, keyboard accessible)  |',
'| Delivery / Release  |                                                    |',
'| Business / Monitor  | Persistent save/review state, correlation footer  |',
'| Ops / Audit / Tests |                                                    |',
'+---------------------+----------------------------------------------------+',
'```','',
'Navigation is a route change, not a security privilege. The API decides which pages and records can be read. Data refresh must preserve selection and filters; auth denial must be distinct from no matching records. In wireframe, role selector is only a simulated persona selector.',
'',
'## Shared rules','',
'- Every visible action has a stable control ID in the click catalog; no inert production buttons.','- Every mutating action uses backend API, role and resource-scope verification, expected revision/ETag, and correlation ID.','- Buttons showing `202 Accepted` must display Pending until server-confirmed completion.','- Destructive/high-impact controls require reason and review/runbook gate; no side effects in the standalone prototype.','- Draft editors show Unsaved changes, Validation errors (anchored to BPMN node/field), save revision, and pinned dependency versions.','- Form generation uses operation/rule JSON schemas. Sensitive fields use protected server references, never values in browser.','- UI success toasts are informative, not proof of durable writes. The actual backend state is authoritative.','- All data-heavy tables use server-side pagination, empty state and row-level scope filtering.','',
'## Screen layouts and interactions','']

def layout(s):
  mapping={
 'workbench':'Summary tiles + recent executions + pinned applications; launch actions at upper right',
 'catalog':'Left capability filter + middle operation table + right readiness summary',
 'operation':'Operation key/version title + contract tabs (Inputs, Outputs, Permissions, Messages, AMIE, Tests) + bind action',
 'onboarding':'Manifest wizard: service identity -> operations -> schemas/policy -> validation -> release evidence',
 'apps':'Application header and tabs: modules, capability deps, workflow, scopes, env refs',
 'library':'Filter bar + definition/version table + lifecycle timeline and diff inspector',
 'designer':'3-column work surface: BPMN palette | SVG canvas | typed node inspector; issue panel below',
 'amie':'Rule version list + required facts picker + decision preview and validation errors',
 'triggers':'Trigger type selector + generated form schema editor + CSV validation panel',
 'contracts':'Message list + envelope schema and producer/consumer/ACL inspector',
 'bindings':'Environment selector + logical ref table + redacted target/health panel',
 'releases':'Package overview + dependency/preflight checklist + approvals + Ops-only gated actions',
 'business':'My batches table + summary counters + progress + paged row reasons and report',
 'runs':'Version-pinned BPMN overlay + activity inspector + correlated event timeline',
 'operators':'Selected run/status + allowed transition controls + reason/runbook + status feedback',
 'runbooks':'Control/runbook list + versioned procedure + evidence and acknowledgement',
 'access':'Role-by-action matrix + scope filter + denial test record',
 'audit':'Filter/search bar + immutable chronological event list + safe detail/export',
 'apitests':'Suite selector + regression cases + environment gate + evidence/result panel'}
  return mapping[s['id']]

for s in SCREENS.values():
  lines += [f'### {s["id"]}: {s["title"]}', '',f'**Purpose:** {s["purpose"]}', '',f'**Layout:** {layout(s)}.', '',f'**Data contract:** `{s["data"]}`', '',f'**Inputs:** {s["fields"] or "None"}', '',f'**Roles:** {s["roles"]}', '',f'**Empty state:** {s["empty"]}. **Loading:** {s["loading"]}. **Errors:** {s["error"]}.','',
            '| Control | Button/interaction | Role | API call | Immediate visible result |','|---|---|---|---|---|']
  for a in [x for x in ACTIONS if x['page']==s['id']]:
    lines.append('| '+ ' | '.join(map(slug,[a['id'],a['label'],a['roles'],f'`{a["endpoint"]}`',a['success']]))+' |')
  lines+=['', '**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.', '', '---','']
(R/'docs/ui/07-SCREEN-BY-SCREEN-WIREFRAMES.md').write_text('\n'.join(lines)+'\n')

lines=['# UI 08 - Click-by-Click Action Contract Catalog','',
 f'Canonical source `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. All {len(ACTIONS)} controls in this table have an implemented *mock* handler in `wireframes/Unity_BE_Clickable_Wireframes_v1.0.html`. The prototype does not execute backend work.',
'', '## Binding rule for all controls','',
 'On click: 1) require correct role/resource scope; 2) validate field inputs; 3) call designated API with correlation and expected revision for mutation; 4) display pending state for async requests; 5) confirm from backend response; 6) surface structured error; 7) record indicated audit event; 8) preserve selection. In the HTML prototype, these outcomes are visibly simulated and permissions are not security enforcement.', '']
for s in SCREENS.values():
  lines += [f'## {s["title"]}', '', '| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |', '|---|---|---|---|---|---|']
  for a in [x for x in ACTIONS if x['page']==s['id']]:
    lines.append('| '+ ' | '.join(map(slug,[f'**{a["id"]}** {a["label"]}',f'`{a["endpoint"]}`',a['roles'],a['success'],a['rejection'],a['audit']]))+' |')
  lines+=['']
lines+=['## Control wiring implementation rules','',
'- Preserve stable `data-control-id` matching table IDs in Blazor component tests and UI telemetry.','- For filters, the data-source API must apply scope server-side; client-side filtering alone is not sufficient.','- For mutations, a UI confirmation or optimistic immediate badge is not the server state. Wait for durable result or poll status.','- Use business disposition wording in business queue. Technical operation or broker outcomes appear only for authorized roles in run monitor.','- Browser file upload uses approved API with size/type/schema checks and tokenized blob reference; do not send CSV payload in Kafka.','- For actions marked `mock only`, there must be **no** production API counterpart. They exist solely to demonstrate state changes in the static prototype.','- Production activation and rollback remain disabled in the prototype, irrespective of selected persona.','']
(R/'docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md').write_text('\n'.join(lines)+'\n')
print('wrote registry docs',len(SCREENS),len(ACTIONS))
