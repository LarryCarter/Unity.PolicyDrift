# Unity BPMN Designer, Reusable BE UI and Cross-Service Workflows v1.1

**Current working specification:** November 11, 2026. [Open INDEX.md](INDEX.md) for direct navigation. v1.1 adds complete BPMN UI authoring contracts, 18 editable flow/sequence/state diagrams, four principal workflow configurations plus separate hygiene, a new clickable multi-workflow configurator, 63 additional action contracts and 20 focused DEVIN jobs. All v1.0 and earlier current architecture content remains below as reference.

**Required first step:** reconcile the real Unity repository. The example BPMN XML, JSON descriptors and HTML are design fixtures only, not executable implementations, and unknown NAS/AutoSys/CyberArk contracts are explicitly marked as unverified. No new unapproved library is assumed.

---

# Unity BE + Capability SDK Detailed Wireframes and Execution Handoff v1.0

This version **extends the v0.9 current implementation handoff**. It adds **19 specified UI screens, 107 action contracts, an interactive behavior model, 9 detailed SDK design modules, 17 DEVIN subtask packets and updated five repository Skills**. The existing architecture and original JOB-00 through JOB-20 remain available below.

**Read [INDEX.md](INDEX.md) first.** The most important new references are `docs/ui/07-*`, `docs/ui/08-*`, `docs/sdk/00-*` through `08-*`, and `jobs/interaction/INDEX.md`. `wireframes/Unity_BE_Clickable_Wireframes_v1.0.html` is a self-contained browser simulation, not Blazor source or a connected service.

**Status:** Proposed contract/specification. Prior work contains conceptual SDK names and mocked examples; current Unity source and bank approvals are NOT included. DEVIN must perform JOB-00/SDK-10 before naming new types and projects. No production activation permission is inferred from these docs.

---

# Unity Platform — DEVIN Implementation Handoff v0.8

**Planning snapshot:** 2026-11-11. **Target:** demonstrable core by 2026-11-30. **Implementation status:** design and assignment pack; repository code, approvals, and bank controls NOT inspected or verified.

## Read this first

1. Read [`AGENTS.md`](AGENTS.md) and [`docs/00-START-HERE.md`](docs/00-START-HERE.md).
2. Execute **JOB-00 — repo reconciliation**. Do not invent new AMIE APIs: the existing AMIE implementation is substantial.
3. Review [`docs/roadmap/DELIVERY-PLAN.md`](docs/roadmap/DELIVERY-PLAN.md), then take independent jobs from [`jobs/INDEX.md`](jobs/INDEX.md).
4. Apply the corresponding repository instruction from `.agents/skills/*/SKILL.md`.
5. Use [`docs/ui/`](docs/ui/) for operator/designer click paths and [`docs/testing/`](docs/testing/) for test evidence.
6. Merge these documents by PR with the current Unity repository; do not treat proposed class names or mocked UI as deployed implementations.

## Core invariant

**BE (Blazor)** designs/observes/operates; **BOB** executes BPMN workflows; **AMIE** evaluates existing configurable rules/mappings; **capability microservices** perform approved business-system operations; **Kafka** carries cross-service commands/outcomes; **MSSQL** persists BOB state, audit, and durable integration metadata. Services own their business data. Central and embedded BOB use the *same core semantics*.

## Deliverables

- `docs/architecture/`: technical requirements, topologies, interfaces, state, security, workload example.
- `docs/contracts/`: proposed C# APIs, schema and event contracts, version compatibility. These are reconciliation targets, not claims of existing code.
- `docs/ui/`: step-by-step configuration, execution, access, test, deployment runbooks for Blazor BE.
- `docs/testing/`: API and BPMN regression, failure tests, release evidence.
- `docs/roadmap/`: dependency-ordered November cut line and demo criteria.
- `jobs/`: independently assignable job packets with prerequisites, acceptance checks, deliverables, guardrails and changed-file expectations.
- `.agents/skills/`: five reusable Devin Skills for new capabilities, BPMN, AMIE wiring, BE development, and release/testing.
- `history/`: original v0.6/v0.7 source artifacts retained without silent rewrite.
- `examples/`: **nonproduction** illustration contracts and workflows.

## Non-goals for November

No implementation of all BPMN 2.0 semantics, no new AMIE engine, no full mid-flight migration, no arbitrary code execution from BPMN/UI, no unrestricted SQL bridge, no direct browser Kafka, no assumption of new unapproved paid/open-source dependencies, no fabricated ServiceNow/CA approvals, and no guarantee of PROD release before actual bank gates.

## Evidence and authority

- **[USER]** = direction explicitly established in conversation (architecture, MVP target, DCMS behavior).
- **[PROPOSED]** = implementation contract offered for DEVIN to validate and adapt.
- **[VERIFY]** = must inspect source, environment, approval, or ownership before declaring done.
- **[DEFER]** = non-MVP idea preserved on backlog.

The original v0.7 materials are under `history/`. v0.8 extends and organizes them; it does not claim to replace code or bank controls.

## External reference URLs

- BPMN 2.0.2: https://www.omg.org/spec/BPMN/2.0.2
- Devin repository Skills: https://docs.devin.ai/product-guides/skills
- Blazor JS interop (.NET 10): https://learn.microsoft.com/en-us/aspnet/core/blazor/javascript-interoperability/?view=aspnetcore-10.0
- OptimaJet public API (feature research only; not source/SDK license): https://api.workflowengine.io/
