# Unity | Capability Discovery, Configuration Composition, and Controlled Promotion

**Version:** 0.6  
**Date:** November 11, 2026  
**Status:** Architecture proposal for reconciliation with existing Unity repositories  
**Audience:** Unity architecture owners, BE/Blazor implementers, BOB/AMIE engineers, DEVIN work packet owners, operations and controls reviewers  
**Delivery target:** Demonstrable foundation and one or two configured CVIS/PAM application workloads by November 30, 2026  
**Related record:** `Unity_BOB_BE_Visual_Designer_Blueprint_v0.5.md` and Unity MVP matrix v0.4

## 1. Architectural decision

**Unity is a configuration-first platform, not a collection of custom-written application workflows.**

An approved, versioned **Capability Manifest** describes operations supplied by a capability microservice. BE automatically discovers the allowable operations, their input/output schemas, permissions, execution modes, and version constraints. A designer composes a business process in BPMN, references existing AMIE rules for decisions and transformations, and binds process tasks to capability operations or other reusable BOB workflows. When an operation already exists, a new application use case should usually require only configuration. Only missing *fundamental primitives* require new C# adapter code.

The **same BOB execution core** runs both centrally (distributed process orchestration) and embedded inside capability services (local sub-workflows). The **existing AMIE runtime** supplies decision and transformation logic. Kafka carries cross-service commands and outcomes; it is not required for each local activity or rule evaluation. BE provides the Blazor authoring experience, catalog, release management, status, and audit inspection.

### User-established constraints to preserve

- BE is Blazor. A visual designer is a first-class requirement, not an incidental administrator screen.
- BOB is the current critical blocker; substantial AMIE implementation already exists. Reuse its actual interfaces after repository inspection.
- Central BOB coordinates distributed workflows; embedded BOB and AMIE run in process within a capability when appropriate.
- Capabilities own integrations, registered operations, and their data boundaries. Email uses **Email Capability**, Kafka, and AMIE policy—not a hardcoded BOB email sender.
- BOB workflow persistence supports **Microsoft SQL Server only**. That does not mean all capability-owned data must be hosted in the same database.
- New dependencies are subject to Wells Fargo approval. Do not make a new unapproved BPMN editor package a prerequisite for the November demo. An already approved paid component can be evaluated, but approval has not been established.
- DEV/UAT configuration must be promotable without granting developers access to production. Operations and approved control gates own production activation.
- DCMS, hygiene, enrichment, onboarding, compliance, and Policy Drift are **application workloads**, not hardcoded BOB or AMIE features.
- The goal is a coherent working foundation and one/two demonstrable CVIS/PAM workloads by November 30, not complete BPMN 2.0 coverage or a full commercial product clone.

### New proposals in this record (validate against existing code)

- A versioned capability/operation manifest and a central authorized discovery registry.
- BE Application Studio for selecting and composing reusable primitives.
- Typed input/output bindings with schema validation, rather than unconstrained reflection or arbitrary SQL/API calls.
- A portable, immutable Unity configuration package with dependency locks, release digest, trusted signature, control evidence, and environment-independent logical references.
- A distinct Operations activation interface that maps logical references to approved target-environment service routes and secret references.

## 2. Unified runtime topology

```mermaid
flowchart LR
  Users[Authorized designer and operations users] --> BE[BE - Blazor UI]
  BE --> Registry[Approved Capability and AMIE Registries]
  BE --> Defs[Workflow Definition and Package API]
  Defs --> SQL[(MSSQL: BOB definitions, runs, audit)]
  Defs --> Artifacts[Immutable approved artifact repository]
  Registry --> Defs
  BE --> Status[Run and Evidence API]
  Status --> SQL
  Artifacts -->|Approved promotion| Ops[Operations deployment service]
  Ops --> Bindings[Target environment binding provider / secrets references]
  Ops --> Central[BOB Central Host]
  Central -->|Command with correlation| Kafka[(Kafka)]
  Kafka -->|Authorized command| Cyber[CyberArk Capability]
  Kafka -->|Authorized command| Mail[Email Capability]
  Kafka -->|Authorized command| Data[Database Capability]
  subgraph CyberBoundary[Inside CyberArk Capability]
    Cyber --> LocalBOB[BOB Embedded Runtime]
    LocalBOB --> AMIE[AMIE Embedded Evaluator]
    LocalBOB --> Adapter[Registered CyberArk Operation Handlers]
  end
  Cyber -->|Outcome event| Kafka
  Mail -->|Outcome event| Kafka
  Data -->|Outcome event| Kafka
  Kafka -->|Correlated results| Central
```

**Critical separation:** the definition/registry/control plane publishes approved packages and descriptors. Runtime execution must not synchronously consult it for every local rule or activity. Hosts cache approved version-pinned definitions and verify updates independently.

## 3. Glossary of configuration assets

| Asset | Purpose | Owned by | Changed by |
|---|---|---|---|
| Capability | Deployed service that owns implementations and integrations | Capability team | Code release |
| Operation descriptor | Public, typed, authorized contract exposed for composition | Capability team | Capability manifest release |
| Activity handler | Implementation of a registered operation | Capability service | Code release |
| AMIE rule set | Business rule, condition, transformation, policy and mapped result | Rule owner | Controlled rule configuration |
| BOB workflow definition | Executable process flow, sequencing, gateways, tasks and call activities | Process owner | Controlled BPMN configuration |
| Workflow binding | Reference from BPMN activity to operation/rule/subworkflow and typed mappings | Application/workload owner | Controlled configuration |
| Application blueprint | A group of related workflows and rule references for DCMS or another workload | Application team | Controlled configuration |
| Unity release package | Immutable versioned set of definitions and dependency locks | Release pipeline | Published by trusted automation |
| Environment binding | Logical-to-physical route, topic, endpoint and secret reference | Operations/platform | Target-specific controlled configuration |
| Runtime execution record | Historical evidence of one process and its cross-service events | BOB/audit services | Append-only by trusted runtime |

**Do not confuse:** `CapabilityManifest` metadata (discoverable) with `ActivityHandler` implementation (executed server-side). The browser never sends arbitrary CLR class/method names, SQL statements, C# scripts, or credentials for BOB to invoke.

## 4. Screen-by-screen BE design (10 main surfaces + operation inspector drill-down)

| Screen | Required visual interactions | Backend/data responsibility | MVP cut line |
|---|---|---|---|
| 1. Workbench | Architecture and workload overview, quick navigation | Registry summaries and recent run data | P0 - straightforward |
| 2. Capability Registry + Operation Inspector | Search, filter, list operations and versions; inspect typed inputs, side effects, entitlements, and add to flow | Authenticated descriptor API, compatibility, server-side RBAC | P0 |
| 3. Capability Onboarding | Developer registration journey, manifest example, validation checklist, registry publication status | Capability build + manifest signing + approved service release | P0 contract; richer UI later |
| 4. Application Studio | Choose DCMS module, reuse operations/rules, build a configuration blueprint | Application metadata + BOB/AMIE registry references | P0 light; richer templates later |
| 5. BOB Workflow Designer | BPMN canvas, node selection/drag, binding pickers, typed field mapping, errors, save draft | BOB server-side parse/validate/compiler; editor UI remains replaceable | P0 narrow subset |
| 6. AMIE Rule Studio | Browse/select current rule sets; edit supported approved expressions, preview result | Existing AMIE model and validation APIs; avoid a duplicate rules engine | P0 integration / reuse current UI |
| 7. Environment Bindings | Show logical key and approved resolved target binding; validate compatibility | Operations-controlled mapping and vault references | P0 for release preflight; UI can be read-only |
| 8. Release Center | Candidate package, DEV → UAT → PROD path, approval/control status, Operations activation | Signed artifacts, CI/CD, bank CA integrations and server-side gates | P0 minimal controls, production depends on approvals |
| 9. Run Monitor | Same BPMN with state overlay, cross-service timeline and selected activity evidence | BOB MSSQL state, Kafka/capability outcomes, trusted audit service | P0 |
| 10. Audit & Controls | Version lineage, identity, rule decisions, release authorization and evidence review | Trusted audit/index service mapped to actual bank controls | P0 minimal evidence; expansion later |

**Design ergonomics:** central canvas plus left operation palette and right inspector; responsive labels; search rather than enormous dropdowns; bindings auto-populated from schemas; unknown operations shown as **Missing Capability Primitive** rather than inventing callable methods. The design and run views should share diagram geometry (BPMN DI), though only execution mode overlays node statuses.

### Workflow inspector contract

Selecting a BOB node should show:

- **Identity:** BPMN node ID, task name, description, owner.
- **Operation:** capability key, operation key, immutable contract version, local vs cross-service dispatch.
- **Inputs:** typed fields mapped from workflow context, earlier task outputs, constants allowed by policy, and AMIE values.
- **Outputs:** strongly identified result fields available to downstream nodes.
- **Policy:** auth/permission, idempotency requirements, retry and timeout, sensitive-data classification, compensation/reconciliation behavior.
- **Dependencies:** AMIE rule ID/version, subprocess ID/version, message schema version, capability contract version.
- **Evidence:** required audit fields, correlation identity, masking, approval and environment restrictions.

When adding a capability task, BE queries an **approved operation descriptor** and generates the form from schema. It must not require a developer to hand-code a new Blazor page for each operation.

## 5. Adding a new business process without rewriting CyberArk

**Scenario:** a new DCMS process combines existing CyberArk account operations with hygiene or policy logic.

1. Designer opens Application Studio, selects **DCMS**, and chooses to configure a new workflow/module.
2. BE queries the published CyberArk manifest and displays available operations (`SearchAccounts`, `GetAccount`, `UpdateAccount`, `ListSafes`, etc.). These are *illustrative* operation names; match the real adapter catalog before implementation.
3. Designer adds a **CyberArk operation task** to a local BOB subworkflow and maps the inputs from workflow context using typed selectors.
4. Designer adds an **AMIE business rule task** to evaluate the account eligibility/hygiene/policy decision, then maps returned result fields to a BOB gateway or subsequent activity.
5. Designer adds another already-registered CyberArk operation, such as `UpdateAccount`, if authorized. BOB executes that handler locally in the capability. No new CyberArk service code is necessary **when that operation and contract exist**.
6. The central BOB orchestration can call this reusable CyberArk subflow as **one logical capability activity** via a Kafka command, wait for a correlated result, then continue to Database, Email, or another capability.
7. BE validates schema compatibility, permissions, process semantics, and dependencies. The author requests approval to publish a versioned package.
8. After deployment, the same model is used by the Run Monitor to show what happened.

### If a required operation is missing

1. BE shows the operation as unavailable; it does **not** allow direct arbitrary CyberArk REST invocation or a raw connection-string escape hatch.
2. Capability developer implements and tests one reusable adapter/primitive within the CyberArk service and describes its inputs, outputs, permissions, side effects, idempotency and execution mode.
3. The normal approved code release deploys the new capability version and registers its authorized descriptor.
4. BE discovers the newly available operation. Any permitted application can now bind it without modifying BOB or AMIE Core.

**Platform rule:** business process assembly is configuration; *primitive creation* is engineering. No-code is not equivalent to unrestricted production execution.

## 6. Capability manifest and operation contract

*Illustrative schema; do not treat these type names as implemented Unity classes.*

```json
{
  "capabilityKey": "CyberArk",
  "capabilityVersion": "1.4.0-demo",
  "owner": "PAM Platform Team",
  "status": "illustrative",
  "operations": [
    {
      "operationKey": "CyberArk.GetAccount",
      "contractVersion": "1.0",
      "executionModes": ["EmbeddedLocal", "KafkaCommand"],
      "inputSchema": {
        "type": "object",
        "required": ["accountId"],
        "properties": {"accountId": {"type": "string"}}
      },
      "outputSchema": {
        "type": "object",
        "required": ["account"],
        "properties": {"account": {"$ref": "contracts/AccountRecord.v1.json"}}
      },
      "authorizationPolicy": "PAM.Account.Read",
      "sideEffect": "Read",
      "idempotency": "SafeToRetry",
      "auditCategory": "PAM_ACCOUNT_READ"
    }
  ]
}
```

Key contract requirements:

- **Stable operation key** independent of hosting address, assembly, endpoint and Kafka topic.
- **Versioned typed schemas**; mark breaking changes and reject incompatible bindings.
- **Explicit operation allowlist and policy**. A descriptor never grants additional authorization by its mere presence in a registry.
- **Execution mode** determined by boundary: inside capability local handler; between services message command/outcome (or explicitly approved API where justified).
- **Side effect and retry semantics**. Write operations must declare their idempotency and reconciliation constraints.
- **Per-operation evidence contract**. Choose what can be logged; redact sensitive fields.
- **Health and compatibility**. Registry metadata should distinguish published contract from currently healthy deployed version; availability is a runtime concern.

### C# contract sketch

Recommended file boundaries, subject to reconciliation with the existing Unity solution:

```text
/Unity.Capability.Contracts/Descriptors/CapabilityManifest.cs
/Unity.Capability.Contracts/Descriptors/CapabilityOperationDescriptor.cs
/Unity.Capability.Contracts/Execution/CapabilityInvocation.cs
/Unity.Capability.Contracts/Execution/CapabilityOutcome.cs
/Unity.Capability.Runtime/Registry/ICapabilityOperationRegistry.cs
/Unity.Capability.Runtime/Execution/ICapabilityOperationHandler.cs
/Unity.Capability.Runtime/Execution/CapabilityOperationDispatcher.cs
/Unity.Bob.Contracts/Bindings/WorkflowActivityBinding.cs
/Unity.Bob.Core/Execution/BOBActivityDispatcher.cs
/Unity.Bob.Embedded/Execution/EmbeddedWorkflowHost.cs
/Unity.Bob.Service/Execution/DistributedWorkflowHost.cs
/Unity.BE/Components/Pages/CapabilityRegistry.razor
/Unity.BE/Components/Pages/CapabilityInspector.razor
/Unity.BE/Components/Pages/ApplicationStudio.razor
/Unity.BE/Components/Pages/BobDesigner.razor
/Unity.BE/Components/Pages/ReleaseCenter.razor
/Unity.BE/Components/Pages/RunMonitor.razor
```

```csharp
// /Unity.Capability.Contracts/Execution/CapabilityInvocation.cs
public sealed record CapabilityInvocation(
    string CapabilityKey,
    string OperationKey,
    string ContractVersion,
    string WorkflowInstanceId,
    string ActivityInstanceId,
    string CorrelationId,
    string IdempotencyKey,
    IReadOnlyDictionary<string, object?> Inputs);

// /Unity.Capability.Runtime/Execution/ICapabilityOperationHandler.cs
public interface ICapabilityOperationHandler
{
    string OperationKey { get; }
    string ContractVersion { get; }
    Task<CapabilityOutcome> ExecuteAsync(
        CapabilityInvocation invocation,
        CancellationToken cancellationToken);
}

// /Unity.Capability.Contracts/Execution/CapabilityOutcome.cs
public sealed record CapabilityOutcome(
    string ActivityInstanceId,
    string OperationKey,
    string ContractVersion,
    string OutcomeCode,
    IReadOnlyDictionary<string, object?> Outputs);
```

This is **not** permission to dispatch by arbitrary user-supplied strings. The dispatcher resolves only explicitly registered handlers, validates the manifest version, checks authorization in the service boundary, enforces input schema and idempotency policy, then invokes the handler. An existing AMIE/BOB SDK contract takes precedence over illustrative signatures above.

## 7. BOB/AMIE invocation semantics

| Workflow element | Runtime ownership | How execution occurs |
|---|---|---|
| BPMN start/end/gateway | BOB Core | In-process token/state transitions; no Kafka for ordinary local flow |
| BPMN service task within capability | Embedded BOB host | Dispatch registered local capability activity handler |
| BPMN business rule task within capability | Existing AMIE embedded evaluator | Evaluate locally cached approved rule version and return typed decision |
| BPMN call activity pointing to local subflow | Embedded BOB | Execute reusable version-pinned workflow in the same service boundary |
| BPMN task crossing service boundary | Central BOB + Kafka adapter | Publish typed command, persist wait, correlate outcome, resume |
| Human task / approval | Central BOB + BE + identity/control adapter | Durable wait, authorized completion, audit record |
| Timer wait | Central durable host | MSSQL checkpoint and scheduler; no long-lived thread per waiting instance |
| Email request | Email Capability | Kafka command, capability-side AMIE policy, approved transport and outcome event |

**Prohibit:** a browser-drawn workflow that invokes unregistered URLs, compiles arbitrary C# in runtime, embeds credentials, or bypasses a capability boundary because the author has access to a UI.

## 8. Message, identity, trace and audit envelope

A cross-service activity should preserve at least these identities (exact names must align with existing Kafka standards):

```json
{
  "messageId": "evt-demo-001",
  "correlationId": "trc-demo-6e92",
  "causationId": "evt-demo-000",
  "workflowInstanceId": "run-demo-1012",
  "activityInstanceId": "activity-demo-0004",
  "definitionRef": "dcms.account.lifecycle@0.6.0-demo",
  "operationRef": "CyberArk.GetAccount@1.0",
  "schemaVersion": "1.0",
  "idempotencyKey": "run-demo-1012:activity-demo-0004",
  "actorRef": "principalref://redacted",
  "occurredAtUtc": "2026-11-11T00:00:00Z",
  "payloadRef": "authorized-payload-reference-not-secret-data"
}
```

Runtime must provide: transactional outbox for reliable command publication, inbox/deduplication for at-least-once delivery, bounded retries, dead-letter handling, idempotency/reconciliation of side effects, correlation on outcomes, and immutable evidence metadata. **Do not rely on exactly-once Kafka delivery to make external CyberArk writes exactly once.** The capability must enforce its own operation-specific idempotency or reconciliation.

## 9. Portable release package and production promotion

### Separate two deployment classes

**A. Capability code release:** introduces or changes executable adapters, handlers, security policies, dependency binaries, schemas or infrastructure. Goes through full code deployment approval and CI/CD. Cannot be smuggled into a config bundle.

**B. Configuration-only release:** composes already approved operations, BPMN definitions, AMIE rule definitions, templates and allowed policies. Produces an immutable release package. May be deployed by authorized Operations without developers accessing PROD, **subject to bank controls**.

### Suggested portable artifact

A proposed `*.unitypkg` archive (extension is provisional) contains:

```text
manifest.json                 # application and immutable release ID
workflows/*.bpmn              # canonical supported BPMN XML + diagram geometry
rules/*.json                  # AMIE rule references / included allowed configs
contracts/dependencies.json   # capability operation and schema lock
metadata/validation.json      # compiled/validated results and required approvals
checksums.json                # integrity manifest
signature.sig                 # trusted release signing outcome
```

Do **not** package raw connection strings, vault secrets, CyberArk credentials, or production URLs. An exported development artifact is not trusted merely because its filename ends in `.unitypkg`. The release pipeline and target service must validate the exact artifact content, trusted signature, publisher, dependency versions and control evidence.

### Controlled promotion sequence

1. **DEV authoring:** designer composes workflow and AMIE rules in BE and saves drafts.
2. **Validation:** BOB compiles supported BPMN, resolves operation schemas, checks rule versions, allowed permissions and cross-service message compatibility.
3. **Review/approval:** approved author/reviewer controls capture required evidence. Developer cannot self-approve where separation is required.
4. **Build:** trusted pipeline packages the immutable definition snapshot and dependency lock, computes a content digest and signs it using approved infrastructure.
5. **UAT staging:** authorized release process imports **the exact candidate**. Target binding provider resolves UAT topics/endpoints/secret references.
6. **UAT verification:** integration, permission, failure/retry, data handling and audit tests recorded against the same digest.
7. **Change authorization:** bank-required CAs, control attestations, approvals and release windows checked against authoritative services. Control names and IDs are **unknown until provided by Wells Fargo**.
8. **PROD Operations activation:** Operations selects the immutable release ID (or uploads/requests an approved signed artifact through a controlled channel). A server-side preflight verifies signature, UAT evidence, CA authorization, separation of duties, runtime compatibility, schema versions, and target bindings. Developer PROD access is unnecessary and must not be introduced by the UI.
9. **Atomic activation:** approved configuration references switch to the new version; in-flight workflows remain pinned to prior definitions unless explicitly migrated. Emit release evidence and provide rollback to the last approved version.

### Environment binding example

| Logical key within package | DEV binding | UAT binding | PROD binding |
|---|---|---|---|
| `CyberArk.CVIS` | DEV-approved capability route | UAT-approved capability route | Ops-controlled PROD route |
| `Email.Primary` | DEV test transport | UAT test transport | Approved PROD mail gateway |
| `unity.capability.command` | DEV topic | UAT topic | PROD topic |
| `BOB.WorkflowStore` | DEV MSSQL schema | UAT MSSQL schema | PROD MSSQL schema |
| `CyberArk.ServiceIdentity` | DEV vault ref | UAT vault ref | PROD vault ref (not in bundle) |

The binding registry and runtime enforce authorization; none of this is editable simply because a BE designer can view it. Production activation should **fail closed** if authorization, required bindings, signed artifacts or dependency versions are missing. A configuration update that widens permissions, changes data classification or attempts new capability execution must undergo appropriate additional review.

## 10. Proposed BE API endpoints

*Proposals only; reuse any already implemented Unity endpoints rather than duplicating services.*

```text
GET    /api/be/capabilities                              # authorized catalog
GET    /api/be/capabilities/{key}/operations              # descriptor/schema lookup
GET    /api/be/amie/rules                                 # approved rule versions
GET    /api/be/applications/{appKey}                      # workload blueprints
POST   /api/be/workflows/drafts                           # draft save
POST   /api/be/workflows/{workflowKey}/validate           # BPMN + typed refs
POST   /api/be/releases/candidates                       # trusted build request
GET    /api/be/releases/{releaseId}                       # immutable manifest/status
POST   /api/be/releases/{releaseId}/request-approval      # authorized request
GET    /api/be/runs/{instanceId}/timeline                  # correlated evidence
GET    /api/ops/environments/{environment}/bindings      # sanitized logical map
POST   /api/ops/releases/{releaseId}/preflight            # RBAC + control checks
POST   /api/ops/releases/{releaseId}/activate             # ops-only; server enforced
```

BE navigation and UI buttons are *not* security boundaries. Each management and execution endpoint enforces the caller's authorization, scope, separation-of-duties and required approvals.

## 11. Minimum November demonstration boundary

The November demo should prove **reuse and controlled composition**, not the existence of every BPMN symbol. A suggested order of work for DEVIN and existing developers:

| Build packet | Deliverable | Dependencies | Acceptance test |
|---|---|---|---|
| P0-1 Contracts | Versioned `CapabilityOperationDescriptor`, workflow binding, correlation envelope | Existing AMIE/BOB interface inventory | One schema/contract used by BE and host; no duplicated definitions |
| P0-2 Registry | Capability publishes/BE reads allowed descriptors | Contracts, identity/RBAC | BE lists a new approved operation without a UI code change |
| P0-3 Embedded BOB | Local service task, rule invocation, subworkflow dispatch | BOB core, actual AMIE adapter | Capability runs without central per-step calls |
| P0-4 Central BOB | Kafka command/outcome, wait state, MSSQL checkpoint | Contracts, Kafka, persistence | Correlated completion resumes after restart |
| P0-5 BE Designer | Limited BPMN SVG modeler, inspector and mappings | Contracts, validator | A user can build, reopen, validate and configure a workflow |
| P0-6 Run + Audit | Diagram overlay and correlated trace | Runtime and evidence model | One trace spans BE/BOB/AMIE/Kafka/capabilities |
| P0-7 Promotion | Immutable candidate, binding preflight, UAT demo and ops roles | Package signing/control evidence | UAT stage works; PROD activation refuses absent bank approvals |
| P0-8 Pilot Workload A | Read-only PAM hygiene or account inventory process | CyberArk read ops, BOB, BE | Full demonstrable flow with real or approved sandbox data |
| P1-9 Pilot Workload B | Enrichment, onboarding or Policy Drift as approved | Existing operations and rule maturity | Second independent workflow proves reuse |

**Must have by Nov 30:** at least one application demonstrably executes via BOB with configured AMIE/capability operations and visible audit trace. A second application is a target, not an excuse to bypass correctness/security. Whether production release is possible depends on existing bank control and CA timing.

**Defer unless pilot requires it:** full BPMN conformance, arbitrary event choreography, advanced compensation, complex inclusive gateways, generalized plugin marketplace, drag-and-drop auto-layout, ad-hoc activities, multi-database providers, universal form designer, all OptimaJet features.

## 12. Validation gates and unknowns

- **Not verified:** current .NET project structure, existing AMIE contracts, existing approved paid Blazor/BPMN libraries, CyberArk operation coverage, Kafka topics, production release gates, service identity schema, and internal CA/control naming.
- **No evidence of implementation:** the HTML prototype is a standalone simulated UI and does not execute BPMN, call CyberArk, run AMIE, publish Kafka events, or deploy to PROD.
- **Architectural risk:** an unapproved dynamic C# compiler or reflection-based HTTP endpoint could accidentally become a privileged generic execution surface. Restrict composition to explicitly registered, permissioned handlers and approved rule semantics.
- **Audit risk:** centralized trace storage can leak credentials, PII, or account metadata. Store sanitized identifiers and references to separately controlled records.
- **Production risk:** switching UI personas or toggling checkboxes cannot constitute authorization. Real release operations must verify actor, package, approval, policy, target binding and bank controls server-side.
- **Operational risk:** package compatibility and in-flight version pinning must be proven by tests, especially during rollback or failure recovery.

## 13. Concrete next handoff

Reconcile this proposal against the **existing Unity solution** before a large DEVIN build: locate actual AMIE entrypoints, BOB code and contracts, capability registrations, BE Blazor shell, approved UI dependencies, and bank configuration-promotion mechanisms. Freeze the smallest shared contract. Then split DEVIN work by ownership of contracts rather than giving multiple agents unrestricted authority over the same runtime. Keep one canonical review of message/event schemas, rule decisions and service boundaries.

**Configuration-first invariant:** If an approved capability operation exists, users should be able to compose it with AMIE rules and BOB workflows without changing the service's code. If a primitive does not exist, implement it once behind an approved contract and immediately make it reusable across future processes.

---

*End of v0.6 design proposal. User-established decisions remain authoritative; new contracts and deployment mechanics in this document are candidates until reconciled with the running Unity implementation and Wells Fargo requirements.*
