# Unity Business Enablement Design Pack v0.6

## What is included

- `Unity_BE_Capability_Composer_Prototype_v0.6.html`: standalone interactive browser mockup of the ten main BE screens and capability operation inspector.
- `Unity_Capability_Discovery_Composition_and_Promotion_Blueprint_v0.6.md`: engineering blueprint and acceptance criteria.
- `Unity_Capability_Manifest_Sample_v0.6.json`: illustrative typed CyberArk capability operation descriptor.
- `Unity_Configuration_Package_Sample_v0.6.json`: unsigned and unapproved portable configuration package example.
- `screenshots/*.png`: screen previews.

## How to explore the prototype

1. Open the HTML file in a modern browser. No network dependency or installation is required.
2. Browse **Capability Registry** and select **CyberArk**; inspect a typed operation contract.
3. Choose **Use in workflow** to bind the sample operation into the BOB designer.
4. Switch BOB designer from **Central orchestration** to **CyberArk embedded** and inspect the AMIE activity.
5. Use **Application Studio** to add an existing primitive to a DCMS module.
6. Check **Environment Bindings**, **Release Center**, and **Run Monitor** for the promotion and traceability flow.

Everything in the HTML is illustrative. Operation names, versions, permissions, approvals, traces and UI status are mock data. Draft persistence depends on browser permissions and may be limited to the open session. The HTML does not connect to Unity, CyberArk, AMIE, Kafka, MSSQL, Wells Fargo change control or any production environment; it does not deploy configuration.

## Architecture invariant

**BE discovers and configures; BOB executes; AMIE decides; capabilities perform actions; Kafka connects services; MSSQL persists BOB state; Operations activates approved, signed, version-pinned configuration packages without developer production access.**

Missing operations require an authorized capability code release. Reusing registered operations does not.
