# Unity / DEVIN — Complete History and Implementation Handoff v0.8

**Purpose:** Preserve previous design artifacts in their original form while providing one clearly identified current DEVIN implementation handoff.

## Canonical order for DEVIN

1. **CURRENT:** `current/Unity_DEVIN_Implementation_Handoff_v0.8/README.md` and `AGENTS.md` are the current tasking entrypoints. Work only from the latest reconciled contract after JOB-00 and JOB-01, not old prototypes.
2. **HISTORY:** `history/` is evidence of prior discussion, alternative designs, historical matrices, and UI inspiration. It is **not** authorization to implement superseded designs. Later explicit user decisions take precedence over historical proposals.
3. **REFERENCE:** `references/workflowengine-api-docs.md` is user-supplied OptimaJet API reference text for feature learning only; it is **not a license to copy code, proprietary design assets or use dependencies without approval**.
4. **BE prototypes:** v0.5, v0.6, v0.7 HTML are demo/UI references only and are not deployed or production approved.

## Earlier work preserved here

| Version | What the original artifact covers | Status |
|---|---|---|
| v0.2 | BOB/OptimaJet comparison, BPMN features, MSSQL, early gap matrix | Historical; superseded in parts |
| v0.3 | BOB application-agnostic correction, workload separation | Historical; decision carried forward |
| v0.4 | Integrated Unity MVP architecture, BE, capabilities, Kafka, audit, DEVIN packets | Historical; revise for repository code |
| v0.5 | First BE BPMN designer blueprint and interactive visual | Historical UI inspiration |
| v0.6 | Capability registry, composition, operation contracts, release promotion; full zipped designer/screens pack | Historical UI inspiration and contracts |
| v0.7 | Run controls, roles, audit, operational views, DCMS vertical slice; full zipped prototype/screens/matrix pack | Historical integration baseline |
| v0.8 | Repo Skills, architecture specs, tests, 21 DEVIN job packets and UI runbooks | Current proposed plan; still requires actual code reconciliation |

## Limits and known gaps

- This pack preserves **available generated artifacts and the uploaded vendor reference**; it does not automatically include every in-chat thought or the source repository.
- The initial Unity Architecture ADR v0.1 was a **chat writing block**, not an accessible standalone file in this runtime. It is **not present verbatim**. Related decisions are represented in subsequent documents; verify any older ADR-specific language before claiming a complete textual archive.
- The full actual AMIE implementation and current Blazor/BOB/CyberArk source code are **not included**. DEVIN must inspect the live repository in JOB-00.
- Wells Fargo internal approvals, CAs, control IDs, and ServiceNow records are **not included** and must be supplied/verified by authorized owners.
- Vendor documentation is reference material, not a substitute for licensing or validation.

## File roles

- `current/` — v0.8 repository-ready files, unchanged relative to the original v0.8 package.
- `history/v0.2` through `history/v0.7` — original pre-v0.8 artifacts. Full v0.6/v0.7 archives include screenshots and manifests.
- `references/` — external reference supplied by the user.
- `previews/` — earlier preview screenshots where available.
- `MANIFEST.sha256` — SHA-256 checksums of all bundled input files for integrity.

**Rule:** This is an archive and consolidation of evidence; no source code was changed, no bank deployment was performed, and historical statements were not silently promoted to approved requirements.
