# UNITY | BOB + BE Visual Designer & Integration Blueprint

**Version:** 0.5 | **Date:** November 10, 2026 | **Status:** Design proposal for review/merger, not implemented  
**Target:** Working, demonstrable Unity vertical slices by November 30, 2026  
**Primary implementation:** Existing .NET/Blazor solution; use already-approved enterprise dependencies only  
**Reference:** OptimaJet Workflow Engine .NET API documentation (feature-learning reference, not a replacement or a license to copy its implementation)

> **Architecture invariant:** The Unity platform remains application-agnostic. Hygiene, CMDB enrichment, onboarding, Policy Drift, and other CVIS/PAM applications are workloads configured onto Unity, not BOB or AMIE core features.

## 1. Executive decision

Unity already has a broad architecture and significant AMIE work. The near-term blocker is specifying and implementing the **BOB core + its BE designer/operations contract**, not recreating the rest of Unity. The designer is important from day one: users need to assemble executable workflows, bind steps to reusable capability operations and AMIE rules, publish according to controls, and then see what happened across services.

**The integration boundary to stabilize first:**

- **BE (Business Enablement):** Blazor design surface, configuration editor, validation, authorized publication, workflow starts, operational timeline, audit/evidence views.
- **BOB shared core:** BPMN definition parser/validator, executable plan, token/state semantics, step execution and local activity dispatch; no UI, email, CyberArk code, or Kafka-specific code in the core.
- **BOB embedded host:** A capability can run approved local workflow definitions in-process against registered activities and local AMIE rules. No per-step central calls.
- **BOB central host:** Runs durable cross-capability processes, persists wait states to MSSQL, sends configured commands via the messaging adapter and correlates outcomes.
- **AMIE:** Existing configurable rule evaluation and transformations, executed locally in the relevant capability, or inside a service boundary appropriate to the rule. Reuse existing AMIE contracts where possible, do not start a duplicate AMIE implementation.
- **Capabilities:** Each capability owns its actions and data (e.g., CyberArk/PAM, Database/shared-data, Email, other CVIS operations). They register versioned, typed operations for the designer; the activity handlers live in these services.
- **Kafka:** Transports typed commands, events, outcomes. The BOB hosting/messaging adapter uses Kafka for asynchronous cross-service work. A capability may execute its internal BOB subflow entirely locally.
- **MSSQL:** Only database provider for BOB durable state. This choice does not force unrelated capabilities to use BOB storage or prevent direct EF Core for capability-owned data.
- **Audit/control layer:** Correlates changes and runs across BE, BOB, AMIE, Kafka, and capabilities. The actual Wells Fargo control/CA IDs and approval process are authoritative; this spec does not invent them.

### Logical sequence (one distributed workflow)

```mermaid
flowchart LR
  Human[Authorized BE user] --> Design[BE Blazor designer]
  Design --> Definition[Definition / validation API]
  Definition --> Sql[(MSSQL: versions / audit)]
  Definition -->|Publish approved version| Registry[Approved definition registry]
  Human --> Start[BE run / status API]
  Start --> Orchestrator[BOB central host]
  Registry --> Orchestrator
  Orchestrator -->|Typed command + correlation| Kafka[(Kafka)]
  Kafka --> Cap[Capability microservice]
  Cap --> LocalBOB[Embedded BOB runtime]
  LocalBOB --> LocalAMIE[Embedded AMIE runtime]
  LocalBOB --> Adapter[Capability-owned adapter]
  Adapter --> LocalBOB
  Cap -->|Outcome event| Kafka
  Kafka --> Orchestrator
  Orchestrator --> Sql
  Sql --> Status[BE run status / audit view]
  Orchestrator --> Status
```

Important: **The user draws and configures the workflow in BE. BE never executes it in the browser.** The published definition is compiled/validated server-side for BOB. The BE designer and BE monitor use the same BPMN diagram but different modes.

## 2. Designer: four connected BE surfaces

### A. Workflow library

Searchable tiles/table of workflow name, owning application, business purpose, tags, draft/approved/published versions, environments, owner, updated date and last run. Offer **Create**, **Duplicate**, **Open**, **View Versions**, **Run** (permission dependent), **Inspect Evidence**. Workload names are catalog metadata, not BOB engine code.

### B. Visual BPMN designer (primary investment)

**Layout:**

1. Global BE navigation: Design Library, Workflow Designer, Runs, Capabilities, Rules, Control/Audit.
2. Designer top bar: name, version, owner, environment, draft status, Save Draft, Validate, Publish (authorized only), Preview Run, Zoom-to-fit.
3. Left palette: limited, visibly labeled supported BPMN event/task/gateway shapes plus **Capability Task** and **AMIE Decision** templates; bindings still serialize into valid BPMN types + Unity extension metadata.
4. Center canvas: familiar BPMN shapes/flows, align/grid/snap, pan/zoom, selection, connection points, labels and route points. Display ownership boundaries with lanes or grouped frames once supported; do not confuse an embedded subflow with a cross-service request.
5. Right properties panel: selected item name/description; activity contract picker from capability registry; AMIE rule and pinned version; input/output mappings; retry/timeouts; message contract and correlation; security requirements; documentation.
6. Bottom drawer: validation errors/warnings (click to focus), execution test/preview output, version diff or audit timeline.

**Interactions required for credible demo:** add/select/move/delete supported elements; connect/disconnect sequential flows; edit properties; zoom/pan; undo/redo; save draft; validate supported BPMN semantics; see errors on actual nodes; publish an approved version; open a run on the same diagram with node statuses and a correlated timeline. It is preferable to build these reliably for a constrained vocabulary than to display dozens of elements that do not execute.

**Design quality:** 60fps-feeling canvas motion, stable geometry after refresh, clear typography, discoverable tools, keyboard actions, good selection/hover states, compact properties, clean empty/loading/error states and responsive side panels. Accessibility and keyboard alternatives must be planned; no claim of WCAG compliance without testing.

**Implementation note for Blazor:** Prefer SVG for the canvas and built-in Razor components for the shell, palette, properties and validation. Put high-frequency pan/drag transforms in a small **locally authored and reviewed JavaScript module**; commit model state to Blazor on pointer release or throttled checkpoints. Avoid invoking Blazor Server .NET logic on every pointer move. Do not require a new BPMN UI package pending bank approval. A previously approved commercial component can be substituted behind the canvas adapter later, without changing BOB contracts.

### C. Workflow operations / run inspector

A separate **Run** mode overlays the same BPMN nodes with status: Not Started, Ready, Running, Waiting (Kafka/human/timer), Completed, Failed, Skipped, Compensated. Click node -> show activity instance, exact binding/version, attempts, duration, sanitized inputs/outputs, correlated service events, resulting state, relevant control evidence. Timeline explains the cross-capability journey, not just the central BOB state.

### D. Control & audit review

Track author/edit/version/approver/publisher/environment, validation and release gates, workflow/rule versions, actor identity, service principal, correlation and trace identifiers, activity transitions, data handling classification, evidence links and failures. The bank's control and CA mapping **must be entered/reviewed by authorized stakeholders**, not guessed or embedded in JavaScript. Evidence must be server-authoritative and tamper-evident according to approved storage controls; client-only logs are not evidence.

## 3. BPMN representation and designer/server contract

### Canonical artifacts

- `*.bpmn`: BPMN 2.0 XML for the supported executable subset, including **BPMN DI** geometry for diagram round-tripping.
- **Unity extension metadata:** Versioned references (not credentials, arbitrary code, or secrets) to capability operations, AMIE rule sets, correlation contracts and execution policy. Retain unknown safe extensions on round-trip when feasible; reject unsupported executable semantics at validation.
- **Immutable publication snapshot:** Workflow key, revision/version, content hash, owning application, approved binding manifest, target environment, source author and publication/approval provenance.
- **Runtime execution plan:** Server-generated, validated internal model. Renderer and editor do not dictate runtime semantics.

### Core example contracts (illustrative signatures; align to existing code before adoption)

```csharp
public record WorkflowDraft(
    string WorkflowKey, string ApplicationKey, string DraftRevision,
    string BpmnXml, string? ETag);

public record CapabilityOperationDescriptor(
    string CapabilityKey, string OperationKey, string ContractVersion,
    string DisplayName, string? InputSchemaId, string? OutputSchemaId,
    string ExecutionMode); // Local | KafkaCommand | ApprovedApi

public record AmieRuleDescriptor(
    string RuleKey, string Version, string DisplayName,
    string? InputSchemaId, string? OutputSchemaId);

public record WorkflowValidationIssue(
    string ElementId, string Code, string Message, string Severity);

public interface IWorkflowDefinitionApi
{
    Task<WorkflowDraft> GetDraftAsync(string key, CancellationToken ct);
    Task<WorkflowDraft> SaveDraftAsync(WorkflowDraft draft, CancellationToken ct);
    Task<IReadOnlyList<WorkflowValidationIssue>> ValidateAsync(
        WorkflowDraft draft, CancellationToken ct);
    Task<string> RequestPublishAsync(string key, string revision, CancellationToken ct);
}
```

**Publication:** `RequestPublishAsync` requests an authorized workflow change. It **must not** silently bypass bank approval requirements. Only the approved publishing service writes immutable publication records. This contract is illustrative rather than a mandate to replace established interfaces.

### Property binding example

A BPMN Service Task might reference `capability=CyberArk`, `operation=GetAccount`, `contractVersion=1.0`, `executionMode=KafkaCommand` when BOB central dispatches it across services. Another task inside a CyberArk capability's embedded workflow may be `executionMode=Local` for the same capability-owned adapter. A BPMN Business Rule Task references `AMIE:AccountPolicyEvaluation@approved-version` instead of embedding business-specific logic in the BPMN XML.

**Do not let the designer accept arbitrary Kafka topics, arbitrary SQL or arbitrary executable C# strings.** Users select registered approved operations/rules/contracts, and validation checks them before publication.

## 4. Core designer workflows (behavior, not just screens)

### Author → validate → publish

1. Open template or new process; BE creates a draft with BPMN XML and DI.
2. Select nodes and bind approved capability operations / AMIE rule versions from registries.
3. Save draft to definition API with optimistic concurrency (`ETag` or equivalent) to avoid silent overwrites.
4. Server validates XSD/structure, start/end reachability, gateway flows, bindings, schema compatibility, permissions, unsupported elements, version pins and requested environment.
5. BE focuses erroneous nodes; cannot publish invalid process.
6. Request approval/publication; authorized control gateway applies Wells Fargo's actual gates.
7. Published definition becomes immutable; capabilities receive approved version by registry and cache where relevant. A running instance pins versions.

### Run → correlate → inspect

1. Authorized initiator starts a published workflow; BOB central creates a workflow instance and audit seed.
2. Local steps execute without remote per-step calls; cross-service steps publish Kafka requests with correlation and idempotency identifiers.
3. Capability consumer loads embedded BOB/AMIE approved definitions as needed, performs capability-owned operations, records sanitized audit and publishes a typed outcome.
4. BOB central correlates the outcome, resumes its durable wait state, advances the process and records a checkpoint in MSSQL.
5. BE run inspector shows node status and cross-service chronology; authorized operators can examine errors without access to sensitive payloads.

### Status categories and nonfunctional behavior

Server-side state is authoritative. BE may poll status at a bounded interval for the initial demo, switching to an approved push mechanism later. Canvas drag and status polling must not interfere. Published versions remain available for active runs. Message and activity retries require deduplication. Kafka/DB operations should use an outbox/inbox or equivalent reliability mechanism; do not claim exactly-once end-to-end effects for CyberArk/email.

## 5. Minimum BPMN subset for November (explicit, executable)

| BPMN element | Demo cut | Notes |
|---|---|---|
| Start event / end event | **Required** | Single start and simple end initially. |
| Service task | **Required** | Registered capability operation, local or cross-service. |
| Business rule task | **Required** | AMIE binding; result becomes workflow variable. |
| Exclusive gateway and conditional/default flows | **Required** | Deterministic routing; expression via approved AMIE result. |
| Send task / message catch or receive task | **Required if async demo** | Persist wait, correlate Kafka outcome and resume. |
| User task / approval | **Conditional** | Only if selected pilot requires it and authorized control gates exist. |
| Embedded subprocess / call activity | **Later or pilot-specific** | Reuse matters but avoid premature recursive scope. |
| Parallel gateway + joining | **Later or pilot-specific** | Correct join semantics are substantial. |
| Timer / boundary events | **Later or pilot-specific** | Requires durable scheduling and exact semantics. |
| Inclusive gateway, signals, compensation | **Later** | Do not display as executable until conformance tests exist. |
| Full BPMN 2.0 import/export parity | **Later** | Round-trip the authored subset first, never falsely claim full conformance. |

**Validation behavior:** unsupported executable BPMN constructs trigger an explicit error, never a no-op or a different process meaning. BPMN 2.0.2 reference: https://www.omg.org/spec/BPMN/2.0.2

## 6. Bank controls: minimum evidence envelope

Every meaningful state transition / business action should have a durable, correlated audit event with fields such as:

```text
EventId, OccurredAtUtc, Environment, ApplicationKey, WorkflowKey,
WorkflowVersion, WorkflowInstanceId, BPMNElementId, ActivityInstanceId,
Attempt, CapabilityKey, OperationKey, MessageId, CorrelationId, CausationId,
TraceId, SpanId, ActorIdOrServicePrincipal, RuleKey, RuleVersion,
ActionType, OutcomeCode, Status, ControlReference(s), EvidenceReference(s),
SanitizedContextDigest, FailureCategory
```

- Enforce authorization on **every backend** draft/publish/run/retry/approve/export endpoint, not just on BE navigation.
- Separate human actor from delegated service identity and keep attribution through Kafka headers.
- Don't log passwords, CyberArk secrets, tokens, PII, or unredacted PAM account material.
- Use bank-approved time sources, retention, audit storage controls and release processes; the actual CA/control taxonomy and evidence system remain to be mapped.
- Distinguish **application release readiness** from **production authorization**: an impressive DEV demo does not imply an approved deployment.

## 7. Sample configurable CVIS/PAM workloads (NOT platform hardcoding)

| Workload | Example bindings | First demonstration value | Risk |
|---|---|---|---|
| Hygiene / account inventory | Read CyberArk account metadata → AMIE hygiene evaluation → record issue/outcome | Shows configuration + read-only capability | Low if limited to approved metadata |
| Policy Drift | Read policy baseline and actual metadata → AMIE compare → drift event → email capability via Kafka | Strong cross-capability trace and compliance story | Medium; avoid unapproved remediation |
| Data enrichment (CMDB etc.) | Load source data → capability-owned mapping → AMIE transformations → account update | Good example of embedded BOB and AMIE composition | Higher due to writes; use mock/DEV scope |
| Onboarding / offboarding | Request/approval → authorized provisioning or revocation → status | Human tasks, security and audit | Higher; requires explicit control approval |
| Compliance attestations | Collect evidence → evaluate policy → route review | Audit lineage and BE tracking | Depends on bank control definitions |

**Recommendation:** use at least two **different** examples in the technical demonstration: (1) a read-only hygiene/policy evaluation, and (2) a process that crosses Kafka → Email Capability → event correlation. Reuse the same BOB Core, AMIE and BE; neither example should be compiled into those components. Exact business application pilots are not selected by this document.

## 8. Blazor implementation slices and proposed file boundaries

These are **proposed** paths only; reconcile with actual solution, component naming and existing AMIE code.

```text
/Unity.BE/Pages/Workflows/WorkflowLibrary.razor
/Unity.BE/Pages/Workflows/WorkflowDesignerPage.razor
/Unity.BE/Pages/Workflows/WorkflowRunPage.razor
/Unity.BE/Components/WorkflowDesigner/WorkflowCanvas.razor
/Unity.BE/Components/WorkflowDesigner/ActivityPalette.razor
/Unity.BE/Components/WorkflowDesigner/PropertiesInspector.razor
/Unity.BE/Components/WorkflowDesigner/ValidationDrawer.razor
/Unity.BE/Components/WorkflowDesigner/ExecutionOverlay.razor
/Unity.BE/Components/WorkflowDesigner/WorkflowCanvas.razor.css
/Unity.BE/wwwroot/js/workflow-canvas.js
/Unity.BE/Services/IWorkflowDesignerApi.cs
/Unity.BE/Services/IWorkflowRunApi.cs
/Unity.Bob.Contracts/WorkflowDefinitions/WorkflowDraft.cs
/Unity.Bob.Contracts/WorkflowDefinitions/WorkflowValidationIssue.cs
/Unity.Bob.Contracts/Capabilities/CapabilityOperationDescriptor.cs
/Unity.Bob.Core/Bpmn/BpmnDefinitionValidator.cs
/Unity.Bob.Core/Execution/WorkflowExecutor.cs
/Unity.Bob.Embedded/Execution/EmbeddedWorkflowHost.cs
/Unity.Bob.Service/Execution/DistributedWorkflowHost.cs
/Unity.Bob.Persistence.SqlServer/WorkflowPersistence.cs
/Unity.Audit/Contracts/WorkflowAuditEnvelope.cs
```

**Performance:** Canvas interaction owned by the browser for pointer-frequency events, server synchronization only on meaningful model changes; server-side BPMN validation and persistence. For interactive server render mode, JS interop crosses the network and should not process each drag frame. Microsoft reference: https://learn.microsoft.com/en-us/aspnet/core/blazor/performance/rendering?view=aspnetcore-10.0

## 9. Narrow implementation sequence for Devin

**Day 0–1, freeze interfaces:** Map existing Unity/AMIE code and approved UI/runtime dependencies. Agree on BPMN subset, capability descriptor schema, AMIE rule invocation, Kafka envelope, audit event envelope, version strategy. No duplicate AMIE implementation.

**Day 1–3, split parallel work:** BOB core parsing/semantic validation; BE canvas/inspector; capability and AMIE registry adapter; MSSQL definition/run store; Kafka and audit envelopes. One owner per contract.

**Day 4–7, vertical slice:** BE creates diagram → validates → publishes to DEV under approved local process → BOB starts run → one capability executes local BOB/AMIE → result visible in BE, evidence persisted. Use fake adapters first.

**Day 8–12, platform boundary:** Add second capability via Kafka (Email) with mock/approved transport; persist durable message wait/outcome correlation; drill down audit timeline.

**Day 13–17, CVIS pilots:** Connect at least one read-only CyberArk/PAM use case, with a second workload dependent on readiness and authorized access. Real writes require specific approvals, not just demo enthusiasm.

**Day 18–20, stabilization and review preparation:** Cross-service retries, restart recovery, access-control checks, status accuracy, documentation, automated tests, controls/evidence mapping. Freeze new UI features, demo only measured and tested behavior.

Target: Nov 30, 2026. Dates are planning targets, not delivery or approval guarantees.

### Acceptance milestones (real, falsifiable)

1. Two unrelated valid BPMN definitions authored in BE run through the **same** BOB engine.
2. Invalid/unsupported BPMN visibly fails validation with node-specific errors.
3. A capability runs a local rule/workflow with central BOB/AMIE endpoints unavailable after obtaining approved definitions.
4. A central workflow successfully parks, receives a correlated Kafka completion, and resumes after a host restart.
5. BE shows workflow definition version, AMIE version, BOB transition history, capability outcome, initiator identity and audit timeline.
6. A second capability (Email) receives a typed request and records a correlated outcome without code added to BOB Core.
7. Workflow definition cannot be published/operated by an unauthorized user via direct HTTP API.
8. Supported BPMN DI geometry survives save/refresh/reopen without moving nodes.

## 10. Known unknowns / integration checks

- Existing repository structure, current BOB state and actual AMIE public interfaces have not been inspected here.
- Blazor render mode (Interactive Server, WebAssembly, Auto) is unknown; canvas transport strategy must be selected accordingly.
- Approved paid/third-party design packages are unknown; **do not introduce any new dependency** assuming approval.
- Bank-specific CA controls, control identifiers, release artifacts and approvers must be supplied/confirmed by the bank.
- Kafka topics, message versions, secret handling, CyberArk endpoints and service identities must be reconciled with existing enterprise standards.
- Detailed BPMN execution and durable persistence need tests; a visual editor demo alone cannot validate engine correctness.

## 11. Reference lessons (feature inventory, not code reuse)

The uploaded OptimaJet reference exhibits a mature split of core workflow API, persistence provider, BPMN plugin, designer API, approvals, forms and real-time tracking. It includes examples of `WorkflowRuntime`, `ProcessDefinition`, `ProcessInstance`, `IWorkflowActionProvider`, `IPersistenceProvider`, BPMN import/visitor structures, `MSSQLProvider` and versioned form/approval abstractions. **These are useful feature prompts for our roadmap, but they are not Unity contracts and do not automatically prove BPMN conformance.**

- OptimaJet Core API: https://api.workflowengine.io/core/
- OptimaJet BPMN API: https://api.workflowengine.io/bpmn-plugin/
- OptimaJet MSSQL API: https://api.workflowengine.io/sql-server/
- OptimaJet real-time tracking API: https://api.workflowengine.io/realtime-tracking-plugin/
- BPMN 2.0.2: https://www.omg.org/spec/BPMN/2.0.2
- Microsoft Blazor rendering guidance: https://learn.microsoft.com/en-us/aspnet/core/blazor/performance/rendering?view=aspnetcore-10.0

## 12. Status of decisions

**User-established:** Unity platform/workload separation; BE in Blazor; visual designer is essential; BOB+AMIE support central and embedded execution; configuration-first rules/workflows; capabilities own integrations and may use direct EF for owned data; Kafka is cross-service bus; email through Email Capability, not BOB; MSSQL-only for workflow persistence; substantial AMIE code already exists; November 30 MVP/demo target; avoid new unapproved libraries.

**Proposed for merge/confirmation:** SVG/Blazor native canvas with small locally authored JS module; initial BPMN executable subset; separate designer/operations modes; registry descriptor shapes; versioned Unity extension bindings; precise audit event fields; candidate pilot order and Devin work order.

**Not asserted:** Complete BPMN support, Wells Fargo regulatory compliance, production approval, compilation/testing of these proposed interfaces, or availability of any unreviewed dependency.

**Next engineering handoff:** inventory the actual Unity solution and existing AMIE implementation; sign off Day-0 contracts; then parallelize work. This design record must not silently replace existing code/contracts.
