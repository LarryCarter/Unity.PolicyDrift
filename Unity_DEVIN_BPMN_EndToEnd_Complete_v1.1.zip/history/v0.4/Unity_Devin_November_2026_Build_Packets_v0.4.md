# UNITY / NOVEMBER 30 — DEVIN Build Work Packets v0.4

**Planning reference.** No coding has been started by this artifact. Interface names/project paths are proposed and must be reconciled with the actual repository.

## Global instructions for all DEVIN tasks

Build original, independently authored .NET 10 C# code. Follow common contracts from D00. Do not copy OptimaJet proprietary implementation; use documented features only as requirements evidence. BOB is generic BPMN execution shared between embedded and central hosts. AMIE rules execute locally in capabilities from versioned approved configuration. BE is the UI for design and status. Capabilities own integrations, email is an Email Capability driven by Kafka and local AMIE policy. Use only MSSQL for BOB persistence; do not introduce other workflow database providers. Preserve every service boundary. Instrument audit and trace context. Do not hide unsupported BPMN elements or invent Wells Fargo controls/CAs. Provide tests and documentation for every task. All environment access and production actions require authorized owners.

## Dependency order

D00 and DEV infrastructure D16 first. Then D01, D03, D05, D07, D08 can proceed in parallel against frozen contracts. D04, D06, D09, D10 connect those streams. D12 demonstrates the first real pilot; D13 remains a stretch. D14/D15 gate claims of readiness.

### D00 — Freeze shared typed interfaces and canonical event/audit envelopes

**Target:** Nov 11  |  **Dependency:** None  |  **Gate:** MUST  |  **Owner:** Platform lead / Devin

**Proposed paths:** `/Unity.Contracts/Contracts/* (proposed)`

**Devin instruction:** Implement freeze shared typed interfaces and canonical event/audit envelopes as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Contracts compile and sample payloads validate; no two teams define conflicting schemas.

**Non-negotiable constraints:** Envelope, BPMN supported subset and control mapping.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D01 — Minimal BPMN XML parser/validator/token execution engine

**Target:** Nov 16  |  **Dependency:** D00  |  **Gate:** MUST  |  **Owner:** Devin — BOB core

**Proposed paths:** `/Unity.Bob.Core/ (proposed)`

**Devin instruction:** Implement minimal bpmn xml parser/validator/token execution engine as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Accept start/end/service/exclusive and rule tasks; reject unsupported; conformance fixture tests.

**Non-negotiable constraints:** No OptimaJet source copying; no direct SMTP/Kafka or business-app logic.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D02 — BOB SDK, DI activity registry and local handler execution

**Target:** Nov 17  |  **Dependency:** D00,D01  |  **Gate:** MUST  |  **Owner:** Devin — embedded

**Proposed paths:** `/Unity.Bob.Embedded/ (proposed)`

**Devin instruction:** Implement bob sdk, di activity registry and local handler execution as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Local activity executes with central BOB unavailable; two unrelated adapters resolve by contract.

**Non-negotiable constraints:** No remote per-step callback; no cross-capability private DB.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D03 — Approved rule version cache and embedded deterministic evaluation

**Target:** Nov 17  |  **Dependency:** D00  |  **Gate:** MUST  |  **Owner:** Devin — AMIE

**Proposed paths:** `/Unity.Amie.Embedded/ (proposed)`

**Devin instruction:** Implement approved rule version cache and embedded deterministic evaluation as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Change rule configuration without rebuild; same pinned version available offline.

**Non-negotiable constraints:** No arbitrary C# eval; bounded rule interpreter; local execution.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D04 — Small orchestration API and Kafka outcome correlation

**Target:** Nov 20  |  **Dependency:** D00,D01,D05,D07  |  **Gate:** MUST  |  **Owner:** Devin — orchestration

**Proposed paths:** `/Unity.Bob.Service/ (proposed)`

**Devin instruction:** Implement small orchestration api and kafka outcome correlation as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Start/advance one durable process and correlate notification outcome after restart.

**Non-negotiable constraints:** Single DEV instance allowed initially; no false HA claims.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D05 — Definition versions, checkpoints, optimistic concurrency and history

**Target:** Nov 18  |  **Dependency:** D00,D01  |  **Gate:** MUST  |  **Owner:** Devin — persistence

**Proposed paths:** `/Unity.Bob.Persistence.SqlServer/ (proposed)`

**Devin instruction:** Implement definition versions, checkpoints, optimistic concurrency and history as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Restart and resume process; in-flight V1 pinned after V2 published.

**Non-negotiable constraints:** MSSQL only; never private application databases.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D06 — Draft, validate, publish, approve and cache workflow/AMIE definitions

**Target:** Nov 19  |  **Dependency:** D00,D01,D03  |  **Gate:** MUST  |  **Owner:** Devin — registry

**Proposed paths:** `/Unity.Definitions/ (proposed)`

**Devin instruction:** Implement draft, validate, publish, approve and cache workflow/amie definitions as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Invalid BPMN rejected; author/approver and immutable version traceable.

**Non-negotiable constraints:** Bank control gates and production publish rules need validation.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D07 — Typed request/outcome + Kafka consumer + AMIE email policy + dedupe

**Target:** Nov 20  |  **Dependency:** D00,D03  |  **Gate:** MUST  |  **Owner:** Devin — email integration

**Proposed paths:** `/Unity.Capabilities.Email/ (proposed)`

**Devin instruction:** Implement typed request/outcome + kafka consumer + amie email policy + dedupe as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Rule selects approved template, mail submission event correlated; duplicate request safe.

**Non-negotiable constraints:** Email provider sanctioned or mock in DEV; BOB Core never sends email.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D08 — Embed reviewed BPMN web modeler; constrained palette, import/export and publish

**Target:** Nov 20  |  **Dependency:** D00,D06  |  **Gate:** MUST  |  **Owner:** Devin — BE UX

**Proposed paths:** `/Unity.BE/Components/WorkflowDesigner/ (proposed)`

**Devin instruction:** Implement embed reviewed bpmn web modeler; constrained palette, import/export and publish as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** User creates/drafts/publishes supported BPMN; unsupported elements blocked by server.

**Non-negotiable constraints:** Use bpmn-js if approved; fallback XML upload/viewer if blocked.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D09 — Workflow start, status, cross-capability timeline and exception viewing

**Target:** Nov 21  |  **Dependency:** D00,D04,D10  |  **Gate:** MUST  |  **Owner:** Devin — BE ops

**Proposed paths:** `/Unity.BE/Components/WorkflowOperations/ (proposed)`

**Devin instruction:** Implement workflow start, status, cross-capability timeline and exception viewing as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** One process shows activity, AMIE decision, Kafka/email outcome and error status.

**Non-negotiable constraints:** Backend auth enforced; no unrestricted audit export.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D10 — Unified trace, SQL audit history, rule/definition provenance and redaction

**Target:** Nov 21  |  **Dependency:** D00,D05,D07  |  **Gate:** MUST  |  **Owner:** Devin — observability

**Proposed paths:** `/Unity.Audit/ (proposed)`

**Devin instruction:** Implement unified trace, sql audit history, rule/definition provenance and redaction as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Single correlation chain reconstructs who/what/when/version/outcome after restart.

**Non-negotiable constraints:** Metadata-only by default; bank retention and CAs are unresolved.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D11 — SSO/role authorization, secrets policy and control/CA evidence mapping

**Target:** Nov 24  |  **Dependency:** D00  |  **Gate:** RELEASE  |  **Owner:** Bank controls owner + Devin

**Proposed paths:** `/Unity.Security/ and release evidence (proposed)`

**Devin instruction:** Implement sso/role authorization, secrets policy and control/ca evidence mapping as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Backend permission denial, provenance and approved control evidence; unresolved gates flagged.

**Non-negotiable constraints:** Internal bank SSO, CA IDs and approvals required; no invented compliance.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D12 — First real application integration; configured BPMN+AMIE+capability adapter

**Target:** Nov 25  |  **Dependency:** D02,D03,D04,D07,D08  |  **Gate:** MUST  |  **Owner:** Pilot A team + Devin

**Proposed paths:** `/Unity.Pilots/AppA/ (placeholder)`

**Devin instruction:** Implement first real application integration; configured bpmn+amie+capability adapter as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** One real pilot completes from BE with visible trace and negative-path test.

**Non-negotiable constraints:** Select actual app immediately; no custom engine branch.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D13 — Second independent real app integration if readiness allows

**Target:** Nov 27  |  **Dependency:** D12,D02  |  **Gate:** STRETCH  |  **Owner:** Pilot B team + Devin

**Proposed paths:** `/Unity.Pilots/AppB/ (placeholder)`

**Devin instruction:** Implement second independent real app integration if readiness allows as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Second application demonstrates unchanged engine and its own adapter/rules.

**Non-negotiable constraints:** Do not block App A on App B.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D14 — Contract, BPMN subset, duplicate, restart, authorization and failure tests

**Target:** Nov 28  |  **Dependency:** D01,D04,D07,D09,D10  |  **Gate:** MUST  |  **Owner:** Devin — QA

**Proposed paths:** `/Unity.Tests/ (proposed)`

**Devin instruction:** Implement contract, bpmn subset, duplicate, restart, authorization and failure tests as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** End-to-end suite reproducibly passes in DEV; open failures explicit.

**Non-negotiable constraints:** Tests gate claims; a green UI alone is not evidence.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D15 — CI/CD, security scan, change evidence, app demo and go/no-go

**Target:** Nov 30  |  **Dependency:** D11,D12,D14  |  **Gate:** RELEASE  |  **Owner:** Release owner / Devin

**Proposed paths:** `/Unity.Deployment/ (proposed)`

**Devin instruction:** Implement ci/cd, security scan, change evidence, app demo and go/no-go as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** Build/provenance + control evidence + app A demo; bank sign-off for production.

**Non-negotiable constraints:** No automatic production release based on successful demo.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

### D16 — Repeatable SQL/Kafka/service deployment, health probes, config injection

**Target:** Nov 17  |  **Dependency:** D00  |  **Gate:** MUST  |  **Owner:** Devin — DevOps

**Proposed paths:** `/Unity.Deployment/Dev/ (proposed)`

**Devin instruction:** Implement repeatable sql/kafka/service deployment, health probes, config injection as an independently testable Unity component. Respect the shared contracts and component ownership rules. Produce a deterministic build/test path. Keep changes scoped to the proposed project or an architecture-owner-approved replacement; do not alter unrelated repositories. Include security and telemetry acceptance tests.

**Required acceptance:** BE + BOB + email + audit endpoints deploy with health and test configuration.

**Non-negotiable constraints:** Use existing sanctioned bank infrastructure; no new shadow systems.

**Deliverables:** source files with full `/Project/Folder/File.cs` paths, tests, configuration sample without credentials, API/message contract notes, commands to build/test, and a Files and Structure Summary (New/Updated/Deleted/No Change).

## Architecture and rollout acceptance checklist

- [ ] Shared contracts frozen and owned by D00; contracts compile in all services.
- [ ] Executable BPMN subset declared; unsupported shapes rejected.
- [ ] BE can author, publish, start and view a workflow.
- [ ] Embedded AMIE / BOB works without remote per-step central calls.
- [ ] BOB central stores checkpoints in MSSQL; safe recovery shown.
- [ ] Kafka Email Capability consumes and applies AMIE rule locally, emits outcome.
- [ ] Common trace and audit envelope spans every service.
- [ ] Identity, secrets, approvals and bank CAs mapped to actual owner input.
- [ ] One selected real app (Pilot A) works end to end.
- [ ] Second app only if ready; no forced engine-specific changes.
- [ ] DEV demo and bank release approval are recorded as separate outcomes.

≛ Contollo ≛
