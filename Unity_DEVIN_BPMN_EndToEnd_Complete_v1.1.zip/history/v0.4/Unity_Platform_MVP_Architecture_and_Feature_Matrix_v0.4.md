# Unity Platform — Feature Gap Matrix & November 30 MVP Plan (v0.4)

**Date:** 2026-11-10  |  **Deadline:** 2026-11-30  |  **Status:** Planning baseline, not implemented or bank-approved

> **Foundational boundary:** BOB and AMIE are generic runtimes. Business Enablement Website (BE) is the workflow designer, operations and audit interface. Capabilities own integrations and their data. Kafka moves cross-service events and commands. MSSQL is the sole BOB workflow persistence backend. Workload-specific processes are configuration, not engine code.

## 1. What changed from v0.3

- Corrected missing BE scope: constrained BPMN authoring, versioned publication, workflow initiation, status and cross-service progress.
- Added Email Capability: BOB emits Kafka requests; the Email microservice applies **local AMIE rules**, sends through an enterprise-approved adapter and publishes outcomes. No direct mail sender in BOB.
- Made audit/traceability, role-scoped operations, release evidence, bank controls and **CAs** explicit. Internal control IDs and the meaning/mapping of CAs have not been supplied; they cannot be invented.
- Added November 30 implementation cut line and parallel DEVIN work packets. Important long-term core features are not assumed to be needed for this demo.
- Preserved separation: CMDB, Policy Drift, legacy modernization and pilots are workloads, not platform internals.
- Kept MSSQL-only BOB persistence while preserving EF Core direct access for data owned by an individual capability.

## 2. November architecture diagram

```mermaid
flowchart TB
  BE["Business Enablement Website\nBPMN designer • publish • start • status • audit"]
  REG["Approved definition registry\nBOB BPMN + AMIE rule sets"]
  CENT["BOB Central Host\nDurable orchestration"]
  SQL["MSSQL\nVersions • checkpoints • inbox/outbox • audit"]
  KAFKA["Kafka\nVersioned commands and outcomes"]
  CAP["Application Capabilities\nEmbedded BOB + Embedded AMIE + adapters"]
  MAIL["Email Capability\nKafka consumer + local AMIE + mail provider"]
  AUDAPI["Authorized audit query API"]
  BE <--> REG
  BE <--> CENT
  BE --> AUDAPI
  AUDAPI --> SQL
  REG -. "Approved packages / cached rules" .-> CAP
  REG -. "Approved package" .-> MAIL
  CENT <--> SQL
  CENT <--> KAFKA
  KAFKA <--> CAP
  KAFKA <--> MAIL
```

**Diagram caveat:** BE reads process/audit data through authorized APIs, not direct SQL connections. Dotted lines represent independently refreshed definitions; cache refresh is not in the per-request execution path. All message/result flows use standardized correlation and version metadata.

## 3. Constrained end-of-month implementation

| Capability | Build by Nov 30 | Defer until required |
| --- | --- | --- |
| **CORE — BOB interpreter and dual hosts** | BPMN subset: start/end, service task, XOR, AMIE rule task, correlated message wait. | No full BPMN conformance; reject unsupported constructs. |
| **RULES — AMIE configuration-first runtime** | Approved versioned rules evaluated locally; no per-rule remote calls. | Full DMN engine and designer deferred. |
| **DATA — MSSQL durable process state** | Definition versions, checkpoint, history, optimistic concurrency, inbox/outbox. | Multi-node HA/complex migration deferred. |
| **BUS — Kafka event backbone** | Typed requests/outcomes and correlation; sanctioned topics. | Generic connector marketplace and custom event UI deferred. |
| **MAIL — Email microservice** | AMIE decides notification policy; Kafka request; provider adapter; outcome event. | BOB bundled mail sender excluded. |
| **BE — Workflow design and live visibility** | BPMN editor subset, draft/publish, start, status, cross-service timeline. | Full forms, advanced workflow designer, simulation deferred. |
| **AUDIT — Compliance by design** | Actor, versions, decision, trace, attempts, approval, sensitive-data redaction. | No fabricated bank control IDs or compliance signoff. |
| **APP A — First real application** | Real app configured to platform BPMN/AMIE/adapter contracts. | App business details are not BOB features. |
| **APP B — Second real application** | Independent application with distinct activities and/or rules. | Must not delay Pilot A. |
| **OPS — DEV deployment and CI checks** | Reproducible DEV build, service probes, fault tests, scan/approval checkpoints. | Full HA, autoscale, extensive analytics deferred. |

**Feasibility warning:** Building full BPMN semantics, a new secure orchestration system, complete BE, Kafka reliability, and two bank-approved applications from scratch in roughly 20 days is high risk. The dates are targets, not a verified schedule. The cut line is an executable *subset* with real evidence; applications that need unsupported BPMN constructs cannot be silently simulated.

## 4. What an email request looks like

1. BE starts an approved BPMN definition on BOB Central. The process is assigned an ID, definition version, initiator and correlation ID.
2. A service task produces a versioned `notification.email.requested.v1` command through the sanctioned Kafka path with a stable idempotency key and rule/template references.
3. The independent Email Capability consumes the command, checks the inbox/idempotency key, and executes the approved AMIE email policy **locally** to determine eligibility and the selected template.
4. The Email Capability invokes a sanctioned mail transport adapter, records submission result and publishes `notification.email.submitted.v1` or `.failed.v1` with the original process correlation.
5. BOB correlates the outcome to its waiting process state and advances or fails according to configured BPMN and AMIE behavior. BE displays the result with auditable transitions.
6. **Submission is not mailbox delivery.** Only claim recipient delivery if a provider supplies separate verified delivery evidence.

## 5. Bank audit, traceability, controls and CAs

**Do not claim regulatory compliance without approved bank mapping.** The user identified Wells Fargo controls and CAs, but the internal control catalog, thresholds, retention, approval workflow and official CA definitions have not been provided. The following is a technical evidence plan—not a bank attestation.

An audit envelope should capture at minimum: `eventId`, `correlationId`, `causationId`, `processInstanceId`, `workflowDefinitionId`, `workflowVersion`, `amieRuleSetId`, `amieRuleVersion`, `activityId`, `capabilityId`, `actorRef`, `action`, `outcome`, `timestampUtc`, `traceparent` (as trace propagation), and a control/change reference when supplied. Version identifiers should be hashes or immutable keys if configured. Avoid placing secrets or raw sensitive payloads in Kafka or general-purpose logs.

**Regulatory release gate:** authorized sign-in and service identities; least privilege and segregation of duties as mandated; published-definition approvals; tamper-resistant or otherwise sanctioned audit retention; secret management; security/SCA scans; change records; recoverability; explicit bank control/CA review. A successful DEV demo **does not** grant production release permission.

## 6. Dated implementation sequence

| Target window | Workstream | Required proof |
| --- | --- | --- |
| Nov 10-11: freeze contracts | Ratify platform boundaries, BPMN subset, common envelope, two pilot owners, bank control/CAs list, sanctioned deps. | Signed architecture/interfaces, executable fixtures, scoped Devin work packets, access risks assigned. |
| Nov 12-16: parallel component skeletons | Shared BOB core, AMIE local rules, BE design shell, SQL checkpoint, Kafka contracts, email service, release infra. | Builds, unit tests, deployable DEV services, restricted BPMN import/draft, no hidden cross-DB calls. |
| Nov 17-21: integrate vertical path | End-to-end BE -> BOB -> AMIE -> Kafka -> Email Capability -> status/audit; Pilot A adapter starts. | Successful synthetic process, email submit outcome, correlation trace, controlled failure path in DEV. |
| Nov 22-25: pilot and control proof | Complete Pilot A; conditional Pilot B; audit/control evidence; negative tests and restart/duplicate event tests. | One real pilot demonstrates configured process; second only if ready; bank control gaps explicit. |
| Nov 26-30: release candidate / demo | Security scans, SSO/RBAC validation, reviewer signoffs, deployment package, demo rehearsal, go/no-go. | Demo of integrated Unity with 1-2 pilots; release conditional on bank control owner approval. |
| After Nov: advanced BPMN | Parallel/inclusive gateway coverage, timers, human tasks, multi-instance, compensation as priorities require. | Each added BPMN element passes conformance and restart safety checks. |
| After Nov: full BE and ops | Richer forms, business calendars, visual incident tracing, advanced version migration and simulation. | Approved, tested feature release based on actual workload demand. |
| After Nov: scale and resilience | Multi-worker orchestration, lease fencing, HA, throughput SLOs, extended audit export and retention. | Reliability/DR/load/CA validation targets agreed and measured. |

## 7. Architecture invariants (source: existing Unity discussion)

- **ARC-01 — One engine, two hosts (Established):** Shared BOB core executes same supported BPMN IR embedded and centrally. **Proof:** Compare conformance fixtures in both hosts.
- **ARC-02 — Embedded execution is local (Established):** No mandatory BOB or AMIE network call per local activity or rule. **Proof:** An approved local workflow executes with central BOB / AMIE registry unavailable.
- **ARC-03 — Central services govern definitions (Established):** Central service manages rule/workflow publication, versions and approvals. **Proof:** Only approved definitions can be activated.
- **ARC-04 — AMIE owns business decisions (Established):** BOB delegates business rule evaluation, mapping and validation to cached AMIE rules. **Proof:** Change the output of a business decision via AMIE configuration without embedding the rule in BOB.
- **ARC-05 — BOB owns control flow (Established):** BOB handles BPMN tasks, tokens, events, timers, state and orchestration. **Proof:** AMIE rule invocation does not own task scheduling.
- **ARC-06 — Kafka owns transport (Established):** Cross-capability async messages use contracts; BPMN controls correlation. **Proof:** No private cross-service database queries.
- **ARC-07 — Only MSSQL for BOB persistence (Established):** Exclude other persistence-provider code; preserve clean core/provider separation. **Proof:** Dependency report contains only MSSQL provider.
- **ARC-08 — Capability data ownership (Established):** Direct EF Core is allowed in owning capability; shared data accessed via owner API. **Proof:** Data ownership test verifies no private DB bypass.
- **ARC-09 — Capability adapter execution (Established):** Registered C# activities live with owning capability, not in central orchestration. **Proof:** Each adapter executes only inside the capability that owns the operation.
- **ARC-10 — Business Enablement Website is UI (Established):** Business Enablement Website (BE) owns workflow authoring, initiation, operational monitoring, intervention and task UI; the BOB runtime does not implement the user-facing application. **Proof:** BOB REST only exposes scoped management/operations.
- **ARC-11 — Definition and rule version pinning (Established):** Running instance uses immutable BOB and AMIE versions. **Proof:** V1 instance retains behavior after V2 publishes.
- **ARC-12 — No silent BPMN degradation (Proposed safeguard):** Unsupported elements cause rejection, never auto-transitions or inert shapes. **Proof:** Importer negative-fixture suite.
- **ARC-13 — No arbitrary code as configuration (Established constraint):** Use approved typed activities and constrained AMIE expressions; no general C# compilation. **Proof:** Adversarial BPMN cannot access arbitrary files/commands.
- **ARC-14 — Durability matched to execution (Proposed):** Short embedded work can remain in memory; persistent waits require durable storage. **Proof:** Timer task rejects memory-only execution mode.
- **ARC-15 — Use reference as feature evidence (Established approach):** API types and vendor plugin behavior inform design; not evidence of Unity implementation. **Proof:** Each matrix row has source and acceptance criteria.
- **ARC-16 — BPMN is canonical process language (Proposed):** Target OMG BPMN 2.0.2 supported executable subset with conformance statement. **Proof:** Publication includes supported elements and tested semantics.
- **ARC-17 — No distributed shared SQL transaction (Established principle):** Cross-service reliability uses outbox, dedupe and compensation where needed. **Proof:** Failure-injection end-to-end tests.
- **ARC-18 — Avoid instance explosion (Proposed):** Batch orchestration and local row processing chosen on benchmarking. **Proof:** Workload test shows DB pressure under target.
- **ARC-19 — License/code independence (Established constraint):** OptimaJet is a product/API design reference, not a code source. **Proof:** Provenance review before integrating any third-party library.
- **ARC-20 — Platform / workload separation (Established user direction):** CMDB enrichment, Policy Drift and modernized legacy applications are independently configured Unity workloads, not platform engine features. BOB and AMIE stay reusable and application-agnostic. **Proof:** Two unrelated applications execute through the same unchanged engine and separate definitions.
- **ARC-21 — BE is the unified workflow UI (Established user direction):** Business Enablement Website provides BPMN design, status, initiation, and operations across BOB/AMIE/capabilities; BOB remains an engine. **Proof:** Designer creates a valid process; status view displays cross-capability execution.
- **ARC-22 — Email belongs to a capability (Established user direction):** BOB creates Kafka commands/events; Email Capability consumes, evaluates cached AMIE policy, sends through approved provider and emits outcomes. **Proof:** Email transport package is absent from BOB core; end-to-end notification is correlated.
- **ARC-23 — No per-step central execution tax (Established user direction):** Capability-local BOB/AMIE runtimes perform local work; central BOB coordinates durable cross-capability workflows. **Proof:** Local process completes during central AMIE registry outage.
- **ARC-24 — Bank control evidence is a core design input (Established user direction):** Every workflow change, decision, command, actor, service outcome and version should be traceable with control evidence. Bank control/CAs mapping needs owners. **Proof:** Audit/control matrix links required evidence to bank control owner and review disposition.
- **ARC-25 — November 30 is delivery cut line (Established user direction):** Prioritize a demonstrable, integrated Unity platform with one mandatory pilot and a second stretch pilot; defer advanced platform features. **Proof:** Nov 30 acceptance gates pass without claiming unapproved bank production release.
- **ARC-26 — Controlled BPMN editor in BE (Proposed implementation):** Use a reusable BPMN modeler to publish only the subset the BOB runtime correctly supports; full editor functionality may come later. **Proof:** Invalid/unsupported BPMN cannot be published; valid workflow round-trips.
- **ARC-27 — Compliance evidence is not regulatory certification (Proposed safeguard):** Provide evidence and enforce release gates, but bank control owners must decide whether controls and CAs are satisfied. **Proof:** Release state remains pending when bank control IDs or approvals are missing.
- **ARC-28 — One end-to-end correlation contract (Proposed contract):** Carry correlation/causation/process/definition/rule version/actor/outcome provenance across BE, BOB, AMIE, Kafka and capability. **Proof:** One process is explainable end to end without joining on private data.
- **ARC-29 — Independent configurable workload integration (Established direction):** Pilot A/B are selected application configurations, not baked into BOB, AMIE or BE. **Proof:** A second app integrates without editing generic engine or Email Capability.

## 8. DEVIN work packet overview

| Packet | Workstream | Target | Acceptance |
| --- | --- | --- | --- |
| **D00** | Freeze shared typed interfaces and canonical event/audit envelopes | Nov 11 | Contracts compile and sample payloads validate; no two teams define conflicting schemas. |
| **D01** | Minimal BPMN XML parser/validator/token execution engine | Nov 16 | Accept start/end/service/exclusive and rule tasks; reject unsupported; conformance fixture tests. |
| **D02** | BOB SDK, DI activity registry and local handler execution | Nov 17 | Local activity executes with central BOB unavailable; two unrelated adapters resolve by contract. |
| **D03** | Approved rule version cache and embedded deterministic evaluation | Nov 17 | Change rule configuration without rebuild; same pinned version available offline. |
| **D04** | Small orchestration API and Kafka outcome correlation | Nov 20 | Start/advance one durable process and correlate notification outcome after restart. |
| **D05** | Definition versions, checkpoints, optimistic concurrency and history | Nov 18 | Restart and resume process; in-flight V1 pinned after V2 published. |
| **D06** | Draft, validate, publish, approve and cache workflow/AMIE definitions | Nov 19 | Invalid BPMN rejected; author/approver and immutable version traceable. |
| **D07** | Typed request/outcome + Kafka consumer + AMIE email policy + dedupe | Nov 20 | Rule selects approved template, mail submission event correlated; duplicate request safe. |
| **D08** | Embed reviewed BPMN web modeler; constrained palette, import/export and publish | Nov 20 | User creates/drafts/publishes supported BPMN; unsupported elements blocked by server. |
| **D09** | Workflow start, status, cross-capability timeline and exception viewing | Nov 21 | One process shows activity, AMIE decision, Kafka/email outcome and error status. |
| **D10** | Unified trace, SQL audit history, rule/definition provenance and redaction | Nov 21 | Single correlation chain reconstructs who/what/when/version/outcome after restart. |
| **D11** | SSO/role authorization, secrets policy and control/CA evidence mapping | Nov 24 | Backend permission denial, provenance and approved control evidence; unresolved gates flagged. |
| **D12** | First real application integration; configured BPMN+AMIE+capability adapter | Nov 25 | One real pilot completes from BE with visible trace and negative-path test. |
| **D13** | Second independent real app integration if readiness allows | Nov 27 | Second application demonstrates unchanged engine and its own adapter/rules. |
| **D14** | Contract, BPMN subset, duplicate, restart, authorization and failure tests | Nov 28 | End-to-end suite reproducibly passes in DEV; open failures explicit. |
| **D15** | CI/CD, security scan, change evidence, app demo and go/no-go | Nov 30 | Build/provenance + control evidence + app A demo; bank sign-off for production. |
| **D16** | Repeatable SQL/Kafka/service deployment, health probes, config injection | Nov 17 | BE + BOB + email + audit endpoints deploy with health and test configuration. |

## 9. End-to-end demo checkpoints

- **DEMO-01 — Preflight:** BE, BOB central, embedded SDK sample, AMIE cache, Kafka, MSSQL and Email healthy **Pass:** Health and deployment data recorded
- **DEMO-02 — Design:** In BE create workflow using supported BPMN palette, save draft and show XML round-trip **Pass:** Valid BPMN imported/saved; unsupported element blocked
- **DEMO-03 — Govern:** Publish V1 through authorized BE path with definition/rule version and approval evidence **Pass:** Author/reviewer/event captured; version immutable
- **DEMO-04 — Start:** Start Pilot A in BE, return ProcessId, show running status **Pass:** Real selected pilot uses separate capability adapter
- **DEMO-05 — Local rules:** Capability executes embedded AMIE rule + embedded BOB activity; central registry unavailable test **Pass:** No per-rule remote call, pinned rules used locally
- **DEMO-06 — Kafka:** BOB emits notification.email.requested with correlation and idempotency **Pass:** Event logged; no sensitive body or secrets in Kafka payload
- **DEMO-07 — Email:** Email Capability consumes and applies AMIE policy, sends via sandbox/approved provider **Pass:** Outcome notification.email.submitted or failed; no duplicate sending
- **DEMO-08 — Status:** BE shows complete timeline and status after capability result **Pass:** Single correlation ID with each component name/outcome
- **DEMO-09 — Audit:** Inspect transition history, rule version, actor, approval, message attempt **Pass:** Auditor role query works; secrets absent
- **DEMO-10 — Negative:** Duplicate Kafka event, failed mail provider, invalid BPMN and unauthorized publish **Pass:** Expected errors, no unsafe side effect, audit evidence remains
- **DEMO-11 — Durability:** Restart central BOB between wait and completion then resume **Pass:** No lost process and no repeated email due to replay
- **DEMO-12 — Optional app:** Start Pilot B with different configuration and show same shared runtime **Pass:** No BOB/AMIE code edits; separate adapter/rules
- **DEMO-13 — Release gate:** Show evidence checklist and open internal CAs/security/change blockers **Pass:** Correctly labeled demo-ready vs bank-approved for release

## 10. Full platform feature inventory

The table below preserves the long-term core / BPMN / MSSQL reference inventory and extends it with missing BE, Email Capability, audit, governance and integration features. **Roadmap P0/P1/P2 is not the same as November scope.**

### COR-01 — Versioned process definition and immutable identity

**Owner:** BOB Core  |  **Area:** Definition model  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** process / definitions / Shared
- **Reference:** ProcessDefinition (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ProcessDefinition
- **Unity design:** Each execution references an approved definition ID and version.
- **Open gap:** Define canonical schema, identity, immutability, effective dates.
- **Acceptance:** Two definition versions coexist; each instance retains its pinned version.
- **Dependencies:** None

### COR-02 — BPMN XML importer and parser

**Owner:** BOB Core  |  **Area:** Definition model  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** definitions / process / Shared
- **Reference:** BpmnConverter (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/BpmnConverter
- **Unity design:** BPMN 2.0.2 is source notation; normalize into executable IR.
- **Open gap:** Choose supported subset and XML compatibility baseline.
- **Acceptance:** Import valid fixtures; reject invalid XML, missing refs and unsupported elements.
- **Dependencies:** None

### COR-03 — Schema and semantic validation

**Owner:** BOB Core  |  **Area:** Definition model  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** all supported BPMN / Shared
- **Reference:** BpmnConverterSettings (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/BpmnConverterSettings
- **Unity design:** Fail fast on unsupported or ill-formed BPMN; no silent fallback.
- **Open gap:** Separate XSD validation from semantic and deployability checks.
- **Acceptance:** Invalid wait, orphaned flow, unsupported gateway never deploy.
- **Dependencies:** COR-02

### COR-04 — Compile BPMN to executable intermediate representation

**Owner:** BOB Core  |  **Area:** Definition model  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D01

- **BPMN / host:** all supported BPMN / Shared
- **Reference:** IWorkflowBuilder (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Builder/IWorkflowBuilder
- **Unity design:** One execution representation used by embedded and central hosts.
- **Open gap:** Define IR format and compile-time activity binding.
- **Acceptance:** Same BPMN fixture has equal observable outcomes in both hosts.
- **Dependencies:** COR-02

### COR-05 — Process instances, IDs and lifecycle states

**Owner:** BOB Core  |  **Area:** Execution  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** process instance / Shared
- **Reference:** ProcessInstance (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ProcessInstance
- **Unity design:** Separate process template from independently tracked execution.
- **Open gap:** Define lifecycle, suspended/cancelled/error states and transitions.
- **Acceptance:** Start, query, resume and complete deterministic process instances.
- **Dependencies:** COR-01

### COR-06 — BPMN token engine and concurrent paths

**Owner:** BOB Core  |  **Area:** Execution  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** sequence flow / gateways / Shared
- **Reference:** TransitionDefinition (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/TransitionDefinition
- **Unity design:** Track executable tokens across split/join without conflating threads.
- **Open gap:** Define token ownership, join conditions, completion and cancellation.
- **Acceptance:** Parallel branch fixtures synchronize exactly once.
- **Dependencies:** COR-04

### COR-07 — Pluggable typed activity handlers with DI

**Owner:** BOB Core  |  **Area:** Execution  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D02

- **BPMN / host:** serviceTask / task / Shared
- **Reference:** ICustomActivityProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ICustomActivityProvider
- **Unity design:** Workflows invoke registered C# primitives owned by capabilities.
- **Open gap:** Typed inputs/outputs, versioning, scope and failures.
- **Acceptance:** Registered activity executes through DI in both hosts.
- **Dependencies:** None

### COR-08 — Async execution and cancellation propagation

**Owner:** BOB Core  |  **Area:** Execution  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** serviceTask / Shared
- **Reference:** WorkflowRuntimeSettings (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeSettings
- **Unity design:** Avoid blocking threads; cancellation must be explicit.
- **Open gap:** Checkpoint semantics and cooperative cancellation limits.
- **Acceptance:** Cancel before/after checkpoint does not corrupt state.
- **Dependencies:** COR-07

### COR-09 — Typed workflow variables and execution context

**Owner:** BOB Core  |  **Area:** Execution  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** dataInput / dataOutput / Shared
- **Reference:** ParametersCollection (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ParametersCollection
- **Unity design:** Pass structured context between tasks and AMIE rule evaluations.
- **Open gap:** Serialization, scoping, mutable vs immutable fields, sensitive values.
- **Acceptance:** Type mismatch detected; variables safely persist/round-trip.
- **Dependencies:** COR-05

### COR-10 — Parameter and output mappings across activities

**Owner:** BOB Core  |  **Area:** Execution  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D01

- **BPMN / host:** dataAssociation / Shared
- **Reference:** ParameterDefinition (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ParameterDefinition
- **Unity design:** Enable configuration-driven data transfer without procedural glue.
- **Open gap:** Expression syntax, null handling and mapping precedence.
- **Acceptance:** Map outputs between service tasks and subprocesses.
- **Dependencies:** COR-09

### COR-11 — Explicit activity and transition triggers

**Owner:** BOB Core  |  **Area:** Execution  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** sequenceFlow / event / Shared
- **Reference:** TriggerDefinition (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/TriggerDefinition
- **Unity design:** Separate automatic transitions, commands, timers and messages.
- **Open gap:** Trigger taxonomy and exact-once state progression boundaries.
- **Acceptance:** Auto and external-trigger flows behave correctly.
- **Dependencies:** COR-06

### COR-12 — Execution results and typed failures

**Owner:** BOB Core  |  **Area:** Execution  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** serviceTask / Shared
- **Reference:** ProcessStatus (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/ProcessStatus
- **Unity design:** Consistent outcomes for local workflows and central orchestration.
- **Open gap:** Error categories, retries, cancellation and compensatable failures.
- **Acceptance:** Caller gets precise success/failure and correlation IDs.
- **Dependencies:** None

### COR-13 — Activity registry and resolution policy

**Owner:** BOB Core  |  **Area:** Extension model  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D02

- **BPMN / host:** serviceTask / Shared
- **Reference:** AggregatingActionProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/AggregatingActionProvider
- **Unity design:** Capabilities register safe reusable activities by versioned identifiers.
- **Open gap:** Collision rules, authorization, version compatibility.
- **Acceptance:** Unknown/ambiguous activity is rejected before activation.
- **Dependencies:** COR-07

### COR-14 — No arbitrary runtime compilation from BPMN

**Owner:** Security / BOB  |  **Area:** Extension model  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** scriptTask / Both
- **Reference:** CodeActionDefinition (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/CodeActionDefinition
- **Unity design:** Use preapproved handlers and constrained expressions; avoid arbitrary C#.
- **Open gap:** Formalize allowlist and DSL rule sandbox contract.
- **Acceptance:** Malicious/unapproved code cannot be executed from configuration.
- **Dependencies:** COR-13

### COR-15 — Preserve BPMN diagram metadata separately from behavior

**Owner:** BOB Core  |  **Area:** Definition model  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** BPMNDI / Shared
- **Reference:** BpmnDiagram (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/BpmnDiagram
- **Unity design:** Imported visualization is not proof of executable semantics.
- **Open gap:** DI round-trip without altering process meaning.
- **Acceptance:** Import/export process geometry without changing tokens.
- **Dependencies:** COR-02

### BPM-01 — Start and normal end events

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** startEvent / endEvent / Shared
- **Reference:** StartEvent (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/StartEvent
- **Unity design:** Deterministic process creation and normal completion.
- **Open gap:** Multiple start policy; end event token semantics.
- **Acceptance:** Start/end fixtures pass across both hosts.
- **Dependencies:** COR-06

### BPM-02 — Service tasks resolve capability-owned activities

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D02

- **BPMN / host:** serviceTask / Both
- **Reference:** ServiceTaskActivity (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ServiceTaskActivity
- **Unity design:** BOB coordinates, capability does the real operation.
- **Open gap:** Bindings between task definition and registered adapter.
- **Acceptance:** Service task invokes local adapter without central call.
- **Dependencies:** COR-07

### BPM-03 — Exclusive gateway with conditional/default branch

**Owner:** BOB Core + AMIE  |  **Area:** BPMN semantics  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** exclusiveGateway / Shared
- **Reference:** ExclusiveGateway (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ExclusiveGateway
- **Unity design:** BPMN routing consumes AMIE decisions rather than hardcoded rules.
- **Open gap:** Default precedence and invalid/multiple true condition behavior.
- **Acceptance:** One and only one route chosen per token under documented policy.
- **Dependencies:** AM-01

### BPM-04 — Parallel split and synchronization join

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** parallelGateway / Shared
- **Reference:** ParallelGateway (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ParallelGateway
- **Unity design:** True concurrent token semantics, not simple simultaneous method calls.
- **Open gap:** Join counters, cancellation and crash recovery.
- **Acceptance:** Join waits for required branches and fires once.
- **Dependencies:** COR-06

### BPM-05 — Embedded subprocess and scoped variables

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** subProcess / Shared
- **Reference:** SubprocessNodeVisitor (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/SubprocessNodeVisitor
- **Unity design:** Reusable local subflows inside a capability.
- **Open gap:** Variable propagation, boundary events, lifecycle.
- **Acceptance:** Parent can call and complete nested reusable flow.
- **Dependencies:** COR-09

### BPM-06 — Reusable call activity references

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** callActivity / Shared
- **Reference:** CallActivityNodeVisitor (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/CallActivityNodeVisitor
- **Unity design:** Invoke separately versioned workflow definitions without code duplication.
- **Open gap:** Version binding, recursion limits, local vs distributed invocation.
- **Acceptance:** Call activity executes correct pinned referenced definition.
- **Dependencies:** COR-01

### BPM-07 — Terminate end event

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** terminateEventDefinition / Shared
- **Reference:** TerminateEvent (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/TerminateEvent
- **Unity design:** End all active tokens for intended process scope.
- **Open gap:** Cancel in-flight tasks and compensation policy.
- **Acceptance:** Terminate cancels sibling branches deterministically.
- **Dependencies:** COR-06

### BPM-08 — Message catch / receive-task wait states

**Owner:** BOB Core + Kafka  |  **Area:** BPMN semantics  |  **Roadmap priority:** P1  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D04

- **BPMN / host:** intermediateCatchEvent / receiveTask / Central + optional embedded
- **Reference:** MessageCatchEvent (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/MessageCatchEvent
- **Unity design:** Release resources while awaiting correlated Kafka message.
- **Open gap:** Message name, process ID, correlation and authorization.
- **Acceptance:** Wrong/duplicate messages do not advance another instance.
- **Dependencies:** KAF-01

### BPM-09 — Timer catch and timer start events

**Owner:** BOB Core + MSSQL  |  **Area:** BPMN semantics  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** timerEventDefinition / Central
- **Reference:** TimerCatchEvent (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/TimerCatchEvent
- **Unity design:** Durable wait without sleeping application threads.
- **Open gap:** UTC, DST, scheduler lease and clock drift rules.
- **Acceptance:** Timer resumes once after restart and node failover.
- **Dependencies:** PST-04

### BPM-10 — Boundary timer and error event semantics

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** boundaryEvent / Central
- **Reference:** TBoundaryEvent (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TBoundaryEvent
- **Unity design:** Timeout or errors can reroute a running task.
- **Open gap:** Interrupting vs non-interrupting scope; vendor importer incomplete.
- **Acceptance:** Timeout cancels task only if interrupting; async callbacks safe.
- **Dependencies:** BPM-09

### BPM-11 — Event-based gateway race

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** eventBasedGateway / Central
- **Reference:** TEventBasedGateway (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TEventBasedGateway
- **Unity design:** First matching external event wins and cancels alternatives.
- **Open gap:** Atomic competing event subscriptions; Kafka/timer interplay.
- **Acceptance:** Simultaneous events select exactly one outgoing path.
- **Dependencies:** BPM-08

### BPM-12 — Inclusive gateway split and merge

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** inclusiveGateway / Shared
- **Reference:** TInclusiveGateway (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TInclusiveGateway
- **Unity design:** Useful conditional parallel routing; join semantics are subtle.
- **Open gap:** Full synchronization must not imitate vendor partial import.
- **Acceptance:** Join waits only for branches activated by split.
- **Dependencies:** BPM-04

### BPM-13 — Business rule task invokes embedded AMIE

**Owner:** BOB Core + AMIE  |  **Area:** BPMN semantics  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D03

- **BPMN / host:** businessRuleTask / Both
- **Reference:** TBusinessRuleTask (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TBusinessRuleTask
- **Unity design:** Business logic stays in AMIE; BPMN controls sequence.
- **Open gap:** Input/output schema, rule version pin, error mapping.
- **Acceptance:** Rule task invokes AMIE locally without synchronous central dependency.
- **Dependencies:** AM-01

### BPM-14 — User task lifecycle and completion

**Owner:** BOB Central + BE  |  **Area:** BPMN semantics  |  **Roadmap priority:** P2  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** userTask / Central
- **Reference:** TUserTask (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TUserTask
- **Unity design:** Durable human approvals integrated with Business Enablement Website.
- **Open gap:** Assignment, authorization, deadlines, claim/reassign.
- **Acceptance:** Suspend and resume via authorized completion; audit actor.
- **Dependencies:** UI-01

### BPM-15 — Multi-instance sequential tasks

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** multiInstanceLoopCharacteristics / Both
- **Reference:** TMultiInstanceLoopCharacteristics (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMultiInstanceLoopCharacteristics
- **Unity design:** Apply a reusable workflow to a set of rows without new C#.
- **Open gap:** Collection snapshot, item scope and partial failure policy.
- **Acceptance:** N items processed once, in order, with bounded memory.
- **Dependencies:** COR-09

### BPM-16 — Multi-instance parallel tasks with limits

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** multiInstanceLoopCharacteristics / Both
- **Reference:** TMultiInstanceLoopCharacteristics (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMultiInstanceLoopCharacteristics
- **Unity design:** Execute any multi-instance workload with bounded parallelism and capability-specific limits.
- **Open gap:** Concurrency limits, error aggregation, cancellation.
- **Acceptance:** 10k items with configurable max concurrency and no loss.
- **Dependencies:** BPM-15

### BPM-17 — Compensation handlers and rollback semantics

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** compensateEventDefinition / Central
- **Reference:** TCompensateEventDefinition (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TCompensateEventDefinition
- **Unity design:** Compensating transactions for cross-service failures.
- **Open gap:** Compensation registration and order; idempotent reversal.
- **Acceptance:** Failure after partial steps triggers appropriate compensations.
- **Dependencies:** PST-07

### BPM-18 — Error end and escalation events

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** errorEventDefinition / escalationEventDefinition / Central
- **Reference:** TErrorEventDefinition (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TErrorEventDefinition
- **Unity design:** Explicit error routing beyond generic exceptions.
- **Open gap:** Error type propagation through nested scopes.
- **Acceptance:** Expected handler catches matching error; others fail safely.
- **Dependencies:** BPM-05

### BPM-19 — Conditional catch events

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** conditionalEventDefinition / Central
- **Reference:** TConditionalEventDefinition (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TConditionalEventDefinition
- **Unity design:** Optional future event-driven conditional waits.
- **Open gap:** Signal/update dependency graph rather than polling every instance.
- **Acceptance:** Condition triggers once on relevant state change.
- **Dependencies:** BPM-08

### BPM-20 — Signal and broadcast events

**Owner:** BOB Core + Kafka  |  **Area:** BPMN semantics  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** signalEventDefinition / Central
- **Reference:** TSignalEventDefinition (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TSignalEventDefinition
- **Unity design:** Broadcast signals are distinct from targeted messages.
- **Open gap:** Who subscribes, durable fanout semantics and authorization.
- **Acceptance:** Signal delivery matches subscribed instances without duplicates.
- **Dependencies:** KAF-01

### BPM-21 — Send task and message throw

**Owner:** BOB Core + Kafka  |  **Area:** BPMN semantics  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** sendTask / intermediateThrowEvent / Central
- **Reference:** TMessageFlow (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMessageFlow
- **Unity design:** Issue a versioned command/event through capability integration.
- **Open gap:** Outbox commit and message correlation.
- **Acceptance:** Message published transactionally with workflow transition intent.
- **Dependencies:** PST-07

### BPM-22 — Manual task and script task

**Owner:** Capability / Security  |  **Area:** BPMN semantics  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** manualTask / scriptTask / Both
- **Reference:** TScriptTask (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TScriptTask
- **Unity design:** Manual work belongs in human task handling; script execution is restricted.
- **Open gap:** Decide if safe sandbox expression needed at all.
- **Acceptance:** Unapproved scripts not executed; human work mapped deliberately.
- **Dependencies:** None

### BPM-23 — Pools, lanes and collaborations

**Owner:** BOB Central + BE  |  **Area:** BPMN semantics  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** collaboration / lane / Central
- **Reference:** TCollaboration (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TCollaboration
- **Unity design:** Model service participants, but no shared-memory cross-pool execution.
- **Open gap:** Map message flows to Kafka, preserve independent capabilities.
- **Acceptance:** Each pool has isolated state and explicit cross-pool messages.
- **Dependencies:** KAF-01

### BPM-24 — Event subprocess and cancellation scopes

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** eventSubProcess / Central
- **Reference:** TSubProcess (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TSubProcess
- **Unity design:** Advanced interrupt and event handlers.
- **Open gap:** Determine whether business cases justify full semantics.
- **Acceptance:** Interrupt and non-interrupt event subprocess conformance.
- **Dependencies:** BPM-10

### BPM-25 — Complex gateways and ad-hoc subprocesses

**Owner:** BOB Core  |  **Area:** BPMN semantics  |  **Roadmap priority:** OUT  |  **Nov 30:** Excluded  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** complexGateway / adHocSubProcess / N/A
- **Reference:** TComplexGateway (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TComplexGateway
- **Unity design:** Not needed for initial Unity workflows; reject as unsupported.
- **Open gap:** Revisit only with proven business use.
- **Acceptance:** Validator rejects unsupported definitions with precise reason.
- **Dependencies:** COR-03

### BPM-26 — BPMN conformance fixture suite

**Owner:** BOB Core / QA  |  **Area:** BPMN semantics  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D14

- **BPMN / host:** supported subset / Both
- **Reference:** TDefinitions (API surface; OMG standard); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TDefinitions
- **Unity design:** Prevent misleading BPMN compatible claim without executable proofs.
- **Open gap:** Map every accepted element to token and failure tests.
- **Acceptance:** Fixture suite runs with same observable outcomes under both hosts.
- **Dependencies:** COR-04

### HST-01 — Single reusable workflow engine library

**Owner:** BOB Core  |  **Area:** Hosting  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D01

- **BPMN / host:** all / Shared
- **Reference:** WorkflowRuntime (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime
- **Unity design:** Embedded and centralized hosts execute the same engine and definition IR.
- **Open gap:** Host-neutral interfaces; no central REST on local hot path.
- **Acceptance:** One package builds in-process and service hosting without divergent logic.
- **Dependencies:** None

### HST-02 — Embedded capability workflow host

**Owner:** BOB Embedded  |  **Area:** Hosting  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D02

- **BPMN / host:** local flows / Embedded
- **Reference:** SingleServerServiceRunner (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.ServiceRunners/SingleServerServiceRunner
- **Unity design:** Runs workflows directly in capability process with registered DI adapters.
- **Open gap:** Request scope, local lifecycle and memory controls.
- **Acceptance:** Two unrelated local workflows execute during central BOB / AMIE registry outage using approved cached definitions.
- **Dependencies:** HST-01

### HST-03 — Central orchestration service host

**Owner:** BOB Central  |  **Area:** Hosting  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D04

- **BPMN / host:** long-running processes / Central
- **Reference:** MultiServerServiceRunner (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.ServiceRunners/MultiServerServiceRunner
- **Unity design:** Durable coordination across capabilities and Kafka.
- **Open gap:** Partitioning, lifecycle API, administration.
- **Acceptance:** Process survives service failover and resumes work.
- **Dependencies:** PST-01

### HST-04 — Host-specific persistence policies

**Owner:** BOB Core  |  **Area:** Hosting  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D05

- **BPMN / host:** wait states / Both
- **Reference:** IPersistenceProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IPersistenceProvider
- **Unity design:** In-memory local execution where safe; MSSQL for durable workflows.
- **Open gap:** Clear refusal to start durable waits without persistence configured.
- **Acceptance:** Embedded no-durability scenario works; timer wait rejects unsafe mode.
- **Dependencies:** PST-01

### HST-05 — Definition and rule cache in capabilities

**Owner:** BOB Embedded + AMIE  |  **Area:** Configuration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D03

- **BPMN / host:** definitions / Embedded
- **Reference:** IParsedProcessCache (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Cache/IParsedProcessCache
- **Unity design:** No per-activity network calls to load definitions.
- **Open gap:** Atomic swap, expiry and stale security policies.
- **Acceptance:** 100k local activities require zero registry round trips.
- **Dependencies:** HST-02

### HST-06 — Approved definition registry and publishing

**Owner:** Unity Control Plane  |  **Area:** Configuration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks bank release  |  **Packet:** D06

- **BPMN / host:** definitions / Central
- **Reference:** ISchemePersistenceProvider<TSchemeMedium> (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/ISchemePersistenceProvider-TSchemeMedium
- **Unity design:** Central governance while executing locally.
- **Open gap:** Approval workflow, signed package publication and access control.
- **Acceptance:** Unapproved definition cannot be loaded by capability.
- **Dependencies:** SEC-01

### HST-07 — Definition version pinning in running instances

**Owner:** BOB Core + AMIE  |  **Area:** Configuration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D06

- **BPMN / host:** calledElement / definitions / Both
- **Reference:** SchemeDefinition<T> (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/SchemeDefinition-T
- **Unity design:** Running workflows must not silently adopt new logic.
- **Open gap:** Pin AMIE and BOB versions together as needed.
- **Acceptance:** Publish v2 during v1 instance; v1 outcome unchanged.
- **Dependencies:** COR-01

### HST-08 — Schema migration of live workflow instances

**Owner:** BOB Central  |  **Area:** Configuration  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** definitions / Central
- **Reference:** SchemeEntity (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Entities/SchemeEntity
- **Unity design:** Explicit migration only; prioritize version coexistence.
- **Open gap:** Migration planner, compatibility check, rollback.
- **Acceptance:** V1 instances remain executable with V2 deployed.
- **Dependencies:** HST-07

### HST-09 — Signed execution packages and dependency manifest

**Owner:** Unity Control Plane  |  **Area:** Configuration  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** definitions / Both
- **Reference:** ProcessDefinition (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ProcessDefinition
- **Unity design:** Publish approved workflow/rule bundles to trusted hosts.
- **Open gap:** Package format, signing keys, expiry and capability compatibility.
- **Acceptance:** Tampered/unsupported package rejected before activation.
- **Dependencies:** HST-06

### HST-10 — Atomic activation/rollback of definition sets

**Owner:** Unity Control Plane  |  **Area:** Configuration  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** definitions / Both
- **Reference:** IParsedProcessCache (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Cache/IParsedProcessCache
- **Unity design:** Avoid partially updated AMIE/BOB logic.
- **Open gap:** Rollout strategy and rollback semantics.
- **Acceptance:** Concurrent requests only see full old or full new package.
- **Dependencies:** HST-09

### HST-11 — Multi-node execution coordination

**Owner:** BOB Central  |  **Area:** Hosting  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** distributed instance / Central
- **Reference:** MultiServerRestorer (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.ServiceRunners/MultiServerRestorer
- **Unity design:** Central workers should recover on node failures without double execution.
- **Open gap:** Lease ownership, fencing tokens and failover.
- **Acceptance:** Kill worker mid-task; exactly one active lease holder remains.
- **Dependencies:** PST-06

### HST-12 — Local workflow limits and watchdogs

**Owner:** BOB Embedded  |  **Area:** Hosting  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** multiInstance / loops / Embedded
- **Reference:** WorkflowRuntimeSettings (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeSettings
- **Unity design:** Prevent misconfigured workflows from consuming capability resources.
- **Open gap:** Timeouts, max recursion, steps and memory budget.
- **Acceptance:** Infinite/expensive loop aborted with controlled failure.
- **Dependencies:** SEC-02

### HST-13 — Programmatic workflow builder optional

**Owner:** BOB Core  |  **Area:** Configuration  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** definitions / Shared
- **Reference:** ProcessDefinitionBuilder (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model.Builder/ProcessDefinitionBuilder
- **Unity design:** May help tests and developer tools; BPMN remains canonical.
- **Open gap:** Decide if builder is public API or internal testing tool.
- **Acceptance:** Builder round-trip conforms to BPMN subset.
- **Dependencies:** None

### HST-14 — Runtime startup, shutdown and restore hooks

**Owner:** BOB Core  |  **Area:** Hosting  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** process lifecycle / Both
- **Reference:** WorkflowRuntime (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime
- **Unity design:** Controlled suspend/drain and restore.
- **Open gap:** Crash vs graceful shutdown and in-flight handler contract.
- **Acceptance:** Stop/restart without orphaned workflow state.
- **Dependencies:** PST-01

### HST-15 — Offline use of last approved definitions

**Owner:** BOB Embedded + AMIE  |  **Area:** Configuration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D03

- **BPMN / host:** definitions / Embedded
- **Reference:** DefaultParcedProcessCache (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Cache/DefaultParcedProcessCache
- **Unity design:** Registry outage should not disable authorized local workflows.
- **Open gap:** Define fail-closed exceptions for expired security policy.
- **Acceptance:** Offline approved configuration continues; revoked sensitive rules fail closed.
- **Dependencies:** HST-05

### HST-16 — Use REST only for management or intentional remote execution

**Owner:** BOB Central / BE  |  **Area:** Hosting  |  **Roadmap priority:** P1  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D04

- **BPMN / host:** process API / Central
- **Reference:** WorkflowRuntime (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime
- **Unity design:** Avoid turning every workflow step into a central API call.
- **Open gap:** Management endpoints vs execution endpoints.
- **Acceptance:** Embedded workflow call path contains no central HTTP requests.
- **Dependencies:** HST-02

### PST-01 — Single SQL Server persistence implementation

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D05

- **BPMN / host:** process state / Central / durable embedded
- **Reference:** MSSQLProvider (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/MSSQLProvider
- **Unity design:** Only MSSQL support; keep persistence behind internal contracts.
- **Open gap:** Schema, transactions, EF vs ADO and connection policy.
- **Acceptance:** Creation, mutation and restoration across worker restart.
- **Dependencies:** None

### PST-02 — Workflow definitions and immutable snapshots

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P1  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D05

- **BPMN / host:** definitions / Central
- **Reference:** WorkflowScheme (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowScheme
- **Unity design:** Persist published BPMN source and executable version metadata.
- **Open gap:** Version indexes, hash validation, retention policy.
- **Acceptance:** Load exact pinned definition and prove integrity.
- **Dependencies:** PST-01

### PST-03 — Process instance checkpoints

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D05

- **BPMN / host:** wait states / Central
- **Reference:** WorkflowProcessInstance (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowProcessInstance
- **Unity design:** Store current tokens, context and state atomically.
- **Open gap:** Checkpoint frequency and payload sizes.
- **Acceptance:** Crash at each boundary; replay never skips committed state.
- **Dependencies:** PST-01

### PST-04 — Durable timer registration and recovery

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** timerEventDefinition / Central
- **Reference:** WorkflowProcessTimer (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowProcessTimer
- **Unity design:** Timer survive restart and multi-node execution.
- **Open gap:** UTC handling, due-time index, lease/dedupe.
- **Acceptance:** Timers fire once across leader failover and DST boundary.
- **Dependencies:** PST-03

### PST-05 — Transition history and audit

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks bank release  |  **Packet:** D10

- **BPMN / host:** all / Central
- **Reference:** WorkflowProcessTransitionHistory (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowProcessTransitionHistory
- **Unity design:** Reconstruct state changes and evidence for operations.
- **Open gap:** Sensitive payload redaction and retention.
- **Acceptance:** Every state transition traceable by version, actor and correlation.
- **Dependencies:** PST-03

### PST-06 — Worker leases, locking and fencing

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** distributed execution / Central
- **Reference:** WorkflowSync (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.MSSQL.Models/WorkflowSync
- **Unity design:** Avoid simultaneous ownership of workflow instance on two nodes.
- **Open gap:** Fencing in downstream adapters; lease timeout selection.
- **Acceptance:** Concurrent workers never commit incompatible transitions.
- **Dependencies:** PST-03

### PST-07 — Transactional outbox for events and commands

**Owner:** BOB MSSQL + Kafka  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D07

- **BPMN / host:** message events / Central
- **Reference:** IPersistenceProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IPersistenceProvider
- **Unity design:** Persist state and outbound message intent atomically.
- **Open gap:** Define outbox schema, publisher, retry and dedupe.
- **Acceptance:** Crash after SQL commit before Kafka publish still eventually emits.
- **Dependencies:** PST-03

### PST-08 — Inbox and message deduplication

**Owner:** BOB MSSQL + Kafka  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D07

- **BPMN / host:** message catch / Central
- **Reference:** WorkflowInbox (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowInbox
- **Unity design:** Retry-safe event processing; do not interpret vendor approval inbox as Kafka inbox.
- **Open gap:** Dedicated consumed-message identity schema required.
- **Acceptance:** Duplicate deliveries lead to one state transition.
- **Dependencies:** PST-07

### PST-09 — Optimistic concurrency / rowversion

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P1  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D05

- **BPMN / host:** process state / Central
- **Reference:** WorkflowProcessInstanceStatus (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowProcessInstanceStatus
- **Unity design:** Prevent lost updates and conflicting commits.
- **Open gap:** Locking vs rowversion, deadlock handling.
- **Acceptance:** Concurrent updates conflict and retry safely.
- **Dependencies:** PST-03

### PST-10 — Schema migration and versioned upgrades

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** persistence / Central
- **Reference:** Migration10Initial (API surface); https://api.workflowengine.io/sql-server/OptimaJet.Workflow.MSSQL.Migrations/Migration10Initial
- **Unity design:** Controlled evolving MSSQL schema for durable instances.
- **Open gap:** Expand/contract strategy, rollback and online migration.
- **Acceptance:** Upgrade schema with old instances running without data loss.
- **Dependencies:** PST-01

### PST-11 — Tenant partitioning and access constraints

**Owner:** BOB MSSQL / Security  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P2  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** tenant / process / Central
- **Reference:** ProcessInstanceEntity (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Entities/ProcessInstanceEntity
- **Unity design:** OptimaJet exposes tenant-related models; Unity need TBD.
- **Open gap:** Decide if multiple logical tenants or applications need strict partitioning.
- **Acceptance:** Tenant A cannot access/affect tenant B process or definition.
- **Dependencies:** SEC-01

### PST-12 — Retention, archiving and purging

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** history / Central
- **Reference:** ProcessHistoryItem (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ProcessHistoryItem
- **Unity design:** Control SQL growth without losing legally required audit records.
- **Open gap:** Data lifecycle and export policy.
- **Acceptance:** Archived instances remain queryable; active workflows unaffected.
- **Dependencies:** PST-05

### PST-13 — Recovery / orphaned instance resumption

**Owner:** BOB Central  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** wait states / Central
- **Reference:** IProcessRestorer (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.ProcessRestoring/IProcessRestorer
- **Unity design:** Recover from node failures and resume durable steps.
- **Open gap:** Unknown side-effect resolution after crash before checkpoint.
- **Acceptance:** Crash injection matrix passes idempotent replay requirements.
- **Dependencies:** PST-06

### PST-14 — Indexing, batching and DB load instrumentation

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** bulk / history / Central
- **Reference:** WorkflowRuntimeBulkApi (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeBulkApi
- **Unity design:** Protect MSSQL workflow-state performance under high instance, timer and history volumes.
- **Open gap:** Choose instance granularity per workload; define concurrency, retention, and data growth targets.
- **Acceptance:** Mixed process workload meets defined throughput/latency SLO without excessive SQL scans or lock contention.
- **Dependencies:** PST-01

### PST-15 — No other workflow persistence provider modules

**Owner:** BOB MSSQL  |  **Area:** MSSQL persistence  |  **Roadmap priority:** OUT  |  **Nov 30:** Excluded  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** persistence / N/A
- **Reference:** PersistenceProviderId (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core/PersistenceProviderId
- **Unity design:** Drop MongoDB/MySQL/Oracle/PostgreSQL/SQLite providers.
- **Open gap:** Confirm no incidental runtime references to other providers.
- **Acceptance:** No package or project reference to other provider implementations.
- **Dependencies:** None

### AM-01 — Local AMIE rule evaluation inside service tasks

**Owner:** AMIE Embedded  |  **Area:** AMIE boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D03

- **BPMN / host:** businessRuleTask / Embedded
- **Reference:** IWorkflowActionProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider
- **Unity design:** BOB dispatches to the AMIE SDK; does not reimplement rules.
- **Open gap:** Typed evaluator interface, local snapshots, errors.
- **Acceptance:** Rule evaluation with AMIE registry unavailable and no network calls.
- **Dependencies:** None

### AM-02 — AMIE mapping, validation and decision reuse

**Owner:** AMIE  |  **Area:** AMIE boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D03

- **BPMN / host:** gateway / rule task / Both
- **Reference:** ConditionDefinition (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ConditionDefinition
- **Unity design:** Rules, transforms and mappings configured, not repeated C#.
- **Open gap:** AMIE DSL, type safety, expression execution and cache.
- **Acceptance:** Change a business mapping and eligibility rule through approved AMIE configuration without rebuilding the owning capability.
- **Dependencies:** AM-01

### AM-03 — Pin AMIE rule versions alongside BPMN definition

**Owner:** AMIE + BOB Core  |  **Area:** AMIE boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D03

- **BPMN / host:** businessRuleTask / Both
- **Reference:** SchemeDefinition<T> (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/SchemeDefinition-T
- **Unity design:** Prevent in-flight outcomes changing under updated AMIE configuration.
- **Open gap:** Reference rule version or content hash from workflow instance.
- **Acceptance:** Rule revision does not alter already-started workflow.
- **Dependencies:** HST-07

### AM-04 — Rules control business choices; BOB controls flow

**Owner:** AMIE + BOB Core  |  **Area:** AMIE boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D03

- **BPMN / host:** gateway / rule task / Both
- **Reference:** IWorkflowRuleProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowRuleProvider
- **Unity design:** Do not treat vendor authorization rule API as AMIE business rule engine.
- **Open gap:** Specify business vs actor-authorization rule namespaces.
- **Acceptance:** BPMN gateway calls business rule and logs decision version.
- **Dependencies:** AM-01

### AM-05 — Evaluate DMN decision-table compatibility for AMIE

**Owner:** AMIE / Architecture  |  **Area:** AMIE boundary  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** businessRuleTask / Embedded + Central
- **Reference:** DecisionTable (API surface + OMG DMN outside reference); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Plugins.BasicsPlugin/DecisionTable
- **Unity design:** OMG DMN complements BPMN for decisions; do not embed rule tables in BOB. See https://www.omg.org/spec/DMN/1.6
- **Open gap:** Decide whether AMIE native rule format should import/export a supported DMN subset.
- **Acceptance:** Prototype a generic rule/decision table with deterministic versioned inputs and outputs; keep it independent of BOB.
- **Dependencies:** AM-01

### KAF-01 — Event/command contracts for cross-capability workflows

**Owner:** Kafka / BOB Central  |  **Area:** Kafka integration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D07

- **BPMN / host:** messageFlow / Central
- **Reference:** TMessageFlow (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMessageFlow
- **Unity design:** Message transport in Kafka, orchestration state in BOB.
- **Open gap:** Topic naming, schema registry, headers, correlation.
- **Acceptance:** Cross-service message resumes right process, no shared DB access.
- **Dependencies:** None

### KAF-02 — Message correlation and process subscriptions

**Owner:** BOB Central + Kafka  |  **Area:** Kafka integration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D07

- **BPMN / host:** messageCatchEvent / Central
- **Reference:** CommandDefinition (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/CommandDefinition
- **Unity design:** Target message to instance or business key; avoid broadcast confusion.
- **Open gap:** Correlation uniqueness, ordering, expiration.
- **Acceptance:** Out-of-order and duplicate messages do not corrupt process.
- **Dependencies:** KAF-01

### KAF-03 — Backpressure, retry topics, DLQ

**Owner:** Kafka / Capabilities  |  **Area:** Kafka integration  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** serviceTask / message events / Both
- **Reference:** ProcessExecutionException (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Fault/ProcessExecutionException
- **Unity design:** Transport retry differs from workflow task retry.
- **Open gap:** Policy matrix for transient/fatal and failed messages.
- **Acceptance:** Poison message quarantined without losing other work.
- **Dependencies:** KAF-01

### CAP-01 — Capability-owned activity adapters

**Owner:** Capabilities  |  **Area:** Capability boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D02

- **BPMN / host:** serviceTask / Embedded
- **Reference:** ActivityBase (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core/ActivityBase
- **Unity design:** Integration adapters remain inside the owning capability, never inside the generic BOB engine.
- **Open gap:** Activity versioning and contract manifest.
- **Acceptance:** Two independent capability adapters execute in their owning services without modifying BOB Core.
- **Dependencies:** COR-07

### CAP-02 — No cross-capability private database access

**Owner:** Capabilities / Security  |  **Area:** Capability boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D02

- **BPMN / host:** serviceTask / Both
- **Reference:** IWorkflowExternalParametersProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowExternalParametersProvider
- **Unity design:** Inter-service data exchange through APIs/events, not shared DbContext.
- **Open gap:** Formal data ownership map and access policy.
- **Acceptance:** No capability reads another service private tables directly.
- **Dependencies:** None

### CAP-03 — Direct EF Core for capability-owned SQL data

**Owner:** Capabilities  |  **Area:** Capability boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** serviceTask / Embedded
- **Reference:** IWorkflowActionProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider
- **Unity design:** Avoid DB capability network hop when service owns MSSQL tables.
- **Open gap:** DbContext lifetime and transaction isolation.
- **Acceptance:** Locally owned data operation uses registered adapter and local EF.
- **Dependencies:** None

### CAP-04 — Managed Database Capability API for shared data

**Owner:** Database Capability  |  **Area:** Capability boundary  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** serviceTask / Central/remote
- **Reference:** IWorkflowActionProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider
- **Unity design:** Shared data owner exposes controlled domain contracts.
- **Open gap:** Clarify centralized Unity data vs legacy shared data.
- **Acceptance:** Caller cannot execute arbitrary SQL against shared data.
- **Dependencies:** None

### CAP-05 — Configuration-driven composition for unrelated Unity workloads

**Owner:** Unity Platform Integration  |  **Area:** Capability boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D12

- **BPMN / host:** subProcess / serviceTask / Both
- **Reference:** IWorkflowActionProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider
- **Unity design:** Different applications assemble the same BOB Core, AMIE rule engine and capability activities by configuration.
- **Open gap:** Prove application-neutral contracts, configuration isolation and extension compatibility.
- **Acceptance:** Two unrelated configured processes run using unchanged BOB/AMIE engine binaries.
- **Dependencies:** CAP-01

### CAP-06 — High-volume workloads should not create needless workflow instances

**Owner:** BOB Core / Capabilities  |  **Area:** Capability boundary  |  **Roadmap priority:** P1  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** multi-instance / Both
- **Reference:** WorkflowRuntimeBulkApi (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeBulkApi
- **Unity design:** Choose durable work units by business transaction, not every operation or item by default.
- **Open gap:** Benchmark the appropriate checkpoint and workflow-instance granularity for varied workload types.
- **Acceptance:** Performance test compares per-item, per-batch and per-transaction instance strategies.
- **Dependencies:** PST-14

### CAP-07 — No distributed EF or SQL transaction spanning services

**Owner:** BOB Central + Kafka  |  **Area:** Capability boundary  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D07

- **BPMN / host:** collaboration / compensation / Central
- **Reference:** IPersistenceProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IPersistenceProvider
- **Unity design:** Use local transactions and eventual coordination with compensations.
- **Open gap:** Failure semantics, outbox/inbox, saga policy.
- **Acceptance:** Partial service failure does not leave hidden DB locks.
- **Dependencies:** PST-07

### SEC-01 — Signed and authorized workflow/rule publication

**Owner:** Unity Control Plane  |  **Area:** Security  |  **Roadmap priority:** P1  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D06

- **BPMN / host:** definitions / Central
- **Reference:** IWorkflowRuleProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowRuleProvider
- **Unity design:** Only approved and authorized definitions reach execution hosts.
- **Open gap:** Trust chain, approvals, revocation, tenant handling.
- **Acceptance:** Unapproved package cannot execute in any capability.
- **Dependencies:** None

### SEC-02 — Resource quotas and restricted expression language

**Owner:** BOB Core / AMIE  |  **Area:** Security  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D03

- **BPMN / host:** conditionExpression / Both
- **Reference:** ExpressionManager (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.CodeActions/ExpressionManager
- **Unity design:** Limit CPU/memory and forbid privileged arbitrary code.
- **Open gap:** Sandbox semantics and max evaluation depth/time.
- **Acceptance:** Adversarial expression tests cannot access file/network/reflection.
- **Dependencies:** None

### SEC-03 — Actor roles and authorization for human commands

**Owner:** BOB Central + BE  |  **Area:** Security  |  **Roadmap priority:** P2  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D11

- **BPMN / host:** userTask / Central
- **Reference:** IWorkflowRuleProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowRuleProvider
- **Unity design:** Authorization differs from business rule evaluation.
- **Open gap:** Identity provider, impersonation controls, ABAC/RBAC.
- **Acceptance:** Only eligible actor can claim/complete task.
- **Dependencies:** BPM-14

### SEC-04 — Secrets not embedded in workflow definitions

**Owner:** Capabilities / Vault  |  **Area:** Security  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D11

- **BPMN / host:** serviceTask / Both
- **Reference:** IWorkflowExternalParametersProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowExternalParametersProvider
- **Unity design:** Workflow definitions reference secret IDs, not plaintext values.
- **Open gap:** Secret provider integration and log scrub.
- **Acceptance:** No secrets in BPMN XML, cache files, logs, or outbox payloads.
- **Dependencies:** None

### OPS-01 — Process logs, correlation and OpenTelemetry

**Owner:** BOB Core  |  **Area:** Observability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks bank release  |  **Packet:** D10

- **BPMN / host:** all / Both
- **Reference:** IProcessLogProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Logging/IProcessLogProvider
- **Unity design:** Trace executions through BOB/AMIE/Kafka/capabilities.
- **Open gap:** Define span naming and PII redaction.
- **Acceptance:** One trace spans BOB, local AMIE, Kafka and an independently deployed capability on success and failure.
- **Dependencies:** COR-05

### OPS-02 — Process history query and event replay for audit

**Owner:** BOB Central  |  **Area:** Observability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks bank release  |  **Packet:** D10

- **BPMN / host:** all / Central
- **Reference:** ProcessHistoryItem (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ProcessHistoryItem
- **Unity design:** Operators need reliable execution history.
- **Open gap:** Replay history is not same as safely replaying effects.
- **Acceptance:** History reconstructs decisions, versions and manual interventions.
- **Dependencies:** PST-05

### OPS-03 — Metrics, rate limits and SLO dashboards

**Owner:** BOB Central + BE  |  **Area:** Observability  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** all / Both
- **Reference:** ProcessLogEntry (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Logging/ProcessLogEntry
- **Unity design:** Observe p95 rule latency, queue lag, DB pressure, API throttling.
- **Open gap:** Choose targets after baseline test.
- **Acceptance:** Load test emits host-specific latency and error metrics.
- **Dependencies:** OPS-01

### OPS-04 — Workflow dry-run, simulation and pre-execution tracing

**Owner:** BOB Core / QA  |  **Area:** Observability  |  **Roadmap priority:** P2  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** all / Both
- **Reference:** OfflineApi (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/OfflineApi
- **Unity design:** Test routing without destructive capability actions.
- **Open gap:** Mock side effects and AMIE rule snapshots.
- **Acceptance:** Simulation predicts gateway paths and records mock effects only.
- **Dependencies:** BPM-26

### OPS-05 — Bulk execution and process operations API

**Owner:** BOB Central  |  **Area:** Observability  |  **Roadmap priority:** P2  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** bulk / Central
- **Reference:** WorkflowRuntimeBulkApi (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeBulkApi
- **Unity design:** Operationally useful for bulk starts/retries; avoid excessive write load.
- **Open gap:** Role restrictions, dedupe and page sizes.
- **Acceptance:** Bulk command retries safely and audits each item.
- **Dependencies:** SEC-03

### OPS-06 — Versioned workflow management REST API

**Owner:** BOB Central  |  **Area:** Observability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D04

- **BPMN / host:** management / Central
- **Reference:** WorkflowRuntime (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime
- **Unity design:** BE starts/monitors processes; embedded calls remain local.
- **Open gap:** Define read/start/suspend/resume/history endpoints.
- **Acceptance:** OpenAPI supports status/history without exposing internal DB.
- **Dependencies:** HST-03

### OPS-07 — BE live workflow status and operational dashboard

**Owner:** Business Enablement Website  |  **Area:** Observability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D09

- **BPMN / host:** userTask / Central
- **Reference:** ApprovalPlugin (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Plugins/ApprovalPlugin
- **Unity design:** BE presents process and cross-capability state, filtered by actor/role, with correlated status timeline.
- **Open gap:** Approvals, comments, retries, dashboards and access control.
- **Acceptance:** Authorized user completes suspended task, status updates.
- **Dependencies:** BPM-14

### OPS-08 — BE constrained BPMN designer (reuse editor toolkit)

**Owner:** Business Enablement Website  |  **Area:** Observability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D08

- **BPMN / host:** BPMNDI / Central
- **Reference:** DesignerSettings (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/DesignerSettings
- **Unity design:** Embed a reviewed BPMN modeler in BE; author, validate, draft, and publish only supported executable BPMN subset. Full custom designer is deferred.
- **Open gap:** Roundtrip, schema validation and approved publishing.
- **Acceptance:** Editing diagram does not silently change process behavior.
- **Dependencies:** COR-15

### OPS-09 — Forms plugin and richer task forms

**Owner:** Business Enablement Website  |  **Area:** Observability  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** userTask / Central
- **Reference:** IFormDataProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IFormDataProvider
- **Unity design:** Forms useful only once human tasks exist.
- **Open gap:** Form schema, versioning and validation.
- **Acceptance:** Resume works with version-pinned form schema.
- **Dependencies:** OPS-07

### OPS-10 — Actor inbox/outbox and approval history

**Owner:** BOB Central / BE  |  **Area:** Observability  |  **Roadmap priority:** P2  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** —

- **BPMN / host:** userTask / Central
- **Reference:** IApprovalProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IApprovalProvider
- **Unity design:** Human work queue and audit distinct from Kafka transport inbox.
- **Open gap:** Approval delegation, expiration, audit retention.
- **Acceptance:** Reassignment audited; action authorized.
- **Dependencies:** OPS-07

### OPS-11 — Working calendar / business day timers

**Owner:** BOB Central  |  **Area:** Observability  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** timerEventDefinition / Central
- **Reference:** ICalendar (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.Calendars/ICalendar
- **Unity design:** Time periods may depend on holidays and working hours.
- **Open gap:** Calendar provider, timezone and country rules.
- **Acceptance:** Business-hours SLA timer survives DST/holiday.
- **Dependencies:** BPM-09

### OPS-12 — Localization of workflow labels

**Owner:** Business Enablement Website  |  **Area:** Observability  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** BPMNDI / Central
- **Reference:** ILocalizationProvider (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ILocalizationProvider
- **Unity design:** UI concern; keep runtime identifiers stable.
- **Open gap:** Multilingual labels and process versioning.
- **Acceptance:** Switch display locale without altering execution.
- **Dependencies:** None

### OPS-13 — Source API surface parity is not a scope goal

**Owner:** BOB Core  |  **Area:** Observability  |  **Roadmap priority:** OUT  |  **Nov 30:** Excluded  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** all / N/A
- **Reference:** WorkflowRuntime (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime
- **Unity design:** Only implement features justified by Unity and BPMN target.
- **Open gap:** Do not pursue one-to-one OptimaJet class replication.
- **Acceptance:** Each accepted feature linked to a business/architecture acceptance.
- **Dependencies:** None

### OUT-01 — Other OptimaJet database providers

**Owner:** BOB MSSQL  |  **Area:** Out of scope  |  **Roadmap priority:** OUT  |  **Nov 30:** Excluded  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** persistence / N/A
- **Reference:** PersistenceProviderId (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core/PersistenceProviderId
- **Unity design:** No SQLite/MySQL/Mongo/Postgres/Oracle workflow persistence.
- **Open gap:** Eliminate provider-specific assemblies and migrations.
- **Acceptance:** Only MSSQL provider in dependency graph.
- **Dependencies:** None

### OUT-02 — Copy OptimaJet proprietary source/API shapes

**Owner:** Engineering governance  |  **Area:** Out of scope  |  **Roadmap priority:** OUT  |  **Nov 30:** Excluded  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** all / N/A
- **Reference:** WorkflowRuntime (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime
- **Unity design:** Reference capabilities and documented concepts; implement independent original engine.
- **Open gap:** Review licenses if evaluating vendor packages.
- **Acceptance:** Independent code and documentation provenance.
- **Dependencies:** None

### OUT-03 — Bundled AD/files/email plugins as a general platform

**Owner:** Capabilities  |  **Area:** Out of scope  |  **Roadmap priority:** P3  |  **Nov 30:** Post-Nov  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** serviceTask / N/A
- **Reference:** IWorkflowPlugin (API surface); https://api.workflowengine.io/core/OptimaJet.Workflow.Plugins/IWorkflowPlugin
- **Unity design:** Add integrations only when Unity capability needs them.
- **Open gap:** Map each plugin to capability-owned registered adapter.
- **Acceptance:** Core contains no AD/file/email dependencies.
- **Dependencies:** None

### OUT-04 — Support every BPMN 2.0.2 construct in first release

**Owner:** BOB Core  |  **Area:** Out of scope  |  **Roadmap priority:** OUT  |  **Nov 30:** Excluded  |  **Release impact:** Later  |  **Packet:** —

- **BPMN / host:** full BPMN / N/A
- **Reference:** BpmnPlugin (API surface); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin/BpmnPlugin
- **Unity design:** Define an executable subset, reject remaining constructs.
- **Open gap:** Publish conformance statement and unsupported list.
- **Acceptance:** Unsupported BPMN cannot silently import as automatic flow.
- **Dependencies:** None

### BE-01 — Authenticated BE shell + role-aware navigation

**Owner:** BE Website  |  **Area:** Business Enablement  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D11

- **BPMN / host:** human-facing / BE UI
- **Reference:** IApprovalProvider (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IApprovalProvider
- **Unity design:** BE is front door, not a workflow execution engine. Use approved bank identity integration.
- **Open gap:** SSO/roles must be supplied by internal owners.
- **Acceptance:** Unauthorized users cannot publish, intervene, or view restricted processes.
- **Dependencies:** SEC-03

### BE-02 — Workflow authoring through embedded BPMN web modeler

**Owner:** BE Website  |  **Area:** Business Enablement  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D08

- **BPMN / host:** BPMN XML / BE UI
- **Reference:** bpmn-js toolkit (External library); https://bpmn.io/toolkit/bpmn-js/
- **Unity design:** Integrate existing BPMN 2 web editor rather than build canvas from scratch.
- **Open gap:** Bank review of library/license; supported-element palette.
- **Acceptance:** Create and save two unrelated valid BPMN definitions without touching BOB code.
- **Dependencies:** COR-02

### BE-03 — BPMN palette restricted to supported subset + server validation

**Owner:** BE / BOB  |  **Area:** Business Enablement  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D08

- **BPMN / host:** supported subset / BE UI + API
- **Reference:** BpmnConverter (Vendor API concept); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/BpmnConverter
- **Unity design:** Never permit deployment of BPMN constructs unsupported by BOB.
- **Open gap:** Modeler UI and server semantic validator can disagree.
- **Acceptance:** Unsupported inclusive gateway cannot publish; error identifies element.
- **Dependencies:** COR-03

### BE-04 — Draft / publish / approve workflow version with actor provenance

**Owner:** BE / Registry  |  **Area:** Business Enablement  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D06

- **BPMN / host:** process / BE UI + API
- **Reference:** Designer (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow/Designer
- **Unity design:** Author and optionally approve immutable definitions, not edit active running version.
- **Open gap:** Enterprise separation of duties may require different author and approver.
- **Acceptance:** Version V2 publish logged; V1 in-flight instance unchanged; required approval gate enforced.
- **Dependencies:** HST-06

### BE-05 — Start configured workflow and inspect run inputs

**Owner:** BE Website  |  **Area:** Business Enablement  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D09

- **BPMN / host:** startEvent / BE UI + API
- **Reference:** WorkflowRuntime (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime
- **Unity design:** Allow authorized users to start deployed processes with validated typed inputs.
- **Open gap:** Prevent replay/duplicate starts and leaking sensitive inputs.
- **Acceptance:** Start selected published version, show process ID, reject invalid parameters.
- **Dependencies:** HST-03

### BE-06 — Live workflow state and cross-capability timeline

**Owner:** BE Website  |  **Area:** Business Enablement  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D09

- **BPMN / host:** all / BE UI + API
- **Reference:** RealTimeTrackingExtensions (Vendor API concept); https://api.workflowengine.io/realtime-tracking-plugin/
- **Unity design:** Central query view presents status; capabilities emit correlated activity status.
- **Open gap:** Avoid false realtime claim; polling fallback for demo.
- **Acceptance:** Timeline shows task succeeded/failed plus email notification submitted/failed.
- **Dependencies:** OPS-01

### BE-07 — Investigate failures by correlation / process ID

**Owner:** BE Website  |  **Area:** Business Enablement  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D09

- **BPMN / host:** all / BE UI + API
- **Reference:** ProcessHistoryItem (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ProcessHistoryItem
- **Unity design:** Bank reviewer can reconstruct one process across AMIE, BOB, Kafka, and capabilities.
- **Open gap:** Sensitive exception output must be redacted.
- **Acceptance:** Search by process ID; show actor, decision version, message, outcome, timestamps.
- **Dependencies:** AUD-01

### BE-08 — AMIE rule-set reference picker in workflow editor

**Owner:** BE Website  |  **Area:** Business Enablement  |  **Roadmap priority:** P0  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D08

- **BPMN / host:** businessRuleTask / BE UI + API
- **Reference:** CodeActionDefinition (Vendor API contrast); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/CodeActionDefinition
- **Unity design:** BE selects approved AMIE rule-set ID and version; no hardcoded C# expressions.
- **Open gap:** Full AMIE designer deferred.
- **Acceptance:** Change selected approved rule version; published workflow binds expected version.
- **Dependencies:** AM-03

### BE-09 — Restricted retry / intervention controls

**Owner:** BE Website  |  **Area:** Business Enablement  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D09

- **BPMN / host:** serviceTask / BE UI + API
- **Reference:** ResumeParams (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ResumeParams
- **Unity design:** Only when selected pilot needs manual intervention; audit every decision.
- **Open gap:** Unsafe restart must not duplicate email or external side effects.
- **Acceptance:** Authorized retry has reason code and audit; unauthorized retry rejected.
- **Dependencies:** BE-06

### BE-10 — Human approval inbox (basic)

**Owner:** BE Website  |  **Area:** Business Enablement  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D09

- **BPMN / host:** userTask / BE UI + API
- **Reference:** IApprovalProvider (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IApprovalProvider
- **Unity design:** Simple approvals only if selected pilot requires human gating.
- **Open gap:** Full forms, delegation and escalation later.
- **Acceptance:** Assigned actor approves/rejects; audit captures actor/time/decision.
- **Dependencies:** SEC-03

### MAIL-01 — Kafka notification request consumer

**Owner:** Email Capability  |  **Area:** Email Capability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D07

- **BPMN / host:** serviceTask/message / Email microservice
- **Reference:** IWorkflowActionProvider (Vendor API contrast); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider
- **Unity design:** BOB publishes a typed Kafka notification request; BOB Core never sends SMTP/email directly.
- **Open gap:** Topic/contract approved and idempotent.
- **Acceptance:** Email worker consumes notification.email.requested with correlation IDs.
- **Dependencies:** KAF-01

### MAIL-02 — Evaluate approved AMIE email policies locally

**Owner:** Email Capability / AMIE  |  **Area:** Email Capability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D07

- **BPMN / host:** businessRuleTask / Embedded AMIE
- **Reference:** IWorkflowRuleProvider (Vendor API contrast); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowRuleProvider
- **Unity design:** Local rules select template, recipient eligibility, routing and restrictions.
- **Open gap:** Sensitive templates and destinations must be validated.
- **Acceptance:** Policy change through approved AMIE configuration changes behavior without rebuilding worker.
- **Dependencies:** AM-01

### MAIL-03 — Enterprise-approved mail transport adapter

**Owner:** Email Capability  |  **Area:** Email Capability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D07

- **BPMN / host:** serviceTask / Email microservice
- **Reference:** IWorkflowPlugin (Vendor plugin contrast); https://api.workflowengine.io/core/OptimaJet.Workflow.Plugins/IWorkflowPlugin
- **Unity design:** Capability owns integration with sanctioned mail transport, secrets, rate limits.
- **Open gap:** Provider access and sandbox credentials not confirmed.
- **Acceptance:** One test email submitted via bank-approved provider or instrumented sandbox mock.
- **Dependencies:** MAIL-01

### MAIL-04 — Notification result events and BOB correlation

**Owner:** Email Capability / BOB  |  **Area:** Email Capability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D07

- **BPMN / host:** messageCatch / Email microservice + Kafka
- **Reference:** MessageCatchEvent (Vendor API concept); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/MessageCatchEvent
- **Unity design:** Publish notification.email.submitted or failed; central process correlates result.
- **Open gap:** Do not equate provider acceptance with delivered-to-inbox.
- **Acceptance:** BE displays correct result event, attempts, and correlated workflow ID.
- **Dependencies:** MAIL-03

### MAIL-05 — Duplicate-request suppression + safe retry

**Owner:** Email Capability  |  **Area:** Email Capability  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks bank release  |  **Packet:** D07

- **BPMN / host:** serviceTask / Email microservice
- **Reference:** BulkOperationOptions (Vendor API inspiration); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/BulkOperationOptions
- **Unity design:** Kafka at-least-once must not trigger repeated email due to redelivery.
- **Open gap:** Guarantee limited by mail-provider idempotency.
- **Acceptance:** Repeated request event produces one logical send; retry does not silently double-send.
- **Dependencies:** PST-08

### MAIL-06 — Template versioning and safe recipient data

**Owner:** Email Capability / AMIE  |  **Area:** Email Capability  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D07

- **BPMN / host:** businessRuleTask / Email microservice
- **Reference:** CodeActionParameterDefinition (Vendor API inspiration); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/CodeActionParameterDefinition
- **Unity design:** Template/version and recipient policy are configuration, not BOB hardcode.
- **Open gap:** Content review, PII minimization, controlled rendering.
- **Acceptance:** Test template rendering with approved dummy recipients and no secrets in Kafka.
- **Dependencies:** MAIL-02

### AUD-01 — Canonical cross-platform audit/event envelope

**Owner:** Unity Contracts  |  **Area:** Audit & Trace  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks bank release  |  **Packet:** D00

- **BPMN / host:** all / Shared
- **Reference:** ProcessHistoryItem (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ProcessHistoryItem
- **Unity design:** Use EventId, CorrelationId, CausationId, ProcessId, DefinitionVersion, RuleVersion, Actor, Activity, Capability, Outcome, UTC timestamp.
- **Open gap:** Agree message/trace schema before Devin parallel builds.
- **Acceptance:** One demo execution has contiguous provenance across BE/BOB/AMIE/Kafka/email.
- **Dependencies:** OPS-01

### AUD-02 — Write-once-oriented durable audit history with an authorized audit store

**Owner:** Audit Capability  |  **Area:** Audit & Trace  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D10

- **BPMN / host:** all / Audit-owned MSSQL or bank collector
- **Reference:** ProcessTransitionHistoryEntity (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Entities/ProcessTransitionHistoryEntity
- **Unity design:** Persist transition/command/approval records in an audit-owned schema or bank collector; BOB-owned MSSQL checkpoints stay separate.
- **Open gap:** Tamper evidence, retention, access controls need bank design review.
- **Acceptance:** Actor/decision/timestamp/old-new version/outcome queryable after restart.
- **Dependencies:** PST-05

### AUD-03 — Propagation of W3C trace context through Kafka headers

**Owner:** Unity Contracts / Capabilities  |  **Area:** Audit & Trace  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks bank release  |  **Packet:** D10

- **BPMN / host:** serviceTask / Shared
- **Reference:** IProcessLogProvider (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Logging/IProcessLogProvider
- **Unity design:** Propagate traceparent/correlation/causation headers for end-to-end linkage.
- **Open gap:** Avoid sensitive identifiers in trace attributes.
- **Acceptance:** Trace starts in BE and reaches downstream mail and outcome event.
- **Dependencies:** AUD-01

### AUD-04 — Capture business decision/rule version and outcome

**Owner:** AMIE / Audit  |  **Area:** Audit & Trace  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D10

- **BPMN / host:** businessRuleTask / Embedded + central
- **Reference:** ExpressionsInvoker (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.CodeActions/ExpressionsInvoker
- **Unity design:** Audit AMIE decision name/version/hash and result category without leaking inputs.
- **Open gap:** Explainability fields and disclosure policy not yet agreed.
- **Acceptance:** Change rule configuration; both versions and decisions are distinguishable in audit.
- **Dependencies:** AM-03

### AUD-05 — Definition change author, reviewer, approval and deployment evidence

**Owner:** Registry / BE  |  **Area:** Audit & Trace  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D10

- **BPMN / host:** process / Control plane
- **Reference:** DesignerRequest (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Designer/DesignerRequest
- **Unity design:** Every configuration publication ties to an authorized actor, reviewer/control reference and artifact hash.
- **Open gap:** Control/CAs and approver identities must be supplied by owners.
- **Acceptance:** Reconstruct who changed workflow, what, when, approved by whom, and deployed where.
- **Dependencies:** BE-04

### AUD-06 — Least-privilege evidence query and sensitive-data redaction

**Owner:** BE / Audit  |  **Area:** Audit & Trace  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D10

- **BPMN / host:** all / BE UI + API
- **Reference:** ProcessLogEntry (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Logging/ProcessLogEntry
- **Unity design:** Audit evidence is useful without exposing passwords, personal data, or token payloads.
- **Open gap:** Bank data classification and retention policy unknown.
- **Acceptance:** Unauthorized actor cannot query evidence; no passwords or connection strings in logs.
- **Dependencies:** AUD-02

### AUD-07 — Evidence export to approved bank governance process

**Owner:** BE / Audit  |  **Area:** Audit & Trace  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D10

- **BPMN / host:** all / BE UI + API
- **Reference:** IProcessLogProvider (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Logging/IProcessLogProvider
- **Unity design:** Export controlled trace/audit bundle if audit team requires; not mandatory to show filter/screen.
- **Open gap:** File handling, signatures, records retention need review.
- **Acceptance:** Reviewer extracts scoped correlation history with source provenance.
- **Dependencies:** AUD-06

### GOV-01 — Map bank controls and CAs to testable technical evidence

**Owner:** Release Governance  |  **Area:** Compliance & Controls  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D11

- **BPMN / host:** N/A / Governance
- **Reference:** ApprovalHistoryItem (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/ApprovalHistoryItem
- **Unity design:** Use internal control catalog and CA identifiers supplied by owners; no fabricated compliance claims.
- **Open gap:** Actual Wells Fargo requirements and CAs not provided.
- **Acceptance:** Each mandated control has owner, implementation, test, evidence, exception and disposition.
- **Dependencies:** AUD-01

### GOV-02 — RBAC and authorization enforcement on APIs and BE actions

**Owner:** BE / BOB API  |  **Area:** Compliance & Controls  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D11

- **BPMN / host:** userTask / BE/API
- **Reference:** ActorDefinition (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ActorDefinition
- **Unity design:** Least privilege for design, approve, publish, run, retry, and audit read.
- **Open gap:** Bank SSO/identity integration unknown.
- **Acceptance:** Role checks on backend deny unauthorized operations, not UI-only gates.
- **Dependencies:** SEC-03

### GOV-03 — Release evidence gate, change record and control approval

**Owner:** Release Governance  |  **Area:** Compliance & Controls  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D15

- **BPMN / host:** N/A / Pipeline
- **Reference:** ProcessHistoryItem (Vendor API inspiration); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ProcessHistoryItem
- **Unity design:** DEV demo completion is not release authorization; approved security/CA gates decide.
- **Open gap:** Control owners, change review, vulnerability scans and DLP approvals unknown.
- **Acceptance:** Go/no-go checklist prevents production promotion if required signoffs missing.
- **Dependencies:** GOV-01

### GOV-04 — Service identity, approved secrets store, protected config

**Owner:** Platform Security  |  **Area:** Compliance & Controls  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D11

- **BPMN / host:** N/A / Infrastructure
- **Reference:** WorkflowRuntimeSettings (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeSettings
- **Unity design:** Use sanctioned secret management, encryption and service authentication from bank platform.
- **Open gap:** No bank credentials or infra details provided.
- **Acceptance:** No secrets in repository/artifacts; isolated service identity demonstrated.
- **Dependencies:** SEC-04

### PLT-01 — Versioned common event schemas / message contract registry

**Owner:** Unity Contracts  |  **Area:** Platform Integration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D00

- **BPMN / host:** messageFlow / Shared
- **Reference:** MessageCatchEvent (Vendor API concept); https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/MessageCatchEvent
- **Unity design:** BE, BOB, AMIE and capabilities share one stable envelope and typed command/result contracts.
- **Open gap:** Avoid incompatible event payloads across parallel Devin tasks.
- **Acceptance:** Contract tests pass for publisher and consumer independently.
- **Dependencies:** AUD-01

### PLT-02 — Capability activity catalog and dependency resolution

**Owner:** Unity Contracts / Capabilities  |  **Area:** Platform Integration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D02

- **BPMN / host:** serviceTask / Shared
- **Reference:** ICustomActivityProvider (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ICustomActivityProvider
- **Unity design:** BE designer lists authorized named capability activities and input schemas; execution stays local in owner.
- **Open gap:** Activity availability mismatch between design and deployment.
- **Acceptance:** Unsupported/unregistered activity is rejected at publication.
- **Dependencies:** COR-07

### PLT-03 — DEV environment bootstrap and deployable service manifests

**Owner:** Platform DevOps  |  **Area:** Platform Integration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D16

- **BPMN / host:** N/A / DEV
- **Reference:** WorkflowRuntimeConfigurationExtension (Vendor API inspiration); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeConfigurationExtension
- **Unity design:** Deploy BE, BOB, AMIE config, Kafka, email, audit, and pilot adapters independently.
- **Open gap:** DEV cluster access, CI credentials, Kafka topics, SQL grants TBD.
- **Acceptance:** One repeatable DEV deployment and health probe per service.
- **Dependencies:** PLT-01

### PLT-04 — Cross-service acceptance and failure-injection test harness

**Owner:** Platform QA  |  **Area:** Platform Integration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D14

- **BPMN / host:** N/A / DEV
- **Reference:** TestTracer (Vendor API inspiration); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.TestTrace/TestTracer
- **Unity design:** Exercise process -> AMIE -> Kafka -> capability -> outcome -> BE history.
- **Open gap:** Vendor API does not supply test cases.
- **Acceptance:** Success, rule denial, failed email, duplicate event and app restart tested.
- **Dependencies:** PLT-03

### PLT-05 — Health checks, build scans and environment promotion guard

**Owner:** Platform DevOps  |  **Area:** Platform Integration  |  **Roadmap priority:** P0  |  **Nov 30:** Release-gate  |  **Release impact:** Blocks bank release  |  **Packet:** D15

- **BPMN / host:** N/A / DEV
- **Reference:** WorkflowRuntimeStartResult (Vendor API inspiration); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeStartResult
- **Unity design:** Pipeline blocks known-failing tests and gathers provenance of build/deployment.
- **Open gap:** Bank CI and scanning controls must be confirmed.
- **Acceptance:** Build/scan logs and deployment commit traceable for demonstrated release candidate.
- **Dependencies:** PLT-03

### PLT-06 — Backpressure, DLQ visibility and safe event redrive

**Owner:** Kafka / Capabilities  |  **Area:** Platform Integration  |  **Roadmap priority:** P1  |  **Nov 30:** Conditional  |  **Release impact:** Depends on app  |  **Packet:** D07

- **BPMN / host:** messageFlow / Central+capability
- **Reference:** IWorkflowActionProvider (Vendor API inspiration); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider
- **Unity design:** Bounded consumers with visible failure handling; advanced dashboards optional for demo.
- **Open gap:** Replay/dedup must be proven if selected app drives failures.
- **Acceptance:** Rejected event visible with correlation; controlled reprocess does not duplicate side effect.
- **Dependencies:** KAF-02

### PLT-07 — Pilot A and Pilot B integration acceptance contracts

**Owner:** Solution Teams  |  **Area:** Platform Integration  |  **Roadmap priority:** P0  |  **Nov 30:** Must-demo  |  **Release impact:** Blocks demo  |  **Packet:** D12

- **BPMN / host:** N/A / DEV
- **Reference:** IWorkflowActionProvider (Vendor API concept); https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider
- **Unity design:** Two independent real applications consume platform; no application logic compiled into BOB/AMIE cores.
- **Open gap:** Owners must select pilots and define data/access needs immediately.
- **Acceptance:** At least one real pilot runnable; second if ready; both remain separately configured.
- **Dependencies:** PLT-03

## 11. BPMN coverage boundary

- **BPMN XML definitions — November: Must-demo.** Canonical BPMN 2.0.2 source; compile to shared IR. **Proof:** Validate XML + semantic model before publish.
- **Start event (none) — November: Must-demo.** Start initial token deterministically. **Proof:** One start event => one workflow instance.
- **End event (none) — November: Must-demo.** Consume token; complete when no active tokens remain. **Proof:** Parallel branches finish according to token rules.
- **Service task — November: Must-demo.** Invoke registered local DI activity; no central remote call per step. **Proof:** A registered capability-local handler executes with deterministic attempt semantics.
- **Exclusive gateway — November: Must-demo.** Use AMIE result or approved expressions for branching. **Proof:** Exactly one path, default branch checks.
- **Parallel gateway — November: Conditional.** Implement token fork/join correctly. **Proof:** Parallel fixture with branch delays synchronizes once.
- **Business rule task — November: Must-demo.** Bind AMIE rule invocation explicitly. **Proof:** Rule task invokes cached versioned AMIE rule.
- **Sequence flows / conditions — November: Post-Nov.** Source/target refs and deterministic transition semantics. **Proof:** Invalid connections rejected; conditions evaluated correctly.
- **BPMNDI visual geometry — November: Post-Nov.** Keep diagram representation separate from runtime IR. **Proof:** Import/export geometry without changing flow.
- **Embedded subprocess — November: Post-Nov.** Explicit nested variable scope and lifecycle semantics. **Proof:** Nested fixture validates exit/cancel propagation.
- **Call activity — November: Conditional.** Invoke separately versioned reusable workflow definition. **Proof:** Call referenced pinned definition exactly once.
- **Multi-instance sequential — November: Post-Nov.** Sequential iteration with item scope. **Proof:** 100-item sequence processes once in order.
- **Terminate end event — November: Post-Nov.** Terminate all tokens in correct scope. **Proof:** Parallel sibling tasks receive cancellation.
- **Timer start/catch — November: Conditional.** Durable timer wakeup using MSSQL. **Proof:** Restart/failover does not drop or double-fire timer.
- **Message catch — November: Must-demo.** Explicit Kafka correlation and durable wait. **Proof:** Wrong message does not advance instance.
- **Receive task — November: Post-Nov.** Wait on correlated message safely. **Proof:** Duplicate receipt dedupes.
- **Send task / message throw — November: Post-Nov.** Outbound event via Kafka/outbox, not BPMN runtime transport itself. **Proof:** SQL commit + eventual event delivery.
- **Event-based gateway — November: Post-Nov.** Atomic competing waits; first winner cancels alternatives. **Proof:** Simultaneous timer/message selects one.
- **Inclusive gateway split/join — November: Post-Nov.** Must implement actual inclusive join if accepted. **Proof:** Activated-path join cases incl nested splits.
- **Boundary timer/error — November: Conditional.** Handle interrupting and noninterrupting semantics explicitly. **Proof:** Task timeout cancels only when configured.
- **User task — November: Conditional.** Durable human task with assignment and authorized completion. **Proof:** Suspends for approval; resumes after authorized action.
- **Parallel multi-instance — November: Post-Nov.** Bounded fanout applies generically; each capability enforces its own resource and API quotas. **Proof:** Concurrency cap observed; recover partial failures.
- **Compensation — November: Post-Nov.** Register and invoke safe compensating actions. **Proof:** Compensation order and idempotency fixture.
- **Error / escalation events — November: Post-Nov.** Structured error propagation across activity scopes. **Proof:** Error handler catches only matching errors.
- **Signal event — November: Post-Nov.** Distinct broadcast model if justified. **Proof:** Subscriptions and delivery semantics tested.
- **Conditional event — November: Post-Nov.** Controlled condition triggering without polling explosion. **Proof:** State change triggers exactly once.
- **Event subprocess — November: Post-Nov.** Define scope interruption only if use case demands. **Proof:** Interrupting/noninterrupting fixture.
- **Pools/lanes/message flows — November: Post-Nov.** Keep capability boundaries; Kafka transports interactions. **Proof:** Cross-pool workflow uses explicit topic contracts.
- **Complex gateway — November: Post-Nov.** Reject until justified by actual workflows. **Proof:** Deployment validation fails with precise diagnostic.
- **Ad-hoc subprocess — November: Post-Nov.** Not in first supported subset. **Proof:** Deployment validation fails with precise diagnostic.
- **Arbitrary script task — November: Post-Nov.** Allow preapproved handler only, never arbitrary script. **Proof:** No user-supplied C# execution.

## 12. Risk and control register

- **G-01 — Definition subset and conformance claim [High].** Question: Which BPMN 2.0.2 constructs are supported in v1? Action: Freeze P0/P1 subset; comprehensive fixtures.
- **G-02 — Token flow and parallel joins [Critical].** Question: What state model supports concurrent forks and recovery? Action: Document token/instance model; run fork/join stress tests.
- **G-03 — Version pin across workflow and rule sets [High].** Question: What happens when rules change mid-process? Action: Persist rule version/hash per instance or task.
- **G-04 — How do activities bind without networking? [High].** Question: How is DI scope resolved safely in embedded host? Action: Proof via two distinct capability-local activities and registry outage.
- **G-05 — What expressions are allowed? [Critical].** Question: Can a rule execute arbitrary code or consume unlimited resources? Action: Constrained interpreter and quotas, never execute arbitrary C#.
- **G-06 — Call activity target version [High].** Question: Can parent and child process versions drift? Action: Pin call target and validate dependency manifest.
- **G-07 — Package and signature format [High].** Question: How are compatible approved definitions shipped to capabilities? Action: Package manifest + integrity check + atomic swap.
- **G-08 — Memory-only vs durable support [High].** Question: When may embedded workflows block/await timers? Action: Host capability matrix and refusal to run unsafe waits.
- **G-09 — Schema and transaction boundaries [Critical].** Question: How do state checkpoints and outbox commits interact? Action: Single SQL transaction per durable transition + outbox.
- **G-10 — Concurrency ownership [Critical].** Question: What prevents two central workers executing same instance? Action: Lease + fencing + rowversion + crash tests.
- **G-11 — Correlation and duplicate messages [Critical].** Question: How do incoming events map to the right wait? Action: Correlation key, inbox dedupe, explicit subscriptions.
- **G-12 — Unknown side effects after crash [Critical].** Question: Did a downstream capability action succeed before its outcome was checkpointed? Action: Idempotency and reconciliation callback contract.
- **G-13 — High-volume workload execution granularity [High].** Question: One process instance per item, batch or business transaction? Action: Benchmark multiple workflow types and granularities with bounded parallelism.
- **G-14 — Human task contract [Medium].** Question: How are assignment, completion, auth, forms versioned? Action: User task state machine and BE contract.
- **G-15 — Inclusive join correctness [High].** Question: How to handle nontrivial activated-path synchronization? Action: Do not enable until normative fixtures pass.
- **G-16 — Interrupting vs noninterrupting boundary events [High].** Question: Can boundary handler create token without cancelling task? Action: Explicit event-subscription semantics, negative fixtures.
- **G-17 — Safe offline behavior [High].** Question: Which revoked policies cannot be executed offline? Action: Define maximum stale age and fail-closed rules.
- **G-18 — Interoperability with standard modelers [Medium].** Question: Will vendor BPMN XML extensions be accepted? Action: Strict core model + documented extension policy.
- **G-19 — API type != execution semantics [High].** Question: Which OptimaJet features actually run vs just deserialize? Action: Source API -> vendor behavior -> our test chain.
- **G-20 — Shared DB meaning [Medium].** Question: Is shared data a central Unity DB or legacy shared applications? Action: Catalog ownership and choose API vs direct EF.
- **G-21 — Timers, leases and transaction SQL load [High].** Question: How many workers/instances before locks or IO dominate? Action: SQL load test, indexes and recovery injection.
- **G-22 — Copyright/licensing boundaries [Medium].** Question: Are any vendor assemblies/licenses to be used? Action: Use API docs as references only, evaluate licenses separately.
- **G-23 — Should AMIE support DMN decision tables? [Medium].** Question: DMN 1.6 complements BPMN but has not been selected for Unity. Action: Evaluate import/export/interpreter scope without coupling to BOB.
- **G-24 — Designer not connected to publishable BPMN subset [Critical].** Question: Can BE author, server-validate, approve and publish actual executable diagrams? Action: Use reviewed bpmn-js toolkit; restrict palette; reject unsupported semantics.
- **G-25 — No unified process/capability progress view [Critical].** Question: Can users reconstruct cross-capability states and reasons? Action: Contract first; BE status+timeline query; poll initially if streaming is costly.
- **G-26 — Vendor built-in email conflicts with Unity service boundary [Critical].** Question: How do BOB, Kafka, AMIE and Email Capability exchange requests and outcome? Action: Contract-driven Email Capability with local rules and idempotency.
- **G-27 — Wells Fargo control/CAs catalog and owners not supplied [Critical].** Question: Which control IDs and CAs are release-blocking? Action: Obtain actual internal control requirements and reviewers; no self-declared compliance.
- **G-28 — Audit envelope and sensitive-data minimization not agreed [Critical].** Question: Which fields are mandatory and which are restricted? Action: Freeze common envelope and audit redaction before parallel Devin jobs.
- **G-29 — Enterprise SSO/role integration not selected [Critical].** Question: Which bank-approved identity and backend authorization mechanism? Action: Integrate sanctioned SSO/auth; demonstration cannot bypass release security controls.
- **G-30 — No practical latency or throughput envelope [High].** Question: Will rule/persistence overhead and Kafka dominate? Action: Benchmark local rule evaluation, parallelism, events, SQL queries under demo load.
- **G-31 — Timebox until November 30 may be insufficient for new BPMN engine [Critical].** Question: What proven subset can be complete with correct semantics? Action: Freeze narrow subset; choose no new element unless pilot needs it; gate MVP after tests.
- **G-32 — No pilot applications and owners selected [Critical].** Question: Which 1-2 real app teams can provide endpoints and datasets now? Action: Choose readiness-based Pilot A/B; keep app details outside BOB Core.
- **G-33 — Kafka topics, DEV MSSQL grants, deployment environment unknown [Critical].** Question: Can all services deploy with independent health checks? Action: Secure environments and access at outset; integration on day two.
- **G-34 — Browser BPMN editor dependency requires review [High].** Question: Is bpmn-js/license and package supply chain approved by bank? Action: Review permitted packages/licenses; otherwise fall back to BPMN XML upload and viewer.
- **G-35 — Duplicate email after redelivery or crash [Critical].** Question: Can a notification be submitted twice? Action: Persist idempotency and distinguish submitted from delivered; provider-level caveat.
- **G-36 — Audit contains sensitive data or secrets [Critical].** Question: Could payload/logging expose account or recipient details? Action: Store metadata and references; redact payloads; access-controlled evidence.
- **G-37 — Definition author may self-approve a regulated workflow [High].** Question: Is maker-checker approval mandatory? Action: Enforce role-specific approvals when required and audit approved version.
- **G-38 — Full BPMN / forms / real-time push absorbs all delivery time [High].** Question: What can be deferred without blocking pilot? Action: Defer advanced constructs, custom designer, rich forms, calendar and localization.
- **G-39 — Email provider accepted a message but not confirmed delivery [High].** Question: What lifecycle should BE show? Action: Expose requested/accepted/submitted/failed; never claim delivered without evidence.

## 13. Workloads — distinct from Unity platform components

| Workload | Status | Platform contract |
| --- | --- | --- |
| CMDB enrichment | User-provided illustration / possible Unity workload | BOB runs same general workflow primitives with different data and activity handlers. |
| Policy Drift | Intended workload; detailed requirements pending | Policy-specific BPMN + rule configuration executes without modifying BOB Core. |
| Legacy application modernization | Intended portfolio / many workflows | Two different legacy workflows execute against stable platform interfaces. |
| Future Unity applications | Extensible goal | Onboard a novel workflow and rule set without changing shared core binaries. |
| INVARIANT: WORKLOADS CONSUME THE PLATFORM - THEY DO NOT DEFINE THE PLATFORM | None | None |
| The feature gap matrix tracks generic BOB execution, BPMN semantics, MSSQL durability, configuration distribution, AMIE integration, Kafka coordination and developer-facing extension contracts. Each actual application is specified separately after the platform can execute independent configurations. Example applications may be optional acceptance fixtures; they are not prerequisites for BOB Core. | None | None |
| Provenance: user-established Unity platform/workload distinction (2026-11-10); scenario details above are illustrative, not finalized implementation contracts. | None | None |
| Pilot Application A | Must select immediately; owner/contract TBD | BE starts; activities execute; trace/audit and completion visible. |
| Pilot Application B | Conditional on readiness; owner/contract TBD | Second app runs without modifications to BOB/AMIE engine binaries. |

## 14. Source and evidence boundaries

- **User-established architecture:** BE, BOB shared core and two execution hosts, embedded AMIE, Kafka, capability microservices, database access ownership, regulated bank controls and deadline.
- **Supplied reference:** `workflowengine-api-docs.md` from OptimaJet Workflow Engine .NET; documented classes are evidence of available API shapes, not tested behavior or source-code license.
- **External implementation option:** bpmn-js is a browser BPMN toolkit; using it must pass the bank license, security and supply-chain review.
- **Normative BPMN scope:** OMG BPMN 2.0.2; support only explicit validated, conformance-tested constructs.
- **No code status claim:** This document defines backlog, interfaces and evidence. No DEVIN coding, compilation, integrated demo or bank approval has been verified.

### Reference URLs

- **SRC-01 User-provided OptimaJet API capture:** https://api.workflowengine.io/. Uploaded reference; API type existence and signatures, not conformance proof.
- **SRC-02 OptimaJet Core API:** https://api.workflowengine.io/core/. API structure and extension points.
- **SRC-03 OptimaJet BPMN API:** https://api.workflowengine.io/bpmn-plugin/. Model types do not imply executable semantics.
- **SRC-04 OptimaJet MSSQL API:** https://api.workflowengine.io/sql-server/. Only desired BOB persistence provider.
- **SRC-05 OptimaJet Web API:** https://api.workflowengine.io/web-api/. Reference for later administrative API; not mandatory on embedded path.
- **SRC-06 OptimaJet BPMN plugin overview:** https://docs.workflowengine.io/plugins/bpmn-plugin/. Behavioral clarification from vendor product docs; checked 2026-11-10.
- **SRC-07 OptimaJet BPMN supported elements:** https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/. Behavioral reference: unsupported behavior can be retained only as shape.
- **SRC-08 OMG BPMN 2.0.2 standard:** https://www.omg.org/spec/BPMN/2.0.2/About-BPMN/. Normative target; BOB compliance must be scoped to tested subset.
- **SRC-10 OMG DMN 1.6 formal standard:** https://www.omg.org/spec/DMN/1.6. Formal DMN 1.6 September 2026; proposed evaluation only, not a BOB requirement.
- **SRC-09 Unity architecture working baseline:** Internal user direction / bank owner input required. User-established architectural requirements; not third-party evidence.
- **SRC-11 bpmn-js official toolkit:** https://bpmn.io/toolkit/bpmn-js/. External UI implementation option, not runtime engine.
- **SRC-12 bpmn-js GitHub:** https://github.com/bpmn-io/bpmn-js. Review browser editor license and vendor dependencies before bank adoption.
- **SRC-13 OMG BPMN 2.0.2:** https://www.omg.org/spec/BPMN/2.0.2. Executable subset must be validated, not inferred from drawing library.
- **SRC-14 Unity platform instruction:** Internal user direction / bank owner input required. User stated; internal compliance catalog not yet provided.
- **SRC-15 November 30 delivery target:** Internal user direction / bank owner input required. Schedule target, not demonstrated readiness.
