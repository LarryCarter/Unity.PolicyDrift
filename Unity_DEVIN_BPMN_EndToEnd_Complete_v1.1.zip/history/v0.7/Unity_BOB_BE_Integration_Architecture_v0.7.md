# Unity / BOB / BE / AMIE / Capabilities: Integrated Design Record v0.7

**Date:** 2026-11-11  |  **Target:** November 30, 2026 demonstrable MVP  |  **Status:** Proposed integration contract for reconciliation with existing repository and bank controls.

## 0. Authority, scope, and non-goals

User-established direction:

1. Unity is a configurable application platform. BOB is a reusable BPMN 2.0 workflow engine, not a DCMS-specific program.
2. AMIE is substantially implemented; adapt to its real public interfaces after inspecting the repository. Do not duplicate its rule evaluator.
3. Capability microservices implement reusable primitives and advertise them through a common library/manifest. BE composes them through BOB and AMIE without service code changes when all necessary primitives already exist.
4. BOB has one core runtime with central and embedded hosts. Central BOB coordinates capabilities over Kafka; embedded BOB+AMIE execute local subflows in the capability boundary without a per-step remote call.
5. BE is Blazor and must support strong visual process design, business-friendly status, operational process controls, lifecycle management, audit, and controlled releases.
6. BOB persistence is MSSQL-only; capability-owned data may have its own owner and technology. Do not impose a global shared database.
7. All BE and platform functions must have secure, automation-testable APIs. Frontend-only behaviors are not authoritative.
8. Separate definition authors, execution users, operators, approvers, release personnel, and auditors by resource-scoped authorization.
9. Operations must be able to activate the identical approved configuration through DEV/UAT/PROD without developer production access, using trusted environment bindings and real bank change/control approval.
10. Use OptimaJet's published API as a feature-discovery reference, not a proprietary implementation template. Favor first-party/previously-approved dependencies; licensing or review remains a release gate.
11. CVIS workloads (DCMS, Hygiene, Enrichment, Onboarding, Policy Drift, PAM compliance) validate platform reuse; none belongs in BOB Core.

**Explicit non-goals for November:** all BPMN 2.0 behavior, migration of running instances between definition versions, cross-database provider support, custom high-volume drag/drop designer engine from scratch, full ServiceNow integration, AutoSys integration, or arbitrary user-script execution. These stay on a roadmap unless a selected pilot proves essential.

## 1. System topology and execution boundaries

```mermaid
flowchart LR
  U[Users: business / designer / operator / auditor] --> BE[BE Blazor]
  BE --> API[Authorized BE/API facade]
  API --> REG[Capability registry + workflow catalog]
  API --> PUB[BOB definition / package service]
  API --> VIEW[Status + audit query API]
  PUB --> SQL[(MSSQL: definitions / runtime / history)]
  VIEW --> SQL
  API --> START[Central BOB host]
  START --> K[(Kafka)]
  K --> CAP[Capability microservices]
  CAP --> LOCAL[Embedded BOB runtime]
  LOCAL --> AMIE[Embedded AMIE evaluator]
  LOCAL --> OPS[Registered, allowlisted handlers]
  CAP --> K
  K --> START
  CAP --> OUT[Outcome / evidence events]
  OUT --> AUDIT[(MSSQL append-only audit)]
  START --> AUDIT
  AUDIT --> VIEW
  VIEW --> PUSH[Authorized SignalR / SSE updates]
  PUSH --> BE
```

- The **control plane** registers/publishes definitions, permissions, manifests, package hashes, bindings, and release policy.
- The **execution plane** uses approved pinned versions; it must not depend on the control plane for each local activity or AMIE evaluation.
- **Central BOB** executes cross-capability processes with durable wait states and event correlation.
- **Embedded BOB** executes a local capability's subflows using approved operations. For local short operations an in-memory execution mode can be used; durable local execution is explicitly selectable when needed.
- **Kafka** transports commands/events, not live CLR calls, UI forms, or whole CSV files. Large files land in approved secure storage; messages carry authorized references and metadata.
- **Email** is an independent Email Capability that processes a Kafka notification command and returns delivery status. AMIE rules select recipients/templates/eligibility under approved policy; BOB does not own SMTP.

## 2. Reference user journeys and BE screens

| Surface | Who | User goal | Mandatory API | MVP |
|---|---|---|---|---|
| Workflow Library | Designer, viewer, operations | Search templates, inspect owner/status/version/change ID, clone approved template | List/get/version/history | P0 |
| BPMN Visual Designer | Designer | Draw supported BPMN, bind activities and inputs, validate, save draft | Draft CRUD, validation, import/export | P0 narrow subset |
| Capability Catalog | Designer, service owner | Discover approved operations and their data requirements | Registry read/contract health | P0 |
| Operation Binding Inspector | Designer | Bind inputs from upload/form/DB/AMIE/previous tasks; see errors and auth | Schema+binding validation | P0 |
| AMIE Rule Studio/Picker | Designer, rule owner | Reuse approved rules, map inputs/output; optionally edit by existing AMIE UI | Existing AMIE APIs | P0 reuse |
| Trigger Editor | Designer | Select manual upload/form/API/event/schedule trigger and schema | Trigger contract CRUD | P0 manual/API; schedule later |
| Business Work Queue | Business user | Start allowed tasks, upload, inspect only their batches/records/counts | Start, upload, summary, task actions | P0 |
| Operator Console | Operations | Inspect runs, pause/resume/cancel/retry/restart with reason and runbook | Run query + control commands | P0 safe subset |
| BPMN Run Monitor | Operations, support, authorized engineer | Inspect diagram overlay, activity statuses, traces | Run history/steps; push events | P0 basic |
| Audit/Controls Explorer | Auditor, control owner | Trace actor/change/rule/instance/ticket and export evidence | Audit query/export, runbook lookup | P0 basic |
| Release Center | Release/Operations | Promote immutable package via DEV/UAT/PROD binding/approval gates | Candidate/preflight/activate/rollback | P0 approved flow; no fake PROD actions |
| API Regression Console | QA/test owner | Discover endpoint contracts, execute tests using non-production fixtures | OpenAPI+test fixture APIs | P0 build/test pipeline; UI later |

**Two user-facing monitoring modes:**
- *Business summary:* batch number; total/queued/in progress/succeeded/failed/skipped; percent complete; result report; no need to expose BPMN.
- *Technical monitor:* BPMN activity overlay, command/event chains, retries, errors, AMIE rule versions, capability timings, and audit evidence.

## 3. BPMN 2.0 commitment and scope

- Use OMG BPMN 2.0.2 XML with BPMN DI layout for import/export; a **Unity extension namespace** may carry approved operation/rule bindings while preserving standard BPMN structure.
- Execution support and XML serialization are separate acceptance tests. An imported element is not executable merely because it has a model class or renders in BE.
- P0 *candidate subset*, finalized against pilot needs: start/end events, service tasks, business-rule tasks (invoke AMIE), exclusive gateways with validated conditions, sequence flows, simple call activities/subprocesses, **sequential multi-instance call activity if DCMS is the selected pilot** (one row at a time), durable waits for Kafka command outcomes, and error/termination outcome handling. Include basic timer event if required by pilot.
- P1: parallel gateway fork/join with correct token semantics, user tasks/approval wait states, timers, messages, signal events, **parallel** multi-instance/batch patterns, boundary events, compensation. Promote a particular feature to P0 only when a chosen demo needs it and automated conformance tests exist.
- Unsupported element: clearly mark in editor; reject publication as executable. Do not ignore it or silently execute a different interpretation.
- For BOB's central/embedded operation binding, prefer a stable `operationKey@contractVersion`; resolve through an allowlisted registry at publication and execution. No arbitrary class/method names or dynamic SQL from designer.

**Conformance criterion:** a known BPMN fixture passes XML parse/serialize round trip, graph validation, and a test of each supported element's actual runtime semantics. For gateways, assert which branch executes; for call activities, assert input/output and failure propagation; for Kafka waits, assert correlation and restart recovery.

## 4. Workflow definition and release lifecycle

**Draft -> In Review -> Approved -> Published -> Active -> Retired**. Rejected returns to Draft; Deprecated denotes an active version scheduled for retirement. Paused/Suspended describes a *run*, not the lifecycle of the definition. Draft revisions are editable; approved/published version content is immutable, addressed by `(workflowKey, version, packageDigest)`.

Rules:
1. A designer creates a draft or clones a version; the original remains immutable.
2. Each change records actor ID, UTC timestamp, source version, optional ticket during draft, diff/meaning, and revision number.
3. Review/publish/promotion requires an approved ServiceNow change ID or equivalent bank-recognized authorization, independent approver when bank control requires it, validated manifest dependencies, test evidence, and immutable artifact digest.
4. Operations installs the identical signed package in target environment; only allowlisted `EnvironmentBinding` references vary. No developer target secrets or PROD deployment rights.
5. Starting a new run pins workflow version, AMIE version dependencies, and capability operation contract versions. Running instances complete against pinned versions; **mid-flight version migration is deferred** by explicit decision.
6. Retirement prohibits new starts but does not delete history or invalidate in-flight runs. Existing active runs remain visible and governed.
7. Rollback activates a prior approved package for *new runs*, not implicit rollback of external CyberArk changes.

**ServiceNow IDs**: store as opaque ticket references in a controlled change record; don't claim a string pattern verifies approval. DEV demo may validate presence and format. PROD must verify authorization using the bank's authoritative existing control process or integration. Record maker, reviewer, deployer separately.

## 5. Identity, roles, and authorization

Use corporate identity/SSO where already available; map identity groups/claims to **resource-scoped policies**. Proposed roles, not assumptions about Wells Fargo actual IAM role names:

- **PlatformAdmin**: registry/policy administration within granted environment; not automatically PROD publisher.
- **CapabilityPublisher**: publish vetted manifest and operation contracts after code release.
- **WorkflowDesigner**: create/change drafts for assigned application/workflow.
- **RuleMaintainer**: edit AMIE rule drafts in assigned domain.
- **WorkflowReviewer**: review/approve designs per delegated authority; cannot self-approve where dual control applies.
- **ReleaseOperator**: promote approved packages for permitted environment after preflight; no ability to alter signed content.
- **ProcessOperator**: pause/resume/cancel/retry/restart authorized runs, with reason and optional ticket; not authorized to change definition.
- **BusinessExecutor**: start only authorized workflow definitions and fill assigned forms/upload data; view scoped summaries.
- **TaskAssignee**: claim/complete only assigned user tasks and view minimum necessary data.
- **Auditor**: read approved audit evidence without mutation; payload exposure remains masked by classification.
- **ReadOnlyObserver**: view permitted business status and no action buttons.

Authorization is not UI-only: enforce at API, application service, capability dispatch and event/view filtering. Separate role from **permission** and from **scope** `(application, workflow, capability operation, environment, data domain, run ownership)`. Default deny. A user must not gain a sensitive operation merely by importing a BPMN file or replaying a previously approved message.

## 6. Process control semantics (required exact definition)

| Control | Requested transition | What BOB guarantees | What it does NOT guarantee |
|---|---|---|---|
| Pause | Running -> PauseRequested -> Paused | Do not schedule new units once pause gate is observed; capture requestor/reason/time; permit in-flight step to reach safe checkpoint | Does not retract a Kafka message or interrupt an external CyberArk write already accepted |
| Resume | Paused -> ResumeRequested -> Running | Resume from stored token position, preserve instance ID, recheck rights and dependencies | Does not switch to a newer definition automatically |
| Stop/Cancel | Running/Paused -> CancelRequested -> Cancelled/CompensationPending | Stop future activity scheduling, cooperatively cancel where supported, record partial outcomes | Not a hard kill/automatic undo of external side effects |
| Retry failed step | Failed/WaitingRecovery -> Running | Reinvoke only after retry policy + idempotency/reconciliation check | Never blindly execute an uncertain side effect again |
| Restart run | Terminal -> new Running instance | Create new process instance ID linked to original by `restartedFrom`; new authorization/inputs/intent; preserve both histories | Not rewind to time zero and not erase original evidence |

Require `reasonCode`, free-text reason (sanitized), actor and authorization check for each operator action; PROD runbook/control may also require a ServiceNow ticket and second approval. Concurrency handled with expected run revision/ETag and idempotent `commandId`; return `202 Accepted` for asynchronous control commands. Double click, concurrent operators, crash recovery, and stale run state must be tested.

## 7. Canonical persistent data and audit reconstruction

**Recommended MSSQL split** (separate schemas and restrictive service identities, not mandatory separate databases):

- `bob.WorkflowDefinition`, `bob.WorkflowVersion`, `bob.WorkflowPackage`, `bob.WorkflowActivityBinding`, `bob.WorkflowRun`, `bob.RunToken`, `bob.ActivityRun`, `bob.Timer`, `bob.PendingCommand`, `bob.ControlRequest`, `bob.WorkItemProjection` as required.
- `audit.AuditEvent` **append-only**: authorized actor/actions, runtime transitions, message/capability outcomes, AMIE decision metadata, package publication, ticket references, control outcomes.
- `integration.OutboxMessage`, `integration.InboxReceipt` (deduplication), optionally `integration.Correlation`.
- `controls.RunbookVersion`, `controls.ControlDefinition`, `controls.ControlEvidence`, `controls.ControlAssessment` where bank control owners approve.
- Business payload and detailed DCMS row records belong to the owning workload/service, not to generic `bob.WorkflowRun`.

`audit.AuditEvent` minimum fields: `eventId`, `recordedAtUtc`, `occurredAtUtc`, `eventType`, `actorId`, `actorKind`, `role/claimSnapshotRef`, `tenantOrDomain`, `applicationKey`, `workflowKey`, `workflowVersion`, `packageDigest`, `runId`, `activityId`, `batchId`, `recordId`, `correlationId`, `causationId`, `messageId`, `traceId`, `capabilityKey`, `operationKey`, `operationVersion`, `amieRuleKey`, `amieRuleVersion`, `decisionOrOutcomeCode`, `oldState/newState` if relevant, `reasonCode`, `serviceNowChangeId`, `controlId`, `evidenceRef`, `safeDetailsHash`, `classification`, `eventSchemaVersion`.

Do not serialize passwords, vault secrets, full privileged account records, full CSV uploads, or unrestricted person data into audit rows or Kafka payloads. Store an approved redacted summary + external evidence reference/hash, under retention and access controls.

Store **source events** to reconstruct history and **query projections** for current status/dashboard speed. Keep immutable published definitions and rule version references so the auditor can reconstruct the executable model; do not pretend logs alone recreate missing code releases. For integrity, consider SQL Server append-only Ledger tables if its version and bank approval allow it; retaining protected off-database digests and testing verification is a separate controls decision. Export/forward required evidence to the bank's approved central logging/SIEM pipeline according to actual policy.

Audit failures on critical writes should be handled as transaction or fail-closed conditions as defined by bank requirements; avoid success without durable evidence. A multi-service command can be committed with an MSSQL outbox in the same transaction; downstream receipt and outcomes are separate stages.

## 8. Common capability library / registration protocol

**Minimum SDK libraries** (names proposed, reconcile with real code):

```
/Unity.Capabilities.Contracts/CapabilityManifest.cs
/Unity.Capabilities.Contracts/OperationDescriptor.cs
/Unity.Capabilities.Contracts/MessageContractDescriptor.cs
/Unity.Capabilities.Contracts/OperationInvocation.cs
/Unity.Capabilities.Contracts/OperationOutcome.cs
/Unity.Capabilities.Hosting/IUnityCapabilityModule.cs
/Unity.Capabilities.Hosting/IUnityOperationHandler.cs
/Unity.Capabilities.Hosting/CapabilityRegistrationExtensions.cs
/Unity.Capabilities.Kafka/CapabilityKafkaConsumer.cs
/Unity.Capabilities.Kafka/CapabilityKafkaPublisher.cs
/Unity.Capabilities.Kafka/OutboxDispatcher.cs
/Unity.Capabilities.Kafka/InboxDeduplication.cs
/Unity.Capabilities.Audit/AuditEventEmitter.cs
/Unity.BOB.Core/Execution/WorkflowEngine.cs
/Unity.BOB.Central/Execution/CentralWorkflowHost.cs
/Unity.BOB.Embedded/Execution/EmbeddedWorkflowHost.cs
/Unity.BE/Components/Pages/WorkflowLibrary.razor
/Unity.BE/Components/Pages/BusinessWorkQueue.razor
/Unity.BE/Components/Pages/OperationsConsole.razor
/Unity.BE/Components/Pages/RunMonitor.razor
/Unity.BE/Components/Pages/AuditExplorer.razor
```

`OperationDescriptor` must carry: stable `capabilityKey`, `operationKey`, `contractVersion`, input/output JSON schemas and UI hints, required/optional fields, classifications, allowed execution hosts, allowed caller scopes, authorization policy, side-effect classification, retry/idempotency/reconciliation policy, timeout, completion event contract, data owner, audit category, required AMIE rule contracts (if any), prerequisite bindings, supported environment/version and test fixture names.

`MessageContractDescriptor` must carry: logical command topic subscription, outcome topic publication, schema key/version, partition key, consumer group identity, delivery expectation, idempotency key mapping, correlation fields, minimum permissions and redaction policy. **Declared subscription** is not blanket permission to consume an enterprise Kafka topic; broker ACLs and service identity remain authoritative.

**Registration sequence:**
1. Capability code declares and unit-tests handlers and manifests using the shared SDK.
2. Build pipeline validates JSON schemas, unique keys, compatibility, role policies, declared topic names, handler-to-descriptor binding and approved publication identity.
3. Deployment installs the service and subscribes to its authorized topics via approved infrastructure; service advertises a signed manifest + health/compatibility handshake.
4. Registry validates publisher and version, stores manifest, marks operation `Available/Degraded/Unavailable`, and exposes descriptors through a read API.
5. BE lists only authorized/compatible operations and uses schemas to generate form fields and binding selectors.
6. BOB publication validates all referenced operation/rule contracts; runtime enforces selected operation policy and signed version again.
7. If a primitive is missing, DEVIN adds **one** approved handler and companion tests; the new operation is reusable by unrelated workflows.

**No data-driven arbitrary operations:** the manifest names a server-registered handler; it is not a remotely supplied C# type or method invocation, reflection policy bypass, or unbounded SQL query.

### Sample C# contract sketch (not claimed to exist)

```csharp
// /Unity.Capabilities.Hosting/IUnityCapabilityModule.cs
public interface IUnityCapabilityModule
{
    string CapabilityKey { get; }
    CapabilityManifest Describe();
    void RegisterOperations(IServiceCollection services);
}

// /Unity.Capabilities.Hosting/IUnityOperationHandler.cs
public interface IUnityOperationHandler<TInput, TOutput>
{
    Task<TOutput> ExecuteAsync(
        TInput input,
        UnityExecutionContext context,
        CancellationToken cancellationToken);
}

// /Unity.Capabilities.Contracts/UnityExecutionContext.cs
public sealed record UnityExecutionContext(
    Guid WorkflowRunId,
    Guid? WorkItemId,
    string CorrelationId,
    string CausationId,
    string IdempotencyKey,
    string WorkflowVersion,
    string OperationContractVersion,
    string ActorId,
    string Environment,
    string? ServiceNowChangeId);
```

The SDK must provide extensions to attach an approved AMIE evaluator and an embedded BOB host **without embedding either where unnecessary**. It must also expose a self-describing contract endpoint protected by mTLS/service auth and an internal validation API used by CI. The operation handlers remain pure DI-registered C# and do not know a specific BPMN designer implementation.

## 9. Kafka message contract and reliability

Use a common envelope containing `messageId`, `messageType`, `schemaVersion`, `commandId`, `correlationId`, `causationId`, `traceparent`, `occurredAtUtc`, `applicationKey`, `workflowKey`, `workflowVersion`, `runId`, `activityId`, `batchId`, `workItemId`, `operationKey`, `operationContractVersion`, `idempotencyKey`, `actorContextRef`, `payload` or `payloadRef`, `classification`, and `sourceCapability`. Avoid full sensitive data and untrusted arbitrary return topics.

Use logical topics in contracts and approved target-specific Kafka bindings; don't hardcode a proposed enterprise naming scheme. **Commands** target the owning capability's authorized consumer group; **outcome events** return with matching correlation and causation IDs. Ensure cross-service correlation even if events arrive out of order or repeat.

Default to Kafka at-least-once delivery, durable outbox for DB->Kafka publication, inbox deduplication before effects, and idempotent outcome handling. Do not claim Kafka provides exactly-once side effects against CyberArk. Poison messages route to controlled DLQ/quarantine with audit and operation runbook. No raw Kafka consumption from the browser: backend projects authorized events to SQL, then SignalR/SSE sends sanitized run status updates.

## 10. Start triggers and future integration routes

All triggers normalize to the same authorized `StartWorkflowRequest {workflowKey, versionOrActiveAlias, sourceType, inputRef, inputSchemaVersion, userOrServiceIdentity, idempotencyKey, correlationId}`:

- **P0 manual BE upload:** user uploads CSV through a validated API; store securely; import capability returns artifact reference and batch ID.
- **P0 manual BE form:** UI generated from operation/workflow input schema; backend validates field requirements and AMIE policies.
- **P0 service API:** authorized application/client starts a workflow by HTTP contract.
- **P1 schedule:** supported timer / approved enterprise scheduler. AutoSys may call the same authenticated API; it is not a special workflow runtime.
- **P1 API ingestion:** upstream system posts data; an ingress capability validates and publishes the normalized start command.
- **P1 pull integration:** owning capability reads approved upstream API/DB through service-specific connector and publishes normalized work; not unrestricted central BOB database access.
- **P1 Kafka event trigger:** vetted event subscription policy maps event schema to start-workflow schema with anti-loop/idempotency constraints.

## 11. DCMS as a cross-platform acceptance fixture (NOT framework code)

**Existing behavior supplied by business owner:**
1. CSV is imported to a table and assigned a batch number. Each row is assigned a GUID.
2. Each row is processed one-by-one. Query corresponding CyberArk account.
3. CSV values replace/add configured platform custom attributes **in memory**.
4. Call CyberArk add/update account, then capture per-row outcome, why it passed or failed, and success/failure status.
5. When batch is complete, generate a report of successes, failures, and explanations, then send by Email Capability.

**Recommended Unity mapping:**
- BusinessExecutor BE upload or API trigger -> upload service -> approved Database staging operation; workload owns batch/row data.
- Central BOB: start batch, invoke a reusable row processor subworkflow/capability with batch correlation, wait for all terminal results, request result report, then send `Email.RequestNotification` through Kafka, await delivery outcome, complete.
- Embedded CyberArk BOB: `GetAccount` -> AMIE mapping/eligibility -> allowlisted `ApplyCustomAttributesInMemory` primitive -> `AddOrUpdateAccount` primitive -> report typed outcome. If primitives don't exist, capability developer creates them once.
- Workload row record: `{batchNumber, recordGuid, sourceRowNumber, status, reasonCode, reasonTextSafe, accountRef, attempt, start/endUtc, operationVersion, amieRuleVersion, correlationId}`.
- Batch status counters: `total, queued, validating, processing, succeeded, failed, skipped, completed`, where completed is terminal count. For UI use `completed = succeeded + failed + skipped`; retain separately `validationPassed` vs `writeSucceeded` so a passed rule is not mistaken for confirmed CyberArk success.
- The initial fixture preserves one-by-one processing using a generic sequential multi-instance / iterator behavior in BOB, not a DCMS-specific loop; concurrency is a later configurable bound after CyberArk/API safety and rate limits are understood.
- Only terminal states count as finished; pending retries, DLQ, and uncertain CyberArk side effects must be resolved or explicitly reported as unresolved before the final email.
- Example phases for eventual feed changes: CSV now; later API push, API pull, or approved AutoSys-triggered ingestion. All share the same work contract and reporting process.

**Other workloads:** Onboarding uses CSV/API/DB inputs and configurable approval/policy decisions; hygiene/Policy Drift inspect attributes and apply authorized remediation (including safe movement) with explicit policy, change evidence, and optional approval. Safe movement is a consequential write, not an unreviewed dynamic configuration action.

**No-code promise boundary:** configuration can combine *existing* secure primitives. New CyberArk API capabilities, missing handlers, schema changes or brand-new side effects still require code + security review.

## 12. API-first contract and automated regression coverage

Every UI function must invoke a backend API also usable by CI or an authorized test identity. Use OpenAPI/JSON Schema as the agreed contract source. Core route families (draft contract in companion OpenAPI file):

- `GET /api/v1/capabilities`, `GET /api/v1/capabilities/{key}/operations`, `GET /api/v1/operations/{key}/schema`
- `GET/POST /api/v1/workflows`, `GET/PUT /api/v1/workflows/{key}/draft`, `POST /api/v1/workflows/{key}/validate`, `POST /api/v1/workflows/{key}/submit-review`, `POST /api/v1/workflows/{key}/publish`, `GET /api/v1/workflows/{key}/versions`
- `POST /api/v1/workflow-runs`, `GET /api/v1/workflow-runs/{runId}`, `GET /api/v1/workflow-runs/{runId}/timeline`, `POST /api/v1/workflow-runs/{runId}/controls`
- `GET /api/v1/batches/{batchNumber}/summary`, `GET /api/v1/batches/{batchNumber}/records` (workload-specified business API)
- `GET /api/v1/audit/events`, `GET /api/v1/audit/exports/{exportId}`, `GET /api/v1/controls/runbooks`, `POST /api/v1/releases/{packageId}/preflight`

For each route require: authenticated actor/service, scope checks, schema validation, response shape/version, correlation ID, audit event when appropriate, error taxonomy, pagination/filters for collections, idempotency for writes, no sensitive payload leakage. API must expose functionality necessary for *UI regression* without requiring a GUI click path. Health/readiness/metrics endpoints are not substitutes for functional APIs.

Test groups for the November demo:
- DTO/schema contract compatibility; invalid binding rejected with actionable designer error.
- RBAC allow + deny across user roles, workflow ownership and environment.
- BPMN XML round trip + each advertised executable element.
- Central to Kafka to embedded BOB to AMIE to capability to outcome correlation.
- Restart after DB checkpoint / delayed Kafka outcome / duplicate Kafka message.
- Controlled pause + resume + cancel + retry + restart, authorization/race and audit.
- Input schema required fields, CSV validation, batch/record GUID lifecycle, summary counts and reasons.
- Two different workloads using the same BOB/AMIE engine and one shared operation without new BOB code.
- Definition publication with version/ticket + immutable hash, runner version pin and retirement behavior.
- Role-filtered SignalR events; no data exposed to other users or environments.
- Audit reconstruction: given run ID and release ID, retrieve start -> decisions -> commands -> results -> publication/control evidence; missing events flagged.
- Tests target non-production fixtures. No false statement that DEV demo tests certify PROD authorization.

## 13. Controls/runbooks as first-class configuration and evidence

Runbook is a versioned artifact owned by Operations/control owner and linked to workflow, capability and control ID. It should declare expected sequence, monitors, SLA/thresholds, on-call/escallation, manual decisions, pause/cancel/retry conditions, evidence to retain, exceptional cases, and change request/approval rules. BE presents read-only guidance to BusinessExecutor, and authorized action links to ProcessOperator.

Model `controlId`, `controlOwner`, `runbookVersion`, `workflowKey`, `applicability`, `riskClassification`, `requiredEvidenceTypes`, `allowedOperatorActions`, `approvalPolicy`, `retentionPolicyRef`, `exceptionProcedure`, `reviewDueUtc` (if required). Control check results produce `Pass/Fail/Exception/NotEvaluated` evidence records. **This design does not invent Wells Fargo CA numbers or certify compliance.** Bank control mapping and approval remain external verification gates.

## 14. November 30 delivery path and stop/go tests

Priority is based on dependency and proof, not feature count:

1. **Contract freeze (P0):** review current AMIE API, agree `OperationDescriptor`, BOB activity binding, Kafka envelope, RBAC scope, audit event shape, BPMN executable subset. Demo-fixture-only SDK prototypes may exist before production authorization.
2. **First vertical path (P0):** publish/read a capability manifest; BE list/inspect; create a BPMN draft with service/AMIE task; validate; invoke central/embedded path; persist outcomes to MSSQL; show business counts and trace.
3. **Control plane (P0):** versioned workflow catalog, publish gate, change ID, reasoned operator actions, API contract tests, role enforcement; manual controlled release preflight.
4. **DCMS pilot (P0 if integration available):** CSV -> batch/row GUIDs -> Get -> map -> CyberArk add/update -> per-row outcome -> email report; use non-production approved fixtures.
5. **Second workload (P0 target/P1 contingency):** onboarding or hygiene/Policy Drift with different AMIE rules but reuse BOB and CyberArk operation primitives.
6. **After cut:** advanced BPMN, full human task engine, business calendars/complex event gateways, graphical polish, end-to-end ServiceNow/AutoSys integrations, automated PROD activation.

**Exit criteria:** a reviewer can use secured APIs and BE to trace one representative application run through all components; no hidden manual postprocessing; unauthorized actions fail; failure cases are visible; version/ticket/actor/time are reconstructable; no PROD privileges/approvals are misrepresented. If core cannot be made correct in time, demonstrate a smaller safe subset and call out unsupported constructs instead of presenting a false complete engine.

## 15. Open items requiring actual code/control-owner inspection

| Item | Decision currently | Verification gate |
|---|---|---|
| Existing AMIE public interfaces | ADAPT, do not replace | Repo build/API inventory |
| Existing Kafka topic names and ACLs | Logical descriptors only | Platform owner review |
| Approved identity provider/roles | Corporate auth + scoped policies | Security/IAM mapping |
| Bank CA and control identifiers | No invented IDs | Control owner signoff |
| ServiceNow approval verification | ID in package; validation link TBD | Approved process/integration |
| Production audit retention/legal hold | Storage recommended, retention TBD | Compliance/records owner |
| MSSQL version and Ledger eligibility | Append-only tables P0; Ledger optional | DBA/security review |
| CyberArk adapter operations and rate limits | Illustrative names only | Capability inventory/contract test |
| Designer library approvals | First-party minimum / approved library only | OSS/commercial license and bank approvals |
| Second demo workload | Candidate: Onboarding or Hygiene | Reusable capability and input availability |
| Pause/Cancel behavior for in-flight CyberArk write | Cooperative checkpoints + reconcile | Integration failure-injection test |
| Runtime liveness / high availability | Single-worker demo allowed with recovery tests; production HA separate | Load/failover validation |

## References

- Unity v0.6 architecture and capability manifest (prior working documents); user-provided DCMS/onboarding details (Nov 11, 2026).
- OMG BPMN 2.0.2: https://www.omg.org/spec/BPMN/2.0.2
- ASP.NET Core SignalR hubs/auth: https://learn.microsoft.com/en-us/aspnet/core/signalr/hubs?view=aspnetcore-10.0
- Kafka delivery semantics: https://docs.confluent.io/kafka/design/delivery-semantics.html
- OpenTelemetry context propagation: https://opentelemetry.io/docs/concepts/context-propagation/
- SQL Server Ledger overview: https://learn.microsoft.com/en-us/sql/relational-databases/security/ledger/ledger-overview?view=sql-server-ver17
- OptimaJet API reference as feature inventory only: https://api.workflowengine.io/
