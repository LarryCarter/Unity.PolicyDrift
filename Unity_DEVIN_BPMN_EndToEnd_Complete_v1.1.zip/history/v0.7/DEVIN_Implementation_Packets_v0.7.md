# DEVIN Handoff: Unity Integration Milestones v0.7

**Status:** Engineering plan / proposed interfaces, NOT deployed code. **Read FIRST:** `Unity_BOB_BE_Integration_Architecture_v0.7.md`. Target: a truthful end-to-end demo by 2026-11-30; production authorization is a separate bank gate.

## Global instructions DEVIN must preserve

- Inspect/reconcile current solution/repo, AMIE interfaces, available CyberArk capability, Kafka infrastructure, BE UI framework, security, and existing SQL scripts before creating new abstractions.
- Implement BOB as a **generic** BPMN engine used by embedded and central hosts. Never hardcode DCMS, PAM policy, onboarding, email or account fields in BOB Core.
- Use only approved libraries. A commercial BPMN component can be used only if bank approval already exists; do not delay core work for an unapproved designer dependency.
- Every BE action must have a secure testable backend API, with OpenAPI specification and positive/negative functional regression tests.
- BOB workflow persistence is MSSQL only. Data is owned by a capability or workload; do not grant services direct SQL permissions to another service's tables as a shortcut.
- Configuration-only change cannot create arbitrary handler invocations, raw SQL, or bypass operation entitlement checks. Missing operation -> reusable adapter code and normal code release.
- Backend must enforce RBAC/ABAC and audit independently of frontend elements. Maker/checker, change IDs, and PROD approvals are not fake implementation flags.
- Assume at-least-once Kafka delivery; implement outbox/inbox, idempotency, source event correlation, and failure reconciliation. No exactly-once guarantee against external CyberArk calls.
- Do not expose secrets or full privileged records in messages, logs, screenshots, or responses.
- Produce code changes using `/Project/Folder/File.cs` paths; finish with Files and Structure Summary (new/updated/deleted/no change), tests run, test failures, unresolved dependencies, and evidence.

## Work packet table

| ID | Priority | Deliverable | Depends on | Acceptance / test evidence |
|---|---|---|---|---|
| D01 | P0 | Inventory current code and freeze shared contracts | Existing repo access | AMIE/BOB/BE/Kafka interface map; no duplicate rule engine; human signoff on contract gaps |
| D02 | P0 | Capability SDK, registration and discovery API | D01 | Two capability manifests auto-discover; schema/permission/handler mismatch fails; register once reuse twice |
| D03 | P0 | BOB BPMN 2.0 subset validator + central/embedded host | D01,D02 | One BPMN fixture imports, serializes, validates and executes in both host modes; unsupported construct rejected |
| D04 | P0 | Kafka command/outcome, correlation, outbox/inbox | D02,D03 | Duplicate commands don't duplicate an external effect; outcome arrives with same run/activity correlation |
| D05 | P0 | MSSQL persistence, audit, package/version and control APIs | D01,D03 | Workflow survives restart, audit reconstructs change/actor/ticket/rules/messages/outcome; immutable approved version |
| D06 | P0 | Blazor Workflow Library, designer, operation bindings, schema-driven form | D02,D03,D05 | A designer can assemble and validate a flow using registered operation+AMIE rule without code changes; API regression |
| D07 | P0 | Business summary, Run Monitor, Operator Console | D04,D05,D06 | Authorized updates visible near real time; actions pause/resume/cancel/retry/restart with correct safety semantics |
| D08 | P0 | DCMS pilot wiring with Email capability | D02-D07 + approved CyberArk adapter | CSV->batch+row IDs->lookup/map/update->terminal row results->report/email; detailed reason, idempotency and audit |
| D09 | P0 | Regression, role-deny suites, release checks, runbooks | D02-D08 | Nonproduction API tests, denial tests, publication gate, ticket/actor/time, read-only evidence export |
| D10 | P1 target | Second distinct pilot: Hygiene or Onboarding | D08 platform proven | Reuse same BOB/AMIE/one capability operation with alternate rules and input; no BOB Core modification |
| D11 | P1 | AutoSys/API pull/scheduled triggers and advanced BPMN | Post-MVP | Proven source adapter, auth, correlation, schedule semantics, supported-element tests |

## D01 - Repo reconciliation / contract freeze

Inventory existing namespaces, services, NuGet dependencies, `DbContext`/ADO.NET patterns, AMIE evaluation contracts, DI registration, Kafka producer/consumer libraries, and Blazor host type. Produce `current->target` mapping for every proposed interface; identify capabilities already present. Build a tiny contract fixture that declares an operation with input/output schema and one `AMIE.Rule@version` dependency. **Do not create new AMIE engine**. Report missing information as blockers rather than guessing.

## D02 - Capability SDK

Implementation deliverables: typed `IUnityCapabilityModule`, `IUnityOperationHandler<TRequest,TResult>`, descriptor manifest, runtime handler registry, schema and permission validator, health/version discovery endpoint, optional module host extension. An SDK-integrated service publishes operation contracts at startup or deployment through a trusted registry handshake; no dynamic C# execution. The registry stores declared logical inbound/outbound Kafka contracts, their versions, and required fields so BE can bind data sources and generate forms. The registry does not provision arbitrary brokers/ACLs.

**Test:** publish `CyberArk.GetAccount@1` and `Email.RequestNotification@1` example descriptors, then use the same `GetAccount` operation in two different draft workflows without modifying either service. Unknown operation / incompatible schema / missing entitlement is rejected by the server.

## D03 - BPMN Core & hosts

Use standard BPMN XML and BPMN DI. P0 subset: start/end, service task, business-rule task, exclusive gateway, sequence flows, call activity/subprocess, sequential multi-instance call activity for DCMS if selected, outcome wait state, error outcome. Implement exact token semantics and branch selection; add XML roundtrip and execution fixtures per supported element. Shared execution core with central host (MSSQL persisted) and embedded host (opt-in persistence/in-memory). Reject unsupported elements at publish time.

**Test:** same service-task definition produces corresponding activity invocation under the appropriate host; AMIE rule returns a typed decision; no remote AMIE call for local evaluation; duplicate Kafka outcome cannot advance an activity twice.

## D04 - Messaging contracts

Produce envelope schema and messages: command, activity succeeded, activity failed, process status changed, notification requested/completed, operator command. Message envelope carries process run, activity, correlation and causation. Persist outbox before publishing; consumer inbox dedupes and checks authorization/contract version. Maintain separate DLQ/quarantine with operator action/resolution logs. Never use Kafka topics as an API replacement for BE status reads.

## D05 - Database, lifecycle and audit

MSSQL schemas `bob`, `audit`, `integration`, optionally `controls` or approved equivalent. Persist definitions/versions, active run state, activity steps, control requests, source audit events and projections. Use immutable definition hashes and version pinning. Provide authorized audit timeline and evidence export. Review `audit` security with bank controls; SQL Server Ledger optional after version/license/control approval. All writes have replay/idempotency tests. Release records include ServiceNow ID/actor/UTC/digest without false assertion that the ticket is approved.

## D06 - Blazor BE designer & library

Deliver workflow library (Draft/In Review/Approved/Published/Active/Retired), inspector for selected operation, property editor with input/output fields and source selectors, AMIE rule selector, validation pane, draft save, publish-preflight route. Bind BE components to real APIs, not static arrays. The existing v0.6/v0.7 HTML prototype is **visual reference only**. A first-party Blazor SVG editor is acceptable if no approved designer component exists; keep the runtime independent of rendering tech. Always preserve BPMN IDs and layout.

## D07 - User and operator experiences

Separate Business Dashboard (batch, queue counts, percent done, summary report) from technical Run Monitor (BPMN status overlay, correlated events) and Operator Console (runbook-linked pause/resume/cancel/retry/restart). Queries read SQL-backed projection. Authorized live updates through SignalR; reconnect must request authoritative state from API. Backend enforces scopes and audit for every control command. Show pending control states (PauseRequested vs Paused).

## D08 - DCMS acceptance scenario (not engine functionality)

Input: CSV, batch number, row GUID. Process one row at a time via generic BOB sequential multi-instance call activity; do not introduce DCMS-specific iteration inside BOB Core. For each row: lookup CyberArk account; evaluate/map AMIE data; modify in-memory account custom attributes; call approved add/update; record success/failure and reason. After all rows terminal, use Email Capability via Kafka to dispatch a report with succeeded/failed/skipped details. The report is generated from persisted row outcomes, not inferred from emitted command count. Test malformed CSV, unknown account, mapping error, API timeout after possible external success, retried message, canceled batch, partial failure, notification delivery failure.

**Data ownership:** staging table belongs to the appropriate DCMS/workload or Database Capability as explicitly decided; not hardcoded inside BOB. **Future:** API push/pull or AutoSys start contract, out of initial scope unless input integration already approved.

## D09 - Compliance gate and API tests

Publish OpenAPI definitions for every view/action. Run contract regression, negative authorization, cross-tenant/workflow isolation, draft immutability, ServiceNow change capture, malformed message rejection, idempotent operator actions, audit reconstruction and race tests in CI. Store test evidence references with release candidate. For PROD, actual bank CAB/CA/controls approval is required; no test fixture `approved: true` is sufficient.

## D10 - Second workload acceptance

Choose Onboarding or Hygiene based on existing data and approved integration. Demonstrate a distinct configured process, AMIE rule set, and business dashboard; reuse `GetAccount` and the SDK + core BOB engine unchanged. Policy-based safe movement requires explicit target authorization, before/after state and audit; default read-only evaluation if remediation isn't approved.

## Sequencing and stop/go gates

- **Gate A:** Existing code and contracts reconciled (D01); unresolved AMIE API mismatch blocks speculative code.
- **Gate B:** Capability manifest -> BE inspector -> BOB activity resolution -> AMIE/local call -> Kafka outcome -> MSSQL history works with nonproduction fixture.
- **Gate C:** Business dashboard and operator controls report truth; role-denied controls do not execute; audit reconstructs chain.
- **Gate D:** DCMS demo shows persisted batch/record outcomes and report/email via actual approved Email capability path (or accurately flagged simulator).
- **Gate E:** Second application configured, and release package has provenance/test evidence. Bank authorization is tracked separately from demo readiness.

## Suggested pull request review checklist

- [ ] No application-specific branches in generic BOB/AMIE Core
- [ ] No new unapproved dependencies or dynamic arbitrary code
- [ ] Positive and negative API tests
- [ ] Every mutation has scoped authorization and audit
- [ ] Messages schema-validated, correlated, idempotent and sanitized
- [ ] Process control semantics preserve side-effect safety
- [ ] Versioned definition and pinned dependencies
- [ ] Shared SDK registration is exercised by two capabilities
- [ ] BE business view and technical view use common authoritative run state
- [ ] No assumed Wells Fargo controls/approvals or production access
- [ ] File and Structure Summary and all validation output included

## Sources

See architecture spec references. Prior Unity v0.6 design is preserved and updated here, not silently superseded in repository. None of these proposed types/routes is claimed as implemented.
