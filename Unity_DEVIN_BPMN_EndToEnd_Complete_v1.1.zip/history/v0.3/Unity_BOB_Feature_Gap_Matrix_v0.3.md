# Unity / BOB Platform Feature Gap Matrix — v0.3

**Date:** 2026-11-10  
**Scope:** Reusable Unity platform features only: BPMN 2.0.2 executable subset, shared BOB Core, local embedded workflows, central orchestration, cached AMIE, Kafka, and MSSQL-only BOB persistence. Application workflows are configured independently.

> This is a requirements and design-gap matrix, not a claim about existing implemented BOB code. The uploaded OptimaJet API reference identifies features and API types; it does not prove execution semantics or conformance. Vendor BPMN behavior and OMG are linked separately.

## Platform / Workload Boundary (Clarified v0.3)

**BOB is a generic BPMN workflow engine, not a CMDB enrichment engine.** AMIE is a generic configuration-first rule evaluator, not a Policy Drift-specific rules package. Unity capabilities provide integration activities and own their data and service boundaries. Kafka connects independently operating capabilities; MSSQL stores BOB's durable workflow state.

**Intended Unity workloads:** CMDB enrichment, Policy Drift, and legacy application modernization. Each of these should be modeled, configured, validated and deployed independently on the same shared Unity infrastructure. No workload-specific process or data mapping should be hardcoded into the BOB interpreter or AMIE core. Their exact workflow contracts remain to be defined.

**Proof of platform generality:** Two or more distinct, neutral BPMN+AMIE configurations execute in embedded and central hosts without modifications to shared engine binaries. Individual application proofs may come later and belong to their own design records.

This is a correction of the former v0.2 matrix, which elevated the illustrative CMDB enrichment example into a platform pilot and embedded CMDB-specific acceptance criteria in core requirements.

## Architectural invariants

- **ARC-01 — One engine, two hosts (Established):** Shared BOB core executes same supported BPMN IR embedded and centrally. Proof: Compare conformance fixtures in both hosts.
- **ARC-02 — Embedded execution is local (Established):** No mandatory BOB or AMIE network call per local activity or rule. Proof: Approved local workflow runs while central configuration services are unavailable.
- **ARC-03 — Central services govern definitions (Established):** Central service manages rule/workflow publication, versions and approvals. Proof: Only approved definitions can be activated.
- **ARC-04 — AMIE owns business decisions (Established):** BOB delegates business rule evaluation, mapping and validation to cached AMIE rules. Proof: Business decision behavior changes through AMIE configuration without rewriting BOB code.
- **ARC-05 — BOB owns control flow (Established):** BOB handles BPMN tasks, tokens, events, timers, state and orchestration. Proof: AMIE rule invocation does not own task scheduling.
- **ARC-06 — Kafka owns transport (Established):** Cross-capability async messages use contracts; BPMN controls correlation. Proof: No private cross-service database queries.
- **ARC-07 — Only MSSQL for BOB persistence (Established):** Exclude other persistence-provider code; preserve clean core/provider separation. Proof: Dependency report contains only MSSQL provider.
- **ARC-08 — Capability data ownership (Established):** Direct EF Core is allowed in owning capability; shared data accessed via owner API. Proof: Data ownership test verifies no private DB bypass.
- **ARC-09 — Capability adapter execution (Established):** Registered C# activities live with owning capability, not in central orchestration. Proof: Every integration operation stays inside its owning capability.
- **ARC-10 — Business Enablement Website is UI (Established):** Initiation, monitoring, intervention and human tasks live in BET UI. Proof: BOB REST only exposes scoped management/operations.
- **ARC-11 — Definition and rule version pinning (Established):** Running instance uses immutable BOB and AMIE versions. Proof: V1 instance retains behavior after V2 publishes.
- **ARC-12 — No silent BPMN degradation (Proposed safeguard):** Unsupported elements cause rejection, never auto-transitions or inert shapes. Proof: Importer negative-fixture suite.
- **ARC-13 — No arbitrary code as configuration (Established constraint):** Use approved typed activities and constrained AMIE expressions; no general C# compilation. Proof: Adversarial BPMN cannot access arbitrary files/commands.
- **ARC-14 — Durability matched to execution (Proposed):** Short embedded work can remain in memory; persistent waits require durable storage. Proof: Timer task rejects memory-only execution mode.
- **ARC-15 — Use reference as feature evidence (Established approach):** API types and vendor plugin behavior inform design; not evidence of Unity implementation. Proof: Each matrix row has source and acceptance criteria.
- **ARC-16 — BPMN is canonical process language (Proposed):** Target OMG BPMN 2.0.2 supported executable subset with conformance statement. Proof: Publication includes supported elements and tested semantics.
- **ARC-17 — No distributed shared SQL transaction (Established principle):** Cross-service reliability uses outbox, dedupe and compensation where needed. Proof: Failure-injection end-to-end tests.
- **ARC-18 — Avoid instance explosion (Proposed):** Batch orchestration and local row processing chosen on benchmarking. Proof: Workload test shows DB pressure under target.
- **ARC-19 — License/code independence (Established constraint):** OptimaJet is a product/API design reference, not a code source. Proof: Provenance review before integrating any third-party library.

- **ARC-20 — Platform / workload separation (Established user direction):** CMDB enrichment, Policy Drift, and legacy app modernization are configurable Unity workloads, not BOB engine features. Proof: Two unrelated workflows execute using the same unchanged BOB/AMIE core.

## Feature Matrix

### COR-01 — Versioned process definition and immutable identity

**Domain:** Definition model | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Established principle

- **BPMN:** process / definitions
- **Reference evidence:** `ProcessDefinition` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ProcessDefinition)); evidence type: API surface.
- **Unity fit:** Each execution references an approved definition ID and version.
- **Gap:** Define canonical schema, identity, immutability, effective dates.
- **Proof:** Two definition versions coexist; each instance retains its pinned version.

### COR-02 — BPMN XML importer and parser

**Domain:** Definition model | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** definitions / process
- **Reference evidence:** `BpmnConverter` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/BpmnConverter)); evidence type: API surface.
- **Unity fit:** BPMN 2.0.2 is source notation; normalize into executable IR.
- **Gap:** Choose supported subset and XML compatibility baseline.
- **Proof:** Import valid fixtures; reject invalid XML, missing refs and unsupported elements.

### COR-03 — Schema and semantic validation

**Domain:** Definition model | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** all supported BPMN
- **Reference evidence:** `BpmnConverterSettings` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/BpmnConverterSettings)); evidence type: API surface.
- **Unity fit:** Fail fast on unsupported or ill-formed BPMN; no silent fallback.
- **Gap:** Separate XSD validation from semantic and deployability checks.
- **Proof:** Invalid wait, orphaned flow, unsupported gateway never deploy.
- **Depends on:** COR-02

### COR-04 — Compile BPMN to executable intermediate representation

**Domain:** Definition model | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** all supported BPMN
- **Reference evidence:** `IWorkflowBuilder` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Builder/IWorkflowBuilder)); evidence type: API surface.
- **Unity fit:** One execution representation used by embedded and central hosts.
- **Gap:** Define IR format and compile-time activity binding.
- **Proof:** Same BPMN fixture has equal observable outcomes in both hosts.
- **Depends on:** COR-02

### COR-05 — Process instances, IDs and lifecycle states

**Domain:** Execution | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** process instance
- **Reference evidence:** `ProcessInstance` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ProcessInstance)); evidence type: API surface.
- **Unity fit:** Separate process template from independently tracked execution.
- **Gap:** Define lifecycle, suspended/cancelled/error states and transitions.
- **Proof:** Start, query, resume and complete deterministic process instances.
- **Depends on:** COR-01

### COR-06 — BPMN token engine and concurrent paths

**Domain:** Execution | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** sequence flow / gateways
- **Reference evidence:** `TransitionDefinition` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/TransitionDefinition)); evidence type: API surface.
- **Unity fit:** Track executable tokens across split/join without conflating threads.
- **Gap:** Define token ownership, join conditions, completion and cancellation.
- **Proof:** Parallel branch fixtures synchronize exactly once.
- **Depends on:** COR-04

### COR-07 — Pluggable typed activity handlers with DI

**Domain:** Execution | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Established principle

- **BPMN:** serviceTask / task
- **Reference evidence:** `ICustomActivityProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ICustomActivityProvider)); evidence type: API surface.
- **Unity fit:** Workflows invoke registered C# primitives owned by capabilities.
- **Gap:** Typed inputs/outputs, versioning, scope and failures.
- **Proof:** Registered activity executes through DI in both hosts.

### COR-08 — Async execution and cancellation propagation

**Domain:** Execution | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** serviceTask
- **Reference evidence:** `WorkflowRuntimeSettings` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeSettings)); evidence type: API surface.
- **Unity fit:** Avoid blocking threads; cancellation must be explicit.
- **Gap:** Checkpoint semantics and cooperative cancellation limits.
- **Proof:** Cancel before/after checkpoint does not corrupt state.
- **Depends on:** COR-07

### COR-09 — Typed workflow variables and execution context

**Domain:** Execution | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** dataInput / dataOutput
- **Reference evidence:** `ParametersCollection` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ParametersCollection)); evidence type: API surface.
- **Unity fit:** Pass structured context between tasks and AMIE rule evaluations.
- **Gap:** Serialization, scoping, mutable vs immutable fields, sensitive values.
- **Proof:** Type mismatch detected; variables safely persist/round-trip.
- **Depends on:** COR-05

### COR-10 — Parameter and output mappings across activities

**Domain:** Execution | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** dataAssociation
- **Reference evidence:** `ParameterDefinition` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ParameterDefinition)); evidence type: API surface.
- **Unity fit:** Enable configuration-driven data transfer without procedural glue.
- **Gap:** Expression syntax, null handling and mapping precedence.
- **Proof:** Map outputs between service tasks and subprocesses.
- **Depends on:** COR-09

### COR-11 — Explicit activity and transition triggers

**Domain:** Execution | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** sequenceFlow / event
- **Reference evidence:** `TriggerDefinition` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/TriggerDefinition)); evidence type: API surface.
- **Unity fit:** Separate automatic transitions, commands, timers and messages.
- **Gap:** Trigger taxonomy and exact-once state progression boundaries.
- **Proof:** Auto and external-trigger flows behave correctly.
- **Depends on:** COR-06

### COR-12 — Execution results and typed failures

**Domain:** Execution | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** serviceTask
- **Reference evidence:** `ProcessStatus` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/ProcessStatus)); evidence type: API surface.
- **Unity fit:** Consistent outcomes for local workflows and central orchestration.
- **Gap:** Error categories, retries, cancellation and compensatable failures.
- **Proof:** Caller gets precise success/failure and correlation IDs.

### COR-13 — Activity registry and resolution policy

**Domain:** Extension model | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** serviceTask
- **Reference evidence:** `AggregatingActionProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/AggregatingActionProvider)); evidence type: API surface.
- **Unity fit:** Capabilities register safe reusable activities by versioned identifiers.
- **Gap:** Collision rules, authorization, version compatibility.
- **Proof:** Unknown/ambiguous activity is rejected before activation.
- **Depends on:** COR-07

### COR-14 — No arbitrary runtime compilation from BPMN

**Domain:** Extension model | **Owner:** Security / BOB | **Disposition:** Exclude | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Established constraint

- **BPMN:** scriptTask
- **Reference evidence:** `CodeActionDefinition` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/CodeActionDefinition)); evidence type: API surface.
- **Unity fit:** Use preapproved handlers and constrained expressions; avoid arbitrary C#.
- **Gap:** Formalize allowlist and DSL rule sandbox contract.
- **Proof:** Malicious/unapproved code cannot be executed from configuration.
- **Depends on:** COR-13

### COR-15 — Preserve BPMN diagram metadata separately from behavior

**Domain:** Definition model | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P1 | **Host:** Shared | **Wave:** W2 | **Status:** Proposed

- **BPMN:** BPMNDI
- **Reference evidence:** `BpmnDiagram` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/BpmnDiagram)); evidence type: API surface.
- **Unity fit:** Imported visualization is not proof of executable semantics.
- **Gap:** DI round-trip without altering process meaning.
- **Proof:** Import/export process geometry without changing tokens.
- **Depends on:** COR-02

### BPM-01 — Start and normal end events

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** startEvent / endEvent
- **Reference evidence:** `StartEvent` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/StartEvent)); evidence type: API surface.
- **Unity fit:** Deterministic process creation and normal completion.
- **Gap:** Multiple start policy; end event token semantics.
- **Proof:** Start/end fixtures pass across both hosts.
- **Depends on:** COR-06

### BPM-02 — Service tasks resolve capability-owned activities

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Established principle

- **BPMN:** serviceTask
- **Reference evidence:** `ServiceTaskActivity` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ServiceTaskActivity)); evidence type: API surface.
- **Unity fit:** BOB coordinates, capability does the real operation.
- **Gap:** Bindings between task definition and registered adapter.
- **Proof:** Service task invokes local adapter without central call.
- **Depends on:** COR-07

### BPM-03 — Exclusive gateway with conditional/default branch

**Domain:** BPMN semantics | **Owner:** BOB Core + AMIE | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** exclusiveGateway
- **Reference evidence:** `ExclusiveGateway` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ExclusiveGateway)); evidence type: API surface.
- **Unity fit:** BPMN routing consumes AMIE decisions rather than hardcoded rules.
- **Gap:** Default precedence and invalid/multiple true condition behavior.
- **Proof:** One and only one route chosen per token under documented policy.
- **Depends on:** AM-01

### BPM-04 — Parallel split and synchronization join

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Proposed

- **BPMN:** parallelGateway
- **Reference evidence:** `ParallelGateway` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ParallelGateway)); evidence type: API surface.
- **Unity fit:** True concurrent token semantics, not simple simultaneous method calls.
- **Gap:** Join counters, cancellation and crash recovery.
- **Proof:** Join waits for required branches and fires once.
- **Depends on:** COR-06

### BPM-05 — Embedded subprocess and scoped variables

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P1 | **Host:** Shared | **Wave:** W2 | **Status:** Proposed

- **BPMN:** subProcess
- **Reference evidence:** `SubprocessNodeVisitor` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/SubprocessNodeVisitor)); evidence type: API surface.
- **Unity fit:** Reusable local subflows inside a capability.
- **Gap:** Variable propagation, boundary events, lifecycle.
- **Proof:** Parent can call and complete nested reusable flow.
- **Depends on:** COR-09

### BPM-06 — Reusable call activity references

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P1 | **Host:** Shared | **Wave:** W2 | **Status:** Proposed

- **BPMN:** callActivity
- **Reference evidence:** `CallActivityNodeVisitor` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/CallActivityNodeVisitor)); evidence type: API surface.
- **Unity fit:** Invoke separately versioned workflow definitions without code duplication.
- **Gap:** Version binding, recursion limits, local vs distributed invocation.
- **Proof:** Call activity executes correct pinned referenced definition.
- **Depends on:** COR-01

### BPM-07 — Terminate end event

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P1 | **Host:** Shared | **Wave:** W2 | **Status:** Proposed

- **BPMN:** terminateEventDefinition
- **Reference evidence:** `TerminateEvent` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/TerminateEvent)); evidence type: API surface.
- **Unity fit:** End all active tokens for intended process scope.
- **Gap:** Cancel in-flight tasks and compensation policy.
- **Proof:** Terminate cancels sibling branches deterministically.
- **Depends on:** COR-06

### BPM-08 — Message catch / receive-task wait states

**Domain:** BPMN semantics | **Owner:** BOB Core + Kafka | **Disposition:** Build | **Priority:** P1 | **Host:** Central + optional embedded | **Wave:** W3 | **Status:** Proposed

- **BPMN:** intermediateCatchEvent / receiveTask
- **Reference evidence:** `MessageCatchEvent` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/MessageCatchEvent)); evidence type: API surface.
- **Unity fit:** Release resources while awaiting correlated Kafka message.
- **Gap:** Message name, process ID, correlation and authorization.
- **Proof:** Wrong/duplicate messages do not advance another instance.
- **Depends on:** KAF-01

### BPM-09 — Timer catch and timer start events

**Domain:** BPMN semantics | **Owner:** BOB Core + MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W2 | **Status:** Proposed

- **BPMN:** timerEventDefinition
- **Reference evidence:** `TimerCatchEvent` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/TimerCatchEvent)); evidence type: API surface.
- **Unity fit:** Durable wait without sleeping application threads.
- **Gap:** UTC, DST, scheduler lease and clock drift rules.
- **Proof:** Timer resumes once after restart and node failover.
- **Depends on:** PST-04

### BPM-10 — Boundary timer and error event semantics

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** boundaryEvent
- **Reference evidence:** `TBoundaryEvent` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TBoundaryEvent)); evidence type: API surface.
- **Unity fit:** Timeout or errors can reroute a running task.
- **Gap:** Interrupting vs non-interrupting scope; vendor importer incomplete.
- **Proof:** Timeout cancels task only if interrupting; async callbacks safe.
- **Depends on:** BPM-09

### BPM-11 — Event-based gateway race

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** eventBasedGateway
- **Reference evidence:** `TEventBasedGateway` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TEventBasedGateway)); evidence type: API surface.
- **Unity fit:** First matching external event wins and cancels alternatives.
- **Gap:** Atomic competing event subscriptions; Kafka/timer interplay.
- **Proof:** Simultaneous events select exactly one outgoing path.
- **Depends on:** BPM-08

### BPM-12 — Inclusive gateway split and merge

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Defer | **Priority:** P2 | **Host:** Shared | **Wave:** W4 | **Status:** Proposed

- **BPMN:** inclusiveGateway
- **Reference evidence:** `TInclusiveGateway` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TInclusiveGateway)); evidence type: API surface.
- **Unity fit:** Useful conditional parallel routing; join semantics are subtle.
- **Gap:** Full synchronization must not imitate vendor partial import.
- **Proof:** Join waits only for branches activated by split.
- **Depends on:** BPM-04

### BPM-13 — Business rule task invokes embedded AMIE

**Domain:** BPMN semantics | **Owner:** BOB Core + AMIE | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Established principle

- **BPMN:** businessRuleTask
- **Reference evidence:** `TBusinessRuleTask` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TBusinessRuleTask)); evidence type: API surface.
- **Unity fit:** Business logic stays in AMIE; BPMN controls sequence.
- **Gap:** Input/output schema, rule version pin, error mapping.
- **Proof:** Rule task invokes AMIE locally without synchronous central dependency.
- **Depends on:** AM-01

### BPM-14 — User task lifecycle and completion

**Domain:** BPMN semantics | **Owner:** BOB Central + BET | **Disposition:** Build | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** userTask
- **Reference evidence:** `TUserTask` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TUserTask)); evidence type: API surface.
- **Unity fit:** Durable human approvals integrated with Business Enablement Website.
- **Gap:** Assignment, authorization, deadlines, claim/reassign.
- **Proof:** Suspend and resume via authorized completion; audit actor.
- **Depends on:** UI-01

### BPM-15 — Multi-instance sequential tasks

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P1 | **Host:** Both | **Wave:** W2 | **Status:** Proposed

- **BPMN:** multiInstanceLoopCharacteristics
- **Reference evidence:** `TMultiInstanceLoopCharacteristics` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMultiInstanceLoopCharacteristics)); evidence type: API surface.
- **Unity fit:** Apply a reusable workflow to a set of rows without new C#.
- **Gap:** Collection snapshot, item scope and partial failure policy.
- **Proof:** N items processed once, in order, with bounded memory.
- **Depends on:** COR-09

### BPM-16 — Multi-instance parallel tasks with limits

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P2 | **Host:** Both | **Wave:** W4 | **Status:** Proposed

- **BPMN:** multiInstanceLoopCharacteristics
- **Reference evidence:** `TMultiInstanceLoopCharacteristics` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMultiInstanceLoopCharacteristics)); evidence type: API surface.
- **Unity fit:** Bounded concurrency for any high-volume multi-instance workflow, respecting downstream quotas.
- **Gap:** Concurrency limits, error aggregation, cancellation.
- **Proof:** 10k items with configurable max concurrency and no loss.
- **Depends on:** BPM-15

### BPM-17 — Compensation handlers and rollback semantics

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Defer | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** compensateEventDefinition
- **Reference evidence:** `TCompensateEventDefinition` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TCompensateEventDefinition)); evidence type: API surface.
- **Unity fit:** Compensating transactions for cross-service failures.
- **Gap:** Compensation registration and order; idempotent reversal.
- **Proof:** Failure after partial steps triggers appropriate compensations.
- **Depends on:** PST-07

### BPM-18 — Error end and escalation events

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Defer | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** errorEventDefinition / escalationEventDefinition
- **Reference evidence:** `TErrorEventDefinition` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TErrorEventDefinition)); evidence type: API surface.
- **Unity fit:** Explicit error routing beyond generic exceptions.
- **Gap:** Error type propagation through nested scopes.
- **Proof:** Expected handler catches matching error; others fail safely.
- **Depends on:** BPM-05

### BPM-19 — Conditional catch events

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** conditionalEventDefinition
- **Reference evidence:** `TConditionalEventDefinition` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TConditionalEventDefinition)); evidence type: API surface.
- **Unity fit:** Optional future event-driven conditional waits.
- **Gap:** Signal/update dependency graph rather than polling every instance.
- **Proof:** Condition triggers once on relevant state change.
- **Depends on:** BPM-08

### BPM-20 — Signal and broadcast events

**Domain:** BPMN semantics | **Owner:** BOB Core + Kafka | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** signalEventDefinition
- **Reference evidence:** `TSignalEventDefinition` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TSignalEventDefinition)); evidence type: API surface.
- **Unity fit:** Broadcast signals are distinct from targeted messages.
- **Gap:** Who subscribes, durable fanout semantics and authorization.
- **Proof:** Signal delivery matches subscribed instances without duplicates.
- **Depends on:** KAF-01

### BPM-21 — Send task and message throw

**Domain:** BPMN semantics | **Owner:** BOB Core + Kafka | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** sendTask / intermediateThrowEvent
- **Reference evidence:** `TMessageFlow` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMessageFlow)); evidence type: API surface.
- **Unity fit:** Issue a versioned command/event through capability integration.
- **Gap:** Outbox commit and message correlation.
- **Proof:** Message published transactionally with workflow transition intent.
- **Depends on:** PST-07

### BPM-22 — Manual task and script task

**Domain:** BPMN semantics | **Owner:** Capability / Security | **Disposition:** Defer | **Priority:** P3 | **Host:** Both | **Wave:** W5 | **Status:** Proposed

- **BPMN:** manualTask / scriptTask
- **Reference evidence:** `TScriptTask` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TScriptTask)); evidence type: API surface.
- **Unity fit:** Manual work belongs in human task handling; script execution is restricted.
- **Gap:** Decide if safe sandbox expression needed at all.
- **Proof:** Unapproved scripts not executed; human work mapped deliberately.

### BPM-23 — Pools, lanes and collaborations

**Domain:** BPMN semantics | **Owner:** BOB Central + BET | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** collaboration / lane
- **Reference evidence:** `TCollaboration` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TCollaboration)); evidence type: API surface.
- **Unity fit:** Model service participants, but no shared-memory cross-pool execution.
- **Gap:** Map message flows to Kafka, preserve independent capabilities.
- **Proof:** Each pool has isolated state and explicit cross-pool messages.
- **Depends on:** KAF-01

### BPM-24 — Event subprocess and cancellation scopes

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** eventSubProcess
- **Reference evidence:** `TSubProcess` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TSubProcess)); evidence type: API surface.
- **Unity fit:** Advanced interrupt and event handlers.
- **Gap:** Determine whether business cases justify full semantics.
- **Proof:** Interrupt and non-interrupt event subprocess conformance.
- **Depends on:** BPM-10

### BPM-25 — Complex gateways and ad-hoc subprocesses

**Domain:** BPMN semantics | **Owner:** BOB Core | **Disposition:** Exclude | **Priority:** OUT | **Host:** N/A | **Wave:** Excluded | **Status:** Excluded from initial scope

- **BPMN:** complexGateway / adHocSubProcess
- **Reference evidence:** `TComplexGateway` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TComplexGateway)); evidence type: API surface.
- **Unity fit:** Not needed for initial Unity workflows; reject as unsupported.
- **Gap:** Revisit only with proven business use.
- **Proof:** Validator rejects unsupported definitions with precise reason.
- **Depends on:** COR-03

### BPM-26 — BPMN conformance fixture suite

**Domain:** BPMN semantics | **Owner:** BOB Core / QA | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Proposed

- **BPMN:** supported subset
- **Reference evidence:** `TDefinitions` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TDefinitions)); evidence type: API surface; OMG standard.
- **Unity fit:** Prevent misleading BPMN compatible claim without executable proofs.
- **Gap:** Map every accepted element to token and failure tests.
- **Proof:** Fixture suite runs with same observable outcomes under both hosts.
- **Depends on:** COR-04

### HST-01 — Single reusable workflow engine library

**Domain:** Hosting | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Shared | **Wave:** W1 | **Status:** Established principle

- **BPMN:** all
- **Reference evidence:** `WorkflowRuntime` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime)); evidence type: API surface.
- **Unity fit:** Embedded and centralized hosts execute the same engine and definition IR.
- **Gap:** Host-neutral interfaces; no central REST on local hot path.
- **Proof:** One package builds in-process and service hosting without divergent logic.

### HST-02 — Embedded capability workflow host

**Domain:** Hosting | **Owner:** BOB Embedded | **Disposition:** Build | **Priority:** P0 | **Host:** Embedded | **Wave:** W1 | **Status:** Established principle

- **BPMN:** local flows
- **Reference evidence:** `SingleServerServiceRunner` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.ServiceRunners/SingleServerServiceRunner)); evidence type: API surface.
- **Unity fit:** Runs workflows directly in capability process with registered DI adapters.
- **Gap:** Request scope, local lifecycle and memory controls.
- **Proof:** Two unrelated configured workflows run with the central BOB registry unavailable.
- **Depends on:** HST-01

### HST-03 — Central orchestration service host

**Domain:** Hosting | **Owner:** BOB Central | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Established principle

- **BPMN:** long-running processes
- **Reference evidence:** `MultiServerServiceRunner` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.ServiceRunners/MultiServerServiceRunner)); evidence type: API surface.
- **Unity fit:** Durable coordination across capabilities and Kafka.
- **Gap:** Partitioning, lifecycle API, administration.
- **Proof:** Process survives service failover and resumes work.
- **Depends on:** PST-01

### HST-04 — Host-specific persistence policies

**Domain:** Hosting | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W2 | **Status:** Proposed

- **BPMN:** wait states
- **Reference evidence:** `IPersistenceProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IPersistenceProvider)); evidence type: API surface.
- **Unity fit:** In-memory local execution where safe; MSSQL for durable workflows.
- **Gap:** Clear refusal to start durable waits without persistence configured.
- **Proof:** Embedded no-durability scenario works; timer wait rejects unsafe mode.
- **Depends on:** PST-01

### HST-05 — Definition and rule cache in capabilities

**Domain:** Configuration | **Owner:** BOB Embedded + AMIE | **Disposition:** Build | **Priority:** P0 | **Host:** Embedded | **Wave:** W1 | **Status:** Established principle

- **BPMN:** definitions
- **Reference evidence:** `IParsedProcessCache` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Cache/IParsedProcessCache)); evidence type: API surface.
- **Unity fit:** No per-activity network calls to load definitions.
- **Gap:** Atomic swap, expiry and stale security policies.
- **Proof:** 100k local activities require zero registry round trips.
- **Depends on:** HST-02

### HST-06 — Approved definition registry and publishing

**Domain:** Configuration | **Owner:** Unity Control Plane | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W2 | **Status:** Established principle

- **BPMN:** definitions
- **Reference evidence:** `ISchemePersistenceProvider<TSchemeMedium>` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/ISchemePersistenceProvider-TSchemeMedium)); evidence type: API surface.
- **Unity fit:** Central governance while executing locally.
- **Gap:** Approval workflow, signed package publication and access control.
- **Proof:** Unapproved definition cannot be loaded by capability.
- **Depends on:** SEC-01

### HST-07 — Definition version pinning in running instances

**Domain:** Configuration | **Owner:** BOB Core + AMIE | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Established principle

- **BPMN:** calledElement / definitions
- **Reference evidence:** `SchemeDefinition<T>` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/SchemeDefinition-T)); evidence type: API surface.
- **Unity fit:** Running workflows must not silently adopt new logic.
- **Gap:** Pin AMIE and BOB versions together as needed.
- **Proof:** Publish v2 during v1 instance; v1 outcome unchanged.
- **Depends on:** COR-01

### HST-08 — Schema migration of live workflow instances

**Domain:** Configuration | **Owner:** BOB Central | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** definitions
- **Reference evidence:** `SchemeEntity` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Entities/SchemeEntity)); evidence type: API surface.
- **Unity fit:** Explicit migration only; prioritize version coexistence.
- **Gap:** Migration planner, compatibility check, rollback.
- **Proof:** V1 instances remain executable with V2 deployed.
- **Depends on:** HST-07

### HST-09 — Signed execution packages and dependency manifest

**Domain:** Configuration | **Owner:** Unity Control Plane | **Disposition:** Build | **Priority:** P1 | **Host:** Both | **Wave:** W2 | **Status:** Proposed mechanism

- **BPMN:** definitions
- **Reference evidence:** `ProcessDefinition` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ProcessDefinition)); evidence type: API surface.
- **Unity fit:** Publish approved workflow/rule bundles to trusted hosts.
- **Gap:** Package format, signing keys, expiry and capability compatibility.
- **Proof:** Tampered/unsupported package rejected before activation.
- **Depends on:** HST-06

### HST-10 — Atomic activation/rollback of definition sets

**Domain:** Configuration | **Owner:** Unity Control Plane | **Disposition:** Build | **Priority:** P1 | **Host:** Both | **Wave:** W2 | **Status:** Proposed

- **BPMN:** definitions
- **Reference evidence:** `IParsedProcessCache` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Cache/IParsedProcessCache)); evidence type: API surface.
- **Unity fit:** Avoid partially updated AMIE/BOB logic.
- **Gap:** Rollout strategy and rollback semantics.
- **Proof:** Concurrent requests only see full old or full new package.
- **Depends on:** HST-09

### HST-11 — Multi-node execution coordination

**Domain:** Hosting | **Owner:** BOB Central | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** distributed instance
- **Reference evidence:** `MultiServerRestorer` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.ServiceRunners/MultiServerRestorer)); evidence type: API surface.
- **Unity fit:** Central workers should recover on node failures without double execution.
- **Gap:** Lease ownership, fencing tokens and failover.
- **Proof:** Kill worker mid-task; exactly one active lease holder remains.
- **Depends on:** PST-06

### HST-12 — Local workflow limits and watchdogs

**Domain:** Hosting | **Owner:** BOB Embedded | **Disposition:** Build | **Priority:** P1 | **Host:** Embedded | **Wave:** W2 | **Status:** Proposed

- **BPMN:** multiInstance / loops
- **Reference evidence:** `WorkflowRuntimeSettings` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeSettings)); evidence type: API surface.
- **Unity fit:** Prevent misconfigured workflows from consuming capability resources.
- **Gap:** Timeouts, max recursion, steps and memory budget.
- **Proof:** Infinite/expensive loop aborted with controlled failure.
- **Depends on:** SEC-02

### HST-13 — Programmatic workflow builder optional

**Domain:** Configuration | **Owner:** BOB Core | **Disposition:** Defer | **Priority:** P3 | **Host:** Shared | **Wave:** W5 | **Status:** Proposed

- **BPMN:** definitions
- **Reference evidence:** `ProcessDefinitionBuilder` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model.Builder/ProcessDefinitionBuilder)); evidence type: API surface.
- **Unity fit:** May help tests and developer tools; BPMN remains canonical.
- **Gap:** Decide if builder is public API or internal testing tool.
- **Proof:** Builder round-trip conforms to BPMN subset.

### HST-14 — Runtime startup, shutdown and restore hooks

**Domain:** Hosting | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P1 | **Host:** Both | **Wave:** W2 | **Status:** Proposed

- **BPMN:** process lifecycle
- **Reference evidence:** `WorkflowRuntime` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime)); evidence type: API surface.
- **Unity fit:** Controlled suspend/drain and restore.
- **Gap:** Crash vs graceful shutdown and in-flight handler contract.
- **Proof:** Stop/restart without orphaned workflow state.
- **Depends on:** PST-01

### HST-15 — Offline use of last approved definitions

**Domain:** Configuration | **Owner:** BOB Embedded + AMIE | **Disposition:** Build | **Priority:** P0 | **Host:** Embedded | **Wave:** W2 | **Status:** Established principle

- **BPMN:** definitions
- **Reference evidence:** `DefaultParcedProcessCache` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Cache/DefaultParcedProcessCache)); evidence type: API surface.
- **Unity fit:** Registry outage should not disable authorized local workflows.
- **Gap:** Define fail-closed exceptions for expired security policy.
- **Proof:** Offline approved configuration continues; revoked sensitive rules fail closed.
- **Depends on:** HST-05

### HST-16 — Use REST only for management or intentional remote execution

**Domain:** Hosting | **Owner:** BOB Central / BET | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** process API
- **Reference evidence:** `WorkflowRuntime` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime)); evidence type: API surface.
- **Unity fit:** Avoid turning every workflow step into a central API call.
- **Gap:** Management endpoints vs execution endpoints.
- **Proof:** Embedded workflow call path contains no central HTTP requests.
- **Depends on:** HST-02

### PST-01 — Single SQL Server persistence implementation

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P0 | **Host:** Central / durable embedded | **Wave:** W2 | **Status:** Established principle

- **BPMN:** process state
- **Reference evidence:** `MSSQLProvider` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/MSSQLProvider)); evidence type: API surface.
- **Unity fit:** Only MSSQL support; keep persistence behind internal contracts.
- **Gap:** Schema, transactions, EF vs ADO and connection policy.
- **Proof:** Creation, mutation and restoration across worker restart.

### PST-02 — Workflow definitions and immutable snapshots

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W2 | **Status:** Proposed

- **BPMN:** definitions
- **Reference evidence:** `WorkflowScheme` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowScheme)); evidence type: API surface.
- **Unity fit:** Persist published BPMN source and executable version metadata.
- **Gap:** Version indexes, hash validation, retention policy.
- **Proof:** Load exact pinned definition and prove integrity.
- **Depends on:** PST-01

### PST-03 — Process instance checkpoints

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W2 | **Status:** Proposed

- **BPMN:** wait states
- **Reference evidence:** `WorkflowProcessInstance` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowProcessInstance)); evidence type: API surface.
- **Unity fit:** Store current tokens, context and state atomically.
- **Gap:** Checkpoint frequency and payload sizes.
- **Proof:** Crash at each boundary; replay never skips committed state.
- **Depends on:** PST-01

### PST-04 — Durable timer registration and recovery

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W2 | **Status:** Proposed

- **BPMN:** timerEventDefinition
- **Reference evidence:** `WorkflowProcessTimer` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowProcessTimer)); evidence type: API surface.
- **Unity fit:** Timer survive restart and multi-node execution.
- **Gap:** UTC handling, due-time index, lease/dedupe.
- **Proof:** Timers fire once across leader failover and DST boundary.
- **Depends on:** PST-03

### PST-05 — Transition history and audit

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W2 | **Status:** Proposed

- **BPMN:** all
- **Reference evidence:** `WorkflowProcessTransitionHistory` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowProcessTransitionHistory)); evidence type: API surface.
- **Unity fit:** Reconstruct state changes and evidence for operations.
- **Gap:** Sensitive payload redaction and retention.
- **Proof:** Every state transition traceable by version, actor and correlation.
- **Depends on:** PST-03

### PST-06 — Worker leases, locking and fencing

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** distributed execution
- **Reference evidence:** `WorkflowSync` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.MSSQL.Models/WorkflowSync)); evidence type: API surface.
- **Unity fit:** Avoid simultaneous ownership of workflow instance on two nodes.
- **Gap:** Fencing in downstream adapters; lease timeout selection.
- **Proof:** Concurrent workers never commit incompatible transitions.
- **Depends on:** PST-03

### PST-07 — Transactional outbox for events and commands

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL + Kafka | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** message events
- **Reference evidence:** `IPersistenceProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IPersistenceProvider)); evidence type: API surface.
- **Unity fit:** Persist state and outbound message intent atomically.
- **Gap:** Define outbox schema, publisher, retry and dedupe.
- **Proof:** Crash after SQL commit before Kafka publish still eventually emits.
- **Depends on:** PST-03

### PST-08 — Inbox and message deduplication

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL + Kafka | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** message catch
- **Reference evidence:** `WorkflowInbox` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowInbox)); evidence type: API surface.
- **Unity fit:** Retry-safe event processing; do not interpret vendor approval inbox as Kafka inbox.
- **Gap:** Dedicated consumed-message identity schema required.
- **Proof:** Duplicate deliveries lead to one state transition.
- **Depends on:** PST-07

### PST-09 — Optimistic concurrency / rowversion

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W2 | **Status:** Proposed

- **BPMN:** process state
- **Reference evidence:** `WorkflowProcessInstanceStatus` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.DbPersistence/WorkflowProcessInstanceStatus)); evidence type: API surface.
- **Unity fit:** Prevent lost updates and conflicting commits.
- **Gap:** Locking vs rowversion, deadlock handling.
- **Proof:** Concurrent updates conflict and retry safely.
- **Depends on:** PST-03

### PST-10 — Schema migration and versioned upgrades

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** persistence
- **Reference evidence:** `Migration10Initial` ([API](https://api.workflowengine.io/sql-server/OptimaJet.Workflow.MSSQL.Migrations/Migration10Initial)); evidence type: API surface.
- **Unity fit:** Controlled evolving MSSQL schema for durable instances.
- **Gap:** Expand/contract strategy, rollback and online migration.
- **Proof:** Upgrade schema with old instances running without data loss.
- **Depends on:** PST-01

### PST-11 — Tenant partitioning and access constraints

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL / Security | **Disposition:** Investigate | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** tenant / process
- **Reference evidence:** `ProcessInstanceEntity` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Entities/ProcessInstanceEntity)); evidence type: API surface.
- **Unity fit:** OptimaJet exposes tenant-related models; Unity need TBD.
- **Gap:** Decide if multiple logical tenants or applications need strict partitioning.
- **Proof:** Tenant A cannot access/affect tenant B process or definition.
- **Depends on:** SEC-01

### PST-12 — Retention, archiving and purging

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** history
- **Reference evidence:** `ProcessHistoryItem` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ProcessHistoryItem)); evidence type: API surface.
- **Unity fit:** Control SQL growth without losing legally required audit records.
- **Gap:** Data lifecycle and export policy.
- **Proof:** Archived instances remain queryable; active workflows unaffected.
- **Depends on:** PST-05

### PST-13 — Recovery / orphaned instance resumption

**Domain:** MSSQL persistence | **Owner:** BOB Central | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** wait states
- **Reference evidence:** `IProcessRestorer` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.ProcessRestoring/IProcessRestorer)); evidence type: API surface.
- **Unity fit:** Recover from node failures and resume durable steps.
- **Gap:** Unknown side-effect resolution after crash before checkpoint.
- **Proof:** Crash injection matrix passes idempotent replay requirements.
- **Depends on:** PST-06

### PST-14 — Indexing, batching and DB load instrumentation

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** bulk / history
- **Reference evidence:** `WorkflowRuntimeBulkApi` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeBulkApi)); evidence type: API surface.
- **Unity fit:** Protect MSSQL workflow-state throughput under high instance, timer and history volumes.
- **Gap:** Choose instance granularity per workload; define concurrency, retention and data growth targets.
- **Proof:** Mixed workflow benchmark meets declared latency and throughput targets without excessive scans or lock contention.
- **Depends on:** PST-01

### PST-15 — No other workflow persistence provider modules

**Domain:** MSSQL persistence | **Owner:** BOB MSSQL | **Disposition:** Exclude | **Priority:** OUT | **Host:** N/A | **Wave:** Excluded | **Status:** Established constraint

- **BPMN:** persistence
- **Reference evidence:** `PersistenceProviderId` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core/PersistenceProviderId)); evidence type: API surface.
- **Unity fit:** Drop MongoDB/MySQL/Oracle/PostgreSQL/SQLite providers.
- **Gap:** Confirm no incidental runtime references to other providers.
- **Proof:** No package or project reference to other provider implementations.

### AM-01 — Local AMIE rule evaluation inside service tasks

**Domain:** AMIE boundary | **Owner:** AMIE Embedded | **Disposition:** Delegate | **Priority:** P0 | **Host:** Embedded | **Wave:** W1 | **Status:** Established principle

- **BPMN:** businessRuleTask
- **Reference evidence:** `IWorkflowActionProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider)); evidence type: API surface.
- **Unity fit:** BOB dispatches to the AMIE SDK; does not reimplement rules.
- **Gap:** Typed evaluator interface, local snapshots, errors.
- **Proof:** Rule evaluation with AMIE registry unavailable and no network calls.

### AM-02 — AMIE mapping, validation and decision reuse

**Domain:** AMIE boundary | **Owner:** AMIE | **Disposition:** Delegate | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Established principle

- **BPMN:** gateway / rule task
- **Reference evidence:** `ConditionDefinition` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/ConditionDefinition)); evidence type: API surface.
- **Unity fit:** Rules, transforms and mappings configured, not repeated C#.
- **Gap:** AMIE DSL, type safety, expression execution and cache.
- **Proof:** Change a business mapping or decision through approved AMIE configuration without recompiling the owning capability.
- **Depends on:** AM-01

### AM-03 — Pin AMIE rule versions alongside BPMN definition

**Domain:** AMIE boundary | **Owner:** AMIE + BOB Core | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Proposed

- **BPMN:** businessRuleTask
- **Reference evidence:** `SchemeDefinition<T>` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/SchemeDefinition-T)); evidence type: API surface.
- **Unity fit:** Prevent in-flight outcomes changing under updated AMIE configuration.
- **Gap:** Reference rule version or content hash from workflow instance.
- **Proof:** Rule revision does not alter already-started workflow.
- **Depends on:** HST-07

### AM-04 — Rules control business choices; BOB controls flow

**Domain:** AMIE boundary | **Owner:** AMIE + BOB Core | **Disposition:** Delegate | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Established principle

- **BPMN:** gateway / rule task
- **Reference evidence:** `IWorkflowRuleProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowRuleProvider)); evidence type: API surface.
- **Unity fit:** Do not treat vendor authorization rule API as AMIE business rule engine.
- **Gap:** Specify business vs actor-authorization rule namespaces.
- **Proof:** BPMN gateway calls business rule and logs decision version.
- **Depends on:** AM-01

### AM-05 — Evaluate DMN decision-table compatibility for AMIE

**Domain:** AMIE boundary | **Owner:** AMIE / Architecture | **Disposition:** Investigate | **Priority:** P2 | **Host:** Embedded + Central | **Wave:** W4 | **Status:** New candidate; not selected

- **BPMN:** businessRuleTask
- **Reference evidence:** `DecisionTable` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Plugins.BasicsPlugin/DecisionTable)); evidence type: API surface + OMG DMN outside reference.
- **Unity fit:** OMG DMN complements BPMN for decisions; do not embed rule tables in BOB. See https://www.omg.org/spec/DMN/1.6
- **Gap:** Decide whether AMIE native rule format should import/export a supported DMN subset.
- **Proof:** Prototype a generic rule/decision table with deterministic versioned inputs and outputs, independent of BOB.
- **Depends on:** AM-01

### KAF-01 — Event/command contracts for cross-capability workflows

**Domain:** Kafka integration | **Owner:** Kafka / BOB Central | **Disposition:** Delegate | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Established principle

- **BPMN:** messageFlow
- **Reference evidence:** `TMessageFlow` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMessageFlow)); evidence type: API surface.
- **Unity fit:** Message transport in Kafka, orchestration state in BOB.
- **Gap:** Topic naming, schema registry, headers, correlation.
- **Proof:** Cross-service message resumes right process, no shared DB access.

### KAF-02 — Message correlation and process subscriptions

**Domain:** Kafka integration | **Owner:** BOB Central + Kafka | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** messageCatchEvent
- **Reference evidence:** `CommandDefinition` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/CommandDefinition)); evidence type: API surface.
- **Unity fit:** Target message to instance or business key; avoid broadcast confusion.
- **Gap:** Correlation uniqueness, ordering, expiration.
- **Proof:** Out-of-order and duplicate messages do not corrupt process.
- **Depends on:** KAF-01

### KAF-03 — Backpressure, retry topics, DLQ

**Domain:** Kafka integration | **Owner:** Kafka / Capabilities | **Disposition:** Delegate | **Priority:** P1 | **Host:** Both | **Wave:** W3 | **Status:** Proposed

- **BPMN:** serviceTask / message events
- **Reference evidence:** `ProcessExecutionException` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Fault/ProcessExecutionException)); evidence type: API surface.
- **Unity fit:** Transport retry differs from workflow task retry.
- **Gap:** Policy matrix for transient/fatal and failed messages.
- **Proof:** Poison message quarantined without losing other work.
- **Depends on:** KAF-01

### CAP-01 — Capability-owned activity adapters

**Domain:** Capability boundary | **Owner:** Capabilities | **Disposition:** Delegate | **Priority:** P0 | **Host:** Embedded | **Wave:** W1 | **Status:** Established principle

- **BPMN:** serviceTask
- **Reference evidence:** `ActivityBase` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core/ActivityBase)); evidence type: API surface.
- **Unity fit:** Integration adapters stay inside their owning capability; BOB remains domain-neutral.
- **Gap:** Activity versioning and contract manifest.
- **Proof:** Two independent capability-specific operations remain in their owning services.
- **Depends on:** COR-07

### CAP-02 — No cross-capability private database access

**Domain:** Capability boundary | **Owner:** Capabilities / Security | **Disposition:** Delegate | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Established principle

- **BPMN:** serviceTask
- **Reference evidence:** `IWorkflowExternalParametersProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowExternalParametersProvider)); evidence type: API surface.
- **Unity fit:** Inter-service data exchange through APIs/events, not shared DbContext.
- **Gap:** Formal data ownership map and access policy.
- **Proof:** No capability reads another service private tables directly.

### CAP-03 — Direct EF Core for capability-owned SQL data

**Domain:** Capability boundary | **Owner:** Capabilities | **Disposition:** Delegate | **Priority:** P0 | **Host:** Embedded | **Wave:** W1 | **Status:** Established principle

- **BPMN:** serviceTask
- **Reference evidence:** `IWorkflowActionProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider)); evidence type: API surface.
- **Unity fit:** Avoid DB capability network hop when service owns MSSQL tables.
- **Gap:** DbContext lifetime and transaction isolation.
- **Proof:** Locally owned data operation uses registered adapter and local EF.

### CAP-04 — Managed Database Capability API for shared data

**Domain:** Capability boundary | **Owner:** Database Capability | **Disposition:** Delegate | **Priority:** P1 | **Host:** Central/remote | **Wave:** W2 | **Status:** Established principle

- **BPMN:** serviceTask
- **Reference evidence:** `IWorkflowActionProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider)); evidence type: API surface.
- **Unity fit:** Shared data owner exposes controlled domain contracts.
- **Gap:** Clarify centralized Unity data vs legacy shared data.
- **Proof:** Caller cannot execute arbitrary SQL against shared data.

### CAP-05 — Configurable workload composition across independent domains

**Domain:** Capability boundary | **Owner:** Unity Platform Integration | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W1-W3 | **Status:** Established principle

- **BPMN:** subProcess / serviceTask
- **Reference evidence:** `IWorkflowActionProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowActionProvider)); evidence type: API surface.
- **Unity fit:** Different applications assemble the same BOB Core, AMIE rules, and capability activities by configuration.
- **Gap:** Prove application-neutral contracts, configuration isolation and extension compatibility.
- **Proof:** Two unrelated configured processes execute with unchanged BOB and AMIE engine binaries.
- **Depends on:** CAP-01

### CAP-06 — High-volume workloads should not create needless workflow instances

**Domain:** Capability boundary | **Owner:** BOB Core / Capabilities | **Disposition:** Investigate | **Priority:** P1 | **Host:** Both | **Wave:** W3 | **Status:** Proposed

- **BPMN:** multi-instance
- **Reference evidence:** `WorkflowRuntimeBulkApi` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeBulkApi)); evidence type: API surface.
- **Unity fit:** Choose durable work units by business transaction, not every operation or item by default.
- **Gap:** Benchmark the appropriate checkpoint and workflow-instance granularity for varied workload types.
- **Proof:** Performance test compares per-item, per-batch and per-transaction instance strategies.
- **Depends on:** PST-14

### CAP-07 — No distributed EF or SQL transaction spanning services

**Domain:** Capability boundary | **Owner:** BOB Central + Kafka | **Disposition:** Delegate | **Priority:** P0 | **Host:** Central | **Wave:** W3 | **Status:** Established principle

- **BPMN:** collaboration / compensation
- **Reference evidence:** `IPersistenceProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IPersistenceProvider)); evidence type: API surface.
- **Unity fit:** Use local transactions and eventual coordination with compensations.
- **Gap:** Failure semantics, outbox/inbox, saga policy.
- **Proof:** Partial service failure does not leave hidden DB locks.
- **Depends on:** PST-07

### SEC-01 — Signed and authorized workflow/rule publication

**Domain:** Security | **Owner:** Unity Control Plane | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W2 | **Status:** Proposed

- **BPMN:** definitions
- **Reference evidence:** `IWorkflowRuleProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowRuleProvider)); evidence type: API surface.
- **Unity fit:** Only approved and authorized definitions reach execution hosts.
- **Gap:** Trust chain, approvals, revocation, tenant handling.
- **Proof:** Unapproved package cannot execute in any capability.

### SEC-02 — Resource quotas and restricted expression language

**Domain:** Security | **Owner:** BOB Core / AMIE | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Established constraint

- **BPMN:** conditionExpression
- **Reference evidence:** `ExpressionManager` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.CodeActions/ExpressionManager)); evidence type: API surface.
- **Unity fit:** Limit CPU/memory and forbid privileged arbitrary code.
- **Gap:** Sandbox semantics and max evaluation depth/time.
- **Proof:** Adversarial expression tests cannot access file/network/reflection.

### SEC-03 — Actor roles and authorization for human commands

**Domain:** Security | **Owner:** BOB Central + BET | **Disposition:** Build | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** userTask
- **Reference evidence:** `IWorkflowRuleProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowRuleProvider)); evidence type: API surface.
- **Unity fit:** Authorization differs from business rule evaluation.
- **Gap:** Identity provider, impersonation controls, ABAC/RBAC.
- **Proof:** Only eligible actor can claim/complete task.
- **Depends on:** BPM-14

### SEC-04 — Secrets not embedded in workflow definitions

**Domain:** Security | **Owner:** Capabilities / Vault | **Disposition:** Build | **Priority:** P0 | **Host:** Both | **Wave:** W1 | **Status:** Proposed

- **BPMN:** serviceTask
- **Reference evidence:** `IWorkflowExternalParametersProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/IWorkflowExternalParametersProvider)); evidence type: API surface.
- **Unity fit:** Workflow definitions reference secret IDs, not plaintext values.
- **Gap:** Secret provider integration and log scrub.
- **Proof:** No secrets in BPMN XML, cache files, logs, or outbox payloads.

### OPS-01 — Process logs, correlation and OpenTelemetry

**Domain:** Observability | **Owner:** BOB Core | **Disposition:** Build | **Priority:** P1 | **Host:** Both | **Wave:** W2 | **Status:** Proposed

- **BPMN:** all
- **Reference evidence:** `IProcessLogProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Logging/IProcessLogProvider)); evidence type: API surface.
- **Unity fit:** Trace executions through BOB/AMIE/Kafka/capabilities.
- **Gap:** Define span naming and PII redaction.
- **Proof:** One trace spans BOB, local AMIE, Kafka and an independently deployed capability, including failure.
- **Depends on:** COR-05

### OPS-02 — Process history query and event replay for audit

**Domain:** Observability | **Owner:** BOB Central | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** all
- **Reference evidence:** `ProcessHistoryItem` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ProcessHistoryItem)); evidence type: API surface.
- **Unity fit:** Operators need reliable execution history.
- **Gap:** Replay history is not same as safely replaying effects.
- **Proof:** History reconstructs decisions, versions and manual interventions.
- **Depends on:** PST-05

### OPS-03 — Metrics, rate limits and SLO dashboards

**Domain:** Observability | **Owner:** BOB Central + BET | **Disposition:** Build | **Priority:** P1 | **Host:** Both | **Wave:** W3 | **Status:** Proposed

- **BPMN:** all
- **Reference evidence:** `ProcessLogEntry` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Logging/ProcessLogEntry)); evidence type: API surface.
- **Unity fit:** Observe p95 rule latency, queue lag, DB pressure, API throttling.
- **Gap:** Choose targets after baseline test.
- **Proof:** Load test emits host-specific latency and error metrics.
- **Depends on:** OPS-01

### OPS-04 — Workflow dry-run, simulation and pre-execution tracing

**Domain:** Observability | **Owner:** BOB Core / QA | **Disposition:** Defer | **Priority:** P2 | **Host:** Both | **Wave:** W4 | **Status:** Proposed

- **BPMN:** all
- **Reference evidence:** `OfflineApi` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/OfflineApi)); evidence type: API surface.
- **Unity fit:** Test routing without destructive capability actions.
- **Gap:** Mock side effects and AMIE rule snapshots.
- **Proof:** Simulation predicts gateway paths and records mock effects only.
- **Depends on:** BPM-26

### OPS-05 — Bulk execution and process operations API

**Domain:** Observability | **Owner:** BOB Central | **Disposition:** Defer | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** bulk
- **Reference evidence:** `WorkflowRuntimeBulkApi` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntimeBulkApi)); evidence type: API surface.
- **Unity fit:** Operationally useful for bulk starts/retries; avoid excessive write load.
- **Gap:** Role restrictions, dedupe and page sizes.
- **Proof:** Bulk command retries safely and audits each item.
- **Depends on:** SEC-03

### OPS-06 — Versioned workflow management REST API

**Domain:** Observability | **Owner:** BOB Central | **Disposition:** Build | **Priority:** P1 | **Host:** Central | **Wave:** W3 | **Status:** Proposed

- **BPMN:** management
- **Reference evidence:** `WorkflowRuntime` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime)); evidence type: API surface.
- **Unity fit:** BET starts/monitors processes; embedded calls remain local.
- **Gap:** Define read/start/suspend/resume/history endpoints.
- **Proof:** OpenAPI supports status/history without exposing internal DB.
- **Depends on:** HST-03

### OPS-07 — Business Enablement dashboard and task inbox

**Domain:** Observability | **Owner:** Business Enablement Website | **Disposition:** Delegate | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** userTask
- **Reference evidence:** `ApprovalPlugin` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Plugins/ApprovalPlugin)); evidence type: API surface.
- **Unity fit:** Human workflow UI belongs to BET, not engine core.
- **Gap:** Approvals, comments, retries, dashboards and access control.
- **Proof:** Authorized user completes suspended task, status updates.
- **Depends on:** BPM-14

### OPS-08 — Designer and BPMN visual editing

**Domain:** Observability | **Owner:** Business Enablement Website | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** BPMNDI
- **Reference evidence:** `DesignerSettings` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Model/DesignerSettings)); evidence type: API surface.
- **Unity fit:** Core/runtime first; visual tooling later.
- **Gap:** Roundtrip, schema validation and approved publishing.
- **Proof:** Editing diagram does not silently change process behavior.
- **Depends on:** COR-15

### OPS-09 — Forms plugin and richer task forms

**Domain:** Observability | **Owner:** Business Enablement Website | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** userTask
- **Reference evidence:** `IFormDataProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IFormDataProvider)); evidence type: API surface.
- **Unity fit:** Forms useful only once human tasks exist.
- **Gap:** Form schema, versioning and validation.
- **Proof:** Resume works with version-pinned form schema.
- **Depends on:** OPS-07

### OPS-10 — Actor inbox/outbox and approval history

**Domain:** Observability | **Owner:** BOB Central / BET | **Disposition:** Defer | **Priority:** P2 | **Host:** Central | **Wave:** W4 | **Status:** Proposed

- **BPMN:** userTask
- **Reference evidence:** `IApprovalProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Persistence/IApprovalProvider)); evidence type: API surface.
- **Unity fit:** Human work queue and audit distinct from Kafka transport inbox.
- **Gap:** Approval delegation, expiration, audit retention.
- **Proof:** Reassignment audited; action authorized.
- **Depends on:** OPS-07

### OPS-11 — Working calendar / business day timers

**Domain:** Observability | **Owner:** BOB Central | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** timerEventDefinition
- **Reference evidence:** `ICalendar` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime.Calendars/ICalendar)); evidence type: API surface.
- **Unity fit:** Time periods may depend on holidays and working hours.
- **Gap:** Calendar provider, timezone and country rules.
- **Proof:** Business-hours SLA timer survives DST/holiday.
- **Depends on:** BPM-09

### OPS-12 — Localization of workflow labels

**Domain:** Observability | **Owner:** Business Enablement Website | **Disposition:** Defer | **Priority:** P3 | **Host:** Central | **Wave:** W5 | **Status:** Proposed

- **BPMN:** BPMNDI
- **Reference evidence:** `ILocalizationProvider` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/ILocalizationProvider)); evidence type: API surface.
- **Unity fit:** UI concern; keep runtime identifiers stable.
- **Gap:** Multilingual labels and process versioning.
- **Proof:** Switch display locale without altering execution.

### OPS-13 — Source API surface parity is not a scope goal

**Domain:** Observability | **Owner:** BOB Core | **Disposition:** Exclude | **Priority:** OUT | **Host:** N/A | **Wave:** Excluded | **Status:** Established constraint

- **BPMN:** all
- **Reference evidence:** `WorkflowRuntime` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime)); evidence type: API surface.
- **Unity fit:** Only implement features justified by Unity and BPMN target.
- **Gap:** Do not pursue one-to-one OptimaJet class replication.
- **Proof:** Each accepted feature linked to a business/architecture acceptance.

### OUT-01 — Other OptimaJet database providers

**Domain:** Out of scope | **Owner:** BOB MSSQL | **Disposition:** Exclude | **Priority:** OUT | **Host:** N/A | **Wave:** Excluded | **Status:** Established constraint

- **BPMN:** persistence
- **Reference evidence:** `PersistenceProviderId` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core/PersistenceProviderId)); evidence type: API surface.
- **Unity fit:** No SQLite/MySQL/Mongo/Postgres/Oracle workflow persistence.
- **Gap:** Eliminate provider-specific assemblies and migrations.
- **Proof:** Only MSSQL provider in dependency graph.

### OUT-02 — Copy OptimaJet proprietary source/API shapes

**Domain:** Out of scope | **Owner:** Engineering governance | **Disposition:** Exclude | **Priority:** OUT | **Host:** N/A | **Wave:** Excluded | **Status:** Established constraint

- **BPMN:** all
- **Reference evidence:** `WorkflowRuntime` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Core.Runtime/WorkflowRuntime)); evidence type: API surface.
- **Unity fit:** Reference capabilities and documented concepts; implement independent original engine.
- **Gap:** Review licenses if evaluating vendor packages.
- **Proof:** Independent code and documentation provenance.

### OUT-03 — Bundled AD/files/email plugins as a general platform

**Domain:** Out of scope | **Owner:** Capabilities | **Disposition:** Defer | **Priority:** P3 | **Host:** N/A | **Wave:** W5 | **Status:** Proposed

- **BPMN:** serviceTask
- **Reference evidence:** `IWorkflowPlugin` ([API](https://api.workflowengine.io/core/OptimaJet.Workflow.Plugins/IWorkflowPlugin)); evidence type: API surface.
- **Unity fit:** Add integrations only when Unity capability needs them.
- **Gap:** Map each plugin to capability-owned registered adapter.
- **Proof:** Core contains no AD/file/email dependencies.

### OUT-04 — Support every BPMN 2.0.2 construct in first release

**Domain:** Out of scope | **Owner:** BOB Core | **Disposition:** Exclude | **Priority:** OUT | **Host:** N/A | **Wave:** Excluded | **Status:** Established constraint

- **BPMN:** full BPMN
- **Reference evidence:** `BpmnPlugin` ([API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin/BpmnPlugin)); evidence type: API surface.
- **Unity fit:** Define an executable subset, reject remaining constructs.
- **Gap:** Publish conformance statement and unsupported list.
- **Proof:** Unsupported BPMN cannot silently import as automatic flow.

## BPMN Coverage

- **BPMN XML definitions (W1, Implement):** Vendor: Importer converts selected elements into native schemes. Unity: Canonical BPMN 2.0.2 source; compile to shared IR. Proof: Validate XML + semantic model before publish. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/BpmnConverter) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Start event (none) (W1, Implement):** Vendor: Start event is a supported converted shape. Unity: Start initial token deterministically. Proof: One start event => one workflow instance. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/StartEvent) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **End event (none) (W1, Implement):** Vendor: End event is a supported converted shape. Unity: Consume token; complete when no active tokens remain. Proof: Parallel branches finish according to token rules. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/EndEvent) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Service task (W1, Implement):** Vendor: Converts to custom service task referencing named application actions. Unity: Invoke registered local DI activity; no central remote call per step. Proof: Capability-local handler executes with deterministic attempt semantics. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ServiceTaskActivity) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Exclusive gateway (W1, Implement):** Vendor: Vendor converter imports named/expressed conditions and default flow. Unity: Use AMIE result or approved expressions for branching. Proof: Exactly one path, default branch checks. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ExclusiveGateway) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Parallel gateway (W1, Implement):** Vendor: Vendor converter maps to parallel transitions and join build steps. Unity: Implement token fork/join correctly. Proof: Parallel fixture with branch delays synchronizes once. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/ParallelGateway) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Business rule task (W1, Implement via AMIE):** Vendor: Vendor importer retains as ordinary task with warning; no implementation. Unity: Bind AMIE rule invocation explicitly. Proof: Rule task invokes cached versioned AMIE rule. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TBusinessRuleTask) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Sequence flows / conditions (W1, Implement):** Vendor: Vendor importer converts flows into native transitions. Unity: Source/target refs and deterministic transition semantics. Proof: Invalid connections rejected; conditions evaluated correctly. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TSequenceFlow) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **BPMNDI visual geometry (W2, Retain metadata):** Vendor: Vendor has BPMN diagram model types. Unity: Keep diagram representation separate from runtime IR. Proof: Import/export geometry without changing flow. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/BpmnDiagram) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Embedded subprocess (W2, Implement):** Vendor: Vendor imports nonempty subprocess as inline scheme, not a runtime child. Unity: Explicit nested variable scope and lifecycle semantics. Proof: Nested fixture validates exit/cancel propagation. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/SubprocessNodeVisitor) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Call activity (W2, Implement):** Vendor: Vendor default importer creates ordinary task with issue; no auto invocation. Unity: Invoke separately versioned reusable workflow definition. Proof: Call referenced pinned definition exactly once. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Import/CallActivityNodeVisitor) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Multi-instance sequential (W2, Implement):** Vendor: BPMN model exists; do not infer imported execution behavior. Unity: Sequential iteration with item scope. Proof: 100-item sequence processes once in order. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMultiInstanceLoopCharacteristics) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Terminate end event (W2, Implement):** Vendor: Vendor has special converted Terminate Event shape. Unity: Terminate all tokens in correct scope. Proof: Parallel sibling tasks receive cancellation. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/TerminateEvent) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Timer start/catch (W2, Implement durable):** Vendor: Supports date/duration/expression; vendor timeCycle unsupported. Unity: Durable timer wakeup using MSSQL. Proof: Restart/failover does not drop or double-fire timer. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/TimerCatchEvent) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Message catch (W3, Implement durable):** Vendor: Vendor maps message wait to command, not broker subscription. Unity: Explicit Kafka correlation and durable wait. Proof: Wrong message does not advance instance. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Elements/MessageCatchEvent) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Receive task (W3, Implement durable):** Vendor: Vendor maps receive task to command-triggered transition. Unity: Wait on correlated message safely. Proof: Duplicate receipt dedupes. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TReceiveTask) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Send task / message throw (W3, Implement):** Vendor: Vendor send task remains ordinary with warning; no messaging side effect. Unity: Outbound event via Kafka/outbox, not BPMN runtime transport itself. Proof: SQL commit + eventual event delivery. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TSendTask) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Event-based gateway (W4, Implement):** Vendor: Vendor routes following timer/message catches via triggers. Unity: Atomic competing waits; first winner cancels alternatives. Proof: Simultaneous timer/message selects one. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TEventBasedGateway) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Inclusive gateway split/join (W4, Defer until correct):** Vendor: Vendor documents general inclusive join as unsupported. Unity: Must implement actual inclusive join if accepted. Proof: Activated-path join cases incl nested splits. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TInclusiveGateway) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Boundary timer/error (W4, Implement after waits):** Vendor: Vendor converts some boundary events as transitions; noninterrupting semantics not preserved. Unity: Handle interrupting and noninterrupting semantics explicitly. Proof: Task timeout cancels only when configured. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TBoundaryEvent) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **User task (W4, Implement with BET):** Vendor: Vendor user task import only ordinary activity; no forms or lifecycle. Unity: Durable human task with assignment and authorized completion. Proof: Suspends for approval; resumes after authorized action. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TUserTask) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Parallel multi-instance (W4, Implement bounded):** Vendor: Model type exists; runtime semantics not established by model. Unity: Bounded worker fanout for arbitrary multi-instance business workloads. Proof: Concurrency cap observed; recover partial failures. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TMultiInstanceLoopCharacteristics) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Compensation (W4, Defer pending proof):** Vendor: Model type exists; vendor import behavior not established here. Unity: Register and invoke safe compensating actions. Proof: Compensation order and idempotency fixture. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TCompensateEventDefinition) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Error / escalation events (W4, Defer pending proof):** Vendor: Model type exists; vendor supports selected boundary event conversion only. Unity: Structured error propagation across activity scopes. Proof: Error handler catches only matching errors. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TErrorEventDefinition) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Signal event (W5, Defer):** Vendor: Vendor signal catch ignored as ordinary activity, warning. Unity: Distinct broadcast model if justified. Proof: Subscriptions and delivery semantics tested. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TSignalEventDefinition) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Conditional event (W5, Defer):** Vendor: Vendor conditional catch ignored as ordinary activity, warning. Unity: Controlled condition triggering without polling explosion. Proof: State change triggers exactly once. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TConditionalEventDefinition) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Event subprocess (W5, Defer):** Vendor: BPMN model exists; no evidence of converted semantics. Unity: Define scope interruption only if use case demands. Proof: Interrupting/noninterrupting fixture. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TSubProcess) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Pools/lanes/message flows (W5, Model separately):** Vendor: Vendor lanes ignored; pools become schemes; message transport not generated. Unity: Keep capability boundaries; Kafka transports interactions. Proof: Cross-pool workflow uses explicit topic contracts. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TCollaboration) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Complex gateway (Excluded, Reject):** Vendor: Vendor activation condition not implemented. Unity: Reject until justified by actual workflows. Proof: Deployment validation fails with precise diagnostic. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TComplexGateway) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Ad-hoc subprocess (Excluded, Reject):** Vendor: Model class exists; no vendor execution semantics shown. Unity: Not in first supported subset. Proof: Deployment validation fails with precise diagnostic. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TAdHocSubProcess) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)
- **Arbitrary script task (Excluded, Reject executable scripts):** Vendor: Vendor does not import script as executable code. Unity: Allow preapproved handler only, never arbitrary script. Proof: No user-supplied C# execution. [API](https://api.workflowengine.io/bpmn-plugin/OptimaJet.Workflow.BpmnPlugin.Model/TScriptTask) / [Vendor guide](https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/)

## Risks and Design Decisions

- **G-01 — Definition subset and conformance claim (High, W1):** Which BPMN 2.0.2 constructs are supported in v1? — Freeze P0/P1 subset; comprehensive fixtures.
- **G-02 — Token flow and parallel joins (Critical, W1):** What state model supports concurrent forks and recovery? — Document token/instance model; run fork/join stress tests.
- **G-03 — Version pin across workflow and rule sets (High, W1):** What happens when rules change mid-process? — Persist rule version/hash per instance or task.
- **G-04 — How do activities bind without networking? (High, W1):** How is DI scope resolved safely in embedded host? — Proof with two capability-local activity bindings during registry outage.
- **G-05 — What expressions are allowed? (Critical, W1):** Can a rule execute arbitrary code or consume unlimited resources? — Constrained interpreter and quotas, never execute arbitrary C#.
- **G-06 — Call activity target version (High, W2):** Can parent and child process versions drift? — Pin call target and validate dependency manifest.
- **G-07 — Package and signature format (High, W2):** How are compatible approved definitions shipped to capabilities? — Package manifest + integrity check + atomic swap.
- **G-08 — Memory-only vs durable support (High, W2):** When may embedded workflows block/await timers? — Host capability matrix and refusal to run unsafe waits.
- **G-09 — Schema and transaction boundaries (Critical, W2):** How do state checkpoints and outbox commits interact? — Single SQL transaction per durable transition + outbox.
- **G-10 — Concurrency ownership (Critical, W3):** What prevents two central workers executing same instance? — Lease + fencing + rowversion + crash tests.
- **G-11 — Correlation and duplicate messages (Critical, W3):** How do incoming events map to the right wait? — Correlation key, inbox dedupe, explicit subscriptions.
- **G-12 — Unknown side effects after crash (Critical, W3):** Did a downstream side effect happen before its outcome was checkpointed? — Idempotency and reconciliation callback contract.
- **G-13 — High-volume workload execution granularity (High, W3):** One instance per item, batch or business transaction? — Benchmark alternative granularities; bounded parallelism.
- **G-14 — Human task contract (Medium, W4):** How are assignment, completion, auth, forms versioned? — User task state machine and BET contract.
- **G-15 — Inclusive join correctness (High, W4):** How to handle nontrivial activated-path synchronization? — Do not enable until normative fixtures pass.
- **G-16 — Interrupting vs noninterrupting boundary events (High, W4):** Can boundary handler create token without cancelling task? — Explicit event-subscription semantics, negative fixtures.
- **G-17 — Safe offline behavior (High, W2):** Which revoked policies cannot be executed offline? — Define maximum stale age and fail-closed rules.
- **G-18 — Interoperability with standard modelers (Medium, W2):** Will vendor BPMN XML extensions be accepted? — Strict core model + documented extension policy.
- **G-19 — API type != execution semantics (High, W1):** Which OptimaJet features actually run vs just deserialize? — Source API -> vendor behavior -> our test chain.
- **G-20 — Shared DB meaning (Medium, W2):** Is shared data a central Unity DB or legacy shared applications? — Catalog ownership and choose API vs direct EF.
- **G-21 — Timers, leases and transaction SQL load (High, W3):** How many workers/instances before locks or IO dominate? — SQL load test, indexes and recovery injection.
- **G-22 — Copyright/licensing boundaries (Medium, W1):** Are any vendor assemblies/licenses to be used? — Use API docs as references only, evaluate licenses separately.
- **G-23 — Should AMIE support DMN decision tables? (Medium, W4):** DMN 1.6 complements BPMN but has not been selected for Unity. — Evaluate import/export/interpreter scope without coupling to BOB.

## Delivery Waves

- **W0 — Architecture baseline (Review):** Finalize BOB scope, AMIE/BOB boundary, BPMN P0 subset and MSSQL-only ADR. Exit: Approved ADR; feature matrix; source evidence; critical risks tracked.
- **W1 — Shared core + embedded POC (Build next):** BPMN parser/validator, IR, token engine, service tasks, exclusive/parallel gateways, AMIE rule task, local DI. Exit: Generic conformance fixtures pass in embedded host; two unrelated local configurations execute while registry is offline.
- **W2 — Versioning and MSSQL durability (Planned):** Definition publication/cache, immutable versions, snapshots, timers, checkpoints, crash-safe storage. Exit: V1 survives V2 publish; timer resumes after restart; correct SQL transactions.
- **W3 — Central orchestration + Kafka (Planned):** Central host; leased multi-worker processing; outbox/inbox; message correlation; generic cross-capability orchestration. Exit: Two unrelated cross-service processes survive retries, duplicate messages and worker failures without engine modifications.
- **W4 — Advanced BPMN + human tasks (Conditional):** Boundary events, event gateways, mult-instance parallel, inclusive/compensation if proven, BET tasks. Exit: Each accepted construct passes negative fixtures; authorized human completion; stress tests.
- **W5 — Design tools and optional extensions (Deferred):** BPMN visual editor, forms, richer clocks/calendars, simulation, optional special events. Exit: Designer round-trip; extension isolation; no core dependencies on unused plugins.

## Intended Unity Workloads (Outside BOB Core Scope)

| Workload | BOB responsibility | AMIE responsibility | Capability boundary | Planning status |
| --- | --- | --- | --- | --- |
| CMDB enrichment | Configure appropriate import / processing orchestration | Configure data mappings and decisions if required | Data and account service adapters remain capability-owned | Illustrative example; not a BOB requirement |
| Policy Drift | Configure policy scan, detection, escalation or remediation workflow as needed | Configure policy interpretation and drift decisions | Policy/infrastructure integrations remain capability-owned | Intended workload; detailed contracts pending |
| Legacy application modernization | Configure extracted processes as reusable BPMN workflows | Replace hardcoded rules with approved rule configurations | Each modernized capability owns APIs and data | Intended portfolio; individual app scope pending |
| Future workloads | Compose existing activities and new process definitions | Reuse rules or publish approved new rules | Build adapter primitives only when necessary | Open-ended, platform-agnostic |

These are **applications of Unity**, not items that BOB Core must implement to be complete. Reusable engine validation must not depend on a single application domain.

## Sources

- **SRC-01 User-provided OptimaJet API capture:** Workflow Engine .NET API reference downloaded as workflowengine-api-docs.md. https://api.workflowengine.io/ Uploaded reference; API type existence and signatures, not conformance proof.
- **SRC-02 OptimaJet Core API:** WorkflowRuntime, ProcessInstance, activity/transition/parameter models. https://api.workflowengine.io/core/ API structure and extension points.
- **SRC-03 OptimaJet BPMN API:** Importer, BPMN model classes, custom element adapters. https://api.workflowengine.io/bpmn-plugin/ Model types do not imply executable semantics.
- **SRC-04 OptimaJet MSSQL API:** SQL Server persistence providers, workflow state models and migrations. https://api.workflowengine.io/sql-server/ Only desired BOB persistence provider.
- **SRC-05 OptimaJet Web API:** Management API surface for workflows, designer and runtime. https://api.workflowengine.io/web-api/ Reference for later administrative API; not mandatory on embedded path.
- **SRC-06 OptimaJet BPMN plugin overview:** Imported BPMN converted to native workflows, not full conformance. https://docs.workflowengine.io/plugins/bpmn-plugin/ Behavioral clarification from vendor product docs; checked 2026-11-10.
- **SRC-07 OptimaJet BPMN supported elements:** Detailed task/gateway/event mapping and importer limits. https://docs.workflowengine.io/plugins/bpmn-plugin/supported-elements/ Behavioral reference: unsupported behavior can be retained only as shape.
- **SRC-08 OMG BPMN 2.0.2 standard:** Formal standard and normative machine-readable schemas. https://www.omg.org/spec/BPMN/2.0.2/About-BPMN/ Normative target; BOB compliance must be scoped to tested subset.
- **SRC-10 OMG DMN 1.6 formal standard:** Optional evaluation for AMIE decision table interoperability. https://www.omg.org/spec/DMN/1.6 Formal DMN 1.6 September 2026; proposed evaluation only, not a BOB requirement.
- **SRC-09 Unity architecture working baseline:** Conversation: AMIE/BOB two-level runtimes, local execution, Kafka, capability data ownership.  User-established architectural requirements; not third-party evidence.
