# Prior design history

`INDEX.md` and `docs/` at archive root are the current authoritative v1.1 handoff. Historical v0.2-v0.7 materials and OptimaJet research remain here for comparison/provenance only. Do not promote superseded examples as requirements without a reviewed decision. This archive does not contain a real Unity source repository or bank security approvals.
