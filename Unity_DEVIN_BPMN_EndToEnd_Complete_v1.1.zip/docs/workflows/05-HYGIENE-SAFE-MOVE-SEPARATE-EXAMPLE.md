# Workflow 05 - Account Hygiene / Privileged Safe Move (Separate from Policy Drift)

This is a separate PAM compliance business workflow. Example: an account is found with privilege/safe placement inconsistent with approved rules; AMIE decides whether remediation is appropriate; a registered CyberArk operation may move it after controls/approval. It must not be conflated with ZIP/INI policy baseline drift or DCMS custom-attribute enrichment.

```mermaid
flowchart TD
  A[Manual / approved schedule / API] --> B[Query eligible accounts via approved Data/CyberArk capability]
  B --> C[GetAccount and current safe]
  C --> D[AMIE: placement rule / policy]
  D --> E{Violation?}
  E -->|No| F[Mark compliant]
  E -->|Yes| G[Propose target safe + reason]
  G --> H[Control / approval check]
  H -->|Denied| I[Finding only]
  H -->|Authorized| J[CyberArk.MoveAccount]
  J --> K[Read/verify target safe]
  K --> L[Row outcome + audit]
  F --> L
  I --> L
  L --> M[Report / optional Email / Business Dashboard]
```

BE config: select trigger, pick registered data enumeration/`GetAccount`, bind AMIE rule with permitted target safe list, add conditional gateway, attach required approval and safe-move operation, configure denial/outcome branch. On save validate safe permissions, account scope, target vault/safe, idempotency and reconciliation; publish approved DEV. User sees compliant, violations found, remediated, requires approval, failed/unknown. Audit captures who authorized the move and before/after safe references (classified). Demonstrates operation reuse from DCMS but a distinct configured app.

Initial demo can be read-only finding generation (no actual move), and should mark remediation capability as deferred if the underlying operation/security approval is not available.
