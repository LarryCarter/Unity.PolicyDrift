# Workflow 01 - DCMS CSV -> CyberArk Custom Attribute Enrichment

## Established business behavior

DCMS imports a CSV to a table, assigns the batch a number, gives each row a GUID, processes rows **one by one**, looks up the CyberArk account, updates/adds the platform custom attribute values **in memory**, calls CyberArk add/update, and emails a final report containing passed/failed/successful records and reasons. This is a workload using Unity; BOB does not hardcode DCMS.

## Required registered operation contracts (logical names)

| Step | Operation | Runtime location | AMIE inputs/outcomes | Expected result |
|---|---|---|---|---|
| Stage | `NAS.StageBatch@1` (data owner may differ) | Data/NAS EF API | validate CSV contract | batchId + N row GUIDs |
| Read | `NAS.GetRowsPage@1` | Data API from worker | row data in scoped context | cursor + typed row |
| Account | `CyberArk.GetAccount@1` | embedded CyberArk BOB | account and platform metadata | current account or NOT_FOUND |
| Validate | `DCMS.Eligibility@1` | existing AMIE | row/account/metadata | ALLOW, SKIP, REJECT + reason |
| Map | `DCMS.MapAttributes@1` | existing AMIE | four CSV fields, account and platform | allowed typed changeset |
| Apply | `CyberArk.ApplyCustomAttributes@1` | embedded local | approved change set | modified in-memory account |
| Write | `CyberArk.AddOrUpdateAccount@1` | embedded local | decision permits write | confirmed outcome or uncertain |
| Row outcome | `NAS.MarkRowOutcome@1` | Data API | status + reason | persisted idempotent result |
| Report | `Reporting.CreateBatchReport@1` | Reporting capability | aggregate result ref | reportRef |
| Email | `Email.SendReport@1` | Email capability via Kafka | recipients/template policy | message outcome |

These are **proposed interface names**. DEVIN must map them to already implemented CyberArk and data code, and add missing reusable primitives only.

## BE authoring procedure

1. Workbench > choose DCMS > Workflow Library > create `DCMS.BatchEnrichment` from Batch Template. Assign owner, scope, control/runbook.
2. Trigger Designer > Manual CSV > required account ID, platform ID and four attributes; choose approved staging operation and file validation policy.
3. Data Sources > bind the row-read and status-write operations from the owning NAS/EF/API capability; bind `batchId` and `rowGuid` fields explicitly.
4. BPMN Canvas > Start -> Stage -> Call/Dispatch ProcessRowBatch -> Wait for confirmed outcome -> Report -> Email -> End. Add failure path and report error behavior.
5. Embedded subprocess > sequential multi-instance (`concurrency=1`), GetAccount, AMIE Eligibility, XOR ALLOW/SKIP/REJECT, Map Attributes, Apply In Memory, AddOrUpdate, Persist Result.
6. For each task use operation inspector: `operationKey@version`, inputs (current row, prior outputs or AMIE output), host, timeout, side effect, audit policy. Add no raw CyberArk URL.
7. Validation > schema check and synthetic 5-row fixture; publish immutable DEV version. Choose UI roles for upload and viewing own batch only.
8. BE user uploads CSV; obtains accepted batch number + run link. Business dashboard moves through Pending, In Progress, Success/Skipped/Failed/Review. BPMN view restricted to support/operator.
9. Final report uses persisted row results, not inferred from rule output. Email send status is separately tracked.

## Detailed sequence

```mermaid
sequenceDiagram
  autonumber
  actor User as CVIS User
  participant UI as BE Blazor
  participant API as Unity API
  participant NAS as Data/NAS EF API
  participant BOB as Central BOB
  participant K as Kafka
  participant C as CyberArk Capability (Embedded BOB)
  participant A as AMIE
  participant EPV as CyberArk API
  participant E as Reporting / Email
  User->>UI: Upload CSV (approved schema)
  UI->>API: POST upload + start
  API->>NAS: StageBatch(fileRef)
  NAS-->>API: batchId, row GUIDs
  API->>BOB: Start pinned workflow
  API-->>UI: 202 runId, batchId
  BOB->>K: ProcessBatch command (outbox)
  K->>C: Deliver command
  loop Each staged row sequentially
    C->>NAS: GetRowsPage / next row
    C->>EPV: GetAccount(accountId)
    C->>A: Eligibility + MapAttributes
    A-->>C: Decision and changeset
    alt Allowed and needs write
      C->>EPV: AddOrUpdateAccount(modified account)
      EPV-->>C: Write outcome
    else Skip/reject
      Note over C: Persist safe reason
    end
    C->>NAS: MarkRowOutcome(rowGuid,status,reason)
    NAS-->>UI: Aggregate/projection refresh
  end
  C->>K: Completed/failed batch outcome
  K->>BOB: Correlate and resume wait
  BOB->>E: Create report + send via Email Capability
  E-->>BOB: ReportRef + delivery status
  BOB-->>UI: Completed or completed with errors
```

## Failure and recovery requirements

- CSV missing required data -> no run, user sees row/schema errors.
- Missing account -> configured SKIP/REJECT branch; no implicit create.
- Attribute mismatch -> AMIE validation result; no write; record reason.
- CyberArk timeout after request -> `WRITE_OUTCOME_UNKNOWN`, reconcile by approved read; do **not** automatically retry a potentially completed write.
- Row status update fails -> retry idempotent `rowGuid/version` command, preserve write outcome proof; do not re-write CyberArk.
- Kafka message duplicate -> inbox returns same accepted run; no second batch mutation.
- Report email failure -> account outcomes unchanged; email status failed/pending, operator can retry notification with idempotent message ref.
- Pause at row boundary, not mid-EPV request; stop scheduling next row.

## Acceptance fixture

Five rows: #1 write success, #2 no change, #3 missing account, #4 AMIE validation reject, #5 simulated EPV timeout / reconciliation. Verify total = terminal + in-progress + pending; rows retain GUIDs and reasons; report lists distinct validation and write outcomes; dashboard eventually updates from authoritative projection. Link all events by correlation and pinned versions.
