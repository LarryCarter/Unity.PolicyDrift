# Workflow Examples - Reusable Platform Patterns

These are **example application compositions**, not application-specific branches in BOB, AMIE, BE or the Capability SDK. Statuses: `USER-DEFINED` denotes explicitly described current behavior; `PROPOSED` denotes planned reusable primitive; `VERIFY` requires actual repository/manifest; `DEFERRED` is not required for the initial demo.

## Common workflow blueprint

```mermaid
flowchart LR
  Trigger[Trigger Source] --> Normalize[Authorized Trigger Normalizer]
  Normalize --> Central[Central BOB Workflow]
  Central --> Data[Typed Data Capability or NAS EF API]
  Central --> Bus[Kafka Command]
  Bus --> Embedded[Embedded BOB at Capability]
  Embedded --> Rule[Existing AMIE Rule]
  Rule --> Handler[Registered Handler]
  Handler --> Outcome[Typed Outcome + Audit]
  Outcome --> Bus2[Kafka Outcome]
  Bus2 --> Central
  Central --> Report[Reporting + Email Capability]
  Central --> Project[Business Projection]
  Project --> BE[BE Business Dashboard]
```

For very short wholly local workflows, central BOB/Kafka hops can be omitted; local BOB shares the same interpreter. For cross-service work, durable dispatch/correlation is necessary. Rules decide; handlers perform externally verified side effects.

## Scenarios and feature reuse

| Application / test slice | Trigger | Data boundary | BOB shape | AMIE | Capability operations | Dashboard result |
|---|---|---|---|---|---|---|
| DCMS attribute enrichment | BE CSV now; API later | stage batch + GUID rows via data owner | central batch + embedded sequential row subprocess | eligibility + mapping + skip decision | stage/page/outcomes, GetAccount, ApplyAttributes, AddOrUpdate, Report, Email | counts per row and reasons |
| Account Delete | user/form/API after approval | account & request refs | approval wait -> guarded delete -> verification | eligibility, retention, delete policy | GetAccount, VerifyDelete, DeleteAccount, Notify | request status + approval + outcome |
| NAS/EF data workflow | user/API/BOB | owned EF DbContext behind typed NAS API | typed service tasks, pagination | validation and transform | typed GET/POST/Update only | batch/count summary |
| Policy Drift | AutoSys via approved trigger | EPV API ZIP/INI + policy baseline store | central trigger + ingestion/compare subprocess | normalization, compare, status | DownloadPolicyBundle, ParsePolicy, BaselineGet/Upsert, WriteDrift, Report/Email | policies processed/no drift/drift/missing |
| Account hygiene / safe move | schedule/manual | EVD/reporting metadata + CyberArk API | query -> rule -> approval -> move | safe-placement decision | GetAccount, MoveAccount, Verify, Report | compliance and remediation result |

## Critical invariants

1. No business app appears as an `if` inside generic BOB or AMIE engine.
2. Bound `operationKey@contractVersion` must be published/authorized and available in target environment.
3. AMIE cannot perform destructive writes; it outputs decisions or typed changesets, and capability handler enforces scope/side-effect controls.
4. Each async Kafka boundary has durable wait/correlation, inbox/outbox, idempotency and late-outcome rules.
5. Each workflow references pinned BPMN/rule/operation/contract versions; mid-flight version migration not MVP.
6. Process user-facing counts are projections of business data and result events; not inferred solely from BPMN token location.
7. Background schedulers must not be given unrestricted Kafka/DB credentials; use approved adapter identity and policy.
8. Unverified NAS entity names, CyberArk endpoints or AutoSys AEWS paths remain placeholders and must be sourced from real approved contracts.

## Failure state taxonomy

`REJECTED_INPUT`, `VALIDATION_FAILED`, `NOT_FOUND`, `SKIPPED_NO_CHANGE`, `BLOCKED_POLICY`, `AWAITING_APPROVAL`, `WRITE_CONFIRMED`, `WRITE_REJECTED`, `WRITE_OUTCOME_UNKNOWN`, `RETRYABLE_INFRA`, `FAILED_PERMANENT`, `COMPLETED_WITH_ERRORS`. Central workflow must distinguish batch business status from reporting/email send status.
