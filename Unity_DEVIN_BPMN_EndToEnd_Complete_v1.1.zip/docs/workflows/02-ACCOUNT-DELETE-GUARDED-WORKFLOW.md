# Workflow 02 - Guarded CyberArk Account Delete

## Intent and risk

Reusable application for a **high-impact privileged deletion**. Only approved roles and narrowly scoped identities may request or approve. This is not merely a `DeleteAccount` service task placed after a button click. If control/approval APIs or BPMN user-task semantics do not yet exist, demo the full screen and safe simulated backend outcome **without performing an actual deletion**. DEVIN may not assume bank authorization.

## BE configuration

1. Create application/workflow `PAM.AccountDeletion` with owner, runbook, change ticket policy and explicit deletion permission.
2. Trigger > authenticated request form (accountRef, reason, approved request ID, expected account state, dryRun=true default); optionally API with trusted caller.
3. Add CyberArk capability `GetAccount`, AMIE rule `AccountDelete.Eligibility@1` (ownership, retention, target, allowed environment, policy), `CyberArk.VerifyDeleteCandidate`, and a durable control approval step.
4. Designer > Start -> GetAccount -> Eligibility -> exclusive gateway -> Preview Impact -> Approval Wait -> guarded DeleteAccount -> Verify -> Report/Email -> End; Reject and failure branches go to audit.
5. Configure durable approval: if BPMN User Task is implemented and tested, use it; otherwise model `Control.RequestApproval` + correlated message catch/wait. Do not portray an unsupported user task as live.
6. Delete handler descriptor declares `ExternalDestructiveWrite`, required permission, `NoBlindRetry`, reconciliation method and high-impact audit category.
7. Save/validate/test using mock CyberArk response and a non-production fixture; require two separate identities where bank policy mandates segregation.
8. Publish DEV version and show status on business dashboard: Requested -> Evaluating -> Awaiting Approval -> Delete Pending -> Verified Deleted / Rejected / Failed / Outcome Unknown.

## BPMN process

```mermaid
flowchart TD
  A[Authorized request] --> B[Get CyberArk account]
  B --> C[AMIE delete eligibility]
  C --> D{Eligible?}
  D -->|No| X[Rejected / report + audit]
  D -->|Yes| P[Preview impact + explicit confirmation]
  P --> Q[Control request approval]
  Q --> W[Durable approval outcome wait]
  W --> R{Approved?}
  R -->|No| X
  R -->|Yes| S[Guarded CyberArk.DeleteAccount]
  S --> T[Verify deletion via approved read]
  T --> U{Confirmed?}
  U -->|Yes| V[Report and Email]
  U -->|Unknown| Y[Requires reconciliation + manual review]
  V --> Z[Complete]
```

## Integration and evidence

- BE -> API authorizes submit. Authenticated actor is a user, not an anonymous application input.
- BOB pins workflow and capability/rule versions; AMIE emits eligibility decision with reason.
- Control/approval service emits actor/role/ticket/time evidence. The receiver validates that this approval pertains to *this exact* account and request, not merely a reusable ticket ID.
- CyberArk Capability checks permissions **again**, captures expected current state and issues only the approved API delete operation. No direct EPV database mutation.
- Auditable external outcome and post-delete confirmation are distinct. If API timed out, the result may be unknown even if account is gone; reconcile before any retried delete.
- Kafka is used only if the operation is across services. The delete event should contain references and safe metadata, never credentials.
- Email is notification via Email Capability; failure to email does not reverse a confirmed delete.

## Regression

Unauthorized trigger denies; rule-denied request produces no delete call; approval by requester denied when separation required; approval replay for a different account denied; race (account changed after preview) aborts; timeout outcome becomes manual reconciliation; denied PROD config activation never sends delete command; test shows who/when/what version and ticket. Use mocks or bank-approved DEV test account only.
