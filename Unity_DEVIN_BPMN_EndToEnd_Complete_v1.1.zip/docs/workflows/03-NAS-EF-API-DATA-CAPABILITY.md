# Workflow 03 - NAS/EF Backend and API as a Reusable Unity Data Capability

## Grounded versus unknown

The user identifies a `NAS API Database (EF backend and API)` that Unity workflows should use. The **exact meaning of NAS, existing controllers, EF entities, schemas, authorization model and database ownership are not yet verified**. Preserve its name and the requested API/EF architecture; do not invent concrete controller names or table layouts as facts.

## Desired service separation

```mermaid
flowchart LR
  UI[BE Data Binding Picker] --> Reg[Capability Registry metadata]
  UI --> BOB[BPMN Service Task]
  BOB --> K[Kafka or Approved Service API]
  K --> NAS[NAS Data Capability API]
  NAS --> EF[EF Core DbContext / UoW]
  EF --> DB[(NAS owned MSSQL database)]
  NAS --> O[Typed result + audit]
  O --> BOB
```

If NAS has its **own** database, it may use local EF directly. Other services consume its approved API, **not** its DbContext or physical tables. This is distinct from BOB's MSSQL-only workflow persistence decision. If existing legacy APIs own the data, use those contracts instead of creating a redundant NAS store.

## Proposed operation families to inventory (not code claims)

| Family | Typed operations | Must not expose |
|---|---|---|
| Batch staging | StageBatch, GetBatchStatus, GetRowsPage, MarkRowOutcome | `query(tableName, sqlText)` |
| Account metadata | FindAccounts, GetAccountSnapshot, GetMetadataByKey | unrestricted EF joins to other service DBs |
| Policy baseline | GetBaseline, UpsertBaseline, SaveDriftResult | uncontrolled baseline overwrite |
| Report | GetBatchAggregates, GetPolicyRunSummary | unscoped classified exports |

## BE screens and dynamic behavior

1. Capability Catalog > filter `Data` > choose `NAS` > view approved service version/health and declared operations.
2. Inspect one operation: permissions, required input schema, output schema, side effect, owner, supported hosts, data classification.
3. In BPMN Designer add Service Task -> bind registered NAS operation; a schema-generated form appears. Bind `batchId` from trigger or previous stage output.
4. Test preview calls a safe fixture endpoint (or mocks) with redaction, not live production tables. Edit source binding, save and revalidate.
5. On backend run, BOB dispatches typed request via approved API/Kafka; NAS API performs EF query/transaction and returns typed response. The browser never supplies arbitrary SQL, table names, DB connection strings or credentials.

## DEVIN source audit instructions

- Find actual NAS project, API routes, OpenAPI schema, EF DbContext, entity ownership, migrations, DI setup, authentication, FluentValidation and transaction strategy. Record repository paths and versions.
- Reuse existing methods; implement only missing typed primitives. Ensure pagination, optimistic concurrency, idempotent writes, audit context forwarding, classified response handling.
- Register these approved operations via shared Capability SDK manifest; link `OperationDescriptor` to existing DTOs with schema tests.
- Add API-first regression and a second BOB workflow proving reuse without modifying NAS code.

## Acceptance

With a real approved NAS endpoint in DEV, user selects an operation in BE, sees its required parameters, maps them from workflow data, validates, tests and executes a BOB service task that roundtrips through the API and EF backend. Audit shows caller, operation version, source/run correlation, data owner and result, with no direct SQL exposed to consumers.
