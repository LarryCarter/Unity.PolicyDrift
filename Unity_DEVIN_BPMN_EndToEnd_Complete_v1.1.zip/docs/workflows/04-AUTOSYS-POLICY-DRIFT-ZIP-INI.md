# Workflow 04 - AutoSys-Triggered Policy Drift (EPV ZIP/INI Baseline Comparison)

## Existing behavior and evidence boundary

Previous project work describes a Policy Drift process using scheduled EPV ZIP/API ingestion, recursive nested ZIP and INI parsing, PolicyId normalization, policy baseline comparisons, drift records and audit. The exact original SQL queries, EF entity classes, current AutoSys version/job IDs and approved endpoints **must be retrieved from the repository** before implementing handlers. Earlier design discussed `BaselinePolicy`, policy-evaluation records, and an audit/event history; use original SQL as an acceptance oracle rather than inventing LINQ equivalence. The policy status vocabulary includes `NO_DRIFT`, `DRIFT`, and `MISSING_BASELINE`; exceptions must retain reasons. This is NOT the same workflow as safe-move account hygiene.

## Trigger design - first workable integration

**Preferred initial path:** existing AutoSys job runs an approved script/command that calls a secured Unity trigger API with `jobName`, `schedulerInstance`, `sourceRunId`, `scheduledAtUtc`, and approved data/ZIP reference. The trigger service validates caller identity, allowlisted job and schema, dedupes on job + run ID, starts pinned central BOB definition, and returns `202 Accepted` with `runId`. AutoSys can record this ID; completion can be queried or signaled by approved contract if scheduling policy requires it.

**Alternative after review:** an AutoSys Capability consumes its AEWS REST API to discover run/job status. This depends on installed AutoSys 12.1/R24.1 (or actual version), its documentation, security approvals and connectivity; it is **not** assumed present. Vendor reference: https://knowledge.broadcom.com/external/article/445384/rest-api-and-swagger-documentation-for.html.

## BPMN / AMIE / capability stages

| Stage | Owner | Reusable operation/rule | Result + status |
|---|---|---|---|
| AutoSys execution | AutoSys / trusted trigger adapter | `WorkflowTrigger.StartByScheduler@1` | runId or rejected duplicate/role |
| Fetch policy data | EPV/CyberArk Capability | `CyberArk.DownloadPolicyBundle@1` OR existing approved data accessor | managed bundleRef; fatal retrieval error aborts run |
| Expand and parse | Policy Ingestion Capability | `Policy.ExtractNestedArchives@1`, `Policy.ParseIni@1` | typed policies, parse issues |
| Normalize | AMIE or existing sanitizer adapter | `Policy.NormalizePolicyId@1` | normalized PolicyID; must call existing real sanitizer |
| Load baseline | owning Data/EF API | `Policy.GetBaseline@1` | baseline snapshot / missing |
| Compare | AMIE | `Policy.CompareAttributes@1` | `NO_DRIFT`, `DRIFT`, `MISSING_BASELINE` and diffRef |
| Persist | owning EF API | `Policy.SaveEvaluation@1` | idempotent run/policy write and audit |
| Optional baseline update | controlled baseline operation | `Policy.UpdateBaseline@1` | approved mutation + version; must respect baseline-update override |
| Aggregate/report | Reporting capability | `Reporting.PolicyDriftSummary@1` | counts, error reasons, reportRef |
| Notify | Email capability | `Email.SendReport@1` | delivery outcome independent of drift result |

Example policy baseline file convention previously considered: `baseline update/{PolicyID}.txt`; check actual file path and source first. `MISSING_BASELINE` must not be silently classified as `NO_DRIFT`.

## BE configuration walkthrough

1. Application Studio > Policy Drift > Workflow Library > `Create from Scheduled Ingestion Template`.
2. Trigger Designer > `AutoSys Job` > choose approved logical job from registry, not free-text API credential/host; set schema, runId mapping, overlap policy, idempotency and failure notification.
3. Data Sources > bind EPV download and policy baseline operations from the correct data owner; verify actual EF model and API routes.
4. BPMN Designer > start -> download ZIP -> extract/parse subprocess -> sequential policies -> normalize -> baseline retrieve -> compare AMIE -> branch into `DRIFT`/`NO_DRIFT`/`MISSING_BASELINE` -> write result -> aggregate -> report/email -> end.
5. AMIE configuration > set attribute comparison and exclusion rule with reason; preserve normalization behavior; attach approved baseline version. Rule test panel runs 4 policy fixtures.
6. Configure failure paths: total download/unzip failure abort batch; individual invalid INI or policy writes produce per-policy failure and continue under approved policy; unknown policy ID flagged.
7. Test with nested ZIP/INI bundle, duplicate AutoSys start and restart; publish DEV version. UAT/PROD follow release gates and authorized Operations activation.
8. Business dashboard shows policies seen, processed, no-drift, drift, missing-baseline, excluded, failed and last-run status. Technical run monitor shows task/timer/adapter outcomes.

## Full flow

```mermaid
flowchart TD
  A[AutoSys job executes] --> B[Authorized Unity scheduler trigger]
  B --> C[Central BOB: start pinned workflow]
  C --> D[Download EPV ZIP / API data]
  D --> E{Bundle available?}
  E -->|No| F[Fail run + alert + audit]
  E -->|Yes| G[Extract nested ZIPs + parse INI]
  G --> H[For each policy]
  H --> I[Normalize PolicyId]
  I --> J{Policy valid?}
  J -->|No| N[Record excluded/parse reason]
  J -->|Yes| K[Get baseline via Data API]
  K --> L[AMIE compare policy fields]
  L --> M{Result}
  M -->|NO_DRIFT| O[Persist unchanged evaluation]
  M -->|DRIFT| P[Persist diff and evidence]
  M -->|MISSING_BASELINE| Q[Persist missing-baseline finding]
  N --> R{More policies?}
  O --> R
  P --> R
  Q --> R
  R -->|Yes| H
  R -->|No| S[Aggregate + Report]
  S --> T[Kafka Email Capability]
  T --> U[Dashboard + Audit + AutoSys status correlation]
```

## Failure, fallback and concurrency rules

- EPV download failure or total unzip failure abort batch with fatal reason.
- Missing/invalid PolicyID -> log row and continue according to runbook; do not silently delete it.
- Per-policy EF write failure retries idempotently and yields policy-level failed status; one failed policy should not masquerade as successful batch.
- If an approved fallback to a reporting database is used when EPV API returns errors, audit records fallback source, reason, freshness and confidence; no secret/privileged DB fallback.
- Baseline updates are governed mutations. Persist upsert/evaluation/event in a transaction when same DB; file deletion/archival follows after transaction and records failure separately.
- Duplicate scheduler `sourceRunId` must resolve to original run, not create new policy evaluations; overlap policy explicit (skip, queue, or concurrent by scope).
- Version pins preserve PolicyId sanitizer, AMIE compare, baseline schema and capability operation versions; no in-flight migrations required for initial pilot.

## Tests and evidence

Fixture 1 identical policy -> NO_DRIFT. Fixture 2 changed attributes -> DRIFT + diff. Fixture 3 no baseline -> MISSING_BASELINE. Fixture 4 invalid INI -> excluded with reason. Fixture 5 recursive nested ZIP. Fixture 6 invalid/untrusted source job -> 403. Fixture 7 duplicate AutoSys run -> same runId. Fixture 8 fatal EPV download -> FAILED + audit + no misleading email success. Fixture 9 original SQL vs new EF query equivalence using approved dataset; deviations explicitly flagged. Tests must not depend on real PROD policy dumps.
