# Start Here — Integration Strategy and Immediate Assignment

## Objective

By **2026-11-30** demonstrate a narrowly scoped but **real** configuration-first Unity vertical slice: BE authoring, operation registry, AMIE mapping, executable BOB BPMN subset, capability execution, Kafka command/outcome, MSSQL run/audit history, business summary, user scopes, and failure handling. DCMS is the first business acceptance fixture; a second independently configured workload is a stretch goal. Bank production approval is a distinct release gate.

## First action for DEVIN

Run `jobs/JOB-00-reconcile-repository.md` immediately in read-only mode. Output `docs/decisions/REAL-REPOSITORY-MAP.md` with (a) what exists, (b) what works, (c) the exact AMIE integration seam, (d) actual capability and Blazor structures, (e) approved libraries, (f) broker and database conventions, (g) blockers. This task should precede mass scaffolding.

## Priority gates

- **A Contract gate:** one real handler + descriptor -> registry -> BE inspector -> AMIE adapter (use existing engine) -> BOB activity binding.
- **B Execution gate:** BPMN fixture executes in embedded and central hosts; cross-service command completes by Kafka; MSSQL checkpoint and audit survive restarts.
- **C UX gate:** BE can configure, validate and publish a supported workflow, start it as an authorized user, view business counts and inspect a technical timeline; operator controls reflect real state.
- **D Pilot gate:** DCMS CSV stages batch + row GUIDs, processes rows sequentially through CyberArk read/map/write, reports verified outcomes and notifications via Email Capability.
- **E Reuse gate:** second business process uses same engine and existing approved operations without BOB code changes. Validate separated from bank PROD authorization.

## What is already known, and what is not

[USER] AMIE is largely written; BOB is the bottleneck. Unity includes Blazor BE, embedded/central BOB, Kafka and independently owned capability services. DCMS uses CSV->staging->batch/row IDs->CyberArk enrichment->report/email. DEV/UAT->PROD configuration promotion by Operations is desired.

[VERIFY] Exact code/assembly names, deployed service interfaces, Kafka topic conventions, approved designer/paid libraries, SQL migrations, existing ServiceNow workflow, audit retention, SSO group names, CyberArk API behavior, current test harness. Do not fabricate these.

[PROPOSED] Names like `IUnityOperationHandler`, `CapabilityManifest`, `BOB.Run` and example OpenAPI routes are contracts for discussion, not authoritative until reconciled.

## Parallel job plan

After JOB-00 freezes the cross-team contracts: SDK/registry (JOB-01/02), BOB parser/runtime (JOB-04/05), Kafka (JOB-06), SQL/audit (JOB-07), BE designer (JOB-08/09), and testing/release (JOB-15/16) can proceed in **separate worktrees or branches** with contract fixtures. Pilot-specific CyberArk/Data (JOB-11/12) may progress independently once their interfaces are fixed. Integration (JOB-17) must wait on verified seams.

## Safe no-approval dependency fallback

Re-use bank-approved libraries already in repository. If no graphical BPMN library is approved, implement a limited first-party Blazor SVG canvas + small version-controlled JS pointer module, keeping BPMN XML/DI as the model and leaving BOB independent of canvas rendering. Any new dependency remains a bank review blocker, not an assumed shortcut.

## How to use skills in Devin

Copy `.agents/skills/` into the actual repository, commit through normal review, then invoke e.g. `@skills:unity-capability-service` for new microservice scaffolding. Devin's official documentation supports repo `SKILL.md` auto-discovery at `.agents/skills/<name>/SKILL.md`; ensure the connected repository/session exposes them. They are **instructions** and examples, not installed runtime SDK NuGet packages.

## Documentation navigation

- Architecture: `docs/architecture/01-PLATFORM-TOPOLOGY.md` through `12-DELIVERY-BOUNDARIES.md`.
- Machine contracts: `docs/contracts/`.
- Walkthroughs: `docs/ui/`.
- Tests: `docs/testing/`.
- Jobs and targets: `jobs/INDEX.md` and `docs/roadmap/DELIVERY-PLAN.md`.


## v1.0 detailed UX and SDK handoff addition

After the read-only source reconciliation, freeze the interface between registered capability descriptors, BE typed inspector, existing AMIE rule descriptors and the BOB activity compiler. New UI source is `wireframes/UI_CONTROL_REGISTRY_v1.0.json` (19 screens/102 controls). Detailed development work packets are at `jobs/interaction/INDEX.md`; they are **subtasks** of the original JOB plan, not a second independent engine roadmap. Use the browser HTML only to review intended state transitions; real implementation must pass API, auth, Kafka, MSSQL, BPMN and recovery tests.

## v1.1 priority additions

Read the [new v1.1 index](../INDEX.md) and [BPMN UI/end-to-end jobs](../jobs/bpmn/INDEX.md). First working app remains DCMS. New primary user flow is [UI 18](ui/18-FULL-BPMN-DESIGNER-UI-CONFIGURATION-AND-TEST-RUNBOOK.md). Sources and diagrams: [all workflows](workflows/00-REUSABLE-WORKFLOW-PATTERNS.md) and [18 diagrams](diagrams/DIAGRAMS.md). Account Delete mock and AutoSys Policy Drift are conditional second pilots; bank approvals and legacy code verification gate real execution.
