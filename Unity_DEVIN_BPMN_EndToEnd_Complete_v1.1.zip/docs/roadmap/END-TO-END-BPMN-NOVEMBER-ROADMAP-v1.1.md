# Roadmap - End-to-End BPMN UI, SDK and Four Pilot Configurations

**Planning date:** November 11, 2026. **Target demo:** November 30, 2026. These are proposed checkpoints, not claims of completed work. DEV demo != security, CA, runbook, ServiceNow or production approval.

## Dependency and parallelization map

```mermaid
flowchart LR
  A[JOB-00: Source audit] --> B[JOB-01: Contract freeze]
  B --> C[SDK-31: Handler/registry]
  B --> D[BOB-37: Shared interpreter]
  B --> E[BOB-38: Existing AMIE adapter]
  B --> F[BE-21/22: Reusable UI + wizard]
  C --> G[SDK-32/33: NAS/CyberArk]
  C --> H[BE-24/25: Dynamic inspector + binding]
  D --> I[BE-23: BPMN canvas]
  E --> H
  I --> J[BE-27/28: Validate/test/publish]
  H --> J
  G --> K[INT-39: DCMS end to end]
  J --> K
  D --> K
  K --> L[BE-29/30: Dashboard + audit]
  K --> M[QA-40: Regression, demo]
  L --> M
  G --> N[SDK-34: Account Delete mock]
  C --> O[SDK-35: AutoSys adapter]
  O --> P[SDK-36: Policy Drift compare]
  N --> M
  P --> M
```

## Priority cutline

| Priority | Scope | Demo proof | Defer when needed |
|---|---|---|---|
| P0 foundation | SDK registered operation, existing AMIE adapter, shared BOB BPMN subset, Kafka command/outcome, MSSQL checkpoints and audit | one registered operation discoverable and executable through BE/BOB/AMIE | advanced BPMN elements |
| P0 designer | Blazor shell, new draft, trigger CSV, service/rule picker, diagram, typed inspector, validate, test, save/publish DEV version | supported BPMN import/export XML+DI, 5-row fixture | full general-purpose forms builder |
| P0 DCMS | CSV -> staged batch + row GUID -> CyberArk attributes -> outcome -> report/email + dashboard | actual approved DEV integration or clearly marked external stub | scheduling API/AutoSys for DCMS |
| P0 observability | business count cards, run overlay, role-denial API, control/audit reconstruction | correlation across BOB/AMIE/capability/Kafka/SQL | advanced analytics |
| P1 Account Delete | guarded approval, dry-run, controlled delete operation with verification | mock or approved nonprod only | real destructive execution without approval |
| P1 AutoSys Policy Drift | approved scheduler trigger -> ZIP/INI ingestion + policy baseline compare | secure adapter trigger + representative policy fixtures | full AEWS integration and exhaustive legacy migration |
| P1 NAS actual service | reconcile existing API, EF Core model, operation registration, typed mappings | real DEV data-owner API read with correct scope | new generic DB query service |
| P2 future | parallel joins, advanced gateways, compensation, process instance version migration, full BPMN conformance | documented supported vs planned | all P2 deferred |

## Work calendar targets

| Dates (Nov 2026) | Checkpoint | Go/no-go evidence |
|---|---|---|
| 11-13 | Repository audit + contract freeze | existing AMIE and BE paths identified, approved dependencies enumerated, SDK/BPMN schemas agreed |
| 13-17 | SDK registry + BOB graph + base Blazor components | typed operation auto-discovered; mock BPMN service task parsed/validated; UI loads manifest |
| 17-21 | End-to-end draft authoring/test and durable execution | sample rule bound, tested, local/remote dispatch reconciles; cross-service trace |
| 21-25 | DCMS 5-row DEV integration, reporting/email, business progress | real evidence and failure paths, no double writes, dashboards update |
| 25-28 | AutoSys adapter/Policy Drift fixture and guarded Delete demo conditional; harden RBAC/audit | second distinct configuration reuses primitives, no false destructive/PROD claims |
| 28-30 | Freeze for demo and evidence | regression report, BOM/dependency approval status, runbooks/control gaps, known issues and fallback demo |

No human/DEVIN activity is assumed started. Adjust immediately after source audit; do not chase full BPMN palette at expense of a working verified vertical slice.

## Engineering release gates

- **G0 Source reality:** actual repo, AMIE implementations, service manifests, NAS meaning/owner, AutoSys version/job, approved CyberArk operations identified. Without source, docs only.
- **G1 Shared contract:** no incompatible SDK/BOB/BE DTO forks; operation key/version, rule refs and message envelope stabilized.
- **G2 BPMN behavior:** XML + DI roundtrip, graph parser, executing P0 subset, unsupported rejection, sequential/async wait semantics tested.
- **G3 Service execution:** one operation from BE through real authorized API/BOB/AMIE -> handler with proper audit/correlation.
- **G4 DCMS regression:** 5-row fixture, row GUID and reasons, failure recovery, report/email status separate, live business dashboard.
- **G5 Security/control:** direct API denial, per-app scope, sourceRunId dedupe, high-impact approval gate, no raw credentials, reconstructable audit.
- **G6 Demo:** fresh DEV deployment, runbook and operator-controlled restart/pause path, test evidence and outstanding controls honestly listed.

## Evidence packages per DEVIN PR

Source paths and modifications, typed contract diff, API/manifest update, BPMN XML fixture and expected trace, tests/run log (unit/API/integration/role-deny), screenshot or screen recording, audit event examples with masked data, rollback, ServiceNow/control requirements still open, and clear `New / Updated / Deleted / No Change` file summary.

## Dependencies and blockers to resolve rapidly

`NAS` actual API/EF model unknown, original Policy Drift SQL and PolicyId sanitizer require retrieval, AutoSys job identity/adapter requires policy approval, CyberArk delete API and dual-control rules require security approval, paid BPMN renderer depends on previously approved library inventory, existing AMIE interface must be reused, actual BE project and namespace unknown. Do not turn any of these assumptions into undocumented production facts.
