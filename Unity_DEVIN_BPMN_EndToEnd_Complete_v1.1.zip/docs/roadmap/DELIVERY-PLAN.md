# November 11–30, 2026 — Critical Path and Immediate Roadmap

**Start state:** AMIE mostly exists; BOB is an architectural/implementation bottleneck; BE is Blazor; v0.7 HTML is a prototype; production controls require Wells Fargo approval. **Confidence in full target before code audit:** unverified. Dates are planning checkpoints, not confirmed engineer availability or release promises.

## Calendar gates

| Window | Gate | Critical deliverable | Parallel work |
|---|---|---|---|
| Nov 11–12 | G0 Inventory | JOB-00 source/AMIE mapping, approved dependencies, demo pilot confirmation | Read-only technical discovery |
| Nov 12–13 | G1 Contract | JOB-01 stable operation/rule/BPMN/message/error/audit/release contracts | Prepare isolated fixtures |
| Nov 13–18 | G2 Foundation | SDK+manifest+registry; AMIE bridge; BPMN compiler; Kafka/SQL prototypes | JOB-02..05,07,08,09 |
| Nov 18–22 | G3 Thin vertical slice | Central->Kafka->embedded BOB+AMIE->handler->MSSQL history->BE status | JOB-06,10–14 |
| Nov 22–26 | G4 DCMS process | Batch/row GUIDs; sequential CyberArk; report/email; RBAC and operator controls | JOB-11–18; release gates |
| Nov 26–29 | G5 Regression / reuse | P0 test matrix; crash/duplicate/auth; second application if feasible | JOB-17,19,20 |
| Nov 30 | G6 Demo decision | Demonstrable integrated DEV/UAT configuration and documented gaps | Security/control owner decides bank PROD eligibility separately |

## Dependency graph

```mermaid
flowchart LR
  J0[JOB-00 Inventory] --> J1[JOB-01 Contracts]
  J1 --> SDK[JOB-02 SDK]
  SDK --> REG[JOB-03 Registry]
  J1 --> AMIE[JOB-04 AMIE]
  J1 --> BPMN[JOB-05 BPMN]
  BPMN --> HOST[JOB-06 Hosts]
  SDK --> HOST
  AMIE --> HOST
  J1 --> K[JOB-07 Kafka]
  J1 --> SQL[JOB-08 MSSQL]
  BPMN --> UI[JOB-09 Designer]
  REG --> INS[JOB-10 Inspector]
  UI --> INS
  J1 --> DATA[JOB-11 Ingest]
  SDK --> PAM[JOB-12 CyberArk]
  K --> EMAIL[JOB-13 Report/Email]
  SQL --> MON[JOB-14 Monitor]
  HOST --> OPS[JOB-15 Controls]
  UI --> RELEASE[JOB-16 Release]
  HOST --> DCMS[JOB-18 DCMS Pilot]
  K --> DCMS
  DATA --> DCMS
  PAM --> DCMS
  EMAIL --> DCMS
  MON --> DCMS
  DCMS --> DEMO[JOB-20 Demo]
  DCMS --> REUSE[JOB-19 Second app]
  TEST[JOB-17 Regression] --> DEMO
```

## Execution lanes

**Lane A — SDK/registry:** JOB-01 -> JOB-02 -> JOB-03, plus CyberArk handler inventory JOB-12.  
**Lane B — Engine:** JOB-05 -> JOB-06 with AMIE bridge JOB-04.  
**Lane C — Infrastructure:** JOB-07 Kafka, JOB-08 SQL/audit.  
**Lane D — Experience:** JOB-09/10 Blazor designer/inspector; JOB-14 dashboard/monitor, JOB-15 operators.  
**Lane E — Workload:** JOB-11 ingest, JOB-12 CyberArk, JOB-13 Email/Reporting, JOB-18 integrated DCMS; JOB-19 second use case.  
**Lane F — QA/Controls:** JOB-17 continuous regression, JOB-16 versioned promotion, JOB-20 demo.

## First integration spike (absolute priority)

One compiled approved **safe** handler exposed by SDK manifest -> registry API -> BE schema inspector -> BPMN service task + AMIE rule reference -> embedded execution -> Kafka correlated completion -> durable MSSQL run/audit -> BE status. The handler can be test-only until actual CyberArk adapter is authorized. No fake claims of real CyberArk operations.

## Cut order if deadline at risk

1. Drop P1 advanced BPMN, full visual polish, AutoSys, rich user tasks, full ServiceNow API, parallel batch and version migration.
2. Narrow to exactly one approved data source and one registered operation family, one report/email adapter.
3. Keep required safety: server auth, immutable version, correlation, idempotency/reconciliation, durable audit, API regression, truthful status.
4. Present second app only if same primitives genuinely reused with tests; otherwise show as planned demo not completed.

## Stop/go proof

G1: contract fixture unit tests pass, real AMIE adapter seam mapped.  
G2: compiler/SDK/registry startup tests pass, handler discoverable.  
G3: crash/duplicate run resumes and BE shows it.  
G4: DCMS five-row fixture, persisted outcomes, report and email status agree.  
G5: all P0 regression R01–R18 pass; bank review blockers visible.  
G6: demo works from a clean environment and cannot bypass authorization. PROD decision belongs to authorized bank controls.

## Ownership and deliverables

Each lane owns its PR(s). Integration owner merges after cross-team tests; control owner validates bank-specific gates. Every JOB file includes copy-ready DEVIN prompt, proposed path boundaries, criteria and negative tests. Do not start all twenty jobs concurrently without contract review—parallelize only after G1 to avoid incompatible SDKs.


## v1.0 workstream refinements (target date unchanged: Nov 30, 2026)

**Gate 0 (immediate):** SDK-10 source reconciliation + original JOB-00. Produce exact AMIE and BOB seams, approved dependencies and current CVIS service inventory; do not refactor working AMIE blindly.

**Gate 1:** original JOB-01 freezes `OperationDescriptor`, AMIE rule descriptor, typed binding, message envelope, workflow package/audit schema, and BE action API convention. Use schema fixtures and cross-team sign-off.

**Gate 2:** SDK-11/12/13 parallelize handler DI/registry and existing AMIE adapter; SDK-14/15/16 stabilize BOB dispatch, Kafka outbox/inbox and audit. UI-10 shell, UI-11 catalog/inspector, UI-12 library, UI-13 BPMN designer can run alongside once contracts freeze.

**Gate 3:** UI-14 typed AMIE/trigger forms, UI-15 business/run views, UI-16 operator/audit and UI-17 regression/release. Produce a single BOB service-task binding from BE, execute it via existing AMIE and a real registered handler in DEV.

**Gate 4:** SDK-18 DCMS 5-row fixture: CSV staging, batch number, row GUIDs, sequential embedded CyberArk processing, actual outcome persistence, Reporting+Email messaging, business dashboard and audit replay. Second workload reuse is stretch if timeline permits.

**Risk/cut:** defer advanced BPMN, arbitrary user forms, AutoSys integration, full live ServiceNow API, UI styling beyond usable wireframes, parallel batch and mid-flight version migration. Do not cut backend auth, schema validation, safe writes, audit, transport dedup/recovery or bank release gates.

Per-button and per-component acceptance: `docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md`; SDK tests: `docs/sdk/08-SDK-API-REGRESSION-SUITE.md`; detailed DEVIN assignments: `jobs/interaction/INDEX.md`.
