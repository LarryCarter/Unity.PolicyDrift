# After November 30 — Prioritized Backlog

**P1** where actual business need emerges: rich human approval tasks, timers/schedules, AutoSys adapter, API/DB connector for DCMS input, generic parallel multi-instance, advanced BOB subprocess visual tooling, rule test cases managed within BE, graphical comparison of workflow versions, reusable configuration templates and marketplace, extensive runbook authoring.

**P2** if justified: complete BPMN 2.0 support and conformance test suite, process instance migration between versions, compensation/saga primitives, comprehensive ServiceNow ticket/approval integration after bank review, advanced observability, SQL Server Ledger if allowed, performance and multi-region fault tolerance, compile-time SDK manifest source generator.

Do not add legacy database provider support to BOB merely because OptimaJet offers it. Revisit business capability data providers according to actual service needs.
