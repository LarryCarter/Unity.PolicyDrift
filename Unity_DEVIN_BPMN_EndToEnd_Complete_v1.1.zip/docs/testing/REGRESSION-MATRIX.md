# Automated Regression Matrix — Acceptance IDs

Every row is intended for a runnable test plus redacted evidence. Prioritize P0: R01–R18. Each test specifies its fixture in the implementation PR.

| ID | Component | Test and expected result | Priority |
|---|---|---|---|
| R01 | SDK | Compiled CyberArk handler registers with valid contract; duplicate key fails startup | P0 |
| R02 | Registry | Signed/attested publisher accepted; unapproved manifest never executable | P0 |
| R03 | Registry/BE | Schema renders required fields and output bindings; missing field blocks publish | P0 |
| R04 | AMIE | Real existing AMIE rule evaluates through adapter, pinned version reported | P0 |
| R05 | BOB | Start -> service -> rule -> exclusive gateway -> end executes correct path | P0 |
| R06 | BOB | BPMN XML+DI roundtrip stable IDs; unsupported node fails publish | P0 |
| R07 | BOB | Central and embedded share interpreter semantics | P0 |
| R08 | BOB | DCMS sequential 3 rows at most one active per batch | P0 |
| R09 | Kafka | Outbox persists command, published once or more without duplicate effect | P0 |
| R10 | Kafka | Duplicate/out-of-order outcome doesn't double advance | P0 |
| R11 | SQL | Restart central service during wait, load pinned run and resume | P0 |
| R12 | Auth | Unauthorized REST operation, forged Kafka identity and cross-scope read denied | P0 |
| R13 | Controls | Pause requested does not kill in-flight external write; next row gate respected | P0 |
| R14 | Audit | Reconstruct run+row+actor+rule+version+message+ticket from event history | P0 |
| R15 | Release | Modified digest / missing actual approval blocks PROD activation | P0 |
| R16 | DCMS | CSV stages unique batch/row IDs and processes confirmed outcomes | P0 |
| R17 | Email | Report from persisted outcomes sent via independent Email Capability | P0 |
| R18 | API-first | Every exposed BE action has tested authenticated API | P0 |
| R19 | Reuse | Hygiene reuses same `CyberArk.GetAccount` without BOB/CyberArk changes | P1 target |
| R20 | Triggers | API pull/AutoSys schedules normalize start intent | Later |
| R21 | BPMN | Parallel gateway token/join exact semantics | Later |
| R22 | BPMN | User task authorization/inbox/approval wait | P1 if pilot requires |

## Evidence schema per test

`testId`, `fixtureId/version`, `environment`, `testRunId`, `packageDigest`, `commit`, `executedAtUtc`, `result`, `redactedRequestResponseRef`, `auditQueryRef`, `CIArtifactRef`, `screenshotsRef`, `knownLimitations`. A green result without executed evidence is not a release qualification.
