# Failure Injection, Security and Restart Tests

## Execution integrity

- Kill central BOB after outbox commit but before Kafka publish; restart: command eventually delivered, no missing run.
- Kill CyberArk capability after external write could have succeeded but before acknowledgment: row becomes `UnknownExternalOutcome`, reconciliation required, no blind auto-replay.
- Deliver duplicate command and duplicate outcome in arbitrary order; each run transition occurs once and external write does not duplicate.
- Pause immediately before row n; previously accepted write may finish but no next row begins after pause checkpoint. Resume version is pinned.
- Cancel while email pending; report accurately distinguishes business completion from notification status.
- Lose SignalR connection; UI reloads authoritative projection and does not show false complete.
- Corrupt/missing AMIE version in package; start rejected/suspended with evidence.
- Two workers claim same batch/row; lease and optimistic concurrency prevent two simultaneous external effects.

## Access and governance

- BusinessExecutor with app A token attempts app B batch read; deny and safe audit.
- WorkflowDesigner tries direct publish/activate REST; deny even if UI is hidden.
- Run operator supplies stale ETag or duplicates same commandId; idempotent reject/return original result.
- Kafka service uses allowed topic but forbidden operationKey; dispatch denies.
- Import BPMN XML with `scriptTask`, `external entity`, raw HTTP target or unapproved extension; reject safely.
- Tamper signed config package after UAT; PROD digest check fails.
- Supply ServiceNow-looking text with no validated approval; no PROD activation.
- Try to export privileged account material in audit; redaction holds.

## Required fault evidence

Pre/post MSSQL run state; in/out Kafka event IDs; audit sequence and UTC; worker restart logs; idempotency/reconciliation decision; explicit user-visible status; CI test result; absence of repeated CyberArk modification.
