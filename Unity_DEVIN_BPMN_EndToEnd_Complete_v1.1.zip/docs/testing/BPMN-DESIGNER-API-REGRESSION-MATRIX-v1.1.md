# BPMN Designer and Service Integration - API-First Regression Matrix v1.1

All tests below are **requirements for DEVIN**, not claims of passing tests in Unity's source repository. Every UI click maps to backend API contract `docs/ui/16-*`, and every result carries correlation, authorization, audit, and version evidence. Use automated headless browser tests for BE and authenticated API/integration tests for runtime.

| Test ID | Priority | Workflow or component | Input / action | Expected evidence and rejection condition |
|---|---|---|---|---|
| UI-001 | P0 | Workbench | Change app | Registry and runs scope changes; direct API cross-app 403 |
| UI-002 | P0 | Draft wizard | Create new and reload | Same immutable draftId, version/revision and metadata |
| UI-003 | P0 | Draft wizard | Duplicate key | HTTP 409, user input retained |
| UI-004 | P0 | BPMN canvas | Add node/connect/reposition | Stable IDs, DI geometry, undo/redo, save/reload |
| UI-005 | P0 | BPMN import | Import unsupported gateway | Visible element + publish blocker, not silent removal |
| UI-006 | P0 | BPMN export | Export/import roundtrip | Same graph, element IDs, DI and approved extensions |
| UI-007 | P0 | BPMN compiler | Unreachable node/default path missing | Per-node diagnostic with severity and exact ID |
| UI-008 | P0 | Property inspector | Select service task | Schema fields generated from approved descriptor |
| UI-009 | P0 | Property inspector | Change operation version | Input mappings revalidated; stale fact refs flagged |
| UI-010 | P0 | Typed binding | Connect mismatched source type | Structured `BIND_TYPE_MISMATCH`, no save/publish success |
| UI-011 | P0 | AMIE binding | Missing required fact | `BIND_REQUIRED` / rule unavailable blocks compile |
| UI-012 | P0 | AMIE rule test | Evaluate sample | Rule outcome and external side effect status separate |
| UI-013 | P0 | Workflow save | Two editors save same revision | HTTP 409/412 with compare and retained local changes |
| UI-014 | P0 | Workflow validation | Service not approved in target env | Backend denies publication even if front end button enabled |
| UI-015 | P0 | Versioning | Edit published workflow | New draft, original immutable version intact |
| UI-016 | P0 | Reusable UI | Different capability schemas | Same SchemaField and inspector render correctly without new Razor page |
| UI-017 | P0 | Security | Viewer invokes publish through API | Denied at backend; audit policy-denial event |
| UI-018 | P0 | Business dashboard | Subscribe + disconnect + reconnect | Snapshot reconciles counts and ordered event sequence |
| UI-019 | P0 | Operator controls | Pause mid external CyberArk call | PauseRequested until safe checkpoint; no fake rollback |
| UI-020 | P0 | Operator controls | Restart failed run | New linked runId, original audit remains, reconciliation required |
| SDK-001 | P0 | Capability SDK | Auto-register trusted compiled operation | Manifest validated; DI handler resolves; no auto-prod publication |
| SDK-002 | P0 | Registry | Duplicate operationKey@version | Startup/registration rejected with precise error |
| SDK-003 | P0 | Manifest | Sensitive schema property | UI shows logical ref; no raw credential in logs/messages |
| SDK-004 | P0 | Kafka | Duplicate command | Inbox returns same outcome without new external write |
| SDK-005 | P0 | Kafka | Worker crash after write | OutcomeUnknown/reconciliation; no blind retry |
| SDK-006 | P0 | AMIE + BOB | Embedded local execution | No central roundtrip for each record-level step |
| SDK-007 | P0 | MSSQL + BOB | Restart central host with waiting token | Run resumes from persisted checkpoint and correlation |
| DATA-001 | P0 | NAS/EF API | Query typed page | Allowed scope, pagination, no raw SQL input |
| DATA-002 | P0 | NAS/EF API | Retry MarkRowOutcome | Idempotent rowGuid/concurrency; no duplicate status counts |
| DATA-003 | P0 | NAS/EF API | Foreign app tries batch read | Backend denies even if caller knows batch ID |
| DCMS-001 | P0 | CSV trigger | Invalid/missing columns | Reject upload before starting run; show detailed row errors |
| DCMS-002 | P0 | Batch staging | 5-row fixture | One batch number and 5 unique row GUIDs |
| DCMS-003 | P0 | Sequential processing | 3-row order check | Concurrency exactly 1 in configured row subprocess |
| DCMS-004 | P0 | AMIE attribute mapping | Four sample custom attributes | In-memory changeset matches approved schema |
| DCMS-005 | P0 | CyberArk write | Confirmed outcome | Business SUCCESS only after actual write confirmation |
| DCMS-006 | P0 | CyberArk write | API timeout/uncertain | Requires reconciliation; never mark success or blind retry |
| DCMS-007 | P0 | Report/email | Email failure | Account outcomes unchanged, separate notification failure |
| DCMS-008 | P0 | Dashboard | Batch status counts | Sum of status buckets equals total, row reasons available |
| DELETE-001 | P1 | Guarded Delete | Missing approval | No delete API invocation, denied with audit |
| DELETE-002 | P1 | Guarded Delete | Changed target account after approval | Expected revision conflict, require reapproval |
| DELETE-003 | P1 | Guarded Delete | No approved DEV account | Use mock only; never PROD destructive request |
| DELETE-004 | P1 | Guarded Delete | API timeout | OutcomeUnknown + verified read before any retry |
| AUTOSYS-001 | P1 | Trusted schedule | Authorized sourceRunId trigger | 202 accepted with durable runId and source job audit |
| AUTOSYS-002 | P1 | Trusted schedule | Duplicate jobName/sourceRunId | Same runId, no second processing |
| AUTOSYS-003 | P1 | Trusted schedule | Unknown source job or identity | HTTP 403 and no BOB process created |
| POLICY-001 | P1 | Policy Drift | Nested ZIP + INI | All valid policies parsed with provenance |
| POLICY-002 | P1 | Policy Drift | Baseline equal | NO_DRIFT with evidence |
| POLICY-003 | P1 | Policy Drift | Changed values | DRIFT + exact difference output |
| POLICY-004 | P1 | Policy Drift | Missing baseline | MISSING_BASELINE, never NO_DRIFT |
| POLICY-005 | P1 | Policy Drift | Invalid PolicyId | Excluded with reason and original sanitizer evidence |
| POLICY-006 | P1 | Policy Drift | Original SQL vs EF API | Equivalent approved dataset results; mismatches reported |
| REL-001 | P0 | UAT/PROD promotion | Change artifact digest | Block activation after UAT if digest differs |
| REL-002 | P0 | PROD controls | Ticket entered, no real approval | PROD activation denied |
| AUD-001 | P0 | Audit | Reconstruct run and row | Actor, UTC, batch/row GUID, BPMN/rule/op versions, outcomes, changeRef |
| AUD-002 | P0 | Audit export | Classified field present | Mask/redact based on export permission; access recorded |

## Automated test harness recommendation

- Component tests: Blazor bUnit or existing approved component test setup; use `data-testid` stable selectors for browser tests.
- HTTP/API integration: reuse existing approved .NET test clients and CI runners, no unapproved dependencies added solely for demos.
- Kafka: broker simulator or approved DEV broker, duplicate and out-of-order test messages, bounded retries, service identity checks.
- SQL: DEV MSSQL isolated schema with migration/recovery and append-only event tests.
- External APIs: mocked stubs for destructive account actions, bank-approved non-prod credentials only for authorized reads/writes.
- BPMN: parse/DI roundtrip + graph validation + actual token execution + failure recovery separately; a valid XML document is insufficient.
- Evidence: exact build and code revision, run/row IDs, fixture hash, UTC, signed/approved package digest, expected/actual, redacted traces, screenshot and known open controls.
