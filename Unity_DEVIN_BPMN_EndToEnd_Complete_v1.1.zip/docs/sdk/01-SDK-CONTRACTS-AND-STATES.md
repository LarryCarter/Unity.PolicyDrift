# SDK 01 - Canonical Contracts, Identity, and State Machines

Status: PROPOSED until reconciled to existing repo. Dependencies: `docs/contracts/OPERATION-CONTRACT.md`, `docs/contracts/MESSAGING-CONTRACT.md`, `docs/architecture/04-AMIE-BINDINGS.md`.

## 1. Contract boundaries and proposed assembly paths

- `/Unity.Capabilities.Contracts/CapabilityManifest.cs`: metadata only; no executable classes in serialized payload.
- `/Unity.Capabilities.Contracts/OperationDescriptor.cs`: operation key/version, schema, permission, side effect, auth scope, retry/reconciliation, transport, AMIE requirements, examples.
- `/Unity.Capabilities.Contracts/OperationInvocation.cs`: request DTO + authenticated execution context.
- `/Unity.Capabilities.Contracts/OperationOutcome.cs`: typed disposition, safe reason, result and external reconciliation reference.
- `/Unity.Capabilities.Hosting/IUnityOperationHandler.cs`: compile-time typed operation interface.
- `/Unity.Capabilities.Hosting/OperationDispatcher.cs`: verified allowlist routing to DI handler; no client-provided CLR name resolution.
- `/Unity.Capabilities.Registry/ManifestPublisher.cs`: deployment/privileged registry action, NOT triggered merely by runtime scanning.
- `/Unity.Capabilities.Kafka/CommandConsumer.cs`: schema/auth/inbox/dispatch, outcome and outbox.
- `/Unity.Capabilities.BOB/EmbeddedWorkflowAdapter.cs`: bridge to shared interpreter.
- `/Unity.Capabilities.AMIE/AmieRuleAdapter.cs`: thin adapter to current existing rule engine.

Choose final project names only after JOB-00 inventory. Namespace conventions must follow existing services.

## 2. Proposed C# interface sketches

```csharp
public interface IUnityOperationHandler<TRequest, TResponse>
{
    Task<OperationOutcome<TResponse>> ExecuteAsync(
        TRequest input, UnityExecutionContext context,
        CancellationToken cancellationToken);
}

public sealed record UnityExecutionContext(
    string ApplicationKey, string DefinitionKey, string DefinitionVersion,
    Guid RunId, string ActivityId, string CorrelationId, string CausationId,
    string ActorContextRef, string PackageDigest, string IdempotencyKey,
    string? BatchId, Guid? RecordGuid, string? TraceParent);

public enum OperationDisposition
{
    Succeeded, NoChange, Rejected, Failed, UnknownExternalOutcome
}

public sealed record OperationOutcome<T>(
    OperationDisposition Disposition, string ReasonCode, string SafeReason,
    T? Result, string? ExternalOperationRef, string? ResultHash);
```

These are examples for contract alignment, NOT source already available. An input DTO contains business data; the execution context contains provenance and auth references. Data types must be serializable and compatible with existing library conventions.

## 3. Required OperationDescriptor fields

| Group | Required property | Validation |
|---|---|---|
| Identity | capabilityKey, operationKey, contractVersion | Unique key + compatible version; names cannot shadow another capability |
| Service | codeVersion, owner, manifestDigest | Code/manifest release must agree |
| Data | input/output JSON Schema, required fields, classification, fixture IDs | Validate examples and required fields; never generate schema from untrusted runtime input |
| Authentication | policy name, permitted resource scopes, service audience | Fail closed at registry and worker; no trust from UI alone |
| Side effects | Read / LocalTransform / ExternalWrite / HighImpactExternalWrite | Write has idempotency/reconciliation and control references |
| Execution | EmbeddedLocal / KafkaCommand, timeout and cancellation | At least one supported mode; no unapproved direct route |
| AMIE | required rule/data descriptor versions | Rule must resolve, pin and type-check before publish |
| Messaging | inbound/outbound logical types, partition/correlation/idempotency strategy | Broker binding checked per environment |
| Evidence | audit code, redaction profile, safe test fixture | No secrets or raw sensitive account payload in audit |

## 4. Lifecycle / state transitions

### Operation manifest

`CodeWritten -> BuiltAndTested -> ServiceApproved -> Deployed -> ManifestSubmitted -> Registered -> Available -> Deprecated -> Retired`.

- `Registered` is metadata-only. `Available` also requires healthy compatible service, environment ACL/policy and permitted application scope.
- Code release and configuration release are separate. A workflow can only invoke an operation available in its deployment environment and compatible with its pinned contract.
- Removing an operation from available list does NOT delete historical manifest metadata used for audit.

### Workflow definition

`Draft -> InReview -> Approved -> Published -> Active -> Retired`.

- Editing Published or Active creates a new Draft/version; all existing runs stay pinned.
- Publication requires BPMN subset/compiler validation, typed bindings, rule and operation compatibility, approved roles and change evidence.
- `Approved` is not `Active`; Operations owns activation according to real bank controls.

### Process run

`Created -> Running -> PauseRequested -> Paused -> Running`, plus `CancelRequested -> Cancelled`, `Completed`, `Failed`, and `AwaitingOutcome`/`ReconciliationRequired` substates as needed.

- Pause is cooperative at safe checkpoint; active CyberArk HTTP call cannot be magically stopped/undone.
- Cancel is cooperative; terminal `Cancelled` only when known work has settled or is explicitly marked unresolved.
- RetryFailedStep is permitted only where the dispatcher can establish prior outcome or safely reconcile it.
- RestartAsNewRun creates a fresh RunId and linkage to previous RunId; never erases original audit history.

## 5. Contract version pinning and backwards compatibility

- Workflow package pins explicit `operationKey@contractVersion`, AMIE `ruleKey@version`, called-subworkflow version, source schemas and package digest.
- Additive optional DTO fields may be compatible only after contract tests; removing required inputs or changing side-effect semantics is a breaking version.
- At runtime, no implicit fallback to `latest`. If pinned dependency is absent, fail start or enter `BlockedByDependency` with audit.
- Service code versions are tracked separately from operation contract versions; a new service deployment may preserve the contract only if compatibility tests pass.

## 6. API contracts (all future routes proposed)

- `GET /api/v1/capabilities`, `GET /api/v1/capabilities/{key}/operations`, `GET /api/v1/operations/{key}/versions/{version}`.
- `POST /api/v1/manifests/validate`, `POST /api/v1/manifests/submit`, `POST /api/v1/manifests/{id}/approve`, `GET /api/v1/manifests/{id}/readiness`.
- `POST /api/v1/operation-tests/{key}/execute` (non-PROD approved fixture only, separate test permission).
- `POST /api/v1/workflow-drafts/{id}/validate`, `POST /api/v1/workflows/{key}/runs` and authorized lifecycle endpoints.

Every endpoint must be OpenAPI-described and tested directly without a browser, including denied and invalid requests. Never let a generic test endpoint execute arbitrary operations or reach PROD.
