# SDK 06 - DCMS: End-to-End Composition, Configuration, Execution and Evidence

**Purpose:** Use the user-described DCMS behavior to prove the generic Unity platform. DCMS must remain a workload/application, not SDK/BOB special code. Field names, CyberArk DTOs and API return codes must be confirmed in repo.

## 1. Source-described business process (do not reinterpret)

- User uploads CSV containing new values for account/platform custom attributes.
- Import rows into a data-owned table. Assign **one batch number** to the import and a **GUID to every row**.
- Process each row sequentially for the initial workflow.
- Locate the corresponding CyberArk account.
- Replace/add the specified custom attribute values **in account memory first**.
- Execute add/update account API call.
- Record per-row success/failure/pass/skipped and human-useful reason.
- After batch completion, generate report with all pass/fail/success reasons and send via Email Capability.
- Future (NOT currently implemented): approved API ingestion, scheduled AutoSys/DB API pull, additional trigger sources; leave extension seams rather than implementing prematurely.

## 2. Service inventory and compile-time primitives

| Primitive (proposed stable key) | Owner | Input -> Output | Side effect | Required protection |
|---|---|---|---|---|
| Data.ValidateUpload | Data/ingestion | uploadRef -> validation | Read | file policy, schema, classification |
| Data.StageBatch | Data/ingestion | validatedRef -> batchId, rowCount | DB write | idempotent upload key |
| Data.GetBatchPage | Data/ingestion | batchId, pageCursor -> page rows | Read | owner-scope, pagination |
| CyberArk.GetAccount | CyberArk | accountRef -> accountRecord | Read | PAM.Account.Read |
| CyberArk.ApplyAllowedAttributePatch | CyberArk | accountRecord, patch -> modifiedRecord | In-memory transform | platform allowlist |
| CyberArk.AddOrUpdateAccount | CyberArk | modifiedRecord + revision -> writeOutcome | External write | PAM.Account.Update, reconciliation |
| Data.RecordRowOutcome | Data/ingestion | rowGuid, disposition, reason -> persisted status | DB write | expected revision + idempotency |
| Reporting.ComposeBatchReport | Reporting | batchId -> secureReportRef | Artifact write | scope, redaction |
| Email.SendApprovedNotification | Email | reportRef, recipientsPolicyRef -> delivery outcome | External send | recipient policy + deduplication |

All keys are **candidates**. Existing CyberArk and data operations in the repo must be mapped, not rewritten.

## 3. AMIE descriptors (proposed, not current source names)

- `DCMS.ValidateAccount@1`: facts CurrentRow+GetAccountResult+Platform; result Eligible/Skip/Reject with reasonCode.
- `DCMS.MapAttributes@1`: facts CurrentRow+Platform; result typed `CyberArkAttributePatch` of four allowed custom attributes.
- `DCMS.ShouldUpdate@1`: facts original account + proposed patch; result Update/NoChange and reason.
- `DCMS.ClassifyBusinessResult@1`: facts validation+actual external outcome; result business status/reason (do not conflate with successful validation).

Rules are configuration. No static `if application == DCMS` in CyberArk or BOB. AMIE evaluator is existing code; use adapter.

## 4. UI configuration click path

1. **Application Studio** -> New application -> enter `DCMS`, owner, allowed scopes, process template and business display settings -> Save draft.
2. **Capability Catalog** -> inspect `Data.StageBatch@ver`, `Data.GetBatchPage@ver`, `CyberArk.GetAccount@ver`, `CyberArk.AddOrUpdateAccount@ver`, `Reporting.ComposeBatchReport@ver`, `Email.SendApprovedNotification@ver` -> check availability and permission.
3. **Workflow Library** -> Create Draft from `Batch + Sequential Rows` template -> name `DCMS.Batch` -> select Central BOB.
4. **BOB Designer** -> configure start trigger (CSV upload), stage task, embedded CyberArk subworkflow task (Kafka dispatch), await correlated result, report task, email task, end event; link connections; save.
5. **Embedded subworkflow** -> sequential multi-instance over data-owned page iterator; GetAccount -> AMIE.Validate -> exclusive gateway; Map -> ApplyPatch -> AddOrUpdate -> RecordRowOutcome. Continue on configured row failure after recording outcome.
6. **AMIE Rules** -> bind rule descriptors to typed facts. Map each source CSV column to target platform custom attribute; configure missing-value policy and NoChange decision; execute fixture preview.
7. **Triggers & Forms** -> choose Manual CSV; generate required data input schema and file metadata; future API/AutoSys trigger marked planned/not active.
8. **Kafka Contracts** -> view logical command/outcome types, required correlation, partition policy; no freeform topic editing.
9. **Environment Bindings** -> choose `DEV` approved CyberArk endpoint ref, staging API, broker logical topic and test recipients; verify dependencies, no credential values.
10. **Validate Draft** -> backend BPMN/compiler/schema/rule/operation/host/permission checks; fix errors on node inspector.
11. **API Regression** -> test 5-row success+failure fixture, duplicate command, missing account, declined rule, uncertain write, row checkpoint, email failure and role denial.
12. **Workflow Library** -> Submit Review -> independent approve -> Publish immutable version. **Release Center** -> UAT exact digest, then production only after real bank approvals and Operations activation.
13. **Business Work Queue** -> upload CSV (authorized user) -> start batch; see counts and record reasons. **Run Monitor** for authorized staff -> diagram overlay, correlation, activity detail. **Audit** -> reconstruct run and report evidence.

## 5. Runtime logical sequence

```mermaid
flowchart TD
  U[Authorized CSV upload] --> S[Data validates and stages batch/row GUID]
  S --> CB[Central BOB starts pinned DCMS.Batch]
  CB --> OUT[Persist command/outbox; Kafka dispatch]
  OUT --> EB[CyberArk Embedded BOB receives batchRef]
  EB --> PAGE[Data-owned paginated row fetch]
  PAGE --> ROW[Sequential row iteration]
  ROW --> GET[CyberArk.GetAccount]
  GET --> RULE[Existing AMIE Validate / Map / ShouldUpdate]
  RULE --> DEC{Eligible and change?}
  DEC -->|Yes| PATCH[Apply allowed changes in memory]
  PATCH --> WRITE[CyberArk AddOrUpdate]
  DEC -->|No| RESULT[Persist skipped/nochange/rejected reason]
  WRITE --> RESULT
  RESULT --> NEXT{More rows?}
  NEXT -->|Yes| ROW
  NEXT -->|No| DONE[Publish correlated batch outcome]
  DONE --> REPORT[Reporting composes artifact]
  REPORT --> EMAIL[Email Capability sends approved report]
  EMAIL --> END[Central BOB records terminal business status]
```

## 6. Exact example fixture

- CSV source: 5 rows `accountRef,platformKey,application,costCenter,owner,businessUnit` (illustrative column names).
- Batch: `BATCH-DCMS-0001` with five row GUIDs generated at staging.
- Expected: row 1 updated; row 2 no change; row 3 rejected missing account; row 4 skipped by AMIE rule; row 5 external call timed out after request, marked UnknownExternalOutcome pending reconciliation.
- Per-row invariants: batchId stable, unique rowGuid, one active claim per row, no second write for duplicate command without reconcile, reason code persisted, audit has rule/operation/package versions.
- Aggregate counts **must reconcile** to all rows. `Total = Succeeded + NoChange + Rejected + Skipped + Failed + UnknownOutcome + InProgress + Pending`; terminal count should exclude unknown states until resolution policy says otherwise.
- Report contains status and human-readable reason per row, not raw credentials. Email status is separate from CyberArk update outcome.

## 7. Recovery and release proof

- Crash after row two: after restart rows 1 and 2 are not blindly processed again; row three is resumed or claimed safely.
- Broker delivers `ExecuteEmbeddedWorkflow` twice: inbox prevents duplicate batch side effects.
- Timeout after CyberArk write: query/reconcile external state before retry; do not assume failure.
- Pause mid-row: complete or reconcile current external write, then pause at checkpoint; show PauseRequested until actually paused.
- Replace AMIE version in DEV: new draft package required; existing batch remains pinned.
- Trigger source changes later from CSV to approved API: input adapter changes, downstream staged-row contract and BOB/AMIE composition remain stable.

## 8. Demonstration success criteria

Present in BE: source/upload -> batch + row GUIDs -> configured BPMN with registered operations -> AMIE mapping/eligibility -> one real/approved nonprod CyberArk update or clearly marked stub -> final persisted row reasons -> report/email outcome -> live business dashboard -> technical run overlay -> audit reconstruction. Also demonstrate a second workflow (Hygiene) reusing at least one capability operation without source edits; if second pilot not complete, mark it pending, not demonstrated.
