# SDK 05 - Security, Audit, Operator Controls, and Release Promotion

## 1. Least privilege / identity

Every invocation checks backend API auth, workflow/app scope, resource scope, service identity and operation permission, **again in the capability worker**. A user may view only their own batch without permission to view the BPMN process, inspect safe audit events or operate runs. BE controls visibility but does not enforce security alone. Align bank roles to actual SSO groups after owner review.

Proposed roles: BusinessRequester, BusinessExecutor, WorkflowDesigner, RuleMaintainer, CapabilityMaintainer, WorkflowReviewer, ProcessOperator, ReleaseOperator, Auditor and PlatformAdministrator. Role names are placeholders pending enterprise mapping. No shared wildcard admin role for ordinary users.

## 2. Audit storage strategy

MSSQL append-only events are the operational source for reconstruction. Tables for current run/batch status are projections for fast reads. Preserve event version, eventId, UTC event/record time, run/activity, message/correlation/causation, actor/service identities, operation/rule/package version references, batch/row GUID, reason/outcome, resource scope, relevant ServiceNow ticket and runbook/control ID, and payload hash/protected reference. Prevent update/delete for normal service roles; consider write-once controls, retention and ledger separately with bank approval.

Audit export is a controlled, scope-filtered API; redact credentials, raw account content, tokens and sensitive CSV data. The event history is not a secret copy of source payloads.

## 3. Operator semantics

| Command | Precondition | Result / audit | Forbidden |
|---|---|---|---|
| Pause | Running, ProcessOperator for scope, reason, current revision | PauseRequested; reach Paused at safe boundary, emit reason/time | Pretend to reverse a started write |
| Resume | Paused, compatible pinned dependencies, authorized | Running, queue next task, audit | Resume incompatible retired dependency silently |
| Cancel | Running/Paused, authorized reason | CancelRequested; settle or reconcile outstanding, then Cancelled | Remove historical evidence |
| RetryFailedStep | Failed at safely retryable step, reconciled prior attempt | New attempt on same run with linkage | Blind retry on unknown CyberArk write |
| RestartAsNewRun | Terminal run, authorized and policy allows | New runId linked to old, new explicit input selection | Reuse old runId or alter original outcomes |
| Export audit | Scoped auditor access | Evidence export with redaction and audit of export | Leaks raw secret/sensitive fields |

All mutating actions require expected revision/ETag to prevent two operators issuing conflicting commands. UI shows pending acknowledgement and refreshes from server; local click is not authoritative success.

## 4. Release and production control flow

- Author creates/validates draft in DEV. BPMN, AMIE rules, capability contract versions and bindings manifest are locked into immutable package digest.
- Reviewer checks diff, complete test evidence, maker/checker separation where required, and change ticket. Approval is an authoritative backend event, not a typed ticket field.
- UAT deploys **exact package bytes**, substitutes only allowlisted environment refs, executes regression and captures evidence.
- Release Center production preflight checks signature/digest, compatible live service manifests, Kafka ACL, secrets refs without exposing values, rule versions, approved CA/control evidence and user rights.
- Operations-controlled pipeline activates package; developer does not need PROD access. Existing runs stay pinned, new runs receive new active version.
- Rollback selects previously approved package for **future** starts. It does not roll back external CyberArk writes.

## 5. Controls vs software permissions

Runbooks/controls specify required operational procedure, permitted exception path, required evidence, escalation and owner. Roles specify who may invoke which API. Both must be represented and validated separately. Actual Wells Fargo CAs, control IDs, retention and ServiceNow integration are UNKNOWN until verified by authorized owner. Never invent them or mark a mock ticket as bank approval.

## 6. Production-safe testing

- Developer/tester fixtures run only in isolated DEV/UAT with approved test accounts and test broker bindings.
- Destructive or external writes must use approved fake server/test tenant or explicit owner permission.
- No API Regression button executes production writes or creates broker subscriptions from arbitrary user input.
- Negative tests: denied direct API, altered manifest digest, wrong environment binding, duplicate command, timeout during external write, cross-tenant data disclosure, self-approval and missing control evidence.
