# SDK 03 - BOB, AMIE, Capability and Kafka Interaction Protocol

This is the interaction contract DEVIN must implement or map to existing code. It is a **proposed architecture**, not a verified current runtime.

## 1. Central versus embedded host boundary

```mermaid
sequenceDiagram
  participant BE as BE API / Designer
  participant CB as Central BOB
  participant SQL as MSSQL state and outbox
  participant K as Kafka
  participant CH as Capability Host / Embedded BOB
  participant AM as Existing AMIE
  participant H as Approved handler
  participant AU as Audit
  BE->>CB: Start approved workflow package
  CB->>SQL: Persist run + waiting command + outbox atomically
  SQL-->>K: Outbox dispatcher emits authorized command
  K-->>CH: Deliver command (may be repeated)
  CH->>CH: Verify auth, digest, inbox key, compatibility
  CH->>AM: Evaluate pinned rule locally
  AM-->>CH: Typed decision + reason
  CH->>H: Execute handler using typed mapped input
  H-->>CH: Outcome incl external reference
  CH->>AU: Append safe operation/decision evidence
  CH->>K: Publish correlated outcome via outbox
  K-->>CB: Deliver outcome (may be repeated)
  CB->>SQL: Compare-and-swap complete waiting activity
  CB-->>BE: Status projection / secured near-real-time hint
```

Embedded BOB uses the **same** BPMN parser/compiler/interpreter as central BOB; its host adapter selects local DI, AMIE, and storage/transport. Central BOB may wait durably in MSSQL. Do not implement an application-specific local workflow engine inside the CyberArk adapter.

## 2. Compilation of a workflow designed in BE

1. Load BPMN 2.0 XML + BPMN DI geometry; reject malformed XML, unsupported semantic elements, unreachable branches, missing IDs and ambiguous joins.
2. Parse vendor-neutral service tasks / business rule tasks; read Unity extension bindings (operationKey@version, ruleKey@version, input/output mapping, host, retry policy).
3. Resolve approved Capability Registry manifest and AMIE rule descriptor, including ownership, availability, schemas, permission and side effect.
4. Type-check every source (trigger field, item field, prior task output, rule output, constant, environment ref, secret ref) against required input. Null/default/classification policy must be explicit.
5. Resolve child/call activity and sequential multi-instance semantics. Pin exact dependency versions and output a deterministic package lock/digest.
6. Check configured execution host can access the requested local handler and AMIE rule; otherwise require remote command mode. Reject silent transport fallback.
7. Enforce allowable concurrency, timeouts, cancellation and retry/reconciliation behavior; no unsafe automatic retry for CyberArk external writes.
8. Emit prepublish validation results by BPMN element ID, field path, severity, code, description and suggested action. Only error-free approved definitions can publish.

## 3. On executing a local task

1. Shared BOB evaluates task input binding in a typed workflow context.
2. Before a privileged handler, authorize service identity and the signed actor context/scope at dispatch; BOB's previous validation alone is not sufficient.
3. Dispatcher resolves an allowlisted `operationKey@contractVersion` to a DI handler. It never reflects untrusted CLR method names.
4. Invoke with `UnityExecutionContext`, cancellation token, per-operation timeout and safe telemetry scope.
5. Validate output schema, redact classified data, persist outcome/audit and advance token exactly once.
6. For local AMIE business-rule task, call existing AMIE API, not a new rule interpreter; obtain typed decision and safe reason. Version pin is mandatory.

## 4. On remote task through Kafka

Before publish, persist *both* pending command state and outbox record in one BOB-owned transaction. Kafka producer publishes pending outbox. The capability consumer validates schema, broker principal, caller audience, policy, idempotency key and package version, then checks inbox. For duplicates, replay prior stable outcome or reject safely. Execute handler and persist outcome in same capability-controlled transaction when possible; external CyberArk writes are not part of that transaction and require reconciliation.

The outcome envelope includes command ID, causation/correlation ID, run ID, activity ID, operation key/version, status, reason code and safe result reference. The BOB outcome consumer updates its waiting activity only once by optimistic concurrency. Out-of-order and late messages are recorded; they do not advance the wrong run.

## 5. Failures and reconciliation

| Failure | Required behavior | Forbidden behavior |
|---|---|---|
| Invalid input schema | Reject before dispatch, audit safe error | Invoke handler with half-built DTO |
| AMIE rule false | Follow configured BPMN branch, record rule reason | Treat false as CyberArk write failure |
| Handler returns NoChange | Persist business NoChange and continue | Report update success without a write |
| CyberArk returns clear failure | Record Failed with safe reason/retry policy | Infinite unbounded retry |
| Network timeout after write request | `UnknownExternalOutcome`; reconcile with external reference/state | Blindly retry a possibly successful write |
| Kafka message duplicate | Inbox dedup, replay stable outcome | Execute same write twice |
| Kafka outcome lost | Keep durable waiting state, retry transport or query correlation | Move token to success without evidence |
| Worker crashes mid-batch | Resume at checkpoint and reconcile current row | Restart batch from row one without checking outcomes |
| Pause while write in flight | Set PauseRequested, stop new steps at safe checkpoint | Kill ongoing HTTP call and claim rollback |
| Cancel | Cooperative stop, mark unfinished work explicitly | Delete history or claim external rollback |
| Retired rule/handler after start | Keep pinned version if still available or mark dependency blocked | Replace with newest rule without review |

## 6. DCMS as application-level sequence

Central BOB: authorized manual CSV / future API start -> Data capability stage -> create batch and row GUIDs -> send `ExecuteEmbeddedWorkflow` to CyberArk capability -> wait for result -> report generation -> Email Capability -> summarize and close. Embedded BOB: get bounded page -> sequential multi-instance row loop -> CyberArk.GetAccount -> AMIE eligibility -> AMIE mapping -> CyberArk ApplyAllowedPatch in memory -> CyberArk AddOrUpdate -> row outcome persist -> next row -> aggregate completion. This is a **configured** workflow, not special code in BOB or SDK.

## 7. Evidence contract

At minimum emit `WorkflowStarted`, `TaskScheduled`, `RuleEvaluated`, `OperationRequested`, `OperationCompleted|UnknownOutcome`, `RowOutcomeRecorded`, `WorkflowPaused|Resumed|Cancelled|Completed`, `NotificationRequested`, `NotificationOutcome`, `ConfigurationPublished|Activated`, and `ControlAction` with actor, UTC, version digest, correlation, run/activity, source references and safe summary.
