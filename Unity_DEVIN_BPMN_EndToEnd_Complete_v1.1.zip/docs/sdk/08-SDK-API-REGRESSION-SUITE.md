# SDK 08 - Required API / Contract / Runtime Regression

All BE interactions must have server APIs. Test semantics through API/worker even when a UI screen is not yet built. The routes below are proposed families; align with actual API surfaces from repository inspection.

| ID | Test request / setup | Expected behavior / rejection | Owner |
|---|---|---|---|
| SDK-01 | Start service with two handlers same key/version | Startup fails diagnostic, no ambiguous registration | SDK |
| SDK-02 | Valid compiled handler + manifest fixture | Deterministic schema and registry descriptor | SDK |
| SDK-03 | Manifest submitted by untrusted caller | 403 / no registry state change, audit denial | Registry |
| SDK-04 | Manifest has invalid schema or missing permission | 422 structured field errors | Registry |
| SDK-05 | Registry `Registered` but service incompatible/unhealthy | BE sees unavailable; BOB denies execution | Registry |
| SDK-06 | GET operations as scoped user | Only permitted descriptors/details returned | API/RBAC |
| SDK-07 | GET operation input schema | Required fields/types and classification match DTO | SDK/BE |
| SDK-08 | Bind string to complex object input | Compiler returns BIND_TYPE_MISMATCH and BPMN element ID | BOB |
| SDK-09 | AMIE rule missing required fact | Compiler error; no publish | AMIE bridge |
| SDK-10 | AMIE evaluates valid fixture in embedded host | Typed output and pinned rule version | AMIE bridge |
| SDK-11 | Local handler via BOB | No central per-step HTTP roundtrip | Embedded host |
| SDK-12 | Kafka remote handler invocation | Correlated persisted command/outcome, token resumes once | Kafka/BOB |
| SDK-13 | Duplicate Kafka command | No duplicate write; stable outcome | Capability worker |
| SDK-14 | Timeout after external write sent | UnknownExternalOutcome; reconciliation gate | CyberArk worker |
| SDK-15 | Worker restart after two DCMS rows | Resume remaining rows; no duplicate outcomes | Embedded host |
| SDK-16 | Paused mid-CyberArk write | PauseRequested, safe checkpoint, no false rollback | BOB/operator |
| SDK-17 | Wrong role invokes operator API | 403, state unchanged, denial event | Security |
| SDK-18 | Different user reads batch outside scope | 403/404, no sensitive metadata | BE API |
| SDK-19 | Published workflow edited in place | Reject conflict; copy to new draft required | Definition API |
| SDK-20 | Approved UAT package changed before PROD | Digest mismatch blocks activation | Release |
| SDK-21 | Typed ServiceNow ticket but no approval evidence | PROD preflight blocked | Release |
| SDK-22 | DCMS five-row fixture | Correct per-row and aggregate statuses, reasons and report | DCMS |
| SDK-23 | Email fails after account processing | Account outcomes preserved; email separate | Email |
| SDK-24 | Reuse same GetAccount operation in Hygiene and DCMS | No BOB core or CyberArk handler code change | Integration |
| SDK-25 | Simulate broker reconnect during monitor | Business projection refreshes from API, no ghost state | BE |
| SDK-26 | Audit export with restricted account details | Redacted, scope-limited, export event logged | Audit |
| SDK-27 | Unsupported BPMN element | Validation/publish error, not silent skip | BOB |
| SDK-28 | Disallowed physical Kafka topic from UI | Reject; only approved logical bindings | SDK/Security |

## Response conventions

- 200/201 success with correlation, revision and stable schema.
- 202 accepted async run/control request; do not misrepresent as completed.
- 400 syntax, 401 unauthenticated, 403 unauthorized, 404 scoped invisible, 409 revision/dependency conflict, 422 semantic/schema errors, 503 unavailable dependency. Exact codes must be finalized with existing API conventions.
- Negative tests assert no side effects and audit denial. Positive tests assert actual state, not merely HTTP status.
- Regression results must record test identity, time, environment, package/manifest digest and evidence URI. Fixtures cannot contain real passwords or live account identifiers.

## CI lanes

- PR: build, static security checks, SDK registration and schema fixtures, BOB parser/compiler semantics, AMIE adapter unit tests, API authorization, deterministic UI interaction tests.
- DEV integration: Kafka consumer/outbox/inbox, MSSQL database migrations/checkpoint/audit, fake CyberArk external client, crash/restart and duplicate tests, BE UI+API E2E.
- UAT: exact approved package digest, compatible service versions, controlled test tenant, bank-required CA evidence and smoke test.

Do not label tests as passing without execution evidence in the actual repository pipeline.
