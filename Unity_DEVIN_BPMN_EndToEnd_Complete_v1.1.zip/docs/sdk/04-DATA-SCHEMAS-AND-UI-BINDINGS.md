# SDK 04 - Schema-driven BE Forms and AMIE/BOB Binding

## 1. Why the descriptor is a UI contract

When capability publishes a `GetAccount@1.0` descriptor, BE should automatically render: operation title, required/optional input fields, data types, source binding controls, output variables, execution host choices, permissions/side effects, timeout/retry and test fixture. No CyberArk-specific Razor form should be required for each operation.

## 2. Unified typed binding descriptor (proposed)

```json
{
  "targetField": "accountRef",
  "sourceKind": "CurrentItem",
  "sourcePath": "item.accountRef",
  "expectedSchemaRef": "schema://cyberark/account-ref/1.0",
  "nullable": false,
  "onMissing": "ValidationError",
  "dataClassification": "Internal"
}
```

Supported source kinds for MVP: WorkflowInput, CurrentItem, PriorOperationOutput, AmieRuleOutput, ConstantAllowlisted, EnvironmentBinding, SecretReferenceServerSide. The user sees logical references only; raw secrets must never be resolved into browser fields or BPMN XML.

## 3. Binding builder behavior

1. User selects an operation in Capability Catalog and clicks Add to Workflow.
2. Designer inserts a service task with stable BPMN element ID and pinned operation key/version.
3. Inspector fetches operation descriptor from authorized API and dynamically renders input slots.
4. For each slot, user picks source kind; picker offers only in-scope upstream outputs with a compatible JSON schema/data classification.
5. A missing required field is visibly invalid. An incompatible type is invalid even if a fake preview happens to work.
6. On adding AMIE rule, inspector loads rule descriptor and offers required facts from available workflow context; resolved decisions become branch conditions.
7. User chooses permissible host (Local vs Kafka) only from operation manifest and workflow deployment constraints.
8. Save persists a Draft (ETag/optimistic concurrency), Validate calls backend BOB compiler and AMIE adapter validator, Preview runs only deterministic DEV fixtures.
9. A published package locks exact manifests/rules/BPMN/subprocess versions; designer previews do not grant production execution.

## 4. Dynamic form generation

Inputs may have `type`, `format`, `enum`, `required`, `minLength`, `maxLength`, `maximum`, `pattern`, `description`, `classification` and optional approved UI hints. Required data is derived from the schema, never from the decorative mockup. The form engine supports hidden fields only for security/data dependency, server-side validation and structured error display. It must not expose an unrestricted JavaScript expression or C# editor to end users.

## 5. Example DCMS bindings

| Task | Field | Source | Validation |
|---|---|---|---|
| StageBatch | uploadedCsvRef | trigger.uploadRef | Authorized non-secret file ref, file passed safety checks |
| GetPage | batchId | steps.stage.output.batchId | Typed batch identifier, paginated bounds |
| GetAccount | accountRef | item.accountRef | Required, correct scope |
| AMIE.AccountEligibility | row, account | item + steps.get.output.account | Pinned rule and fact schemas match |
| AMIE.AttributeMap | row, platform | item + steps.get.output.platform | Only allowed custom attributes emitted |
| ApplyAllowedPatch | account, patch | previous account + rules.map.output.patch | Platform-specific patch schema validated |
| AddOrUpdate | modifiedAccount | steps.apply.output.account | Write authorization + reconcile policy |
| RecordRowOutcome | recordGuid, result | item.guid + steps.upsert.output | Side-effect outcome distinct from rule-pass |
| ComposeBatchReport | batchId | workflow.input.batchId | Counts reconciled against terminal rows |
| RequestNotification | reportRef, recipientPolicyRef | steps.report + config | Permission and recipient allowlist |

## 6. Designer error contract

Return errors as `{code, severity, bpmnElementId, fieldPath, message, suggestedAction}`. Required examples: `BIND_REQUIRED`, `BIND_TYPE_MISMATCH`, `BIND_UNAUTHORIZED_SCOPE`, `RULE_VERSION_UNAVAILABLE`, `OPERATION_NOT_APPROVED`, `HOST_MODE_UNSUPPORTED`, `BPMN_ELEMENT_UNSUPPORTED`, `DUPLICATE_OPERATION_KEY`. BE must display them on the affected node and in a keyboard-accessible issue list. A disabled Publish button is not a substitute for backend rejection.

## 7. Example data source GUI

- Node selected: `Task_GetAccount`.
- Operation inspector: `CyberArk.GetAccount@1.0`; permission `PAM.Account.Read`.
- Required `accountRef` -> choose Current Item -> `DCMS.Row.AccountRef`.
- Output `AccountRecord` -> name `account`.
- Test contract -> sanitized fixture only (DEV); result visible with safe event IDs.
- Validate -> green only if BE/backend schema, AMIE dependencies, host and permissions agree.

## 8. Explicit design alternatives

For MVP, an auto-generated property inspector plus a controlled binding picker is more feasible than a full no-code generalized forms builder. Advanced expression editing, custom renderers, full human-task form designer and advanced BPMN elements remain backlog unless first pilot proves they are required.
