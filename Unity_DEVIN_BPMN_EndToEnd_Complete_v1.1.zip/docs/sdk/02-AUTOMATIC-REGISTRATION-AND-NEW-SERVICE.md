# SDK 02 - Automatic Registration, Service Bootstrap and Registry Publication

Status: implementation design; current AMIE/capability conventions are unknown until source audit.

## 1. Creating a service (dev workflow)

1. Select the domain owner and service archetype: CyberArk/PAM, Data, Email, Reporting, Identity or Legacy. Determine data owner, environment policies, and broker requirements.
2. Create the service from an approved .NET service template; reference shared Unity.Contracts and Unity.Hosting packages already reviewed by Wells Fargo.
3. Implement typed handlers. Write handler metadata (`UnityOperation` attribute or equivalent compile-time registration) and DTOs; no dynamic code execution. Handler must be DI-constructible and in an allowlisted compiled assembly.
4. Classify each operation: read, local transform, external write or high-impact external write; define permission, timeouts, idempotency and result reconciliation.
5. Implement adapter clients and secret refs through approved DI; do not put credentials in handlers/manifests.
6. Add AMIE rule descriptors only as **references/typed bindings**. Existing AMIE compiler/evaluator remains authoritative.
7. Declare logical command/outcome contracts; environment settings map logical keys to authorized Kafka topics/consumer groups.
8. Register handlers in startup; on failure in production registration fail fast with deterministic diagnostic (duplicate key, invalid schema, missing policy, wrong major version).
9. Generate manifest + JSON Schema + examples + OpenAPI metadata as build outputs; verify against approved fixtures.
10. Run CI tests, create/approve ordinary service-code release, deploy via approved pipeline, submit manifest via privileged service identity.
11. Registry checks signature/provenance, service release, owner, compatibility, policies, and environmental readiness; BE discovers only the properly scoped descriptors.
12. Reuse the operation from an authorized workflow; observe correlated audit and repeat in a second workflow without code changes.

## 2. Example registration (illustrative, not verified repo API)

`/Unity.Capability.CyberArk/Program.cs`

```csharp
builder.Services
  .AddUnityCapabilityHost(o => o.CapabilityKey = "CyberArk")
  .RegisterApprovedOperations(typeof(GetAccountHandler).Assembly)
  .UseExistingAmieAdapter()
  .UseEmbeddedBob()
  .UseKafkaContracts()
  .UseStructuredAudit();
```

The implementation must scan **only** assemblies allowed by the deployed service configuration or use compile-time generator registration. Do not accept assembly names or method names from the network or manifest consumers.

`/Unity.Capability.CyberArk/Operations/GetAccountHandler.cs`

```csharp
[UnityOperation("CyberArk.GetAccount", "1.0",
   Policy = "PAM.Account.Read", SideEffect = "Read")]
public sealed class GetAccountHandler
    : IUnityOperationHandler<GetAccountRequest, GetAccountResponse>
{
    private readonly ICyberArkClient _client;
    public GetAccountHandler(ICyberArkClient client) => _client = client;

    public async Task<OperationOutcome<GetAccountResponse>> ExecuteAsync(
        GetAccountRequest request, UnityExecutionContext context,
        CancellationToken ct)
    {
        // Actual adapter, error mapping and authorization must be implemented
        // against the existing service. No mock production client.
        var account = await _client.GetAccountAsync(request.AccountRef, ct);
        return new(OperationDisposition.Succeeded, "ACCOUNT_FOUND",
                   "Account read succeeded", new(account), null, null);
    }
}
```

Example intentionally omits credentials and concrete SDK/library details. Real code must use existing policy, cancellation, retry and audit interceptors.

## 3. Startup validation algorithm

1. Discover allowed handler type and declaration.
2. Verify exactly one expected typed interface and DI registration.
3. Verify unique operation key/version and permitted compatibility major.
4. Validate input/output JSON schemas against DTOs, fixtures and declared classification.
5. Ensure required permission/scope and side-effect policy are supplied.
6. For writes, require idempotency behavior and `UnknownExternalOutcome` reconciliation strategy.
7. Check message contract names, required fields, correlation and partition key.
8. Validate AMIE descriptor references are resolvable for declared runtime where needed.
9. Construct immutable manifest with deterministic digest; emit startup diagnostic state.
10. Expose metadata to authenticated deployment/registry agent, but DO NOT self-approve.

## 4. Manifest publication lifecycle

Build CI produces manifest artifact and approved service release -> release pipeline deploys binary -> signed deployment identity submits manifest -> Registry validates owner, signature, compatible handler/codeVersion, exact schema, environment ACL -> Registry marks `Registered` -> operational readiness checks mark `Available` -> BE discovery is scope filtered -> BOB can bind only `Available` approved operations. Republish or revoke under control; no arbitrary end-user registration from BE.

## 5. New primitive vs configuration decision

Ask in order:

- Is there an approved operation that already produces the required output? Reuse it.
- Can a combination of existing operations, BOB control flow and AMIE mapping produce the result without bypassing security? Configure it.
- Is a new domain primitive required (e.g. verified safe movement)? Implement once in owning capability with a reviewed code release, schema, policy and tests.
- Is the proposed primitive unbounded (generic REST executor, arbitrary SQL, direct C# eval)? Reject and replace with typed approved operation.

## 6. DEVIN coding boundaries

- Preserve existing DI host style, .NET version, project names and namespace conventions.
- Do not generate a new central AMIE runtime or duplicated BOB interpreter.
- Do not hardcode physical topic names or endpoints into descriptors.
- Do not include DCMS as a capability kind. DCMS is an application/workload config.
- Publish PR with actual `/Project/Folder/File.cs` paths and New/Updated/Deleted/No Change summary.
- Add unit/contract tests and a demo showing operation discoverable in BE and reject unauthorized direct call.
