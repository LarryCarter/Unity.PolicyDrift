# SDK 00 - Why a Unity Capability Service Exists

Status: DESIGN PROPOSAL built on user-established Unity architecture. Before coding, DEVIN MUST inspect the actual repo in JOB-00. Do not interpret proposed namespaces as implemented APIs.

## 1. Purpose and non-goals

A capability service is an independently deployed .NET service exposing approved, reusable business-system primitives through versioned typed contracts. It performs operations that require privileged access, domain validation, network or SDK interaction, or domain data ownership. It **does not own an application's end-to-end business workflow**.

Examples:
- CyberArk: GetAccount, FindAccount, ReadPlatform, ApplyAllowedAttributePatch, AddOrUpdateAccount, MoveAccount (only if separately implemented and authorized).
- Data/ingestion: ValidateCsv, StageBatch, GetPage, RecordRowOutcome, ReadBatchSummary. The owner owns business staging data, not BOB's workflow state.
- Email: SendApprovedNotification using template and recipient policies; the email transport is not inside BOB.
- Reporting: ComposeBatchReport, return access-controlled artifact reference; not automatically send email.
- Identity: ResolveUser/Group within approved scope; not a generic privileged directory browser.
- Legacy: Typed facade over a reviewed API; not arbitrary service method invocation.

Do not put DCMS-specific branches in CyberArk handlers, author AMIE rules in source code just for DCMS, create unrestricted SQL/HTTP operation handlers, or let BE submit arbitrary CLR assembly names or Kafka topics.

## 2. Platform responsibility matrix

| Concern | Source of truth | How consumers access it | Prohibited coupling |
|---|---|---|---|
| Workflow definition / version | BOB/Unity configuration package | BE designer + workflow API | Capability inventing its own private workflow format |
| Token execution / checkpoints | BOB shared interpreter | Embedded/central BOB host | Different semantics per host |
| Business decision/mapping | Existing AMIE runtime / published rule package | Typed AMIE adapter | BOB duplicating rule grammar |
| Compiled primitive/permissions | Capability release + manifest | Registry/dispatcher/worker | BE invoking arbitrary C# type |
| Event transport | Kafka with approved logical contracts | Shared SDK outbox/inbox | Browser talking to Kafka directly |
| Operational current state | Workload data owner and BOB projection | Authorized APIs/BE view | All capabilities reading one shared DB |
| Immutable audit history | Append-only MSSQL event store | Scope-filtered audit API | Audit derived only from ephemeral logs |
| Visualization, authorization UX | BE (Blazor) | API-first UI | Hiding buttons as sole security control |
| Release and approvals | Operations/change-control process | Release API + immutable package | Developer direct PROD access |

MSSQL is the sole **BOB persistence** target for MVP; capability-owned business data may use its approved datastore or API. No cross-service direct table access is implied.

## 3. Minimum contracts every service must supply

1. **Service identity**: capability key, code release/version, service owner, deploy identity and health.
2. **Operation descriptors**: stable `capability.operation@major.minor` identity, request and result schema, classification, required permission/scope, side effect, retry/reconcile mode, supported execution hosts, timeout, fixture identifiers.
3. **Message descriptors**: logical inbound command/outbound outcome identities, schema, partition key, idempotency key construction, consumer group and permitted environment bindings. Kafka physical topic names and credentials are never authored in workflow tasks.
4. **AMIE binding descriptors**: each rule's expected facts and typed decision/output; operation descriptions cannot guarantee a rule is installed.
5. **Invocation boundary**: authenticated `OperationInvocation` with process/activity IDs, pinned package digest, actor/service identity references, correlation/causation IDs and idempotency key.
6. **Execution outcome**: `Succeeded`, `NoChange`, `Rejected`, `Failed`, `UnknownExternalOutcome`, with safe reason code and trace reference. Distinguish operation disposition from business row status.
7. **Audit**: structured evidence for invocation, authorization, decision, dispatch, attempt, external action, completion/reconciliation, without raw credentials or sensitive account objects.
8. **Diagnostics**: health/registry status, effective operation version, schema/contract mismatch errors, safe test fixtures; no health signal alone authorizes invocation.

## 4. Two registration events - must not be confused

- **Local registration** on trusted service startup: approved compiled operation handlers are discovered/explicitly registered in DI, validated, and made callable by the local dispatcher.
- **Enterprise publication** on approved deployment: trusted service identity submits a signed or attested manifest to registry; registry checks owner, environment compatibility, release approval, schema and permissions; only then may BE discover executable operations for its assigned scope.

An operation is useable only when the published manifest is compatible, the running service is healthy, environment bindings are configured, required auth is satisfied, and the operation is explicitly allowed for the application and workflow package.

## 5. Three execution shapes

1. **Local**: Embedded BOB invokes handler via DI, AMIE through existing local adapter. Avoid per-step central roundtrips.
2. **Remote command**: Central BOB persists an outstanding activity/command + outbox; broker delivers command to owning capability; worker validates and executes; correlated outcome resumes central BOB once.
3. **Capability subworkflow**: One approved message invokes a pinned embedded subworkflow (e.g. process staged batch rows sequentially). Worker performs several local handler/AMIE steps and emits aggregate/progress events; central host does not schedule every row's local steps.

## 6. Definition of reusable success

A safe operation registered once can appear in the BE catalog, bind to a published BPMN service task and AMIE rule, execute in its authorized host, produce consistent run/audit evidence and then be reused in a **second unrelated workflow without a new handler or BOB Core change**.

## 7. Immediate acceptance proof / no fake completion

DEVIN must show: actual handler class in repo, DI registration, manifest metadata and API response, registry approval state, BE operation inspector with typed inputs, a runnable approved BPMN path, existing AMIE runtime invocation, an outcome and audit event, a negative direct-API permission test, and replay/restart tests. Demo fixtures do not prove a real CyberArk integration.
