# UI Runbook 06 — How QA Tests the Finished Unity System

**Test both API and Blazor, never UI alone.** Use approved nonproduction identity, test data and broker/database resources. Do not run external CyberArk writes against PROD.

## BE test inventory

| Screen | Happy path | Negative path |
|---|---|---|
| Capability Registry | Manifest visible with schema and health | Unapproved operation cannot be invoked |
| Operation Inspector | Required inputs generated and mapped | Missing field/type or forbidden scope blocks validate |
| BPMN Designer | Drag supported nodes, save XML+DI, validate, publish | Unsupported gateway/invalid diagram rejected |
| AMIE Picker | Pinned approved rule evaluates | Missing/mismatched rule version errors |
| Trigger | Authorized CSV/API starts run | Malformed CSV/unauthorized/duplicate start denied |
| Business Queue | Correct counts and report | Other user's rows hidden; reconnect refresh |
| Run Monitor | Same BPMN with state overlay | Late/duplicate Kafka outcome doesn't duplicate transition |
| Operator Console | Pause->Paused->Resume; cancel/restart audited | In-flight write unaffected; stale revision refused |
| Audit | By run/batch/change ID reconstruct timeline | Restricted fields redacted; no mutate |
| Release Center | Same digest UAT->PROD after approval | Unapproved/fake ticket blocked |

## Regression sequence

1. Run unit/contract test suite after each SDK/core change.
2. Validate BPMN fixture XML and semantics of supported nodes, AMIE adapter and operation resolution.
3. Use authenticated API to create/save/validate/review/publish/start. Query run and audit via APIs.
4. Run DCMS five-row fixture with a mock or approved test CyberArk adapter, compare persisted batch rows with report and business projection.
5. Simulate Kafka duplicate, network failure, crash after possible external write, restart and concurrent operators.
6. Exercise role deny and scope partition for every mutation/read route; check redaction.
7. Run browser walkthrough, capture desktop screenshot, console errors and API evidence; don't substitute mock frontend state for real API responses.
8. Attach CI/environment/package digest/test evidence to release candidate; mark bank authorization separately.

## Acceptance threshold

No hidden unsafe retry, unauthorized operation, mismatched version, false terminal status, missing mandatory audit, or fake PROD approval. If any persists, block release and report exact failing scenario.
