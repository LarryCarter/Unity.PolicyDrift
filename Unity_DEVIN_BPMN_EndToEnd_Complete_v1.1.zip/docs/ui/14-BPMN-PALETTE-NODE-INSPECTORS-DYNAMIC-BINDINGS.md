# UI 14 - BPMN Palette, Element Inspectors and Dynamic Configuration

**Source of truth:** BPMN 2.0.2 XML + BPMN DI; BE never owns a separate executable DSL. Unity bindings use stable BPMN element IDs and typed operation/rule references, with exact versions pinned at publish. **Supported visually** is distinct from **executable**.

## Inspector tabs (every node)

| Tab | Dynamic fields | Data source | Change impact |
|---|---|---|---|
| General | name, immutable ID, description, element type, lane, documentation | workflow draft | BPMN XML + DI |
| Inputs | required/optional schema properties, binding source, transforms, type and scope | operation or rule descriptor | Unity bindings |
| Outputs | strongly typed result properties, target context path, secrecy classification | operation descriptor | context graph |
| Rule | pinned AMIE rule/version, input facts, sample evaluation, branch output | AMIE catalog | rule binding |
| Execution | local vs cross-capability, timeout class, concurrency, idempotency, wait | operation manifest, BOB host | runtime binding |
| Errors | structured error category, retry limit/backoff, timeout/boundary path, manual review | operation policy + BOB | BPMN edges + policy |
| Security | permission, application scope, runner service identity, approver roles | registry + RBAC | authorization snapshot |
| Audit | evidence category, safe payload fields, control/runbook references, version | approved control catalog | audit policy |
| Testing | test fixture, mock vs live DEV, sample output, expected failure | test catalog | test definitions |

### Palette and executable coverage decision table

| BPMN 2.0 element family | Inspector/config details | Target | Publish behavior |
|---|---|---|---|
| None/message Start Event | trigger source, normalized typed input, caller scope | P0: manual/API/Kafka normalizer | permit only implemented start form |
| Timer Start Event | schedule definition/owner/timezone/misfire | P1 unless scheduler approved | show but block unsupported timer |
| End Event | completion outcome, business status projection | P0 | confirm reachable termination |
| Service Task | operation picker + schema-driven typed mapping + host | P0 | reject unknown/unapproved operation |
| Business Rule Task | AMIE rule/version and fact/output bindings | P0 | reject missing rule or type mismatch |
| Exclusive Gateway | predicate references, named branches, deterministic default | P0 | require unambiguous default |
| Parallel Gateway | token split/join, join semantics | P1 | reject execution until verified |
| Inclusive / Event-based / Complex Gateways | branch/join and event semantics | P2 | visualize/import, not executable until conformance |
| Subprocess / Call Activity | reusable workflow key/version, input/output mapping, host boundary | P0 (call/subprocess selected) | reject recursion/version conflict |
| Sequential Multi-instance | collection expression, concurrency=1, aggregation, fail policy | P0 DCMS | require bounded input/page references |
| Parallel Multi-instance | concurrency/ordering/joins | P1 | block until token semantics tested |
| Intermediate Message Catch / Receive Task | correlation selector, expected schema, timeout, late-event policy | P0 for Kafka outcome wait; approval if required | reject missing correlation |
| Message Throw / Send Task | logical message/operation, outcome handling | P0 through approved capability | no direct topic permissions in browser |
| User Task | eligible role, assignment, form schema, due time, escalation | P1 or P0 if Account Delete demo requires real approval | cannot fake approval as ordinary task |
| Timer/Error Boundary | attached activity, interrupting behavior, timeout/error branches | P1 or minimal P0 for selected exceptions | block unverified form |
| Terminate / Error End | containment/termination rules, error code | P1 | block unsupported scope behavior |
| Lanes / Pools / Participants | actor, lane metadata, collaboration rendering | P0 visual; collaboration semantics P2 | do not treat message-flow as sequence-flow |
| Data Objects, Stores, Annotations | data refs, classification, comments | P0 visual | not executable independently |
| Compensation / Transactions / Choreography / Conversation | handlers/correlation/semantic rules | P2 | import/render with explicit unsupported badge |
| Event Subprocess, Escalation, Signal, Conditional, Link, Cancel Events | specialized event metadata | P2 | explicit unsupported on publish |

**Do not claim full BPMN 2.0 execution.** OMG distinguishes model conformance from executable process semantics. See https://www.omg.org/spec/BPMN/2.0.2.

## Capability Service Task - field-generation algorithm

1. User selects task. Read `operationKey`, `contractVersion` from current draft; if missing, display approved operation picker with app/scope filters.
2. Fetch `OperationDescriptor` (stable contract version, input/output JSON schemas, UI hints, permission, side-effect class, allowed execution hosts, retry/reconciliation policy, audit).
3. For each input schema property build `SchemaField` or `BindingPicker` by format and type; required fields cannot be empty; classify secret references server-side; validate on backend.
4. Show available typed context sources: `WorkflowInput`, `CurrentItem`, `PriorOutput`, `AMIEOutput`, approved constant, environment binding, secret reference (ref only).
5. Reject invalid source type (e.g., list bound to account ID), missing scope, prohibited secret, stale version, or untrusted manifest.
6. Output fields choose destination path and scope (workflow/subprocess/item); mark PII/sensitive values; do not show raw CyberArk account/password in audit tab.
7. Execution mode defaults to operation-approved local when handler resides in embedded host; interservice goes via approved Kafka command/outcome. User cannot force host mode unsupported by descriptor.
8. SideEffect=ExternalWrite exposes reconciliation and approval policy; unsafe retries disabled by default; no arbitrary backoff override for bank-controlled operations.
9. `Save` updates draft revision, records actor and diff. Any change invalidates previous `Validated` state.

## AMIE business-rule task dynamic fields

- Select pinned `amieRuleKey@version` and inspect declared fact/output schema from existing AMIE engine (through adapter, do not rewrite engine).
- Bind required facts to known workflow data; build optional decision branches from enumerated result e.g. `ALLOW`, `SKIP`, `REJECT`, `REQUIRES_APPROVAL`.
- Provide sample test inputs and output preview, **labeled as simulated or executed**. Separate `ruleEvaluated` from `capabilityWriteConfirmed`.
- Editor must allow field mappings from uploaded CSV rows to typed CyberArk change set, with type compatibility and null/overwrite policy explicit.
- If rule needs a fact not available from prior tasks, display `MISSING_FACT` and offer to add an approved provider operation, not arbitrary new C#.

## Data/variable binding picker component contract

```json
{
  "destination": "CyberArk.AddOrUpdateAccount.input.account",
  "expectedType": "CyberArkAccountDto@v1",
  "classification": "Restricted",
  "allowedSources": [
    {"kind":"OperationOutput", "reference":"Task_ApplyAttributes.result.account", "type":"CyberArkAccountDto@v1"},
    {"kind":"AMIEOutput", "reference":"Rule_MapAttributes.result.changeSet", "type":"AttributeChangeSet@v1"}
  ],
  "currentSelection": null
}
```

This is an illustrative picker descriptor. Backend type-checks source-to-destination against pinned schemas. No arbitrary code eval in browser or BPMN.

## Start trigger inspector

- **Manual CSV:** app, file-schema, max size, MIME/CSV delimiter policy, upload endpoint, staging operation, permitted role, duplicate batch policy. User dashboard linked to batch ID immediately after accepted staging.
- **Form:** form-schema ref, defaults, validators, run-as policy, human identity + ticket when required.
- **API:** authenticated caller service, request schema, idempotency header, request/response contract, async 202+runId.
- **AutoSys:** authorized scheduler job identity, sourceRunId, jobName allowlist, replay window, mapping to workflow input, acknowledgement response. No broad AEWS credentials in BE.
- **Kafka:** logical inbound message, schema version, trusted producer identities, correlation, dedupe and DLQ policy.
- **Timer:** only if scheduling feature/host actually implemented; AutoSys schedules can be external triggers and **do not require** BOB timer-start support in MVP.

## Designer gestures and control semantics

| Gesture/control | State mutation | Required behavior |
|---|---|---|
| Drag BPMN item into canvas | add node + stable ID + DI bounds | snap grid, undo, dirty state |
| Click node/edge | selection | inspector swaps to matching schema; no save |
| Connect anchors | add sequence flow | prevent illegal edges, create ID and waypoints |
| Rename node | draft metadata | debounce optional, validation invalidated |
| Pan, zoom, fit, snap | view transform | preview JS local, persisted DI on commit only |
| Inline add `+` | add task between flows | rewire sequence paths atomically in draft |
| Delete node | remove node + incident flows | confirm if mappings/references affected |
| Duplicate/copy | new IDs, new safe binding refs | never reuse original BPMN ID |
| Undo/redo | local draft revision | never mutate published/running versions |
| Save / CTRL+S | PUT with ETag | 409/412 conflict opens compare dialog |
| Import BPMN | parse XML, preserve unknown extensions | report unsupported executable nodes; do not drop silently |
| Export BPMN | XML + DI + pinned bindings | no env secrets; stable roundtrip |
| Validate | backend compiler | precise issue bpmnId/path/code + jump-to-node |
| Test | safe DEV harness | fixture/stub vs live explicitly visible |
| Publish | immutable version + control gate | approval/time/version; backend RBAC |
| Add external connector | choose registered operation | no arbitrary URL/SQL editor |

## Error taxonomies

`BPMN_PARSE`, `BPMN_UNSUPPORTED_NODE`, `BPMN_GRAPH`, `BPMN_UNREACHABLE`, `BIND_REQUIRED`, `BIND_TYPE_MISMATCH`, `BIND_FORBIDDEN`, `OPERATION_NOT_APPROVED`, `HOST_MODE_UNSUPPORTED`, `AMIE_RULE_UNAVAILABLE`, `SCHEMA_VERSION_CONFLICT`, `DATA_OWNER_SCOPE`, `APPROVAL_REQUIRED`, `UNSAFE_RETRY`, `EXPIRED_DRAFT`, `REVISION_CONFLICT`, `POLICY_DENIED`.

Every issue includes `{code, severity, bpmnElementId, fieldPath, message, proposedFix}`; warnings do not silently become executable support.
