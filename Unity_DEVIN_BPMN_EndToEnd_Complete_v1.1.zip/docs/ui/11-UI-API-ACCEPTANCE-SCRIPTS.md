# UI 11 - Automated Functional / Visual Acceptance Scripts

Each step references the stable `data-control-id` and backend route in `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. Use Blazor component/bUnit tests (if approved), Playwright E2E, HTTP contract tests and direct worker tests. This is an acceptance plan, not evidence of execution against Unity.

## Scenario UI-E2E-01 - Operation registration and schema-driven use

**Given** trusted CyberArk handler and deployment release fixture; **when** Capability Owner uses ON-01/02/03/04; Reviewer uses ON-05; Operations checks ON-06; Designer opens CAT-02/OP-02/OP-04; **then** typed input fields render from manifest, version pins, and handler can be inserted into BPMN without a new editor component. **Negative:** duplicate key, untrusted publisher, unavailable service, missing permission all deny; direct API 403 also tested.

## Scenario UI-E2E-02 - BPMN drafting and AMIE wiring

**Given** a writable DCMS Draft and approved manifest/rule; **when** Designer creates service task DES-01, rule DES-02, gateway DES-03, connects flows DES-04, binds required input DES-05, saves DES-06, validates DES-07, and previews DES-08; **then** visible graph IDs, DI geometry, typed binding and rule outcomes persist after reload; compiler reports no errors and fixture cannot write to PROD. **Negative:** type mismatch, missing fact, unsupported BPMN, stale ETag, inaccessible rule version; error anchored to node.

## Scenario UI-E2E-03 - Workflow lifecycle and exact release

**Given** valid draft with exact operation/rule versions; **when** author submits LIB-05, independent reviewer approves LIB-06, publishes LIB-07, release operator runs REL-02 and requests UAT REL-03; **then** package digest immutable and target bindings safe. **Negative:** self approval, ticket without real CA, altered package bytes, missing service manifest, developer PROD attempt; REL-05 must remain blocked in wireframe.

## Scenario UI-E2E-04 - User CSV and business progress

**Given** assigned Business User; **when** TRI-03 validates CSV, BUS-01 starts DCMS, BUS-03 refreshes, BUS-04 reads outcome reasons, BUS-05 opens report; **then** staged batch number and row GUIDs are unique, records remain scoped, counts reconcile, final report includes reasons and email result separate from account writes. **Negative:** invalid CSV, duplicate uploaded batch, another user's batch ID, report before terminal, no raw CSV in Kafka.

## Scenario UI-E2E-05 - Operator control and audit

**Given** a running workflow with an in-flight external CyberArk write; **when** Operations opens RUN-05, provides reason and clicks CTL-02, and later CTL-03 or CTL-04; **then** UI shows PauseRequested until safe checkpoint, authoritative state on refresh, and immutable evidence for actor/reason/time/revision. **Negative:** no reason, unauthorized user, concurrent revision, unknown prior write, cancel requested during unsettled write, restart reuses old ID.

## Scenario UI-E2E-06 - Audit and regression

**Given** a test batch and known correlation; **when** Auditor searches AUD-01, inspects AUD-02, exports AUD-03; **then** sequence can be reconstructed, sensitive fields redacted, export event recorded. API regression suite TST-01/02/03 runs isolated tests only; UI test result is not proof that CI ran.

## Browser and accessibility checks

- Every authorized `data-control-id` can be activated by pointer and keyboard; no handler throws JS exception.
- Screen titles, status live region, error summary, confirm modals, focus restoration and text-based diagram status work.
- Navigation grants no additional resource scope. Denied screen should not reveal data when direct API called.
- Resize to 1280x800, 768x1074 and 390x844; major controls remain operable and data table scroll/paginates.
- No secrets in URL/query/body logging, DOM snapshots, downloadable mock results or audit export.
- Check reconnection from disconnected signal: GET authoritative snapshot, no ghost completed state.

## Explicit success evidence for DEVIN PR

Provide screenshots before/after, video only if useful, per-control test pass/fail, API request/response with redaction, CI job URL, contract/schema diff, DB evidence and actual file summary. Do not claim mock images are functional delivery.
