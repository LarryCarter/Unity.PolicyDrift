# UI 09 - User Journeys and Visible State Transitions

This is the design flow specification for DEVIN. Screen/control IDs correspond to `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. The HTML wireframe simulates the interaction; all durable effects require actual APIs.

## Journey A - Register a new CyberArk primitive once, reuse everywhere

| Step | Persona | Page -> click | Required input / check | UI must show |
|---|---|---|---|---|
| 1 | Capability Owner | Onboarding `ON-01` Create manifest draft | capability key, owner, code-release metadata | New Draft identity and version |
| 2 | Capability Owner | `ON-02` Add operation declaration | `CyberArk.FindAccount` key, typed schemas, policy, side effect, transports | Operation in manifest draft, local validation issues |
| 3 | Capability Owner | `ON-03` Validate manifest | handler exists in compiled release, no duplicate key, sample fixtures | Detailed schema/policy/compatibility result |
| 4 | Capability Owner | `ON-04` Submit service evidence | signed/attested build, CI, source release | InReview; cannot self-approve |
| 5 | Reviewer | `ON-05` Approve manifest | independent owner/release checks | Approved; still not automatically Available |
| 6 | Operations | `ON-06` Check readiness | deployed binary/version, health, Kafka ACL, environment binding | Registered vs Available separately |
| 7 | Designer | Catalog `CAT-01` search, `CAT-02` inspect | application scope, exact operation version | Typed inputs and outputs, permission and host |
| 8 | Designer | Operation `OP-04` add | writable workflow draft | BPMN ServiceTask with operationKey@version |
| 9 | Designer | Designer `DES-05` bind, `DES-07` validate | schema-compatible data source | No unresolved required fields |
| 10 | Designer | AMIE `AMI-01`, `AMI-02`, `AMI-03` | rule version, required facts, sanitized fixture | Typed rule decision and output binding |
| 11 | Designer/Reviewer | `DES-09`, `LIB-06`, `LIB-07` | validation, ticket, maker/checker, immutability | Published version/digest, no post-publish editing |
| 12 | Business User | `BUS-01` execute approved workflow | allowed application/input schema | Run ID/correlation, non-technical summary |
| 13 | Designer | Reuse same registered operation in Hygiene | different AMIE rule / workflow | Second application works without new CyberArk handler |

No new manifest should be required for steps 8-13 if the existing operation contract is sufficient. Creating genuinely missing CyberArk behavior still requires a normal code release and security policy.

## Journey B - DCMS configuration through UI

1. Workbench `WB-02` -> App Studio `APP-01`: configure `DCMS`, owner and scope; `APP-02` add approved Data/CyberArk/Reporting/Email dependencies; `APP-03` save.
2. Library `LIB-01`: create Batch + Sequential Rows BPMN draft.
3. Designer `DES-01` add service tasks: stage data, invoke pinned CyberArk embedded subworkflow, report, send email. `DES-02` add AMIE business rule tasks in embedded workflow, `DES-03` configure exclusive gateway, `DES-04` connect paths. Unsupported BPMN elements must yield a semantic error, not run silently.
4. Operation inspector `OP-02` verifies typed fields and side effects. Designer `DES-05` binds `CurrentItem`, prior output and AMIE rule result to operation inputs; `DES-06` saves XML+DI.
5. AMIE `AMI-01` select rule version, `AMI-02` bind required facts (CSV values, account and platform), `AMI-03` preview on fixture, `AMI-04` save binding.
6. Triggers `TRI-01` choose Manual CSV (future API/AutoSys displayed as unavailable), `TRI-02` define columns, `TRI-03` validate safe sample, `TRI-04` save trigger.
7. Kafka Contracts `KAF-01` inspect command/outcome schema, `KAF-02` verify correlation/idempotency; Environment Bindings `ENV-01/03` confirm allowed DEV topic/endpoint/secret references, never values.
8. Designer `DES-07` validates BPMN, AMIE, contracts and permissions; `DES-08` previews fixture; `DES-09` submits. Library `LIB-06/07` approves/publishes only after back-end evidence.
9. Release `REL-01/02` checks digest, tests, binding, ServiceNow evidence; `REL-03` requests controlled UAT. `REL-05` PROD activation must be actually denied in wireframe and cannot be assumed approved in real code.
10. Business `BUS-01` uploads approved CSV/starts batch. Data stage creates one batch number and unique GUID per row; central BOB sends Kafka command. Embedded BOB/AMIE process rows sequentially and persist actual outcomes. `BUS-03/04/05` show status/reasons/report, `BUS-07` opens technical monitor only for authorized role. Audit `AUD-01/02` reconstructs decisions, operations and change references.

## Journey C - Business user with minimal technical privileges

- On Workbench `WB-03` open My Work; Business `BUS-01` starts approved request only for owned app; `BUS-02/03` select and refresh batch; `BUS-04` read row failures with safe reason codes; `BUS-05` access report only when prepared.
- `BUS-07` technical monitor is not available unless an explicit additional role is granted. User never sees raw account passwords, broker topic internals, API authorization tokens or other batches.
- Distinguish `Pending/InProgress` from terminal `Succeeded/NoChange/Skipped/Rejected/Failed`. Unknown external outcome is not success and cannot be counted as a confirmed completed update.

## Journey D - Operator handling an in-flight CyberArk write

1. Operations opens Run Monitor `RUN-01` and `RUN-02` to inspect current task/evidence; `RUN-05` opens controls.
2. Operator selects a running run `CTL-01`, enters reason, clicks `CTL-02 Pause` with expected revision.
3. API returns 202/accepted and UI shows `PauseRequested`; **do not show Paused** until durable checkpoint reached. If write is still in flight, external outcome must be confirmed or reconciled first.
4. Run Monitor `RUN-04` refresh/push eventually shows `Paused` and exact waiting activity.
5. Operator reviews `RB-02` runbook, then `CTL-03 Resume` with reason and new revision. UI shows Running only after backend confirms.
6. For Failed external write, `CTL-05 Retry` is permitted only if prior outcome is known or reconciliation has completed; otherwise deny with `RECONCILIATION_REQUIRED`.
7. For Cancel `CTL-04`, UI shows CancelRequested while in-flight work settles. Restart `CTL-06` creates a **new RunId** and links original history, no deletion.
8. Audit `AUD-01/02` must show each control action, actor, reason, expected revision, result and UTC time.

## Journey E - Operations-only production promotion

1. Reviewer/Operations chooses exact candidate `REL-01` and checks manifest/rule/operation lock/digest.
2. `REL-02` preflight checks real controls/CA requirements, signed artifact, tests, UAT digest, service health and logical bindings; **a typed change ticket is not approval**.
3. Authorized Release Operator `REL-03` promotes identical artifact to UAT and records approver/evidence.
4. On PROD, `REL-05` is authorized only if server-side bank policy passes and Operations identity is allowed. This mock ALWAYS blocks it.
5. Rollback `REL-06` selects previously approved package **for new runs**; previous CyberArk writes are not undone.

## State machines used by the UI

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> InReview: Submit (valid + ticket)
  InReview --> Approved: Independent review
  Approved --> Published: Immutable package
  Published --> Active: Operations activates
  Active --> Retired: Retire for new runs
  Published --> Retired
  InReview --> Draft: Request changes
```

```mermaid
stateDiagram-v2
  [*] --> Running
  Running --> PauseRequested: Pause API accepted
  PauseRequested --> Paused: Safe checkpoint confirmed
  Paused --> Running: Resume confirmed
  Running --> CancelRequested: Cancel API accepted
  Paused --> CancelRequested: Cancel API accepted
  CancelRequested --> Cancelled: Known/settled state
  Running --> Failed
  Running --> Completed
  Failed --> Running: Safe retry after reconciliation
  Failed --> RestartedLink: New run with distinct ID
  Cancelled --> RestartedLink: New run with distinct ID
  Completed --> RestartedLink: New run with distinct ID
```

## User-visible error policy

- Permission denied: show requested action not authorized, no sensitive resource names. Log denial; direct API 403 test required.
- Validation error: show field/node ID, code and remediation; preserve unsaved draft.
- Revision conflict: show server and local revision, offer controlled reload/diff; never silently overwrite.
- Request accepted/pending: show pending with correlation; do not treat transport acknowledgement as side-effect success.
- Dependency unavailable: show exact logical dependency/version/health with no secret values, block publish or execution as applicable.
- Unknown external outcome: preserve visible reconciliation-required state, never count as success or restart blindly.
