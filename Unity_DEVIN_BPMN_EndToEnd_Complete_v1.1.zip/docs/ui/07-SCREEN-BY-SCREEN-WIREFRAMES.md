# UI 07 - BE Screen-by-Screen Wireframe Specification

> Canonical interaction source: `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. This specification is a **proposal grounded in v0.9 architecture**, not evidence that the Blazor app implements these screens.

## Global UI shell and behavior

```text
+--------------------------------------------------------------------------+
| UNITY BE     Application [scope]    Environment [DEV/UAT/PROD]   [role]   |
+---------------------+----------------------------------------------------+
| Workbench           | Breadcrumb / page title / status of last fetch    |
| Registry            | Contextual actions and global validation/errors   |
| Onboarding          | ------------------------------------------------  |
| Studio / Library    | Search/list / visual work surface / detail panel  |
| BOB / AMIE          | (responsive, role-filtered, keyboard accessible)  |
| Delivery / Release  |                                                    |
| Business / Monitor  | Persistent save/review state, correlation footer  |
| Ops / Audit / Tests |                                                    |
+---------------------+----------------------------------------------------+
```

Navigation is a route change, not a security privilege. The API decides which pages and records can be read. Data refresh must preserve selection and filters; auth denial must be distinct from no matching records. In wireframe, role selector is only a simulated persona selector.

## Shared rules

- Every visible action has a stable control ID in the click catalog; no inert production buttons.
- Every mutating action uses backend API, role and resource-scope verification, expected revision/ETag, and correlation ID.
- Buttons showing `202 Accepted` must display Pending until server-confirmed completion.
- Destructive/high-impact controls require reason and review/runbook gate; no side effects in the standalone prototype.
- Draft editors show Unsaved changes, Validation errors (anchored to BPMN node/field), save revision, and pinned dependency versions.
- Form generation uses operation/rule JSON schemas. Sensitive fields use protected server references, never values in browser.
- UI success toasts are informative, not proof of durable writes. The actual backend state is authoritative.
- All data-heavy tables use server-side pagination, empty state and row-level scope filtering.

## Screen layouts and interactions

### workbench: Unity Workbench

**Purpose:** Find assigned applications, actions and runs

**Layout:** Summary tiles + recent executions + pinned applications; launch actions at upper right.

**Data contract:** `GET /api/v1/me/dashboard`

**Inputs:** application selector; favorite filter

**Roles:** All authenticated users

**Empty state:** No applications in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| WB-01 | Browse capabilities | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/capabilities` | Open registry scoped to current role |
| WB-02 | Open Application Studio | Designer,Reviewer,Operations | `GET /api/v1/applications` | Open assigned application configurations |
| WB-03 | My work | All authenticated users | `GET /api/v1/batches?scope=mine` | Open authorized batch list |
| WB-04 | Refresh status | All authenticated users | `GET /api/v1/me/dashboard` | Reload counts and last-updated time |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### catalog: Capability Registry

**Purpose:** Discover approved operations and service health

**Layout:** Left capability filter + middle operation table + right readiness summary.

**Data contract:** `GET /api/v1/capabilities; GET /api/v1/operations`

**Inputs:** search query; capability filter; availability filter

**Roles:** Designer,Capability Owner,Operations,Auditor

**Empty state:** No operations available in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| CAT-01 | Search / filter | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/capabilities?q=&status=` | Table is filtered without altering registry |
| CAT-02 | Inspect operation | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/operations/{key}/versions/{version}` | Open descriptor inspector at exact contract version |
| CAT-03 | Use in workflow | Designer | `POST /api/v1/workflow-drafts/{id}/activities` | Insert bound service task with stable key/version |
| CAT-04 | Refresh health | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/capabilities/{key}/readiness` | Fetch current readiness and compatibility |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### operation: Operation Inspector

**Purpose:** Inspect versioned schema and prepare reusable binding

**Layout:** Operation key/version title + contract tabs (Inputs, Outputs, Permissions, Messages, AMIE, Tests) + bind action.

**Data contract:** `GET /api/v1/operations/{key}/versions/{version}`

**Inputs:** operation selector; contract version; test fixture

**Roles:** Designer,Capability Owner,Operations,Auditor

**Empty state:** Operation removed or not in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| OP-01 | Back to Registry | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/capabilities` | Return to same catalog filters |
| OP-02 | View input/output schemas | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/operations/{key}/schemas` | Show required inputs, outputs, permissions and side effects |
| OP-03 | Test with DEV fixture | Capability Owner,Designer | `POST /api/v1/operation-tests/{key}/execute` | Non-PROD fixture result with reason/correlation shown |
| OP-04 | Add to BOB workflow | Designer | `POST /api/v1/workflow-drafts/{id}/activities` | Append service task using selected descriptor |
| OP-06 | Download contract manifest | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/operations/{key}/manifest` | Download approved manifest with schema refs but no secrets |
| OP-05 | Request missing primitive | Designer,Capability Owner | `POST /api/v1/operation-development-requests` | Generate typed DEVIN operation request, not code execution |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### onboarding: Capability Onboarding

**Purpose:** Review and publish typed compiled operations

**Layout:** Manifest wizard: service identity -> operations -> schemas/policy -> validation -> release evidence.

**Data contract:** `GET /api/v1/capability-manifests/drafts`

**Inputs:** capability key; operation key; owner; input schema ref; permission; side effect

**Roles:** Capability Owner,Reviewer,Operations

**Empty state:** No manifest drafts. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| ON-01 | Create manifest draft | Capability Owner | `POST /api/v1/capability-manifests/drafts` | Create local metadata draft; no executable registration yet |
| ON-02 | Add operation declaration | Capability Owner | `POST /api/v1/capability-manifests/drafts/{id}/operations` | Attach typed operation metadata to draft |
| ON-03 | Validate manifest | Capability Owner,Reviewer | `POST /api/v1/capability-manifests/drafts/{id}/validate` | Display schema/security/version checks |
| ON-04 | Submit service release evidence | Capability Owner | `POST /api/v1/capability-manifests/drafts/{id}/submit` | Send draft for privileged review, not auto-approve |
| ON-05 | Approve registry publication | Reviewer | `POST /api/v1/capability-manifests/{id}/approve` | Approve compatible manifest; no auto handler creation |
| ON-06 | Check deployed readiness | Capability Owner,Reviewer,Operations | `GET /api/v1/capability-manifests/{id}/readiness` | Show registered vs actually available separately |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### apps: Application Studio

**Purpose:** Compose application from workflows/capabilities

**Layout:** Application header and tabs: modules, capability deps, workflow, scopes, env refs.

**Data contract:** `GET /api/v1/applications`

**Inputs:** application name; owner; scope; selected modules

**Roles:** Designer,Reviewer,Operations

**Empty state:** No assigned applications. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| APP-01 | Create application draft | Designer | `POST /api/v1/applications` | New app blueprint with owner and scope |
| APP-02 | Add capability dependency | Designer | `POST /api/v1/applications/{id}/capabilities` | Add stable approved contract dependency |
| APP-03 | Save configuration | Designer | `PUT /api/v1/applications/{id}/draft` | Persist revision and ETag |
| APP-05 | Select application module | Designer,Reviewer,Operations | `GET /api/v1/applications/{id}/modules/{key}` | Switch composition tab with selected workflow and capability dependencies |
| APP-04 | Open workflow library | Designer,Reviewer,Operations | `GET /api/v1/workflow-definitions?application=` | Show workflows for selected app |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### library: Workflow Library

**Purpose:** Manage immutable definitions and lifecycle

**Layout:** Filter bar + definition/version table + lifecycle timeline and diff inspector.

**Data contract:** `GET /api/v1/workflow-definitions`

**Inputs:** search; application; lifecycle filter; selected definition

**Roles:** Designer,Reviewer,Operations,Auditor

**Empty state:** No definitions in filter. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| LIB-01 | New draft from template | Designer | `POST /api/v1/workflow-drafts` | Create draft and initial BPMN IDs |
| LIB-02 | Open selected version | Designer,Reviewer,Operations,Auditor | `GET /api/v1/workflow-definitions/{key}/versions/{version}` | Open editor if draft or read-only if published |
| LIB-03 | Compare versions | Designer,Reviewer,Operations,Auditor | `GET /api/v1/workflow-definitions/{key}/diff?from=&to=` | Show BPMN/rules/contracts/change diff |
| LIB-04 | Clone as new draft | Designer | `POST /api/v1/workflow-definitions/{key}/clone` | New editable version referencing parent |
| LIB-05 | Submit for review | Designer | `POST /api/v1/workflow-drafts/{id}/review` | Draft moves to InReview with ticket and evidence |
| LIB-06 | Approve version | Reviewer | `POST /api/v1/workflow-reviews/{id}/approve` | Independently approve candidate |
| LIB-07 | Publish immutable version | Reviewer | `POST /api/v1/workflow-definitions/{key}/publish` | Published with digest and pinned dependencies |
| LIB-08 | Retire selected version | Operations | `POST /api/v1/workflow-definitions/{key}/retire` | Prevent new runs but retain evidence |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### designer: BOB BPMN Designer

**Purpose:** Edit standard BPMN and type-safe Unity bindings

**Layout:** 3-column work surface: BPMN palette | SVG canvas | typed node inspector; issue panel below.

**Data contract:** `GET/PUT /api/v1/workflow-drafts/{id}/bpmn`

**Inputs:** node selection; operation; input binding; rule; host; flow path

**Roles:** Designer,Reviewer,Operations

**Empty state:** Empty BPMN canvas with Start and End. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| DES-01 | Add service task | Designer | `POST /api/v1/workflow-drafts/{id}/activities` | New BPMN service task with stable node ID |
| DES-02 | Add business rule task | Designer | `POST /api/v1/workflow-drafts/{id}/activities` | New BPMN business-rule task |
| DES-03 | Add exclusive gateway | Designer | `POST /api/v1/workflow-drafts/{id}/elements` | BPMN XOR gateway with branch conditions |
| DES-04 | Connect selected nodes | Designer | `PUT /api/v1/workflow-drafts/{id}/bpmn` | Directed sequence flow with new ID |
| DES-05 | Bind selected task input | Designer | `PUT /api/v1/workflow-drafts/{id}/bindings` | Typed mapping to input/current row/prior output |
| DES-06 | Save draft | Designer | `PUT /api/v1/workflow-drafts/{id}` | Persist BPMN XML + DI + inspector data with ETag |
| DES-07 | Validate BPMN and contracts | Designer,Reviewer | `POST /api/v1/workflow-drafts/{id}/validate` | Highlight node errors and publish readiness |
| DES-08 | Preview safe execution | Designer | `POST /api/v1/workflow-drafts/{id}/simulate` | DEV fixture preview with explicit mock label |
| DES-09 | Submit workflow review | Designer | `POST /api/v1/workflow-drafts/{id}/review` | Submit validated draft to reviewer |
| DES-10 | Import BPMN XML | Designer | `POST /api/v1/workflow-drafts/{id}/import` | Parse BPMN XML + DI and show unsupported elements |
| DES-11 | Export BPMN XML | Designer,Reviewer,Operations | `GET /api/v1/workflow-drafts/{id}/export` | Download BPMN 2.0 XML with DI/extension refs |
| DES-12 | Undo edit | Designer | `local editor; persist on Save` | Revert most recent uncommitted canvas edit |
| DES-14 | Switch central / embedded workflow | Designer,Reviewer,Operations | `GET /api/v1/workflow-definitions/{key}/execution-contexts` | Change designer context, loading pinned central or CyberArk embedded subworkflow |
| DES-13 | Redo edit | Designer | `local editor; persist on Save` | Reapply reverted canvas edit |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### amie: AMIE Rule Picker and Binding

**Purpose:** Reuse existing typed rules without rebuilding AMIE

**Layout:** Rule version list + required facts picker + decision preview and validation errors.

**Data contract:** `GET /api/v1/amie/rules`

**Inputs:** rule key/version; fact binding; output binding; safe fixture

**Roles:** Designer,Rule Maintainer,Reviewer

**Empty state:** No compatible AMIE rules. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| AMI-01 | Select rule version | Designer,Rule Maintainer,Reviewer | `GET /api/v1/amie/rules/{key}/versions/{version}` | Show required facts/decision types |
| AMI-02 | Map required facts | Designer,Rule Maintainer | `PUT /api/v1/workflow-drafts/{id}/rule-bindings` | Bind typed input facts and output references |
| AMI-03 | Preview rule with fixture | Designer,Rule Maintainer | `POST /api/v1/amie/rules/{key}/preview` | Existing AMIE evaluator returns typed safe result |
| AMI-04 | Save rule binding | Designer,Rule Maintainer | `PUT /api/v1/workflow-drafts/{id}/rule-bindings` | Persist pinned rule version and ETag |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### triggers: Triggers and Forms

**Purpose:** Declare validated manual/API/schedule inputs

**Layout:** Trigger type selector + generated form schema editor + CSV validation panel.

**Data contract:** `GET /api/v1/triggers`

**Inputs:** trigger type; CSV input; required column schema; application scope

**Roles:** Designer,Business User,Operations

**Empty state:** No configured trigger. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| TRI-01 | Choose trigger type | Designer,Operations | `GET /api/v1/triggers/types` | Display manual CSV/API/schedule capabilities and readiness |
| TRI-02 | Add required input field | Designer | `PUT /api/v1/workflow-drafts/{id}/trigger-schema` | New typed schema field for BE form |
| TRI-03 | Validate sample CSV | Designer,Business User | `POST /api/v1/ingestion/validate` | Return schema/row errors, no live write |
| TRI-04 | Save trigger mapping | Designer | `PUT /api/v1/workflow-drafts/{id}/trigger` | Persist trigger schema and source adapter ref |
| TRI-05 | Open business start form | Business User,Designer | `GET /api/v1/workflows/{key}/start-form` | Open role-scoped start UI |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### contracts: Kafka Contract Explorer

**Purpose:** Inspect logical message contracts and mappings

**Layout:** Message list + envelope schema and producer/consumer/ACL inspector.

**Data contract:** `GET /api/v1/messaging/contracts`

**Inputs:** message search; schema version; logical topic

**Roles:** Designer,Capability Owner,Operations,Auditor

**Empty state:** No declared messages. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| KAF-01 | Inspect message schema | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/messaging/contracts/{key}` | Show producer/consumer/required fields/versions |
| KAF-02 | Validate correlation envelope | Designer,Capability Owner,Operations | `POST /api/v1/messaging/contracts/validate` | Check commandId/runId/activityId/idempotency/partition |
| KAF-03 | Check environment bindings | Designer,Capability Owner,Operations | `GET /api/v1/environment-bindings` | Show approved logical-to-physical resolutions |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### bindings: Environment Bindings

**Purpose:** Resolve approved logical endpoint/topic/secret references

**Layout:** Environment selector + logical ref table + redacted target/health panel.

**Data contract:** `GET /api/v1/environment-bindings`

**Inputs:** environment DEV/UAT/PROD; selected logical reference

**Roles:** Designer,Operations,Release Operator,Auditor

**Empty state:** No approved bindings. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| ENV-01 | Select target environment | Designer,Operations,Release Operator,Auditor | `GET /api/v1/environment-bindings?env=` | Show redacted refs for selected environment |
| ENV-02 | Inspect binding dependency | Designer,Operations,Release Operator,Auditor | `GET /api/v1/environment-bindings/{key}` | Show reference/type/version/owner not secret value |
| ENV-03 | Validate readiness | Operations,Release Operator | `POST /api/v1/environment-bindings/validate` | Report unresolved refs, ACL/health incompatibility |
| ENV-04 | Request binding change | Operations | `POST /api/v1/environment-bindings/change-requests` | Create controlled binding change request |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### releases: Release Center

**Purpose:** Review signed package and operations-controlled promotion

**Layout:** Package overview + dependency/preflight checklist + approvals + Ops-only gated actions.

**Data contract:** `GET /api/v1/releases`

**Inputs:** candidate version; target environment; change ticket; approval refs

**Roles:** Reviewer,Operations,Release Operator,Auditor

**Empty state:** No release candidates. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| REL-01 | Inspect candidate digest | Reviewer,Operations,Release Operator,Auditor | `GET /api/v1/releases/{id}` | Show diff, exact package digest and pinned deps |
| REL-02 | Run preflight | Reviewer,Operations,Release Operator | `POST /api/v1/releases/{id}/preflight` | Show signed evidence, approvals, bindings, health and tests |
| REL-03 | Request UAT promotion | Release Operator | `POST /api/v1/releases/{id}/promote?target=UAT` | Stage exact digest for approved UAT pipeline |
| REL-04 | Inspect approvals | Reviewer,Operations,Release Operator,Auditor | `GET /api/v1/releases/{id}/approvals` | Show authoritative approval evidence, not ticket string only |
| REL-05 | Activate PROD (gated) | Release Operator | `POST /api/v1/releases/{id}/activate?target=PROD` | Only real backend controls can authorize; demo always blocked |
| REL-07 | Build immutable release candidate | Reviewer,Operations | `POST /api/v1/releases/candidates` | Bundle published BPMN, AMIE and operation lock into signed candidate digest |
| REL-06 | Rollback for NEW runs (gated) | Release Operator | `POST /api/v1/releases/{id}/rollback` | Select previously approved digest for future runs only |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### business: Business Work Queue

**Purpose:** User-scoped batch counts and outcome reports

**Layout:** My batches table + summary counters + progress + paged row reasons and report.

**Data contract:** `GET /api/v1/batches?scope=mine`

**Inputs:** batch selection; CSV fixture; status filter

**Roles:** Business User,Designer,Operations,Auditor

**Empty state:** No authorized batches. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| BUS-01 | Start CSV request (mock) | Business User,Designer | `POST /api/v1/workflows/DCMS.Batch/runs` | Create mock batch with batch number, row GUIDs and queued state |
| BUS-02 | Select batch | Business User,Designer,Operations,Auditor | `GET /api/v1/batches/{id}/summary` | Show selected batch counts by status |
| BUS-03 | Refresh progress | Business User,Designer,Operations,Auditor | `GET /api/v1/batches/{id}/summary` | Refresh from source; show last-updated timestamp |
| BUS-04 | View outcome reasons | Business User,Designer,Operations,Auditor | `GET /api/v1/batches/{id}/rows` | Show paged per-row reason codes with classification mask |
| BUS-05 | Open report | Business User,Designer,Operations,Auditor | `GET /api/v1/batches/{id}/reports` | Show generated secure report refs only when terminal |
| BUS-06 | Advance fixture 5 rows | Business User,Designer,Operations | `mock only (no production API)` | Advance simulated queue safely and counts reconcile |
| BUS-07 | Technical run (authorized) | Operations,Designer,Auditor | `GET /api/v1/runs/{runId}` | Open BPMN overlay and correlation evidence |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### runs: BPMN Run Monitor

**Purpose:** Near-real-time task overlay and correlated timeline

**Layout:** Version-pinned BPMN overlay + activity inspector + correlated event timeline.

**Data contract:** `GET /api/v1/runs/{id}; GET /api/v1/runs/{id}/events`

**Inputs:** run selector; event filter; activity ID

**Roles:** Operations,Designer,Auditor

**Empty state:** No run in permitted scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| RUN-01 | Choose run | Operations,Designer,Auditor | `GET /api/v1/runs/{id}` | Load pinned BPMN version and activity states |
| RUN-02 | Inspect activity | Operations,Designer,Auditor | `GET /api/v1/runs/{id}/activities/{activityId}` | Show task inputs redacted, handler/rule/correlation/outcome |
| RUN-03 | Filter event timeline | Operations,Designer,Auditor | `GET /api/v1/runs/{id}/events?type=` | Filter event types while preserving sequence |
| RUN-04 | Refresh now | Operations,Designer,Auditor | `GET /api/v1/runs/{id}/events?after=` | Query authoritative state after push/reconnect |
| RUN-05 | Open Operator Console | Operations | `GET /api/v1/runs/{id}/controls` | Show authorized state transitions |
| RUN-07 | Inspect correlated Kafka event | Operations,Designer,Auditor | `GET /api/v1/runs/{id}/events/{eventId}` | Show command/outcome envelope metadata, message IDs and safe result |
| RUN-06 | Open audit history | Operations,Designer,Auditor | `GET /api/v1/audit?runId=` | Open filtered immutable evidence |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### operators: Operator Console

**Purpose:** Privileged checkpoint-safe process controls

**Layout:** Selected run/status + allowed transition controls + reason/runbook + status feedback.

**Data contract:** `GET /api/v1/runs/{id}/controls`

**Inputs:** run selector; reason; expected run revision

**Roles:** Operations

**Empty state:** No operable runs. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| CTL-01 | Select run | Operations | `GET /api/v1/runs/{id}/controls` | Show current state, revision and allowed actions |
| CTL-02 | Pause | Operations | `POST /api/v1/runs/{id}/pause` | Running -> PauseRequested -> Paused at safe checkpoint |
| CTL-03 | Resume | Operations | `POST /api/v1/runs/{id}/resume` | Paused -> Running, pins checked |
| CTL-04 | Cancel | Operations | `POST /api/v1/runs/{id}/cancel` | Request cooperative cancellation with linked evidence |
| CTL-05 | Retry failed step | Operations | `POST /api/v1/runs/{id}/retry` | Reconcile before retry; increment attempt |
| CTL-06 | Restart as new run | Operations | `POST /api/v1/runs/{id}/restart` | New linked run ID; old run remains intact |
| CTL-07 | Read controlling runbook | Operations | `GET /api/v1/runbooks/by-run/{id}` | Open procedures and control owner |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### runbooks: Controls and Runbooks

**Purpose:** Read operational procedures and evidence requirements

**Layout:** Control/runbook list + versioned procedure + evidence and acknowledgement.

**Data contract:** `GET /api/v1/runbooks`

**Inputs:** runbook selection; control ID; version

**Roles:** Operations,Auditor,Reviewer

**Empty state:** No runbooks assigned. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| RB-01 | Select runbook | Operations,Auditor,Reviewer | `GET /api/v1/runbooks/{id}/versions/{v}` | Open read-only procedure and version |
| RB-02 | View procedure and exceptions | Operations,Auditor,Reviewer | `GET /api/v1/runbooks/{id}` | Show what to do, when to stop, escalation, owner |
| RB-03 | Acknowledge procedure | Operations | `POST /api/v1/runbooks/{id}/ack` | Record operator acknowledgement when required |
| RB-04 | View related control evidence | Operations,Auditor,Reviewer | `GET /api/v1/audit?controlId=` | Open control-specific audit events |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### access: Role and Scope Policies

**Purpose:** View permissions and test actual denial paths

**Layout:** Role-by-action matrix + scope filter + denial test record.

**Data contract:** `GET /api/v1/access/policies`

**Inputs:** selected application; permission query

**Roles:** Operations,Reviewer,Auditor

**Empty state:** No policies in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| ACC-01 | Inspect role-policy matrix | Operations,Reviewer,Auditor | `GET /api/v1/access/policies` | Show action, role, scope, separation requirements |
| ACC-02 | Test denied API fixture | Operations,Reviewer | `POST /api/v1/test/authorization/denial` | Show isolated negative API test contract |
| ACC-03 | Request policy change | Operations | `POST /api/v1/access/change-requests` | Open controlled policy change request |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### audit: Audit and Traceability

**Purpose:** Reconstruct what ran and who changed it

**Layout:** Filter/search bar + immutable chronological event list + safe detail/export.

**Data contract:** `GET /api/v1/audit`

**Inputs:** runId; batchId; changeId; actor; timeframe

**Roles:** Operations,Auditor,Reviewer

**Empty state:** No events in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| AUD-01 | Search evidence | Operations,Auditor,Reviewer | `GET /api/v1/audit?run=&batch=&change=` | Filtered append-only timeline, stable order |
| AUD-02 | Inspect event detail | Operations,Auditor,Reviewer | `GET /api/v1/audit/{eventId}` | Show actor, versions, UTC, correlation, safe result |
| AUD-03 | Export scoped evidence (mock) | Auditor | `POST /api/v1/audit/exports` | Create redacted, traceable export request |
| AUD-04 | Follow run correlation | Operations,Auditor | `GET /api/v1/runs/{id}` | Open technical run view at matching correlation |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### apitests: API Functional Regression

**Purpose:** Plan and review API-first test gates

**Layout:** Suite selector + regression cases + environment gate + evidence/result panel.

**Data contract:** `GET /api/v1/regression/suites`

**Inputs:** suite selector; environment; fixture

**Roles:** Designer,Capability Owner,Operations,Reviewer,Auditor

**Empty state:** No test suites available. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| TST-01 | Select suite | Designer,Capability Owner,Operations,Reviewer,Auditor | `GET /api/v1/regression/suites/{id}` | Show cases and required environment/fixture |
| TST-02 | Preview test plan | Designer,Capability Owner,Operations,Reviewer,Auditor | `GET /api/v1/regression/suites/{id}/cases` | Show positive, denied, failure injection cases |
| TST-03 | Run mock fixture test | Designer,Capability Owner,Operations | `POST /api/v1/regression/runs (nonprod only)` | Simulate test results with explicit MOCK marker |
| TST-04 | Inspect failed case | Designer,Capability Owner,Operations,Reviewer,Auditor | `GET /api/v1/regression/runs/{id}/cases/{caseId}` | Show assertion, expected and actual, evidence ref |
| TST-05 | Open DEVIN job index | Designer,Capability Owner,Operations,Reviewer,Auditor | `local docs/jobs/INDEX.md` | Show relevant workstream and acceptance mapping |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

