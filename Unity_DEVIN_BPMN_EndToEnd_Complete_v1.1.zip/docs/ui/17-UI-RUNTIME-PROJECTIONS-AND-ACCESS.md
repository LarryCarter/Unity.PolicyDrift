# UI 17 - BE Runtime Projections, State, Security and Operational Monitoring

## User perspectives

- **Business submitter:** upload CSV/start approved run; see batch ID, counts, ETA only if measured, row reasons and report; no need to know BPMN internals.
- **Workflow author:** create/test draft and inspect source-compatible operations/rules; no PROD execution permission merely from design rights.
- **Operations:** authorized run controls, runbook and ServiceNow change association; can see operational errors and correlation; no arbitrary rule edits.
- **Auditor/control owner:** immutable version graph, actor, rule decision, external side effect, change ticket, UTC timestamps, history reassembly, export with classification.
- **Platform engineer:** capability health/contracts, Kafka DLQ/outbox, BOB instances, AMIE versions; support trace under separation of duties.

## State projections (separate write/read models)

| Projection | Source events/data | Audience | Refresh | Security |
|---|---|---|---|---|
| `BusinessBatchSummary` | staged row results + workflow status | batch owner | on record outcome / periodic aggregation | own app/batch scope |
| `BusinessRowDetail` | row GUID, validation/write outcome, reason | submitter/support | page on request | classified fields masked |
| `BpmnRunSnapshot` | BOB durable token/checkpoint | runtime viewer | event-driven + resume GET | technical runtime scope |
| `RunTimeline` | BOB, Kafka, AMIE, capability evidence | operator/auditor | append query/SSE hint | redacted by policy |
| `ReleaseReadiness` | signed digest and approvals | author/release operator | after gate check | no prod secrets |
| `OperationalControl` | runbook version, operator reason and command result | operations/audit | append on action | immutable evidence |

## Publish/update protocol

1. Authorized API receives request, verifies app scope and data owner, writes business state and outbox atomically (where same transaction feasible).
2. Outbox publishes logical business progress event; projection worker updates read model or cache and emits notification with sequence number.
3. BE server delivers authorized SignalR/SSE message containing `{runId,batchId,revision,changedFields}` not raw account data.
4. Browser applies monotonic sequence updates; if gap/reconnect occurs, fetch snapshot with ETag; never trust UI count as source of truth.
5. Business user filters by own batch. Runtime viewer may open technical BPMN overlay. Auditor sees append-only events, not raw Kafka payloads.

## Run operator state machine

```mermaid
stateDiagram-v2
    [*] --> Created
    Created --> Running
    Running --> PauseRequested
    PauseRequested --> Paused: safe checkpoint
    PauseRequested --> Running: request denied or rolled back
    Paused --> Running: resume authorized
    Running --> CancelRequested
    Paused --> CancelRequested
    CancelRequested --> Cancelled: cooperative checkpoint
    Running --> Completed
    Running --> Failed
    Failed --> Restarted: new linked run
    Cancelled --> Restarted: new linked run
    Restarted --> Running
```

- Pause/cancel does not revoke a request already sent to CyberArk. Run detail must show `InFlightExternalWrite` and any `OutcomeUnknown` state.
- Restart must never resurrect an uncertain external write without reconciliation. New run IDs link back to original with runbook decision, actor and UTC time.
- User tasks/approvals must be real durable waits if implemented; no one-click UI-only approval simulating BPMN task completion.

## Security and audit controls

Backend enforcement includes SSO groups, application scope, role+operation permission, acting service identity, data classification, operation side-effect level, runbook, change management, UAT/PROD separation, and redaction. Every code change or configuration publication includes actor/version/time, ServiceNow change ID as appropriate, verified review approval (not only ticket string). Do not store secret values in BPMN XML, Kafka payloads, audit row, preview or browser logs.

## Required error UI

- Blocked publication: list exact BPMN node/error with link and remedy. No vague "invalid workflow".
- Backend permission failure: 403 with safe message + correlation, not 404 exposing existence across scopes.
- Kafka timeout/delivery uncertainty: show `PendingOutcome` / `AwaitingReconciliation`; do not mark succeeded.
- AutoSys duplicate source run ID: show existing workflow run link rather than creating second run.
- NAS API unavailable: show read-only retry/reconcile instruction, no direct SQL fallback from BE.
- Missing AMIE rule version: disable executable publish; view-only historic version remains viewable.

## Regression gates

1. 2 users own different batches: no cross-scope row/audit leakage.
2. 2 simultaneous draft editors: ETag conflict, no lost updates.
3. 1 worker crashes after CyberArk write but before completion: unknown outcome, reconciliation gate.
4. Client disconnect/reconnect during 250-row batch: counters fetched from authoritative API.
5. Repeat AutoSys trigger with same job/sourceRunId: one workflow run, both acknowledgments resolve consistently.
6. Auditor exports event history: row GUID, rule versions, operation outcome, actor UTC and change ticket appear with proper masking.
