# UI 13 - End-to-End BPMN Workflow Authoring Journey

**Status:** Proposed implementation contract for DEVIN; retain v1.0 contracts, do not invent completed source code. **Deadline:** November 30, 2026 DEV demo; bank release approvals are separate.

## Objectives and non-goals

A Business Enablement (BE) user must create, configure, validate, test, version, publish and observe a reusable BPMN 2.0 workflow without programming a new application. Approved CyberArk, NAS/Data, Reporting, Email and scheduling operations are discovered through typed capability manifests. AMIE rules add configured decisions and mappings. BOB executes the BPMN definition via shared core in embedded/central hosts. Kafka only crosses relevant service boundaries. The browser never contacts Kafka, SQL or CyberArk directly.

**Not an MVP requirement:** execute the full BPMN 2.0 surface, arbitrary code editor, in-flight migration, dynamic SQL, dynamic arbitrary HTTP, a new unapproved commercial design library, real PROD activation from a prototype.

## End-to-end path

```mermaid
flowchart LR
  S1[Select Application] --> S2[Create Workflow Draft]
  S2 --> S3[Choose Trigger and Input Contract]
  S3 --> S4[Browse Approved Capability Operations]
  S4 --> S5[Draw BPMN Process]
  S5 --> S6[Bind Data and AMIE Rules]
  S6 --> S7[Validate and Test]
  S7 -->|Errors| S5
  S7 -->|Pass| S8[Review and Publish Version]
  S8 --> S9[Bind Environments and Approvals]
  S9 --> S10[Initiate or Schedule]
  S10 --> S11[Business Dashboard + BPMN Monitor]
  S11 --> S12[Report + Audit + Runbook]
```

## Screen-by-screen navigation map

| Screen/route (proposed) | User intent | Key controls | Backend read/write | Next step |
|---|---|---|---|---|
| U01 Workbench `/be` | Find owned apps/jobs | app selector, status cards, create | GET `/applications`, `/summary` | U02/U14 |
| U02 Application Studio `/be/apps/{app}` | Scope business package | add dependency, owner, role, launch workflow | GET/PUT `/applications/{id}` | U03 |
| U03 Workflow Library `/be/workflows` | Templates, versions, lifecycle | create, clone, compare, retire | GET/POST `/workflows`, GET `/versions` | U04 |
| U04 New Workflow Wizard `/be/workflows/new` | Define title, ownership, scope | 4-step wizard, cancel, create | POST `/workflows/drafts` | U05 |
| U05 Trigger Designer `/be/workflows/{id}/triggers` | Manual CSV, form, API, AutoSys adapter, Kafka | type cards, schema picker, preview test | GET `/trigger-types`; PUT `/drafts/{id}/trigger` | U06 |
| U06 Data Sources `/be/workflows/{id}/data` | NAS API, staging, outputs | source selector, schema, policy scope, preview | GET `/capabilities`, `/schemas`, `/bindings` | U07 |
| U07 Capability Catalog `/be/capabilities` | Discover approved operations | search, filter, status, version | GET `/capabilities` + `/operations` | U08 |
| U08 Operation Inspector `/be/operations/{key}` | Understand handler | inputs, outputs, permissions, host, side effects | GET `/operations/{key}/versions/{ver}` | U09 |
| U09 BPMN Designer `/be/workflows/{id}/design` | Model process and subprocesses | palette, canvas, undo/redo, connect, inspector | GET/PUT `/drafts/{id}/bpmn` | U10 |
| U10 Binding Inspector | Wire inputs/outputs/rules | binding picker, schema preview, rule selection | GET `/binding-sources`, `/rules`; POST `/bindings/validate` | U11 |
| U11 Validation Panel | Confirm executable definition | validate, issue list, jump-to-node | POST `/drafts/{id}/validate` | U12 |
| U12 Test Bench | Use fixtures and stubs in DEV | dry-run, inspect step/outcomes, replay failure | POST `/drafts/{id}/tests` | U13 |
| U13 Version Review `/be/workflows/{id}/versions` | Diff and publish approved draft | compare, lock, publish | POST `/drafts/{id}/publish` | U16 |
| U14 Business Work Queue `/be/work` | Batch and record progress | filter, detail, download report | GET `/business/batches` | U15 |
| U15 Run Monitor `/be/runs/{runId}` | Technical BPMN overlay and timeline | time/step selector, view events | GET `/runs/{id}`, stream via authorized projection | U17 |
| U16 Release Center `/be/releases` | UAT/PROD configuration promotion | package digest, checks, approval evidence, activate | POST `/releases`, `/activations` | U18 |
| U17 Operations Console `/be/operations/runs` | Safe pause/resume/cancel/restart | reason, runbook, confirmation | POST `/runs/{id}/commands` | U18 |
| U18 Audit and Controls `/be/audit` | Reconstruct who/what/when/why | search, export, runbook link | GET `/audit/events`, `/controls` | U01 |
| U19 API Regression `/be/tests` | Prove UI and service behavior | suite list, tests, fixtures, evidence | GET `/test-runs` | U03 |

**Routes are proposed.** Reconcile existing Blazor routes during JOB-00. Initial pages can share existing BE shell and app selectors rather than new infrastructure.

## Main designer layout

```text
+----------------------------------------------------------------------------------------------------------------+
| Application: DCMS  [DEV]  Workflow: DCMS.BatchEnrichment  [Draft v4]  Saved  [Undo] [Redo] [Validate] [Test] |
| [Save Draft] [Review] [Publish] [Import BPMN] [Export BPMN]  [Help/Controls]  Role: WorkflowAuthor              |
+----------------------+-----------------------------------------------------------------+-----------------------+
| PALETTE              | CANVAS (semantic BPMN graph + BPMN DI geometry)                | INSPECTOR             |
| Start / End          | [Start] -> [Stage CSV] -> [Subprocess: Process Rows] -> [Email] | General               |
| Service Tasks        |                 selection, anchors, connectors, pan/zoom         | Inputs / Outputs      |
| AMIE Rule Tasks      |                                                                 | AMIE / Conditions     |
| Gateways             |                                                                 | Execution / Retry     |
| Subprocess / Call    |                                                                 | Security / Audit      |
| Wait / Events        |                                                                 | Validation/Readiness  |
| Swimlanes            |                                                                 |                       |
+----------------------+-----------------------------------------------------------------+-----------------------+
| BOTTOM PANEL: Problems [2] | Data Context | Rule Test | BPMN XML | Run Preview | Change History                         |
+----------------------------------------------------------------------------------------------------------------+
```

## Reusable UI interaction state machine

- Every data-loading component has `Idle -> Loading -> Loaded | Empty | Denied | Error` and can `Retry` without losing local draft edits.
- Every mutation has `Editing -> Dirty -> Submitting -> Accepted | Rejected | Conflict`; an HTTP 202 means *accepted* not *completed*.
- Every editor draft has `New -> Dirty -> SavedDraft -> Validated -> InReview -> Approved -> Published -> Active -> Retired`. Invalidating changes clear the *validated* badge. A published version is immutable; new edits create a new draft.
- State transitions depend on **backend** permission; hiding or disabling a control is only a UI affordance.
- Reason, ServiceNow change ID and approvals are required on mutation actions according to control policy; invalid ticket shape is not approval.
- Cross-service operations use a durable correlated command/outcome and may remain pending. UI shows the actual confirmed state and a delayed/unknown status rather than optimistic success.

## Create-from-scratch walkthrough

1. Workbench > choose `DCMS` > Workflow Library > `Create workflow`. Confirm app and write permission.
2. Wizard > enter workflow name/key, owner, purpose, scope and a reusable template. Leave no hardcoded CyberArk details in BOB.
3. Trigger > select Manual CSV > choose approved input schema > map file reference and batch metadata to workflow inputs. Optionally save trigger templates for later API/AutoSys binding.
4. Data > add NAS/Data API binding for stage, page, mark outcome (requires actual approved endpoint contracts).
5. Designer > insert Start, Stage CSV service task, embedded Process Rows call/subprocess, Report, Email and End; attach default and failure paths.
6. Service task inspector > select approved `operationKey@version`; map required inputs using `BindingPicker`, map output into scoped context; choose host local or Kafka based on manifest.
7. AMIE task inspector > select pinned rule key/version, inspect required facts, map current row/account, view sample rule output and typed change-set output.
8. Sequential multi-instance > bind row collection, cap concurrency=1, define per-record outcome aggregation and continue-on-row-error policy.
9. Validation > fix unsupported elements, bad bindings, missing rule version, missing operation authorization, absent environment binding, unreachable nodes or dangerous retry policy.
10. Test Bench > use 5-row sample (success, unchanged, account missing, rule reject, write error/uncertain); prove outcomes and event timeline. Use mocks for destructive effects.
11. Save and compare draft > reviewer sees diff and controls > publish immutable version if policy passes.
12. In DEV trigger via BE/API. Dashboard shows per-batch status; technical Run Monitor shows pinned BPMN node statuses; Audit shows event causality.
13. UAT/PROD transfer is **separate**, exact package digest and approved environment bindings, authorized Operations activation. No developer PROD access.

## UX obligations per screen

- **Field states:** default, focused, dirty, required-missing, invalid-format, type-conflict, unauthorized-value, not-supported, async-checking, checking-failed, valid. Preserve user's input on transient network errors.
- **Accessibility:** keyboard operable node list + accessible property panels, visible focus, proper labels/error summary, diagram not sole carrier of meaning, modal focus restore, clear dialog cancellation, logical tab order.
- **Large data:** virtualized/paginated operations and batch rows, lazy schema loading, request cancellation for search, not all batch records shipped to browser.
- **Performance:** local canvas gestures in reviewed JS module; commit changes into Blazor state after gesture; no per-pointermove Blazor Server roundtrips.
- **Audit:** designer edits and published changes get actor/time/ServiceNow references according to policy; raw file contents, secrets and credentials are excluded from browser logs.

## Acceptance

A new app is authorable end-to-end with the same UI components, and BE shows dynamically discovered NAS/Data, CyberArk, Reporting, Email operations with typed binding forms. Save/import/export preserves BPMN XML IDs/DI. A central/embedded workflow passes real DEV API regression, and a business user can see counts without seeing private audit/technical detail. A denied user cannot bypass the UI by calling backend endpoints directly.
