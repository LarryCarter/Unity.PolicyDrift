# UI Runbook 02 — Compose a BPMN Workflow with an AMIE Rule

**Audience:** WorkflowDesigner, RuleMaintainer, Reviewer. **Goal:** no new microservice code when operations already exist.

1. Sign in to **BE → Workflow Library → New Draft** (or clone an approved template). Enter application key, description, owner, logical input contract, optional ServiceNow draft reference.
2. In **Designer**, select **Start Event**, **Service Task**, **Business Rule Task**, **Exclusive Gateway**, **Service Task**, **End Event**. Connect valid sequence flows, labels and default branch.
3. Click first service task; open **Capability Operation** palette. Search only **approved compatible** operations. Choose `CyberArk.GetAccount@1.0` as example.
4. Inspect auto-generated required inputs; set `accountRef ← input.accountRef` or `item.accountRef`. Output `account` to `steps.getAccount.output.account`.
5. Click Business Rule Task; select an **existing approved AMIE rule**, inspect its required facts/expected output. Map account object and source data from typed binding selector. Example result `eligible` and `reasonCode`.
6. Click gateway, choose rule outcome binding; configure eligible branch and explicit rejected/skipped branch. Do not paste C# into the gateway.
7. Click write service task if permitted; bind AMIE mapping/modified account result to the operation. Show write side-effect warning, permission and reconciliation policy.
8. Choose **Validate Draft**. Confirm backend compiler checks BPMN 2.0/DI, supported elements, flow reachability, data types, rule/handler versions, host mode, retry, authorization and missing environment keys.
9. Save (ETag/revision check); preview rule with **safe fixtures**, no real CyberArk mutation.
10. Submit for review; reviewer checks manifest versions and audit/control changes; approved publisher creates immutable version.
11. Author starts only DEV/approved environment test run through authorized API; inspect Run Monitor and complete event chain.

## Expected UX behavior

Palette shows operation owner/version/side-effect and compatibility. Right inspector renders typed input editors and source binding dropdowns. Validation uses node IDs and provides exact missing field. Published packages are immutable. Re-edit requires clone draft, not in-place mutation.

## Regression

Unknown operation; rule missing; bad field mapping; unsupported BPMN element; missing gateway default; unauthorized writer; stale draft; forbidden secret in form field; render XML->BPMN DI->XML roundtrip.
