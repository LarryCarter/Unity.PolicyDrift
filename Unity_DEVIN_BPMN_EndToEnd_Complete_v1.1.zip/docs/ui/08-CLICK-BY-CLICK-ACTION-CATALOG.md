# UI 08 - Click-by-Click Action Contract Catalog

Canonical source `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. All 107 controls in this table have an implemented *mock* handler in `wireframes/Unity_BE_Clickable_Wireframes_v1.0.html`. The prototype does not execute backend work.

## Binding rule for all controls

On click: 1) require correct role/resource scope; 2) validate field inputs; 3) call designated API with correlation and expected revision for mutation; 4) display pending state for async requests; 5) confirm from backend response; 6) surface structured error; 7) record indicated audit event; 8) preserve selection. In the HTML prototype, these outcomes are visibly simulated and permissions are not security enforcement.

## Unity Workbench

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **WB-01** Browse capabilities | `GET /api/v1/capabilities` | Designer,Capability Owner,Operations,Auditor | Open registry scoped to current role | 403 or no authorized capabilities | Read view only |
| **WB-02** Open Application Studio | `GET /api/v1/applications` | Designer,Reviewer,Operations | Open assigned application configurations | 403 if not owner or delegated | Read view only |
| **WB-03** My work | `GET /api/v1/batches?scope=mine` | All authenticated users | Open authorized batch list | No work in permitted scope | Read view only |
| **WB-04** Refresh status | `GET /api/v1/me/dashboard` | All authenticated users | Reload counts and last-updated time | Retain stale-data warning and correlation ID | Read view only |

## Capability Registry

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **CAT-01** Search / filter | `GET /api/v1/capabilities?q=&status=` | Designer,Capability Owner,Operations,Auditor | Table is filtered without altering registry | Return empty state with clear filters | Read view only |
| **CAT-02** Inspect operation | `GET /api/v1/operations/{key}/versions/{version}` | Designer,Capability Owner,Operations,Auditor | Open descriptor inspector at exact contract version | Unavailable/unauthorized contract shows status | Read view only |
| **CAT-03** Use in workflow | `POST /api/v1/workflow-drafts/{id}/activities` | Designer | Insert bound service task with stable key/version | No writable draft or unavailable op -> block | WorkflowDraftActivityAdded |
| **CAT-04** Refresh health | `GET /api/v1/capabilities/{key}/readiness` | Designer,Capability Owner,Operations,Auditor | Fetch current readiness and compatibility | Mark unknown/unavailable, never assume available | Read view only |

## Operation Inspector

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **OP-01** Back to Registry | `GET /api/v1/capabilities` | Designer,Capability Owner,Operations,Auditor | Return to same catalog filters | Retain prior selection | Read view only |
| **OP-02** View input/output schemas | `GET /api/v1/operations/{key}/schemas` | Designer,Capability Owner,Operations,Auditor | Show required inputs, outputs, permissions and side effects | Missing schema blocks binding | Read view only |
| **OP-03** Test with DEV fixture | `POST /api/v1/operation-tests/{key}/execute` | Capability Owner,Designer | Non-PROD fixture result with reason/correlation shown | PROD/live writes forbidden; invalid fixture rejected | OperationTestAttempt |
| **OP-04** Add to BOB workflow | `POST /api/v1/workflow-drafts/{id}/activities` | Designer | Append service task using selected descriptor | Draft not owned/contract unavailable | WorkflowDraftActivityAdded |
| **OP-06** Download contract manifest | `GET /api/v1/operations/{key}/manifest` | Designer,Capability Owner,Operations,Auditor | Download approved manifest with schema refs but no secrets | Unknown/unapproved contract -> deny export | OperationManifestDownloaded |
| **OP-05** Request missing primitive | `POST /api/v1/operation-development-requests` | Designer,Capability Owner | Generate typed DEVIN operation request, not code execution | Missing owner/schema or permission blocks submit | OperationDevelopmentRequested |

## Capability Onboarding

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **ON-01** Create manifest draft | `POST /api/v1/capability-manifests/drafts` | Capability Owner | Create local metadata draft; no executable registration yet | Missing service owner/key -> 422 | ManifestDraftCreated |
| **ON-02** Add operation declaration | `POST /api/v1/capability-manifests/drafts/{id}/operations` | Capability Owner | Attach typed operation metadata to draft | Duplicate key/version or schema missing | ManifestDraftChanged |
| **ON-03** Validate manifest | `POST /api/v1/capability-manifests/drafts/{id}/validate` | Capability Owner,Reviewer | Display schema/security/version checks | Invalid input/scope fails with field code | ManifestValidation |
| **ON-04** Submit service release evidence | `POST /api/v1/capability-manifests/drafts/{id}/submit` | Capability Owner | Send draft for privileged review, not auto-approve | CI digest/code-release evidence missing | ManifestSubmitted |
| **ON-05** Approve registry publication | `POST /api/v1/capability-manifests/{id}/approve` | Reviewer | Approve compatible manifest; no auto handler creation | Cannot self-approve; missing release proof | ManifestApproved |
| **ON-06** Check deployed readiness | `GET /api/v1/capability-manifests/{id}/readiness` | Capability Owner,Reviewer,Operations | Show registered vs actually available separately | Unhealthy/unapproved still blocked | Read view only |

## Application Studio

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **APP-01** Create application draft | `POST /api/v1/applications` | Designer | New app blueprint with owner and scope | Owner/scope required | ApplicationDraftCreated |
| **APP-02** Add capability dependency | `POST /api/v1/applications/{id}/capabilities` | Designer | Add stable approved contract dependency | Unavailable contract or incompatible version | ApplicationDependencyAdded |
| **APP-03** Save configuration | `PUT /api/v1/applications/{id}/draft` | Designer | Persist revision and ETag | 409 on concurrent edit | ApplicationDraftSaved |
| **APP-05** Select application module | `GET /api/v1/applications/{id}/modules/{key}` | Designer,Reviewer,Operations | Switch composition tab with selected workflow and capability dependencies | Unknown or unauthorized module -> clear empty state | Read view only |
| **APP-04** Open workflow library | `GET /api/v1/workflow-definitions?application=` | Designer,Reviewer,Operations | Show workflows for selected app | Missing app scope -> 403 | Read view only |

## Workflow Library

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **LIB-01** New draft from template | `POST /api/v1/workflow-drafts` | Designer | Create draft and initial BPMN IDs | No template permission | WorkflowDraftCreated |
| **LIB-02** Open selected version | `GET /api/v1/workflow-definitions/{key}/versions/{version}` | Designer,Reviewer,Operations,Auditor | Open editor if draft or read-only if published | Definition not visible or immutable | Read view only |
| **LIB-03** Compare versions | `GET /api/v1/workflow-definitions/{key}/diff?from=&to=` | Designer,Reviewer,Operations,Auditor | Show BPMN/rules/contracts/change diff | Missing comparison version | Read view only |
| **LIB-04** Clone as new draft | `POST /api/v1/workflow-definitions/{key}/clone` | Designer | New editable version referencing parent | Retired source allowed only under policy | WorkflowDraftCloned |
| **LIB-05** Submit for review | `POST /api/v1/workflow-drafts/{id}/review` | Designer | Draft moves to InReview with ticket and evidence | Validation errors or no change request | WorkflowReviewRequested |
| **LIB-06** Approve version | `POST /api/v1/workflow-reviews/{id}/approve` | Reviewer | Independently approve candidate | Maker/checker or missing tests | WorkflowApproved |
| **LIB-07** Publish immutable version | `POST /api/v1/workflow-definitions/{key}/publish` | Reviewer | Published with digest and pinned dependencies | Unapproved or missing capabilities | WorkflowPublished |
| **LIB-08** Retire selected version | `POST /api/v1/workflow-definitions/{key}/retire` | Operations | Prevent new runs but retain evidence | Active dependency/runs require policy check | WorkflowRetired |

## BOB BPMN Designer

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **DES-01** Add service task | `POST /api/v1/workflow-drafts/{id}/activities` | Designer | New BPMN service task with stable node ID | No approved operation available | DraftActivityAdded |
| **DES-02** Add business rule task | `POST /api/v1/workflow-drafts/{id}/activities` | Designer | New BPMN business-rule task | No AMIE descriptor available | DraftActivityAdded |
| **DES-03** Add exclusive gateway | `POST /api/v1/workflow-drafts/{id}/elements` | Designer | BPMN XOR gateway with branch conditions | Unsupported element/invalid graph | DraftElementAdded |
| **DES-04** Connect selected nodes | `PUT /api/v1/workflow-drafts/{id}/bpmn` | Designer | Directed sequence flow with new ID | Cycle/invalid branch rejected | DraftFlowChanged |
| **DES-05** Bind selected task input | `PUT /api/v1/workflow-drafts/{id}/bindings` | Designer | Typed mapping to input/current row/prior output | Missing source or wrong schema | DraftBindingChanged |
| **DES-06** Save draft | `PUT /api/v1/workflow-drafts/{id}` | Designer | Persist BPMN XML + DI + inspector data with ETag | 409 stale revision, preserve local edits | WorkflowDraftSaved |
| **DES-07** Validate BPMN and contracts | `POST /api/v1/workflow-drafts/{id}/validate` | Designer,Reviewer | Highlight node errors and publish readiness | Unsupported BPMN/AMIE/operation denies publish | WorkflowValidation |
| **DES-08** Preview safe execution | `POST /api/v1/workflow-drafts/{id}/simulate` | Designer | DEV fixture preview with explicit mock label | Real external writes forbidden in preview | WorkflowSimulationRequested |
| **DES-09** Submit workflow review | `POST /api/v1/workflow-drafts/{id}/review` | Designer | Submit validated draft to reviewer | Required ticket/digest/tests missing | WorkflowReviewRequested |
| **DES-10** Import BPMN XML | `POST /api/v1/workflow-drafts/{id}/import` | Designer | Parse BPMN XML + DI and show unsupported elements | Invalid XML or unsupported semantics fail | WorkflowDraftImported |
| **DES-11** Export BPMN XML | `GET /api/v1/workflow-drafts/{id}/export` | Designer,Reviewer,Operations | Download BPMN 2.0 XML with DI/extension refs | Draft not accessible | Read view only |
| **DES-12** Undo edit | `local editor; persist on Save` | Designer | Revert most recent uncommitted canvas edit | Nothing to undo | Read view only |
| **DES-14** Switch central / embedded workflow | `GET /api/v1/workflow-definitions/{key}/execution-contexts` | Designer,Reviewer,Operations | Change designer context, loading pinned central or CyberArk embedded subworkflow | Unavailable embedded definition or host compatibility rejected | Read view only |
| **DES-13** Redo edit | `local editor; persist on Save` | Designer | Reapply reverted canvas edit | Nothing to redo | Read view only |

## AMIE Rule Picker and Binding

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **AMI-01** Select rule version | `GET /api/v1/amie/rules/{key}/versions/{version}` | Designer,Rule Maintainer,Reviewer | Show required facts/decision types | Unavailable version, no implicit latest | Read view only |
| **AMI-02** Map required facts | `PUT /api/v1/workflow-drafts/{id}/rule-bindings` | Designer,Rule Maintainer | Bind typed input facts and output references | Mismatch/missing fact or unauthorized scope | RuleBindingChanged |
| **AMI-03** Preview rule with fixture | `POST /api/v1/amie/rules/{key}/preview` | Designer,Rule Maintainer | Existing AMIE evaluator returns typed safe result | Missing facts or unsafe fixture | RulePreviewed |
| **AMI-04** Save rule binding | `PUT /api/v1/workflow-drafts/{id}/rule-bindings` | Designer,Rule Maintainer | Persist pinned rule version and ETag | Conflict or unpublished rule | RuleBindingSaved |

## Triggers and Forms

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **TRI-01** Choose trigger type | `GET /api/v1/triggers/types` | Designer,Operations | Display manual CSV/API/schedule capabilities and readiness | AutoSys/API not yet implemented -> planned | Read view only |
| **TRI-02** Add required input field | `PUT /api/v1/workflow-drafts/{id}/trigger-schema` | Designer | New typed schema field for BE form | Unsupported data type/duplicate field | TriggerSchemaChanged |
| **TRI-03** Validate sample CSV | `POST /api/v1/ingestion/validate` | Designer,Business User | Return schema/row errors, no live write | Bad extension, oversize, missing cols | UploadValidation |
| **TRI-04** Save trigger mapping | `PUT /api/v1/workflow-drafts/{id}/trigger` | Designer | Persist trigger schema and source adapter ref | Missing owner/scope and unmapped data | TriggerMappingSaved |
| **TRI-05** Open business start form | `GET /api/v1/workflows/{key}/start-form` | Business User,Designer | Open role-scoped start UI | No execute permission | Read view only |

## Kafka Contract Explorer

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **KAF-01** Inspect message schema | `GET /api/v1/messaging/contracts/{key}` | Designer,Capability Owner,Operations,Auditor | Show producer/consumer/required fields/versions | Unknown logical message | Read view only |
| **KAF-02** Validate correlation envelope | `POST /api/v1/messaging/contracts/validate` | Designer,Capability Owner,Operations | Check commandId/runId/activityId/idempotency/partition | Missing required IDs or unapproved schema | MessageContractValidated |
| **KAF-03** Check environment bindings | `GET /api/v1/environment-bindings` | Designer,Capability Owner,Operations | Show approved logical-to-physical resolutions | No approved topic ACL | Read view only |

## Environment Bindings

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **ENV-01** Select target environment | `GET /api/v1/environment-bindings?env=` | Designer,Operations,Release Operator,Auditor | Show redacted refs for selected environment | PROD sensitive values never shown | Read view only |
| **ENV-02** Inspect binding dependency | `GET /api/v1/environment-bindings/{key}` | Designer,Operations,Release Operator,Auditor | Show reference/type/version/owner not secret value | Unauthorized value access denied | Read view only |
| **ENV-03** Validate readiness | `POST /api/v1/environment-bindings/validate` | Operations,Release Operator | Report unresolved refs, ACL/health incompatibility | Missing binding fails preflight | EnvironmentReadinessChecked |
| **ENV-04** Request binding change | `POST /api/v1/environment-bindings/change-requests` | Operations | Create controlled binding change request | Direct PROD edit denied | EnvironmentChangeRequested |

## Release Center

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **REL-01** Inspect candidate digest | `GET /api/v1/releases/{id}` | Reviewer,Operations,Release Operator,Auditor | Show diff, exact package digest and pinned deps | Tampered/missing package -> reject | Read view only |
| **REL-02** Run preflight | `POST /api/v1/releases/{id}/preflight` | Reviewer,Operations,Release Operator | Show signed evidence, approvals, bindings, health and tests | Any control missing => Blocked | ReleasePreflightChecked |
| **REL-03** Request UAT promotion | `POST /api/v1/releases/{id}/promote?target=UAT` | Release Operator | Stage exact digest for approved UAT pipeline | No DEV validation/owner approval | ReleasePromotionRequested |
| **REL-04** Inspect approvals | `GET /api/v1/releases/{id}/approvals` | Reviewer,Operations,Release Operator,Auditor | Show authoritative approval evidence, not ticket string only | Missing approval explicitly shown | Read view only |
| **REL-05** Activate PROD (gated) | `POST /api/v1/releases/{id}/activate?target=PROD` | Release Operator | Only real backend controls can authorize; demo always blocked | No real bank CA/approval; no operation in prototype | ReleaseActivationAttempt |
| **REL-07** Build immutable release candidate | `POST /api/v1/releases/candidates` | Reviewer,Operations | Bundle published BPMN, AMIE and operation lock into signed candidate digest | Unpublished workflow or missing dependency blocks build | ReleaseCandidateCreated |
| **REL-06** Rollback for NEW runs (gated) | `POST /api/v1/releases/{id}/rollback` | Release Operator | Select previously approved digest for future runs only | No hidden rollback of CyberArk side effects | ReleaseRollbackAttempt |

## Business Work Queue

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **BUS-01** Start CSV request (mock) | `POST /api/v1/workflows/DCMS.Batch/runs` | Business User,Designer | Create mock batch with batch number, row GUIDs and queued state | Invalid upload/permission or missing input contract | WorkflowStartRequested |
| **BUS-02** Select batch | `GET /api/v1/batches/{id}/summary` | Business User,Designer,Operations,Auditor | Show selected batch counts by status | Out-of-scope batch invisible | Read view only |
| **BUS-03** Refresh progress | `GET /api/v1/batches/{id}/summary` | Business User,Designer,Operations,Auditor | Refresh from source; show last-updated timestamp | Disconnected stream shows stale status | Read view only |
| **BUS-04** View outcome reasons | `GET /api/v1/batches/{id}/rows` | Business User,Designer,Operations,Auditor | Show paged per-row reason codes with classification mask | No sensitive raw account fields | Read view only |
| **BUS-05** Open report | `GET /api/v1/batches/{id}/reports` | Business User,Designer,Operations,Auditor | Show generated secure report refs only when terminal | Nonterminal batch shows pending report | Read view only |
| **BUS-06** Advance fixture 5 rows | `mock only (no production API)` | Business User,Designer,Operations | Advance simulated queue safely and counts reconcile | Never claim real operation success | DemoFixtureAdvanced |
| **BUS-07** Technical run (authorized) | `GET /api/v1/runs/{runId}` | Operations,Designer,Auditor | Open BPMN overlay and correlation evidence | Business-only user denied | Read view only |

## BPMN Run Monitor

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **RUN-01** Choose run | `GET /api/v1/runs/{id}` | Operations,Designer,Auditor | Load pinned BPMN version and activity states | Unavailable run denied | Read view only |
| **RUN-02** Inspect activity | `GET /api/v1/runs/{id}/activities/{activityId}` | Operations,Designer,Auditor | Show task inputs redacted, handler/rule/correlation/outcome | Protected fields masked | Read view only |
| **RUN-03** Filter event timeline | `GET /api/v1/runs/{id}/events?type=` | Operations,Designer,Auditor | Filter event types while preserving sequence | Empty filter state | Read view only |
| **RUN-04** Refresh now | `GET /api/v1/runs/{id}/events?after=` | Operations,Designer,Auditor | Query authoritative state after push/reconnect | Show stale indicator when unavailable | Read view only |
| **RUN-05** Open Operator Console | `GET /api/v1/runs/{id}/controls` | Operations | Show authorized state transitions | Insufficient control permission | Read view only |
| **RUN-07** Inspect correlated Kafka event | `GET /api/v1/runs/{id}/events/{eventId}` | Operations,Designer,Auditor | Show command/outcome envelope metadata, message IDs and safe result | Missing event or sensitive payload masked | Read view only |
| **RUN-06** Open audit history | `GET /api/v1/audit?runId=` | Operations,Designer,Auditor | Open filtered immutable evidence | Scope-restricted events masked | Read view only |

## Operator Console

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **CTL-01** Select run | `GET /api/v1/runs/{id}/controls` | Operations | Show current state, revision and allowed actions | Unknown run/role denied | Read view only |
| **CTL-02** Pause | `POST /api/v1/runs/{id}/pause` | Operations | Running -> PauseRequested -> Paused at safe checkpoint | Not running, missing reason or stale revision | RunPauseRequested |
| **CTL-03** Resume | `POST /api/v1/runs/{id}/resume` | Operations | Paused -> Running, pins checked | Not paused or missing dependencies | RunResumeRequested |
| **CTL-04** Cancel | `POST /api/v1/runs/{id}/cancel` | Operations | Request cooperative cancellation with linked evidence | Missing reason; may require reconciliation | RunCancelRequested |
| **CTL-05** Retry failed step | `POST /api/v1/runs/{id}/retry` | Operations | Reconcile before retry; increment attempt | Unknown write outcome or incorrect state | RunRetryRequested |
| **CTL-06** Restart as new run | `POST /api/v1/runs/{id}/restart` | Operations | New linked run ID; old run remains intact | Missing authorization/terminal status | RunRestartRequested |
| **CTL-07** Read controlling runbook | `GET /api/v1/runbooks/by-run/{id}` | Operations | Open procedures and control owner | No applicable runbook => block command if required | Read view only |

## Controls and Runbooks

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **RB-01** Select runbook | `GET /api/v1/runbooks/{id}/versions/{v}` | Operations,Auditor,Reviewer | Open read-only procedure and version | Retired version remains readable for history | Read view only |
| **RB-02** View procedure and exceptions | `GET /api/v1/runbooks/{id}` | Operations,Auditor,Reviewer | Show what to do, when to stop, escalation, owner | Missing real CA/control clearly marked | Read view only |
| **RB-03** Acknowledge procedure | `POST /api/v1/runbooks/{id}/ack` | Operations | Record operator acknowledgement when required | Wrong version or role rejected | RunbookAcknowledged |
| **RB-04** View related control evidence | `GET /api/v1/audit?controlId=` | Operations,Auditor,Reviewer | Open control-specific audit events | Scope denied | Read view only |

## Role and Scope Policies

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **ACC-01** Inspect role-policy matrix | `GET /api/v1/access/policies` | Operations,Reviewer,Auditor | Show action, role, scope, separation requirements | No global bypass roles | Read view only |
| **ACC-02** Test denied API fixture | `POST /api/v1/test/authorization/denial` | Operations,Reviewer | Show isolated negative API test contract | Never use PROD write endpoints | SecurityTestExecuted |
| **ACC-03** Request policy change | `POST /api/v1/access/change-requests` | Operations | Open controlled policy change request | No direct role grant in UI | SecurityChangeRequested |

## Audit and Traceability

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **AUD-01** Search evidence | `GET /api/v1/audit?run=&batch=&change=` | Operations,Auditor,Reviewer | Filtered append-only timeline, stable order | Missing filter returns authorized scope only | Read view only |
| **AUD-02** Inspect event detail | `GET /api/v1/audit/{eventId}` | Operations,Auditor,Reviewer | Show actor, versions, UTC, correlation, safe result | Sensitive payloads masked | Read view only |
| **AUD-03** Export scoped evidence (mock) | `POST /api/v1/audit/exports` | Auditor | Create redacted, traceable export request | Unauthorized caller denied; no raw secrets | AuditExportRequested |
| **AUD-04** Follow run correlation | `GET /api/v1/runs/{id}` | Operations,Auditor | Open technical run view at matching correlation | Dangling run reference shown | Read view only |

## API Functional Regression

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **TST-01** Select suite | `GET /api/v1/regression/suites/{id}` | Designer,Capability Owner,Operations,Reviewer,Auditor | Show cases and required environment/fixture | Unknown suite | Read view only |
| **TST-02** Preview test plan | `GET /api/v1/regression/suites/{id}/cases` | Designer,Capability Owner,Operations,Reviewer,Auditor | Show positive, denied, failure injection cases | No production test execution | Read view only |
| **TST-03** Run mock fixture test | `POST /api/v1/regression/runs (nonprod only)` | Designer,Capability Owner,Operations | Simulate test results with explicit MOCK marker | No live run, unknown env, or unsafe scenario | RegressionFixtureRun |
| **TST-04** Inspect failed case | `GET /api/v1/regression/runs/{id}/cases/{caseId}` | Designer,Capability Owner,Operations,Reviewer,Auditor | Show assertion, expected and actual, evidence ref | No result yet | Read view only |
| **TST-05** Open DEVIN job index | `local docs/jobs/INDEX.md` | Designer,Capability Owner,Operations,Reviewer,Auditor | Show relevant workstream and acceptance mapping | Document missing -> provide path | Read view only |

## Control wiring implementation rules

- Preserve stable `data-control-id` matching table IDs in Blazor component tests and UI telemetry.
- For filters, the data-source API must apply scope server-side; client-side filtering alone is not sufficient.
- For mutations, a UI confirmation or optimistic immediate badge is not the server state. Wait for durable result or poll status.
- Use business disposition wording in business queue. Technical operation or broker outcomes appear only for authorized roles in run monitor.
- Browser file upload uses approved API with size/type/schema checks and tokenized blob reference; do not send CSV payload in Kafka.
- For actions marked `mock only`, there must be **no** production API counterpart. They exist solely to demonstrate state changes in the static prototype.
- Production activation and rollback remain disabled in the prototype, irrespective of selected persona.

