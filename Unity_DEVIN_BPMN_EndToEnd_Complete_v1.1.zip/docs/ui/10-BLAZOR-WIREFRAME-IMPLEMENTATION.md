# UI 10 - Translating Wireframes to Blazor Implementation

## 1. Baseline and sources

- Previous v0.7 browser prototype is visual inspiration; `wireframes/Unity_BE_Clickable_Wireframes_v1.0.html` is the actionable **behavior model** with stable 107 action IDs, simulated role switching and state changes.
- Existing Blazor solution/routers/services must be discovered in JOB-00. The file paths below are **proposed** component boundaries, not current source tree.
- Backend contract spec: `docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md` and `wireframes/UI_CONTROL_REGISTRY_v1.0.json`.

## 2. Component decomposition (proposed paths)

| Path | Responsibility | Test boundary |
|---|---|---|
| `/BusinessEnablement/Components/Layout/UnityShell.razor` | Nav, app/env context, role-scoped current user, status/error region | Route access not granted by hiding |
| `/BusinessEnablement/Components/Capabilities/CapabilityCatalog.razor` | Search, filter, readiness, scoped registry records | CAT-01 to CAT-04 |
| `/BusinessEnablement/Components/Capabilities/OperationInspector.razor` | schema-derived inputs, output, host, permission, test & add | OP-01 to OP-05 |
| `/BusinessEnablement/Components/Capabilities/CapabilityOnboarding.razor` | metadata draft + validation + approval status | ON-01 to ON-06 |
| `/BusinessEnablement/Components/Applications/ApplicationStudio.razor` | select app, deps and role scope | APP-01 to APP-04 |
| `/BusinessEnablement/Components/Workflows/WorkflowLibrary.razor` | template/version lifecycle and diff | LIB-01 to LIB-08 |
| `/BusinessEnablement/Components/Workflows/BpmnDesigner.razor` | visual SVG canvas and BPMN DI/typed binding model | DES-01 to DES-13 |
| `/BusinessEnablement/wwwroot/js/bpmnCanvas.js` | small reviewed JS module for high-rate drag/pan/zoom gestures | commits only through Blazor interop |
| `/BusinessEnablement/Components/Rules/AmieBindingInspector.razor` | rules and typed facts, sample preview | AMI-01 to AMI-04 |
| `/BusinessEnablement/Components/Triggers/TriggerEditor.razor` | schema-driven start forms, CSV source, future adapters | TRI-01 to TRI-05 |
| `/BusinessEnablement/Components/Messaging/ContractExplorer.razor` | logical topic/envelope, redacted bindings | KAF-01 to KAF-03 |
| `/BusinessEnablement/Components/Release/EnvironmentBindings.razor` | approved refs, readiness; no secret values | ENV-01 to ENV-04 |
| `/BusinessEnablement/Components/Release/ReleaseCenter.razor` | digest, approvals, UAT/prod gates | REL-01 to REL-06 |
| `/BusinessEnablement/Components/Business/BatchQueue.razor` | scoped business counts and reasons | BUS-01 to BUS-07 |
| `/BusinessEnablement/Components/Monitoring/RunMonitor.razor` | pinned BPMN overlay, activity details, events | RUN-01 to RUN-06 |
| `/BusinessEnablement/Components/Monitoring/OperatorConsole.razor` | safe process controls, reason/runbook | CTL-01 to CTL-07 |
| `/BusinessEnablement/Components/Controls/RunbookLibrary.razor` | operational procedures and evidence | RB-01 to RB-04 |
| `/BusinessEnablement/Components/Security/AccessPolicies.razor` | read-only role/scope views and policy requests | ACC-01 to ACC-03 |
| `/BusinessEnablement/Components/Audit/AuditExplorer.razor` | append-only event query/export | AUD-01 to AUD-04 |
| `/BusinessEnablement/Components/Tests/ApiRegression.razor` | read CI test evidence and suites | TST-01 to TST-05 |
| `/BusinessEnablement/Services/UnityApiClient.cs` | Typed HTTP clients to real API endpoints | bearer policy and status mapping |
| `/BusinessEnablement/Components/Shared/UiActionState.razor` | loading, pending, errors, revision conflict and correlation | reusable status behavior |

Adjust paths to actual `DashboardApp-main`/Blazor project layout if existing; do not accidentally create a second BE app. Use existing FluentValidation convention if available and approved.

## 3. BPMN canvas architecture

- Maintain one in-memory editor document (BPMN graph + BPMN DI geometry + Unity extension references). No dual hidden "diagram JSON" that drifts from BPMN XML.
- JS owns pointermove, drag preview, connect preview, snap guides, pan/zoom; Blazor owns authoritative graph, validation, selection, dialog state and saves. JS calls Blazor with **committed** actions, not every mouse pixel.
- Palette restricts initial supported executable elements. Unsupported elements imported from external BPMN remain visible with an explicit validation error; never silently drop them.
- Right inspector loads manifest/rule JSON Schema and pins versions. Bindings are typed references, not arbitrary expressions.
- Undo/redo affects editor draft history only, never deployed workflow/production run state. Save requires revision/ETag. Import/export must retain BPMN IDs/DI and generated extension elements; roundtrip tests mandatory.
- Provide keyboard accessible list/table alternative for selected nodes and connections; diagram color is not sole indicator.

## 4. API-first client state

Blazor UI calls typed HTTP endpoints; it must not access BOB MSSQL tables, invoke AMIE directly from browser, or subscribe to Kafka. For longer operations, API responds 202 with operation ID, and UI awaits authoritative status. For near-real-time: server-side projection -> authorized SignalR/SSE -> UI event; reconnect triggers GET snapshot to correct missed updates. Use ETag for drafts/control actions; 409 conflicts preserve user edits.

## 5. Form and data handling

- Data-driven field components derive from approved input schemas and UI hints. Validate required data in UI for UX and on backend for security.
- CSV upload: inspect file metadata and size, upload via authorized backend, receive signed/ref token; do not put CSV contents in messages.
- No secret values, password fields, raw sensitive account JSON, auth tokens or unrestricted endpoints in wireframe, telemetry, log or audit export.
- Show exact business row statuses separately from technical BPMN status. Terminal count definitions are documented in DCMS spec.

## 6. Visual and interaction details per control

Every button includes stable `data-control-id` from registry, matching automated test selector. Disabled buttons explain permission/state and preserve keyboard context. Modal/drawer focus is trapped and restored. Before mutation show required reason, change ticket or required input. Pending state is not success. Show service error code and correlation ID with safe message. Support loading/empty/error/permission denied states for every screen as documented in UI 07. Names and UI text must be reviewed against actual bank conventions.

## 7. Done means proven by API and UI

- Screens render data from real, authenticated backend (not hardcoded fixture) in DEV; mock-only UI is not completion.
- Each control's positive and negative API test passes; backend enforces scope independent of button state.
- BPMN canvas design -> save -> reload -> import/export -> compile -> execute works for approved subset.
- SDK-registered operation appears dynamically with schema; AMIE rule output maps to handler input; no CyberArk-specific Razor form coding.
- Business counts match staged row outcomes; tech monitor reconstructs run and audit; pause/resume correctly follows safe checkpoint.
- Production controls remain blocked unless real bank approval is proven. No accessibility-blocking keyboard issues or JS console exceptions.
