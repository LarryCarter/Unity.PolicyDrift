# UI 12 - Preserve Earlier v0.6/v0.7 Prototype Click Behavior

Source: earlier user-approved visual prototypes `Unity_BE_Capability_Composer_Prototype_v0.6.html` and `Unity_BE_Prototype_v0.7.html`. These are **concept prototypes**, not backend code. Original files are preserved in the separate COMPLETE archive. This crosswalk prevents dropping a visible earlier interaction when building v1.0 Blazor UI.

## Original prototype control -> version 1.0 contract

| v0.6/v0.7 `data-action` | v1.0 action ID | Behavior to preserve |
|---|---|---|
| `add-component` | APP-02, DES-01 | Add approved reusable module or service task; do not generate new CyberArk code |
| `add-node` | DES-01 / DES-02 / DES-03 | Insert supported BPMN element with stable ID, save and validate |
| `build-candidate` | REL-07 | Build immutable package with pinned dependencies only from published workflow |
| `check-bindings` | ENV-03 | Readiness for topic/endpoint/secret refs and service compatibility |
| `close-modal` | UI local close | Close with focus return; no backend mutation |
| `designer-scope` | DES-14 | Switch between central BOB process and embedded CyberArk subworkflow |
| `download-manifest` | OP-06 | Export approved operation schema/manifest without credentials |
| `edit-composition` | APP-03, APP-05 | Select app module, edit and save configuration revision |
| `evaluate-rule` | AMI-03 | Preview existing AMIE evaluation in safe DEV fixture |
| `export-draft` | DES-11 | Export BPMN 2.0 XML + DI and Unity references |
| `open-capability` | CAT-02 | Open capability/operation inspector for exact version |
| `open-embedded` | DES-14 | Display embedded BOB subworkflow with its local handler sequence |
| `open-run-event` | RUN-07 | Inspect event contract IDs, safe outcome and broker correlation |
| `preview-prod` | REL-02, REL-05 | Preflight display and hard production gate; mock must never activate |
| `save-demo-draft` | DES-06 | Persist a versioned draft, ETag, safe conflict handling (mock saves locally) |
| `save-rule` | AMI-04 | Save pinned rule binding; does not modify AMIE core code |
| `select-module` | APP-05 | Switch application module/version without losing state |
| `select-operation` | OP-02 | Select exact operation, inspect typed schema and permissions |
| `select-rule` | AMI-01 | Choose existing AMIE rule by key and version |
| `stage-uat` | REL-03 | Operations-controlled UAT staging of exact package digest |
| `use-operation` | OP-04, CAT-03 | Insert operation into authorized BPMN draft |
| `v7-control` | CTL-02..CTL-06 | Pause/resume/cancel/retry/restart safe run-state transitions |
| `v7-inspect-workflow` | LIB-02 / LIB-03 | Open historical version and change diff |
| `v7-report` | BUS-04 / BUS-05 | Show paginated row reasons and secured report |
| `v7-runbook` | RB-02 | View controlling procedure and exception steps |
| `v7-select-batch` | BUS-02 | Select business batch scoped to current user |
| `v7-select-run` | RUN-01 / CTL-01 | Select technical execution and control permissions |
| `v7-start-mock` | BUS-01 | Authorized business start with data requirements and batch reference |
| `v7-tech-run` | BUS-07 | Move business user to technical monitor **only if authorized** |
| `v7-tests` | TST-02 / TST-03 | Inspect API regression plan and run isolated fixture (mock) |
| `v7-topic` | KAF-01 | Inspect logical Kafka contract/schema and message flow |
| `validate-descriptor` | ON-03 | Validate declared service handler metadata and schemas |
| `validate-workflow` | DES-07 | Backend BPMN + operation/AMIE binding validation |

All 33 distinct old `data-action` tokens have a v1.0 disposition above. The old navigation group is mapped to the 19 current routes; Operation Inspector is now a distinct screen. Buttons marked `mock` in earlier prototypes do not become production behaviors without implementing, securing and testing their corresponding real API.

## Blazor acceptance for prototype preservation

Run `wireframes/validate_clickability.py`: all 107 current action IDs must render and trigger a meaningful mock state, validation error or information modal with no JavaScript exceptions. This is UI-behavior smoke evidence **only**. Complete each backend action with `docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md` and `docs/ui/11-UI-API-ACCEPTANCE-SCRIPTS.md`.
