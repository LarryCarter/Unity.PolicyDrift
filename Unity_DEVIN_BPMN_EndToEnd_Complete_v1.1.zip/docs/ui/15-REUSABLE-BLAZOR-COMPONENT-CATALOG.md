# UI 15 - Reusable Blazor Component Library for BE

## Principle

The UI is schema- and descriptor-driven, not CyberArk/DCMS-specific Razor pages. Components work for DCMS, Account Delete, Policy Drift, onboarding and future capability services. No new UI vendor library is required until the bank approves it. Reconcile the actual BE Blazor project and namespace before adding a second app; paths below are logical targets.

## Component tree / ownership

```text
/BusinessEnablement/Components/
  Layout/UnityShell.razor
  Shared/AsyncStateView.razor
  Shared/ScopedPermissionAction.razor
  Shared/CorrelationBanner.razor
  Shared/EntityVersionSelector.razor
  Shared/SchemaField.razor
  Shared/TypedBindingPicker.razor
  Shared/JsonSchemaSummary.razor
  Shared/ValidationIssueList.razor
  Shared/ChangeTicketInput.razor
  Shared/EnvironmentBindingRef.razor
  Shared/RoleGate.razor
  Shared/ConfirmSideEffectDialog.razor
  Shared/ApiResultToast.razor
  Workflows/WorkflowWizard.razor
  Workflows/WorkflowLibrary.razor
  Workflows/BpmnDesignerShell.razor
  Workflows/BpmnPalette.razor
  Workflows/BpmnCanvas.razor
  Workflows/BpmnNodeInspector.razor
  Workflows/BpmnSequenceInspector.razor
  Workflows/BpmnNodeList.razor
  Workflows/WorkflowDiffViewer.razor
  Workflows/WorkflowValidationPanel.razor
  Workflows/WorkflowTestBench.razor
  Workflows/WorkflowPublishWizard.razor
  Workflows/WorkflowRuntimeOverlay.razor
  Triggers/TriggerTypePicker.razor
  Triggers/CsvUploadSchemaEditor.razor
  Triggers/ApiTriggerEditor.razor
  Triggers/AutosysTriggerEditor.razor
  Data/DataSourcePicker.razor
  Data/NasOperationInspector.razor
  Capabilities/CapabilityCatalog.razor
  Capabilities/OperationInspector.razor
  Rules/AmieRulePicker.razor
  Rules/AmieRuleTestPanel.razor
  Messaging/KafkaContractInspector.razor
  Business/BatchStatusCard.razor
  Business/BatchDetailGrid.razor
  Monitoring/ActivityTimeline.razor
  Monitoring/RunControlPanel.razor
  Audit/AuditEvidenceTable.razor
  Release/ReleaseGateStatus.razor
  Release/PromotePackageWizard.razor
  Shared/RunbookReference.razor
/BusinessEnablement/Services/
  IWorkflowCatalogApi.cs / ICapabilityRegistryApi.cs / IRuntimeApi.cs
/BusinessEnablement/wwwroot/js/bpmnCanvas.js
```

These are **proposed** paths. Follow existing project folder pattern, e.g. `/DashboardApp-main/...` where that is actual BE project. Use `FluentValidation` under `/DashboardApp-main/Validation` if the existing application uses that convention; do not introduce DataAnnotations as parallel validation policy.

## Reusable component requirements

| Component | Inputs (parameter model) | Emits/output | Async, empty and error behavior | A11y + test |
|---|---|---|---|---|
| `AsyncStateView<T>` | request status, result, error, retry | load/retry | skeleton/empty/permission/error | announce status changes |
| `ScopedPermissionAction` | policy, resource, enabled-state, action | authorized click intent | disabled reason, server 403 | keyboard + denial test |
| `SchemaField` | JSON schema property, UI hints, value, classification | typed change | required/format/type errors | label/error ids |
| `TypedBindingPicker` | destination type, allowed sources, selected source | validated binding | forbidden/incompatible source excluded with reason | keyboard combobox |
| `AmieRulePicker` | scope, required facts, schema, versions | immutable rule ref | no compatible rule -> clear exception | role filtered |
| `OperationInspector` | operation key/version | add operation, inspect descriptor | deprecation/conflict/read-only | no secret values |
| `BpmnPalette` | supported element catalog, host conformance | selected draggable element | unsupported visible but blocked | list alternative |
| `BpmnCanvas` | draft BPMN XML+DI, bindings, selection | add/move/connect/selection commits | error banner, unsaved state | keyboard node list |
| `BpmnNodeInspector` | node + descriptor + rule catalog | typed property edits | dependency fetch stale -> preserve draft | tab semantics |
| `ValidationIssueList` | codes/severity/nodeRefs | focus affected element | warnings vs blockers | error summary |
| `WorkflowTestBench` | fixtures, runMode, permissions | test run ref | fake vs live label, timeout/pending | test ids |
| `WorkflowRuntimeOverlay` | published DI + activity states | selected activity | stale/reconnect -> snapshot GET | non-color labels |
| `TriggerTypePicker` | authorized trigger types | new trigger contract | unavailable AutoSys adapter labeled pending | cards/radio semantics |
| `CsvUploadSchemaEditor` | CSV columns/schema/policy | staged file ref | size/CSV parse/rejected rows | file input test |
| `NasOperationInspector` | approved NAS/data API manifest | typed data binding | schema/API version mismatch | no raw SQL editor |
| `BatchStatusCard` | aggregate counts/runId | drilldown | progress snapshot on reconnect | aria progress |
| `RunControlPanel` | run status, role, runbook | reasoned operator command | safe checkpoint/202 pending | confirmation focus |
| `ReleaseGateStatus` | package hash, approvals/roles | activate request | cannot bypass real authorization | blocked reason |

## Contract example for schema field wrapper

```csharp
public sealed record FieldUiDescriptor(
    string Name,
    string JsonType,
    bool Required,
    string? DisplayLabel,
    string? Description,
    string Classification,
    IReadOnlyList<string>? AllowedBindings);
```

A real implementation should honor the existing DTO naming and serializer conventions; this is a specification sketch, **not** compiled application code.

## Reusable API-facing state object

```csharp
public sealed record UiLoadState<T>(
    string Status, // Idle, Loading, Ready, Empty, Forbidden, Failed
    T? Data,
    string? ErrorCode,
    string? CorrelationId,
    string? Revision);
```

Do not use this string status as an authorization mechanism. Auth remains backend enforced.

## Dynamic dependency chain

`Capability Manifest` -> `Operation Picker` -> `SchemaField / TypedBindingPicker` -> `BPMN Unity binding` -> `Validation` -> `Test` -> `Published package` -> `Runtime overlay`.

`AMIE Descriptor` -> `Rule Picker` -> `Fact Binding` -> `Rule Test` -> `Business Rule Task` -> `Decision routing`.

`Trigger Contract` -> `Upload/Form/API/AutoSys picker` -> `Input schema` -> `BPMN Start` -> `Run ID + Business Dashboard`.

## BE component regression contract

Each component is unit/component tested for: loading, empty, errors, forbidden, stale versions, changed dependent schema, conflicting edits, keyboard focus, input validation, escaped error messages, data classification, localization fallback, and disconnected/reconnect state. End-to-end Playwright tests use stable `data-testid` attributes, not text selectors; direct API-denial tests are mandatory.

**Canvas implementation:** JS owns high-rate drag/pan/zoom and reports committed changes through JS interop to Blazor. Blazor maintains model, selection, inspector and save API. Do not modify Blazor-owned DOM from JS. Reference: https://learn.microsoft.com/en-us/aspnet/core/blazor/javascript-interoperability/?view=aspnetcore-10.0.
