# UI Runbook 05 — DEV / UAT / PROD Configuration Promotion

**Audience:** workflow author, reviewer, release operator, control owner. This document defines a desired controlled release interface; current actual bank CAs and ServiceNow integration are not verified.

1. **DEV / Workflow Library:** author creates immutable candidate from validated draft, with exact BPMN, AMIE rules and operation contract lock file. Record author, UTC and review request.
2. **DEV / Regression:** execute API, BPMN semantics, role-denial and DCMS acceptance suites. Capture CI evidence and package digest; fail if missing rule/deployed operation version.
3. **Review:** designated reviewer compares diff and operational control/runbook changes. Link actual ServiceNow ticket and approval evidence from bank-authorized process. Prevent self-approval where required.
4. **Release Center → Candidate:** verify signature/digest and full dependency manifest; inspect allowed environment bindings (logical topic key/approved service endpoint/vault ref). Actual secrets not exposed.
5. **UAT:** authorized pipeline installs exact bytes/digest, resolves UAT logical bindings and runs smoke/E2E. UAT users sign off evidence.
6. **Release Center → PROD Preflight:** backend checks trusted issuer, exact UAT-approved digest, current service compatibility, broker access, binding completeness, real bank approvals, segregation of duties and required CAs.
7. **Operations Activation:** authorized ReleaseOperator (not developer) activates exact package; backend records actor/ticket/environment/digest/UTC and emits audit. If a gate fails, display **Blocked** with evidence rather than an enabled deploy button.
8. **Observe:** new runs use new version; existing runs stay pinned. Rollback selects prior approved version for new runs; never promise to undo CyberArk writes.

## Tests

Tampered package digest; missing ticket; ticket string without approval; author same as reviewer in restricted control; unavailable operation; retired AMIE version; wrong environment binding; worker ACL failure; UAT version differs from PROD candidate; developer attempts PROD; rollback while old run active.

## Records for auditors

Candidate diff, precise digest, actor/reviewer/deployer identities, timestamps, ServiceNow change ID and authoritative approval reference, test result evidence, environment bindings version and activation/rollback events. No secrets in package or UI screenshots.
