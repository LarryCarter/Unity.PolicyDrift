# UI Runbook 04 — Roles, Monitoring and Safe Process Controls

**Audience:** access admin, business user, operator, auditor. These role labels are proposals to map to real Wells Fargo entitlements.

## Assign scope

1. Access admin uses approved IAM integration, not UI-created fake enterprise roles. Map corporate identities/groups to permission+scope for application, workflow, data owner and environment.
2. Show a matrix in BE **Access Policies**: Designer (draft), Reviewer (approve), Executor (start/upload), Operator (run controls), Auditor (read evidence), ReleaseOperator (activate). Enforce policy via API and worker dispatch.
3. Test a BusinessExecutor sees **own assigned batches**, report and minimal reasons; cannot access run control, raw audit export or other team's batches.
4. Test ProcessOperator sees authorized runs, state, activity detail, pending Kafka command and runbook; cannot edit published workflow.
5. Test Auditor sees immutable history, permitted masked evidence and change request but no mutation.

## Monitor

1. Open Business Work Queue: summary counters and report link; confirm **no BPMN expertise required**.
2. Open technical Run Monitor as authorized support: select process ID, see activity overlay and event timeline, message IDs and safe AMIE decision reason; verify audit query yields same chain.
3. Temporarily disconnect SignalR/SSE in nonproduction: API reload reconciles current state on reconnect, avoiding stale badges.

## Pause

1. In Operator Console select live run, inspect `expectedRevision` and runbook.
2. Enter reason and approved change reference if required; choose Pause.
3. UI receives `PauseRequested`, **not** immediately `Paused`. Existing CyberArk call may finish; no next row should start after checkpoint acknowledgement.
4. Confirm transition event actor, UTC and reason. Resume with same run version and checkpoint, not new definition.

## Cancel/Retry/Restart

- Cancel requests no future work; does not automatically roll back external changes. Record partially successful rows.
- Retry only after failure classification; unknown external outcome blocks automatic write replay pending reconciliation.
- Restart creates **new run** linked to old; original evidence remains. A stale ETag, denied role or concurrent command returns explicit rejection.

## Runbook acceptance

Each operator action exposes the correct runbook version, required reason/ticket, expected consequences, escalation owner and evidence checklist. Bank control owners must approve exact process.
