# UI 16 - BPMN Composer Click-to-Backend Action Contract

**Maintains** existing 107-action v1.0 registry (`wireframes/UI_CONTROL_REGISTRY_v1.0.json`) as baseline. These are **new grouped v1.1 composer actions**; names are proposed until JOB-00 reconciles existing API routing. Each action must have a backend API; front-end display-only actions may use GET or local state rather than pretend persistence.

## HTTP and state conventions

- Every mutation carries `X-Correlation-ID`, authenticated actor, app/resource scope, `If-Match` revision for drafts and immutable operation IDs for async actions. Service authorization is enforced at both gateway and worker.
- `200/201` => confirmed result; `202` => queued/accepted, poll or push for final result; `400/422` => validation; `401/403` => auth/permission; `404` => scoped absence; `409/412` => revision conflict; `429/503` => backoff and retry guidance with no duplicate mutation; `5xx` => uncertain status, reconcile via run ID.
- Field-level errors are rendered next to fields and in a keyboard-accessible summary; all API errors return stable error code and correlation ID. Never treat a disabled button as a security control.
- Published versions are immutable; draft editing changes revision. Run control commands have `commandId`, `reasonCode`, `requestedAtUtc`, `actor`, runbook/control id.

## Action contract matrix

| Action ID | Screen/control | Input / permission | Proposed call | UI change + audit / negative test |
|---|---|---|---|---|
| CMP-001 | Workbench: select app | app ID / `App.View` | GET `/apps/{id}` | scope filters all downstream operations; deny cross-app |
| CMP-002 | Library: new workflow | app, title / `Workflow.Edit` | POST `/workflow-drafts` | draft created; duplicate key 409 |
| CMP-003 | Library: clone template | template version / `Workflow.Edit` | POST `/workflow-drafts/from-template` | new IDs and draft; no inherited secrets |
| CMP-004 | Library: compare version | definition A/B / `Workflow.View` | GET `/workflows/{id}/diff` | structural diff and rule/operation pin diff |
| CMP-005 | Wizard: save identity | name, owner, scope / edit | PUT `/workflow-drafts/{id}/metadata` | updated ETag; required owner |
| CMP-006 | Wizard: choose trigger | start binding / edit | PUT `/workflow-drafts/{id}/trigger` | selected mode and input schema; disallow unsupported |
| CMP-007 | Trigger: manual CSV | input schema, size, file / execute | POST `/uploads` | returns fileRef; invalid CSV no run created |
| CMP-008 | Trigger: form | schema and values / execute | POST `/workflow-starts` | runId; backend revalidates fields |
| CMP-009 | Trigger: API definition | auth/schema/idempotency / edit | PUT `/workflow-drafts/{id}/trigger` | returns draft binding, never actual credentials |
| CMP-010 | Trigger: AutoSys definition | allowed job, sourceRunId schema / edit | PUT `/workflow-drafts/{id}/trigger` | unknown/unauthorized job rejected |
| CMP-011 | Trigger: Kafka definition | logical message ref/schema / edit | PUT `/workflow-drafts/{id}/trigger` | producer/contract validated |
| CMP-012 | Trigger: timer selection | schedule/timezone / edit | POST `/workflow-drafts/{id}/validate` | clearly unsupported if host not ready |
| CMP-013 | Data: browse NAS source | app scope / view | GET `/capabilities/NAS/operations` | typed approved operations only |
| CMP-014 | Data: inspect schema | operation/version / view | GET `/operations/{key}/versions/{v}` | fields and classifications; no table browse without policy |
| CMP-015 | Data: sample preview | masked fixture / `Data.Preview` | POST `/operations/{key}/preview` | redacted sample; no raw arbitrary queries |
| CMP-016 | Palette: insert node | BPMN type/position / edit | local edit, then PUT `/workflow-drafts/{id}/bpmn` | new BPMN id + DI, undo, validation stale |
| CMP-017 | Canvas: connect nodes | source/target IDs / edit | local edit, PUT draft | graph edge validated; reject illegal connection |
| CMP-018 | Canvas: select node | BPMN id / view | local; optional GET descriptor | inspector reflects current selection |
| CMP-019 | Canvas: move / zoom | bounds/waypoints / edit | local preview, save draft on commit | no pointermove API flood |
| CMP-020 | Canvas: duplicate node | original BPMN id / edit | local then save | generates new IDs, no stale bindings |
| CMP-021 | Canvas: delete node | BPMN id / edit | local then save | warn if dependent edge/data link exists |
| CMP-022 | Canvas: undo / redo | editor history / edit | local only | no change to published version |
| CMP-023 | Canvas: import BPMN | XML and DI / edit | POST `/workflow-drafts/{id}/imports` | issues show unknown elements, preserve extensions |
| CMP-024 | Canvas: export BPMN | version/draft / view | GET `/workflow-drafts/{id}/export` | exact XML+DI, no credentials |
| CMP-025 | Inspector: choose operation | key/version / edit | GET descriptor; PUT draft binding | pinned version and host restrictions |
| CMP-026 | Inspector: change input | field/source / edit | POST `/bindings/validate`; PUT draft | type issue at field path; no invalid silent conversion |
| CMP-027 | Inspector: output binding | destination/path / edit | PUT draft binding | classified output projected safely |
| CMP-028 | Inspector: execution host | mode / edit | POST `/bindings/validate` | disallow remote/local mode not in manifest |
| CMP-029 | Inspector: timeout/retry | policy / edit | POST `/bindings/validate`; PUT draft | unsafe external-write retry blocked |
| CMP-030 | Inspector: boundary event | event type and attached node / edit | PUT draft BPMN | reject if unsupported semantic |
| CMP-031 | AMIE: browse rule | app/facts/version / view | GET `/amie/rules` | scope/version filter |
| CMP-032 | AMIE: bind rule | key/version/inputs / edit | POST `/bindings/validate`; PUT draft | mismatched facts deny |
| CMP-033 | AMIE: sample test | redacted fixture / `Rule.Test` | POST `/amie/rules/{key}/tests` | result marked simulation/test, no external writes |
| CMP-034 | Multi-instance: set collection | source/concurrency/failure mode / edit | PUT binding; POST validate | MVP only sequential verified |
| CMP-035 | Error path: add branch | error code/target / edit | PUT draft BPMN | deterministic error mapping |
| CMP-036 | Save Draft | XML, DI, bindings + ETag / edit | PUT `/workflow-drafts/{id}` | saved revision; 409 merge dialog |
| CMP-037 | Validate | draftId+revision / edit | POST `/workflow-drafts/{id}/validate` | issue list with element links; no publish if blockers |
| CMP-038 | Navigate to issue | bpmnElementId / view | local editor action | inspector selects field; accessible focus |
| CMP-039 | Test / dry run | fixture, mock/live DEV mode / `Workflow.Test` | POST `/workflow-drafts/{id}/test-runs` | result contains runRef/evidence; mock labeled |
| CMP-040 | Inspect test step | testRunId, stepId / test view | GET `/test-runs/{id}/events` | fact/side-effect status separated |
| CMP-041 | Request review | draft, control refs, ticket / edit | POST `/workflow-drafts/{id}/reviews` | frozen review snapshot |
| CMP-042 | Approve review | reviewer, evidence / `Workflow.Approve` | POST `/reviews/{id}/decisions` | server prevents self-approval if policy says so |
| CMP-043 | Publish version | approved review + ETag / publish | POST `/workflow-drafts/{id}/publish` | immutable version, digest, audit |
| CMP-044 | Mark active version | version + env binding / release | POST `/workflow-activations` | approved deployment only |
| CMP-045 | Execute manual CSV | uploadRef, draft/active version / `App.Execute` | POST `/workflow-runs` | 202 with runId and batch link |
| CMP-046 | Business: filter batch | owner/scope/status/page / `Business.View` | GET `/business/batches` | role-scoped counts, masked row data |
| CMP-047 | Business: inspect row | batchId, rowGuid / `Business.View` | GET `/business/batches/{id}/rows/{guid}` | reason and status; no raw credentials |
| CMP-048 | Business: download report | reportRef / `Report.Download` | GET `/reports/{id}` | authorization and export audit |
| CMP-049 | Monitor: live overlay | runId / `Runtime.View` | GET `/runs/{id}/snapshot`; SSE/SignalR | reconnect GET snapshot; no direct Kafka |
| CMP-050 | Monitor: activity details | runId/elementId / `Runtime.Detail` | GET `/runs/{id}/activities/{node}` | timeline, retry count, correlation |
| CMP-051 | Operator: pause | runId, reason, ETag / `Run.Pause` | POST `/runs/{id}/commands` | 202 pause requested; wait checkpoint |
| CMP-052 | Operator: resume | runId, reason / `Run.Resume` | POST `/runs/{id}/commands` | only valid Paused -> Running |
| CMP-053 | Operator: cancel | runId, reason / `Run.Cancel` | POST `/runs/{id}/commands` | cooperative; no undo of write |
| CMP-054 | Operator: restart | runId, reason, reconciliation / `Run.Restart` | POST `/runs/{id}/restarts` | NEW linked run ID, old audit retained |
| CMP-055 | Release: bind NAS endpoint | environment binding ref / `Release.Config` | PUT `/releases/{id}/bindings` | no raw PROD credentials in UI |
| CMP-056 | Release: preflight | immutable artifact digest / `Release.View` | POST `/releases/{id}/preflight` | roles/compatibility/approvals checked |
| CMP-057 | Release: activate | digest/ticket/approval / `Release.Activate` | POST `/releases/{id}/activations` | PROD denied without real controls |
| CMP-058 | Audit: reconstruct run | runId / `Audit.View` | GET `/audit/runs/{id}/events` | cross-service causality and version pins |
| CMP-059 | Audit: export evidence | scoped query / `Audit.Export` | POST `/audit/exports` | classified export, immutable export event |
| CMP-060 | Runbook: open instructions | runbook key/version / `Controls.View` | GET `/runbooks/{key}/versions/{v}` | exact operator procedure version |
| CMP-061 | API regression: suite | env, suite / `Test.View` | GET `/test-runs?tag=bpmn` | test evidence and failing cases |
| CMP-062 | Registry: new handler published | trusted service manifest / service identity | POST `/capability-manifests` | only approved registered operations visible |
| CMP-063 | Registry: inspect capability | key/version / app view | GET `/capabilities/{key}/versions/{v}` | data requirements, topic contracts, security |

## Mandatory test matrix per action

For each non-local action create an API regression that checks valid request, missing required field, bad schema type, cross-app/role denial, stale version/revision, timeout/retry, and audit event presence. For local canvas gestures test undo/redo, save round-trip, clipboard ID uniqueness, keyboard navigation, and import/export DI geometry. Keep v1.0's 107-control tests and map IDs to these contract families; **63 new entries do not mean 63 new backend services**.
