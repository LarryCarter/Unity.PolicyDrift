# AMIE Rule Descriptor and Typed Binding Contract

**Important:** AMIE is already substantially built. The following is an interoperability adapter target; do not replace its rule representation before JOB-00 source inspection.

- Rule descriptor: `ruleKey`, `version`, `owner`, `approvalState`, `inputSchema`, `outputSchema`, `dataClassification`, `requiredFacts`, `testFixtures`, `compatibleHost`, `dependencyHashes`.
- Evaluation: `Evaluate(existingAmieRequest, pinnedRule, executionContext)` returns typed `RuleOutcome` with `decision`, `reasonCode`, safe diagnostic, output DTO and version actually executed.
- Binding source kinds: `WorkflowInput`, `CurrentItem`, `PriorOperationOutput`, `PriorRuleOutput`, `ApprovedConstant`, `EnvironmentBinding`, `SecretReference` (server-only).
- Binding target: JSON schema path in next operation/rule. Both sides typed and classification checked at compilation and execution.
- Policy: AMIE may advise/update data transformation. It cannot override invocation authorization or a required external-write verification.

For DCMS, example rules `DCMS.AccountEligibility`, `DCMS.MapCustomAttributes`, and `DCMS.ShouldUpdate` map CSV custom attributes, account metadata, and approved update policy. Their actual names, DSL and serialized formats are **unverified**; configure these through existing AMIE authoring mechanisms.

**Acceptance:** changing approved AMIE configuration changes an operation's input/decision in a *new published package* with no BOB Core or CyberArk handler modification. A new rule version is pinned and produces audit evidence. Missing fact, incompatible type or restricted classification blocks publish. Embedded host evaluates locally and correctly.
