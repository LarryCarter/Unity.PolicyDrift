# Release and Authorization API Contract

## Principals and scope

Use bank SSO/service identities and real group/claim mapping. Server-side policies combine action + application/workflow/capability + environment + data domain + ownership. Do not trust caller-supplied roles in a JSON body. Read-only audit roles never get mutation endpoints. One author cannot approve and release their own package when bank separation of duties requires independent review.

## Workflow asset lifecycle

Editable draft -> review -> approved -> published immutable version -> activated for **new starts** -> retired. Pending run state is separate from definition state. Material change stores actor, UTC, meaning/diff and approved ServiceNow change ID where required. Resuming existing run uses exact pinned definition.

## Release package fields

`packageKey/version`, `digest`, `publisher`, `signedAtUtc`, workflow XML digests, exact AMIE rule locks, exact operation/schema locks, trigger/form hashes, control/runbook refs, test evidence refs, `change.serviceNowChangeId`, author/reviewer/release operator identity refs, logical environment bindings. **Never secrets**.

## Activation gate

`POST /releases/{id}/activate` (proposed) runs actual authorization, signed digest, approved change/control evidence, deployed compatibility, environment-binding completeness, bank approval and prior UAT evidence. A placeholder ticket or fake `approved=true` is rejected in PROD. Operation service accepts new package only after activation is recorded. Rollback changes which package new runs start; it does not reverse previously committed CyberArk changes.

## Security tests

Direct API call with no UI permission; forged Kafka actor; external binding injection; script/SQL in BPMN extension; stale version; cross-application resource; publication with missing rule; duplicate approval by same actor; modified digest after UAT; PROD unauthorized deploy; audit export classification leak.
