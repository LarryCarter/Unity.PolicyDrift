# BPMN XML + Unity Activity Binding Contract

## Data model

**Primary interchange:** OMG BPMN 2.0.2 XML including BPMN DI diagram layout. Use `unity` extension attributes or external signed binding document referencing the BPMN `id`. Do not store only renderer-private nodes and later hope to convert them reliably.

Example *conceptual* metadata for a standard BPMN service task:

```xml
<bpmn:serviceTask id="Task_GetAccount" name="Get account">
  <bpmn:extensionElements>
    <unity:operationBinding key="CyberArk.GetAccount" version="1.0"
                            execution="EmbeddedLocal" />
  </bpmn:extensionElements>
</bpmn:serviceTask>
```

This fragment requires proper BPMN and `unity` namespace declarations in a complete document; see `examples/` for full illustrative fixtures. `unity:operationBinding` is a **proposal**, not an existing runtime extension.

## Activity binding fields

`bpmnElementId`, `activityType`, `operationKey/version` OR `amieRuleKey/version` OR `subprocessKey/version`, `inputBindings`, `outputBindings`, `executionHost`, `timeoutPolicy`, `retryPolicy`, `auditPolicy`, `requiredPermission`. Disallow conflicting operation/rule references. All output bindings reference typed results.

## Compilation rules

Validate BPMN XML and DI; supported element subset; unique node IDs; reachability; token semantics; input/output graph; AMIE rule versions; operation contract versions; host compatibility; environment bindings; permission policy; external side-effect retry classification; no arbitrary scripts/method names/raw SQL; no mutable 'latest' references in published package.

## Result

Create immutable executable graph + dependency lock, tied to BPMN source digest. Core engine executes graph identically from central/embedded hosts; host adapters supply activity dispatch and persistence. Unsupported BPMN node -> publication rejection with `nodeId`, `errorCode`, user guidance.

## Regression fixtures

See `examples/DCMS_Batch_Illustrative_v0.7.bpmn` and `DCMS_Row_Illustrative_v0.7.bpmn`: source illustrations, NOT evidence of BOB execution/conformance. Add fresh executable tests for each engine element actually supported.
