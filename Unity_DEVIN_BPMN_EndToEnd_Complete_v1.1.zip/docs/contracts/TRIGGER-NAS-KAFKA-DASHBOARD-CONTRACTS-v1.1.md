# Contracts - Workflow Trigger, NAS/EF Data API, Messaging and Dashboard

**Proposal until repository integration test.** Applies to DCMS, Account Delete, Policy Drift and any new capability. Use SDK versioned manifests. Name `NAS` comes from project request; its expansion, actual model/endpoint names and ownership are **unverified**.

## Unified trigger envelope

```json
{
  "triggerType": "ManualCsv|AuthenticatedApi|AutoSysJob|KafkaMessage|Form|Timer",
  "triggerContractVersion": "1.0",
  "applicationKey": "DCMS",
  "workflowKey": "DCMS.BatchEnrichment",
  "workflowVersion": "1.0.0",
  "requestId": "source-generated-idempotency-key",
  "source": {"system": "BE|AutoSys|API", "sourceRunId": "source-specific-run-id"},
  "actorContextRef": "trusted-identity-context-ref",
  "input": {"batchRef": "approved-record-reference", "fileRef": "optional-managed-upload-reference"}
}
```

Sender supplies authenticated identity; backend generates canonical `runId` and records definition, rules, capability version pins. `202 Accepted` includes run ID and business batch link; does **not** mean processing completed.

## NAS/EF Data API

**Do not assume NAS means network-attached storage.** The request names a `NAS API Database (EF backend and API)` but gives no verified controller URLs, EF entities, ownership or keys. DEVIN first inspects the existing NAS/API repository, Swagger/OpenAPI and EF migrations. Until then these are **logical** operation names, not code contracts:

| Logical registered operation | Inputs | Outputs | Storage behavior | Security |
|---|---|---|---|---|
| `NAS.StageBatch@1.0` | authorized fileRef, declared data contract | batchId, stagedCount, rejectedCount | owning EF service inserts batch and row GUIDs transactionally | `Data.Batch.Stage` |
| `NAS.GetBatch@1.0` | batchId | scoped batch metadata | owned EF query via API | `Data.Batch.Read` |
| `NAS.GetRowsPage@1.0` | batchId, cursor, maxPageSize | typed page of rows + cursor | server-side ordered EF query, no table name input | `Data.Batch.Read` |
| `NAS.MarkRowOutcome@1.0` | batchId, rowGuid, expectedVersion, outcome | write receipt | idempotent EF update/concurrency check | `Data.Row.Update` |
| `NAS.GetBatchSummary@1.0` | batchId | status counts and report refs | aggregate/projection | `Data.Batch.Read` |
| `NAS.GetPolicyBaseline@1.0` | normalized policyId | baseline metadata and version | only if existing NAS owns policy baseline | policy read |
| `NAS.SavePolicyRunResult@1.0` | sourceRunId, policyId, status, diffRef | write receipt | only if authorized policy-data owner | policy write |

An actual NAS service may not own all of these models; map each function to the real data owner, **not** a generic SQL proxy. EF Core DbContext remains in the owning service; other capabilities call typed APIs. No unrestricted SQL/filter/expression in BE or Kafka. Do not create a second database for the same business ownership without review.

## Capability operation descriptor mandatory fields

`capabilityKey`, `operationKey`, `contractVersion`, `inputSchema`, `outputSchema`, `dataOwner`, `permissions`, `classification`, `sideEffect`, `allowedHosts`, `timeoutPolicy`, `idempotencyPolicy`, `reconciliationPolicy`, `auditCategory`, `amieFactSchemaRefs`, `logicalMessageContracts`, `health/availability`, `deprecationState`, `approvedInEnvironments`.

## Kafka contracts

Logical commands: `Unity.WorkflowInvokeRequested.v1`, `CyberArk.ProcessBatchRequested.v1`, `CyberArk.DeleteAccountRequested.v1` (guarded), `Email.ReportRequested.v1`, `Data.BatchStageRequested.v1` (only when truly remote). Logical outcomes: `.Completed.v1`, `.Failed.v1`, `.RequiresReconciliation.v1`, plus `Unity.BusinessProgressChanged.v1`. Physical topic names are environment bindings assigned by approved infrastructure. Consumers must check schema, producer, target handler, permission, run correlation, inbox key and idempotent results; use outbox for reliable messages.

**No raw CSV, password, large file or arbitrary CyberArk account object in Kafka.** Send references and safe metadata. Partition by business aggregate ID when ordering matters (e.g., batchId). Correlation ID identifies entire run; causation/message ID links individual decisions.

## Dashboard projection

`BusinessBatchSummary` returns `{batchId,runId,total,pending,inProgress,succeeded,failed,skipped,requiresReview,completedAtUtc,lastUpdatedAtUtc,reportRef}`. Invariants: sum of row-status buckets equals total; terminal statuses `succeeded+failed+skipped+requiresReview` differ from overall process `Completed` until reporting/email policy finishes; distinguish rule-pass from external-write-confirmed. Internal row errors must have reason code and safe error message. Dashboard receives progress from backend projection, never the Kafka broker.

## AutoSys-to-Unity adapter

A supported AutoSys integration can initially use a bank-approved scheduler command/job that calls `POST /workflow-triggers/autosys` with authenticated job identity, `jobName`, `schedulerInstance`, `sourceRunId`, `scheduledAtUtc`, `inputRef`, `idempotencyKey`; Unity validates job allowlist and creates/returns run. Retry of same key returns same run ID. Full AutoSys AEWS REST adapter is a distinct, optionally later capability and depends on installed version and bank security approval. Official vendor reference: https://knowledge.broadcom.com/external/article/445384/rest-api-and-swagger-documentation-for.html.

## Account delete contract (HIGH IMPACT)

`CyberArk.DeleteAccount@version` should be a narrowly scoped handler with `accountId`, target environment, expected revision/verification token, approved request/ref, dryRun flag, authorization context, idempotency key. No delete from free-form account path. Required control: verify identity and current state; check policy eligibility; approved named actor(s) if required; show dry-run impact; human/operations approval for destructive action; perform via approved CyberArk API; confirm result; record immutable evidence; uncertain outcome does not retry blindly. Demo should use a safe mock or approved non-production test account unless explicit authorized scope exists.
