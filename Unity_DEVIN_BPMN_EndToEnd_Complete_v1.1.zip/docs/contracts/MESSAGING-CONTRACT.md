# Kafka Message / Subscription Contract

**Canonical envelope:** use `history/v0.7/contracts/Kafka_Envelope_Sample_v0.7.json` as baseline. `examples/Kafka_Command_Proposed.json` is a minimal redacted example.

Message `messageType`, `schemaVersion`, `messageId`, `correlationId`, `causationId`, `traceparent`, `runId`, `activityId`, application/workflow version, target capability/operation version, command id, idempotency key, payload or payload ref, and classification must survive service boundaries.

### Published contracts versus broker resources

Capability publishes a declared `MessageContractDescriptor` with `logicalTopicBinding`, `schemaKey/version`, consumer group binding, partition strategy, keying, auth policy and retention/classification. Platform Operations provisions actual topic, ACL, service account and secret reference for each environment. Service cannot create arbitrary subscriptions because an unreviewed manifest says so.

### Commands and outcomes

- `unity.capability.command.v1` -> request a single registered handler or approved embedded BOB workflow.
- `unity.capability.outcome.v1` -> correlate success, rejection, confirmed failure or uncertain outcome to command.
- `unity.process.status.v1` -> optional update for projections (authoritative data still SQL-backed).
- `unity.notification.requested.v1` -> Email Capability command; delivery outcome independent from prior business write.
- Operator commands arrive via authorized API and may be internally dispatched through durable commands; do not accept raw browser Kafka.

### Consumer behavior

Validate transport principal, schema, contract version, dispatch identity, idempotency, scopes and run state. Record inbox receipt and audit, execute only compiled known handlers, outbox outcome. If write result is uncertain, suspend/reconcile; do not replay blindly. Duplicated outcome must not advance BOB twice. Cross-batch concurrent processing must not violate account-level safety or sequential DCMS behavior.

### Test examples

Duplicate same command ID; same payload different ID; malformed schema; old schema; unauthorized producer; poison message; retry after consumer crash; late completion after cancel; broker temporarily offline; correlation collision; oversized data ref.
