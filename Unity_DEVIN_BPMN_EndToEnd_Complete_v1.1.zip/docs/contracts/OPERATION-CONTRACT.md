# Capability Operation Contract v0.8 — Proposed and Testable

## Why this contract exists

A developer implements an operation once; the SDK advertises it, BE renders schema-driven configuration, BOB selects a stable operation key, AMIE supplies typed rules, and the service executes under authorized identity. This is the most important compatibility surface to freeze after repository discovery.

## Proposed shape

`CapabilityManifest` = signed/trusted, versioned description of one service's operations; `OperationDescriptor` = stable key/version, schemas, permissions, hosts, side effect, retry/reconcile policy, AMIE requirements, topic contracts, audit code, fixture IDs. `OperationInvocation` = validated typed inputs and execution context. `OperationOutcome` = result or structured safe failure. Do not expose CLR class names to BE.

### C# conceptual interfaces (not current code)

`/Unity.Capabilities.Contracts/Execution/UnityExecutionContext.cs`

```csharp
public sealed record UnityExecutionContext(
    string ApplicationKey, string WorkflowKey, string WorkflowVersion,
    Guid RunId, string ActivityId, string CorrelationId, string CommandId,
    string ActorContextRef, string PackageDigest, string IdempotencyKey,
    string? BatchId, Guid? RecordGuid, string? TraceParent);
```

`/Unity.Capabilities.Hosting/Execution/IUnityOperationHandler.cs`

```csharp
public interface IUnityOperationHandler<TInput, TOutput>
{
    Task<TOutput> ExecuteAsync(TInput input, UnityExecutionContext context, CancellationToken ct);
}
```

`/Unity.Capabilities.Contracts/Execution/OperationOutcome.cs`

```csharp
public enum OperationDisposition { Succeeded, NoChange, Rejected, Failed, UnknownExternalOutcome }
public sealed record OperationOutcome<T>(
    OperationDisposition Disposition, string ReasonCode, string SafeReason,
    T? Result, string? ExternalOperationRef, string? ResultHash);
```

Do not use the enum above as a full DCMS row status—business row projections also have Pending, InProgress and Skipped. The exact DTOs should follow repository style and existing AMIE conventions.

## Descriptor required fields

| Name | Purpose | Test |
|---|---|---|
| `operationKey` + `contractVersion` | Stable capability identity | Duplicate version rejected |
| `inputSchema`, `outputSchema` | Typed composition and UI | Missing or wrong field rejected |
| `permission` and scopes | Backend authorization | Unauthorized direct invocation denied |
| `executionModes` | Local or Kafka use | Unsupported mode rejected |
| `sideEffect` | Read / InMemoryTransform / ExternalWrite | Write requires idempotency policy |
| `retryPolicy` | SafeRetry / RequiresKey / ReconcileBeforeRetry / NeverAutoRetry | Duplicate and uncertain tests |
| `amieRequirements` | Required rule IDs / data types where appropriate | Missing rule/version rejected |
| `subscriptions`, `publications` | Logical Kafka contracts | Unknown topic binding rejected |
| `auditCategory`, `dataClassification` | Evidence and masking | Secrets never logged |
| `testFixtures` | Deterministic regression | CI exercise success + denial |

## Activation is two phase

`Service startup: compiled handler registered and metadata generated` -> `Deploy/publish: verified publisher registers manifest in Unity Registry` -> `Operational readiness: approved environment bindings + broker permissions + healthy version` -> `BOB calls after server-side policy checks`.

Never make `registered` mean `approved` or `available` by itself.

## Compatibility rule

Allow additive optional fields with stable contract when proven backward compatible. Any removed/renamed required field, changed meaning, changed authorization behavior or changed side-effect contract requires explicit new version and fixture. Compilation fails on unresolved operation dependency.

## Example manifest

See `examples/Capability_Manifest_Proposed.json` (draft, unsigned) and `history/v0.7/contracts/Capability_Manifest_Sample_v0.7.json` (original). DEVIN must adjust the schema to actual current library interfaces before implementing generators or runtime.
