# Evidence Required Before Coding or Claiming a Release

DEVIN must answer these from repository/owner evidence during JOB-00 or mark as blockers:

1. What are **actual** AMIE libraries/classes for rule evaluation, validation, configuration version and persistence? Are rule descriptors available already?
2. What BOB source is implemented already? What BPMN parser/designer library is **approved**? Is the BOB core a blank project or incomplete runtime?
3. Which Unity capabilities currently exist, with which public DTOs, DI, Kafka topics and security? Can a CyberArk account be updated safely and idempotently?
4. What is actual DCMS CSV format, table schema and row-GUID semantics? Which service owns staging and report results?
5. Which Kafka .NET client/schema registry/outbox conventions and broker ACL provisioning are approved? Are topics already established?
6. Which MSSQL versions/provider/data access/migration conventions and audit controls are approved? Which service identity may append audit?
7. What BE Blazor hosting mode, state management, component libraries and auth providers already exist? Does it already have workflow or approval UI?
8. Which exact bank CAs, release checks, ServiceNow authorization process, approvers, audit retention and SIEM integrations apply? Who signs off?
9. Which CI/CD tools and automated test frameworks are approved and usable before November 30?
10. What two applications are realistic to demo with approved data and credentials? Who provides UAT acceptance?

For each answer record: evidence URL or actual file path, owner, last verified UTC, proposed code change impact, and unresolved risks. Avoid putting credentials/secrets into the document.
