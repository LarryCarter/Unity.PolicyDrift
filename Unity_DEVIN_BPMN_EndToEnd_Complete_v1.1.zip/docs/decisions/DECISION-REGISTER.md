# Decision Register — Preserve User Decisions and Open Questions

| ID | Status | Decision or issue | Rationale / next proof |
|---|---|---|---|
| U-001 | User-established | Unity configuration-first; application cases stay outside BOB Core | Reuse across CVIS workloads |
| U-002 | User-established | Existing AMIE mostly written; do not rebuild | JOB-00 adapter reconnaissance |
| U-003 | User-established | BOB shared interpreter with central and embedded hosts | Avoid per-step network calls |
| U-004 | User-established | BOB supports BPMN 2.0 interchange | Explicit subset for MVP, no false full conformance |
| U-005 | User-established | BOB persistence MSSQL only | Not a requirement for every capability's business data |
| U-006 | User-established | BE is Blazor, visual and operational | API-first; strong designer |
| U-007 | User-established | Microservices publish reusable operations + AMIE requirements | SDK + registry, approval required |
| U-008 | User-established | Kafka interservice commands/outcomes; Email Capability independent | No email module inside BOB |
| U-009 | User-established | Audit, ServiceNow change ID, roles, runbooks, process controls | Exact bank control IDs pending |
| U-010 | User-established | Operations promotes versioned config without developer PROD access | Signed package / approved binding process |
| U-011 | User-established | DCMS process and one/two application demos by Nov 30 | DCMS is workload acceptance, not engine special case |
| P-012 | Proposed | API + operation descriptor shape and SDK assemblies | Test against current namespaces |
| P-013 | Proposed | Sequential multi-instance + durable Kafka wait in initial BPMN subset | DCMS pilot need |
| P-014 | Proposed | First-party Blazor SVG/JS editor if no approved library exists | Avoid approval delay; verify existing UI components |
| P-015 | Proposed | Append-only audit event table and state projection | Verify bank database audit policy |
| P-016 | Proposed | Workflow Draft -> Review -> Approved -> Published -> Active -> Retired | Verify controls and ownership |
| P-017 | Proposed | Role permission matrix | Map to real SSO/enterprise groups |
| X-018 | Verify | Real AMIE interface/version/DSL | JOB-00 source trace |
| X-019 | Verify | Existing CyberArk operations, API semantics, idempotency and approved test accounts | JOB-11 inventory |
| X-020 | Verify | Installed Kafka library, topics, ACL and outbox conventions | JOB-06 |
| X-021 | Verify | Approved BPMN designer component/paid library | JOB-08 design spike |
| X-022 | Verify | Which DCMS store owns batch/rows and upload | JOB-10 |
| X-023 | Verify | Actual Wells Fargo CA/change procedures, role groups and evidence retention | JOB-14 and bank control owner |
| X-024 | Verify | Actual repository build/deployment environment and CI scripts | JOB-00 |
| F-025 | Refined by v1.1 | Mid-flight migration, advanced BPMN and full ServiceNow deferred; limited approved AutoSys trigger is now P1 | Keep full AEWS adapter separate from MVP |
| U-026 | User-established v1.1 | Reusable BE/Blazor UI components and complete configurable BPMN workflow authoring from UI to backend | UI 13-18 and CMP-001..063 |
| U-027 | User-established v1.1 | NAS EF backend/API is a desired registered data capability | Actual NAS owner/controller/contracts unverified |
| U-028 | User-established v1.1 | Account Delete and AutoSys Policy Drift are illustrative initial application/workflow targets | Safe scope and existing legacy code must be verified |
| P-029 | Proposed v1.1 | AutoSys schedule trigger via approved command -> secured Unity trigger API first | Avoid assuming AEWS access; P1 |
| P-030 | Proposed v1.1 | Full BPMN palette visible but unsupported executable nodes fail publication | Separate visual and runtime conformance |
| X-031 | Verify v1.1 | Policy Drift original SQL, PolicyId sanitizer, ZIP/INI parser, baseline EF ownership | Compare with legacy acceptance oracle |
| X-032 | Verify v1.1 | Delete approval/retention policy and CyberArk delete operation | No PROD destructive demonstration absent approval |

## Change rule

If DEVIN changes any proposed contract or discovers a conflict, add a dated ADR decision with: existing evidence, alternatives, impacts, revised API/fixture, regression changes, owner, approval state. Do not quietly rename a contract in one service only.
