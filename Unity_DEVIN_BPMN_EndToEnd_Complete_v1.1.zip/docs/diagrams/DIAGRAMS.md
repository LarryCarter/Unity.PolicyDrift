# Unity BPMN Designer - Editable Diagram Library

**Diagrams:** 18. All Mermaid sources are maintained as `.mmd` and rendered inline here for Markdown viewers that support Mermaid. The diagram is a specification, not live runtime proof.

## 01 Platform Topology
**Source:** [01-platform-topology.mmd](01-platform-topology.mmd)

```mermaid
flowchart TD
  BE[Blazor Business Enablement] --> API[Unity Backend APIs]
  API --> REG[Capability Registry]
  API --> BOB[Central BOB BPMN Core]
  API --> AUD[Audit / Control Services]
  BOB --> AMIE[AMIE Rule Adapter]
  BOB --> KA[Kafka Command / Outcome]
  KA --> CAP[Capability Service Hosting SDK]
  CAP --> LOCAL[Embedded BOB and AMIE]
  LOCAL --> NAS[NAS / Data EF API]
  LOCAL --> EPV[CyberArk Operations]
  CAP --> EMAIL[Email / Reporting]
  BOB --> SQL[(MSSQL BOB State)]
  AUD --> ASQL[(MSSQL Audit Events)]
  CAP --> EVT[Events / Traces]
  EVT --> AUD
  API --> DASH[Business/Run Projections]
```

## 02 Ui Workflow Creation
**Source:** [02-ui-workflow-creation.mmd](02-ui-workflow-creation.mmd)

```mermaid
sequenceDiagram
  autonumber
  actor Author
  participant BE as BE Workflow Wizard/Canvas
  participant API as Workflow Catalog API
  participant REG as Capability Registry
  participant AMIE as AMIE Rule Catalog
  participant VAL as BPMN Compiler/Validator
  participant DB as MSSQL Definition Store
  Author->>BE: Create draft under application
  BE->>API: POST /workflow-drafts
  API->>DB: Save draft and ETag
  DB-->>BE: draftId/revision
  Author->>BE: Add service task + select operation
  BE->>REG: GET typed operation descriptor
  REG-->>BE: schema/hosts/policy
  Author->>BE: Bind required fields
  BE->>AMIE: Browse rule descriptor
  AMIE-->>BE: fact/output schemas
  BE->>VAL: POST /bindings/validate
  VAL-->>BE: field issues or valid
  Author->>BE: Save BPMN XML+DI
  BE->>API: PUT /workflow-drafts with If-Match
  API->>DB: Save new revision and audit edit
  Author->>BE: Validate + test
  BE->>VAL: Compile executable graph
  VAL-->>BE: issues/test-run reference
  Author->>BE: Request review/publish
  BE->>API: Submit approved revision
  API->>DB: Immutable version + digest and audit
  API-->>BE: version and release readiness
```

## 03 Dynamic Node Binding
**Source:** [03-dynamic-node-binding.mmd](03-dynamic-node-binding.mmd)

```mermaid
flowchart LR
  PICK[Select BPMN Service Task] --> KEY[Choose Approved operationKey@version]
  KEY --> MAN[Fetch OperationDescriptor]
  MAN --> SCHEMA[Render SchemaField / BindingPicker]
  SCHEMA --> TYPE{Typed input compatible?}
  TYPE -->|No| ERR[Field error / jump to source]
  TYPE -->|Yes| HOST[Choose allowed host and retry policy]
  HOST --> AUTH[Check permission, data ownership, audit]
  AUTH --> VALID[Compile workflow binding]
  VALID --> SAVE[Save draft; invalidate prior validated badge]
```

## 04 Editor State And Versions
**Source:** [04-editor-state-and-versions.mmd](04-editor-state-and-versions.mmd)

```mermaid
stateDiagram-v2
  [*] --> NewDraft
  NewDraft --> Dirty: editor change
  Dirty --> SavedDraft: Save + ETag
  SavedDraft --> Dirty: edit
  SavedDraft --> Validated: compile + test
  Validated --> Dirty: any change
  Validated --> InReview: submit review
  InReview --> Approved: approved evidence
  InReview --> Dirty: revisions requested
  Approved --> Published: immutable version + digest
  Published --> Active: authorized release
  Active --> Retired: authorized retirement
  Active --> NewDraft: start next version
```

## 05 Canvas Events To Blazor
**Source:** [05-canvas-events-to-blazor.mmd](05-canvas-events-to-blazor.mmd)

```mermaid
sequenceDiagram
  actor Author
  participant JS as First-party Canvas JS
  participant BZ as Blazor BpmnCanvas
  participant STATE as Draft Editor State
  participant API as Workflow API
  Author->>JS: Drag task / pan / connect
  JS->>JS: Local pointer gesture preview
  JS->>BZ: Commit add/move/edge on pointer-up
  BZ->>STATE: Patch graph XML+DI and undo history
  STATE-->>BZ: Dirty + property inspector refresh
  Author->>BZ: Save draft
  BZ->>API: PUT draft + revision
  API-->>BZ: New ETag or 409/412 conflict
  BZ-->>Author: Saved or compare/resolve conflict
```

## 06 Csv Upload To Dashboard
**Source:** [06-csv-upload-to-dashboard.mmd](06-csv-upload-to-dashboard.mmd)

```mermaid
sequenceDiagram
  autonumber
  actor U as Business User
  participant UI as BE Blazor
  participant UP as Upload API
  participant NAS as NAS / Data EF API
  participant BOB as Central BOB
  participant PROJ as Business Projection
  participant PUSH as Auth SSE / SignalR
  U->>UI: Upload CSV and click Start
  UI->>UP: POST file upload
  UP->>NAS: StageBatch(fileRef)
  NAS-->>UP: batchId + row GUIDs
  UP->>BOB: Start published workflow
  UP-->>UI: 202 accepted runId and batchId
  BOB-->>PROJ: Workflow status event
  NAS-->>PROJ: Row outcomes / counts
  PROJ->>PUSH: Changed summary and sequence
  PUSH->>UI: Authorized progress notification
  UI->>PROJ: GET authoritative snapshot on reconnect
  UI-->>U: Progress counts, row reasons, report link
```

## 07 Dcms Central Embedded
**Source:** [07-dcms-central-embedded.mmd](07-dcms-central-embedded.mmd)

```mermaid
flowchart TD
  Start[Manual CSV / authenticated API] --> Stage[NAS/Data EF API StageBatch]
  Stage --> Top[Central BOB DCMS.BatchEnrichment]
  Top --> Dispatch[Kafka ProcessBatch command]
  Dispatch --> Emb[Embedded CyberArk BOB ProcessRows]
  Emb --> Row[Get next staged row]
  Row --> Account[CyberArk GetAccount]
  Account --> Rule[AMIE eligibility + mapping]
  Rule --> Allow{ALLOW + changed?}
  Allow -->|Yes| Update[Apply in memory + AddOrUpdate]
  Allow -->|No| Skip[Skip/reject with reason]
  Update --> Save[NAS MarkRowOutcome]
  Skip --> Save
  Save --> More{More rows?}
  More -->|Yes| Row
  More -->|No| Done[Kafka outcome to central BOB]
  Done --> Rep[Reporting Capability]
  Rep --> Mail[Email Capability]
  Done --> Dash[BE Dashboard projection]
```

## 08 Nas Ef Api Data Access
**Source:** [08-nas-ef-api-data-access.mmd](08-nas-ef-api-data-access.mmd)

```mermaid
sequenceDiagram
  participant BE as BE Schema Inspector
  participant REG as Registry
  participant BOB as BOB Service Task
  participant K as Kafka / Approved API Client
  participant NAS as NAS Data Capability API
  participant EF as EF Core DbContext
  participant SQL as Owned MSSQL Data
  BE->>REG: Get NAS operation schema
  REG-->>BE: Typed fields and policy
  BOB->>K: Invoke approved typed NAS operation
  K->>NAS: Authenticated operation call
  NAS->>NAS: Validate app/data scope
  NAS->>EF: Execute owned repository operation
  EF->>SQL: Parameterized query or transaction
  SQL-->>EF: Database result
  EF-->>NAS: Typed entity result
  NAS-->>BOB: Typed response + audit/correlation
```

## 09 Account Delete Safety
**Source:** [09-account-delete-safety.mmd](09-account-delete-safety.mmd)

```mermaid
sequenceDiagram
  actor Req as Authorized Requester
  participant BE as BE Account Delete Form
  participant BOB as Central BOB
  participant AMIE as AMIE Eligibility
  participant CTRL as Control Approval
  participant C as CyberArk Capability
  participant EPV as CyberArk API
  Req->>BE: Request deletion with reason/ticket
  BE->>BOB: Create scoped deletion workflow
  BOB->>C: GetAccount + verify current state
  C-->>BOB: Account snapshot
  BOB->>AMIE: Check eligibility/retention
  AMIE-->>BOB: Eligible/denied + explanation
  BOB->>CTRL: Request distinct approval if required
  CTRL-->>BOB: Correlated approval decision
  alt Denied or changed state
    BOB-->>BE: Rejected with audit
  else Authorized and state stable
    BOB->>C: Guarded DeleteAccount (idempotency key)
    C->>EPV: Approved DELETE API action
    EPV-->>C: Outcome
    C->>EPV: Read to verify deletion
    C-->>BOB: Confirmed / Unknown / Failed
    BOB-->>BE: Final status and evidence
  end
```

## 10 Autosys Job Trigger
**Source:** [10-autosys-job-trigger.mmd](10-autosys-job-trigger.mmd)

```mermaid
sequenceDiagram
  autonumber
  participant SCH as AutoSys Scheduled Job
  participant SCRIPT as Approved Trigger Script/Adapter
  participant API as Unity Trigger API
  participant BOB as Central BOB
  participant AUD as Audit/Run Projections
  SCH->>SCRIPT: Execute job with jobName/sourceRunId
  SCRIPT->>API: POST /workflow-triggers/autosys (auth)
  API->>API: Verify job allowlist/scope, dedupe sourceRunId
  alt Duplicate
    API-->>SCRIPT: Existing runId
  else New job run
    API->>BOB: Start pinned PolicyDrift workflow
    BOB->>AUD: Created/run correlation
    API-->>SCRIPT: 202 accepted + runId
  end
  BOB-->>AUD: Completion/event outcome
  Note over SCH,AUD: AutoSys completion feedback is separate and environment-specific
```

## 11 Policy Drift Zip Baselines
**Source:** [11-policy-drift-zip-baselines.mmd](11-policy-drift-zip-baselines.mmd)

```mermaid
flowchart TD
  Auto[AutoSys Trigger] --> Fetch[EPV policy ZIP / API download]
  Fetch --> Valid{Download/ZIP valid?}
  Valid -->|No| Fail[Fail batch + audit alert]
  Valid -->|Yes| Parse[Recursive nested ZIP + INI parse]
  Parse --> Next[Next policy entry]
  Next --> Norm[Normalize PolicyId using existing function]
  Norm --> Id{Valid PolicyId?}
  Id -->|No| Ex[Exclude with reason + evidence]
  Id -->|Yes| Baseline[EF owned API GetBaseline]
  Baseline --> Compare[AMIE compare normalized fields]
  Compare --> Result{Classification}
  Result -->|NO_DRIFT| No[Record unchanged]
  Result -->|DRIFT| Drift[Persist diff evidence]
  Result -->|MISSING_BASELINE| Missing[Record missing baseline]
  Ex --> More{More policies?}
  No --> More
  Drift --> More
  Missing --> More
  More -->|Yes| Next
  More -->|No| Report[Aggregate, email, dashboard]
```

## 12 Hygiene Safe Remediation
**Source:** [12-hygiene-safe-remediation.mmd](12-hygiene-safe-remediation.mmd)

```mermaid
flowchart TD
  A[Scheduled/API/Manual Trigger] --> B[Fetch eligible accounts]
  B --> C[Get CyberArk account/safe]
  C --> D[AMIE evaluates placement policy]
  D --> E{Violation?}
  E -->|No| F[Record compliant]
  E -->|Yes| G[Suggest safe + reason]
  G --> H{Approval and policy?}
  H -->|No| I[Finding only]
  H -->|Yes| J[CyberArk MoveAccount]
  J --> K[Verify actual safe]
  F --> L[Business result + audit]
  I --> L
  K --> L
  L --> M[Report + dashboard]
```

## 13 Kafka Durable Execution
**Source:** [13-kafka-durable-execution.mmd](13-kafka-durable-execution.mmd)

```mermaid
sequenceDiagram
  participant BOB as Central BOB
  participant SQL as MSSQL State + Outbox
  participant K as Kafka Broker
  participant IN as Capability Inbox
  participant C as Embedded BOB/Handler
  participant EPV as External CyberArk API
  BOB->>SQL: Commit PendingCommand + outbox + wait correlation
  SQL-->>K: Reliable outbox dispatch
  K->>IN: Deliver command (possible redelivery)
  IN->>IN: Verify producer, schema and idempotency
  alt First time
    IN->>C: Run local handler + pinned AMIE
    C->>EPV: External operation if approved
    EPV-->>C: Confirmed or uncertain outcome
    C->>IN: Store result, emit outbox outcome
  else Duplicate
    IN-->>K: Ack/replay prior outcome
  end
  IN-->>K: Outcome event
  K->>BOB: Correlate to waiting activity
  BOB->>SQL: Persist completion + audit exactly once per logical event
```

## 14 Run Operator Control
**Source:** [14-run-operator-control.mmd](14-run-operator-control.mmd)

```mermaid
stateDiagram-v2
  [*] --> Created
  Created --> Running
  Running --> PauseRequested: authenticated reasoned command
  PauseRequested --> Paused: checkpoint reached
  Paused --> Running: authorized Resume
  Running --> CancelRequested: reasoned Cancel
  Paused --> CancelRequested: reasoned Cancel
  CancelRequested --> Cancelled: no new activities
  Running --> Completed
  Running --> Failed
  Cancelled --> NewLinkedRun: authorized Restart + reconcile
  Failed --> NewLinkedRun: authorized Restart + reconcile
  NewLinkedRun --> Running
```

## 15 Release Approved Package
**Source:** [15-release-approved-package.mmd](15-release-approved-package.mmd)

```mermaid
flowchart TD
  D[DEV Draft + BPMN + AMIE + bindings] --> V[Validate schemas/operations/rules/BPMN]
  V --> T[DEV/API regression + negative controls]
  T --> P[Immutable package digest + version]
  P --> U[UAT deploy exact artifact with UAT bindings]
  U --> E[UAT evidence + control review]
  E --> SN[ServiceNow change and authorized approvals]
  SN --> OPS{Operations approval valid?}
  OPS -->|No| BLOCK[Block PROD activation]
  OPS -->|Yes| PROD[Ops activates same digest + approved PROD bindings]
  PROD --> AUD[Audit change actor / UTC / environment / digest]
```

## 16 Capability Service Onboarding
**Source:** [16-capability-service-onboarding.mmd](16-capability-service-onboarding.mmd)

```mermaid
sequenceDiagram
  actor DEV as Capability Developer
  participant SVC as Capability Microservice
  participant SDK as Unity Capability SDK
  participant REG as Trusted Capability Registry
  participant BE as BE Catalog/Composer
  participant BOB as BOB Dispatcher
  DEV->>SVC: Implement typed operation handler
  SVC->>SDK: Discover trusted compiled handlers on startup
  SDK->>SDK: Validate unique operation key/schema/permissions
  SDK-->>SVC: Local DI dispatcher and manifest
  Note over SVC,REG: Service deployment approval is separate from local discovery
  SVC->>REG: Publish manifest using trusted deploy identity
  REG-->>BE: Approved operationKey@version, schemas, hosts
  BE->>BE: Generate dynamic inspector and typed bindings
  BE->>BOB: Publish immutable workflow binding
  BOB->>SVC: Invoke approved operation through local handler or Kafka
```

## 17 Workflow Authoring Complete
**Source:** [17-workflow-authoring-complete.mmd](17-workflow-authoring-complete.mmd)

```mermaid
flowchart TD
  App[Select app in BE] --> Create[New workflow draft or template]
  Create --> Trigger[Select trigger CSV / form / API / AutoSys]
  Trigger --> Data[Bind NAS/Data source + typed schema]
  Data --> Catalog[Choose approved capability operations]
  Catalog --> Canvas[Draw BPMN nodes + DI]
  Canvas --> Rule[Bind AMIE rules/typed output]
  Rule --> Validate[Backend compile + validation]
  Validate -->|Invalid| Canvas
  Validate -->|Valid| Test[DEV test bench fixtures + failure injection]
  Test -->|Fail| Canvas
  Test -->|Pass| Review[Review/change ticket/approve]
  Review --> Publish[Publish immutable version]
  Publish --> Release[UAT/PROD package promotion]
  Release --> Execute[Run by BE/API/AutoSys/Kafka]
  Execute --> Monitor[Business dashboard + BPMN overlay]
  Monitor --> Audit[Reconstruct events/control evidence]
```

## 18 Business Dashboard Reconnect
**Source:** [18-business-dashboard-reconnect.mmd](18-business-dashboard-reconnect.mmd)

```mermaid
sequenceDiagram
  participant CAP as Capability Handler
  participant K as Kafka Outcome
  participant BOB as BOB State
  participant PROJ as Business Projection
  participant PUSH as SignalR/SSE Gateway
  actor UI as Browser Dashboard
  CAP->>K: Typed row outcome (safe metadata)
  K->>BOB: Correlated task outcome
  K->>PROJ: Business progress changed
  PROJ->>PUSH: sequence N / batchId
  PUSH-->>UI: Scope-filtered update hint
  UI->>PROJ: GET batch snapshot (ETag)
  PROJ-->>UI: Authoritative counts and reasons
  Note over UI,PROJ: On reconnect or gap, always GET snapshot
```
