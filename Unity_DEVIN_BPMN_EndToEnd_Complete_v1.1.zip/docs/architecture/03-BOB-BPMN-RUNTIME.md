# 03 — BOB BPMN 2.0 Core and Host Design

**Status:** [USER] BPMN 2.0, central/embedded shared engine; [PROPOSED] executable subset and contracts. Reference: https://www.omg.org/spec/BPMN/2.0.2 . OptimaJet documentation is for feature discovery, not code/license substitution.

## Boundaries

- `BOB.Core`: BPMN XML parse/serialize, graph compiler, token/state semantics, activity scheduler, typed variables, subprocess/call-activity semantics, supported-element validation. No Kafka, SQL, Blazor or CyberArk hard dependency.
- `BOB.Contracts`: definition package/operation binding/host interfaces; durable process/activity state DTOs.
- `BOB.Embedded`: in-process host, in-memory or **approved durable** persistence, local DI operation dispatcher and existing AMIE integration. Same core interpreter.
- `BOB.Central`: durable orchestrator with MSSQL provider, Kafka activity dispatcher and correlated outcome resumes.
- `BOB.Persistence.MSSQL`: only BOB persistence provider for MVP, migrations, leases and optimistic concurrency.

## Executable BPMN subset for November (proposed)

| Element | P0 planned behavior | Must prove |
|---|---|---|
| Start/End | Create/terminate run with expected events | One start, terminal state |
| Sequence flow | Follow validated directed edges | Reachability, no duplicate transitions |
| Service task | Invoke approved capability operation | Schema, auth, retry boundaries |
| Business rule task | Invoke existing AMIE evaluator | Typed decision + pinned rule version |
| Exclusive gateway | Select exactly one viable route | No match/default/multiple match semantics |
| Embedded subprocess/call activity | Execute reusable version-pinned workflow | Input/output propagation, error propagation |
| Sequential multi-instance | DCMS row-by-row invocation | Exactly one active row per batch, progress |
| Cross-service wait | Persist command pending then resume on event | Correlation, timeout, restart recovery |
| Error terminal | Record failed/skipped/reconciliation state | Truthful outcome and audit |

**Deferred unless pilot requires:** parallel gateway/join, parallel multi-instance, boundary interrupts, rich human task modeling, signal propagation, compensation, arbitrary scripts, complete BPMN 2.0 conformance and migrating in-flight runs to new definition versions. Every unsupported executable element **fails publication** with precise problem location. A valid BPMN XML import alone is not a successful runtime test.

## Compiler and runtime pipeline

1. BE saves a draft BPMN 2.0 XML document with BPMN DI layout and separate/bundled `unity:*` extension references.
2. XML parser validates allowed namespaces, size/depth, known schema; reject XML external entities.
3. Compiler builds a typed executable graph (node IDs preserved), validates missing flows, gateways, variable shape, operation contracts, AMIE dependencies, and permission policy.
4. Publication pins supported element subset, operation versions, AMIE rule versions, subprocess versions and package digest.
5. Start creates run/token state and audit event, dispatches first ready node using the chosen host.
6. Step execution advances token state transactionally; cross-service work checkpoints a pending command with MSSQL outbox; duplicate outcomes do not advance twice.
7. Pause/cancel requests are observed at safe checkpoints; resume loads exact pinned definition and state.
8. Terminal state generates a complete, auditable chain.

## Sequential multi-instance DCMS semantics

A generic BOB construct accepts a bounded, ordered list/page source or durable iterator token. Only **one row item** may be active in a batch at once when configured sequentially. For each item: execute `CyberArk.ProcessAccountRow` subworkflow; on result update row projection; checkpoint progress; then request next. A failed row can be marked terminal and continue per configured `continueOnRowFailure` policy; a *systemic failure* may suspend the batch. Do not code DCMS CSV parsing into BOB.

If central BOB starts an embedded *batch* within CyberArk, central BOB holds **one** pending cross-capability activity while embedded BOB processes rows locally. Progress events are optional for UI freshness; final outcome resumes central run. If local worker crash occurs, durable row staging + claim/lease/reconciliation must permit safe resume without repeating confirmed writes.

## Run controls

- `PauseRequested -> Paused`: stop **new** work at checkpoint; in-flight side effect may complete.
- `ResumeRequested -> Running`: same run/version/position; validate authority and dependencies.
- `CancelRequested -> Cancelled` or `CompensationPending`: stop future steps, don't undo CyberArk write.
- `RetryFailed`: only after classifying failure and reconciling unknown external outcome.
- `Restart`: new run linked to original via `restartedFrom`, preserve old run history.

Use command IDs (dedupe), reason text (sanitized), actor/ticket, expected revision/ETag; return 202 for async operator commands; UI polls/subscribes for final state.

## Required conformance test fixtures

1. Basic service task and end event.
2. AMIE result driving exclusive gateway with true/false/default branches.
3. Reusable call activity and mismatched version rejection.
4. Sequential multi-instance 3 rows with one fail/one skip; check order and count.
5. Kafka command emits but outcome arrives after central process restart.
6. Double-delivered outcome and two competing workers; exactly one state transition, idempotent *effect* logic.
7. Pause during in-flight write: no subsequent row starts before resume.
8. Unsupported BPMN boundary element rejected at publish with node ID.

## BE designer relationship

SVG canvas and property inspectors produce standards-valid BPMN XML+DI, not a private JSON-only format. Use one source-of-truth definition for design and execution overlays. Avoid depending on a newly unapproved visual designer library for the demo; evaluate bank-approved components first.
