# 05 — Kafka Messaging Standard, Reliability and SDK Subscriptions

## What capability services declare

Each manifest declares **logical** subscription and publication descriptors: topic binding key (not physical broker address), message type/schema/version, consumer-group binding key, partition key, correlation requirements, idempotency strategy, retention/classification, allowed publisher/consumer identities. Platform deploys broker ACLs separately and validates authorization.

## Canonical envelope

`messageId`, `commandId` (if command), `messageType`, `schemaVersion`, `correlationId`, `causationId`, `traceparent`, `occurredAtUtc`, `applicationKey`, `workflowKey/version`, `runId`, `activityId`, `batchId`, `recordGuid` when appropriate, `sourceCapability`, `targetCapability`, `operationKey/version`, `idempotencyKey`, `actorContextRef`, `classification`, `payload` or `payloadRef`.

Keep message payload bounded and schema-valid; use secure reference for CSV/report/privileged account data. `actorContextRef` is a trusted signed/validated identity reference, not a browser-supplied role string.

## Durable dispatch pattern

1. Central BOB transaction records pending activity and integration outbox row with its run state.
2. Publisher delivers outbox to Kafka and marks receipt. Re-send can occur; design for duplicates.
3. Capability consumer validates broker identity, message type/version, operation key permission, data contract, expiry, deduplication key and actor/service scope.
4. Consumer claims inbox receipt and either invokes compiled handler or resumes embedded subworkflow.
5. Result/outcome is published through capability outbox; central BOB correlates once using `runId + activityId + commandId`.
6. Failed validation -> quarantine/DLQ with safe reason and operator runbook; no arbitrary replay without safety check.

## Exactly-once warning

Kafka transactions do not make an external CyberArk REST write exactly once. A crash can occur after a CyberArk update succeeded but before the local worker persisted success. On retry: use target-system revision/lookup/operation reference to reconcile, then mark `Confirmed` / `UnknownExternalOutcome`; never blindly replay writes. Handler declares `SafeToRetry`, `RequiresIdempotencyKey`, `ReconcileBeforeRetry`, or `NeverAutoRetry` policy.

## Ordering and parallelism

For DCMS one **batch** is sequential initially. Ordering within one batch is enforced by embedded BOB and a durable claim/lease. Different batches may process concurrently if permitted, but account-level writes may need a separate account key lock. Kafka partition key is not sufficient by itself to guarantee end-to-end external-write uniqueness.

## Negative tests

Duplicate command; duplicate outcome; changed schema; unauthorized topic/service; poison message; transient network outage; consumer restart while processing; outbox resend; late result after cancellation; unknown operation; revoked capability version; oversized payload; stale run version.

## Routes for future triggers

REST API push, approved data-source pull and AutoSys schedule **all** normalize into an authenticated `StartWorkflow` intent with standardized `triggerType`, source event ID, data artifact ref, idempotency key, correlation and audit. Do not build each trigger as a new BOB code path. Future scheduling orchestration is P1 unless required by pilot.
