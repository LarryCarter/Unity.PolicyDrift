# 01 — Unity Runtime Topology and Ownership

**Status:** [USER] architecture invariant + [PROPOSED] detailed contracts. **Refs:** `history/v0.7/Unity_BOB_BE_Integration_Architecture_v0.7.md` sections 0–2.

```mermaid
flowchart LR
  BE[Blazor BE UI] --> API[Authorized API Facade]
  API --> Catalog[Registry + Workflow Library]
  API --> Central[BOB Central Host]
  Catalog --> DB[(MSSQL definitions + versions)]
  Central --> DB
  Central --> K[(Kafka approved topics)]
  K --> CAP[Capability Service + Unity SDK]
  CAP --> Local[BOB Embedded Host]
  Local --> AMIE[Existing AMIE evaluator]
  Local --> Handler[Compiled registered operations]
  CAP --> K
  CAP --> AUD[Append-only audit event service]
  Central --> AUD
  AUD --> ADB[(MSSQL audit events)]
  ADB --> Projection[Business + technical projections]
  Projection --> API
```

## Control plane versus execution plane

**Control plane:** BE draft/version/approval, AMIE rules + data requirements, operation registry, contract validation, package signing, environment binding configuration, access policy. A workflow cannot be published if a binding is missing or incompatible. A registry descriptor is a *discoverable description*, not permission or actual execution.

**Execution plane:** published immutable package + pinned operation/rule versions, central BOB durable process instances, Kafka command/outcome, embedded BOB, AMIE evaluation, compiled capability handlers. Capability worker must not call BE/control plane at every local activity; cache trusted, version-pinned definitions and fail safely on missing versions.

## Data ownership

- `bob` MSSQL owns workflow definitions, versions, tokens, run checkpoints and durable orchestration state.
- `audit` MSSQL owns append-only historical events and reconstruction metadata.
- `integration` MSSQL owns outbox/inbox, correlation and worker leases where used.
- `controls` stores referenced control/runbook revisions and evidence metadata; verify actual bank retention and store.
- DCMS staging, batch rows, report content, CyberArk account data remain with their respective workload/capability owners, **not** in generic BOB schema.
- Kafka carries bounded, schema-checked messages and **references** to large files/data, not CSV bodies or credentials.

## Five non-negotiable flow rules

1. **Start:** Browser -> authorized BE API -> central BOB; no browser-to-Kafka direct connection.
2. **Cross boundary:** central BOB -> durable outbox -> Kafka -> capability inbox -> local work -> result Kafka -> central BOB resume.
3. **Within capability:** local BOB -> AMIE -> local handlers through DI, no Kafka bounce per row step.
4. **Observe:** append-only events -> trusted projection -> authorized API/SignalR -> user-scope UI. Query after reconnect.
5. **Control:** operator requests through APIs and safe checkpoint transitions; cancel does not undo externally completed work.

## Design proof

A complete test must start from BE and follow correlation through BOB, Kafka, one embedded capability, the AMIE rule result, the handler result, audit and the BE status projection. A second workflow must use the same infrastructure unchanged.

## Non-goals

Do not build a universal database service with arbitrary SQL, use BOB as a centralized interpreter for every local instruction, or embed Email/CyberArk-specific logic into BPMN engine core.
