# 10 — DCMS Acceptance Scenario (Workload, NOT BOB Core)

**Business facts supplied by user:** CSV is imported into a table; table is grouped by batch number; each row receives a GUID; one row at a time is processed; matching CyberArk account is fetched; CSV custom attribute values are added/replaced **in memory**, then account add/update is submitted; final emailed report enumerates success/failure with reasons. Future ingest through API/approved DB source/AutoSys schedule is an idea, not current capability. Onboarding and hygiene are similar but configurable workloads.

## Configuration blueprint

- Application key `DCMS` (illustrative).
- Central workflow `DCMS.BatchCoordinator`: start -> ingest/stage -> start CyberArk embedded batch -> await correlated outcome -> aggregate persisted results -> Reporting Generate -> Email RequestNotification -> complete.
- Embedded workflow `DCMS.ProcessAccountRow` or `CyberArk.ProcessAccountBatch`: fetch staged row -> `CyberArk.GetAccount` -> `AMIE.Eligibility` -> gateway -> `AMIE.MapCustomAttributes` -> `CyberArk.ApplyCustomAttributesInMemory` -> `CyberArk.AddOrUpdateAccount` -> persist row result -> advance sequential iterator.
- Trigger P0: authorized BE CSV upload or API start; future API pull/DB integration/scheduler normalize to same workflow start envelope.
- Data owner: DCMS staging capability or approved Database Capability; **not** BOB core.

## Data model

`Batch` fields: `BatchNumber`, `ApplicationKey`, `InputArtifactRef`, `SubmittedBy`, `SubmittedAtUtc`, `Status`, `TotalRows`, `ConfigurationPackageDigest`, `RunId`.

`BatchRow`: `RowGuid`, `BatchNumber`, `SourceRowNumber`, `AccountRef`, `PayloadRef`, `RowStatus`, `AttemptCount`, `ReasonCode`, `SafeReason`, `CompletedAtUtc`, `ExternalOperationRef`, `LastKnownCyberArkRevision`, `CorrelationId`. SQL constraints: unique `(BatchNumber, RowGuid)`, unique `(BatchNumber, SourceRowNumber)`; resolve re-upload/idempotency by accepted business policy.

## Data flow and failure conditions

1. **Upload:** reject malformed CSV, invalid encodings, missing headers, over-limit size, unauthorized users, unsupported rows. Store original safely with retention policy. Record upload actor, digest and source.
2. **Stage:** assign batch number and row GUIDs; record counts. All-or-nothing staging preferred where feasible; failures return actionable result.
3. **Dispatch:** central BOB saves `BatchStarted` state + outbox, sends approved Kafka request referencing batch and pinned embedded workflow.
4. **Process:** embedded BOB sequentially claims rows via approved API/page; local account read -> AMIE decisions -> in-memory patch -> CyberArk write. Do **not** send entire staged dataset through Kafka.
5. **Record:** `Succeeded` after confirmed external outcome; `NoChange` if already matches; `Skipped` when explicitly allowed by business rule; `Rejected` invalid/unauthorized data; `Failed` confirmed failure; `UnknownExternalOutcome` if write may have succeeded but confirmation is lost.
6. **Recover:** on crash/duplicate event, inspect persisted row ID, external operation ID and target state before reattempt. Never auto-retry an uncertain CyberArk write.
7. **Finish:** report from **persisted row outcomes**, not from number of events emitted. Include counts, row IDs, safe failure reasons; policy for unresolved outcomes must be explicit, not hidden.
8. **Notify:** Reporting Capability returns secure artifact ref; Email Capability receives approved notification command and emits delivery outcome. Notification failure does not turn successful account updates into failures.

## UI walkthrough summary

See `docs/ui/03-DCMS-CONFIGURE-AND-RUN.md`: create DCMS application, assign ownership, import CSV schema, select ingest operation, bind CyberArk subworkflow, map AMIE input/output, bind reporting and Email Capability, publish DEV draft, start, inspect business counts, then inspect technical trace and results.

## Primary regression fixtures

Small CSV with 5 rows: one success, one no-change, one missing account, one invalid AMIE mapping, one uncertain write. Validate counts, no duplicate effects, per-row reason, report content, Kafka correlation, audit history, safe pause/restart, role restriction. Use mock CyberArk adapters in CI; reserved controlled integration tests require approved nonproduction account fixtures.

## Second application reuse

Hygiene/Policy Drift: inspect CyberArk accounts -> AMIE check policy -> optionally route to approved `MoveAccount` operation after explicit authorization -> persist compliance evidence. Reuse same registered `GetAccount` and BOB+AMIE runtime; policy-specific rules live in application package. If `MoveAccount` isn't implemented/approved, **only read-only detection** is a permissible demo.
