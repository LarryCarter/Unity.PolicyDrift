# 11 — API-First Functional Regression Standard

**Every BE action must have a secured backend API.** Every capability operation must have a typed invocation contract and test fixture. Kafka message handling is contract-testable; read models provide query APIs. UI cannot be sole way to publish, start, inspect or operate.

## API route groups (illustrative; validate against existing routes)

- `GET /api/v1/capabilities`, `GET /api/v1/capabilities/{capabilityKey}/operations`, `GET /api/v1/operations/{key}/versions/{version}`.
- `POST /api/v1/workflow-drafts`, `PUT /api/v1/workflow-drafts/{id}`, `POST /api/v1/workflow-drafts/{id}/validate`, `GET /api/v1/workflow-definitions/{key}/versions`.
- `POST /api/v1/workflow-versions/{id}/submit-review`, `POST /api/v1/workflow-versions/{id}/publish` (after policy and approvals).
- `POST /api/v1/workflow-runs`, `GET /api/v1/workflow-runs/{runId}`, `GET /api/v1/workflow-runs/{runId}/activities`.
- `POST /api/v1/workflow-runs/{runId}/pause`, `/resume`, `/cancel`, `/retry`, `/restart` with expected revision, reason, actor context from auth, and commandId.
- `POST /api/v1/inputs/uploads`, `GET /api/v1/business-batches/{batchId}/summary`, `GET /api/v1/business-batches/{batchId}/rows` (paged, scoped).
- `GET /api/v1/audit/events?runId=...`, `GET /api/v1/controls/runbooks/{key}/versions`, `POST /api/v1/release-candidates/{id}/preflight`, `POST /api/v1/releases/{id}/activate`.

These represent *API families*, not a commitment to distinct controllers per family. Avoid overbuilding; use existing application conventions.

## Contract test layers

1. **Unit:** metadata builder, operation resolver, binding validator, BPMN parser/compiler, AMIE adapter with real engine, state machine.
2. **Component:** SDK handler invocation with DI, authorization, serialization, audit and idempotency; Blazor forms display schema-required fields.
3. **Integration:** Kafka broker fixtures, MSSQL migrations/outbox/inbox, process restart recovery, service identity permission checks.
4. **E2E:** BE API create workflow->validate->publish->start->status->audit->report/email with safe test capability.
5. **Negative:** unauthorized/cross-scope, unknown operation, schema drift, invalid BPMN element, missing rule version, invalid ticket/approval, duplicate command, uncertain write and resume races.
6. **UI:** browser clickthrough with accessible selectors, screenshot of error/success, reconnect after status push loss, non-technical progress dashboard and technical trace.

## Evidence capture

Attach redacted API request/response, expected/actual outcomes, exact package digest, test fixture version, run ID, service versions, UTC, CI build URL, screenshots for user flow, and rejection response for negative controls. Bank control evidence may require additional artifacts; get actual control owners to decide.

## Acceptance criterion

An automated test can exercise every action shown in the BE navigation **without clicking through UI**. Automated tests can also invoke the same operations through authorized APIs and verify audit and business projections. CI must fail on schema mismatch, missing policy, unsupported BPMN semantics or broken correlation.
