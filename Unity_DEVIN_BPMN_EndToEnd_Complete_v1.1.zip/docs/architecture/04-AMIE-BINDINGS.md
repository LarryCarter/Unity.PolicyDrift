# 04 — Existing AMIE Integration and Typed Data Binding

**Status:** [USER] AMIE already substantially implemented. This spec defines the adapter expectations, **not** a competing evaluation engine. **Mandatory:** JOB-00 inspect AMIE's real rule evaluator, rule versions, input models, deployment and cache APIs before coding.

## Division of responsibility

- AMIE owns configurable expressions, transformations, eligibility decisions, schema-bound field mapping and decision results.
- BOB owns *when* a rule runs, how its output selects a BPMN route, and how rule outcomes are recorded.
- Capability owns enforcing operation contracts and performing external actions; AMIE config cannot grant privileged access.
- BE owns input binding UI, rule picker, preview and validation; it calls the existing AMIE API/adapter.

## Proposed adapter (rename to existing interface when found)

```csharp
public interface IUnityAmieAdapter
{
    Task<RuleDescriptor> DescribeAsync(string ruleKey, string version, CancellationToken ct);
    Task<RuleOutcome> EvaluateAsync(RuleRequest request, UnityExecutionContext context, CancellationToken ct);
    Task<BindingValidation> ValidateBindingsAsync(RuleDescriptor rule, IReadOnlyDictionary<string, ValueBinding> bindings, CancellationToken ct);
}
```

Do **not** implement fresh parsers, dynamic C# expression compilation or a new rule language unless documented as a required existing AMIE capability and approved by owner.

## Unified binding grammar

Logical values originate from (a) workflow initial inputs, (b) current item/record, (c) prior operation result, (d) AMIE rule output, (e) allowlisted constant, (f) approved environment binding, or (g) protected server-side secret reference.

Example expressions (labels, **not** raw executable code): `input.batchId`, `item.accountRef`, `steps.getAccount.output.account`, `rules.attributeMap.output.changeSet`, `settings.allowCreate`, `environment.cyberark.endpointRef`.

Each binding is stored as a **typed reference descriptor** with source kind, path, expected schema, nullable/default behavior, and classification. The compiler resolves it, validates compatibility, and records origin. Never permit raw variable paths to bypass missing-field errors or escape their scope.

## Rule descriptor

For each rule, expose key/version, owner/approved state, input and output JSON schemas, decision types, minimum configuration, data classification, test examples and compatibility requirements. Rule outputs must be serializable to safe result DTOs for BOB gateways and audit summaries; keep complete restricted inputs with owning data services.

## DCMS mapping

`DCMS.AccountEligibility`: input current CSV row + account metadata -> outcome `Eligible | Skip | Reject`, with reason code. `DCMS.MapAttributes`: source CSV fields + account platform -> approved attribute patch. `DCMS.ShouldUpdate`: current vs desired -> Update or NoChange. These are **design examples**, not names guaranteed to exist in current AMIE.

Workflow: retrieve account -> AMIE eligible -> gateway -> AMIE mapping -> capability in-memory transform -> capability approved write -> classify actual write outcome. A successful rule **does not imply** a successful CyberArk write. Use explicit business outcomes: `Succeeded`, `NoChange`, `Skipped`, `Rejected`, `Failed`, `UnknownExternalOutcome`.

## Versioning

A published workflow package pins exact rule identity + version. If rule isn't present in the deployed runtime, reject start / suspend safely; do not silently substitute latest. New rule version requires new reviewed package for new runs. Audit tracks rule reference, inputs hash/ref and safe outcome metadata.

## Adapter acceptance

- Existing AMIE engine evaluates a real rule using the adapter and supplies typed result.
- BE operation inspector suggests compatible input data and reports mismatches before publish.
- Workflow decision changes when AMIE config changes in **a new published version**, without BOB or CyberArk changes.
- Attempted sensitive action remains forbidden even when a rule outputs `true`.
- Same rule evaluated inside embedded CyberArk host without remote roundtrip per row.
