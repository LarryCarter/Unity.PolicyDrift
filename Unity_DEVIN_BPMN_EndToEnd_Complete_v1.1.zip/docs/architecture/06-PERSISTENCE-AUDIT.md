# 06 — MSSQL Persistence, Audit Reconstruction and Status Projection

## Persistence responsibilities

- `bob.WorkflowDefinition`, `WorkflowVersion`, `ActivityBinding`, `WorkflowRun`, `RunToken`, `ActivityRun`, `PendingCommand`, `ControlRequest`, `PackageActivation`.
- `integration.OutboxMessage`, `InboxReceipt`, optional worker lease/claim tables.
- `audit.AuditEvent` **append-only**; restricted actor and evidence metadata, never full privileged payloads.
- `controls.RunbookVersion`, `ControlDefinition`, `ControlEvidence` if adopted by bank control owners.
- `projection.RunSummary` or equivalent materialized/read model for low-latency BE dashboards.
- DCMS `Batch/BatchRow` stay with DCMS/workload data owner, not generic BOB. Permission checks apply to joining read models across domains.

**MSSQL-only refers to BOB provider; other capability-owned stores remain independent.** Prefer transactional consistency for a run transition and outbox row in the same MSSQL database transaction when both are under same owner; cross-service actions require correlated follow-up outcomes.

## Minimum AuditEvent shape

`eventId`, `occurredUtc`, `recordedUtc`, `eventType`, `actorId`, `actorKind`, `scope`, `applicationKey`, `workflowKey/version`, `runId`, `activityId`, `packageDigest`, `amieRuleKey/version`, `capabilityKey/operationKey/version`, `batchId`, `recordGuid`, `messageId`, `correlationId`, `causationId`, `traceId`, `reasonCode`, `oldState`, `newState`, `serviceNowChangeId`, `controlId`, `evidenceRef`, `safeDetailsHash`, `classification`, `eventSchemaVersion`.

**No secrets or full CyberArk account records in audit.** Use data owner reference/hash + approved redacted summary, limited retention and authorized export. Immutable event stream alone cannot reconstruct unavailable code or rule definitions: retain signed published package and dependency list.

## Truth model

The event log is the durable historical timeline. State tables permit fast execution/recovery. Projections transform source events into counts and timelines; on disconnect/reconnect the BE UI calls the authoritative API before resuming push updates. The projected UI must distinguish `Completed`, `Failed`, `Skipped`, `NoChange`, `InProgress`, `Pending`, and `UnknownExternalOutcome` for DCMS; the workload owner defines business classifications.

## Concurrency and reconstruction

Use expected run revision/rowversion, unique message/command IDs, optimistic concurrency plus lease where necessary. Append an event and advance a state transition atomically whenever possible. Test interleaving commands, restart, projection rebuild, missing event, late Kafka event and duplicate delivery. Protect audit writers via append-only privileges; user/admin deletion forbidden except strictly controlled retention jobs with recorded evidence and bank policy.

## Control evidence

Store ServiceNow ticket ID, requester, reviewer, author, publisher, deployment actor, environment, artifact digest, approval decision, UTC and runbook version. **A populated ticket ID is not proof of approval**. Evidence must derive from authoritative bank records or authorized reviewers in a trusted approval process.

## Optional integrity

SQL Server Ledger and off-database hash/checkpoint mechanisms are **research options only**, requiring installed SQL Server version, security and bank approval. Do not introduce as a November dependency.
