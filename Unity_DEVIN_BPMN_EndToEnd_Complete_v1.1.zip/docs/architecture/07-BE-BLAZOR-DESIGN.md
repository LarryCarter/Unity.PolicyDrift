# 07 — Blazor BE Design, Designer and Business UI

## Core screens (the existing v0.7 HTML prototype is a visual reference, not Blazor code)

1. **Workbench:** application summaries, recent runs, role-scoped quick actions.
2. **Capability Registry:** searchable authorized capability/operation list and operational health.
3. **Operation Inspector:** input/output schemas, binding selector, AMIE dependency, permission and side effect warnings, retry behavior.
4. **Workflow Library:** draft/review/published/active/retired versions, owner, ServiceNow change ID, diff, clone.
5. **BPMN Designer:** left palette of supported BPMN and approved operations; center canvas; right schema-derived inspector; bottom validation and test panel. Preserve BPMN IDs/DI, version pins and unsupported-node diagnostics.
6. **AMIE Picker:** pick existing approved rules, preview on safe test fixtures; never build second AMIE expression engine.
7. **Trigger Forms:** manual start, CSV upload, API trigger, data refs and validation errors; scheduling P1.
8. **Business Work Queue:** batch status counts, result report and record-level reasons, filtered by user scope; BPMN technical detail not required.
9. **Run Monitor:** BPMN diagram overlay of active/completed/error/paused nodes, correlated Kafka/evidence timeline, read-only for most roles.
10. **Operator Console:** pause/resume/cancel/retry/restart with pending request state and runbook/actor/reason; mutation only via authorized backend API.
11. **Audit & Controls:** immutable timeline by batch/run/change/user, safe export and runbook revision.
12. **Release Center:** package hash, dependency validation, environments and binding checks, role-separated approvals and Operations activation.
13. **API Regression:** contract and CI test evidence links (full UI P1; automation is P0).

## Designer implementation without unapproved library

Use approved existing UI dependencies. Otherwise a first-party Blazor component renders SVG nodes/connections and handles selection/property editing. A small first-party JS module owns high-frequency dragging, pan/zoom, snapping and connect-preview; send **committed** gesture results to Blazor through JS interop rather than a C# roundtrip on each mouse event. Maintain a single BPMN model; import/export XML + DI, not a private format that cannot interchange. Avoid mutating Blazor-owned DOM via external JS. Docs: https://learn.microsoft.com/en-us/aspnet/core/blazor/javascript-interoperability/?view=aspnetcore-10.0

## Operation configuration and validation

When designer drops a service task, its inspector must pull `OperationDescriptor@version`. Render inputs based on schema + UI hints, required/optional flags, data classification, supported host modes. Pick binding source: trigger input, current row, prior step output, AMIE output, allowlisted constants, environment binding or protected secret reference. Auto-generate structured error such as `ACT-23 accountRef missing` or `RULE-7 output incompatible with CyberArk.AddOrUpdateAccount@1.0`.

BE calls `POST /api/v1/workflow-drafts/{id}/validate` (proposed) and displays **backend compiler** errors. UI-only validation is friendly guidance, never final admission. Also call backend auth to hide disabled actions, but backend always rechecks.

## UX performance/accuracy

- All long lists paginated and filtered; avoid loading a full batch into the browser.
- Business progress = completed terminal rows / total staged rows, with per-category counts and last-updated timestamp. Push is a hint; refresh from API on reconnect.
- Use semantic text and accessible controls; a visual diagram alone must not be the only source of error explanation.
- Never show tokens/passwords in the browser; display secure binding names only.
- Design run overlay uses the *published workflow XML* with associated BPMN DI geometry.
- Support user scopes: some users see only their own batches; auditors see evidence without mutation; operators may inspect technical detail for assigned workflows.

## Screen tests

Each screen's action must have an API; no fake save/publish. Test unauthorized direct API request after hiding button; keyboard navigation; bad schema; draft conflict; concurrent editor; missing capability; terminal failure; reconnect; large paginated batch; redaction; mobile responsive baseline; no console errors.
