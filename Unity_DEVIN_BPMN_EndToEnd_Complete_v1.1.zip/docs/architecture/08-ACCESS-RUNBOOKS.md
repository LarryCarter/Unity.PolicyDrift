# 08 — Access Control, Operations Controls and Runbooks

## Distinguish permissions from controls

**Permissions** decide *who can call an action*. **Controls/runbooks** document *expected handling, accountable owners, escalation, evidence and approvals*. Wells Fargo actual IAM names, controls, CA identifiers and ServiceNow approval mechanics are **unknown pending inspection**. Do not invent them or claim compliance certification.

## Proposed role slices

- `WorkflowDesigner`: edit only assigned application drafts.
- `RuleMaintainer`: edit assigned AMIE rule drafts.
- `WorkflowReviewer`: approve content under delegated separation-of-duties rules.
- `CapabilityPublisher`: register approved manifest after service release.
- `ReleaseOperator`: preflight/install approved immutable package in assigned environment only; cannot edit package.
- `BusinessExecutor`: start authorized workflows, upload or fill assigned forms, view business summaries.
- `TaskAssignee`: claim/complete assigned human tasks when implemented.
- `ProcessOperator`: run-control actions with reason, change ticket if required, and assigned scope.
- `Auditor`: view approved history and evidence, not update.
- `ReadOnlyObserver`: status only.
- `PlatformAdmin`: manage delegated configuration; not automatic override of PROD release restrictions.

## Authorization implementation

Authorization = action permission AND resource scope AND environment AND data classification AND separation-of-duties policy. Check on API, application service, worker operation dispatch and data read. A manifest descriptor cannot grant an entitlement. Kafka service identity must also be authorized for the operation and destination topic. All denials produce redacted audit events; default deny.

## Runbook schema

`runbookKey`, `version`, `owner`, `applicationKey`, `workflowKey`, `controlIds`, `trigger`, `expectedOutcome`, `monitoringThreshold`, `pauseProcedure`, `cancellationLimit`, `retryClassification`, `externalReconciliationSteps`, `escalation`, `requiredTicketKind`, `evidenceChecklist`, `approver`, `effectiveAt`, `retiredAt`. Versions immutable once effective.

## Operator control UX

Show current run state, last transition, pending commands, scope, authorized controls, runbook snippet, and evidence. Before a mutation: collect a structured reason; ask for ticket when bank rule requires; show **what action does not guarantee**. Example `Pause` is checkpoint-cooperative and cannot interrupt accepted CyberArk write. API validates `If-Match` revision, command-idempotency, actor and policy; show `PauseRequested` until the actual state changes.

## Maker/checker

Author/reviewer/release operator identities recorded separately; separation-of-duties is bank-specific and must be enforced server-side where applicable. A ServiceNow string field is an evidence reference, not an approver. No DEV user automatically gets PROD rights.

## Runbook regression

Test allowed/denied scopes, reviewer self-approval deny when required, stop while write in flight, stale state update, two operators racing, retry unknown write, offline audit/DB, failed release preflight, retired definition start denied.
