# 02 — Capability SDK, Registration and New-Service Standard

**Status:** [USER] automatic discovery and reusable operations; [PROPOSED] interface/manifest. **Most important DEVIN contract after JOB-00.** Also read `docs/contracts/OPERATION-CONTRACT.md` and `.agents/skills/unity-capability-service/SKILL.md`.

## A capability has two products

1. **Compiled operation implementations** inside a service: handlers that use approved CyberArk, identity, database, email, reporting, ingestion or other adapters.
2. **Published contract manifest**: descriptions of each allowed operation, IO schemas, dependencies, permissions, side effects, retries, messaging, AMIE requirements, and tests. The manifest is read by BE and BOB, but cannot execute code on its own.

## Proposed logical assemblies (do not scaffold until code mapping)

- `/Unity.Capabilities.Contracts/` — DTOs, manifests, invocation/outcome, schema and compatibility contracts.
- `/Unity.Capabilities.Hosting/` — `IUnityOperationHandler<TIn,TOut>`, DI registration, handler catalog, dispatcher, health + manifest API.
- `/Unity.Capabilities.Kafka/` — command dispatcher, envelope validators, inbox deduplication, outbox publisher, DLQ/poison policy.
- `/Unity.Capabilities.Observability/` — telemetry and audit emission adapters.
- `/Unity.Capabilities.AMIE/` — minimal bridge to **existing AMIE**, not an AMIE copy.
- `/Unity.Capabilities.BOB/` — embedded BOB runtime host, definition cache, activity resolver.
- `/Unity.Capabilities.Testing/` — test harness and contract fixture helpers (P1 if constraints).

Implement only the needed physical projects initially; shared abstractions may coexist in fewer packages while preserving namespace boundaries.

## New service construction recipe

1. Inventory existing service and handler conventions. Choose one service owner, allowed operations, data classification, supported .NET target and authorized Kafka bindings.
2. Implement typed DTOs and business adapter operations. One operation does one reusable capability action, e.g. `CyberArk.GetAccount@1` or `Email.RequestNotification@1`; no app-specific `DCMS` if/else.
3. Register operations at startup from **trusted compiled assemblies** (explicit registration or vetted assembly scanning). Fail startup for duplicate operation keys, missing handlers, invalid schemas, unsupported versions, or missing policy metadata.
4. Generate manifest from **declared** contracts; compile/bundle JSON schema and sample request/response fixtures. Handler must be invocable only by stable operation key + compatible major version.
5. Publish the signed or trusted-attested manifest to registry in deployment flow with service identity; runtime registration is **not** automatic enterprise approval. Registry verifies owner/publisher, version compatibility, active deployment, and permitted environments.
6. BE discovers descriptors using an authorized API; only approved operations appear as executable nodes. Unsupported/unavailable operations remain visible for maintainers as non-callable diagnostics.
7. BOB binds `operationKey@contractVersion` and typed source/output mappings; applies auth at publication *and again at execution*.
8. Configure allowed transport mode: local DI call inside same capability, or Kafka command across services. Do not permit arbitrary topic names from user forms.
9. Instrument every invocation with request/run/activity/correlation IDs, safe metadata, and structured `OperationOutcome`; use outbox/inbox + reconciliation for writes.
10. Run contract, auth, redaction, duplicate message, timeout, crash/restart and second-workload reuse tests.

## Manifest record minimum

| Field group | Fields | Enforcement point |
|---|---|---|
| Identity | `capabilityKey`, capability version, owner, publisher, release state | Registry admission |
| Operation | `operationKey`, `contractVersion`, handler key | Startup and BOB resolver |
| Data | input/output JSON Schemas, required fields, UI hints, classification | Compiler, BE inspector and runtime |
| Security | permission and resource scope, side-effect classification | API and worker dispatch |
| Invocation | supported local/Kafka modes, timeout, retry/reconcile strategy | BOB/worker |
| Messaging | logical subscription/publication keys, message schema version, partition rule | Registry validation, broker provisioning |
| Rules | required AMIE rule contracts/field bindings | BE compilation, embedded runtime |
| Evidence | audit category, safe fields, fixture names | Audit and CI |

**Critical distinction:** published manifest may be `Registered` while service is `Unavailable`; health state must not silently elevate permission. A service needs both a valid approved manifest and a healthy compatible deployed handler for actual use.

## Example handler and host wiring (illustrative)

`/Unity.Capabilities.Hosting/IUnityOperationHandler.cs`

```csharp
public interface IUnityOperationHandler<TIn, TOut>
{
    Task<TOut> ExecuteAsync(TIn input, UnityExecutionContext context, CancellationToken ct);
}
```

`/Unity.Capability.CyberArk/Program.cs`

```csharp
builder.Services.AddUnityCapabilityHost(o => o.CapabilityKey = "CyberArk")
    .RegisterApprovedOperations(typeof(GetAccountHandler).Assembly)
    .UseExistingAmie()
    .UseEmbeddedBob()
    .UseKafkaContracts()
    .UseAudit();
```

**Names above are not current repository APIs.** The implementation must map or revise them in JOB-00. Never ship a mock `AddUnityCapabilityHost` that only registers fake descriptors.

## Standard capability archetypes

- **CyberArk/PAM:** read account, list/search, transform in memory, add/update, safe movement when explicitly authorized, revision checks and external-outcome reconciliation.
- **Database/ingestion:** validate CSV, stage data, get bounded pages, persist row results, implement source-API adapters; deny unrestricted SQL; owns its data contract.
- **Email:** request notification, template/recipient policy, return accepted/sent/failed outcomes; email is not a BOB builtin.
- **Reporting:** aggregate persisted results; create secure report artifact; return reference, not email infrastructure.
- **Identity:** fetch approved identity/group context and validate assignment; avoid exposing directory internals to consumers.
- **Legacy:** wrap a vetted legacy API in a typed operation; no direct workflow dynamic reflection against legacy assemblies.

## Reuse proof

Publish a real `CyberArk.GetAccount@1` or safe test operation once. Bind it into **DCMS** and **Hygiene** definitions using different AMIE rules. Record both successfully executed without a new handler or BOB Core change. A new primitive requires an ordinary code release, not unreviewed workflow config.
