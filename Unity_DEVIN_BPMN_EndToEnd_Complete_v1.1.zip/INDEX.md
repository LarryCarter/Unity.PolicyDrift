# Unity DEVIN - BPMN End-to-End Design and Delivery v1.1

**START HERE:** [DEVIN assignment](DEVIN-BPMN-END-TO-END-START-PROMPT-v1.1.md) -> [read-only repo audit](jobs/JOB-00-reconcile-repository.md) -> [v1.1 job board](jobs/bpmn/INDEX.md).

This v1.1 package extends the v1.0 UI/SDK implementation handoff without changing our architecture. It is a **proposed implementation specification**, not source code built or approved by Wells Fargo. The ZIP opens directly at repository root, with no version-wrapper directories.

## End-to-end BPMN authoring and reusable UI

| Need | Reference |
|---|---|
| Complete screens from new workflow to operation and monitoring | [UI 13 - authoring journey](docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md) |
| Palette, BPMN element types, per-node inspector, dynamic inputs | [UI 14 - element configuration](docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md) |
| Reusable Blazor component tree and exact responsibilities | [UI 15 - component catalog](docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md) |
| New click-to-API specs (supplement to 107 v1.0 controls) | [UI 16 - 63 actions](docs/ui/16-EDITOR-ACTIONS-API-AND-TEST-CATALOG.md) |
| Business projection, near-real-time monitor, safe run controls | [UI 17 - monitoring and security](docs/ui/17-UI-RUNTIME-PROJECTIONS-AND-ACCESS.md) |
| Author/test/publish a BPMN workflow step-by-step | [UI 18 - 30-step DCMS walkthrough](docs/ui/18-FULL-BPMN-DESIGNER-UI-CONFIGURATION-AND-TEST-RUNBOOK.md) |
| Clickable v1.1 configurator for four scenarios | [Interactive UI v1.1](wireframes/Unity_BPMN_Configurator_Clickable_v1.1.html) |
| Existing v1.0 complete behavior model | [Original 19 screens / 107 controls](wireframes/Unity_BE_Clickable_Wireframes_v1.0.html) |
| All editable process and sequence diagrams | [18 Mermaid diagrams](docs/diagrams/DIAGRAMS.md) |

## Backend-to-frontend workflow examples

| Scenario | Reference | Key point |
|---|---|---|
| DCMS upload / account enrichment / email | [DCMS workflow](docs/workflows/01-DCMS-CSV-CYBERARK-ENRICHMENT.md) | CSV -> staged GUID rows -> AMIE -> CyberArk -> report/email |
| Account Delete with human/control approval | [Guarded Account Delete](docs/workflows/02-ACCOUNT-DELETE-GUARDED-WORKFLOW.md) | dry-run and irreversible action gating |
| NAS API database with EF backend | [NAS data capability](docs/workflows/03-NAS-EF-API-DATA-CAPABILITY.md) | typed approved API + EF service data ownership |
| AutoSys scheduled Policy Drift | [Policy Drift](docs/workflows/04-AUTOSYS-POLICY-DRIFT-ZIP-INI.md) | trusted scheduler trigger -> nested ZIP/INI -> baseline comparison |
| PAM account hygiene / safe move | [Account hygiene](docs/workflows/05-HYGIENE-SAFE-MOVE-SEPARATE-EXAMPLE.md) | distinct from policy ZIP/INI drift |
| Common patterns and invariants | [Reuse catalog](docs/workflows/00-REUSABLE-WORKFLOW-PATTERNS.md) | no app-specific behavior inside core |
| Trigger/NAS/Kafka/status DTO proposals | [Contracts](docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md) | source actual code must confirm endpoints |

## Implementation, tests and provenance

- [20 new focused DEVIN jobs](jobs/bpmn/INDEX.md) refining [21 base jobs](jobs/INDEX.md) and [17 earlier subtasks](jobs/interaction/INDEX.md), not independent competing plans.
- [November critical path and P0/P1/P2 cut line](docs/roadmap/END-TO-END-BPMN-NOVEMBER-ROADMAP-v1.1.md).
- [Existing platform architecture](docs/architecture/01-PLATFORM-TOPOLOGY.md) and [BOB engine spec](docs/architecture/03-BOB-BPMN-RUNTIME.md).
- [Existing shared SDK specification](Unity_Capability_SDK_Specification_v1.0.md) and `.agents/skills/` (five repo Skills; BE, BOB, Capability Skills extended in v1.1).
- [Illustrative BPMN XML fixtures](examples/AccountDelete_Guarded_Illustrative_v1.1.bpmn), [NAS manifest](examples/NAS_Data_Capability_Manifest_Proposed_v1.1.json), [AutoSys trigger payload](examples/AutoSys_Trigger_Payload_Proposed_v1.1.json).
- [OpenAPI draft](docs/contracts/WORKFLOW-COMPOSER-API-PROPOSED-v1.1.yaml) (14 proposed endpoint families) and [API-first regression matrix](docs/testing/BPMN-DESIGNER-API-REGRESSION-MATRIX-v1.1.md).
- [QA report](QA-BPMN-v1.1.md) and [checksum manifest](MANIFEST.sha256).

## What is established vs proposed

- **User-defined:** Unity configuration-first, BE Blazor, BPMN 2.0, one shared BOB core for central/embedded, AMIE already largely written, microservice capability SDK, Kafka, MSSQL BOB state, audit and control gates, DCMS business process, AutoSys as intended trigger, and goal of November 30 demonstration.
- **Proposed:** operation/trigger manifest keys, UI routes, SDK method signatures, exact names of the 20 job packets, v1.1 node/palette cut line and example endpoints. Use existing repository implementation whenever it differs.
- **Requires verification:** exact expansion/ownership of NAS and its EF DTO/API, approved CyberArk delete endpoint, installed AutoSys version, existing Policy Drift parser/SQL/PolicyId normalizer, bank SSO and CA controls, paid BPMN library approvals.
- **Not claimed:** production-ready implementation, full BPMN 2.0 runtime conformance, live connection to bank systems, real approval or deployed services.

## Folder structure

```text
README.md, INDEX.md, AGENTS.md, DEVIN-BPMN-END-TO-END-START-PROMPT-v1.1.md
docs/architecture/ contracts/ decisions/ diagrams/ roadmap/ sdk/ testing/ ui/ workflows/
examples/  (proposed JSON and illustrative .bpmn fixtures)
jobs/      (existing JOB-00..20, interaction/ subtasks, bpmn/ new tasks)
.agents/skills/ (five existing repository skills, three updated for v1.1)
skills-packages/  (per-skill zip for repository use)
wireframes/ (v1.0 + v1.1 interactive HTML, screenshots, original control registry)
```
