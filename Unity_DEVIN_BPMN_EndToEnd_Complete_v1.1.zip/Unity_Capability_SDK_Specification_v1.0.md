# Unity Capability SDK - Consolidated Specification v1.0

This is a readable combined reference of the nine modular SDK files. If sections conflict, the modular source and actual Unity code review take precedence.

## Table of contents

1. [00-SDK-PURPOSE-SERVICE-BOUNDARIES](#sdk-section-1)
2. [01-SDK-CONTRACTS-AND-STATES](#sdk-section-2)
3. [02-AUTOMATIC-REGISTRATION-AND-NEW-SERVICE](#sdk-section-3)
4. [03-BOB-AMIE-KAFKA-EXECUTION](#sdk-section-4)
5. [04-DATA-SCHEMAS-AND-UI-BINDINGS](#sdk-section-5)
6. [05-SECURITY-AUDIT-PROMOTION](#sdk-section-6)
7. [06-DCMS-EXAMPLE-END-TO-END](#sdk-section-7)
8. [07-DEVIN-SERVICE-CONSTRUCTION-RECIPE](#sdk-section-8)
9. [08-SDK-API-REGRESSION-SUITE](#sdk-section-9)

---


<a id="sdk-section-1"></a>

# SDK 00 - Why a Unity Capability Service Exists

Status: DESIGN PROPOSAL built on user-established Unity architecture. Before coding, DEVIN MUST inspect the actual repo in JOB-00. Do not interpret proposed namespaces as implemented APIs.

## 1. Purpose and non-goals

A capability service is an independently deployed .NET service exposing approved, reusable business-system primitives through versioned typed contracts. It performs operations that require privileged access, domain validation, network or SDK interaction, or domain data ownership. It **does not own an application's end-to-end business workflow**.

Examples:
- CyberArk: GetAccount, FindAccount, ReadPlatform, ApplyAllowedAttributePatch, AddOrUpdateAccount, MoveAccount (only if separately implemented and authorized).
- Data/ingestion: ValidateCsv, StageBatch, GetPage, RecordRowOutcome, ReadBatchSummary. The owner owns business staging data, not BOB's workflow state.
- Email: SendApprovedNotification using template and recipient policies; the email transport is not inside BOB.
- Reporting: ComposeBatchReport, return access-controlled artifact reference; not automatically send email.
- Identity: ResolveUser/Group within approved scope; not a generic privileged directory browser.
- Legacy: Typed facade over a reviewed API; not arbitrary service method invocation.

Do not put DCMS-specific branches in CyberArk handlers, author AMIE rules in source code just for DCMS, create unrestricted SQL/HTTP operation handlers, or let BE submit arbitrary CLR assembly names or Kafka topics.

## 2. Platform responsibility matrix

| Concern | Source of truth | How consumers access it | Prohibited coupling |
|---|---|---|---|
| Workflow definition / version | BOB/Unity configuration package | BE designer + workflow API | Capability inventing its own private workflow format |
| Token execution / checkpoints | BOB shared interpreter | Embedded/central BOB host | Different semantics per host |
| Business decision/mapping | Existing AMIE runtime / published rule package | Typed AMIE adapter | BOB duplicating rule grammar |
| Compiled primitive/permissions | Capability release + manifest | Registry/dispatcher/worker | BE invoking arbitrary C# type |
| Event transport | Kafka with approved logical contracts | Shared SDK outbox/inbox | Browser talking to Kafka directly |
| Operational current state | Workload data owner and BOB projection | Authorized APIs/BE view | All capabilities reading one shared DB |
| Immutable audit history | Append-only MSSQL event store | Scope-filtered audit API | Audit derived only from ephemeral logs |
| Visualization, authorization UX | BE (Blazor) | API-first UI | Hiding buttons as sole security control |
| Release and approvals | Operations/change-control process | Release API + immutable package | Developer direct PROD access |

MSSQL is the sole **BOB persistence** target for MVP; capability-owned business data may use its approved datastore or API. No cross-service direct table access is implied.

## 3. Minimum contracts every service must supply

1. **Service identity**: capability key, code release/version, service owner, deploy identity and health.
2. **Operation descriptors**: stable `capability.operation@major.minor` identity, request and result schema, classification, required permission/scope, side effect, retry/reconcile mode, supported execution hosts, timeout, fixture identifiers.
3. **Message descriptors**: logical inbound command/outbound outcome identities, schema, partition key, idempotency key construction, consumer group and permitted environment bindings. Kafka physical topic names and credentials are never authored in workflow tasks.
4. **AMIE binding descriptors**: each rule's expected facts and typed decision/output; operation descriptions cannot guarantee a rule is installed.
5. **Invocation boundary**: authenticated `OperationInvocation` with process/activity IDs, pinned package digest, actor/service identity references, correlation/causation IDs and idempotency key.
6. **Execution outcome**: `Succeeded`, `NoChange`, `Rejected`, `Failed`, `UnknownExternalOutcome`, with safe reason code and trace reference. Distinguish operation disposition from business row status.
7. **Audit**: structured evidence for invocation, authorization, decision, dispatch, attempt, external action, completion/reconciliation, without raw credentials or sensitive account objects.
8. **Diagnostics**: health/registry status, effective operation version, schema/contract mismatch errors, safe test fixtures; no health signal alone authorizes invocation.

## 4. Two registration events - must not be confused

- **Local registration** on trusted service startup: approved compiled operation handlers are discovered/explicitly registered in DI, validated, and made callable by the local dispatcher.
- **Enterprise publication** on approved deployment: trusted service identity submits a signed or attested manifest to registry; registry checks owner, environment compatibility, release approval, schema and permissions; only then may BE discover executable operations for its assigned scope.

An operation is useable only when the published manifest is compatible, the running service is healthy, environment bindings are configured, required auth is satisfied, and the operation is explicitly allowed for the application and workflow package.

## 5. Three execution shapes

1. **Local**: Embedded BOB invokes handler via DI, AMIE through existing local adapter. Avoid per-step central roundtrips.
2. **Remote command**: Central BOB persists an outstanding activity/command + outbox; broker delivers command to owning capability; worker validates and executes; correlated outcome resumes central BOB once.
3. **Capability subworkflow**: One approved message invokes a pinned embedded subworkflow (e.g. process staged batch rows sequentially). Worker performs several local handler/AMIE steps and emits aggregate/progress events; central host does not schedule every row's local steps.

## 6. Definition of reusable success

A safe operation registered once can appear in the BE catalog, bind to a published BPMN service task and AMIE rule, execute in its authorized host, produce consistent run/audit evidence and then be reused in a **second unrelated workflow without a new handler or BOB Core change**.

## 7. Immediate acceptance proof / no fake completion

DEVIN must show: actual handler class in repo, DI registration, manifest metadata and API response, registry approval state, BE operation inspector with typed inputs, a runnable approved BPMN path, existing AMIE runtime invocation, an outcome and audit event, a negative direct-API permission test, and replay/restart tests. Demo fixtures do not prove a real CyberArk integration.

---


<a id="sdk-section-2"></a>

# SDK 01 - Canonical Contracts, Identity, and State Machines

Status: PROPOSED until reconciled to existing repo. Dependencies: `docs/contracts/OPERATION-CONTRACT.md`, `docs/contracts/MESSAGING-CONTRACT.md`, `docs/architecture/04-AMIE-BINDINGS.md`.

## 1. Contract boundaries and proposed assembly paths

- `/Unity.Capabilities.Contracts/CapabilityManifest.cs`: metadata only; no executable classes in serialized payload.
- `/Unity.Capabilities.Contracts/OperationDescriptor.cs`: operation key/version, schema, permission, side effect, auth scope, retry/reconciliation, transport, AMIE requirements, examples.
- `/Unity.Capabilities.Contracts/OperationInvocation.cs`: request DTO + authenticated execution context.
- `/Unity.Capabilities.Contracts/OperationOutcome.cs`: typed disposition, safe reason, result and external reconciliation reference.
- `/Unity.Capabilities.Hosting/IUnityOperationHandler.cs`: compile-time typed operation interface.
- `/Unity.Capabilities.Hosting/OperationDispatcher.cs`: verified allowlist routing to DI handler; no client-provided CLR name resolution.
- `/Unity.Capabilities.Registry/ManifestPublisher.cs`: deployment/privileged registry action, NOT triggered merely by runtime scanning.
- `/Unity.Capabilities.Kafka/CommandConsumer.cs`: schema/auth/inbox/dispatch, outcome and outbox.
- `/Unity.Capabilities.BOB/EmbeddedWorkflowAdapter.cs`: bridge to shared interpreter.
- `/Unity.Capabilities.AMIE/AmieRuleAdapter.cs`: thin adapter to current existing rule engine.

Choose final project names only after JOB-00 inventory. Namespace conventions must follow existing services.

## 2. Proposed C# interface sketches

```csharp
public interface IUnityOperationHandler<TRequest, TResponse>
{
    Task<OperationOutcome<TResponse>> ExecuteAsync(
        TRequest input, UnityExecutionContext context,
        CancellationToken cancellationToken);
}

public sealed record UnityExecutionContext(
    string ApplicationKey, string DefinitionKey, string DefinitionVersion,
    Guid RunId, string ActivityId, string CorrelationId, string CausationId,
    string ActorContextRef, string PackageDigest, string IdempotencyKey,
    string? BatchId, Guid? RecordGuid, string? TraceParent);

public enum OperationDisposition
{
    Succeeded, NoChange, Rejected, Failed, UnknownExternalOutcome
}

public sealed record OperationOutcome<T>(
    OperationDisposition Disposition, string ReasonCode, string SafeReason,
    T? Result, string? ExternalOperationRef, string? ResultHash);
```

These are examples for contract alignment, NOT source already available. An input DTO contains business data; the execution context contains provenance and auth references. Data types must be serializable and compatible with existing library conventions.

## 3. Required OperationDescriptor fields

| Group | Required property | Validation |
|---|---|---|
| Identity | capabilityKey, operationKey, contractVersion | Unique key + compatible version; names cannot shadow another capability |
| Service | codeVersion, owner, manifestDigest | Code/manifest release must agree |
| Data | input/output JSON Schema, required fields, classification, fixture IDs | Validate examples and required fields; never generate schema from untrusted runtime input |
| Authentication | policy name, permitted resource scopes, service audience | Fail closed at registry and worker; no trust from UI alone |
| Side effects | Read / LocalTransform / ExternalWrite / HighImpactExternalWrite | Write has idempotency/reconciliation and control references |
| Execution | EmbeddedLocal / KafkaCommand, timeout and cancellation | At least one supported mode; no unapproved direct route |
| AMIE | required rule/data descriptor versions | Rule must resolve, pin and type-check before publish |
| Messaging | inbound/outbound logical types, partition/correlation/idempotency strategy | Broker binding checked per environment |
| Evidence | audit code, redaction profile, safe test fixture | No secrets or raw sensitive account payload in audit |

## 4. Lifecycle / state transitions

### Operation manifest

`CodeWritten -> BuiltAndTested -> ServiceApproved -> Deployed -> ManifestSubmitted -> Registered -> Available -> Deprecated -> Retired`.

- `Registered` is metadata-only. `Available` also requires healthy compatible service, environment ACL/policy and permitted application scope.
- Code release and configuration release are separate. A workflow can only invoke an operation available in its deployment environment and compatible with its pinned contract.
- Removing an operation from available list does NOT delete historical manifest metadata used for audit.

### Workflow definition

`Draft -> InReview -> Approved -> Published -> Active -> Retired`.

- Editing Published or Active creates a new Draft/version; all existing runs stay pinned.
- Publication requires BPMN subset/compiler validation, typed bindings, rule and operation compatibility, approved roles and change evidence.
- `Approved` is not `Active`; Operations owns activation according to real bank controls.

### Process run

`Created -> Running -> PauseRequested -> Paused -> Running`, plus `CancelRequested -> Cancelled`, `Completed`, `Failed`, and `AwaitingOutcome`/`ReconciliationRequired` substates as needed.

- Pause is cooperative at safe checkpoint; active CyberArk HTTP call cannot be magically stopped/undone.
- Cancel is cooperative; terminal `Cancelled` only when known work has settled or is explicitly marked unresolved.
- RetryFailedStep is permitted only where the dispatcher can establish prior outcome or safely reconcile it.
- RestartAsNewRun creates a fresh RunId and linkage to previous RunId; never erases original audit history.

## 5. Contract version pinning and backwards compatibility

- Workflow package pins explicit `operationKey@contractVersion`, AMIE `ruleKey@version`, called-subworkflow version, source schemas and package digest.
- Additive optional DTO fields may be compatible only after contract tests; removing required inputs or changing side-effect semantics is a breaking version.
- At runtime, no implicit fallback to `latest`. If pinned dependency is absent, fail start or enter `BlockedByDependency` with audit.
- Service code versions are tracked separately from operation contract versions; a new service deployment may preserve the contract only if compatibility tests pass.

## 6. API contracts (all future routes proposed)

- `GET /api/v1/capabilities`, `GET /api/v1/capabilities/{key}/operations`, `GET /api/v1/operations/{key}/versions/{version}`.
- `POST /api/v1/manifests/validate`, `POST /api/v1/manifests/submit`, `POST /api/v1/manifests/{id}/approve`, `GET /api/v1/manifests/{id}/readiness`.
- `POST /api/v1/operation-tests/{key}/execute` (non-PROD approved fixture only, separate test permission).
- `POST /api/v1/workflow-drafts/{id}/validate`, `POST /api/v1/workflows/{key}/runs` and authorized lifecycle endpoints.

Every endpoint must be OpenAPI-described and tested directly without a browser, including denied and invalid requests. Never let a generic test endpoint execute arbitrary operations or reach PROD.

---


<a id="sdk-section-3"></a>

# SDK 02 - Automatic Registration, Service Bootstrap and Registry Publication

Status: implementation design; current AMIE/capability conventions are unknown until source audit.

## 1. Creating a service (dev workflow)

1. Select the domain owner and service archetype: CyberArk/PAM, Data, Email, Reporting, Identity or Legacy. Determine data owner, environment policies, and broker requirements.
2. Create the service from an approved .NET service template; reference shared Unity.Contracts and Unity.Hosting packages already reviewed by Wells Fargo.
3. Implement typed handlers. Write handler metadata (`UnityOperation` attribute or equivalent compile-time registration) and DTOs; no dynamic code execution. Handler must be DI-constructible and in an allowlisted compiled assembly.
4. Classify each operation: read, local transform, external write or high-impact external write; define permission, timeouts, idempotency and result reconciliation.
5. Implement adapter clients and secret refs through approved DI; do not put credentials in handlers/manifests.
6. Add AMIE rule descriptors only as **references/typed bindings**. Existing AMIE compiler/evaluator remains authoritative.
7. Declare logical command/outcome contracts; environment settings map logical keys to authorized Kafka topics/consumer groups.
8. Register handlers in startup; on failure in production registration fail fast with deterministic diagnostic (duplicate key, invalid schema, missing policy, wrong major version).
9. Generate manifest + JSON Schema + examples + OpenAPI metadata as build outputs; verify against approved fixtures.
10. Run CI tests, create/approve ordinary service-code release, deploy via approved pipeline, submit manifest via privileged service identity.
11. Registry checks signature/provenance, service release, owner, compatibility, policies, and environmental readiness; BE discovers only the properly scoped descriptors.
12. Reuse the operation from an authorized workflow; observe correlated audit and repeat in a second workflow without code changes.

## 2. Example registration (illustrative, not verified repo API)

`/Unity.Capability.CyberArk/Program.cs`

```csharp
builder.Services
  .AddUnityCapabilityHost(o => o.CapabilityKey = "CyberArk")
  .RegisterApprovedOperations(typeof(GetAccountHandler).Assembly)
  .UseExistingAmieAdapter()
  .UseEmbeddedBob()
  .UseKafkaContracts()
  .UseStructuredAudit();
```

The implementation must scan **only** assemblies allowed by the deployed service configuration or use compile-time generator registration. Do not accept assembly names or method names from the network or manifest consumers.

`/Unity.Capability.CyberArk/Operations/GetAccountHandler.cs`

```csharp
[UnityOperation("CyberArk.GetAccount", "1.0",
   Policy = "PAM.Account.Read", SideEffect = "Read")]
public sealed class GetAccountHandler
    : IUnityOperationHandler<GetAccountRequest, GetAccountResponse>
{
    private readonly ICyberArkClient _client;
    public GetAccountHandler(ICyberArkClient client) => _client = client;

    public async Task<OperationOutcome<GetAccountResponse>> ExecuteAsync(
        GetAccountRequest request, UnityExecutionContext context,
        CancellationToken ct)
    {
        // Actual adapter, error mapping and authorization must be implemented
        // against the existing service. No mock production client.
        var account = await _client.GetAccountAsync(request.AccountRef, ct);
        return new(OperationDisposition.Succeeded, "ACCOUNT_FOUND",
                   "Account read succeeded", new(account), null, null);
    }
}
```

Example intentionally omits credentials and concrete SDK/library details. Real code must use existing policy, cancellation, retry and audit interceptors.

## 3. Startup validation algorithm

1. Discover allowed handler type and declaration.
2. Verify exactly one expected typed interface and DI registration.
3. Verify unique operation key/version and permitted compatibility major.
4. Validate input/output JSON schemas against DTOs, fixtures and declared classification.
5. Ensure required permission/scope and side-effect policy are supplied.
6. For writes, require idempotency behavior and `UnknownExternalOutcome` reconciliation strategy.
7. Check message contract names, required fields, correlation and partition key.
8. Validate AMIE descriptor references are resolvable for declared runtime where needed.
9. Construct immutable manifest with deterministic digest; emit startup diagnostic state.
10. Expose metadata to authenticated deployment/registry agent, but DO NOT self-approve.

## 4. Manifest publication lifecycle

Build CI produces manifest artifact and approved service release -> release pipeline deploys binary -> signed deployment identity submits manifest -> Registry validates owner, signature, compatible handler/codeVersion, exact schema, environment ACL -> Registry marks `Registered` -> operational readiness checks mark `Available` -> BE discovery is scope filtered -> BOB can bind only `Available` approved operations. Republish or revoke under control; no arbitrary end-user registration from BE.

## 5. New primitive vs configuration decision

Ask in order:

- Is there an approved operation that already produces the required output? Reuse it.
- Can a combination of existing operations, BOB control flow and AMIE mapping produce the result without bypassing security? Configure it.
- Is a new domain primitive required (e.g. verified safe movement)? Implement once in owning capability with a reviewed code release, schema, policy and tests.
- Is the proposed primitive unbounded (generic REST executor, arbitrary SQL, direct C# eval)? Reject and replace with typed approved operation.

## 6. DEVIN coding boundaries

- Preserve existing DI host style, .NET version, project names and namespace conventions.
- Do not generate a new central AMIE runtime or duplicated BOB interpreter.
- Do not hardcode physical topic names or endpoints into descriptors.
- Do not include DCMS as a capability kind. DCMS is an application/workload config.
- Publish PR with actual `/Project/Folder/File.cs` paths and New/Updated/Deleted/No Change summary.
- Add unit/contract tests and a demo showing operation discoverable in BE and reject unauthorized direct call.

---


<a id="sdk-section-4"></a>

# SDK 03 - BOB, AMIE, Capability and Kafka Interaction Protocol

This is the interaction contract DEVIN must implement or map to existing code. It is a **proposed architecture**, not a verified current runtime.

## 1. Central versus embedded host boundary

```mermaid
sequenceDiagram
  participant BE as BE API / Designer
  participant CB as Central BOB
  participant SQL as MSSQL state and outbox
  participant K as Kafka
  participant CH as Capability Host / Embedded BOB
  participant AM as Existing AMIE
  participant H as Approved handler
  participant AU as Audit
  BE->>CB: Start approved workflow package
  CB->>SQL: Persist run + waiting command + outbox atomically
  SQL-->>K: Outbox dispatcher emits authorized command
  K-->>CH: Deliver command (may be repeated)
  CH->>CH: Verify auth, digest, inbox key, compatibility
  CH->>AM: Evaluate pinned rule locally
  AM-->>CH: Typed decision + reason
  CH->>H: Execute handler using typed mapped input
  H-->>CH: Outcome incl external reference
  CH->>AU: Append safe operation/decision evidence
  CH->>K: Publish correlated outcome via outbox
  K-->>CB: Deliver outcome (may be repeated)
  CB->>SQL: Compare-and-swap complete waiting activity
  CB-->>BE: Status projection / secured near-real-time hint
```

Embedded BOB uses the **same** BPMN parser/compiler/interpreter as central BOB; its host adapter selects local DI, AMIE, and storage/transport. Central BOB may wait durably in MSSQL. Do not implement an application-specific local workflow engine inside the CyberArk adapter.

## 2. Compilation of a workflow designed in BE

1. Load BPMN 2.0 XML + BPMN DI geometry; reject malformed XML, unsupported semantic elements, unreachable branches, missing IDs and ambiguous joins.
2. Parse vendor-neutral service tasks / business rule tasks; read Unity extension bindings (operationKey@version, ruleKey@version, input/output mapping, host, retry policy).
3. Resolve approved Capability Registry manifest and AMIE rule descriptor, including ownership, availability, schemas, permission and side effect.
4. Type-check every source (trigger field, item field, prior task output, rule output, constant, environment ref, secret ref) against required input. Null/default/classification policy must be explicit.
5. Resolve child/call activity and sequential multi-instance semantics. Pin exact dependency versions and output a deterministic package lock/digest.
6. Check configured execution host can access the requested local handler and AMIE rule; otherwise require remote command mode. Reject silent transport fallback.
7. Enforce allowable concurrency, timeouts, cancellation and retry/reconciliation behavior; no unsafe automatic retry for CyberArk external writes.
8. Emit prepublish validation results by BPMN element ID, field path, severity, code, description and suggested action. Only error-free approved definitions can publish.

## 3. On executing a local task

1. Shared BOB evaluates task input binding in a typed workflow context.
2. Before a privileged handler, authorize service identity and the signed actor context/scope at dispatch; BOB's previous validation alone is not sufficient.
3. Dispatcher resolves an allowlisted `operationKey@contractVersion` to a DI handler. It never reflects untrusted CLR method names.
4. Invoke with `UnityExecutionContext`, cancellation token, per-operation timeout and safe telemetry scope.
5. Validate output schema, redact classified data, persist outcome/audit and advance token exactly once.
6. For local AMIE business-rule task, call existing AMIE API, not a new rule interpreter; obtain typed decision and safe reason. Version pin is mandatory.

## 4. On remote task through Kafka

Before publish, persist *both* pending command state and outbox record in one BOB-owned transaction. Kafka producer publishes pending outbox. The capability consumer validates schema, broker principal, caller audience, policy, idempotency key and package version, then checks inbox. For duplicates, replay prior stable outcome or reject safely. Execute handler and persist outcome in same capability-controlled transaction when possible; external CyberArk writes are not part of that transaction and require reconciliation.

The outcome envelope includes command ID, causation/correlation ID, run ID, activity ID, operation key/version, status, reason code and safe result reference. The BOB outcome consumer updates its waiting activity only once by optimistic concurrency. Out-of-order and late messages are recorded; they do not advance the wrong run.

## 5. Failures and reconciliation

| Failure | Required behavior | Forbidden behavior |
|---|---|---|
| Invalid input schema | Reject before dispatch, audit safe error | Invoke handler with half-built DTO |
| AMIE rule false | Follow configured BPMN branch, record rule reason | Treat false as CyberArk write failure |
| Handler returns NoChange | Persist business NoChange and continue | Report update success without a write |
| CyberArk returns clear failure | Record Failed with safe reason/retry policy | Infinite unbounded retry |
| Network timeout after write request | `UnknownExternalOutcome`; reconcile with external reference/state | Blindly retry a possibly successful write |
| Kafka message duplicate | Inbox dedup, replay stable outcome | Execute same write twice |
| Kafka outcome lost | Keep durable waiting state, retry transport or query correlation | Move token to success without evidence |
| Worker crashes mid-batch | Resume at checkpoint and reconcile current row | Restart batch from row one without checking outcomes |
| Pause while write in flight | Set PauseRequested, stop new steps at safe checkpoint | Kill ongoing HTTP call and claim rollback |
| Cancel | Cooperative stop, mark unfinished work explicitly | Delete history or claim external rollback |
| Retired rule/handler after start | Keep pinned version if still available or mark dependency blocked | Replace with newest rule without review |

## 6. DCMS as application-level sequence

Central BOB: authorized manual CSV / future API start -> Data capability stage -> create batch and row GUIDs -> send `ExecuteEmbeddedWorkflow` to CyberArk capability -> wait for result -> report generation -> Email Capability -> summarize and close. Embedded BOB: get bounded page -> sequential multi-instance row loop -> CyberArk.GetAccount -> AMIE eligibility -> AMIE mapping -> CyberArk ApplyAllowedPatch in memory -> CyberArk AddOrUpdate -> row outcome persist -> next row -> aggregate completion. This is a **configured** workflow, not special code in BOB or SDK.

## 7. Evidence contract

At minimum emit `WorkflowStarted`, `TaskScheduled`, `RuleEvaluated`, `OperationRequested`, `OperationCompleted|UnknownOutcome`, `RowOutcomeRecorded`, `WorkflowPaused|Resumed|Cancelled|Completed`, `NotificationRequested`, `NotificationOutcome`, `ConfigurationPublished|Activated`, and `ControlAction` with actor, UTC, version digest, correlation, run/activity, source references and safe summary.

---


<a id="sdk-section-5"></a>

# SDK 04 - Schema-driven BE Forms and AMIE/BOB Binding

## 1. Why the descriptor is a UI contract

When capability publishes a `GetAccount@1.0` descriptor, BE should automatically render: operation title, required/optional input fields, data types, source binding controls, output variables, execution host choices, permissions/side effects, timeout/retry and test fixture. No CyberArk-specific Razor form should be required for each operation.

## 2. Unified typed binding descriptor (proposed)

```json
{
  "targetField": "accountRef",
  "sourceKind": "CurrentItem",
  "sourcePath": "item.accountRef",
  "expectedSchemaRef": "schema://cyberark/account-ref/1.0",
  "nullable": false,
  "onMissing": "ValidationError",
  "dataClassification": "Internal"
}
```

Supported source kinds for MVP: WorkflowInput, CurrentItem, PriorOperationOutput, AmieRuleOutput, ConstantAllowlisted, EnvironmentBinding, SecretReferenceServerSide. The user sees logical references only; raw secrets must never be resolved into browser fields or BPMN XML.

## 3. Binding builder behavior

1. User selects an operation in Capability Catalog and clicks Add to Workflow.
2. Designer inserts a service task with stable BPMN element ID and pinned operation key/version.
3. Inspector fetches operation descriptor from authorized API and dynamically renders input slots.
4. For each slot, user picks source kind; picker offers only in-scope upstream outputs with a compatible JSON schema/data classification.
5. A missing required field is visibly invalid. An incompatible type is invalid even if a fake preview happens to work.
6. On adding AMIE rule, inspector loads rule descriptor and offers required facts from available workflow context; resolved decisions become branch conditions.
7. User chooses permissible host (Local vs Kafka) only from operation manifest and workflow deployment constraints.
8. Save persists a Draft (ETag/optimistic concurrency), Validate calls backend BOB compiler and AMIE adapter validator, Preview runs only deterministic DEV fixtures.
9. A published package locks exact manifests/rules/BPMN/subprocess versions; designer previews do not grant production execution.

## 4. Dynamic form generation

Inputs may have `type`, `format`, `enum`, `required`, `minLength`, `maxLength`, `maximum`, `pattern`, `description`, `classification` and optional approved UI hints. Required data is derived from the schema, never from the decorative mockup. The form engine supports hidden fields only for security/data dependency, server-side validation and structured error display. It must not expose an unrestricted JavaScript expression or C# editor to end users.

## 5. Example DCMS bindings

| Task | Field | Source | Validation |
|---|---|---|---|
| StageBatch | uploadedCsvRef | trigger.uploadRef | Authorized non-secret file ref, file passed safety checks |
| GetPage | batchId | steps.stage.output.batchId | Typed batch identifier, paginated bounds |
| GetAccount | accountRef | item.accountRef | Required, correct scope |
| AMIE.AccountEligibility | row, account | item + steps.get.output.account | Pinned rule and fact schemas match |
| AMIE.AttributeMap | row, platform | item + steps.get.output.platform | Only allowed custom attributes emitted |
| ApplyAllowedPatch | account, patch | previous account + rules.map.output.patch | Platform-specific patch schema validated |
| AddOrUpdate | modifiedAccount | steps.apply.output.account | Write authorization + reconcile policy |
| RecordRowOutcome | recordGuid, result | item.guid + steps.upsert.output | Side-effect outcome distinct from rule-pass |
| ComposeBatchReport | batchId | workflow.input.batchId | Counts reconciled against terminal rows |
| RequestNotification | reportRef, recipientPolicyRef | steps.report + config | Permission and recipient allowlist |

## 6. Designer error contract

Return errors as `{code, severity, bpmnElementId, fieldPath, message, suggestedAction}`. Required examples: `BIND_REQUIRED`, `BIND_TYPE_MISMATCH`, `BIND_UNAUTHORIZED_SCOPE`, `RULE_VERSION_UNAVAILABLE`, `OPERATION_NOT_APPROVED`, `HOST_MODE_UNSUPPORTED`, `BPMN_ELEMENT_UNSUPPORTED`, `DUPLICATE_OPERATION_KEY`. BE must display them on the affected node and in a keyboard-accessible issue list. A disabled Publish button is not a substitute for backend rejection.

## 7. Example data source GUI

- Node selected: `Task_GetAccount`.
- Operation inspector: `CyberArk.GetAccount@1.0`; permission `PAM.Account.Read`.
- Required `accountRef` -> choose Current Item -> `DCMS.Row.AccountRef`.
- Output `AccountRecord` -> name `account`.
- Test contract -> sanitized fixture only (DEV); result visible with safe event IDs.
- Validate -> green only if BE/backend schema, AMIE dependencies, host and permissions agree.

## 8. Explicit design alternatives

For MVP, an auto-generated property inspector plus a controlled binding picker is more feasible than a full no-code generalized forms builder. Advanced expression editing, custom renderers, full human-task form designer and advanced BPMN elements remain backlog unless first pilot proves they are required.

---


<a id="sdk-section-6"></a>

# SDK 05 - Security, Audit, Operator Controls, and Release Promotion

## 1. Least privilege / identity

Every invocation checks backend API auth, workflow/app scope, resource scope, service identity and operation permission, **again in the capability worker**. A user may view only their own batch without permission to view the BPMN process, inspect safe audit events or operate runs. BE controls visibility but does not enforce security alone. Align bank roles to actual SSO groups after owner review.

Proposed roles: BusinessRequester, BusinessExecutor, WorkflowDesigner, RuleMaintainer, CapabilityMaintainer, WorkflowReviewer, ProcessOperator, ReleaseOperator, Auditor and PlatformAdministrator. Role names are placeholders pending enterprise mapping. No shared wildcard admin role for ordinary users.

## 2. Audit storage strategy

MSSQL append-only events are the operational source for reconstruction. Tables for current run/batch status are projections for fast reads. Preserve event version, eventId, UTC event/record time, run/activity, message/correlation/causation, actor/service identities, operation/rule/package version references, batch/row GUID, reason/outcome, resource scope, relevant ServiceNow ticket and runbook/control ID, and payload hash/protected reference. Prevent update/delete for normal service roles; consider write-once controls, retention and ledger separately with bank approval.

Audit export is a controlled, scope-filtered API; redact credentials, raw account content, tokens and sensitive CSV data. The event history is not a secret copy of source payloads.

## 3. Operator semantics

| Command | Precondition | Result / audit | Forbidden |
|---|---|---|---|
| Pause | Running, ProcessOperator for scope, reason, current revision | PauseRequested; reach Paused at safe boundary, emit reason/time | Pretend to reverse a started write |
| Resume | Paused, compatible pinned dependencies, authorized | Running, queue next task, audit | Resume incompatible retired dependency silently |
| Cancel | Running/Paused, authorized reason | CancelRequested; settle or reconcile outstanding, then Cancelled | Remove historical evidence |
| RetryFailedStep | Failed at safely retryable step, reconciled prior attempt | New attempt on same run with linkage | Blind retry on unknown CyberArk write |
| RestartAsNewRun | Terminal run, authorized and policy allows | New runId linked to old, new explicit input selection | Reuse old runId or alter original outcomes |
| Export audit | Scoped auditor access | Evidence export with redaction and audit of export | Leaks raw secret/sensitive fields |

All mutating actions require expected revision/ETag to prevent two operators issuing conflicting commands. UI shows pending acknowledgement and refreshes from server; local click is not authoritative success.

## 4. Release and production control flow

- Author creates/validates draft in DEV. BPMN, AMIE rules, capability contract versions and bindings manifest are locked into immutable package digest.
- Reviewer checks diff, complete test evidence, maker/checker separation where required, and change ticket. Approval is an authoritative backend event, not a typed ticket field.
- UAT deploys **exact package bytes**, substitutes only allowlisted environment refs, executes regression and captures evidence.
- Release Center production preflight checks signature/digest, compatible live service manifests, Kafka ACL, secrets refs without exposing values, rule versions, approved CA/control evidence and user rights.
- Operations-controlled pipeline activates package; developer does not need PROD access. Existing runs stay pinned, new runs receive new active version.
- Rollback selects previously approved package for **future** starts. It does not roll back external CyberArk writes.

## 5. Controls vs software permissions

Runbooks/controls specify required operational procedure, permitted exception path, required evidence, escalation and owner. Roles specify who may invoke which API. Both must be represented and validated separately. Actual Wells Fargo CAs, control IDs, retention and ServiceNow integration are UNKNOWN until verified by authorized owner. Never invent them or mark a mock ticket as bank approval.

## 6. Production-safe testing

- Developer/tester fixtures run only in isolated DEV/UAT with approved test accounts and test broker bindings.
- Destructive or external writes must use approved fake server/test tenant or explicit owner permission.
- No API Regression button executes production writes or creates broker subscriptions from arbitrary user input.
- Negative tests: denied direct API, altered manifest digest, wrong environment binding, duplicate command, timeout during external write, cross-tenant data disclosure, self-approval and missing control evidence.

---


<a id="sdk-section-7"></a>

# SDK 06 - DCMS: End-to-End Composition, Configuration, Execution and Evidence

**Purpose:** Use the user-described DCMS behavior to prove the generic Unity platform. DCMS must remain a workload/application, not SDK/BOB special code. Field names, CyberArk DTOs and API return codes must be confirmed in repo.

## 1. Source-described business process (do not reinterpret)

- User uploads CSV containing new values for account/platform custom attributes.
- Import rows into a data-owned table. Assign **one batch number** to the import and a **GUID to every row**.
- Process each row sequentially for the initial workflow.
- Locate the corresponding CyberArk account.
- Replace/add the specified custom attribute values **in account memory first**.
- Execute add/update account API call.
- Record per-row success/failure/pass/skipped and human-useful reason.
- After batch completion, generate report with all pass/fail/success reasons and send via Email Capability.
- Future (NOT currently implemented): approved API ingestion, scheduled AutoSys/DB API pull, additional trigger sources; leave extension seams rather than implementing prematurely.

## 2. Service inventory and compile-time primitives

| Primitive (proposed stable key) | Owner | Input -> Output | Side effect | Required protection |
|---|---|---|---|---|
| Data.ValidateUpload | Data/ingestion | uploadRef -> validation | Read | file policy, schema, classification |
| Data.StageBatch | Data/ingestion | validatedRef -> batchId, rowCount | DB write | idempotent upload key |
| Data.GetBatchPage | Data/ingestion | batchId, pageCursor -> page rows | Read | owner-scope, pagination |
| CyberArk.GetAccount | CyberArk | accountRef -> accountRecord | Read | PAM.Account.Read |
| CyberArk.ApplyAllowedAttributePatch | CyberArk | accountRecord, patch -> modifiedRecord | In-memory transform | platform allowlist |
| CyberArk.AddOrUpdateAccount | CyberArk | modifiedRecord + revision -> writeOutcome | External write | PAM.Account.Update, reconciliation |
| Data.RecordRowOutcome | Data/ingestion | rowGuid, disposition, reason -> persisted status | DB write | expected revision + idempotency |
| Reporting.ComposeBatchReport | Reporting | batchId -> secureReportRef | Artifact write | scope, redaction |
| Email.SendApprovedNotification | Email | reportRef, recipientsPolicyRef -> delivery outcome | External send | recipient policy + deduplication |

All keys are **candidates**. Existing CyberArk and data operations in the repo must be mapped, not rewritten.

## 3. AMIE descriptors (proposed, not current source names)

- `DCMS.ValidateAccount@1`: facts CurrentRow+GetAccountResult+Platform; result Eligible/Skip/Reject with reasonCode.
- `DCMS.MapAttributes@1`: facts CurrentRow+Platform; result typed `CyberArkAttributePatch` of four allowed custom attributes.
- `DCMS.ShouldUpdate@1`: facts original account + proposed patch; result Update/NoChange and reason.
- `DCMS.ClassifyBusinessResult@1`: facts validation+actual external outcome; result business status/reason (do not conflate with successful validation).

Rules are configuration. No static `if application == DCMS` in CyberArk or BOB. AMIE evaluator is existing code; use adapter.

## 4. UI configuration click path

1. **Application Studio** -> New application -> enter `DCMS`, owner, allowed scopes, process template and business display settings -> Save draft.
2. **Capability Catalog** -> inspect `Data.StageBatch@ver`, `Data.GetBatchPage@ver`, `CyberArk.GetAccount@ver`, `CyberArk.AddOrUpdateAccount@ver`, `Reporting.ComposeBatchReport@ver`, `Email.SendApprovedNotification@ver` -> check availability and permission.
3. **Workflow Library** -> Create Draft from `Batch + Sequential Rows` template -> name `DCMS.Batch` -> select Central BOB.
4. **BOB Designer** -> configure start trigger (CSV upload), stage task, embedded CyberArk subworkflow task (Kafka dispatch), await correlated result, report task, email task, end event; link connections; save.
5. **Embedded subworkflow** -> sequential multi-instance over data-owned page iterator; GetAccount -> AMIE.Validate -> exclusive gateway; Map -> ApplyPatch -> AddOrUpdate -> RecordRowOutcome. Continue on configured row failure after recording outcome.
6. **AMIE Rules** -> bind rule descriptors to typed facts. Map each source CSV column to target platform custom attribute; configure missing-value policy and NoChange decision; execute fixture preview.
7. **Triggers & Forms** -> choose Manual CSV; generate required data input schema and file metadata; future API/AutoSys trigger marked planned/not active.
8. **Kafka Contracts** -> view logical command/outcome types, required correlation, partition policy; no freeform topic editing.
9. **Environment Bindings** -> choose `DEV` approved CyberArk endpoint ref, staging API, broker logical topic and test recipients; verify dependencies, no credential values.
10. **Validate Draft** -> backend BPMN/compiler/schema/rule/operation/host/permission checks; fix errors on node inspector.
11. **API Regression** -> test 5-row success+failure fixture, duplicate command, missing account, declined rule, uncertain write, row checkpoint, email failure and role denial.
12. **Workflow Library** -> Submit Review -> independent approve -> Publish immutable version. **Release Center** -> UAT exact digest, then production only after real bank approvals and Operations activation.
13. **Business Work Queue** -> upload CSV (authorized user) -> start batch; see counts and record reasons. **Run Monitor** for authorized staff -> diagram overlay, correlation, activity detail. **Audit** -> reconstruct run and report evidence.

## 5. Runtime logical sequence

```mermaid
flowchart TD
  U[Authorized CSV upload] --> S[Data validates and stages batch/row GUID]
  S --> CB[Central BOB starts pinned DCMS.Batch]
  CB --> OUT[Persist command/outbox; Kafka dispatch]
  OUT --> EB[CyberArk Embedded BOB receives batchRef]
  EB --> PAGE[Data-owned paginated row fetch]
  PAGE --> ROW[Sequential row iteration]
  ROW --> GET[CyberArk.GetAccount]
  GET --> RULE[Existing AMIE Validate / Map / ShouldUpdate]
  RULE --> DEC{Eligible and change?}
  DEC -->|Yes| PATCH[Apply allowed changes in memory]
  PATCH --> WRITE[CyberArk AddOrUpdate]
  DEC -->|No| RESULT[Persist skipped/nochange/rejected reason]
  WRITE --> RESULT
  RESULT --> NEXT{More rows?}
  NEXT -->|Yes| ROW
  NEXT -->|No| DONE[Publish correlated batch outcome]
  DONE --> REPORT[Reporting composes artifact]
  REPORT --> EMAIL[Email Capability sends approved report]
  EMAIL --> END[Central BOB records terminal business status]
```

## 6. Exact example fixture

- CSV source: 5 rows `accountRef,platformKey,application,costCenter,owner,businessUnit` (illustrative column names).
- Batch: `BATCH-DCMS-0001` with five row GUIDs generated at staging.
- Expected: row 1 updated; row 2 no change; row 3 rejected missing account; row 4 skipped by AMIE rule; row 5 external call timed out after request, marked UnknownExternalOutcome pending reconciliation.
- Per-row invariants: batchId stable, unique rowGuid, one active claim per row, no second write for duplicate command without reconcile, reason code persisted, audit has rule/operation/package versions.
- Aggregate counts **must reconcile** to all rows. `Total = Succeeded + NoChange + Rejected + Skipped + Failed + UnknownOutcome + InProgress + Pending`; terminal count should exclude unknown states until resolution policy says otherwise.
- Report contains status and human-readable reason per row, not raw credentials. Email status is separate from CyberArk update outcome.

## 7. Recovery and release proof

- Crash after row two: after restart rows 1 and 2 are not blindly processed again; row three is resumed or claimed safely.
- Broker delivers `ExecuteEmbeddedWorkflow` twice: inbox prevents duplicate batch side effects.
- Timeout after CyberArk write: query/reconcile external state before retry; do not assume failure.
- Pause mid-row: complete or reconcile current external write, then pause at checkpoint; show PauseRequested until actually paused.
- Replace AMIE version in DEV: new draft package required; existing batch remains pinned.
- Trigger source changes later from CSV to approved API: input adapter changes, downstream staged-row contract and BOB/AMIE composition remain stable.

## 8. Demonstration success criteria

Present in BE: source/upload -> batch + row GUIDs -> configured BPMN with registered operations -> AMIE mapping/eligibility -> one real/approved nonprod CyberArk update or clearly marked stub -> final persisted row reasons -> report/email outcome -> live business dashboard -> technical run overlay -> audit reconstruction. Also demonstrate a second workflow (Hygiene) reusing at least one capability operation without source edits; if second pilot not complete, mark it pending, not demonstrated.

---


<a id="sdk-section-8"></a>

# SDK 07 - DEVIN New Capability Service Construction Recipe

## A. Inputs DEVIN must obtain

- Existing Unity repository, root `AGENTS.md`, current solution, approved .NET target and CI templates.
- Service name, domain owner, purpose, source data owner, external API/contracts and approved dev/test tenant.
- List of primitives required; do not guess operations from a workflow screenshot.
- Existing AMIE interfaces and BOB embedded hosting types; current Kafka contract/envelope/ACL conventions.
- Required permissions, data classification, timeout, side effects, reconciliation policy and bank controls.

If any key input is absent, report a gap with evidence and propose the smallest safe stub for testing; do not silently invent a production implementation.

## B. Build steps

1. **Inspect first:** Find existing capability framework, handlers, SDK conventions, AMIE runtime. Record reuse vs changes in `JOB-00` audit.
2. **Agree contracts:** Define operation descriptor, DTO/schema, auth policy, messaging, AMIE facts and expected outcomes. Freeze with JSON fixtures and tests before concurrent PRs.
3. **Create service template:** approved .NET service project with health, DI, logging, controlled configuration. Do not add unapproved libraries.
4. **Write domain adapter:** smallest typed client with cancellation, timeouts, exception normalization and test fake. No generic arbitrary HTTP/SQL executor.
5. **Write handler:** implements SDK interface; input/output strongly typed, stable key/version and declared side effect; return structured outcome.
6. **Register:** use trusted assembly registration/compile-generated registry. Startup rejects duplicate keys and malformed metadata. Add test for missing handler registration.
7. **AMIE bridge:** declare needed facts and output schemas, resolve approved published rule via existing AMIE engine; support local evaluation in embedded host.
8. **BOB bridge:** expose handler to local dispatcher and (if needed) remote Kafka execution using same manifest. Confirm exact version pinning.
9. **Broker integration:** subscribe only to allowed logical inbound messages, verify schema/auth/inbox, publish outcome via outbox; derive partition key and correlation fields.
10. **Audit:** emit safe events for request, rule, handler execution and outcome. Audit should reassemble an operation by run/activity IDs.
11. **Public contract:** generate metadata + fixture + OpenAPI test endpoints; backend must be testable without UI.
12. **BE integration:** verify registry lists operation, inspector renders inputs automatically, binding picker type-checks and can insert into BPMN draft.
13. **Regression:** unit, API, schema, denied, duplicate, timeout/crash, redaction, version mismatch and second-workflow reuse.
14. **Submit PR:** source paths, build/test evidence, before/after, restrictions, approval gaps, file summary. No direct PROD deployment.

## C. Reusable PR checklist

- [ ] API contract and `operationKey@contractVersion` stable.
- [ ] Service/class names follow current repository conventions.
- [ ] Local registration tests green, no duplicate/undeclared handler.
- [ ] Manifest published only by approved deployment identity.
- [ ] `InputSchema`/`OutputSchema` and fixtures match compiled DTOs.
- [ ] Auth checked at API **and** worker invocation.
- [ ] AMIE rule metadata typed, rule version pinned; no duplicate AMIE parser.
- [ ] Kafka command/outcome contracts versioned, correlation/idempotency included.
- [ ] In-memory local workflow uses shared BOB core and DI.
- [ ] External write reconciliation specified; retries cannot cause duplicate mutations.
- [ ] Evidence append-only with no secrets/raw sensitive payload.
- [ ] BE inspector configures operation from descriptor, not hardcoded page.
- [ ] OpenAPI regression includes denied/invalid paths.
- [ ] At least two workflow fixtures reuse the same handler.
- [ ] Reviewer receives actual file summary and outstanding CA/approval gaps.

## D. What a handoff from BE should give DEVIN for a missing operation

The designer should export an **Operation Development Request** containing: capability owner, proposed operation key/version, business intent, preconditions, input/output JSON Schema, example fixtures, permissions/resource scope, side effects, mandatory AMIE facts, expected error/outcome codes, external client dependency, timeout, retry/reconcile policy, logical Kafka contracts, audit category, acceptance tests, requested environment and code-review/change ticket references. This is a specification, not automatically executable code.

## E. Correct file path format in PRs

`/Unity.Capability.CyberArk/Operations/GetAccountHandler.cs`
`/Unity.Capabilities.Contracts/OperationDescriptor.cs`
`/Unity.Capabilities.Hosting/Registration/CapabilityRegistrationExtensions.cs`
`/Unity.Capability.CyberArk.Tests/GetAccountHandlerTests.cs`

Follow real repository paths after discovery; above paths are illustrative.

## F. Files and Structure Summary (required in PR response)

New: list paths; Updated: list paths; Deleted: list paths; No Change: related untouched modules; Tests: commands+results; Known gaps: approval/control/library/repo uncertainties.

---


<a id="sdk-section-9"></a>

# SDK 08 - Required API / Contract / Runtime Regression

All BE interactions must have server APIs. Test semantics through API/worker even when a UI screen is not yet built. The routes below are proposed families; align with actual API surfaces from repository inspection.

| ID | Test request / setup | Expected behavior / rejection | Owner |
|---|---|---|---|
| SDK-01 | Start service with two handlers same key/version | Startup fails diagnostic, no ambiguous registration | SDK |
| SDK-02 | Valid compiled handler + manifest fixture | Deterministic schema and registry descriptor | SDK |
| SDK-03 | Manifest submitted by untrusted caller | 403 / no registry state change, audit denial | Registry |
| SDK-04 | Manifest has invalid schema or missing permission | 422 structured field errors | Registry |
| SDK-05 | Registry `Registered` but service incompatible/unhealthy | BE sees unavailable; BOB denies execution | Registry |
| SDK-06 | GET operations as scoped user | Only permitted descriptors/details returned | API/RBAC |
| SDK-07 | GET operation input schema | Required fields/types and classification match DTO | SDK/BE |
| SDK-08 | Bind string to complex object input | Compiler returns BIND_TYPE_MISMATCH and BPMN element ID | BOB |
| SDK-09 | AMIE rule missing required fact | Compiler error; no publish | AMIE bridge |
| SDK-10 | AMIE evaluates valid fixture in embedded host | Typed output and pinned rule version | AMIE bridge |
| SDK-11 | Local handler via BOB | No central per-step HTTP roundtrip | Embedded host |
| SDK-12 | Kafka remote handler invocation | Correlated persisted command/outcome, token resumes once | Kafka/BOB |
| SDK-13 | Duplicate Kafka command | No duplicate write; stable outcome | Capability worker |
| SDK-14 | Timeout after external write sent | UnknownExternalOutcome; reconciliation gate | CyberArk worker |
| SDK-15 | Worker restart after two DCMS rows | Resume remaining rows; no duplicate outcomes | Embedded host |
| SDK-16 | Paused mid-CyberArk write | PauseRequested, safe checkpoint, no false rollback | BOB/operator |
| SDK-17 | Wrong role invokes operator API | 403, state unchanged, denial event | Security |
| SDK-18 | Different user reads batch outside scope | 403/404, no sensitive metadata | BE API |
| SDK-19 | Published workflow edited in place | Reject conflict; copy to new draft required | Definition API |
| SDK-20 | Approved UAT package changed before PROD | Digest mismatch blocks activation | Release |
| SDK-21 | Typed ServiceNow ticket but no approval evidence | PROD preflight blocked | Release |
| SDK-22 | DCMS five-row fixture | Correct per-row and aggregate statuses, reasons and report | DCMS |
| SDK-23 | Email fails after account processing | Account outcomes preserved; email separate | Email |
| SDK-24 | Reuse same GetAccount operation in Hygiene and DCMS | No BOB core or CyberArk handler code change | Integration |
| SDK-25 | Simulate broker reconnect during monitor | Business projection refreshes from API, no ghost state | BE |
| SDK-26 | Audit export with restricted account details | Redacted, scope-limited, export event logged | Audit |
| SDK-27 | Unsupported BPMN element | Validation/publish error, not silent skip | BOB |
| SDK-28 | Disallowed physical Kafka topic from UI | Reject; only approved logical bindings | SDK/Security |

## Response conventions

- 200/201 success with correlation, revision and stable schema.
- 202 accepted async run/control request; do not misrepresent as completed.
- 400 syntax, 401 unauthenticated, 403 unauthorized, 404 scoped invisible, 409 revision/dependency conflict, 422 semantic/schema errors, 503 unavailable dependency. Exact codes must be finalized with existing API conventions.
- Negative tests assert no side effects and audit denial. Positive tests assert actual state, not merely HTTP status.
- Regression results must record test identity, time, environment, package/manifest digest and evidence URI. Fixtures cannot contain real passwords or live account identifiers.

## CI lanes

- PR: build, static security checks, SDK registration and schema fixtures, BOB parser/compiler semantics, AMIE adapter unit tests, API authorization, deterministic UI interaction tests.
- DEV integration: Kafka consumer/outbox/inbox, MSSQL database migrations/checkpoint/audit, fake CyberArk external client, crash/restart and duplicate tests, BE UI+API E2E.
- UAT: exact approved package digest, compatible service versions, controlled test tenant, bank-required CA evidence and smoke test.

Do not label tests as passing without execution evidence in the actual repository pipeline.

---
