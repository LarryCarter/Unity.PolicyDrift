# CVIS PtB → Go-to-Green — Leadership Q&A Speaking Notes

**Audience:** Brad McGruder / leadership · **Speaker:** Larry Carter
**Purpose:** anticipate the questions, answer in value language, don't oversell.

> ★ = answer you must be able to say cold. These three decide how the whole meeting goes:
> **1) Do we have an *official* VM answer yet? · 2) What's the delivery date under each path? · 3) Can we prove when the PtB criteria changed?**

---

## Open in 30 seconds (say this first)

> "Three things: why CVIS went from green to red, what it actually takes to recover, and what I need decided today. This isn't a story about a defect or a team that missed — we were green and approved on June 26th. On July 6th the permit-to-build gate moved from migration-readiness to modernization compliance, and that changed our scope and timeline. Modernization is now real work either way — so the decision in front of you is about sequence and date, and I'll be specific about the ask."

Keep the tone: **factual, evidence-first, no blame.** You're bringing a decision, not an excuse.

---

## A. "What happened" — the history (your strongest ground)

**★ What exactly changed on or around 7/06?**
We were green and on-plan under a VM-based migration. On 7/06 the PtB gate shifted from *migration readiness* to *modernization compliance* — it front-loaded architecture requirements into the migration path. The PtB record shows it: a blocking-condition component was added to the approval that day (GGDH-1747), after our 6/26 approval. That's the before/after in one artifact.

**Why did this only surface three days before the date?**
Because that's when the requirement changed — not when we started paying attention. We were aligned and approved until the gate moved on 7/06. The moment we saw it, we engaged architecture and governance and started re-planning. The timing reflects the change landing late, not the team reacting late.

**What did the team do after you found out?** *(shows responsible response)*
Immediately engaged the architecture and governance teams, evaluated the new modernization expectations, checked whether the existing VMs were still a viable path, and began building schedules for both options so leadership could decide with real numbers. We didn't sit on it.

**Were prior approvals invalidated?**
Effectively, yes. The 6/26 permit-to-build was superseded when the gate changed on 7/06. That's the core point: the requirements moved, our work didn't fail.

**Say this / not that:**
- ✅ "The PtB gating criteria changed mid-execution."
- ❌ "They changed the rules on us overnight." *(true, but it reads as blame — the clean version lands better)*

---

## B. Governance & the decision

**★ Has a definitive VM denial been issued?**
Not in writing that we have. It's been discussed, but there's a real difference between a verbal opinion and a documented decision — which is exactly why I'm asking for an official answer today.

**Who owns the VM exception decision?**
That's one of the things I need clarified. It sits across PtB governance, architecture, and NGDC leadership. I need a named owner so a yes or no is official, not verbal — right now there's no documented decision to point to.

**What specifically caused green → red?**
The gate shifted from migration-readiness to modernization compliance. Concretely it centers on our active-passive model plus related NFR and architecture expectations. **None of it is a code defect or a SonarQube finding** — it's modernization scope. I can show the exact 7/06 change in the PtB record.

**★ What are you asking me to decide?**
Four things:
1. **Sequencing** — move to NGDC now on a VM exception while we modernize, or modernize first and then move.
2. **If moving now** — approve or escalate the VM exception.
3. **A named owner** for VM eligibility, so the decision is official.
4. **Accept a re-baselined delivery date** given the changed gate.
Modernization happens either way — the decision is sequence and date, not whether to do the work.

---

## C. Timeline & delivery

**★ If VMs are allowed, when can you deliver?** *(do NOT oversell this)*
Honestly, the VM path doesn't buy us much time. It could let us move to NGDC on the existing VMs, but it removes none of the modernization work — we still containerize and migrate the 30+ apps, and Unity is already being built for containers, so there's no architectural shortcut. The VM path changes *when* we move, not *how much* work there is.

**★ If modernization is required, when can you deliver?**
Working target is around **February 2027**. December is effectively a lost month between holidays and contractor availability. From there we move Dev → pre-prod → prod, roughly two weeks per environment. I'm still validating exact numbers, so I'd rather commit to the range than a false-precise date.

**What work is ours vs. waiting on someone else?**
The engineering is ours — containerization, the app migrations, the Unity control plane. What's outside our direct control is governance: the VM exception decision, architecture-review sign-offs, and onboarding approvals. That's part of why I need a decision and a named owner today.

**Why can't you just give one date?**
Because two of the four inputs — the VM exception and the governance sign-offs — aren't ours to set. I can commit firmly to the engineering timeline; I won't commit to dates that depend on decisions we're asking *you* to make.

**Say this / not that:**
- ✅ "Target range, pending final validation."
- ❌ A single hard date you can't back up. If they push, give the range and name the dependency.

---

## D. Value & "why Unity" — the part that sells (lean in here)

**If we're adopting SPHEREboard and CyberArk Flows, why keep building Unity? Isn't this throwaway custom code?**
The vendor tools are strong in their lanes and we use them there — vaulting, rotation, identity workflow automation. But they don't cover what's specific to Wells Fargo: our business rules, migrating the 30+ legacy CVIS apps, bulk operations, cross-system data gathering and loading, our API boundaries, routing between tools, auditability, and exception handling. **Unity owns exactly those gaps.** So this isn't throwaway — the modernization ships as a control plane the bank keeps, and it turns work we have to do anyway into reusable capability.

**What do we actually get for the time and cost?**
Three returns. **One,** we get back to green and to NGDC. **Two,** capability we don't have today — Policy Drift detection, a Maturity Model that scores accounts and recommends a more secure access path, and full auditability. **Three,** speed — modernized, reusable components mean the next time you need a pivot, we turn it around fast instead of rebuilding from scratch. That's the return on this spend.

**Why can't AI just modernize the legacy apps quickly?**
We tried that. The legacy apps are tangled enough that AI flags them as too messy to safely break down. Modernizing them is human architecture work — understanding each batch process, redesigning coordination, testing it. That's why it's a real project, not a quick pass.

**Active-passive to active-active — isn't that a config change?**
No. CVIS runs scheduled batch jobs, designed active-passive on purpose so each action runs exactly once under one owner. Active-active means two live instances could fire the same action twice. Preventing that safely means re-engineering coordination — shared queues or messaging, a distributed data layer, new monitoring, and retesting across the portfolio. It's a redesign, not a setting.

**Was the original architecture a mistake, then?**
No — it was correct for the original requirements. Active-passive is a standard, valid pattern for a back-end batch/utility system; it prevents duplicate processing and conflicts. What changed is the requirement, not the quality of the design.

**Value one-liners** *(drop into any answer):*
- "We use the vendor tools where they're strong — Unity owns what only Wells Fargo can own."
- "This is work we'd have to do anyway; Unity makes it reusable instead of throwaway."
- "The original architecture was right → the requirements changed → the change is real work → Unity turns that mandatory work into lasting capability."
- "Modernization is what lets us move faster next time — that's the point of it."

---

## E. The skeptical rapid-fire (Mike signaled Brad will ask these)

Answer each in one or two sentences — don't over-explain.

| Question | Short answer |
|---|---|
| What changed? | The PtB gate moved from migration-readiness to modernization compliance. |
| When? | 7/06 — visible in the PtB record (GGDH-1747), after our 6/26 approval. |
| Who changed it? | The gate change came from the executive-level modernization decision; we got it as a status change, not a heads-up. |
| Old expectation? | Lift-and-shift the VMs to NGDC; modernize later as future-state work. |
| New expectation? | Modernization compliance up front before the migration is approved. |
| VM path — faster? | No. Removes no requirements; only changes *when* we move. |
| Modernization date? | ~Feb 2027, pending validation. |
| Ours vs. others? | Engineering is ours; the exception and sign-offs are governance's. |
| What do you need from me? | Sequencing decision + VM exception call + named owner + re-baselined date. |

---

## Landmines to avoid

- **Don't oversell the VM path.** It is not a fast lane and it saves no scope. If you imply it's faster, they'll hold you to a date you can't hit.
- **Don't overcommit counts or dates.** "~30 active / ~42 total, pending validation." "~Feb 2027 target." Precision you can't defend becomes the story.
- **Don't lead with pipeline/EPLX/Checkmarx problems.** Keep them in the risk appendix; leading with them reads as unprepared. Tie them to legacy complexity if asked.
- **Don't relitigate the past or assign blame.** State what changed, when, and what you're doing about it.
- **Don't claim Unity capabilities are done.** Frame them "by design" — real value, honestly staged.

## Close on the ask (last thing they hear)

> "The original architecture was right for the original requirements. The requirements changed above us. That change is real redesign work — not a two-week fix. And the work we have to do anyway, Unity turns into capability the bank keeps. What I need today is the sequencing decision, the VM exception call with a named owner, and agreement on a realistic date."
