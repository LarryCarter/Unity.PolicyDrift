# Guides 17 — Administrator and Author Step-by-Step Configuration Manual

## A. First-time administrator: application, category and capability
1. In DEV open `Applications` with authorized admin group. Select existing app or `Create Draft`; enter stable key, display name, owner and description. Do not create duplicate existing app.
2. `Collections` > Add categories Onboarding, Hygiene, Governance, Reporting or another permitted name; preview tree before saving. Moving categories must not change workflow IDs or permissions.
3. `Capabilities` > Select existing owner service or Register Draft. Add owner/contacts, manifest/operation schema, service identity *reference*, host/transport and optional Apigee onboarding reference.
4. Confirm SDK local handler registration vs registry approval distinction. `Validate` checks duplicate operation keys, DTO schema, broker and auth references; `Request Review` begins approval workflow, not automatic activation.
5. In `Operations`, inspect each version and its side-effect classification. Use `Development` to set Experimental/NonProd/Approved and InDev/Testing/Verified/ReleaseReady with evidence. Add approved L2 recipe under this capability's Workflows tab.
6. Associate capability Register/Configure entitlement to authorized local Unity groups (Matthew's existing provider). Test effective access and audit. Do not assign external per-user API grants.

## B. Workflow author: create, configure and test a BPMN process
1. `Applications > PAM > Onboarding > New Workflow` selects L1; from `Capabilities > CyberArk > Workflows > New` selects L2. Enter owner, runbook and labels.
2. From designer `Start` choose trigger (BE form, CSV, API, AMIE/Kafka intake, approved scheduler adapter). Configure typed fields and validation.
3. Add ServiceTask from approved capability operation picker, pin operation version and map required inputs/outputs by schema. Use AMIE BusinessRuleTask and bind approved rule facts/version and outputs.
4. Add XOR/Parallel gateway, CallActivity, Timer or Error boundary and minimum UserTask as required. Verify scopes, default paths, error behavior, timezones and external-write reconciliation. Pools/lanes represent responsibilities only.
5. If future nodes needed, turn `Experimental Mode` ON (if authorized) to place/import and save; read warning. Never assume experimental mode enables execution.
6. `Save Draft` stores canonical `process.bpmn` XML+DI and Unity JSON bindings; `Validate` checks compiler, permissions, host availability, pinning, runtime support and experimental node list.
7. `Test DEV` uses fixture or explicitly approved live connection; inspect run monitor and AMIE decision trace; fix validation/operation errors; request review. Publish only under authorized environment and package lifecycle.

## C. AMIE rule and approval-policy author
1. `AMIE > [Application or Capability] > [Category]` selects existing Matthew editor, not a separate rules engine.
2. Add `Eligibility`, `ApprovalPolicy`, `Mapping` or other categorized rule with stable key, version, typed fact/output schema, owner, consumer and test fixtures.
3. For ApprovalPolicy define ordered stages, group primary/backup, required decision count and rejection path. Test policy against redacted sample and inspect typed approval plan.
4. Bind rule from BPMN inspector; verify pinned version and input mapping; deploy rule through approved environment configuration, inspect decisions in trace after run.
5. If missing group/rule permissions, admin links existing groups with effective access preview; do not fabricate enterprise AD membership.

## D. Business executor and approver
1. Select a workflow visible under own application permissions; `Read` can browse/report but cannot run; `Execute` and `Create` can run within scope.
2. Fill BE input or upload authorized CSV and press Start once; accepted runId is not completion. Monitor status and rule/capability results.
3. Execute-Lead may switch to Group Reports, limited to entitled group members only; others return forbidden.
4. Eligible approver opens My Approvals, reviews redacted request and prior stages, selects Approve/Reject with reason; BOB persists decision and advances after required approvals. Backup selection shown when policy allows.

## E. UAT import and PROD preparation
1. Export real BPMN 2.0 XML with DI and Unity manifest/binding package, record content digest and version.
2. In DEV run required negative/positive tests; authorized administrator requests review; promote identical approved package to UAT where permitted, resolve environmental config outside artifact and retest.
3. In Release Center upload `.unitypkg`, view validation: element support/experimental, dependency versions, group/permissions, signed digest, current authorization, approval evidence and required ServiceNow change ID.
4. A ServiceNow ID is required initially but **not externally checked**; entering the ID is not evidence that the ticket was approved.
5. Only authorized PROD operator may activate after verifying trusted signature or approved enterprise release mechanism, Channel Secure integration and other production gates. If absent, PROD activation remains disabled. A user with Create cannot self-promote to PROD merely by changing a form field.
6. Rollback is a new audited activation pointing to an earlier approved immutable version; running processes stay pinned unless an explicit migration policy exists.

## F. Troubleshooting quick reference
`Permission denied` -> view Effective Access to check group/rule/resource; `Missing operation version` -> inspect capability approved environment; `Experimental node` -> save allowed but runtime requires handler and policy; `Timeout` -> inspect external outcome reconciliation; `Rule facts mismatch` -> correct typed mapping; `Package failed signature` -> do not bypass verification; `Gateway join stuck` -> inspect branch token/history and graph validation; `No Channel Secure connection` -> DEV work possible, PROD go-live blocked.

## Documentation acceptance
Every guide step links to the corresponding Blazor screen/control and test ID, supports screenshots after actual UI exists, and distinguishes fixture/prototype from verified production system. No secret values in screenshots.
