# Architecture 01 — Platform Roles, Workflow Levels, and Navigable Catalog

## Platform authority and ownership
| Responsibility | Owning component | Constraint |
|---|---|---|
| Human website experience | BE Blazor/API | UI hiding alone never authorizes execution |
| Initial intake validation, enrichment, workflow selection | AMIE existing intake | Preserve initial contract; BOB checks selected workflow again |
| Business eligibility, routing, mapping, approval policies | AMIE | Rules return typed decisions, not durable orchestrated side effects |
| Token state, BPMN control flow, timers, waits, human tasks | BOB | One shared interpreter, SQL Server durable state |
| Integration operation code, owning data, API credentials | Capability service | Only registered, versioned operations; service account separate from end-user |
| Command/outcome transport | Kafka | Broker ACK not business success; outbox/inbox required |
| Definitions, versions, approvals, activation | Unity control plane | Component boundaries despite common SQL database |

**Current intake:** AMIE receives inbound requests, evaluates/enriches/classifies, emits typed workflow selection to BOB over the established channel; BOB validates entitlement, definition/version and environmental activation, executes and dispatches capability-specific commands. BOB may request additional AMIE evaluations. Capabilities may use approved local cached AMIE rules through adapters. **Do not rewrite working intake in this immediate pilot.** Separate Matthew review identifies future correction triggers.

## Workflow hierarchy
- **L1 Business/enterprise:** cross-department durable process (Account Onboarding, Hygiene, Governance, Policy Drift, CMDB enrichment). BOB central.
- **L2 Capability-local recipe:** bounded technical multi-step process owned by a capability (CyberArk Validate + Create + Verify). Shared interpreter embedded; no independent durable enterprise orchestrator. Long-running/cross-domain should move to L1.
- **L3 Atomic operation:** approved typed handler (GetAccount, AddAccount, StageBatch, SendEmail) with versioned input/output and side-effect classification; not a separate workflow level of orchestration.

**Owner is not the same as consumer.** A workflow has one primary owner and multiple associations. An Application workspace defaults to its L1 workflows organized by functions; a Capability workspace defaults to its approved operations and owned L2 workflows. A shared library appears only on explicit Browse Shared Library or search.

## Multi-dimensional taxonomy, not one giant directory
| Dimension | Examples | Stable semantics |
|---|---|---|
| Application | PAM, Identity, Data Management | Who is responsible for business domain |
| Functional collection | Onboarding, Hygiene, Governance, Reporting, Policy Drift | Navigation and lookup; editable without re-identifying workflow |
| Capability ownership | CyberArk, NAS, Email, AD | Technical operation and local recipe owner |
| Work type | L1, L2, L3 | Determines intended host and semantics |
| Tags | privileged, bulk, recurring, destructive, reconciliation | Search; not authorization grants |
| Permission groups | Local Unity group references, future enterprise group mappings | Actual authorization independently scoped |
| Maturity/version | Experimental / NonProd / Approved, stage; version | Version pinned; environment activation separate |

## Storage and identity principles
Use stable GUID/opaque IDs and unique functional keys; never bind references to mutable folder names. Immutable published versions, drafts with concurrency revision, version-pinned dependencies. `WorkflowAssociation` maps consumers; `WorkflowFolder` stores configurable parent/ordinal per application or capability; `CatalogTag` and `ResourceCategory` are shared searchable concepts. Cross-domain writes go through owning APIs even when entities share SQL Server.

## Scope and non-goals
A capability is not a per-person entitlement integration for every external department. Its service account is approved by the external department/gateway, and Unity checks user/workflow scope before dispatch. Registry existence is not approval; external service login does not grant workflow visibility. No hardcoded CyberArk, Policy Drift, or DCMS logic in BOB/AMIE core.

## Acceptance
A PAM author sees Onboarding/Hygiene/Governance and only permitted workflows; a CyberArk capability owner sees its own operations/L2 recipes; shared version-pinned recipe is reused by a second unrelated application without code change; moving a catalog folder does not change authorization or old running instances.
