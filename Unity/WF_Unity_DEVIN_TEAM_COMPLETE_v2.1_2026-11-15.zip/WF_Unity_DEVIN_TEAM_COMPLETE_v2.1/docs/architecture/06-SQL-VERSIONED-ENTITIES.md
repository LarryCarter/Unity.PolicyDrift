# Architecture 06 — SQL Server `uty_` Schemas, EF Core, Versioning and Change Management

## SQL organizational decision
**Single approved Unity SQL Server database per environment with independently owned schemas and DbContexts.** These are logical target names; adjust only by explicit ADR if live migrations demand non-destructive compatibility. Do not split into new independent DBs without agreement. No cross-service ownership bypass by direct EF queries simply because the database is shared.

| Schema | Owned records | EF context concept |
|---|---|---|
| `uty_catalog` | Application, Category, Collection/Folder, Tag, ResourceAssociation, ResourceOwner | CatalogDbContext |
| `uty_security` | Local Group (existing implementation), Member, EntitlementGrant, GroupEnvironmentBinding, EffectiveAccessAudit | SecurityDbContext |
| `uty_capability` | CapabilityService, OperationDefinition/Version, Manifest/Version, CapabilityActivation, API identity reference | CapabilityDbContext |
| `uty_bob` | WorkflowDefinition/Version, DraftRevision, Token, Scope, GatewayArrival, Timer, Wait, HumanTask, Command | BobDbContext |
| `uty_amie` | RuleDefinition/Version, RuleSet/Version, PolicyBinding, RuleDecision, ApprovalPolicy | AmieDbContext |
| `uty_be` | SavedView, Favorite, UserPreference, NotificationPreference | BeDbContext |
| `uty_release` | ReleasePackage, PackageArtifact, ValidationEvidence, ChangeReference, EnvironmentActivation, PromotionHistory | ReleaseDbContext |
| `uty_audit` | Append-only ConfigChange, OperationEvent, RunEvent, Baseline, DriftFinding (future) | AuditDbContext |

**Caution:** existing classes, migration histories and table ownership have not been inspected; reconcile M0 before implementing migrations. The conceptual group provider may already exist in AMIE or BE. Do not create a second group table just to satisfy a proposed name.

## Core identities and relationships
`Application {ApplicationId,Key,Owner,...}`; `CapabilityService {CapabilityId,Key,...}`; `ResourceCategory {CategoryId,Key,...}`; `CatalogCollection {CollectionId,ParentId,OwnerScope,...}`; `WorkflowDefinition {WorkflowId,Key,Level,OwnerType,OwnerId,...}`; `WorkflowVersion {WorkflowVersionId,DefinitionId,SemanticVersion,PackageDigest,BpmnXml,DiXml/embeddedDI,...}`; `WorkflowAssociation {WorkflowId,ConsumerOwnerId,CategoryId,CollectionId,...}`; `OperationVersion {OperationVersionId,CapabilityId,Key,ContractVersion,ManifestDigest,...}`; `RuleVersion {RuleVersionId,RuleDefinitionId,SchemaVersion,...}`; `DefinitionDependency {SourceVersion,TargetVersion,BindingType,...}`; `EntitlementGrant {GroupId,ResourceId,Role,Environment,PolicyVersion,...}`; `EnvironmentActivation {ObjectVersionId,Environment,Status,...}`.

Use immutable published records; drafts have `rowversion`/ETag optimistic concurrency. Stable workflow IDs are not derived from folder path; moving to another category cannot break a run. Any mutation to a published definition creates a new version. Running instances pin process/rule/operation/subprocess versions and necessary classification/permission context per approved policy.

## Workflow maturity tracking
Store classification enum (`Experimental`, `NonProd`, `Approved`), stage enum (`InDev`, `Testing`, `Verified`, `ReleaseReady`) against a particular **version**; append status-transition history with actor, evidence and review. Activation independently records `Inactive`, `Active`, `Suspended`, `Retired` for each environment. No automatic inheritance of Approved from parent capability to its operations or workflows. A ReleaseReady Experimental version is still not PROD eligible.

## Import, seed and rollout
EF migrations establish schema and data shape; environment-specific **configuration imports** activate approved group references, categories, rules, capability bindings, and workflows. Initial standalone groups remain managed by existing application; all imports must be idempotent by stable IDs/version/hash and atomic. Migrations must not seed fictional AD membership. Approved Prod/NonProd group naming conventions are validated alongside explicit environment classification. Compare plan before apply, version/hash the input, require authorized import and audit changes.

## Policy drift future-proofing
Versioned materialized configuration snapshots/digests and append-only change events for groups, entitlements, AMIE rules, workflow versions, capability manifests and activation. Later drift detector compares runtime/configuration state to approved baseline and alerts via a registered capability; **not** required to build all drift monitoring in first two weeks.

## Transaction boundaries
Same-component state+outbox may commit in one SQL transaction; cross-service coordination remains asynchronous with idempotency/inbox, not a distributed transaction. Sensitive secrets are referenced not stored. EF contexts must not mutate another component's schema. Validate rollback and replay strategies for migration and package import.
