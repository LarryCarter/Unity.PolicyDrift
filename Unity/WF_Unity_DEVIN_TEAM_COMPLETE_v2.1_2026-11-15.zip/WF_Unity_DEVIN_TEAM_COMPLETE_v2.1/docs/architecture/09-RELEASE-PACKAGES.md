> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 09 — Immutable Configuration Release and Environment Promotion

## Split release types

- **Capability code release:** new .NET handler or upgraded adapter, deployment/approval through existing bank SDLC; registry activates only approved manifest version.
- **Configuration-only release:** new BOB BPMN XML, AMIE rules/mappings, operation bindings, forms/triggers and runbook references; compiled service binaries unchanged if all operations exist.

## Proposed Unity Execution Package structure

```
package.json                  # manifest, immutable package ID/version, digest, owner
workflows/*.bpmn              # BPMN 2.0 XML + DI + vetted Unity extensions
amie/*                       # references/versions and approved portable AMIE artifacts
bindings/*.json               # operation bindings, data contracts
forms/*.json                  # schema-driven form metadata, if required
controls/runbooks.json        # versioned operational references
contracts/lock.json           # capability operation, message, rule and schema versions
validation/evidence.json      # CI/test report references, not secrets
```

Package contains **logical binding keys**, never PROD passwords, endpoints or raw Kafka broker credentials.

## Lifecycle

`Draft -> InReview -> Approved -> Published -> Active -> Retired`. Published versions are immutable, named by package digest. For new changes clone into a new draft. Existing runs keep their exact version pins; in-flight migration is deferred. Retirement prevents new starts but leaves evidence and necessary old version artifacts available for active runs/audit.

## Promotion recipe

1. Author builds a draft in DEV, validates BPMN, operation/rule/schema bindings and allowed policies.
2. CI executes repeatable unit/BPMN/API/contract/role-deny/failure regression; captures signed or trusted evidence refs.
3. Workflow reviewer/authorized approver reviews exact digest, diff, ticket reference and tests.
4. Trusted pipeline creates an immutable package and verifies issuer/integrity.
5. UAT installs **the same bytes** by digest; environment-specific logical mappings are resolved from UAT-approved binding set and smoke tests run.
6. Release Operator requests PROD preflight; system validates manifest signatures, deployed compatible handlers, approvals, environment binding sets, bank control checks and separation of duties.
7. Only authorized Operations actor or approved automation activates the exact digest; audit records actor, UTC, environment, change reference, approvals and result.
8. Rollback activates prior approved package for **new runs**; it does not automatically reverse CyberArk writes already done.

## Release gates

A placeholder ticket, `approved:true` in a JSON fixture, or passing DEV tests is **not** authorization for PROD. If an actual bank CA/control remains unresolved, report it as a blocker; do not bypass. If the required dependency library isn't approved, cannot include it in release.

## Versions

- Workflow definition version: executable process semantics.
- AMIE ruleset version: fixed configuration and rule output contract.
- Capability operation contract version: stable IO shape and authorization rules.
- Capability binary version: deployed code implementing contract.
- Kafka message schema version: serialization compatibility.
- App configuration package digest: immutable collection of exact dependencies.

New runs reference pinned dependency lock. The engine must fail gracefully if a required deployed contract is unavailable.
