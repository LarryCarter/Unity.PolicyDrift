# Architecture 07 — Day-One Enterprise Integration Readiness and Unknown-Contract Tracker

**Policy:** All items below are accounted for in initial milestones and Jira placeholders. Some may already exist; verify actual implementations, existing Jira issue keys and ownership before creating new code/tickets. Their unavailable details must not block independent DEV/BE/SDK/BPMN work. A required production dependency cannot be waived merely because its contract is unknown.

| Placeholder | Integration | Initial discovery/tests | Go-live evidence needed | State |
|---|---|---|---|---|
| INT-CHSEC | Channel Secure | SAML SSO, entitlements, existing Matthew auth seam, session/logout claims | Verified login, group mapping, authorization tests | Existing/Partial/TBD after audit |
| INT-APIGEE | Apigee | API products, onboard service identity, OAuth/mTLS scopes, gateway route/environment | Authorized call, deny test, credential rotation, audit | Existing/Partial/TBD after audit |
| INT-SPLUNK | Splunk | logging formatter, trace/correlation fields, redaction, log forwarding | Searchable audit and security telemetry without secrets | Existing/Partial/TBD after audit |
| INT-AUTOSYS | AutoSys | approved scheduler trigger adapter, identity, signed/authorized message, run correlation | Schedule event -> workflow outcome and duplicate prevention | Existing/Partial/TBD after audit |
| INT-NAS | NAS | owner API/EF schema/DTO, staged batch access, authorization; no cross-domain table bypass | Real or approved DEV/UAT API test, data provenance and error handling | Existing/Partial/TBD after audit |
| INT-CRON | Cron/scheduled jobs | job ownership, overlap with BPMN timers, timezone/UTC, callback contracts | Enforced schedule, replay and audit | Existing/Partial/TBD after audit |
| INT-OTHER | Additional departments/systems | API onboarding profile and SDK/REST/Kafka contract | Approved target-specific proof | As discovered |

For each integration create or map a Jira story under M5 with: owner/technical contact (TBD permitted), external documentation needed, credential/scope class, dependencies, target DEV/UAT/PROD, existing source paths if any, negative auth test, pass/fail evidence and blocker. Distinguish `Existing—Verify`, `Partial`, `Awaiting Requirements`, `Ready`, `Verified`. No duplicate ticket just because a placeholder was listed.

## Cross-enterprise boundary
Department controls its own API and grants access to Unity service identity. Unity authorizes users/groups to workflows, dispatches approved pinned operation calls and audits. Apigee may mediate API access; no need to assign every external service a separate permission for every human user.

## Trigger sources and scheduling
Manual BE form/CSV, approved API request, Kafka intake, AutoSys, cron and future timer starts are different trigger adapters. Existing AutoSys or cron can start an approved BOB workflow via typed trigger with identity, idempotency and correlation; BPMN intermediate timers operate **inside an active instance**. Do not equate cron scheduler with BPMN timer catch semantics.

## Readiness conditions
No hardcoded external endpoints, identity secrets, nonexistent APIs, fabricated ServiceNow integration or fictitious production evidence. Handoff must separate DEV mock/conformance tests, approved UAT integration evidence and PROD blocker list. Implement interfaces now; activate real targets when security contracts and test access are supplied.
