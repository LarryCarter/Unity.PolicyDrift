# Architecture 05 — Standalone Groups, Channel Secure Migration and Two Authorization Boundaries

## Implementation rule
**Now:** reuse Matthew's functioning standalone login, user groups and AMIE access rule configuration. Do not create a competing auth server or IAM store. **Before PROD go-live:** integrate Channel Secure for enterprise SAML SSO and entitlements/group resolution; requirements and existing project details may arrive during development. Build a provider adapter boundary, preserve group/resource policy identifiers and make the integration a go-live milestone rather than a distant optional feature. Verify authentication session, claims/entitlements, logout, expiry, group sync/cache and audit when contracts become available.

## Human website group roles
| Permission | Authorizes | Scope |
|---|---|---|
| Read | View definition (if assigned), permitted run results and reports | Resource/group-specific |
| Execute | Read + start a specific approved workflow; view own results | Resource-specific |
| Execute-Lead | Execute + group/team member run/report visibility | Only the expressly authorized group's members and runs |
| Create | Create/change workflow drafts + execute/read within scope | Never implies production activation or approval |
| Capability Register | Submit/review capability registration and metadata | Admin function, independent of workflow Execute |
| Capability Configure | Edit approved capability settings, operations, environment bindings | Admin function, independent of workflow Execute |
| Approve Task / Release Operator | Decide assigned human task / import or activate approved release | Distinct admin entitlements |

A workflow can have **multiple local groups or equivalent AMIE conditions** assigned. Effective policy defines any/all, scope and conflict behavior explicitly; do not assume that categories or folder paths imply permissions. Server enforcement at BE APIs, BOB start admission and capability dispatch must follow the same policy; UI visibility is not authoritative.

## Human-to-workflow versus service-to-API
External department grants technical API access to a Unity **service account** (often via Apigee). The department is not tasked with per-Unity-user group administration. Unity tracks end-user actor and delegated workflow permission; the capability uses the approved service account and keeps provider credentials behind vault references. Many deployed service accounts may have broad rights; enforce operation allowlists, workflow version bindings, command authentication, and audit to prevent a broad service credential becoming unlimited web access. Prefer least-privilege accounts where feasible; don't misrepresent provider-wide admin access as inherently safe.

## Environment isolation
DEV=non-prod, UAT=pre-prod, PROD=production. Group config may include imported enterprise group *references* and trusted name conventions (`Prod`, `NonProd`) as usability checks. Production must enforce explicit environment eligibility rather than solely substring matching. Config/import flow is versioned and audited. No real AD integration or fake memberships required before Channel Secure data arrives.

## Audit fields
ActorId/provider, group snapshot or entitlement proof reference, resourceId/version, action, policy/rule version, allow/deny and reason code, correlation ID, environment, time UTC; redact sensitive data. Group changes and published versions become future policy-drift baselines.

## Tests
User with Read cannot Execute; Execute cannot edit; Execute-Lead sees only entitled group reports; Create cannot approve its own release unless separately permitted and policy allows; browser-only hidden button bypass attempts fail via API; service account cannot bypass approved operation and workflow admission; PROD rejects non-prod group associations; identity-provider swap preserves resource grants, subject to verified enterprise mapping.
