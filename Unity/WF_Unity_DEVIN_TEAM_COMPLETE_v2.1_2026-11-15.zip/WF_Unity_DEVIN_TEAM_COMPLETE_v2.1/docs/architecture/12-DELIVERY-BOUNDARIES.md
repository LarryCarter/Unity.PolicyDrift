> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 12 — Delivery Boundaries and Deliberate Deferrals

## November demo P0

- Existing AMIE adapter, typed rule metadata and execution in embedded capability.
- One actual compiled capability handler, startup registration, approved manifest discovery, schema-rendered BE operation inspector.
- Validatable/executable BPMN 2.0 subset, central/embedded BOB same core, MSSQL state and event history, Kafka command/outcome.
- Blazor workflow library/designer usable enough to configure and save/validate/publish **supported** nodes, not fake unconnected buttons.
- Authorized start/upload/API, business progress dashboard, basic BPMN run monitor, operator pause/resume/cancel, useful audit and ServiceNow ticket metadata.
- DCMS vertical slice CSV->batch/row GUID->CyberArk read/map/in-memory write->persist row outcome->report/email.
- CI API, contract, negative auth, failure recovery tests, package/change evidence; one pilot demo.

## P1 target where feasible

- Second workflow (Hygiene or Onboarding) reusing same handlers and runtime unchanged.
- Retry/restart operator UI with full safety and reconciliation; schema-driven human task forms; basic timers and schedule trigger; richer runbook editor.
- Improved canvas polish, drag connections, templates and diagnostics after backend correctness.

## Later backlog

- All BPMN 2.0 constructs (parallel gateways and joins, compensations, signals, complex boundary events, collaboration/pools), advanced multi-instance, run migration, full ServiceNow and AutoSys integrations, full portable rule editor if existing AMIE UI lacking, additional DB providers (excluded for BOB), multi-region coordination, SQL Ledger if bank approves, visual diff and complex merge.

## Critical early decisions

1. Exact existing AMIE evaluation/serialization/version interfaces.
2. Real deployed CyberArk operations and authentication/approval boundaries.
3. Existing Kafka schema/consumer libraries + approved topic provisioning.
4. Existing approved BPMN designer components vs first-party Blazor SVG.
5. Exact business data owner and API for DCMS staging/rows.
6. Release authorizer/control owner, environments, evidence retention.

## Stop/go

No code release without real bank controls; no demo assertion of live integration if using mocks. If time forces cutbacks, remove P1 features before reducing safety-critical correctness, audit or authorization. Avoid a beautiful designer that cannot execute valid definitions.
