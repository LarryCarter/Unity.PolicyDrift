# Architecture 03 — BOB BPMN 2.0.2 Compiler, Token Runtime and Expanded Phase 1

## Separate conformance dimensions
1. **XML import/export:** BPMN 2.0.2 compliant source with BPMN DI; preserve IDs, lanes, edges and geometry.
2. **Visual modeling:** palette and property editor for standard BPMN elements, with future features behind Experimental Mode.
3. **Compilation:** typed executable intermediate representation; fail unsafe/unsupported constructs before publish.
4. **Runtime semantics:** only explicitly verified element+host+environment combinations execute. Never claim full BPMN 2.0 execution conformance.

## Planned Phase 1 executable subset
| Construct | Required behavior | Essential tests |
|---|---|---|
| Start/end, sequence flow | Deterministic entry/end and graph progression; correct scope lifecycle | Start once, reachable endings, invalid graph |
| Service task | Approved operation/version input/output binding; async outcome | No arbitrary handler; timeout unknown outcome |
| Business-rule task | Pin AMIE rule version and typed fact schema | Misbound facts blocked, decision output audited |
| Exclusive gateway | First valid selected outgoing flow, default flow, no ambiguous result | Branch decisions and missing default |
| Call activity, embedded subprocess | Hierarchical scopes; pinned process identity, input/output maps | Subprocess failure and outer catch |
| Sequential multi-instance | Ordered repeated execution, checkpoint collection state | Three-row ordered, restart without duplication |
| Durable Kafka outcome wait | Persist subscription, correlate, resume once, handle duplicates | Lost/late/duplicate results |
| **Parallel split/join** | Concurrent tokens, tracked activation and atomic join arrivals | Varied completion order, duplicate event, deadlock negative tests |
| **Intermediate timer catch** | Durable one-shot date/duration UTC timer | Pod crash, timer lease, datetime parsing |
| **Interrupting timer boundary** | Attached subscription races normal completion, cancels scope flow | Exactly one winner, late external write reconciliation |
| **Interrupting error boundary** | Catch matching typed BPMN error in correct activity/scope | Matching/unmatched, nested propagate |
| **Minimal durable human task** | Stage assignment, eligible group, approve/reject, resume pending state | Multiple approvers, backups, access, persistence |

BPMN support table belongs to a versioned `BpmnElementCapability` with fields standardElementType, model/import/export support, compiler support, runtime handler maturity, supported hosts, environment policy, feature flag, version, Jira/milestone and tests. **Experimental visibility alone never authorizes execution.** Noninterrupting boundary, inclusive/event-based gateways, parallel multi-instance, event subprocess, compensation, transaction, complex gateway, advanced collaboration, choreography and conversation constructs are design/importable but not executable until authorized handler tests pass.

## Core runtime entities and atomicity
`WorkflowInstance` pins definition revision + package digest. `ExecutionScope` holds parent, lifecycle, variables and attached subscriptions. `ExecutionToken` identifies active path and fork group. `GatewayArrival` records expected/received branch arrivals per activation. `EventSubscription` records correlated wait. `DurableTimer` has dueUtc, lease/revision and fired/cancelled states. `HumanTask` records eligible group/stage/decision state. `PendingCommand`, `Outbox`, `Inbox` and `AuditHistory` protect interservice execution.

Parallel split creates independent tokens and join must atomically consume each required arrival once; never equate transport delivery with work completion. Validate structured fork/join cases first and reject unsupported topologies, including joins that can strand waiting tokens after an error branch.

## Timers and boundary races
A timer cannot rely on in-memory Task.Delay. Store due UTC, event type, scope, claim lease, and durable firing state. Activity start registers attached timers and error subscriptions atomically with the activity token. Normal completion versus boundary event competes for a revision-guarded state transition; the losing event cannot advance another path. External API work may still finish after BPMN interruption—record that outcome and require reconciliation where necessary.

## Errors and retries
Differentiate BPMN business error (`SAFE_NOT_FOUND`), transient retryable technical error, permanent technical error, missing-outcome deadline and engine infrastructure error. Capability manifests declare explicit safe error mappings; generic 503 or SQL exception is not automatically a BPMN error. Unknown external write outcome must not be blindly retried. Raise matching BPMN boundary handlers, else propagate by scope or mark execution for action according to policy. Uncaught errors are operator-visible.

## Pause/resume/cancel/restart
Pause takes effect at safe checkpoints (no guaranteed undo of already dispatched external call). Cancel prevents new work and closes subscriptions, with explicit late-write reconciliation. Restart creates a **new** run ID linked to prior run and pinned approved versions (or an explicit new version choice); maintain audit. Never change executing instance semantics when a new version publishes.

## Shared core and host adapters
BOB core owns interpreter and compiled IR. Central host implements SQL Server durable persistence and Kafka dispatcher. Embedded host uses approved DI dispatcher/local AMIE and host-specific persistence; fail compile/activation for durable waits on memory-only host. Interpreters cannot diverge semantically.

## Operational validation
Enforce graph, schema, operation visibility, entitlement admission, immutable dependency pinning and experimental environment eligibility at backend compile time and again at execution entry. Record machine-readable validation issues with node ID, reason and remediation. No execution from simply importing BPMN XML or viewing it on the designer.
