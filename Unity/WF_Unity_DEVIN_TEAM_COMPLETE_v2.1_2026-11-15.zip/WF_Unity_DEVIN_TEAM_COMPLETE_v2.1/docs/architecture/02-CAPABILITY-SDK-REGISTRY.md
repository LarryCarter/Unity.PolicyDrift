# Architecture 02 — Capability SDK, Registry, Service Accounts, and Enterprise Reuse

## Capability discovery versus administrative approval
`Handler implemented -> trusted local DI discovery -> manifest prepared -> service deployed and registered -> registry review -> capability/operation approval -> environment activation -> visible in authorized BE designer -> pinned executable binding`.
Local SDK discovery registers only compiled, allowlisted handlers in that service; **not** a runtime-scanned arbitrary CLR name nor an automatic enterprise approval. In other languages, generated or manually authored contract manifests and secure REST/Kafka adapters provide equivalent registration through the same published API. SDKs are conveniences, not separate authority or separate orchestration.

## Required manifest fields
| Group | Required metadata |
|---|---|
| Service | capabilityId/key, owning department, technical contact, deployment identity, code version, health API, supported environments |
| Operation identity | operationKey@contractVersion, exact handler/endpoint, input/output JSON Schemas, sideEffectClass |
| Policy | Unity operation admission policy, approved L1/L2 hosts, required AMIE facts/rule bindings, resource scopes |
| Reliability | deadline, timeout, retries, idempotency support, uncertain-outcome reconciliation and cancellation behavior |
| Kafka | logical command/outcome types, correlation/idempotency keys, partitioning expectations, schema versions |
| Security | service identity reference, Apigee onboarding reference (when required), credential vault references only, data classification |
| Lifecycle | version maturity/stage, owner reviewer, approval evidence, environment activation, deprecation, audit |

## Human entitlement and service principal separation
- BE human access: Unity group/AMIE rules authorize workflow Read / Execute / Execute-Lead / Create; capability administration Register / Configure is governed separately.
- Central BOB admits an authorized workflow and enforces **published operation allowlist/pinned versions**; each capability checks authenticated dispatch and approved operation permission. Human user context may be recorded and propagated as redacted audit metadata, without the external department managing that user.
- External provider/Apigee authorizes Unity's **service identity**. Broad provider-side access is not carte blanche to use unapproved operations; prefer least privilege when achievable, but existing broad service account does not require thousands of per-user provider entitlements.
- Service account, resource owner, gateway audience and scopes are configuration references and never serialized as credentials in BPMN or logs.

## Two execution profiles
**Central:** BOB SQL-backed runtime persists command intent and outbox; Kafka transports to capability's inbox; local SDK dispatch runs typed handler; outcome resumes BOB. **Embedded:** same interpreter executes bounded capability-local subworkflow using DI and local AMIE adapter, with host capabilities validated. Persistent waits/timers need a durable host; reject unsupported embedded memory-only plans.

## Maturity workflow (version-specific, separate from activation)
Classifications: Experimental, NonProd, Approved. Stages: InDev, Testing, Verified, ReleaseReady. Standard example progression: Experimental-InDev -> Experimental-Testing -> Experimental-Verified -> NonProd-Testing -> NonProd-Verified -> NonProd-ReleaseReady -> Approved-Verified -> Approved-ReleaseReady. Other combinations are representable where policy and evidence justify; transition audits are separate from environment activation. A parent Approved capability may have an Experimental operation.

## MCP
Expose approved operation catalog/actions through an MCP adapter only if platform admission, version checks, audit and rate limits are enforced exactly as for BE and Kafka. No bypass and no parallel orchestration ownership.

## New-service developer flow
Implement typed DTO and handler -> compile and unit test -> register with SDK -> generate/validate manifest -> deploy to DEV using approved identity -> review and approve operation in Unity capability administration -> bind operation from BPMN designer by name/schema -> test local and Kafka paths -> promote independently versioned manifests through approved environment release.

## Verification
Contract tests for duplicate keys, incompatible schemas, unauthorized operation calls, foreign owners, missing source/target versions, revoked operations, unknown external write outcomes, parallel invocation, no-service-reachable, and cross-language manifest compatibility. Show same operation reused without code changes in two applications; no fake success from metadata-only registration.
