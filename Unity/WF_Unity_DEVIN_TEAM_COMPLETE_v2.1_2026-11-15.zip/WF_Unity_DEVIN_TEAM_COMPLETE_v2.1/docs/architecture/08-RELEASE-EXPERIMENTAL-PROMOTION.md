# Architecture 08 — Experimental Mode, Classification Workflow and DEV/UAT/PROD Promotion

## Independent controls
A resource has (1) per-version maturity classification Experimental/NonProd/Approved, (2) development stage InDev/Testing/Verified/ReleaseReady, (3) execution support capability/host, (4) per-environment activation, and (5) permission/policy authorization. **None alone grants execution.** Same model applies to capabilities, individual operations, workflows, AMIE rule versions and BPMN element handlers.

## Standard illustrative progression
`Experimental-InDev -> Experimental-Testing -> Experimental-Verified -> NonProd-Testing -> NonProd-Verified -> NonProd-ReleaseReady -> Approved-Verified -> Approved-ReleaseReady`. The model stores two fields independently, with required transition review/evidence. Normal maturation may skip states under documented policy; status changes do not activate resources automatically.

## Experimental BPMN mode
- Admin setting enables full BPMN 2.0 palette for approved authors; default designer hides unsupported execution elements but imported XML/DI can still preserve known standard nodes.
- Experimental element is clearly tagged, with tooltip/status, Jira link, missing handler/validation warnings. Parent workflow inherits a warning showing affected nodes.
- Draft save, versioned edit, import/export are allowed even when execution is not. Backend compiler rejects missing handlers, unsupported host or unapproved combination; no silent no-op conversion.
- DEV may execute implemented experimental handlers behind admin flag and explicit authorized test policy; UAT testing requires deliberate NonProd or approved experimental test policy; PROD rejects any not Approved/ReleaseReady and allowed by current runtime.
- A simulator/mock preview is not a proof of executable behavior.

## Release packaging
Canonical `process.bpmn` includes OMG BPMN XML+DI. Unity binding contracts, AMIE rule references and operation descriptors are separately versioned JSON. An example `.unitypkg` is a ZIP container with `manifest.json`, `process.bpmn`, `bindings.json`, typed rule refs, evidence manifest and signature metadata. Never describe a previous mock's binding-plan JSON as executable BPMN. Stable package manifest lists IDs, versions, approval classification/stage, dependencies, content hashes, environment compatibility and approved signer identity. Keep environment secrets external: use resolvable binding references, no secret values.

## Production trust rule
Production uploads are allowed only through an authorized import/activation workflow. PROD requires a **nonempty ServiceNow change ID** (ticket status not verified through API in Phase 1), resource entitlement, validation, immutable approved artifact and cryptographic trust or equivalent approved enterprise release control. **Do not embed reusable secret/private key in the XML.** Package signature must be checked against a production-trusted key independent of package content. Import and activation are distinct; an uploaded artifact does not go live automatically.

### Practical delivery sequencing
1. DEV: make real XML+DI import/export and package validation work; simulate signer if production trust infrastructure not available and label as non-prod.
2. DEV/UAT: test package checks, hash/modified-file rejection, missing dependency and missing ServiceNow ID; test UAT import and approval.
3. PROD: enable upload/activate only after independent trusted signature/approved enterprise release path, Channel Secure authentication/entitlements and required integrations are verified. If those prerequisites are absent, PROD upload remains disabled; DEV work proceeds.
4. Future: ServiceNow API capability validates ticket status, approvals and lifecycle; not present now.

## Version promotion and rollback
Promote **same approved artifact digest** DEV -> UAT -> PROD where feasible; use separately approved environment bindings without mutating signed functional content. Pinned running instances remain on prior version. Retiring or revoking an operation blocks new starts under defined policy while leaving audit/history readable. Rollback is a new audited activation of a prior approved version, not a silent overwrite of active definitions.

## Release approval as AMIE+BOB workflow
AMIE policy checks required reviewers, stages, backups and environment rules; BOB durable human tasks coordinate decisions and wait; BE shows queue, status and evidence; release service validates ticket reference, artifact, permissions and activation. Do not confuse a change ID with approval evidence or allow creator entitlement to grant production activation automatically.

## Tests
Invalid signature (different trusted root), changed BPMN byte, missing ticket ID, non-prod group in PROD, experimental workflow in PROD, missing approved capability version, unapproved rule, wrong host, duplicate import, UAT and PROD activation permission denial, old-version run continuity, separation-of-duties review.
