> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 06 — MSSQL Persistence, Audit Reconstruction and Status Projection

## Persistence responsibilities

- `bob.WorkflowDefinition`, `WorkflowVersion`, `ActivityBinding`, `WorkflowRun`, `RunToken`, `ActivityRun`, `PendingCommand`, `ControlRequest`, `PackageActivation`.
- `integration.OutboxMessage`, `InboxReceipt`, optional worker lease/claim tables.
- `audit.AuditEvent` **append-only**; restricted actor and evidence metadata, never full privileged payloads.
- `controls.RunbookVersion`, `ControlDefinition`, `ControlEvidence` if adopted by bank control owners.
- `projection.RunSummary` or equivalent materialized/read model for low-latency BE dashboards.
- DCMS `Batch/BatchRow` stay with DCMS/workload data owner, not generic BOB. Permission checks apply to joining read models across domains.

**MSSQL-only refers to BOB provider; other capability-owned stores remain independent.** Prefer transactional consistency for a run transition and outbox row in the same MSSQL database transaction when both are under same owner; cross-service actions require correlated follow-up outcomes.

## Minimum AuditEvent shape

`eventId`, `occurredUtc`, `recordedUtc`, `eventType`, `actorId`, `actorKind`, `scope`, `applicationKey`, `workflowKey/version`, `runId`, `activityId`, `packageDigest`, `amieRuleKey/version`, `capabilityKey/operationKey/version`, `batchId`, `recordGuid`, `messageId`, `correlationId`, `causationId`, `traceId`, `reasonCode`, `oldState`, `newState`, `serviceNowChangeId`, `controlId`, `evidenceRef`, `safeDetailsHash`, `classification`, `eventSchemaVersion`.

**No secrets or full CyberArk account records in audit.** Use data owner reference/hash + approved redacted summary, limited retention and authorized export. Immutable event stream alone cannot reconstruct unavailable code or rule definitions: retain signed published package and dependency list.

## Truth model

The event log is the durable historical timeline. State tables permit fast execution/recovery. Projections transform source events into counts and timelines; on disconnect/reconnect the BE UI calls the authoritative API before resuming push updates. The projected UI must distinguish `Completed`, `Failed`, `Skipped`, `NoChange`, `InProgress`, `Pending`, and `UnknownExternalOutcome` for DCMS; the workload owner defines business classifications.

## Concurrency and reconstruction

Use expected run revision/rowversion, unique message/command IDs, optimistic concurrency plus lease where necessary. Append an event and advance a state transition atomically whenever possible. Test interleaving commands, restart, projection rebuild, missing event, late Kafka event and duplicate delivery. Protect audit writers via append-only privileges; user/admin deletion forbidden except strictly controlled retention jobs with recorded evidence and bank policy.

## Control evidence

Store ServiceNow ticket ID, requester, reviewer, author, publisher, deployment actor, environment, artifact digest, approval decision, UTC and runbook version. **A populated ticket ID is not proof of approval**. Evidence must derive from authoritative bank records or authorized reviewers in a trusted approval process.

## Optional integrity

SQL Server Ledger and off-database hash/checkpoint mechanisms are **research options only**, requiring installed SQL Server version, security and bank approval. Do not introduce as a November dependency.
