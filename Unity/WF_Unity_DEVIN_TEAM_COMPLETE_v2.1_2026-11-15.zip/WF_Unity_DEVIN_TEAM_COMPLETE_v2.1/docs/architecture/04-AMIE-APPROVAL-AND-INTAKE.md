# Architecture 04 — Existing AMIE Intake, Rule Catalog and Durable Approval Workflow

## Retain initial deployed boundaries
Keep Matthew's working AMIE intake/rules/user and group implementation unless the repository audit proves a safety or delivery blocker. AMIE currently may validate/enrich/classify inbound messages, select workflow identifiers using rules and send a typed message to BOB's intake topic. This is not competing orchestration until AMIE also owns durable sequences, timers, human-task waits or multi-capability execution. Mark any such detected overlap for **post-pilot immediate remediation**, in `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md`, not a forced two-week rewrite.

## Two AMIE invocation paths
`Inbound request -> AMIE intake classify/enrich/choose workflow -> Kafka typed BOB start request -> BOB authorization and version validation -> run`. `BOB activity or approved embedded capability step -> pinned AMIE evaluation -> typed decision / mapped facts -> BOB follows BPMN flow or local handler uses returned facts`. AMIE never directly owns the BOB active-token state.

## Configurable rule catalog
Every RuleDefinition and RuleSet should have an immutable version, application/capability owner, category, typed facts, outputs, effective group restrictions, consumer associations, testing fixtures, audit history, compatibility policy and environment activation. Suggested categories: IntakeRouting, Eligibility, Validation, Mapping, Classification, Governance, ApprovalPolicy, EntitlementPolicy, Threshold, Reconciliation. A rule may be shared across several owners via explicit association, not copied blindly.

## Human approval: BOB workflow + AMIE policy
**AMIE:** determines whether approval is required, eligible group(s), ordered stages, required count (any-one or all), primary/backup approver reference, rejection/expiry rules. **BOB:** persists tasks and decisions, awaits completion, handles pause/resume/timeouts/parallel-stage semantics. **BE:** presents authorized inbox, task detail, approval/rejection and history. **Security:** enforces that actual decision actor is eligible at time of action. Use immutable approval-plan rule version for the running task; do not silently swap current rule mid-approval.

A minimum Phase 1 contract supports multi-stage approval (sequential stages), multiple approvers in a stage, any-one versus all-required, backup group assignment, explicit reject path, and durable waiting. More sophisticated delegation, quorum, calendar, escalation and form-builder behavior can follow later.

## Sample approval plan (illustrative, not deployed schema)
```json
{
  "policyKey": "PAM.PrivilegedAccount.CreateApproval",
  "ruleVersion": "2.0.0",
  "requestRef": "req-001",
  "required": true,
  "stages": [
    {"order": 1, "eligibleGroups": ["PAM.AppOwners"], "backupGroups": ["PAM.AppBackup"], "mode": "AnyOne"},
    {"order": 2, "eligibleGroups": ["PAM.Security"], "mode": "AllRequired", "requiredApprovals": 2}
  ],
  "rejectOutcome": "Rejected"
}
```
Schema shape is proposed; match existing AMIE syntax/API at M0. The typed approval plan is *data*, not an AMIE-run process.

## AMIE-to-BOB start contract
Include schemaVersion, requestId, correlationId, idempotencyKey, classification, selectedWorkflowKey, selectedWorkflowVersion (or approved active alias resolved by BOB), ruleSetId/version/digest, reasonCodes, enrichedDataSchemaVersion, data reference/value subject to classification, request initiator context and environment. BOB authenticates publisher, checks resource authorization, activation and known dependencies, then starts only once. Unknown workflow keys should be rejected, not dynamically evaluated as executable code.

## Rule-to-BPMN links
BPMN BusinessRuleTask inspector must support choosing approved rule by application/capability context, pinning version, binding named facts from upstream task outputs or process variables, previewing return schema, testing with redacted fixture, browsing consumers and audit/version history. Compiler validates rule/host availability and type compatibility. AMIE mapping may construct typed change-set but no uncontrolled arbitrary C# or SQL.

## Human approval and release approval are distinct
Business-process approval human tasks (e.g. request manager and security) are not automatically sufficient to approve a production workflow release. Production change approval and ServiceNow reference are separate governance actions, although AMIE approval rules and BOB human-task mechanisms may be reused with different policies/permissions.

## User-interface design guidance for Matthew
See `docs/ux/12-AMIE-APPROVAL-WIREFRAMES.md`. Proposed pages are selectable candidates for Matthew to keep/modify/reject, not a directive to replace his existing editor. Keep a common Blazor shell, application selector, category tree, version/status labels, rule inspect/test, consumer links and AMIE->BOB decision trace. Record feedback and current route/component names in review file (excluded from Ask).
