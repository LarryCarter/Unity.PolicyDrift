> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Workflow 05 - Account Hygiene / Privileged Safe Move (Separate from Policy Drift)

This is a separate PAM compliance business workflow. Example: an account is found with privilege/safe placement inconsistent with approved rules; AMIE decides whether remediation is appropriate; a registered CyberArk operation may move it after controls/approval. It must not be conflated with ZIP/INI policy baseline drift or DCMS custom-attribute enrichment.

```mermaid
flowchart TD
  A[Manual / approved schedule / API] --> B[Query eligible accounts via approved Data/CyberArk capability]
  B --> C[GetAccount and current safe]
  C --> D[AMIE: placement rule / policy]
  D --> E{Violation?}
  E -->|No| F[Mark compliant]
  E -->|Yes| G[Propose target safe + reason]
  G --> H[Control / approval check]
  H -->|Denied| I[Finding only]
  H -->|Authorized| J[CyberArk.MoveAccount]
  J --> K[Read/verify target safe]
  K --> L[Row outcome + audit]
  F --> L
  I --> L
  L --> M[Report / optional Email / Business Dashboard]
```

BE config: select trigger, pick registered data enumeration/`GetAccount`, bind AMIE rule with permitted target safe list, add conditional gateway, attach required approval and safe-move operation, configure denial/outcome branch. On save validate safe permissions, account scope, target vault/safe, idempotency and reconciliation; publish approved DEV. User sees compliant, violations found, remediated, requires approval, failed/unknown. Audit captures who authorized the move and before/after safe references (classified). Demonstrates operation reuse from DCMS but a distinct configured app.

Initial demo can be read-only finding generation (no actual move), and should mark remediation capability as deferred if the underlying operation/security approval is not available.
