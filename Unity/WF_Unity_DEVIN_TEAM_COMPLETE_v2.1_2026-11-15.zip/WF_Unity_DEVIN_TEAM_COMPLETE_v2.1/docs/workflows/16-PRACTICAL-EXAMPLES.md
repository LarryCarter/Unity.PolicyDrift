# Workflows 16 — Practical Scenarios for Every Phase 1 and Deferred BPMN Construct

Each scenario is *illustrative*, not verified implementation. Select approved DEV/UAT fixtures; do not use production CyberArk destructive operations without explicit authorization.

| BPMN element | WF Unity example | Rule/capability/boundary |
|---|---|---|
| Start Event | BE user requests privileged account | AMIE intake selects workflow; BOB starts approved run |
| End Event | Provisioning completed/rejected | BOB publishes final outcome and BE projection |
| Service Task | Create Safe or GetAccount | Approved CyberArk capability operation@version |
| Business Rule Task | Is service account eligible? | AMIE eligibility@version returns typed decision |
| Exclusive Gateway | Does request require approval? | Route to approval or direct provisioning |
| Call Activity/Subprocess | Reuse `ProvisionPrivilegedAccount` recipe | Parent pins called process/version, maps outputs |
| Sequential Multi-instance | Process 100 CSV rows in order | Embedded capability L2 recipe or central L1 as appropriate |
| Kafka Wait | Await CyberArk command outcome | Persist correlation and resume on logical outcome |
| Parallel Gateway Split | Start AD, CyberArk and reporting independent tasks | BOB creates multiple execution tokens |
| Parallel Gateway Join | Wait for all required branch completions | Atomic join; error paths cannot count as success |
| Intermediate Timer Catch | Approved operation waits for 10 PM change window | Persistent UTC deadline, survives pod restart |
| Interrupting Timer Boundary | CyberArk provisioning exceeds 5 minutes | Alternate timeout/reconcile path; not proof external write cancelled |
| Interrupting Error Boundary | Capability emits `SAFE_NOT_FOUND` business error | AMIE authorization check -> create safe if permitted -> retry controlled |
| Minimum UserTask | Manager then Security approval | AMIE stages; BOB durable waiting; BE eligible approvals |
| Lanes | Security, Application, Operations responsibilities | Visual membership, not separate Kafka execution host |

## Example end-to-end PAM request
1. BE checks user's local group Execute entitlement; receives redacted form/CSV.
2. AMIE intake validates and enriches; chooses `PAM.AccountOnboarding@2.1`, reasons and ruleVersion.
3. BOB checks definition active and caller entitlement; creates run/scope and durable intake state.
4. AMIE eligibility rule returns whether manager/security approvals needed; BOB creates human-task stages and waits for eligible decisions.
5. Parallel gateway dispatches independent AD validation and CyberArk prerequisites; BOB joins only after required branch results.
6. Create account via approved CyberArk service task; interrupting timer and error boundary perform safe timeout/error routing.
7. BOB publishes final workflow outcome, redacted audit and BE report; Report reader vs Execute-Lead group visibility enforced.
8. Reconciliation required for any timed-out external write with unknown outcome.

## Capability-local recipe
`GetAccount -> AMIE ValidateAttributes -> Map/Transform -> AddOrUpdate -> Verify`, compiled to same supported interpreter with embedded host and approved handler versions. Reuse in different application without separate microservice orchestration architecture. Long approval waits or cross-service joins belong centrally.

## Deferred BPMN with modeled UX
| Deferred construct | Future use | Design-time treatment |
|---|---|---|
| Noninterrupting boundary | Remind approver without cancelling approval | Experimental event with visible warning |
| Inclusive gateway | Only selected subset of services run and join | Import/diagram/inspector but no fake XOR execution |
| Event-based gateway | Approval response versus timeout race | Only execute after atomic subscription handler conformance |
| Parallel multi-instance | 500 accounts max 10 concurrent | Need concurrency/rate limits, aggregation, recovery |
| Compensation | Revert approved account changes on later business failure | Require side-effect compensator, no pretend rollback |
| Event subprocess | Emergency revoke during onboarding | Scoped event activation and interruption |
| Multi-pool collaboration | Department-to-department message choreography | BPMN DI preserved; true multi-participant execution deferred |

## Distinct pilot paths
CyberArk onboarding as first integrated demonstration; second neutral unrelated workload (NAS/Policy Drift/legacy modernization) proves platform generality. Keep Policy Drift baseline ZIP/INI/PolicyId hygiene distinct from account hygiene Safe-Move; no domain-specific rules inside BOB core. AutoSys and cron source triggers tested through authorized adapter when source details arrive.
