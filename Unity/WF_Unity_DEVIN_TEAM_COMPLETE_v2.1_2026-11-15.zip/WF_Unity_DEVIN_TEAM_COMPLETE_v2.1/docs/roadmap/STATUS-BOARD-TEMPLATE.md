> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Implementation Status Board — Update in Actual Repository

**Snapshot at handoff (2026-11-11):** design delivered, no actual Unity repository inspected by this handoff. No job may be marked Done until implementation artifacts/tests are verified.

| Job IDs | State | Owner | PR | Latest test run | Blocker |
|---|---|---|---|---|---|
| JOB-00 / 01 | Not started | Assign | — | — | Actual repo/AMIE interfaces |
| JOB-02 / 03 | Not started | Assign | — | — | Frozen operation contracts |
| JOB-04 / 05 / 06 | Not started | Assign | — | — | Frozen AMIE/BOB semantics |
| JOB-07 / 08 | Not started | Assign | — | — | Kafka/SQL conventions |
| JOB-09 / 10 | Not started | Assign | — | — | Approved Blazor components |
| JOB-11 / 12 / 13 | Not started | Assign | — | — | DCMS/CyberArk/Email owners |
| JOB-14 / 15 / 16 | Not started | Assign | — | — | IAM/bank controls |
| JOB-17 | Not started | Assign | — | — | CI/repo test harness |
| JOB-18 / 19 / 20 | Not started | Assign | — | — | Integrated dependencies |

**State vocabulary:** Backlog, Ready (dependencies verified), In Progress, In Review, Blocked, Done (evidence confirmed). A green mock screen without backend implementation does not mean Done. For each transition record actor, UTC, commit/PR and failing tests.
