> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 07 - DEVIN New Capability Service Construction Recipe

## A. Inputs DEVIN must obtain

- Existing Unity repository, root `AGENTS.md`, current solution, approved .NET target and CI templates.
- Service name, domain owner, purpose, source data owner, external API/contracts and approved dev/test tenant.
- List of primitives required; do not guess operations from a workflow screenshot.
- Existing AMIE interfaces and BOB embedded hosting types; current Kafka contract/envelope/ACL conventions.
- Required permissions, data classification, timeout, side effects, reconciliation policy and bank controls.

If any key input is absent, report a gap with evidence and propose the smallest safe stub for testing; do not silently invent a production implementation.

## B. Build steps

1. **Inspect first:** Find existing capability framework, handlers, SDK conventions, AMIE runtime. Record reuse vs changes in `JOB-00` audit.
2. **Agree contracts:** Define operation descriptor, DTO/schema, auth policy, messaging, AMIE facts and expected outcomes. Freeze with JSON fixtures and tests before concurrent PRs.
3. **Create service template:** approved .NET service project with health, DI, logging, controlled configuration. Do not add unapproved libraries.
4. **Write domain adapter:** smallest typed client with cancellation, timeouts, exception normalization and test fake. No generic arbitrary HTTP/SQL executor.
5. **Write handler:** implements SDK interface; input/output strongly typed, stable key/version and declared side effect; return structured outcome.
6. **Register:** use trusted assembly registration/compile-generated registry. Startup rejects duplicate keys and malformed metadata. Add test for missing handler registration.
7. **AMIE bridge:** declare needed facts and output schemas, resolve approved published rule via existing AMIE engine; support local evaluation in embedded host.
8. **BOB bridge:** expose handler to local dispatcher and (if needed) remote Kafka execution using same manifest. Confirm exact version pinning.
9. **Broker integration:** subscribe only to allowed logical inbound messages, verify schema/auth/inbox, publish outcome via outbox; derive partition key and correlation fields.
10. **Audit:** emit safe events for request, rule, handler execution and outcome. Audit should reassemble an operation by run/activity IDs.
11. **Public contract:** generate metadata + fixture + OpenAPI test endpoints; backend must be testable without UI.
12. **BE integration:** verify registry lists operation, inspector renders inputs automatically, binding picker type-checks and can insert into BPMN draft.
13. **Regression:** unit, API, schema, denied, duplicate, timeout/crash, redaction, version mismatch and second-workflow reuse.
14. **Submit PR:** source paths, build/test evidence, before/after, restrictions, approval gaps, file summary. No direct PROD deployment.

## C. Reusable PR checklist

- [ ] API contract and `operationKey@contractVersion` stable.
- [ ] Service/class names follow current repository conventions.
- [ ] Local registration tests green, no duplicate/undeclared handler.
- [ ] Manifest published only by approved deployment identity.
- [ ] `InputSchema`/`OutputSchema` and fixtures match compiled DTOs.
- [ ] Auth checked at API **and** worker invocation.
- [ ] AMIE rule metadata typed, rule version pinned; no duplicate AMIE parser.
- [ ] Kafka command/outcome contracts versioned, correlation/idempotency included.
- [ ] In-memory local workflow uses shared BOB core and DI.
- [ ] External write reconciliation specified; retries cannot cause duplicate mutations.
- [ ] Evidence append-only with no secrets/raw sensitive payload.
- [ ] BE inspector configures operation from descriptor, not hardcoded page.
- [ ] OpenAPI regression includes denied/invalid paths.
- [ ] At least two workflow fixtures reuse the same handler.
- [ ] Reviewer receives actual file summary and outstanding CA/approval gaps.

## D. What a handoff from BE should give DEVIN for a missing operation

The designer should export an **Operation Development Request** containing: capability owner, proposed operation key/version, business intent, preconditions, input/output JSON Schema, example fixtures, permissions/resource scope, side effects, mandatory AMIE facts, expected error/outcome codes, external client dependency, timeout, retry/reconcile policy, logical Kafka contracts, audit category, acceptance tests, requested environment and code-review/change ticket references. This is a specification, not automatically executable code.

## E. Correct file path format in PRs

`/Unity.Capability.CyberArk/Operations/GetAccountHandler.cs`
`/Unity.Capabilities.Contracts/OperationDescriptor.cs`
`/Unity.Capabilities.Hosting/Registration/CapabilityRegistrationExtensions.cs`
`/Unity.Capability.CyberArk.Tests/GetAccountHandlerTests.cs`

Follow real repository paths after discovery; above paths are illustrative.

## F. Files and Structure Summary (required in PR response)

New: list paths; Updated: list paths; Deleted: list paths; No Change: related untouched modules; Tests: commands+results; Known gaps: approval/control/library/repo uncertainties.
