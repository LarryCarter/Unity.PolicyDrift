> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# November 30 Demo Script and Release Readiness Gates

**Demo != production approval.** Live actions must be real and observed; mocks are permitted only when explicitly marked on screen and in evidence.

## 12-minute business narrative (suggested presentation order, not completion promise)

1. Sign in as workflow designer; show Capability Registry contains approved test operations (`CyberArk.GetAccount@1`, Data, Email). Open input/output contract metadata and owner/version.
2. Open DCMS draft in Workflow Library; BPMN 2.0 XML import/export, select service task, bind source row input, choose an existing AMIE mapping rule, validate and publish approved DEV version.
3. Switch to BusinessExecutor; start CSV upload (five-row fixture). Show unique batch number, row GUIDs and run ID.
4. Show central BOB Kafka command -> embedded CyberArk BOB runs AMIE locally; observe business counts changing and open technical BPMN run monitor.
5. Show one failure reason, one no-change, one confirmed success, and explicit uncertain status after an injected timeout; demonstrate no misleading 'passed'.
6. Show operator pause request -> checkpoint -> paused, resume with actor and reason audit; do not claim interrupt of in-flight write.
7. Show persisted report generated from outcomes, Email Capability Kafka notification and separate delivery result.
8. Open audit timeline by batch/run and ServiceNow change ID; show author, version, rule and handler references, message correlation.
9. Show a second Hygiene workflow using existing CyberArk read operation but different AMIE rule without recompiling BOB; if not ready, label as future target.
10. Show Release Center preflight, immutable package digest and simulated/actual controlled block when bank approval missing. Never click real PROD deployment in demo unless explicitly authorized.

## Technical gate

All P0 R01–R18 tests pass with evidence. Business batch/row counts match persisted data and report. Auth denials are real. BOB survives restart during wait. No unapproved library dependence. Version pins and audit reconstruct the run. Package release state truthfully shows approval status.

## Bank gate (separate)

Approved bank control owners, actual CA/ServiceNow workflows, PROD code/config reviews, service identities, secrets, network/Kafka ACLs and evidence retention are in place. Failing this gate blocks PROD, even if DEV demo passes.
