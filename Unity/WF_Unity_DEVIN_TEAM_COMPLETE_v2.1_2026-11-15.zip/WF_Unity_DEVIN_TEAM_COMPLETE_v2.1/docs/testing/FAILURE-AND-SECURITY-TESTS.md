> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Failure Injection, Security and Restart Tests

## Execution integrity

- Kill central BOB after outbox commit but before Kafka publish; restart: command eventually delivered, no missing run.
- Kill CyberArk capability after external write could have succeeded but before acknowledgment: row becomes `UnknownExternalOutcome`, reconciliation required, no blind auto-replay.
- Deliver duplicate command and duplicate outcome in arbitrary order; each run transition occurs once and external write does not duplicate.
- Pause immediately before row n; previously accepted write may finish but no next row begins after pause checkpoint. Resume version is pinned.
- Cancel while email pending; report accurately distinguishes business completion from notification status.
- Lose SignalR connection; UI reloads authoritative projection and does not show false complete.
- Corrupt/missing AMIE version in package; start rejected/suspended with evidence.
- Two workers claim same batch/row; lease and optimistic concurrency prevent two simultaneous external effects.

## Access and governance

- BusinessExecutor with app A token attempts app B batch read; deny and safe audit.
- WorkflowDesigner tries direct publish/activate REST; deny even if UI is hidden.
- Run operator supplies stale ETag or duplicates same commandId; idempotent reject/return original result.
- Kafka service uses allowed topic but forbidden operationKey; dispatch denies.
- Import BPMN XML with `scriptTask`, `external entity`, raw HTTP target or unapproved extension; reject safely.
- Tamper signed config package after UAT; PROD digest check fails.
- Supply ServiceNow-looking text with no validated approval; no PROD activation.
- Try to export privileged account material in audit; redaction holds.

## Required fault evidence

Pre/post MSSQL run state; in/out Kafka event IDs; audit sequence and UTC; worker restart logs; idempotency/reconciliation decision; explicit user-visible status; CI test result; absence of repeated CyberArk modification.
