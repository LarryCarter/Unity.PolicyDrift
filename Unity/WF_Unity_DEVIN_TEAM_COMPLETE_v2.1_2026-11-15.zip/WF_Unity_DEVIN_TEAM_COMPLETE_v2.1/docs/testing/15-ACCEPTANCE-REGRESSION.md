# Testing 15 — Regression, Failure Injection and Phase Gates

## Required evidence level
`Proposed -> code inspected -> unit test verified -> component/integration tested -> UAT proven -> PROD authorized`. A mock screenshot or SDK manifest registration is not evidence of real external execution. Every PR lists command/test results, actual paths, environment, real versus simulated backend, risk and remaining blockers.

## Core conformance matrix
| Test ID | Scenario | Expected result |
|---|---|---|
| BPM-01 | XML+DI import/export with pools/lanes and layout | Stable IDs, waypoints, lane membership and semantics retained |
| BPM-02 | Unsupported executable element with Experimental OFF | Draft preserves content; publication blocked with node ID |
| BPM-03 | Experimental ON in DEV | Author can add/configure/validate; execute only implemented approved test handler |
| BPM-04 | Experimental workflow to PROD | Block even if imported or flag toggled |
| BPM-05 | Exclusive gateway conditions/default | Deterministic route; invalid/no-default negative |
| BPM-06 | Parallel split into 3 | 3 tokens dispatched independently |
| BPM-07 | Parallel join out-of-order | Advances once after required arrivals |
| BPM-08 | Concurrent Kafka outcomes | No duplicate join / lost update |
| BPM-09 | Branch error bypasses join | Explicit modeled exception or validation blocks deadlock |
| BPM-10 | Timer one-shot after pod crash | Durable due recovered and logically fired once |
| BPM-11 | Two scheduler replicas claim same timer | Exactly one logical state transition |
| BPM-12 | Normal activity completes at boundary timer edge | Revision-guarded only one path wins |
| BPM-13 | Late capability completion after timeout | No advance of cancelled path; reconciliation record maintained |
| BPM-14 | Matching BPMN business error | Correct error boundary path selected |
| BPM-15 | Unmatched error nested subprocess | Correct propagation/uncaught policy |
| BPM-16 | Infrastructure failure | Not mislabeled as BPMN business error |
| BPM-17 | Sequential multi-instance 3 rows | Ordered and recovery safe without row duplication |
| BPM-18 | Call activity version pinning | Old running run remains pinned when new version published |
| BPM-19 | Human task multi-stage / backups | AMIE plan -> BOB tasks -> eligible decisions and resume |
| BPM-20 | Parallel branch + subprocess + timer + error | Combined-scopes conformance under restart |
| MSG-01 | Crash before Kafka publish | Transactional outbox replays durable intent |
| MSG-02 | Crash after publish/before outcome | Inbox/idempotency avoids duplicate logical side effect where supported |
| MSG-03 | Duplicate/late Kafka result | One logical transition; late outcome audited separately |
| SEC-01 | Read user direct POST execute | HTTP 403 and denied audit event |
| SEC-02 | Execute-Lead read group results | Own authorized group only, API row filter |
| SEC-03 | Unapproved Register/Configure | Cannot alter capability even via direct API |
| SEC-04 | Service account provider rights but unapproved workflow | No dispatch; provider rights do not override Unity admission |
| SEC-05 | Channel Secure mapped entitlement (before go-live) | SAML session+claims and group mapping verified; fail closed |
| REL-01 | PROD import lacks ServiceNow ID | Block; empty/whitespace invalid |
| REL-02 | Package hash/signature missing/altered | PROD activation blocked; no embedded key trust shortcut |
| REL-03 | UAT approved artifact import | Exact digest, resolved environment bindings and evidence |
| REL-04 | Active version rollback | New activation event; old runs preserve pinned version |
| REG-01 | Manifest discovered but unapproved | Not executable or visible in permitted operation picker |
| REG-02 | Operation version experimental within approved capability | Individual operation blocked according to policy |
| REG-03 | Capability used by two unrelated apps | Same operation handler and registry contract reused |
| UI-01 | Save conflict while dragging | Unsaved editor state preserved; 409 compare UI |
| UI-02 | AMIE->BOB decision trace | Rule/version, workflow/version, run and command correlation printable/redacted |
| UI-03 | BE reconnect | Server authoritative projection, no double-counting |
| UI-04 | Group administration/search | Authorized scope only, no accidental Prod/NonProd crossover |

## Testing level by milestone
M0 inventory and passing baseline/known failures; M1 SDK/catalog/group contracts; M2 AMIE/BOB human approvals; M3 expanded runtime semantics and failure injection; M4 Blazor screen/API/control tests; M5 integration contract & DEV/UAT package tests; M6 integrated pilot and UAT sign-off evidence. Later staged PROD evidence requires enterprise controls (Channel Secure/Apigee/Splunk etc.).

## Stop conditions
Unverified external endpoint/credential -> typed mock adapter and blocker; absent approval -> no privileged PROD operation; invalid BPMN -> draft allowed but no publish; missing signature trust root -> PROD upload disabled; missing Channel Secure integration -> not go-live ready; broad capability service credential does not waive application/operation admission.
