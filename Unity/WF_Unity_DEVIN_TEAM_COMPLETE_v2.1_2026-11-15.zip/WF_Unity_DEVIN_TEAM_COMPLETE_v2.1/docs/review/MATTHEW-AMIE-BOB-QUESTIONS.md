# WF Unity v2.0 - Questions for Matthew: AMIE, BOB, Groups and BE

**Document class:** Internal review / source reconciliation. **Exclude this entire document from both `ASK-MODE-HANDOFF.md` and `DEVIN-ASK.md`.**

**Status:** Questions and proposed future fix only. Do not instruct Devin to replace existing AMIE intake or authentication as part of the initial two-week development window. No source-code verification has been completed.

## 1. Agreed scope boundaries

- Keep the authentication, groups, and rule mechanisms Matthew has already implemented for the initial development window. Do not build another standalone login or group service without first auditing the existing work.
- In the current intake path, AMIE may receive, validate, enrich and classify an incoming message, select a workflow through rules, and publish a typed intake message to BOB. Keep this path initially unless a concrete defect blocks the first pilot.
- BOB owns durable orchestration: workflow execution, token state, branching, parallel joins, waits, timers, durable human tasks, capability dispatch, and recovery.
- AMIE owns business rule evaluation, policy/approval decisions, mapping and eligibility, including decisions invoked during BOB or capability execution.
- Capability services own API operations and service identities. Their technical API authorization is separate from users' BE/website entitlements.
- Website entitlements apply primarily to workflows (Read, Execute, Execute-Lead, Create) and the grouped capability-admin functions (Register/Configure); several groups or equivalent AMIE rule predicates may apply to the same workflow.
- Three environments only: DEV (non-prod), UAT (pre-prod), PROD. Enterprise Channel Secure SAML SSO/entitlements must be addressed before go-live, but work can continue against existing local arrangements.

## 2. Current implementation inventory: please show us what exists

1. Where are the current AMIE intake consumer, rule evaluation, enrichment, workflow routing and BOB publish implementations (repository paths and classes)? Which are in production-like code versus prototypes?
2. What is the exact inbound message schema? What does AMIE emit to BOB today (workflow identifier/version, enrichment, rule identity/version, correlation ID, request/user context, errors)? Which Kafka topics and schemas are already defined?
3. Does AMIE currently schedule or persist multi-step work, handle retries/approval waits, or directly invoke capability sequences? If yes, identify these exact paths for a *future* boundary correction; do not rewrite them during the first delivery unless they block execution.
4. What rule catalog/editor, group resolution, user authentication, and group-to-rule associations have already been built? Which screens and APIs exist? What would be duplicated by the proposed wireframes?
5. How do AMIE rules associate with applications, capabilities, workflow definitions and categories today? Are rules already versioned and pinned? Which organization changes are missing?
6. Which current AMIE rules select workflows, which govern user entitlements, which govern approvals, and which evaluate capability data? How are rule categories expressed today?
7. Does the existing BE UI already filter and enforce Read / Execute / Execute-Lead / Create, and capability Register/Configure group permissions? Where is *server-side* enforcement performed? Is run/report visibility group-scoped?
8. What components for human approvals exist: multiple approvers, ordered stages, backup approvers, approval state, task inbox, audit? Which component persists the waiting task? What are the current rule outputs?
9. What are current `DbContext`, SQL schema, migration and versioning conventions? Can the proposed lowercase `uty_` schemas be reconciled without destructive migration?
10. What is the current BPMN designer, XML+DI import/export, validation and version publication state? Is any UI output merely preview JSON rather than executable BPMN XML?

## 3. Proposed target contracts to review, NOT presumed existing

### Intake selection contract (AMIE -> BOB)

Fields to reconcile with current actual contracts: request ID, correlation/causation ID, authenticated requester context (or approved service initiator), selected workflow definition/version, AMIE decision/rule-set version, validated/enriched facts and their classification, decision reason codes, idempotency key, environment, and schema version. BOB revalidates approved workflow availability and authorization before execution. No sensitive secrets in the message.

### In-process rule call (BOB or capability -> AMIE adapter)

A typed, version-pinned evaluation request with facts and execution context; response includes rule identity/version, decision, typed outputs, reason codes and trace ID. Capability-local approved cached evaluation should not incur a mandatory central call for every technical step.

### Approval policy (AMIE -> BOB human-task runtime)

Rule response expresses approval stages, eligible group(s), required count / all-approvers policy, named primary/backup approver *references* when supported, reason and deadline policy. BOB owns durable assigned/pending/completed tasks; BE presents them and calls authorized decision endpoints. Approval of a release is separate from approval of an individual workflow request.

## 4. Optional Blazor UX proposals for Matthew to approve, adjust, or reject

- Shared application/capability context selector and consistent breadcrumb navigation across BE, BOB and AMIE.
- AMIE rule library grouped by owner application/capability, configurable category (e.g. Eligibility, Validation, Mapping, Routing, Governance, Approval Policy), version and consumer; rich search and dependency inspection.
- Rule editor preserves existing implementation but adds common tabs: Input/Output, Conditions, Tests, Consumers, Versions, Permissions, Audit.
- Workflow inspector links directly to AMIE rule detail, with inherited filtered application context; show approved rule version and binding schemas.
- Intake decision trace joins AMIE intake decision, enriched attributes, selected workflow, BOB instance and capability outcomes; redacted/printable audit view.
- Approval policy editor with stages, eligible group(s), backup approvers, requirements, rejection path, simulation and history.
- Group-to-workflow assignment with permission preview; avoid recreating Matthew's already-implemented authentication and membership management.

For each proposed screen, please record: **Keep existing**, **Adopt proposal**, **Modify proposal**, or **Reject**; include route/component path and rationale.

## 5. Future phase: recommended AMIE/BOB boundary correction

After the initial integrated demonstration, assess whether any AMIE path is actually orchestrating ongoing work (persistent sequence state, retries, timers, approval waiting, or direct multi-capability dispatch). If such paths exist, propose moving those mechanics into BOB while leaving initial validation, enrichment, classification and rule-based workflow selection in AMIE. Only implement the change after contract compatibility tests, backward-compatible migration planning and an approved follow-up Jira story. **This improvement is explicitly deferred; do not make it a first-pilot blocker.**

## 6. External dependency discovery for this week's integration workshop

Please identify what exists and who owns each: Channel Secure (SAML SSO and entitlements), Apigee gateway/API policy, Splunk logs/audit forwarding, AutoSys trigger and outcome contracts, NAS access through authorized API/service ownership, cron / scheduled job trigger conventions, and any approved service-account or secret reference infrastructure. For each supply existing endpoints/interfaces, required environments, identities, data classification, test fixture, approval/dependency and go-live acceptance gate. Do not invent or hardcode unavailable details.

## 7. Decisions requested from Matthew

- Inventory confirmation and file/route references for working code.
- Approval/adjustment/rejection of AMIE screen proposals.
- The minimal compatible AMIE->BOB message and BOB/capability->AMIE evaluation contract.
- Classification of any current AMIE orchestration behavior as **retain now / fix next phase / actual launch blocker**.
- Explicit known gaps and owners needed for M0/M1 Jira and two-week acceptance.

---

**Packaging rule:** Keep this file as a separate internal-review Markdown document. Do not concatenate or quote it in either Ask Mode handoff. Production release and implementation requirements derived from *approved* decisions belong in the normal handoff documents and therefore in Ask Mode; unresolved private review questions do not.
