> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# API Endpoint Catalog and Automation Naming

**Source baseline:** `history/v0.7/contracts/Unity_OpenAPI_Sketch_v0.7.yaml`. Routes here are proposed **families**, not implemented endpoints. Reconcile existing BE/API controllers in JOB-00 and keep OpenAPI accurate from actual implementation.

| Functional capability | Suggested API action | Default test |
|---|---|---|
| Capability discovery | GET /capabilities; GET operation version/schema | descriptor and role-scoped listing |
| Capability registration | POST /capability-manifests/validate; publisher action | wrong signature/owner rejected |
| Application catalog | GET/POST application blueprint/draft | scoped ownership |
| Workflow drafts | GET/POST/PUT draft, import/export BPMN | ETag conflict and XML safety |
| Workflow validation | POST draft/{id}/validate | incompatible AMIE field and unsupported node |
| Workflow lifecycle | submit review, approve, publish, activate, retire | immutable version and maker/checker |
| AMIE | list rules, describe rule, preview with safe fixture | typed outcome/pinned version |
| Triggers | create manual/API/CSV input intent | unauthorized upload/size rejected |
| Runs | POST run, GET run/activity timeline | correlation and pinned package |
| Operators | pause, resume, cancel, retry, restart | reason/role/ETag + audit |
| Business projections | GET batches/summary/rows/reports | user-scope filtering, paged |
| Audit | GET evidence events/export | redaction, no mutate |
| Runbooks and controls | GET versioned runbook and evidence refs | valid version/owner |
| Release | preflight and activate | unchanged digest and real approval |
| Regression | test harness fixtures via CI API | environment-isolated no-prod writes |

For each endpoint publish request/response JSON Schema, HTTP codes, authentication, scope, idempotency and audit requirements. All BE visual actions must map to backend API calls. Automated tests should not depend on UI clicking to prove business rules.
