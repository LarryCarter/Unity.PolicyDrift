# Contracts 14 — Type-Safe API, AMIE/BOB Intake, Kafka Commands and Registry Bindings

**Important:** Illustrative versioned contracts, not verified API routes. Reconcile existing SDK, AMIE, BOB and gateway conventions in M0; preserve compatibility. Never use a BPMN extension to execute arbitrary CLR class, URL, SQL statement or credential.

## 1. AMIE intake -> BOB request
```json
{
  "schemaVersion": "1.0",
  "requestId": "req-1001",
  "correlationId": "corr-1001",
  "idempotencyKey": "pam-create-1001",
  "environment": "DEV",
  "initiatorRef": "actor-ref-33",
  "source": "AMIE.Intake",
  "selectedWorkflow": {"key": "PAM.AccountOnboarding", "version": "2.1.0"},
  "decision": {"ruleSetKey": "PAM.IntakeRouting", "version": "1.7.0", "reasonCodes": ["ROUTE_PAM"]},
  "enriched": {"schemaRef": "PAM.AccountRequest@2", "dataRef": "redacted-approved-data-ref"}
}
```
Authenticated publisher, source schema, classifications, approved definition/version, environment and effective execution entitlement are verified again by BOB. Unknown version, spoofed initiator, replay or mismatch -> reject and audit. A rule may choose an active version alias only if BOB resolves and pins that approved version atomically at start.

## 2. BOB -> AMIE typed evaluation
```json
{
  "ruleKey": "PAM.CreateEligibility", "ruleVersion": "2.1.0",
  "factsSchema": "PAM.EligibilityFacts@2", "facts": {"accountClass": "service", "environment": "DEV"},
  "context": {"workflowRunId": "run-123", "activityId": "rule-4", "correlationId": "corr-1001"}
}
```
Result: decision enum and typed properties, safe reason codes, rule digest/version, trace ID. Use existing AMIE adapter's actual message format after reconciliation, with local cache permitted in embedded host.

## 3. Kafka approved operation command and outcome
```json
{
  "commandId": "cmd-901", "workflowRunId": "run-123", "scopeId": "scope-1", "tokenId": "token-4",
  "operation": {"capabilityKey": "CyberArk", "operationKey": "AddAccount", "version": "2.4.0"},
  "packageDigest": "sha256:...", "correlationId": "corr-1001", "causationId": "task-7",
  "idempotencyKey": "run-123-task-7", "deadlineUtc": "2026-11-16T18:00:00Z",
  "actorContextRef": "actor-ref-33", "payloadSchema": "CyberArk.AddAccountInput@2", "payloadRef": "protected-ref"
}
```
```json
{
  "commandId": "cmd-901", "correlationId": "corr-1001", "status": "Succeeded",
  "resultSchema": "CyberArk.AddAccountResult@2", "resultRef": "restricted-result-ref",
  "reasonCode": "CREATED", "externalOperationRef": "provider-op-777"
}
```
Expected outcomes `Succeeded`, `NoChange`, `Rejected`, `Failed`, `UnknownExternalOutcome`; BPMN error mapping is a separately declared typed policy. Late outcomes after cancelled activity update reconciliation record, not token advancement. Outbox/inbox persist at least once; business logical advancement once by transaction/idempotency.

## 4. Capability manifest sketch
```json
{
  "capabilityKey": "CyberArk", "manifestVersion": "2.4.0", "serviceOwner": "PAM",
  "operations": [{
    "operationKey": "AddAccount", "contractVersion": "2.4.0",
    "inputSchemaRef": "CyberArk.AddAccountInput@2", "outputSchemaRef": "CyberArk.AddAccountResult@2",
    "sideEffectClass": "ExternalWrite", "hosts": ["EmbeddedLocal", "KafkaCommand"],
    "bpmnErrorCodes": ["SAFE_NOT_FOUND", "POLICY_DENIED"],
    "idempotency": "ReconcileBeforeRetry", "serviceIdentityRef": "vault/identity-ref"
  }]
}
```
Registration is not approval or runtime availability. API gateway onboarding, service scopes, health, exact handler version, operation policy and environment activation all required to resolve an invocation.

## 5. Workflow binding example
```json
{
  "workflowKey": "PAM.AccountOnboarding", "version": "2.1.0",
  "bpmnFile": "process.bpmn",
  "bindings": [
    {"bpmnNodeId": "Task_Create", "operation": "CyberArk.AddAccount@2.4.0", "host": "KafkaCommand",
     "inputs": {"account": "${workflow.request.account}"}},
    {"bpmnNodeId": "Task_Eligibility", "rule": "PAM.CreateEligibility@2.1.0",
     "facts": {"accountClass": "${workflow.request.class}"}}
  ]
}
```
`${...}` placeholders here describe a constrained typed mapping syntax; select actual existing expression grammar rather than evaluating arbitrary JavaScript/C#.

## 6. Approval decision / human-task event
`ApprovalPlan {requestRef, ruleVersion, stages:[{eligibleGroupRefs,backupGroupRefs,decisionMode,requiredApprovals,timeoutPolicy}]}`; `HumanTask {taskId,runId,stageId,eligibleGroups,state,revision}`; `TaskDecision {taskId,actorRef,groupProofRef,decision,reason,revision,correlationId}`. Backend rejects stale/duplicate decision and unauthorized approver; BOB resumes when stage criteria satisfied.

## 7. Release artifact
`manifest.json` pins BPMN, AMIE rule, operation and called-workflow versions; `process.bpmn` is actual XML+DI; `bindings.json` contains typed references; `evidence.json` lists validation; digest/signature is generated/validated by trusted release machinery. PROD import requires valid ServiceNow change ID field and verified signer; package itself cannot establish trust by embedding a public/private key chosen by uploader.

## 8. API permission policy
Proposed routes must be reconciled: `GET /applications`, `GET /capabilities`, `POST /capabilities/manifests`, `POST /workflows/drafts`, `PUT /workflows/drafts/{id}`, `POST /workflows/drafts/{id}/validate`, `POST /runs`, `GET /runs/{id}`, `POST /human-tasks/{id}/decisions`, `POST /releases/imports`, `POST /releases/{id}/activate`, `GET /audit/trace/{correlationId}`. Require server-side resource authorization, ETag on writes, input schemas, correlation, audit, no browser-to-Kafka or direct client access to vault/database.
