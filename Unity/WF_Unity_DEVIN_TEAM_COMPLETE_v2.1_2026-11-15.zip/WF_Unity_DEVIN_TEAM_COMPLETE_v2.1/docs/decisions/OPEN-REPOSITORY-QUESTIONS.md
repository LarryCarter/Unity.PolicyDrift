> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Evidence Required Before Coding or Claiming a Release

DEVIN must answer these from repository/owner evidence during JOB-00 or mark as blockers:

1. What are **actual** AMIE libraries/classes for rule evaluation, validation, configuration version and persistence? Are rule descriptors available already?
2. What BOB source is implemented already? What BPMN parser/designer library is **approved**? Is the BOB core a blank project or incomplete runtime?
3. Which Unity capabilities currently exist, with which public DTOs, DI, Kafka topics and security? Can a CyberArk account be updated safely and idempotently?
4. What is actual DCMS CSV format, table schema and row-GUID semantics? Which service owns staging and report results?
5. Which Kafka .NET client/schema registry/outbox conventions and broker ACL provisioning are approved? Are topics already established?
6. Which MSSQL versions/provider/data access/migration conventions and audit controls are approved? Which service identity may append audit?
7. What BE Blazor hosting mode, state management, component libraries and auth providers already exist? Does it already have workflow or approval UI?
8. Which exact bank CAs, release checks, ServiceNow authorization process, approvers, audit retention and SIEM integrations apply? Who signs off?
9. Which CI/CD tools and automated test frameworks are approved and usable before November 30?
10. What two applications are realistic to demo with approved data and credentials? Who provides UAT acceptance?

For each answer record: evidence URL or actual file path, owner, last verified UTC, proposed code change impact, and unresolved risks. Avoid putting credentials/secrets into the document.
