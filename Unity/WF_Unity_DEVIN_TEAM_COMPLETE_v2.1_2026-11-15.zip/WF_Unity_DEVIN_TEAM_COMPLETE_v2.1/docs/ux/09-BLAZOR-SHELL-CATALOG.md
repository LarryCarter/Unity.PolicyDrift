# UX 09 — Shared Blazor Shell, Application/Catalog Hierarchy and Navigation

## Design principles
Existing BE Blazor components/routes win if compatible; audit first. Standard shell: top bar `Unity | Environment | Application/Capability context | Search | My Tasks | Profile`; sidebar `Workbench, Applications, Capabilities, BOB Designer, AMIE, Run Monitor, Reports, Administration, Release Center, Audit`; breadcrumb and persistent detail-panel tabs. Keep filters when navigating back. Keyboard focus, accessible error summaries, empty/loading/forbidden states and correlation IDs on error. **All clickable controls must have a real authorized backend action**; clickable HTML prototype is only a mock.

### Catalog wireframe (desktop; responsive left drawer on small screens)
```text
+-------------------------------------------------------------------------------------------+
| Unity  [DEV v]  Scope:[PAM v]  Search [workflow/capability/rule ....]  [My Tasks] [User]    |
+---------------------+---------------------------------------------------------------------+
| Workbench           | Applications > PAM > Onboarding                   [New Workflow]    |
| Applications        | Filters: [L1/L2 v] [Category v] [Owner v] [Status v] [Search...]       |
|  PAM                | +---------------------+-------------------------------------------+ |
|   Onboarding        | | COLLECTIONS         | NAME / VERSION / STATUS / GROUPS / OWNER    | |
|   Hygiene           | | > Onboarding        | Account Onboarding  v2.1  Approved  PAM  | |
|   Governance        | | > Hygiene           | Safe Creation       v1.4  NonProd   PAM  | |
| Capabilities        | | > Governance        | ...                                       | |
|  CyberArk           | | > Shared Library    |                                           | |
| BOB Designer        | +---------------------+-------------------------------------------+ |
| AMIE                | [Open] [Duplicate Draft] [View Dependencies] [Access] [Versions]    |
| Run Monitor         | Detail: Overview | Operations | Rules | Groups | Runs | Audit       |
| Release Center      |                                                                     |
+---------------------+---------------------------------------------------------------------+
```

## Screen S09-01 — Workbench
**Purpose:** User finds permitted actions and active requests. **Entry:** shell default. **Tabs:** My Workflows, My Runs, My Approvals, My Reports. **Controls:** context selector; pinned apps; recent runs; New Request; Resume Draft; View Status; Search. **Interactions:** select application filters without changing auth; New Request only offered when Execute; My Approvals only eligible pending tasks; Refresh fetches authoritative run projection. **Negative test:** direct API returns 403 when user lacks entitlement even if route is typed manually.

## Screen S09-02 — Application workspace
**Purpose:** owner-scoped L1 workflows in configurable collections and tags. **List columns:** Name, Level, Category, Version, maturity/stage, Active environment, entitlement summary, owner, updated. **Actions:** New workflow draft, browse version history, select category, linked rules, export, open monitor, assign group (authorized admin). A workflow has one owning app but multiple consuming associations; move category without changing identity. **Empty/invalid:** no permission vs no workflows explicitly distinguished.

## Screen S09-03 — Capability workspace
**Purpose:** owner sees operations and L2 workflows together. **Tabs:** Overview, Operations, Workflows, AMIE Rules, Service Account/API Config, Versions, Permissions, Activity. **Actions:** Open operation inspector, Add owned workflow, Browse Shared Library; assign approved operation to workflow. **No giant global workflow list** until opt-in search. **Backend:** filter by stable capabilityId and authorized scope; do not infer from tags.

## Screen S09-04 — Collection/category administration
**Purpose:** create/edit tree of Onboarding, Hygiene, Governance, Policy Drift, Reporting and custom categories. **Fields:** categoryKey/display, owner scope, parent, sort order, allowed resource levels, status, description, tags. **Controls:** Add, Rename, Move, Retire, Preview affected resources; no permission inheritance by default. **Save:** optimistic concurrency, audit; reject duplicate key, cyclic parent, orphan removal without migration plan.

## Common admin UX
Every resource uses a consistent detail header with owner, environment, version, maturity-stage, activation and experimental warning. Standard tabs `Overview | Configuration | Dependencies | Groups | Versions | Tests | Audit`. Contextual toolbar `Save Draft / Validate / Test / Request Review / Promote`, with disabled reasons rather than silent hidden controls when appropriate. Audit diff with actor/time/changeRef and before/after redacted fields.

## Proposed API surface (verify against repo)
`GET /applications?scope`, `GET /catalog/resources?ownerId&level&category`, `GET /capabilities/{id}/workflows`, `POST /workflow-drafts`, `PUT /catalog/categories/{id}`, `GET /resources/{id}/dependencies`, `GET /me/entitlements`. All endpoints authorize per resource; pagination, ETag and stable IDs mandatory for mutations.

## Acceptance
From PAM Onboarding navigate to workflow, related CyberArk capability, its operation inspector, associated AMIE rule, and back without losing context; register new category without code change; standard 403 and empty states; no client-maintained list of all enterprise workflow definitions.
