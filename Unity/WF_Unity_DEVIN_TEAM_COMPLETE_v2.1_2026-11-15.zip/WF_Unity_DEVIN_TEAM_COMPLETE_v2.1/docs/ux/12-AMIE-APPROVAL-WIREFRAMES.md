# UX 12 — Proposed AMIE Blazor Rule Library, Human Approvals and Group Assignment

**Review status:** design candidates for Matthew, not authoritative replacement of any working AMIE screen. Keep/modify/reject individually. Existing rules and groups are assumed to be implemented at least partially; inspect actual paths before extending.

### Screen A12-01 — AMIE rule library
```text
+-----------------------------------------------------------------------------------------------+
| Unity / AMIE  Context: [PAM v]  Search:[........]  Type:[Approval Policy v] [Version v] [New] |
+---------------------------+-------------------------------------------------------------------+
| Application/Capability    | Rule: PAM.CreateAccountEligibility @ 2.1 [NonProd-Verified]        |
| > PAM                     | Type: Eligibility     Owner: PAM      Consumer: 4 workflows        |
|    > Onboarding           | Inputs: Request.AccountType, Request.Owner; Outputs: Allow, Reason |
|      Eligibility          | [Conditions] [Facts] [Test] [Consumers] [Version History] [Audit] |
|      Approval Policies    | Linked workflow: PAM.AccountOnboarding v2.0   [Open in BPMN]        |
|      Mapping              |                                                                   |
|    > Hygiene              | [Save Draft] [Validate] [Request Review] [Compare Versions]       |
| > CyberArk Capability    |                                                                   |
| > Shared Rule Library     |                                                                   |
+---------------------------+-------------------------------------------------------------------+
```
Add filters by application, category, rule type, owner, approved environment, stage, and used-by. The list defaults to current application/capability, not all enterprise rules. Selected rule has schema-based conditions editor or links to Matthew's current editor; do not rewrite rule grammar. Versions immutable after publication.

### Screen A12-02 — Rule configuration and test
Fields owner, category, rule key/version, trigger/consumer type, typed input facts/output schema, conditions, policy dependencies, group restrictions, test cases, current version and change history. `Run Test` accepts redacted fixture and shows decision, reason codes, version, evaluation duration, trace ID; distinguish mock from live AMIE engine. `View Consumers` lists BOB workflow versions and capability recipes pinned to the rule.

### Screen A12-03 — Approval Policy builder
```text
| AMIE > Approval Policies > PAM.PrivilegedAccount.CreateApproval v2.0 [Draft]                  |
| Conditions: accountType=privileged, highRisk=True  [Test decision]                            |
| Stage 1: Application Owner  [Group:PAM.AppOwners v] [Backup:PAM.Backups v] [AnyOne v]        |
|           [Add backup] [Set SLA] [Reject path: Reject]                                        |
| Stage 2: Security           [Group:PAM.Security v]  [Backup:SecBackup v] [AllRequired v]     |
|           [Required count:2] [Change order] [Remove stage]                                   |
| Stage 3: Operations         [Group:PAM.Ops v]      [Optional based on rule]                   |
| [Add Stage] [Preview Approval Plan] [Validate] [Submit for Rule Review]                       |
```
AMIE rule returns typed approval stages. BOB creates durable HumanTask records and consumes decisions. BE work queue enforces eligible group + current actor, captures approve/reject and comment/reason, and resumes BOB after stage satisfied. Do not use AMIE as a second durable waiting engine.

### Screen A12-04 — Workflow-to-group assignment
On a workflow `Groups & Access` tab choose existing Unity group(s), role Read / Execute / Execute-Lead / Create, rule restriction (optional), env eligibility DEV/UAT/PROD, active dates/version and preview effective access. Show warning for policies that give lead visibility across unintended groups. Provide search/add/remove groups and impact review; changing grants never silently changes current workflow definition version.

### Screen A12-05 — Approval work queue
`My Approvals / My Group / History`, title, request ID, workflow version, current stage, eligible group, backup status, due date, initiator, allowed decision buttons. Clicking task shows redacted request, AMIE decision and rule version, prior stage outcomes, reason field. Unauthorized actor cannot approve through API even if link known; duplicate decision is idempotent; reject path clear. Backup assignment behavior tested, not inferred from UI.

### Screen A12-06 — Intake-to-execution trace (Printable)
AMIE intake message ID -> validated/enriched facts -> rule/version decision -> selected workflow/version -> BOB instance ID -> gateway/task decisions -> capability command/outcome IDs -> completion/report. Redact protected facts. Buttons `Copy Correlation ID`, `Print`, `Export Redacted Trace`, `Open BPMN Monitor`, `Open AMIE Rule`; resource-scoped authorizations. This is for troubleshooting and eventual policy drift evidence.

## Proposed click contract
| Control | Backend intent | Evidence and denial |
|---|---|---|
| AMIE New Rule | Create versioned draft in existing AMIE editor/registry | ETag, creator, authorized owner scope |
| Bind to BPMN | Request typed rule descriptor and pin exact version | Schema type check and dependency history |
| Approval Preview | Evaluate AMIE policy against redacted fixture | No durable approval task created |
| Submit Approval Request | Create BOB task using approved AMIE plan | BOB owns state, actor/time audit |
| Approve/Reject | Authorized decision against pending BOB task | Duplicate/unauthorized rejected, audit reason |
| Assign Group | Versioned entitlement association update through owning API | No direct group membership creation |
| Print Trace | Read authorized redacted AMIE/BOB/capability correlation | Download/print permission checked |

## Acceptance and review
Matthew marks each proposal `Keep Existing / Adopt / Modify / Reject` and identifies current route/component implementation. Phase 1 integrates via compatible existing APIs; source audit and later refactor separately planned. User guide must cover both rule authoring and workflow binding without requiring users to edit database tables.
