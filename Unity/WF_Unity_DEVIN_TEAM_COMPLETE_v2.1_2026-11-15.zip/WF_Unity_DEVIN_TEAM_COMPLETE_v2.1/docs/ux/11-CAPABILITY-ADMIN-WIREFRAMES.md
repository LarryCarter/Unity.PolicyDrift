# UX 11 — Blazor Capability Administration, Operations and Lifecycle

## Intended one-page-first flow
`Capabilities list -> Open capability -> Overview -> Configuration (Operations/Workflows/API reference) -> Development -> Validation -> Approval -> Environment Activation`. All tabs share a persistent resource header with owner, version, combined status, active environment, warnings and last update. User may jump tabs; no forced wizard for ordinary review. For first-time onboarding, optional guided wizard follows same order.

### Screen C11-01 — Capability list
```text
+----------------------------------------------------------------------------------------------+
| Admin > Capabilities                [Search] [Classification v] [Stage v] [Owner v] [Register] |
| Key / Name          Owner          Version      Status                     Env       Actions   |
| CyberArk            PAM            2.0          Approved-ReleaseReady      DEV/UAT   [Open]    |
| Identity API        Identity       1.2          NonProd-Testing            DEV       [Open]    |
| Report Generator    Reporting      0.7          Experimental-InDev         DEV       [Open]    |
|                                                       [Export filtered list]                 |
+----------------------------------------------------------------------------------------------+
```
Examples are hypothetical, not actual environment capabilities. Actions: register draft, compare manifest, inspect operation, check owner and filtered status. No direct user assignment to external provider APIs.

### Screen C11-02 — Capability detail
```text
| Identity API v1.2 [NonProd-Testing]  Owner: Identity   Env: DEV   [Save] [Validate] [Review] |
| Overview | Operations | Workflows | AMIE Rules | API/Service Identity | Development | Audit  |
| Summary: 4 approved handlers / 1 experimental handler; last manifest digest; health status  |
| Operations [Search]  [GetUser@1] [CreateUser@1] [DisableUser@1 Experimental]                |
| Workflows: Local L2 recipes    [Add Workflow] [Browse approved shared recipes]              |
| Service API: Apigee onboarding [pending]  Credential reference [vault://... masked]         |
| Access: Register/Configure entitlement groups (Unity); service identity external grant      |
```

### Screen C11-03 — Development / Validation / Approval
`Development` selects classification Experimental, NonProd, Approved and stage InDev, Testing, Verified, ReleaseReady; shows combined status and required evidence/known limitations. `Validation` shows contract, unit/integration, dependency, authorization, broker, host and scope checks with machine-readable failures. `Approval` shows requested transition, current version owner, reviewer, evidence, request reason, decision and audit. Approval does not automatically activate. Show copyable Jira/milestone link without making ticket maintenance a UI prerequisite for every user action.

### Screen C11-04 — Operation inspector
Tabs: Input Schema / Output Schema / Permissions / API-Transport / AMIE Bindings / Retry and Reconcile / Version History / Tests. Required field editor generated from type schemas. Side effects visually clear (Read, LocalTransform, ExternalWrite, HighImpactExternalWrite). `Add to Workflow` inserts a service task with pinned operation ID and typed bindings; no free-form arbitrary HTTP or CLR class-name input. Test operation uses approved DEV fixtures and labels real external write versus simulated result.

### Screen C11-05 — Capability registration wizard
1. Select owning department/application and name/stable capability key.
2. Choose SDK registration or external REST/Kafka adapter; identify trusted deploy identity and contract schema.
3. Inspect generated handler manifest and operation versions; validate unique keys and schemas.
4. Configure environment and service-account/gateway *references*, topic/message descriptors, policy scope, redaction and health probe.
5. Validate with negative authorization/contract test; submit for review. Registry becomes discoverable only according to approval/activation policy.
6. Go to Workflows to create/view L2 recipes without opening all enterprise workflows.

### Screen C11-06 — Capability registration and configuration groups
Admin selects existing Unity group(s) for `Capability.Register` or `Capability.Configure` within owner scope; AMIE may add policy restrictions; these grants are distinct from users' workflow Execute/Read/Create. Show effective permission preview and audit. Do not require an external provider to add each human user to its service-account/API controls.

## Proposed server actions, to reconcile in code audit
`GET /capabilities`, `GET /capabilities/{id}/operations`, `POST /capabilities/manifests/drafts`, `POST /capabilities/{id}/validate`, `POST /capabilities/{id}/review-requests`, `POST /capabilities/{id}/activate`, `GET /capabilities/{id}/workflows`, `GET /capabilities/{id}/audit`.

## Error/empty behavior
Register collision, missing handler, untrusted manifest, disabled operation, service unreachable, API target unknown, UAT policy restriction, invalid status transition, stale ETag, or group denial all produce explicit actionable nonsecret errors. A Registered manifest without approved code/availability must not appear as executable operation.

## Acceptance
Admin can register example capability, approve one operation for DEV, mark another Experimental, bind approved operation to an L2 workflow and link to L1; unauthorized user cannot configure or invoke outside workflow; human entitlement scope is enforced independently from external service account access.
