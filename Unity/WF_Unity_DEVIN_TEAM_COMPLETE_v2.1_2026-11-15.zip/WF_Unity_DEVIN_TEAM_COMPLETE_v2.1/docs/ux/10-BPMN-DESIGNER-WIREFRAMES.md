# UX 10 — Full BPMN 2.0 Designer, Palette, Experimental Mode and Inspector Wireframes

## Designer shell
```text
+------------------------------------------------------------------------------------------------+
| PAM > Onboarding > Account Onboarding v2.2 (Draft)   [DEV] [Experimental OFF] [Save] [Validate] |
+-----------------------+---------------------------------------------------+--------------------+
| BPMN PALETTE          | CANVAS                                            | INSPECTOR          |
| [Search nodes...]     | Start --> Validate --> XOR --> Service --> End   | Selected: Service  |
| Events                |   (pool / lanes / DI coordinates)                 | Name, ID, scope    |
|  Start End Timer      | Parallel fork -> 2 tasks -> join                  | Capability         |
| Activities            | Boundary timer/error attachment circles          | Operation@version  |
|  Service BusinessRule | [Zoom][Fit][Undo][Redo][MiniMap]                  | Input/Output map   |
|  UserTask Call/Sub    |                                                   | Error/timer        |
| Gateways              |                                                   | Retry/policy       |
|  XOR Parallel         |                                                   | Group entitlements |
| Data / Pools / Lanes  |                                                   |                   |
| Experimental nodes*   |                                                   |                   |
+-----------------------+---------------------------------------------------+--------------------+
| Issues: 2 errors, 1 experimental warning | Versions | Rule Trace | Test Bench | Publish Review |
+------------------------------------------------------------------------------------------------+
```
**Implementation:** reuse/validate an approved BPMN modeling library (e.g. bpmn-js if compatible with existing Blazor framework and dependencies); do not build drag/drop BPMN geometry from scratch without an approved reason. Actual canvas uses BPMN XML/DI, not schematic node-order JSON.

## Full palette inventory and planned semantics
| BPMN group | Model/import and DI support | Phase 1 executable | Deferred/Experimental handling |
|---|---|---|---|
| Events | Start, End, message, timer, signal, conditional, error, escalation, terminate, link, compensation, cancel, multiple/parallel-multiple | Simple Start/End, intermediate Timer Catch, interrupting Timer Boundary, interrupting Error Boundary, current Kafka outcome wait | All other events tagged Experimental until handler passes conformance; precise subtype support matrix mandatory |
| Activities | Task, service, business rule, user, receive, send, script, manual, call, subprocess, event subprocess, transaction, ad hoc, multi-instance | Service, AMIE BusinessRule, minimum durable UserTask, Call, embedded subprocess, sequential multi-instance | Script/custom user code never executable; receive/send if not implemented; parallel multi-instance, event subprocess, transaction, ad hoc as experimental |
| Gateways | Exclusive, Parallel, Inclusive, Event-based, Complex | Exclusive, Parallel split/join | Inclusive/EventBased/Complex experimental, no fake XOR fallback |
| Collaboration | Pools, Participants, Lanes, message/sequence flows | Lane membership and sequence flow in single executable pool; Kafka outcome waiting mapped via registered adapter | Multiple executable participant orchestration/message flow behaviors experimental; preserve XML/DI |
| Data & artifacts | Data object/reference/store, properties, input/output associations, groups, text annotation | Typed variables, mappings, selected data objects | Preserve representation; semantic data-store execution only if explicit supported handler |
| Extensions | Extension elements/attributes, diagram geometry, BPMN XML namespaces | Approved Unity binding IDs + version refs | Preserve unrelated XML where safe; no arbitrary code or unknown execution fallback |

**Strict BPMN correctness:** sequence flow crosses lanes but not pools; message flow links participants; lanes do not inherently map to Kafka topics or execution hosts. Boundary event attached to an activity; noninterrupting boundary appears dashed as standard notation. DI must preserve coordinates, waypoints and stable IDs.

## Feature flag and visual treatment
`Experimental Mode` is an admin-authorized editor-level toggle: OFF hides/de-emphasizes unsupported palette creation; imported experimental nodes still show with warning. ON displays standard elements marked `(Experimental)` with amber badge and explanatory tooltip. A workflow including even one unapproved element displays persistent `Contains Experimental BPMN` banner, list of node IDs, Jira link and environment execution eligibility; save/export available but not PROD activate. A third state NonProd-Approved is maturity policy, not a new unsupported fallback.

## Inspector behavior by node type
- ServiceTask: select capability -> approved operation/version -> input JSON Schema fields -> output variable bindings -> auth/host/side-effect badge -> timeout/retry/error mapping -> test fixture.
- BusinessRuleTask: AMIE application/category filtered picker -> pinned rule version -> typed facts/output -> decision trace preview.
- UserTask: form/approval policy ref -> eligible group(s) -> any-one/all -> backup group -> due policy -> approve/reject response schema.
- ExclusiveGateway: labeled condition for every outgoing path and explicit default; condition authored as constrained expression/AMIE output binding, not arbitrary code.
- ParallelGateway: split/join usage and graph analysis; show warning on potentially unstructured synchronization paths.
- TimerCatch/Boundary: date/duration selector, UTC handling, due preview, interrupting icon, attached activity reference, cancellation warning.
- ErrorBoundary: matching BPMN error code mapping from operation/AMIE definition and outgoing flow; unmatched behavior.
- CallActivity: choose approved WorkflowDefinition@version, host requirements, typed in/out mapping, same/other scope and recursion detection.
- Pools/Lanes: add/rename participant or lane, move nodes, preserve DI; no implicit service binding.

## Top toolbar click contract
| Control | Preconditions | Expected server/UI outcome |
|---|---|---|
| New/Import | Create entitlement; valid XML format | Draft created with original BPMN IDs/DI, unsupported elements preserved/flagged |
| Save | ETag/revision | Persist XML+DI and bindings; 409 shows compare/recover screen |
| Validate | Any saved draft | Graph, schema, approvals, host, experimental, operation/rule/version checks with node links |
| DEV Test | Authorized + compatible handlers | Explicit fixture/live/mock label; runId, trace, token monitor |
| Experimental Toggle | Feature+role/environment policy | Palette visibility only; no runtime privilege change |
| Request Review | Valid draft/evidence | Human review workflow submission and audit |
| Export BPMN XML | Any authorized readable draft | Download `process.bpmn` with real BPMN XML+DI, not JSON-only mock |
| Export Unity Package | Approved package-draft permissions | BPMN XML+Unity manifest/bindings, content hashes; not auto-signed |

## Negative tests
Malformed XML does not replace draft; move node preserves ID/geometry; wrong cross-pool sequence flow rejected; missing service operation version blocks publish; unsupported event-based gateway prevents runtime despite saved drawing; imported experimental node flagged with correct Jira; timer boundary race returns exactly one path; XML roundtrip retains DI/lanes and unknown safe extension elements; keyboard/focus and screenreader support.
