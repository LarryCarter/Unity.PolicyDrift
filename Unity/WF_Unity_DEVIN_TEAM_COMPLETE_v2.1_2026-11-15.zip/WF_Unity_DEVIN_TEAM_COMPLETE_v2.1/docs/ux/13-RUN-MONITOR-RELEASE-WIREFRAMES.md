# UX 13 — BPMN Run Monitor, Group Reports, Human Task Inbox and Production Import

### Screen R13-01 — Run monitor
```text
| Workflows > PAM.AccountOnboarding > Run 8f... [Running] [v2.1] [DEV]                         |
| [BPMN Diagram Overlay] [Timeline] [Variables (redacted)] [Commands] [Errors] [Audit]           |
| Active tokens: AD branch [Succeeded] / CyberArk branch [Waiting] / Reporting [Running]          |
| Timers: CyberArk timeout due 22:00Z   | Last Kafka outcome: command-7   | Join pending 2/3   |
| [Pause] [Resume] [Cancel with Reason] [Restart as New Run] [Export authorized trace]             |
```
Run status uses backend-authoritative snapshot; SignalR/SSE are change hints and reload after reconnection. Multiple concurrent tokens shown without implying ordered execution; boundary timer and error routes distinct from successful join. Unknown external outcome warning cannot be marked success from timer expiry. Pause/resume/cancel require authorized user, reason, safe checkpoint and audit.

### Screen R13-02 — Reports and Execute-Lead scope
`Mine | Group | All (authorized only)` tabs. Read sees permitted results, Execute sees its own run/report data, Execute-Lead sees authorized members of assigned groups but no unrelated group. Data owner may apply classification redaction. Row-level filters at API and projection service, not UI. Printable/downloadable report requires separate release of sensitive fields where classified.

### Screen R13-03 — Release center
```text
| Unity / Release Center                       Environment: [UAT v]                            |
| [Drafts] [Validation] [Packages] [Imports] [Activations] [History]                           |
| Package: PAM.AccountOnboarding v2.1 [Approved-ReleaseReady]                                 |
| process.bpmn XML+DI [OK] | Unity bindings.json [OK] | AMIE@2.0 [OK] | CyberArk@2.4 [OK]       |
| Hash [OK]  Signature [verified with trusted release key?] [pending if unavailable]            |
| Experimental nodes [NONE] | Test evidence [attached] | ServiceNow ID [CHG......]             |
| [Validate Import] [Request Review] [Import Artifact] [Activate Approved Version]              |
```
DEV/UAT import preview supports negative tests. PROD activation requires approved trusted signer/enterprise release mechanism, current eligible entitlements, required approvers and nonempty ServiceNow change ID. Field presence is validated, not live ServiceNow ticket status. **Import does not equal activate**. If signature/trust chain is unavailable, PROD import/activation remains unavailable rather than faking protection with a key embedded in XML.

### Screen R13-04 — Release history and rollback
List environment, activated immutable version, content digest, active alias, actor, approver, change ID, tests, old version and activation time. `Rollback` creates new authorized activation event pointing to prior approved content; no overwriting old artifacts or migrating current runs silently. Audit export and drift baseline supported.

### Screen R13-05 — Group resource administration
Search existing groups (Matthew's store in DEV; future Channel Secure mapped identities) with environment, description, source, active status and assigned resource counts. Select group to view permitted workflow scopes, capability Register/Configure, rules, preview effective permissions, changes. Admin can assign to workflows and rules, not manage external API users. Environment configuration import offers dry-run diff, validation, approval and audit.

## Error/empty state and tests
Mismatch BPMN+DI, missing rule/operation version, missing change ref, invalid signature, expired authorization, UAT-only resources in PROD, concurrent version change, non-eligible group, report forbidden, late Kafka result after interruption, and unverified readiness each have explicit blocked action and reason. No placeholder green check may be shown without verification.
