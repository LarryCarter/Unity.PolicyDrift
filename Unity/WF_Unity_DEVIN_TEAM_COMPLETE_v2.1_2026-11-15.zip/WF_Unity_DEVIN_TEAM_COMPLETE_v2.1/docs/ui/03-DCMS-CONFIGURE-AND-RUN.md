> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI Runbook 03 — Configure and Execute DCMS in DEV

**This is a business workload used to prove platform reuse, not application code inside BOB.** Before a real test, reconcile actual DCMS table schema, AMIE rule names, CyberArk safe test accounts, Email/Reporting integrations and data owner. Mock any unapproved external dependency and label clearly.

## Configure once

1. **BE → Application Studio → Create/Open DCMS**. Set owner, user scopes, allowed trigger and application-specific data contract.
2. **Data source:** select `CSV Upload` trigger; bind configured CSV schema, allowed headers, safe file storage, max rows and required validation. Future API/database/AutoSys sources all normalize to a start intent (P1, not currently present).
3. **Central BOB draft:** create `DCMS.BatchCoordinator`; add `StageImport` capability activity, `CreateBatch`, cross-service `ExecuteEmbeddedWorkflow`, durable wait, `Reporting.GenerateBatchReport`, and `Email.RequestNotification`.
4. **CyberArk embedded BOB:** create/reuse sequential multi-instance row workflow; `GetAccount` -> AMIE eligibility -> AMIE custom-attribute mapping -> in-memory patch -> `AddOrUpdateAccount` -> persist result. Map batch and row GUID to each outcome; only one row at a time.
5. **AMIE:** select existing rule definitions or create approved rule configurations through current AMIE tools. Bind the four illustrative CSV fields to correct CyberArk platform custom-attribute targets. Ensure platform metadata validates allowed attributes. Missing account policy must be explicit: fail/skip/create only if create is approved.
6. **Email:** configure report recipient/template policy in AMIE and bind `Reporting.GenerateBatchReport` output reference to Email capability; do not put SMTP in BOB.
7. **Runbook:** attach batch control owner, accepted failure thresholds, what Pause/Cancel mean, and reconciliation procedure for unknown writes.
8. Validate and publish approved DEV package with exact versions. Do not assume it can go to PROD because it runs in DEV.

## Execute a controlled 5-row fixture

1. Sign in as BusinessExecutor with DCMS scope; choose **Business Work Queue → DCMS → Upload CSV**.
2. Upload safe fixture (success / no change / missing account / invalid AMIE mapping / uncertain write). Confirm batch number and **unique row GUID per row** are created.
3. Choose **Start**. BE calls authorized API and shows run ID; central BOB stores run and sends Kafka command.
4. Watch **Business Batch** summary: pending/in progress/succeeded/failed/skipped/no change/unknown totals and a last update time. Percent = terminal count / total staged; unresolved unknown outcomes must not be hidden.
5. As Operator, open **BPMN Run Monitor**: trace central message, embedded workflow, AMIE decision version, capability result, row GUID and audit event.
6. Confirm every row reaches final or explicitly unresolved classification; generate report from stored row results, not message count. Confirm email requested through Email Capability and delivery recorded separately.
7. Download redacted report, inspect reasons for failures and no change; compare report counts to DB/API; inspect audit by batch number and correlation.

## Negative/UAT controls

Test unauthorized upload; duplicate file import; conflicting batch number; duplicate Kafka command; CyberArk timeout after possible write; pause after row 2 (no row 3 starts until resume); cancel/restart linked run; unexpected email failure; audit unavailable; rule version missing; service ACL denied. No blind external write retry.

## Success evidence

CSV fixture hash, batch/row GUIDs, published package digest, API trace, Kafka command/outcome IDs, AMIE rule versions, CyberArk operation reference or mock marker, persisted row status table, report checksum, email outcome, audit reconstruction screenshot, runbook revision.
