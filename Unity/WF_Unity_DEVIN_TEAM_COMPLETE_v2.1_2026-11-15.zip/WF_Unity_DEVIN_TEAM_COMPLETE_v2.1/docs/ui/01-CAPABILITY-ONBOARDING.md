> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI Runbook 01 — Register and Verify a New Capability

**Audience:** capability developer, service owner, authorized publisher. **Screen names are proposed Blazor BE destinations** based on v0.6/v0.7 prototypes; actual routes require implementation. **Do not use a live enterprise system in regression fixtures.**

## Developer preparation (before BE)

1. Use `@skills:unity-capability-service`. Inspect repo and real SDK first. Identify reusable primitive: operation key, input/output DTO, read/write nature, security policy, schema, AMIE data requirements, Kafka logical contracts, audit and test fixtures.
2. Implement typed handler in service, register with SDK DI, add tests for success, schema-invalid request, denied caller, duplicate command, and uncertainty after an external write.
3. Build signed/trusted-attested manifest; run manifest schema/contract validation in CI. Do not publish automatically because startup found a class.
4. Deploy to **approved nonproduction** environment, complete code controls, and publish manifest using service identity.

## BE click path

1. Sign in as authorized capability owner. Navigate **BE → Capability Registry → My Capability**.
2. Search capability key; inspect **Manifest Version**, owner, deployment, readiness and permissions. If absent, use registration diagnostics; do not bypass with a raw URL.
3. Open **Operations** and choose the declared operation (e.g. `CyberArk.GetAccount@1.0`).
4. Inspect inputs (required fields, types, classification), outputs, execution host modes, AMIE required facts, Kafka subscriptions/publications, retry policy and permission.
5. Choose **Test contract** in DEV with approved nonproduction fixture, pass `AccountRef`, inspect safe response and audit/correlation.
6. Choose **Add to workflow**. BE inserts a service task with operation reference; input field editor auto-populates from schema.
7. Save draft, validate wiring. Successful registration means handler exists + manifest/health/policy are compatible—not that production use is approved.

## Negative demonstration

Change one required field type, reference an unapproved operation, or remove required permission; validation must fail with actionable code and node ID. A direct API invocation must also fail, not just the UI button.

## Required evidence

Manifest version/digest; handler source path; CI build, SDK registration tests; service health; operation schema; API request/response (redacted); denied-call test; BE screenshot; ServiceNow code release evidence where applicable.
