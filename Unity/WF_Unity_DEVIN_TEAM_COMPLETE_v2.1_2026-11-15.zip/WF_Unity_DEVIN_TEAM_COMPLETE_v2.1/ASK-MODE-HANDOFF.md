# WF Unity v2.1 — Devin Ask Mode Complete Current Handoff

**INSTRUCTIONS:** All following sections are the complete, unabridged text of the current Markdown files in the v2.1 master ZIP, including updated old detailed job/UX documents marked with the v2.1 precedence note. They are ordered current-first followed by detailed legacy references. The Matthew questions document is intentionally excluded. Entire original historical archives and the large vendor API reference are excluded; they are preserved separately in the ZIP and explicitly not current implementation instructions. No content from included source files has been summarized. Source-file delimiters show origins. Begin with the root instructions.


---

<!-- BEGIN SOURCE 001: 00-START-HERE.md -->

# WF Unity v2.1 — Definitive Complete Devin + Team Handoff

**Status:** Approved design direction for implementation planning; no repository implementation, production approval, access or successful external integration is claimed. **Environments:** DEV (non-prod), UAT (pre-prod), PROD. **Package role:** complete reconciled v2.1 design handoff, incorporating the original Complete/Current v1.1 archives, updated canonical specifications, and detailed historical cases. **Sources:** current conversation decisions plus inspected original Complete and Current v1.1 archives; see `planning/19-SOURCE-AND-DECISION-REGISTER.md` for source parity proof.

## First instructions for Devin
1. Read repository `AGENTS.md`, existing platform docs, all real implementations, migrations and tests; run the current baseline. Do **not** infer code exists from these specifications.
2. Preserve Matthew's existing authentication, group configuration, AMIE rules, intake/enrichment/routing and BE screens; reconcile and extend. This two-week engineering window is not approval for a wholesale rewrite.
3. Record actual codepaths, APIs, schema names, installed libraries, permissions and contract differences in the M0 audit; no new incompatible duplicate platform.
4. Deliver small dependency-ordered PRs corresponding to `planning/milestones-stories.md`; report tests, screenshots, migration impact, files, blockers and readiness evidence. Never declare integrations operational without live evidence.
5. Distinguish design/demo from DEV execution, UAT proof, and PROD authority. No production activation without verified entitlement and required release gates.

## Architecture in one paragraph
Unity is a reusable enterprise platform. AMIE evaluates business rules, performs initial request validation/enrichment and selects workflow definitions for BOB, and evaluates pinned rules during workflow or capability execution. BOB owns all durable workflow token/event/time/human-task orchestration and dispatches approved versioned operations to department-owned capability services using central Kafka commands or bounded embedded recipes. The SDK makes typed operation registration and schema-driven BE composition easy across languages. The BE Blazor site controls human-facing workflow Create, Execute, Execute-Lead and Read, plus capability Register/Configure and approval/release functions. External APIs authenticate Unity service identities via approved channels (often Apigee), not every end user. SQL Server organizes platform objects in lowercase `uty_` schemas with component ownership and version pinning.

## Critical decisions
- **One engine, two execution profiles:** shared BPMN interpreter, central durable BOB and approved local embedded host. Avoid competing orchestration in every microservice.
- **Three workflow/operation levels:** L1 enterprise business workflow; L2 bounded capability-owned technical workflow; L3 atomic approved operation. All categorized and discoverable contextually.
- **BPMN 2.0.2 XML plus DI** is canonical process source; Unity JSON describes typed operation/rule bindings and release metadata. An interactive mock JSON export does NOT count as BPMN XML export.
- **Phase 1 expanded executable subset:** start/end, service tasks, business-rule tasks, exclusive gateways, call activities/subprocesses, sequential multi-instance, durable Kafka wait, parallel split/join, intermediate timer catch, interrupting timer boundary, interrupting error boundary, and a minimal durable human-task/approval contract.
- **Full BPMN modeling direction:** all standard BPMN 2.0 elements visible behind experimental mode where not supported; draft save/import/export always allowed if XML is valid and preserved; execution only after element, environment and workflow approval and full validation.
- **Approval classification plus stage:** Experimental / NonProd / Approved, each independently InDev / Testing / Verified / ReleaseReady; defined on each version, not automatically inherited by children. Environment activation is separate.
- **Production:** required ServiceNow change ID (presence only for initial implementation), authorized approver/operator, immutable package and trusted release verification. File-import flow first in DEV/UAT; production upload disabled until mandatory trust mechanism exists. No developer-to-PROD direct publish.
- **Identity:** work with Matthew's current standalone auth/group approach now; Channel Secure SAML SSO and entitlement integration is a pre-go-live dependency. No external department should administer Unity individual workflow users to allow capability use.
- **Three environments only:** DEV, UAT, PROD. Do not invent a separate TEST environment.
- **AMIE intake flow:** retain for initial delivery and document a later review of orchestration-boundary refinements. Dedicated questions for Matthew remain outside both Ask documents.
- **Enterprise integrations:** Channel Secure, Apigee, Splunk, AutoSys, NAS and cron are milestone/Jira dependencies; verify existing work before creating duplicate jobs.

## Reading order
1. `docs/architecture/01-PLATFORM-CATALOG-BOUNDARIES.md` through `08-RELEASE-EXPERIMENTAL-PROMOTION.md`
2. `docs/ux/09-BLAZOR-SHELL-CATALOG.md` through `13-RUN-MONITOR-RELEASE-WIREFRAMES.md`
3. `docs/contracts/14-EVENTS-APIS-AND-BINDINGS.md`; `docs/testing/15-ACCEPTANCE-REGRESSION.md`; `docs/workflows/16-PRACTICAL-EXAMPLES.md`
4. `docs/guides/17-ADMIN-USER-GUIDES.md`, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`, and `planning/milestones-stories.md`
5. `planning/19-SOURCE-AND-DECISION-REGISTER.md`; `wireframes/Unity_v2_0_Concept_Blazor.html`
6. Internal-only `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` (excluded from Ask)

## Delivery formats
Every normative source Markdown file stays separately navigable; `ASK-MODE-HANDOFF.md` and `DEVIN-ASK.md` are byte-identical flattened documents assembled from these source Markdown files. No source is summarized; file-boundary delimiters are included. The internal Matthew review is deliberately not in either Ask document. `manifest.json` lists hashes and exclusions.

## Definitive source hierarchy and paths
1. **Current authoritative material:** This `00-START-HERE.md`, `INDEX.md`, `START-DEVIN.md`, the eight current `docs/architecture/*` files, five `docs/ux/*` files, current contracts/testing/guides/workflows, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`, and `planning/milestones-stories.md`.
2. **Detailed implementation references:** Retained `docs/ui/`, `docs/sdk/`, `docs/contracts/` legacy names, `docs/workflows/` legacy names, `jobs/JOB-*`, `jobs/bpmn/*` and old diagram text, each marked with a v2.1 precedence notice. Use these for exact click/test cases **after** the current decisions; do not recreate already verified code.
3. **Original evidence:** `reference-archive/v1.1-complete-original/` contains the literal 262 original files including historical archives, image and diagram assets. No instructions there override current v2.1.
4. **Internal review:** `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` is for Matthew only and **excluded from both Ask compilations**, as requested.
5. **Ask Mode:** `ASK-MODE-HANDOFF.md` and `DEVIN-ASK.md` contain identical concatenated unabridged text of all *active* `.md` documents (including amended v1.1 detail docs); the full historical archive is excluded to prevent superseded instructions and a 6 MB third-party API reference from overrunning paste limits.

## Single-package instruction
**Distribute only `WF_Unity_DEVIN_TEAM_COMPLETE_v2.1_2026-11-15.zip`.** Prior source ZIPs and v2.0 draft should not be separately assigned to Devin. Use `planning/milestones-stories.md` to hand Megan the milestone grouping; Matthew's questions are deliberately separate.

<!-- END SOURCE 001: 00-START-HERE.md -->

---

<!-- BEGIN SOURCE 002: INDEX.md -->

# WF Unity v2.1 — Single Current Handoff Index

**Hand only this complete ZIP to Devin and the team.** It includes the original Complete v1.1 material plus modern v2.1 canonical decisions. No supplemental ZIP is required.

## Step 1 — Read before starting
- `00-START-HERE.md` — authority, approved decisions, source precedence.
- `START-DEVIN.md` — first assignment and PR protocol.
- `planning/milestones-stories.md` — Megan milestones, exactly mapped Jira stories, completion gates.
- `planning/19-SOURCE-AND-DECISION-REGISTER.md` — what has been verified, what remains unverified.
- `planning/20-COMPLETE-MERGE-VERIFICATION.md` — source archive comparison and packaging.
- `planning/21-LEGACY-CROSSWALK.md` — how to use original work packets without conflicting with v2.1.

## Step 2 — Current authoritative architecture and contracts
- `docs/architecture/01-PLATFORM-CATALOG-BOUNDARIES.md`
- `docs/architecture/02-CAPABILITY-SDK-REGISTRY.md`
- `docs/architecture/03-BOB-BPMN-RUNTIME.md`
- `docs/architecture/04-AMIE-APPROVAL-AND-INTAKE.md`
- `docs/architecture/05-SECURITY-ENTITLEMENTS.md`
- `docs/architecture/06-SQL-VERSIONED-ENTITIES.md`
- `docs/architecture/07-ENTERPRISE-INTEGRATION-READINESS.md`
- `docs/architecture/08-RELEASE-EXPERIMENTAL-PROMOTION.md`
- `docs/contracts/14-EVENTS-APIS-AND-BINDINGS.md`

## Step 3 — Blazor and workflows
- `docs/ux/09-BLAZOR-SHELL-CATALOG.md` through `13-RUN-MONITOR-RELEASE-WIREFRAMES.md`.
- `docs/guides/17-ADMIN-USER-GUIDES.md` — user setup instructions.
- `docs/workflows/16-PRACTICAL-EXAMPLES.md` — Phase 1 and deferred BPMN scenarios.
- `docs/testing/15-ACCEPTANCE-REGRESSION.md` — required proof.
- `wireframes/Unity_v2_0_Concept_Blazor.html` — updated concept mock, NOT a live Blazor application.
- `wireframes/Unity_BPMN_Configurator_Clickable_v1.1.html`, `wireframes/screenshots/*`, `previews/*` — original visual references, not live runtime proof.

## Step 4 — Implementation packets, crosswalk and Jira
- `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` — CURRENT dependency-ordered implementation sequence.
- `jobs/JOB-*` and `jobs/bpmn/*` — detailed original tasks retained with v2.1 precedence banners.
- `planning/milestones-stories.md` — milestone-linked story definitions and gates.
- `planning/21-LEGACY-CROSSWALK.md` — translation of old job IDs to current milestones and authoritative docs.

## Step 5 — Alternative Devin Ask Mode
- `ASK-MODE-HANDOFF.md` — one complete flattened CURRENT instructional Markdown document.
- `DEVIN-ASK.md` — byte-identical alias of the same content.
- The Matthew questions file remains outside Ask content by express decision.
- `reference-archive/` is deliberately not copied into Ask: original source, histories, third-party API text and skills are archival evidence and older directives must not override current design.

## Step 6 — Internal review only
- `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` — circulate for Matthew's independent approve/tweak/reject review; deferred refactor is NOT an immediate work requirement.

## Non-negotiable scope summary
One shared BOB engine central/embedded. AMIE intake preserved initially. Capability service API access separate from BE user workflows/groups. Full BPMN 2.0 modeling with experimental flags, expanded Phase 1 executable semantics. DEV/UAT/PROD only. Channel Secure and required enterprise integration work tracked prior to go-live. Production trusted artifact and authorization before activation. Every Jira story belongs to one milestone; no claims of real completion without repository evidence.

<!-- END SOURCE 002: INDEX.md -->

---

<!-- BEGIN SOURCE 003: START-DEVIN.md -->

# Devin Start Prompt — WF Unity v2.1 Definitive Complete Handoff

You are working on an existing enterprise Unity implementation, NOT creating a new greenfield BOB/AMIE/BE architecture. Read `00-START-HERE.md`, `INDEX.md`, the master architecture/UX/contracts/testing documents and `planning/milestones-stories.md`, then read repository `AGENTS.md` and actual existing code. Source paths, classes, UI routes, Jira keys and API examples in handoff are **proposals** to reconcile rather than claims of verified implementation.

## First PR: M0 read-only reconciliation
Identify actual AMIE intake/enrichment/routing, BOB compiler/host/execution state, existing Matthew auth/groups and rule pages, SDK operation manifest/register, central Kafka/outbox, Blazor BE pages, existing SQL Server `DbContext`/migration history, producer/consumer schemas, environments and current tests. Capture exact `/Project/Path/File.cs` references. Verify live work vs prototypes, licensing/approved SDK packages, and cross-language contracts. Both original v1.1 ZIPs are now available and source-preserved. Read current v2.1 before detailed references; do not mistakenly follow original v1.1 scope where superseded. Do not create duplicate interfaces or rewrite functioning AMIE intake for first pilot.

## Execute dependency-ordered milestones
M0 Audit -> M1 Catalog/SDK -> M2 AMIE/group/human approval -> M3 Expanded BPMN shared runtime -> M4 Blazor workflow/admin/screens -> M5 Enterprise integration and DEV/UAT promotion -> M6 Pilot and UAT. Use `planning/milestones-stories.md`: every story has one milestone; create links/parents in Jira but do not invent existing issue IDs or claim real ticket completion. Use detailed `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` as engineering task breakdown.

## Non-negotiables
Preserve BPMN XML+DI; feature visibility != runtime support; experimental workflow can be saved/imported/exported without publishing; implemented experimental handler in DEV only with policy; PROD cannot execute experimental; actual PROD import needs trusted artifact verification and nonempty ServiceNow change ID plus authorized release; PROD Channel Secure SAML+entitlements is required before go-live. Existing standalone auth and groups are reused during development. Human workflow entitlements are separate from technical capability service-account API grants. Shared interpreter avoids duplicated enterprise orchestration in capability microservices. AMIE policies are decisions; BOB persists workflow/token/human-task state. Avoid fabricated enterprise integrations and unapproved production side effects. No secrets in artifacts, Kafka or logs.

## Every PR report
Milestone + story IDs; real repository paths; interfaces/migrations changed; behavior before/after; compatibility and rollback; tests and actual outputs; negative security tests; screens/user-guide changes; external requirements and blockers; evidence level and source/mock classification. No production-ready status without verified Channel Secure, Apigee, Splunk and applicable enterprise release requirements.

`docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` is a separate internal review file intentionally excluded from both Devin Ask compilations. Do not silently treat its unapproved screen suggestions as committed code changes.

## Reconciled detailed implementation references
Retained v1.1 `jobs/JOB-*`, `jobs/bpmn/*` and `docs/ui/*` contain extensive test and screen scripts; apply them only after reading the v2.1 precedence notice at their top and matching to `planning/21-LEGACY-CROSSWALK.md`. Original unchanged files live under `reference-archive/` for forensic comparison.

## Only delivery artifact
This entire folder comes from the single definitive ZIP. Do not request the older Complete/Current ZIPs, as all 262 original Complete files and the modern canonical set are already present.

<!-- END SOURCE 003: START-DEVIN.md -->

---

<!-- BEGIN SOURCE 004: TEAM-HANDOFF-README.md -->

# Give the team ONE file: WF Unity v2.1 Complete

The delivery is the ZIP `WF_Unity_DEVIN_TEAM_COMPLETE_v2.1_2026-11-15.zip`, **not** the old v1.1 Complete/Current ZIPs and not the earlier partial v2.0 ZIP.

**Devin implementing code:** open `INDEX.md` then `START-DEVIN.md`. Begin with M0 read-only repo audit. The modern architecture and jobs are authoritative; the original 61 detailed `jobs/` files and full original v1.1 source tree are included to preserve all instructions and visuals, but older language is subordinate to current decisions.

**Devin Ask Mode:** paste `ASK-MODE-HANDOFF.md` (or `DEVIN-ASK.md`, identical). The contents are all CURRENT annotated Markdown documents, not a summary. Only archived historical sources and Matthew's internal review are excluded by design. It may be long; the file uses explicit source delimiters to support copying/pasting in the tool's supported context size.

**Megan:** review `planning/milestones-stories.md` for M0–M6 milestone descriptions, story links and acceptance gates; all story keys are proposals until added to Jira. No fabricated progress.

**Matthew:** use `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` for the proposed AMIE interface review. This file is separate and not in Ask Mode.

**UI team:** modern detailed `docs/ux/09...13` and interactive v2.0 concept mock; v1.1 click catalogs and screenshots remain available for source review. Wireframes are not proof of implemented APIs.

**Production release:** DEV/UAT/PROD, signed/trusted artifact requirement, mandatory nonempty ServiceNow reference initially, no ticket status API integration yet, secure environment activation, Channel Secure and required enterprise integrations verified before go-live. Unverified PROD blockers may never be bypassed with only a placeholder ID.

<!-- END SOURCE 004: TEAM-HANDOFF-README.md -->

---

<!-- BEGIN SOURCE 005: planning/milestones-stories.md -->

# `milestones-stories.md` — Megan Milestones and Jira-Ready Work Breakdown
**Purpose:** waterfall-style milestone reporting with detailed, explicitly linked Jira stories. Existing Jira issue keys are unknown and may be replaced; proposed `WF-Mx-yy` identifiers are planning placeholders only. Do not infer story completion. One accepted story counts to its milestone, but milestone itself requires gate acceptance.
## Reporting rules
- Every story has exactly one owning milestone and may depend on other milestones; Jira AI should create link relationships and milestone grouping.
- Suggested Jira types: Milestone/epic/feature as supported by Wells Fargo project; Story tasks linked via native parent or configured milestone field. Keep implementation evidence and blocked dependencies visible.
- Milestone progress = accepted stories / total stories, plus gate PASS/FAIL; counts not supplied as real progress. Track blocked, underway, accepted using actual Jira statuses.
- A placeholder for an integration does not mean that integration is missing: M0 maps preexisting implementations/stories before new ones are created.
- Show milestone dates/target teams as TBD pending actual team planning rather than fabricate delivery dates. Two-week goal prioritizes pilot, not completion guarantees for unknown enterprise integrations.

## M0 — Repository and architecture reconciliation
**Objective:** Inventory existing BOB, AMIE, BE, SDK and deployed interfaces; baseline accepted before rework.
**Milestone acceptance gate:** Approved audit, actual paths/test baseline, freeze critical contracts, ranked blockers; no duplicate rebuild.
**Story count:** 4 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M0-01` | Source inventory and source-of-truth contract map | Locate real files, services, migrations, topics, provider configs; mark mock vs verified. |
| `WF-M0-02` | Current AMIE/BOB and auth flow assessment | Demonstrate Matthew existing login/group/intake/rule routing and any durable orchestration overlaps. |
| `WF-M0-03` | BPMN and SDK gap matrix | Compare expanded Phase 1 element semantics, handlers, and SDK contracts to existing code/tests. |
| `WF-M0-04` | Environment and integration ownership register | Confirm DEV/UAT/PROD, owners, existing Jira, missing Channel Secure/Apigee/Splunk/AutoSys/NAS/cron details. |

### WF-M0-01 — Source inventory and source-of-truth contract map
**Milestone:** M0. **Story objective / scope:** Locate real files, services, migrations, topics, provider configs; mark mock vs verified.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M0-02 — Current AMIE/BOB and auth flow assessment
**Milestone:** M0. **Story objective / scope:** Demonstrate Matthew existing login/group/intake/rule routing and any durable orchestration overlaps.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M0-03 — BPMN and SDK gap matrix
**Milestone:** M0. **Story objective / scope:** Compare expanded Phase 1 element semantics, handlers, and SDK contracts to existing code/tests.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M0-04 — Environment and integration ownership register
**Milestone:** M0. **Story objective / scope:** Confirm DEV/UAT/PROD, owners, existing Jira, missing Channel Secure/Apigee/Splunk/AutoSys/NAS/cron details.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M1 — Catalog, SDK and capability governance
**Objective:** Working context-specific catalog with capability onboarding and versioning.
**Milestone acceptance gate:** Approved operations visible only when enabled; two workflows reuse handler; category move retains identity and access.
**Story count:** 6 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M1-01` | Application and capability catalog taxonomy | Application collections Onboarding/Hygiene/Governance; capability owns Operations and L2 Workflows; stable IDs. |
| `WF-M1-02` | Scoped `uty_` SQL migration plan | Align existing DbContexts; implement catalog/capability version associations non-destructively. |
| `WF-M1-03` | SDK handler manifest registration | Compile-time typed operations, deployment-trusted manifest, approve and activate separately. |
| `WF-M1-04` | Capability Register/Configure policy | Only entitled admin group can register/configure capabilities; no external per-user API assignments. |
| `WF-M1-05` | Version maturity and status controls | Experimental/NonProd/Approved + InDev/Testing/Verified/ReleaseReady, transitions audited. |
| `WF-M1-06` | Cross-language and Apigee capability contract | Stable schema/REST/Kafka/MCP policy surface; no invented enterprise endpoint. |

### WF-M1-01 — Application and capability catalog taxonomy
**Milestone:** M1. **Story objective / scope:** Application collections Onboarding/Hygiene/Governance; capability owns Operations and L2 Workflows; stable IDs.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-02 — Scoped `uty_` SQL migration plan
**Milestone:** M1. **Story objective / scope:** Align existing DbContexts; implement catalog/capability version associations non-destructively.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-03 — SDK handler manifest registration
**Milestone:** M1. **Story objective / scope:** Compile-time typed operations, deployment-trusted manifest, approve and activate separately.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-04 — Capability Register/Configure policy
**Milestone:** M1. **Story objective / scope:** Only entitled admin group can register/configure capabilities; no external per-user API assignments.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-05 — Version maturity and status controls
**Milestone:** M1. **Story objective / scope:** Experimental/NonProd/Approved + InDev/Testing/Verified/ReleaseReady, transitions audited.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-06 — Cross-language and Apigee capability contract
**Milestone:** M1. **Story objective / scope:** Stable schema/REST/Kafka/MCP policy surface; no invented enterprise endpoint.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M2 — AMIE bindings, groups, and durable approvals
**Objective:** Preserved current AMIE intake plus typed decision links, workflow access and human tasks.
**Milestone acceptance gate:** End-to-end approved rule selection, group denial, multi-stage human approval, no regression of Matthew functionality.
**Story count:** 6 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M2-01` | Use Matthew existing local user/group mechanism | Reconcile existing group and rule configuration; avoid duplicate auth stack. |
| `WF-M2-02` | Workflow resource entitlements | Read/Execute/Execute-Lead/Create with multiple groups, effective access and group-report scoping. |
| `WF-M2-03` | Typed AMIE intake -> BOB binding | Preserve enrich/classify/select workflow, add versioned correlation and BOB admission checks. |
| `WF-M2-04` | BOB and embedded capability AMIE adapters | Pinned facts/results, no independent long-running orchestration created. |
| `WF-M2-05` | Multi-level approval policy + BOB human tasks | Sequential stages, backup group, any-one/all, durable wait, authorized decisions. |
| `WF-M2-06` | AMIE decision trace and review feedback | Correlated printable trace; Matthew screen candidates can be selected/rejected individually. |

### WF-M2-01 — Use Matthew existing local user/group mechanism
**Milestone:** M2. **Story objective / scope:** Reconcile existing group and rule configuration; avoid duplicate auth stack.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-02 — Workflow resource entitlements
**Milestone:** M2. **Story objective / scope:** Read/Execute/Execute-Lead/Create with multiple groups, effective access and group-report scoping.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-03 — Typed AMIE intake -> BOB binding
**Milestone:** M2. **Story objective / scope:** Preserve enrich/classify/select workflow, add versioned correlation and BOB admission checks.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-04 — BOB and embedded capability AMIE adapters
**Milestone:** M2. **Story objective / scope:** Pinned facts/results, no independent long-running orchestration created.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-05 — Multi-level approval policy + BOB human tasks
**Milestone:** M2. **Story objective / scope:** Sequential stages, backup group, any-one/all, durable wait, authorized decisions.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-06 — AMIE decision trace and review feedback
**Milestone:** M2. **Story objective / scope:** Correlated printable trace; Matthew screen candidates can be selected/rejected individually.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M3 — Expanded BPMN 2.0 Phase 1 engine
**Objective:** Concurrent, timer-driven, error-aware durable BOB execution with common central/embedded semantics.
**Milestone acceptance gate:** BPMN regression matrix and crash/race failure-injection gate passes with evidence.
**Story count:** 7 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M3-01` | Canonical BPMN XML+DI compiler and support registry | Preserve IDs/geometry; separate modeling/import/compiler/execution feature support. |
| `WF-M3-02` | Token scope, atomic branch and parallel join | Multi-token fork/join, optimistic concurrency and deadlock validation. |
| `WF-M3-03` | Durable timer scheduler and intermediate timer | One-shot date/duration, crash restart and multi-replica claim tests. |
| `WF-M3-04` | Interrupting timer boundary and reconciliation | Atomic race vs activity completion; reconcile late external outcome. |
| `WF-M3-05` | Typed error boundary and propagation | Explicit BPMN codes, nested scope handling, unhandled failure. |
| `WF-M3-06` | Kafka wait, outbox/inbox, pause/cancel/restart proof | Exactly-once logical advancement under at-least-once transport. |
| `WF-M3-07` | Common interpreter host compatibility | Central/embedded fixtures and reject non-durable embedded timers/waits. |

### WF-M3-01 — Canonical BPMN XML+DI compiler and support registry
**Milestone:** M3. **Story objective / scope:** Preserve IDs/geometry; separate modeling/import/compiler/execution feature support.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-02 — Token scope, atomic branch and parallel join
**Milestone:** M3. **Story objective / scope:** Multi-token fork/join, optimistic concurrency and deadlock validation.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-03 — Durable timer scheduler and intermediate timer
**Milestone:** M3. **Story objective / scope:** One-shot date/duration, crash restart and multi-replica claim tests.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-04 — Interrupting timer boundary and reconciliation
**Milestone:** M3. **Story objective / scope:** Atomic race vs activity completion; reconcile late external outcome.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-05 — Typed error boundary and propagation
**Milestone:** M3. **Story objective / scope:** Explicit BPMN codes, nested scope handling, unhandled failure.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-06 — Kafka wait, outbox/inbox, pause/cancel/restart proof
**Milestone:** M3. **Story objective / scope:** Exactly-once logical advancement under at-least-once transport.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-07 — Common interpreter host compatibility
**Milestone:** M3. **Story objective / scope:** Central/embedded fixtures and reject non-durable embedded timers/waits.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M4 — Blazor user experience and administrative wireframes
**Objective:** Smooth contextual setup from application/capability into BPMN/AMIE/permissions and running status.
**Milestone acceptance gate:** BE flow usable end-to-end in DEV and action registry behavior verified; no inert production controls.
**Story count:** 6 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M4-01` | Unified Blazor shell and catalog search | Context, folders, filters, details, version/group permission overview. |
| `WF-M4-02` | Capability administration and status workflow | Register, Configure, Development, Validation, Approval, activation tabs and status badges. |
| `WF-M4-03` | BPMN designer with full experimental palette | Save XML+DI; per-node inspector, flag, validation and experimental warnings. |
| `WF-M4-04` | AMIE candidate screens for Matthew | Rule catalog, approval policy, group assign, decision trace; adopt only approved changes. |
| `WF-M4-05` | Work queue, run monitor, group reports | Human task inbox, parallel branch overlay, timer/error, lead group-filtered report. |
| `WF-M4-06` | Administrator user-guide and UI click evidence | Stepwise setup, empty/error states, API role tests, screenshots. |

### WF-M4-01 — Unified Blazor shell and catalog search
**Milestone:** M4. **Story objective / scope:** Context, folders, filters, details, version/group permission overview.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-02 — Capability administration and status workflow
**Milestone:** M4. **Story objective / scope:** Register, Configure, Development, Validation, Approval, activation tabs and status badges.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-03 — BPMN designer with full experimental palette
**Milestone:** M4. **Story objective / scope:** Save XML+DI; per-node inspector, flag, validation and experimental warnings.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-04 — AMIE candidate screens for Matthew
**Milestone:** M4. **Story objective / scope:** Rule catalog, approval policy, group assign, decision trace; adopt only approved changes.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-05 — Work queue, run monitor, group reports
**Milestone:** M4. **Story objective / scope:** Human task inbox, parallel branch overlay, timer/error, lead group-filtered report.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-06 — Administrator user-guide and UI click evidence
**Milestone:** M4. **Story objective / scope:** Stepwise setup, empty/error states, API role tests, screenshots.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M5 — Enterprise integrations and release controls
**Objective:** Bridge existing integrations, identify outstanding external dependencies; test package import through UAT.
**Milestone acceptance gate:** Per integration existing/partial/awaiting/verified recorded; DEV/UAT import tests; PROD blocked until SSO/trust requirements satisfied.
**Story count:** 9 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M5-01` | INT-CHSEC Channel Secure SAML + entitlements | Audit existing auth seam; integrate/verify before PROD go-live; requirements pending. |
| `WF-M5-02` | INT-APIGEE gateway onboarding and service auth | Confirm existing API product/scope access; test allow/deny in approved environment. |
| `WF-M5-03` | INT-SPLUNK structured logging and audit | Correlated safe telemetry, redaction, forwarding and query proof. |
| `WF-M5-04` | INT-AUTOSYS trigger adapter | Schedule-to-BOB trigger schema, replay/authorization, existing code first. |
| `WF-M5-05` | INT-NAS data capability integration | Owned EF/data APIs, schema/row staging and permissions, no direct cross-service DB. |
| `WF-M5-06` | INT-CRON scheduler integration | Approved schedule ownership, timer distinction and audit. |
| `WF-M5-07` | BPMN XML + Unity package import/export | DEV/UAT dry run, test malformed/missing dependencies; no mock-only JSON export. |
| `WF-M5-08` | Release review, ServiceNow reference, trust mechanism | Mandatory PROD change ID presence, signature/approved trust, group and environment validation. |
| `WF-M5-09` | Activation and rollback controls | PROD import != activate; approved operator and immutable digest; rollback recorded. |

### WF-M5-01 — INT-CHSEC Channel Secure SAML + entitlements
**Milestone:** M5. **Story objective / scope:** Audit existing auth seam; integrate/verify before PROD go-live; requirements pending.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-02 — INT-APIGEE gateway onboarding and service auth
**Milestone:** M5. **Story objective / scope:** Confirm existing API product/scope access; test allow/deny in approved environment.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-03 — INT-SPLUNK structured logging and audit
**Milestone:** M5. **Story objective / scope:** Correlated safe telemetry, redaction, forwarding and query proof.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-04 — INT-AUTOSYS trigger adapter
**Milestone:** M5. **Story objective / scope:** Schedule-to-BOB trigger schema, replay/authorization, existing code first.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-05 — INT-NAS data capability integration
**Milestone:** M5. **Story objective / scope:** Owned EF/data APIs, schema/row staging and permissions, no direct cross-service DB.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-06 — INT-CRON scheduler integration
**Milestone:** M5. **Story objective / scope:** Approved schedule ownership, timer distinction and audit.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-07 — BPMN XML + Unity package import/export
**Milestone:** M5. **Story objective / scope:** DEV/UAT dry run, test malformed/missing dependencies; no mock-only JSON export.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-08 — Release review, ServiceNow reference, trust mechanism
**Milestone:** M5. **Story objective / scope:** Mandatory PROD change ID presence, signature/approved trust, group and environment validation.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-09 — Activation and rollback controls
**Milestone:** M5. **Story objective / scope:** PROD import != activate; approved operator and immutable digest; rollback recorded.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M6 — Integrated demonstration, UAT and production readiness
**Objective:** Prove enterprise orchestration value and document remaining go-live blockers.
**Milestone acceptance gate:** Jira stories accepted + milestone conformance/UAT evidence; no unsupported production-ready claim.
**Story count:** 5 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M6-01` | CyberArk first end-to-end pilot | BE -> AMIE -> BOB -> Kafka -> embedded capability -> outcome/report, with safe fixtures. |
| `WF-M6-02` | Parallel, timer, error, approval demo | Multi-branch, boundary events, multi-level approval and crash recovery. |
| `WF-M6-03` | Second unrelated workflow reuse proof | Use same shared SDK, BOB, AMIE core without workload-specific changes. |
| `WF-M6-04` | Security UAT and operational failure injection | Direct API deny, group report scope, launch/retry/reconcile, log/audit verification. |
| `WF-M6-05` | Production readiness and release evidence review | Verify Channel Secure, Apigee, Splunk, scheduled sources, NAS and signature readiness; outstanding blockers visible. |

### WF-M6-01 — CyberArk first end-to-end pilot
**Milestone:** M6. **Story objective / scope:** BE -> AMIE -> BOB -> Kafka -> embedded capability -> outcome/report, with safe fixtures.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M6-02 — Parallel, timer, error, approval demo
**Milestone:** M6. **Story objective / scope:** Multi-branch, boundary events, multi-level approval and crash recovery.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M6-03 — Second unrelated workflow reuse proof
**Milestone:** M6. **Story objective / scope:** Use same shared SDK, BOB, AMIE core without workload-specific changes.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M6-04 — Security UAT and operational failure injection
**Milestone:** M6. **Story objective / scope:** Direct API deny, group report scope, launch/retry/reconcile, log/audit verification.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M6-05 — Production readiness and release evidence review
**Milestone:** M6. **Story objective / scope:** Verify Channel Secure, Apigee, Splunk, scheduled sources, NAS and signature readiness; outstanding blockers visible.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## Megan reporting view
| Milestone | Total planning stories | Accepted from Jira | Blocked | Milestone gate |
|---|---:|---:|---:|---|
| M0 — Repository and architecture reconciliation | 4 | TBD | TBD | Not yet verified |
| M1 — Catalog, SDK and capability governance | 6 | TBD | TBD | Not yet verified |
| M2 — AMIE bindings, groups, and durable approvals | 6 | TBD | TBD | Not yet verified |
| M3 — Expanded BPMN 2.0 Phase 1 engine | 7 | TBD | TBD | Not yet verified |
| M4 — Blazor user experience and administrative wireframes | 6 | TBD | TBD | Not yet verified |
| M5 — Enterprise integrations and release controls | 9 | TBD | TBD | Not yet verified |
| M6 — Integrated demonstration, UAT and production readiness | 5 | TBD | TBD | Not yet verified |

## Suggested import to Jira
Assign a milestone field or parent epic to every story using the Milestone column. Maintain parent/child relationships, standard completion criteria and cross-milestone dependency links. Existing tickets may be deleted/recreated by project owner; avoid claiming any ticket exists before Jira confirms it.

<!-- END SOURCE 005: planning/milestones-stories.md -->

---

<!-- BEGIN SOURCE 006: planning/19-SOURCE-AND-DECISION-REGISTER.md -->

# Planning 19 — Provenance, Adopted Decisions, Remaining Questions and Source Limitations

## Status and provenance
This is the **v2.1 reconciled master handoff**, based on approved conversation decisions, v2.0 current specifications, and the complete original v1.1 archives supplied on November 15, 2026. **Both v1.1 source ZIP archives were inspected and reconciled.** No repository deployment, real Jira completion, signed bank release, or enterprise integration is asserted. Source audit remains mandatory.

## Accessible historic sources reviewed or incorporated
- `Unity_Capability_SDK_Specification_v1.0.md` — typed operation contracts, local DI vs trusted registry publication, Kafka, AMIE/BOB embedded adapters and API regression concepts.
- `Unity_BE_Wireframe_Screens_v1.0.md` — existing detailed BE shell, screen-by-screen controls and negative tests.
- `Unity_BE_Click_Action_Contracts_v1.0.md` — proposed click/API behavior; route names remain illustrative until code audit.
- `18-FULL-BPMN-DESIGNER-UI-CONFIGURATION-AND-TEST-RUNBOOK.md` — detailed source workflow walkthrough, XML+DI validation, DCMS/NAS/AutoSys examples.
- `DEVIN-BPMN-END-TO-END-START-PROMPT-v1.1.md`, `INDEX.md` and `DIAGRAMS.md` — prior v1.1 handoff structure, dependency jobs, release promotion and SDK onboarding flow.
- Conversation-uploaded `Pasted text.txt` — BOB Phase 1 expanded parallel/timer/error boundary dependencies and regression requirements.
- Earlier conversation-generated WF Unity BOB November 15 update (`WF_Unity_BOB_Handoff_2026-11-15`) and Matthew review draft.

**Source preservation verification:** The original `Unity_DEVIN_BPMN_EndToEnd_Complete_v1.1.zip` contains 262 files and the original `Unity_DEVIN_BPMN_EndToEnd_Current_v1.1.zip` contains 224 files. All 224 file names occur in Complete; 223 identical byte-for-byte, one `MANIFEST.sha256` differs because package content differs; Complete adds 38 historical/preview/reference files. The complete 262-file tree is preserved byte-for-byte under `reference-archive/v1.1-complete-original/` and file-level hashes can be checked. Separate retained active detailed `.md` jobs/docs are annotated at top with v2.1 precedence rules; the original v1.1 historical versions are not the current implementation authority. All current Markdown normative/detailed documents, except the deliberately excluded Matthew-only review file, are included verbatim in Ask Mode. The 6.25 MB prior workflowengine API reference, other legacy history documents and skills live in the archive and are excluded from Ask because they are reference evidence, not current implementation instructions.

## Explicit decisions superseding earlier draft language
| Topic | Final decision |
|---|---|
| Package | Full v2.1 complete package, not supplemental; separate `.md` and two flattened Ask docs; separate Matthew review excluded |
| Environments | DEV (non-prod), UAT (pre-prod), PROD only |
| Group login | Reuse Matthew standalone implementation for development; Channel Secure SAML/entitlements before go-live |
| External providers | Authenticate Unity service accounts, often via Apigee; no per-human external department grants |
| Human permissions | Per workflow Read / Execute / Execute-Lead / Create; Register/Configure for capability admin separately |
| AMIE intake | Retain classify/enrich/select/publish to BOB for initial pilot; typed boundary, future correction documented |
| Approval workflow | AMIE policy + BOB durable human tasks + BE Blazor approvals, multi-stage/backup |
| SQL schemas | All lowercase `uty_` prefixes, one approved SQL database per environment, separate schema/context ownership |
| Workflow catalog | Application functional collections and capability-own L2 workflows; stable associations and versions |
| BPMN runtime | Expanded Phase 1 parallel/timer/error and minimum human tasks; full modeling via experimental flagged save/import |
| Status | Experimental / NonProd / Approved with InDev / Testing / Verified / ReleaseReady separately versioned; activation separate |
| PROD release | Mandatory ServiceNow change ID presence initially, not API-verified; trusted package verification needed before PROD activation |
| Enterprise integrations | Channel Secure, Apigee, Splunk, AutoSys, NAS, cron and others in M5 and go-live blockers; verify existing status |
| Jira | `milestones-stories.md` has milestone-owned stories for Megan; old real tickets can be recreated/mapped by user |

## Open verification questions (M0 only, not unresolved product-direction votes)
1. Exact paths/classes and working behavior of current AMIE, BOB, capability SDK, BE and standalone group subsystem.
2. Approved standard API/EF naming and existing `uty_` migrations, support for hosted BPMN engine and licensed third-party modeling libraries.
3. Available DEV/UAT Channel Secure and Apigee contacts, gateway products, security controls, Splunk output format, AutoSys trigger, NAS contracts, cron conventions.
4. Trusted signer/enterprise release mechanism for PROD; actual ticket template and separation-of-duty policy.
5. Which existing Jira stories already cover M0-M6 integration placeholders.
6. Actual initial pilot fixture and necessary production go-live date/criteria.

## Priority / critical path
Source audit and contract freeze -> typed registry + existing auth/rules -> BOB durable execution and approval -> Blazor paths -> integration and DEV/UAT release validation -> UAT end-to-end proof -> PROD go-live gate. The immediate two-week objective is working DEV architecture and demonstrable integration, not an ungrounded guarantee that external bank dependencies will be provisioned.

<!-- END SOURCE 006: planning/19-SOURCE-AND-DECISION-REGISTER.md -->

---

<!-- BEGIN SOURCE 007: planning/20-COMPLETE-MERGE-VERIFICATION.md -->

# Source archive comparison and preservation verification — v2.1

## Originals supplied and inspected

| Source | Files | Uncompressed | Result |
|---|---:|---:|---|
| `Unity_DEVIN_BPMN_EndToEnd_Complete_v1.1.zip` | 262 | 19,915,189 bytes | Entire original tree copied byte-for-byte into `reference-archive/v1.1-complete-original/` |
| `Unity_DEVIN_BPMN_EndToEnd_Current_v1.1.zip` | 224 | 4,864,296 bytes | Every file already represented in Complete, except its own manifest differs |

**Comparison:** 224 same-name entries, 223 byte-identical and 1 different (`MANIFEST.sha256`). Both manifest versions are preserved. Complete adds 38 files, mainly prior versions, previews and third-party reference. The sole differing manifest is separately preserved at `reference-archive/v1.1-current-manifest/MANIFEST.sha256`. No Current-only file names.

**Check:** Source SHA256 Complete `2235d4a4208c8bcae3b693ae6a3f0aadce914a8dbfd93c7b4458daaeabc8de42`; Current `e92e72431d0b18582fb07000e1c0790bb8730d43a8f51fd2ffc959742aebf3ef`.

## Active documents reconciled
- `144` original detailed docs/jobs/diagram files copied to their original relative locations as annotated reference. Their v2.1 header identifies current instructions that take precedence.
- `27` current v2.0 source files adopted, then corrected where v1.1 source preservation had previously been unverified.
- Original source material preserved exactly under archive; updated original text is a non-destructive copy with a preface, **not** a byte-identical original.
- Original screenshot/HTML wireframes remain accessible. Visual simulation does not prove working BPMN XML+DI export or BE integration.
- `docs/architecture/03-BOB-BPMN-RUNTIME.md` is deliberately updated v2.1 content; original v1.1 at `reference-archive/v1.1-complete-original/docs/architecture/03-BOB-BPMN-RUNTIME.md`.

## Source precedence
1. Current approved `00-START-HERE.md`, eight current `docs/architecture`, five `docs/ux`, current contracts/testing/jobs and milestone decisions.
2. Detailed annotated original docs/jobs for test cases and implementation granularity only.
3. Original unchanged source ZIP tree in `reference-archive/`, for historical/technical reference only.

## Explicitly not verified
No user repository, deployed environment, role configuration, live integration, actual Jira story, signing service or UAT acceptance was inspected. Production compatibility remains conditional on the M0 source audit and required enterprise controls. There is no statement of production compliance.

<!-- END SOURCE 007: planning/20-COMPLETE-MERGE-VERIFICATION.md -->

---

<!-- BEGIN SOURCE 008: planning/21-LEGACY-CROSSWALK.md -->

# Original v1.1 Job / Source Crosswalk into v2.1 Milestones

**Rule:** The original job packets are retained so Devin does not lose implementation detail. Each is a **detailed acceptance reference**, not a new Jira story automatically. Create the Jira work once using the current `planning/milestones-stories.md`, map useful details from the old packets, and reconcile with real repository code. Avoid duplicated tickets and do not interpret old P1 deferrals as superseding the expanded Phase 1 execution scope.

| Original detailed packet | Owning v2.1 milestone | Instruction |
|---|---|---|
| `jobs/INDEX.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-00-reconcile-repository.md` | M0 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-01-freeze-contracts.md` | M0 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-02-capability-sdk.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-03-registry-contracts.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-04-amie-adapter.md` | M2 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-05-bpmn-compiler.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-06-bob-hosts.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-07-kafka-sdk.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-08-sql-audit.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-09-be-designer.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-10-be-composition.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-11-input-trigger-staging.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-12-cyberark-operations.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-13-reporting-email.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-14-be-monitor.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-15-rbac-operator.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-16-release-package.md` | M5 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-17-regression-ci.md` | M5 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-18-dcms-e2e.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-19-second-workload.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-20-demo-handoff.md` | M5 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-21-shared-blazor-component-foundation.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-22-workflow-wizard-and-library-lifecycle.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-23-first-party-bpmn-canvas-xml-plus-di.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-24-bpmn-palette-and-node-specific-inspector.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-25-schema-driven-data-binding-and-amie-rule-editor.md` | M2 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-26-triggers-and-input-forms-builder.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-27-compiler-validation-panel-and-dev-test-bench.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-28-workflow-version-review-and-release-wiring.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-29-business-work-queue-and-near-real-time-dashboard.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-30-bpmn-runtime-monitor-controls-and-audit-views.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BOB-37-bpmn-2.0-compiler-shared-runtime-central-embedded-wait.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BOB-38-existing-amie-adapter-and-typed-binding-graph.md` | M2 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/INDEX.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/INT-39-dcms-integrated-ui-to-kafka-to-email-proof.md` | M5 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/QA-40-complete-ui-api-flow-and-second-workload-regression.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-31-operation-registry-and-automatic-be-schema-integration.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-32-nas-ef-core-owned-data-api-integration.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-33-cyberark-dcms-reusable-primitives.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-34-cyberark-guarded-account-delete-operation.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-35-autosys-scheduler-trigger-adapter.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-36-policy-drift-reusable-zip-ini-ef-operations.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/INDEX.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-10-repo-and-contract-seam-audit.md` | M0 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-11-trusted-handler-registration-and-di-sdk.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-12-capability-registry-and-trusted-publication.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-13-existing-amie-adapter-and-rule-metadata.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-14-shared-bob-operation-dispatcher-and-host-modes.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-15-kafka-inbox-outbox-and-command-contracts.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-16-audit,-authorization-and-operational-controls.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-17-capability-service-template-and-reusable-skill-update.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-18-dcms-vertical-slice-plus-second-workload-reuse-proof.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-10-be-shell,-screen-routing-and-role-scoped-api-clients.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-11-capability-catalog,-inspector-and-onboarding-wizard.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-12-application-studio-and-workflow-library-lifecycle.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-13-blazor-bpmn-2.0-canvas-and-typed-operation-inspector.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-14-amie-binding-picker-and-trigger-forms-editor.md` | M2 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-15-business-work-queue-and-bpmn-run-monitor.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-16-operator-controls,-runbooks-and-audit-screens.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-17-environment-release-regression-+-107-control-proof.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |

## Explicit v2.1 changes applied to every original job

1. Channel Secure/SAML/enterprise entitlements and Apigee, Splunk, AutoSys, NAS and cron integrations are early development and go-live dependencies (M5), not optional vague future work.
2. Workflow access (Read/Execute/Execute-Lead/Create) is enforced inside Unity; capability Register/Configure is separate; external departments authenticate only the Unity service account, not individual Unity website users.
3. AMIE existing intake/route/enrichment by Matthew is retained for the initial two-week delivery; do not rewrite it without an agreed later refactor.
4. BPMN expanded Phase 1 includes parallel fork/join, durable intermediate timers, interrupting timer/error boundaries and minimum durable human tasks; compiler must reject unsupported execution semantics.
5. Maintain full-modeling experimental palette, save/import/export XML+DI, and environment-gated execution; do not confuse JSON metadata with executable BPMN XML.
6. `Experimental/NonProd/Approved` classification and `InDev/Testing/Verified/ReleaseReady` stage are independent and versioned; activation per environment is separate.
7. DEV, UAT and PROD only. PROD change ID presence is required without ServiceNow API validation initially; release trust and go-live identity controls still required.
8. v2.1 `planning/milestones-stories.md` controls Jira milestone grouping. Each story must belong to one milestone.
9. All proposed code paths, endpoints and integrations require source audit; do not claim verified implementation from wireframes.

<!-- END SOURCE 008: planning/21-LEGACY-CROSSWALK.md -->

---

<!-- BEGIN SOURCE 009: docs/architecture/01-PLATFORM-CATALOG-BOUNDARIES.md -->

# Architecture 01 — Platform Roles, Workflow Levels, and Navigable Catalog

## Platform authority and ownership
| Responsibility | Owning component | Constraint |
|---|---|---|
| Human website experience | BE Blazor/API | UI hiding alone never authorizes execution |
| Initial intake validation, enrichment, workflow selection | AMIE existing intake | Preserve initial contract; BOB checks selected workflow again |
| Business eligibility, routing, mapping, approval policies | AMIE | Rules return typed decisions, not durable orchestrated side effects |
| Token state, BPMN control flow, timers, waits, human tasks | BOB | One shared interpreter, SQL Server durable state |
| Integration operation code, owning data, API credentials | Capability service | Only registered, versioned operations; service account separate from end-user |
| Command/outcome transport | Kafka | Broker ACK not business success; outbox/inbox required |
| Definitions, versions, approvals, activation | Unity control plane | Component boundaries despite common SQL database |

**Current intake:** AMIE receives inbound requests, evaluates/enriches/classifies, emits typed workflow selection to BOB over the established channel; BOB validates entitlement, definition/version and environmental activation, executes and dispatches capability-specific commands. BOB may request additional AMIE evaluations. Capabilities may use approved local cached AMIE rules through adapters. **Do not rewrite working intake in this immediate pilot.** Separate Matthew review identifies future correction triggers.

## Workflow hierarchy
- **L1 Business/enterprise:** cross-department durable process (Account Onboarding, Hygiene, Governance, Policy Drift, CMDB enrichment). BOB central.
- **L2 Capability-local recipe:** bounded technical multi-step process owned by a capability (CyberArk Validate + Create + Verify). Shared interpreter embedded; no independent durable enterprise orchestrator. Long-running/cross-domain should move to L1.
- **L3 Atomic operation:** approved typed handler (GetAccount, AddAccount, StageBatch, SendEmail) with versioned input/output and side-effect classification; not a separate workflow level of orchestration.

**Owner is not the same as consumer.** A workflow has one primary owner and multiple associations. An Application workspace defaults to its L1 workflows organized by functions; a Capability workspace defaults to its approved operations and owned L2 workflows. A shared library appears only on explicit Browse Shared Library or search.

## Multi-dimensional taxonomy, not one giant directory
| Dimension | Examples | Stable semantics |
|---|---|---|
| Application | PAM, Identity, Data Management | Who is responsible for business domain |
| Functional collection | Onboarding, Hygiene, Governance, Reporting, Policy Drift | Navigation and lookup; editable without re-identifying workflow |
| Capability ownership | CyberArk, NAS, Email, AD | Technical operation and local recipe owner |
| Work type | L1, L2, L3 | Determines intended host and semantics |
| Tags | privileged, bulk, recurring, destructive, reconciliation | Search; not authorization grants |
| Permission groups | Local Unity group references, future enterprise group mappings | Actual authorization independently scoped |
| Maturity/version | Experimental / NonProd / Approved, stage; version | Version pinned; environment activation separate |

## Storage and identity principles
Use stable GUID/opaque IDs and unique functional keys; never bind references to mutable folder names. Immutable published versions, drafts with concurrency revision, version-pinned dependencies. `WorkflowAssociation` maps consumers; `WorkflowFolder` stores configurable parent/ordinal per application or capability; `CatalogTag` and `ResourceCategory` are shared searchable concepts. Cross-domain writes go through owning APIs even when entities share SQL Server.

## Scope and non-goals
A capability is not a per-person entitlement integration for every external department. Its service account is approved by the external department/gateway, and Unity checks user/workflow scope before dispatch. Registry existence is not approval; external service login does not grant workflow visibility. No hardcoded CyberArk, Policy Drift, or DCMS logic in BOB/AMIE core.

## Acceptance
A PAM author sees Onboarding/Hygiene/Governance and only permitted workflows; a CyberArk capability owner sees its own operations/L2 recipes; shared version-pinned recipe is reused by a second unrelated application without code change; moving a catalog folder does not change authorization or old running instances.

<!-- END SOURCE 009: docs/architecture/01-PLATFORM-CATALOG-BOUNDARIES.md -->

---

<!-- BEGIN SOURCE 010: docs/architecture/01-PLATFORM-TOPOLOGY.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 01 — Unity Runtime Topology and Ownership

**Status:** [USER] architecture invariant + [PROPOSED] detailed contracts. **Refs:** `history/v0.7/Unity_BOB_BE_Integration_Architecture_v0.7.md` sections 0–2.

```mermaid
flowchart LR
  BE[Blazor BE UI] --> API[Authorized API Facade]
  API --> Catalog[Registry + Workflow Library]
  API --> Central[BOB Central Host]
  Catalog --> DB[(MSSQL definitions + versions)]
  Central --> DB
  Central --> K[(Kafka approved topics)]
  K --> CAP[Capability Service + Unity SDK]
  CAP --> Local[BOB Embedded Host]
  Local --> AMIE[Existing AMIE evaluator]
  Local --> Handler[Compiled registered operations]
  CAP --> K
  CAP --> AUD[Append-only audit event service]
  Central --> AUD
  AUD --> ADB[(MSSQL audit events)]
  ADB --> Projection[Business + technical projections]
  Projection --> API
```

## Control plane versus execution plane

**Control plane:** BE draft/version/approval, AMIE rules + data requirements, operation registry, contract validation, package signing, environment binding configuration, access policy. A workflow cannot be published if a binding is missing or incompatible. A registry descriptor is a *discoverable description*, not permission or actual execution.

**Execution plane:** published immutable package + pinned operation/rule versions, central BOB durable process instances, Kafka command/outcome, embedded BOB, AMIE evaluation, compiled capability handlers. Capability worker must not call BE/control plane at every local activity; cache trusted, version-pinned definitions and fail safely on missing versions.

## Data ownership

- `bob` MSSQL owns workflow definitions, versions, tokens, run checkpoints and durable orchestration state.
- `audit` MSSQL owns append-only historical events and reconstruction metadata.
- `integration` MSSQL owns outbox/inbox, correlation and worker leases where used.
- `controls` stores referenced control/runbook revisions and evidence metadata; verify actual bank retention and store.
- DCMS staging, batch rows, report content, CyberArk account data remain with their respective workload/capability owners, **not** in generic BOB schema.
- Kafka carries bounded, schema-checked messages and **references** to large files/data, not CSV bodies or credentials.

## Five non-negotiable flow rules

1. **Start:** Browser -> authorized BE API -> central BOB; no browser-to-Kafka direct connection.
2. **Cross boundary:** central BOB -> durable outbox -> Kafka -> capability inbox -> local work -> result Kafka -> central BOB resume.
3. **Within capability:** local BOB -> AMIE -> local handlers through DI, no Kafka bounce per row step.
4. **Observe:** append-only events -> trusted projection -> authorized API/SignalR -> user-scope UI. Query after reconnect.
5. **Control:** operator requests through APIs and safe checkpoint transitions; cancel does not undo externally completed work.

## Design proof

A complete test must start from BE and follow correlation through BOB, Kafka, one embedded capability, the AMIE rule result, the handler result, audit and the BE status projection. A second workflow must use the same infrastructure unchanged.

## Non-goals

Do not build a universal database service with arbitrary SQL, use BOB as a centralized interpreter for every local instruction, or embed Email/CyberArk-specific logic into BPMN engine core.

<!-- END SOURCE 010: docs/architecture/01-PLATFORM-TOPOLOGY.md -->

---

<!-- BEGIN SOURCE 011: docs/architecture/02-CAPABILITY-SDK-REGISTRY.md -->

# Architecture 02 — Capability SDK, Registry, Service Accounts, and Enterprise Reuse

## Capability discovery versus administrative approval
`Handler implemented -> trusted local DI discovery -> manifest prepared -> service deployed and registered -> registry review -> capability/operation approval -> environment activation -> visible in authorized BE designer -> pinned executable binding`.
Local SDK discovery registers only compiled, allowlisted handlers in that service; **not** a runtime-scanned arbitrary CLR name nor an automatic enterprise approval. In other languages, generated or manually authored contract manifests and secure REST/Kafka adapters provide equivalent registration through the same published API. SDKs are conveniences, not separate authority or separate orchestration.

## Required manifest fields
| Group | Required metadata |
|---|---|
| Service | capabilityId/key, owning department, technical contact, deployment identity, code version, health API, supported environments |
| Operation identity | operationKey@contractVersion, exact handler/endpoint, input/output JSON Schemas, sideEffectClass |
| Policy | Unity operation admission policy, approved L1/L2 hosts, required AMIE facts/rule bindings, resource scopes |
| Reliability | deadline, timeout, retries, idempotency support, uncertain-outcome reconciliation and cancellation behavior |
| Kafka | logical command/outcome types, correlation/idempotency keys, partitioning expectations, schema versions |
| Security | service identity reference, Apigee onboarding reference (when required), credential vault references only, data classification |
| Lifecycle | version maturity/stage, owner reviewer, approval evidence, environment activation, deprecation, audit |

## Human entitlement and service principal separation
- BE human access: Unity group/AMIE rules authorize workflow Read / Execute / Execute-Lead / Create; capability administration Register / Configure is governed separately.
- Central BOB admits an authorized workflow and enforces **published operation allowlist/pinned versions**; each capability checks authenticated dispatch and approved operation permission. Human user context may be recorded and propagated as redacted audit metadata, without the external department managing that user.
- External provider/Apigee authorizes Unity's **service identity**. Broad provider-side access is not carte blanche to use unapproved operations; prefer least privilege when achievable, but existing broad service account does not require thousands of per-user provider entitlements.
- Service account, resource owner, gateway audience and scopes are configuration references and never serialized as credentials in BPMN or logs.

## Two execution profiles
**Central:** BOB SQL-backed runtime persists command intent and outbox; Kafka transports to capability's inbox; local SDK dispatch runs typed handler; outcome resumes BOB. **Embedded:** same interpreter executes bounded capability-local subworkflow using DI and local AMIE adapter, with host capabilities validated. Persistent waits/timers need a durable host; reject unsupported embedded memory-only plans.

## Maturity workflow (version-specific, separate from activation)
Classifications: Experimental, NonProd, Approved. Stages: InDev, Testing, Verified, ReleaseReady. Standard example progression: Experimental-InDev -> Experimental-Testing -> Experimental-Verified -> NonProd-Testing -> NonProd-Verified -> NonProd-ReleaseReady -> Approved-Verified -> Approved-ReleaseReady. Other combinations are representable where policy and evidence justify; transition audits are separate from environment activation. A parent Approved capability may have an Experimental operation.

## MCP
Expose approved operation catalog/actions through an MCP adapter only if platform admission, version checks, audit and rate limits are enforced exactly as for BE and Kafka. No bypass and no parallel orchestration ownership.

## New-service developer flow
Implement typed DTO and handler -> compile and unit test -> register with SDK -> generate/validate manifest -> deploy to DEV using approved identity -> review and approve operation in Unity capability administration -> bind operation from BPMN designer by name/schema -> test local and Kafka paths -> promote independently versioned manifests through approved environment release.

## Verification
Contract tests for duplicate keys, incompatible schemas, unauthorized operation calls, foreign owners, missing source/target versions, revoked operations, unknown external write outcomes, parallel invocation, no-service-reachable, and cross-language manifest compatibility. Show same operation reused without code changes in two applications; no fake success from metadata-only registration.

<!-- END SOURCE 011: docs/architecture/02-CAPABILITY-SDK-REGISTRY.md -->

---

<!-- BEGIN SOURCE 012: docs/architecture/03-BOB-BPMN-RUNTIME.md -->

# Architecture 03 — BOB BPMN 2.0.2 Compiler, Token Runtime and Expanded Phase 1

## Separate conformance dimensions
1. **XML import/export:** BPMN 2.0.2 compliant source with BPMN DI; preserve IDs, lanes, edges and geometry.
2. **Visual modeling:** palette and property editor for standard BPMN elements, with future features behind Experimental Mode.
3. **Compilation:** typed executable intermediate representation; fail unsafe/unsupported constructs before publish.
4. **Runtime semantics:** only explicitly verified element+host+environment combinations execute. Never claim full BPMN 2.0 execution conformance.

## Planned Phase 1 executable subset
| Construct | Required behavior | Essential tests |
|---|---|---|
| Start/end, sequence flow | Deterministic entry/end and graph progression; correct scope lifecycle | Start once, reachable endings, invalid graph |
| Service task | Approved operation/version input/output binding; async outcome | No arbitrary handler; timeout unknown outcome |
| Business-rule task | Pin AMIE rule version and typed fact schema | Misbound facts blocked, decision output audited |
| Exclusive gateway | First valid selected outgoing flow, default flow, no ambiguous result | Branch decisions and missing default |
| Call activity, embedded subprocess | Hierarchical scopes; pinned process identity, input/output maps | Subprocess failure and outer catch |
| Sequential multi-instance | Ordered repeated execution, checkpoint collection state | Three-row ordered, restart without duplication |
| Durable Kafka outcome wait | Persist subscription, correlate, resume once, handle duplicates | Lost/late/duplicate results |
| **Parallel split/join** | Concurrent tokens, tracked activation and atomic join arrivals | Varied completion order, duplicate event, deadlock negative tests |
| **Intermediate timer catch** | Durable one-shot date/duration UTC timer | Pod crash, timer lease, datetime parsing |
| **Interrupting timer boundary** | Attached subscription races normal completion, cancels scope flow | Exactly one winner, late external write reconciliation |
| **Interrupting error boundary** | Catch matching typed BPMN error in correct activity/scope | Matching/unmatched, nested propagate |
| **Minimal durable human task** | Stage assignment, eligible group, approve/reject, resume pending state | Multiple approvers, backups, access, persistence |

BPMN support table belongs to a versioned `BpmnElementCapability` with fields standardElementType, model/import/export support, compiler support, runtime handler maturity, supported hosts, environment policy, feature flag, version, Jira/milestone and tests. **Experimental visibility alone never authorizes execution.** Noninterrupting boundary, inclusive/event-based gateways, parallel multi-instance, event subprocess, compensation, transaction, complex gateway, advanced collaboration, choreography and conversation constructs are design/importable but not executable until authorized handler tests pass.

## Core runtime entities and atomicity
`WorkflowInstance` pins definition revision + package digest. `ExecutionScope` holds parent, lifecycle, variables and attached subscriptions. `ExecutionToken` identifies active path and fork group. `GatewayArrival` records expected/received branch arrivals per activation. `EventSubscription` records correlated wait. `DurableTimer` has dueUtc, lease/revision and fired/cancelled states. `HumanTask` records eligible group/stage/decision state. `PendingCommand`, `Outbox`, `Inbox` and `AuditHistory` protect interservice execution.

Parallel split creates independent tokens and join must atomically consume each required arrival once; never equate transport delivery with work completion. Validate structured fork/join cases first and reject unsupported topologies, including joins that can strand waiting tokens after an error branch.

## Timers and boundary races
A timer cannot rely on in-memory Task.Delay. Store due UTC, event type, scope, claim lease, and durable firing state. Activity start registers attached timers and error subscriptions atomically with the activity token. Normal completion versus boundary event competes for a revision-guarded state transition; the losing event cannot advance another path. External API work may still finish after BPMN interruption—record that outcome and require reconciliation where necessary.

## Errors and retries
Differentiate BPMN business error (`SAFE_NOT_FOUND`), transient retryable technical error, permanent technical error, missing-outcome deadline and engine infrastructure error. Capability manifests declare explicit safe error mappings; generic 503 or SQL exception is not automatically a BPMN error. Unknown external write outcome must not be blindly retried. Raise matching BPMN boundary handlers, else propagate by scope or mark execution for action according to policy. Uncaught errors are operator-visible.

## Pause/resume/cancel/restart
Pause takes effect at safe checkpoints (no guaranteed undo of already dispatched external call). Cancel prevents new work and closes subscriptions, with explicit late-write reconciliation. Restart creates a **new** run ID linked to prior run and pinned approved versions (or an explicit new version choice); maintain audit. Never change executing instance semantics when a new version publishes.

## Shared core and host adapters
BOB core owns interpreter and compiled IR. Central host implements SQL Server durable persistence and Kafka dispatcher. Embedded host uses approved DI dispatcher/local AMIE and host-specific persistence; fail compile/activation for durable waits on memory-only host. Interpreters cannot diverge semantically.

## Operational validation
Enforce graph, schema, operation visibility, entitlement admission, immutable dependency pinning and experimental environment eligibility at backend compile time and again at execution entry. Record machine-readable validation issues with node ID, reason and remediation. No execution from simply importing BPMN XML or viewing it on the designer.

<!-- END SOURCE 012: docs/architecture/03-BOB-BPMN-RUNTIME.md -->

---

<!-- BEGIN SOURCE 013: docs/architecture/04-AMIE-APPROVAL-AND-INTAKE.md -->

# Architecture 04 — Existing AMIE Intake, Rule Catalog and Durable Approval Workflow

## Retain initial deployed boundaries
Keep Matthew's working AMIE intake/rules/user and group implementation unless the repository audit proves a safety or delivery blocker. AMIE currently may validate/enrich/classify inbound messages, select workflow identifiers using rules and send a typed message to BOB's intake topic. This is not competing orchestration until AMIE also owns durable sequences, timers, human-task waits or multi-capability execution. Mark any such detected overlap for **post-pilot immediate remediation**, in `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md`, not a forced two-week rewrite.

## Two AMIE invocation paths
`Inbound request -> AMIE intake classify/enrich/choose workflow -> Kafka typed BOB start request -> BOB authorization and version validation -> run`. `BOB activity or approved embedded capability step -> pinned AMIE evaluation -> typed decision / mapped facts -> BOB follows BPMN flow or local handler uses returned facts`. AMIE never directly owns the BOB active-token state.

## Configurable rule catalog
Every RuleDefinition and RuleSet should have an immutable version, application/capability owner, category, typed facts, outputs, effective group restrictions, consumer associations, testing fixtures, audit history, compatibility policy and environment activation. Suggested categories: IntakeRouting, Eligibility, Validation, Mapping, Classification, Governance, ApprovalPolicy, EntitlementPolicy, Threshold, Reconciliation. A rule may be shared across several owners via explicit association, not copied blindly.

## Human approval: BOB workflow + AMIE policy
**AMIE:** determines whether approval is required, eligible group(s), ordered stages, required count (any-one or all), primary/backup approver reference, rejection/expiry rules. **BOB:** persists tasks and decisions, awaits completion, handles pause/resume/timeouts/parallel-stage semantics. **BE:** presents authorized inbox, task detail, approval/rejection and history. **Security:** enforces that actual decision actor is eligible at time of action. Use immutable approval-plan rule version for the running task; do not silently swap current rule mid-approval.

A minimum Phase 1 contract supports multi-stage approval (sequential stages), multiple approvers in a stage, any-one versus all-required, backup group assignment, explicit reject path, and durable waiting. More sophisticated delegation, quorum, calendar, escalation and form-builder behavior can follow later.

## Sample approval plan (illustrative, not deployed schema)
```json
{
  "policyKey": "PAM.PrivilegedAccount.CreateApproval",
  "ruleVersion": "2.0.0",
  "requestRef": "req-001",
  "required": true,
  "stages": [
    {"order": 1, "eligibleGroups": ["PAM.AppOwners"], "backupGroups": ["PAM.AppBackup"], "mode": "AnyOne"},
    {"order": 2, "eligibleGroups": ["PAM.Security"], "mode": "AllRequired", "requiredApprovals": 2}
  ],
  "rejectOutcome": "Rejected"
}
```
Schema shape is proposed; match existing AMIE syntax/API at M0. The typed approval plan is *data*, not an AMIE-run process.

## AMIE-to-BOB start contract
Include schemaVersion, requestId, correlationId, idempotencyKey, classification, selectedWorkflowKey, selectedWorkflowVersion (or approved active alias resolved by BOB), ruleSetId/version/digest, reasonCodes, enrichedDataSchemaVersion, data reference/value subject to classification, request initiator context and environment. BOB authenticates publisher, checks resource authorization, activation and known dependencies, then starts only once. Unknown workflow keys should be rejected, not dynamically evaluated as executable code.

## Rule-to-BPMN links
BPMN BusinessRuleTask inspector must support choosing approved rule by application/capability context, pinning version, binding named facts from upstream task outputs or process variables, previewing return schema, testing with redacted fixture, browsing consumers and audit/version history. Compiler validates rule/host availability and type compatibility. AMIE mapping may construct typed change-set but no uncontrolled arbitrary C# or SQL.

## Human approval and release approval are distinct
Business-process approval human tasks (e.g. request manager and security) are not automatically sufficient to approve a production workflow release. Production change approval and ServiceNow reference are separate governance actions, although AMIE approval rules and BOB human-task mechanisms may be reused with different policies/permissions.

## User-interface design guidance for Matthew
See `docs/ux/12-AMIE-APPROVAL-WIREFRAMES.md`. Proposed pages are selectable candidates for Matthew to keep/modify/reject, not a directive to replace his existing editor. Keep a common Blazor shell, application selector, category tree, version/status labels, rule inspect/test, consumer links and AMIE->BOB decision trace. Record feedback and current route/component names in review file (excluded from Ask).

<!-- END SOURCE 013: docs/architecture/04-AMIE-APPROVAL-AND-INTAKE.md -->

---

<!-- BEGIN SOURCE 014: docs/architecture/04-AMIE-BINDINGS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 04 — Existing AMIE Integration and Typed Data Binding

**Status:** [USER] AMIE already substantially implemented. This spec defines the adapter expectations, **not** a competing evaluation engine. **Mandatory:** JOB-00 inspect AMIE's real rule evaluator, rule versions, input models, deployment and cache APIs before coding.

## Division of responsibility

- AMIE owns configurable expressions, transformations, eligibility decisions, schema-bound field mapping and decision results.
- BOB owns *when* a rule runs, how its output selects a BPMN route, and how rule outcomes are recorded.
- Capability owns enforcing operation contracts and performing external actions; AMIE config cannot grant privileged access.
- BE owns input binding UI, rule picker, preview and validation; it calls the existing AMIE API/adapter.

## Proposed adapter (rename to existing interface when found)

```csharp
public interface IUnityAmieAdapter
{
    Task<RuleDescriptor> DescribeAsync(string ruleKey, string version, CancellationToken ct);
    Task<RuleOutcome> EvaluateAsync(RuleRequest request, UnityExecutionContext context, CancellationToken ct);
    Task<BindingValidation> ValidateBindingsAsync(RuleDescriptor rule, IReadOnlyDictionary<string, ValueBinding> bindings, CancellationToken ct);
}
```

Do **not** implement fresh parsers, dynamic C# expression compilation or a new rule language unless documented as a required existing AMIE capability and approved by owner.

## Unified binding grammar

Logical values originate from (a) workflow initial inputs, (b) current item/record, (c) prior operation result, (d) AMIE rule output, (e) allowlisted constant, (f) approved environment binding, or (g) protected server-side secret reference.

Example expressions (labels, **not** raw executable code): `input.batchId`, `item.accountRef`, `steps.getAccount.output.account`, `rules.attributeMap.output.changeSet`, `settings.allowCreate`, `environment.cyberark.endpointRef`.

Each binding is stored as a **typed reference descriptor** with source kind, path, expected schema, nullable/default behavior, and classification. The compiler resolves it, validates compatibility, and records origin. Never permit raw variable paths to bypass missing-field errors or escape their scope.

## Rule descriptor

For each rule, expose key/version, owner/approved state, input and output JSON schemas, decision types, minimum configuration, data classification, test examples and compatibility requirements. Rule outputs must be serializable to safe result DTOs for BOB gateways and audit summaries; keep complete restricted inputs with owning data services.

## DCMS mapping

`DCMS.AccountEligibility`: input current CSV row + account metadata -> outcome `Eligible | Skip | Reject`, with reason code. `DCMS.MapAttributes`: source CSV fields + account platform -> approved attribute patch. `DCMS.ShouldUpdate`: current vs desired -> Update or NoChange. These are **design examples**, not names guaranteed to exist in current AMIE.

Workflow: retrieve account -> AMIE eligible -> gateway -> AMIE mapping -> capability in-memory transform -> capability approved write -> classify actual write outcome. A successful rule **does not imply** a successful CyberArk write. Use explicit business outcomes: `Succeeded`, `NoChange`, `Skipped`, `Rejected`, `Failed`, `UnknownExternalOutcome`.

## Versioning

A published workflow package pins exact rule identity + version. If rule isn't present in the deployed runtime, reject start / suspend safely; do not silently substitute latest. New rule version requires new reviewed package for new runs. Audit tracks rule reference, inputs hash/ref and safe outcome metadata.

## Adapter acceptance

- Existing AMIE engine evaluates a real rule using the adapter and supplies typed result.
- BE operation inspector suggests compatible input data and reports mismatches before publish.
- Workflow decision changes when AMIE config changes in **a new published version**, without BOB or CyberArk changes.
- Attempted sensitive action remains forbidden even when a rule outputs `true`.
- Same rule evaluated inside embedded CyberArk host without remote roundtrip per row.

<!-- END SOURCE 014: docs/architecture/04-AMIE-BINDINGS.md -->

---

<!-- BEGIN SOURCE 015: docs/architecture/05-KAFKA-RELIABILITY.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 05 — Kafka Messaging Standard, Reliability and SDK Subscriptions

## What capability services declare

Each manifest declares **logical** subscription and publication descriptors: topic binding key (not physical broker address), message type/schema/version, consumer-group binding key, partition key, correlation requirements, idempotency strategy, retention/classification, allowed publisher/consumer identities. Platform deploys broker ACLs separately and validates authorization.

## Canonical envelope

`messageId`, `commandId` (if command), `messageType`, `schemaVersion`, `correlationId`, `causationId`, `traceparent`, `occurredAtUtc`, `applicationKey`, `workflowKey/version`, `runId`, `activityId`, `batchId`, `recordGuid` when appropriate, `sourceCapability`, `targetCapability`, `operationKey/version`, `idempotencyKey`, `actorContextRef`, `classification`, `payload` or `payloadRef`.

Keep message payload bounded and schema-valid; use secure reference for CSV/report/privileged account data. `actorContextRef` is a trusted signed/validated identity reference, not a browser-supplied role string.

## Durable dispatch pattern

1. Central BOB transaction records pending activity and integration outbox row with its run state.
2. Publisher delivers outbox to Kafka and marks receipt. Re-send can occur; design for duplicates.
3. Capability consumer validates broker identity, message type/version, operation key permission, data contract, expiry, deduplication key and actor/service scope.
4. Consumer claims inbox receipt and either invokes compiled handler or resumes embedded subworkflow.
5. Result/outcome is published through capability outbox; central BOB correlates once using `runId + activityId + commandId`.
6. Failed validation -> quarantine/DLQ with safe reason and operator runbook; no arbitrary replay without safety check.

## Exactly-once warning

Kafka transactions do not make an external CyberArk REST write exactly once. A crash can occur after a CyberArk update succeeded but before the local worker persisted success. On retry: use target-system revision/lookup/operation reference to reconcile, then mark `Confirmed` / `UnknownExternalOutcome`; never blindly replay writes. Handler declares `SafeToRetry`, `RequiresIdempotencyKey`, `ReconcileBeforeRetry`, or `NeverAutoRetry` policy.

## Ordering and parallelism

For DCMS one **batch** is sequential initially. Ordering within one batch is enforced by embedded BOB and a durable claim/lease. Different batches may process concurrently if permitted, but account-level writes may need a separate account key lock. Kafka partition key is not sufficient by itself to guarantee end-to-end external-write uniqueness.

## Negative tests

Duplicate command; duplicate outcome; changed schema; unauthorized topic/service; poison message; transient network outage; consumer restart while processing; outbox resend; late result after cancellation; unknown operation; revoked capability version; oversized payload; stale run version.

## Routes for future triggers

REST API push, approved data-source pull and AutoSys schedule **all** normalize into an authenticated `StartWorkflow` intent with standardized `triggerType`, source event ID, data artifact ref, idempotency key, correlation and audit. Do not build each trigger as a new BOB code path. Future scheduling orchestration is P1 unless required by pilot.

<!-- END SOURCE 015: docs/architecture/05-KAFKA-RELIABILITY.md -->

---

<!-- BEGIN SOURCE 016: docs/architecture/05-SECURITY-ENTITLEMENTS.md -->

# Architecture 05 — Standalone Groups, Channel Secure Migration and Two Authorization Boundaries

## Implementation rule
**Now:** reuse Matthew's functioning standalone login, user groups and AMIE access rule configuration. Do not create a competing auth server or IAM store. **Before PROD go-live:** integrate Channel Secure for enterprise SAML SSO and entitlements/group resolution; requirements and existing project details may arrive during development. Build a provider adapter boundary, preserve group/resource policy identifiers and make the integration a go-live milestone rather than a distant optional feature. Verify authentication session, claims/entitlements, logout, expiry, group sync/cache and audit when contracts become available.

## Human website group roles
| Permission | Authorizes | Scope |
|---|---|---|
| Read | View definition (if assigned), permitted run results and reports | Resource/group-specific |
| Execute | Read + start a specific approved workflow; view own results | Resource-specific |
| Execute-Lead | Execute + group/team member run/report visibility | Only the expressly authorized group's members and runs |
| Create | Create/change workflow drafts + execute/read within scope | Never implies production activation or approval |
| Capability Register | Submit/review capability registration and metadata | Admin function, independent of workflow Execute |
| Capability Configure | Edit approved capability settings, operations, environment bindings | Admin function, independent of workflow Execute |
| Approve Task / Release Operator | Decide assigned human task / import or activate approved release | Distinct admin entitlements |

A workflow can have **multiple local groups or equivalent AMIE conditions** assigned. Effective policy defines any/all, scope and conflict behavior explicitly; do not assume that categories or folder paths imply permissions. Server enforcement at BE APIs, BOB start admission and capability dispatch must follow the same policy; UI visibility is not authoritative.

## Human-to-workflow versus service-to-API
External department grants technical API access to a Unity **service account** (often via Apigee). The department is not tasked with per-Unity-user group administration. Unity tracks end-user actor and delegated workflow permission; the capability uses the approved service account and keeps provider credentials behind vault references. Many deployed service accounts may have broad rights; enforce operation allowlists, workflow version bindings, command authentication, and audit to prevent a broad service credential becoming unlimited web access. Prefer least-privilege accounts where feasible; don't misrepresent provider-wide admin access as inherently safe.

## Environment isolation
DEV=non-prod, UAT=pre-prod, PROD=production. Group config may include imported enterprise group *references* and trusted name conventions (`Prod`, `NonProd`) as usability checks. Production must enforce explicit environment eligibility rather than solely substring matching. Config/import flow is versioned and audited. No real AD integration or fake memberships required before Channel Secure data arrives.

## Audit fields
ActorId/provider, group snapshot or entitlement proof reference, resourceId/version, action, policy/rule version, allow/deny and reason code, correlation ID, environment, time UTC; redact sensitive data. Group changes and published versions become future policy-drift baselines.

## Tests
User with Read cannot Execute; Execute cannot edit; Execute-Lead sees only entitled group reports; Create cannot approve its own release unless separately permitted and policy allows; browser-only hidden button bypass attempts fail via API; service account cannot bypass approved operation and workflow admission; PROD rejects non-prod group associations; identity-provider swap preserves resource grants, subject to verified enterprise mapping.

<!-- END SOURCE 016: docs/architecture/05-SECURITY-ENTITLEMENTS.md -->

---

<!-- BEGIN SOURCE 017: docs/architecture/06-PERSISTENCE-AUDIT.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 06 — MSSQL Persistence, Audit Reconstruction and Status Projection

## Persistence responsibilities

- `bob.WorkflowDefinition`, `WorkflowVersion`, `ActivityBinding`, `WorkflowRun`, `RunToken`, `ActivityRun`, `PendingCommand`, `ControlRequest`, `PackageActivation`.
- `integration.OutboxMessage`, `InboxReceipt`, optional worker lease/claim tables.
- `audit.AuditEvent` **append-only**; restricted actor and evidence metadata, never full privileged payloads.
- `controls.RunbookVersion`, `ControlDefinition`, `ControlEvidence` if adopted by bank control owners.
- `projection.RunSummary` or equivalent materialized/read model for low-latency BE dashboards.
- DCMS `Batch/BatchRow` stay with DCMS/workload data owner, not generic BOB. Permission checks apply to joining read models across domains.

**MSSQL-only refers to BOB provider; other capability-owned stores remain independent.** Prefer transactional consistency for a run transition and outbox row in the same MSSQL database transaction when both are under same owner; cross-service actions require correlated follow-up outcomes.

## Minimum AuditEvent shape

`eventId`, `occurredUtc`, `recordedUtc`, `eventType`, `actorId`, `actorKind`, `scope`, `applicationKey`, `workflowKey/version`, `runId`, `activityId`, `packageDigest`, `amieRuleKey/version`, `capabilityKey/operationKey/version`, `batchId`, `recordGuid`, `messageId`, `correlationId`, `causationId`, `traceId`, `reasonCode`, `oldState`, `newState`, `serviceNowChangeId`, `controlId`, `evidenceRef`, `safeDetailsHash`, `classification`, `eventSchemaVersion`.

**No secrets or full CyberArk account records in audit.** Use data owner reference/hash + approved redacted summary, limited retention and authorized export. Immutable event stream alone cannot reconstruct unavailable code or rule definitions: retain signed published package and dependency list.

## Truth model

The event log is the durable historical timeline. State tables permit fast execution/recovery. Projections transform source events into counts and timelines; on disconnect/reconnect the BE UI calls the authoritative API before resuming push updates. The projected UI must distinguish `Completed`, `Failed`, `Skipped`, `NoChange`, `InProgress`, `Pending`, and `UnknownExternalOutcome` for DCMS; the workload owner defines business classifications.

## Concurrency and reconstruction

Use expected run revision/rowversion, unique message/command IDs, optimistic concurrency plus lease where necessary. Append an event and advance a state transition atomically whenever possible. Test interleaving commands, restart, projection rebuild, missing event, late Kafka event and duplicate delivery. Protect audit writers via append-only privileges; user/admin deletion forbidden except strictly controlled retention jobs with recorded evidence and bank policy.

## Control evidence

Store ServiceNow ticket ID, requester, reviewer, author, publisher, deployment actor, environment, artifact digest, approval decision, UTC and runbook version. **A populated ticket ID is not proof of approval**. Evidence must derive from authoritative bank records or authorized reviewers in a trusted approval process.

## Optional integrity

SQL Server Ledger and off-database hash/checkpoint mechanisms are **research options only**, requiring installed SQL Server version, security and bank approval. Do not introduce as a November dependency.

<!-- END SOURCE 017: docs/architecture/06-PERSISTENCE-AUDIT.md -->

---

<!-- BEGIN SOURCE 018: docs/architecture/06-SQL-VERSIONED-ENTITIES.md -->

# Architecture 06 — SQL Server `uty_` Schemas, EF Core, Versioning and Change Management

## SQL organizational decision
**Single approved Unity SQL Server database per environment with independently owned schemas and DbContexts.** These are logical target names; adjust only by explicit ADR if live migrations demand non-destructive compatibility. Do not split into new independent DBs without agreement. No cross-service ownership bypass by direct EF queries simply because the database is shared.

| Schema | Owned records | EF context concept |
|---|---|---|
| `uty_catalog` | Application, Category, Collection/Folder, Tag, ResourceAssociation, ResourceOwner | CatalogDbContext |
| `uty_security` | Local Group (existing implementation), Member, EntitlementGrant, GroupEnvironmentBinding, EffectiveAccessAudit | SecurityDbContext |
| `uty_capability` | CapabilityService, OperationDefinition/Version, Manifest/Version, CapabilityActivation, API identity reference | CapabilityDbContext |
| `uty_bob` | WorkflowDefinition/Version, DraftRevision, Token, Scope, GatewayArrival, Timer, Wait, HumanTask, Command | BobDbContext |
| `uty_amie` | RuleDefinition/Version, RuleSet/Version, PolicyBinding, RuleDecision, ApprovalPolicy | AmieDbContext |
| `uty_be` | SavedView, Favorite, UserPreference, NotificationPreference | BeDbContext |
| `uty_release` | ReleasePackage, PackageArtifact, ValidationEvidence, ChangeReference, EnvironmentActivation, PromotionHistory | ReleaseDbContext |
| `uty_audit` | Append-only ConfigChange, OperationEvent, RunEvent, Baseline, DriftFinding (future) | AuditDbContext |

**Caution:** existing classes, migration histories and table ownership have not been inspected; reconcile M0 before implementing migrations. The conceptual group provider may already exist in AMIE or BE. Do not create a second group table just to satisfy a proposed name.

## Core identities and relationships
`Application {ApplicationId,Key,Owner,...}`; `CapabilityService {CapabilityId,Key,...}`; `ResourceCategory {CategoryId,Key,...}`; `CatalogCollection {CollectionId,ParentId,OwnerScope,...}`; `WorkflowDefinition {WorkflowId,Key,Level,OwnerType,OwnerId,...}`; `WorkflowVersion {WorkflowVersionId,DefinitionId,SemanticVersion,PackageDigest,BpmnXml,DiXml/embeddedDI,...}`; `WorkflowAssociation {WorkflowId,ConsumerOwnerId,CategoryId,CollectionId,...}`; `OperationVersion {OperationVersionId,CapabilityId,Key,ContractVersion,ManifestDigest,...}`; `RuleVersion {RuleVersionId,RuleDefinitionId,SchemaVersion,...}`; `DefinitionDependency {SourceVersion,TargetVersion,BindingType,...}`; `EntitlementGrant {GroupId,ResourceId,Role,Environment,PolicyVersion,...}`; `EnvironmentActivation {ObjectVersionId,Environment,Status,...}`.

Use immutable published records; drafts have `rowversion`/ETag optimistic concurrency. Stable workflow IDs are not derived from folder path; moving to another category cannot break a run. Any mutation to a published definition creates a new version. Running instances pin process/rule/operation/subprocess versions and necessary classification/permission context per approved policy.

## Workflow maturity tracking
Store classification enum (`Experimental`, `NonProd`, `Approved`), stage enum (`InDev`, `Testing`, `Verified`, `ReleaseReady`) against a particular **version**; append status-transition history with actor, evidence and review. Activation independently records `Inactive`, `Active`, `Suspended`, `Retired` for each environment. No automatic inheritance of Approved from parent capability to its operations or workflows. A ReleaseReady Experimental version is still not PROD eligible.

## Import, seed and rollout
EF migrations establish schema and data shape; environment-specific **configuration imports** activate approved group references, categories, rules, capability bindings, and workflows. Initial standalone groups remain managed by existing application; all imports must be idempotent by stable IDs/version/hash and atomic. Migrations must not seed fictional AD membership. Approved Prod/NonProd group naming conventions are validated alongside explicit environment classification. Compare plan before apply, version/hash the input, require authorized import and audit changes.

## Policy drift future-proofing
Versioned materialized configuration snapshots/digests and append-only change events for groups, entitlements, AMIE rules, workflow versions, capability manifests and activation. Later drift detector compares runtime/configuration state to approved baseline and alerts via a registered capability; **not** required to build all drift monitoring in first two weeks.

## Transaction boundaries
Same-component state+outbox may commit in one SQL transaction; cross-service coordination remains asynchronous with idempotency/inbox, not a distributed transaction. Sensitive secrets are referenced not stored. EF contexts must not mutate another component's schema. Validate rollback and replay strategies for migration and package import.

<!-- END SOURCE 018: docs/architecture/06-SQL-VERSIONED-ENTITIES.md -->

---

<!-- BEGIN SOURCE 019: docs/architecture/07-BE-BLAZOR-DESIGN.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 07 — Blazor BE Design, Designer and Business UI

## Core screens (the existing v0.7 HTML prototype is a visual reference, not Blazor code)

1. **Workbench:** application summaries, recent runs, role-scoped quick actions.
2. **Capability Registry:** searchable authorized capability/operation list and operational health.
3. **Operation Inspector:** input/output schemas, binding selector, AMIE dependency, permission and side effect warnings, retry behavior.
4. **Workflow Library:** draft/review/published/active/retired versions, owner, ServiceNow change ID, diff, clone.
5. **BPMN Designer:** left palette of supported BPMN and approved operations; center canvas; right schema-derived inspector; bottom validation and test panel. Preserve BPMN IDs/DI, version pins and unsupported-node diagnostics.
6. **AMIE Picker:** pick existing approved rules, preview on safe test fixtures; never build second AMIE expression engine.
7. **Trigger Forms:** manual start, CSV upload, API trigger, data refs and validation errors; scheduling P1.
8. **Business Work Queue:** batch status counts, result report and record-level reasons, filtered by user scope; BPMN technical detail not required.
9. **Run Monitor:** BPMN diagram overlay of active/completed/error/paused nodes, correlated Kafka/evidence timeline, read-only for most roles.
10. **Operator Console:** pause/resume/cancel/retry/restart with pending request state and runbook/actor/reason; mutation only via authorized backend API.
11. **Audit & Controls:** immutable timeline by batch/run/change/user, safe export and runbook revision.
12. **Release Center:** package hash, dependency validation, environments and binding checks, role-separated approvals and Operations activation.
13. **API Regression:** contract and CI test evidence links (full UI P1; automation is P0).

## Designer implementation without unapproved library

Use approved existing UI dependencies. Otherwise a first-party Blazor component renders SVG nodes/connections and handles selection/property editing. A small first-party JS module owns high-frequency dragging, pan/zoom, snapping and connect-preview; send **committed** gesture results to Blazor through JS interop rather than a C# roundtrip on each mouse event. Maintain a single BPMN model; import/export XML + DI, not a private format that cannot interchange. Avoid mutating Blazor-owned DOM via external JS. Docs: https://learn.microsoft.com/en-us/aspnet/core/blazor/javascript-interoperability/?view=aspnetcore-10.0

## Operation configuration and validation

When designer drops a service task, its inspector must pull `OperationDescriptor@version`. Render inputs based on schema + UI hints, required/optional flags, data classification, supported host modes. Pick binding source: trigger input, current row, prior step output, AMIE output, allowlisted constants, environment binding or protected secret reference. Auto-generate structured error such as `ACT-23 accountRef missing` or `RULE-7 output incompatible with CyberArk.AddOrUpdateAccount@1.0`.

BE calls `POST /api/v1/workflow-drafts/{id}/validate` (proposed) and displays **backend compiler** errors. UI-only validation is friendly guidance, never final admission. Also call backend auth to hide disabled actions, but backend always rechecks.

## UX performance/accuracy

- All long lists paginated and filtered; avoid loading a full batch into the browser.
- Business progress = completed terminal rows / total staged rows, with per-category counts and last-updated timestamp. Push is a hint; refresh from API on reconnect.
- Use semantic text and accessible controls; a visual diagram alone must not be the only source of error explanation.
- Never show tokens/passwords in the browser; display secure binding names only.
- Design run overlay uses the *published workflow XML* with associated BPMN DI geometry.
- Support user scopes: some users see only their own batches; auditors see evidence without mutation; operators may inspect technical detail for assigned workflows.

## Screen tests

Each screen's action must have an API; no fake save/publish. Test unauthorized direct API request after hiding button; keyboard navigation; bad schema; draft conflict; concurrent editor; missing capability; terminal failure; reconnect; large paginated batch; redaction; mobile responsive baseline; no console errors.

<!-- END SOURCE 019: docs/architecture/07-BE-BLAZOR-DESIGN.md -->

---

<!-- BEGIN SOURCE 020: docs/architecture/07-ENTERPRISE-INTEGRATION-READINESS.md -->

# Architecture 07 — Day-One Enterprise Integration Readiness and Unknown-Contract Tracker

**Policy:** All items below are accounted for in initial milestones and Jira placeholders. Some may already exist; verify actual implementations, existing Jira issue keys and ownership before creating new code/tickets. Their unavailable details must not block independent DEV/BE/SDK/BPMN work. A required production dependency cannot be waived merely because its contract is unknown.

| Placeholder | Integration | Initial discovery/tests | Go-live evidence needed | State |
|---|---|---|---|---|
| INT-CHSEC | Channel Secure | SAML SSO, entitlements, existing Matthew auth seam, session/logout claims | Verified login, group mapping, authorization tests | Existing/Partial/TBD after audit |
| INT-APIGEE | Apigee | API products, onboard service identity, OAuth/mTLS scopes, gateway route/environment | Authorized call, deny test, credential rotation, audit | Existing/Partial/TBD after audit |
| INT-SPLUNK | Splunk | logging formatter, trace/correlation fields, redaction, log forwarding | Searchable audit and security telemetry without secrets | Existing/Partial/TBD after audit |
| INT-AUTOSYS | AutoSys | approved scheduler trigger adapter, identity, signed/authorized message, run correlation | Schedule event -> workflow outcome and duplicate prevention | Existing/Partial/TBD after audit |
| INT-NAS | NAS | owner API/EF schema/DTO, staged batch access, authorization; no cross-domain table bypass | Real or approved DEV/UAT API test, data provenance and error handling | Existing/Partial/TBD after audit |
| INT-CRON | Cron/scheduled jobs | job ownership, overlap with BPMN timers, timezone/UTC, callback contracts | Enforced schedule, replay and audit | Existing/Partial/TBD after audit |
| INT-OTHER | Additional departments/systems | API onboarding profile and SDK/REST/Kafka contract | Approved target-specific proof | As discovered |

For each integration create or map a Jira story under M5 with: owner/technical contact (TBD permitted), external documentation needed, credential/scope class, dependencies, target DEV/UAT/PROD, existing source paths if any, negative auth test, pass/fail evidence and blocker. Distinguish `Existing—Verify`, `Partial`, `Awaiting Requirements`, `Ready`, `Verified`. No duplicate ticket just because a placeholder was listed.

## Cross-enterprise boundary
Department controls its own API and grants access to Unity service identity. Unity authorizes users/groups to workflows, dispatches approved pinned operation calls and audits. Apigee may mediate API access; no need to assign every external service a separate permission for every human user.

## Trigger sources and scheduling
Manual BE form/CSV, approved API request, Kafka intake, AutoSys, cron and future timer starts are different trigger adapters. Existing AutoSys or cron can start an approved BOB workflow via typed trigger with identity, idempotency and correlation; BPMN intermediate timers operate **inside an active instance**. Do not equate cron scheduler with BPMN timer catch semantics.

## Readiness conditions
No hardcoded external endpoints, identity secrets, nonexistent APIs, fabricated ServiceNow integration or fictitious production evidence. Handoff must separate DEV mock/conformance tests, approved UAT integration evidence and PROD blocker list. Implement interfaces now; activate real targets when security contracts and test access are supplied.

<!-- END SOURCE 020: docs/architecture/07-ENTERPRISE-INTEGRATION-READINESS.md -->

---

<!-- BEGIN SOURCE 021: docs/architecture/08-ACCESS-RUNBOOKS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 08 — Access Control, Operations Controls and Runbooks

## Distinguish permissions from controls

**Permissions** decide *who can call an action*. **Controls/runbooks** document *expected handling, accountable owners, escalation, evidence and approvals*. Wells Fargo actual IAM names, controls, CA identifiers and ServiceNow approval mechanics are **unknown pending inspection**. Do not invent them or claim compliance certification.

## Proposed role slices

- `WorkflowDesigner`: edit only assigned application drafts.
- `RuleMaintainer`: edit assigned AMIE rule drafts.
- `WorkflowReviewer`: approve content under delegated separation-of-duties rules.
- `CapabilityPublisher`: register approved manifest after service release.
- `ReleaseOperator`: preflight/install approved immutable package in assigned environment only; cannot edit package.
- `BusinessExecutor`: start authorized workflows, upload or fill assigned forms, view business summaries.
- `TaskAssignee`: claim/complete assigned human tasks when implemented.
- `ProcessOperator`: run-control actions with reason, change ticket if required, and assigned scope.
- `Auditor`: view approved history and evidence, not update.
- `ReadOnlyObserver`: status only.
- `PlatformAdmin`: manage delegated configuration; not automatic override of PROD release restrictions.

## Authorization implementation

Authorization = action permission AND resource scope AND environment AND data classification AND separation-of-duties policy. Check on API, application service, worker operation dispatch and data read. A manifest descriptor cannot grant an entitlement. Kafka service identity must also be authorized for the operation and destination topic. All denials produce redacted audit events; default deny.

## Runbook schema

`runbookKey`, `version`, `owner`, `applicationKey`, `workflowKey`, `controlIds`, `trigger`, `expectedOutcome`, `monitoringThreshold`, `pauseProcedure`, `cancellationLimit`, `retryClassification`, `externalReconciliationSteps`, `escalation`, `requiredTicketKind`, `evidenceChecklist`, `approver`, `effectiveAt`, `retiredAt`. Versions immutable once effective.

## Operator control UX

Show current run state, last transition, pending commands, scope, authorized controls, runbook snippet, and evidence. Before a mutation: collect a structured reason; ask for ticket when bank rule requires; show **what action does not guarantee**. Example `Pause` is checkpoint-cooperative and cannot interrupt accepted CyberArk write. API validates `If-Match` revision, command-idempotency, actor and policy; show `PauseRequested` until the actual state changes.

## Maker/checker

Author/reviewer/release operator identities recorded separately; separation-of-duties is bank-specific and must be enforced server-side where applicable. A ServiceNow string field is an evidence reference, not an approver. No DEV user automatically gets PROD rights.

## Runbook regression

Test allowed/denied scopes, reviewer self-approval deny when required, stop while write in flight, stale state update, two operators racing, retry unknown write, offline audit/DB, failed release preflight, retired definition start denied.

<!-- END SOURCE 021: docs/architecture/08-ACCESS-RUNBOOKS.md -->

---

<!-- BEGIN SOURCE 022: docs/architecture/08-RELEASE-EXPERIMENTAL-PROMOTION.md -->

# Architecture 08 — Experimental Mode, Classification Workflow and DEV/UAT/PROD Promotion

## Independent controls
A resource has (1) per-version maturity classification Experimental/NonProd/Approved, (2) development stage InDev/Testing/Verified/ReleaseReady, (3) execution support capability/host, (4) per-environment activation, and (5) permission/policy authorization. **None alone grants execution.** Same model applies to capabilities, individual operations, workflows, AMIE rule versions and BPMN element handlers.

## Standard illustrative progression
`Experimental-InDev -> Experimental-Testing -> Experimental-Verified -> NonProd-Testing -> NonProd-Verified -> NonProd-ReleaseReady -> Approved-Verified -> Approved-ReleaseReady`. The model stores two fields independently, with required transition review/evidence. Normal maturation may skip states under documented policy; status changes do not activate resources automatically.

## Experimental BPMN mode
- Admin setting enables full BPMN 2.0 palette for approved authors; default designer hides unsupported execution elements but imported XML/DI can still preserve known standard nodes.
- Experimental element is clearly tagged, with tooltip/status, Jira link, missing handler/validation warnings. Parent workflow inherits a warning showing affected nodes.
- Draft save, versioned edit, import/export are allowed even when execution is not. Backend compiler rejects missing handlers, unsupported host or unapproved combination; no silent no-op conversion.
- DEV may execute implemented experimental handlers behind admin flag and explicit authorized test policy; UAT testing requires deliberate NonProd or approved experimental test policy; PROD rejects any not Approved/ReleaseReady and allowed by current runtime.
- A simulator/mock preview is not a proof of executable behavior.

## Release packaging
Canonical `process.bpmn` includes OMG BPMN XML+DI. Unity binding contracts, AMIE rule references and operation descriptors are separately versioned JSON. An example `.unitypkg` is a ZIP container with `manifest.json`, `process.bpmn`, `bindings.json`, typed rule refs, evidence manifest and signature metadata. Never describe a previous mock's binding-plan JSON as executable BPMN. Stable package manifest lists IDs, versions, approval classification/stage, dependencies, content hashes, environment compatibility and approved signer identity. Keep environment secrets external: use resolvable binding references, no secret values.

## Production trust rule
Production uploads are allowed only through an authorized import/activation workflow. PROD requires a **nonempty ServiceNow change ID** (ticket status not verified through API in Phase 1), resource entitlement, validation, immutable approved artifact and cryptographic trust or equivalent approved enterprise release control. **Do not embed reusable secret/private key in the XML.** Package signature must be checked against a production-trusted key independent of package content. Import and activation are distinct; an uploaded artifact does not go live automatically.

### Practical delivery sequencing
1. DEV: make real XML+DI import/export and package validation work; simulate signer if production trust infrastructure not available and label as non-prod.
2. DEV/UAT: test package checks, hash/modified-file rejection, missing dependency and missing ServiceNow ID; test UAT import and approval.
3. PROD: enable upload/activate only after independent trusted signature/approved enterprise release path, Channel Secure authentication/entitlements and required integrations are verified. If those prerequisites are absent, PROD upload remains disabled; DEV work proceeds.
4. Future: ServiceNow API capability validates ticket status, approvals and lifecycle; not present now.

## Version promotion and rollback
Promote **same approved artifact digest** DEV -> UAT -> PROD where feasible; use separately approved environment bindings without mutating signed functional content. Pinned running instances remain on prior version. Retiring or revoking an operation blocks new starts under defined policy while leaving audit/history readable. Rollback is a new audited activation of a prior approved version, not a silent overwrite of active definitions.

## Release approval as AMIE+BOB workflow
AMIE policy checks required reviewers, stages, backups and environment rules; BOB durable human tasks coordinate decisions and wait; BE shows queue, status and evidence; release service validates ticket reference, artifact, permissions and activation. Do not confuse a change ID with approval evidence or allow creator entitlement to grant production activation automatically.

## Tests
Invalid signature (different trusted root), changed BPMN byte, missing ticket ID, non-prod group in PROD, experimental workflow in PROD, missing approved capability version, unapproved rule, wrong host, duplicate import, UAT and PROD activation permission denial, old-version run continuity, separation-of-duties review.

<!-- END SOURCE 022: docs/architecture/08-RELEASE-EXPERIMENTAL-PROMOTION.md -->

---

<!-- BEGIN SOURCE 023: docs/architecture/09-RELEASE-PACKAGES.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 09 — Immutable Configuration Release and Environment Promotion

## Split release types

- **Capability code release:** new .NET handler or upgraded adapter, deployment/approval through existing bank SDLC; registry activates only approved manifest version.
- **Configuration-only release:** new BOB BPMN XML, AMIE rules/mappings, operation bindings, forms/triggers and runbook references; compiled service binaries unchanged if all operations exist.

## Proposed Unity Execution Package structure

```
package.json                  # manifest, immutable package ID/version, digest, owner
workflows/*.bpmn              # BPMN 2.0 XML + DI + vetted Unity extensions
amie/*                       # references/versions and approved portable AMIE artifacts
bindings/*.json               # operation bindings, data contracts
forms/*.json                  # schema-driven form metadata, if required
controls/runbooks.json        # versioned operational references
contracts/lock.json           # capability operation, message, rule and schema versions
validation/evidence.json      # CI/test report references, not secrets
```

Package contains **logical binding keys**, never PROD passwords, endpoints or raw Kafka broker credentials.

## Lifecycle

`Draft -> InReview -> Approved -> Published -> Active -> Retired`. Published versions are immutable, named by package digest. For new changes clone into a new draft. Existing runs keep their exact version pins; in-flight migration is deferred. Retirement prevents new starts but leaves evidence and necessary old version artifacts available for active runs/audit.

## Promotion recipe

1. Author builds a draft in DEV, validates BPMN, operation/rule/schema bindings and allowed policies.
2. CI executes repeatable unit/BPMN/API/contract/role-deny/failure regression; captures signed or trusted evidence refs.
3. Workflow reviewer/authorized approver reviews exact digest, diff, ticket reference and tests.
4. Trusted pipeline creates an immutable package and verifies issuer/integrity.
5. UAT installs **the same bytes** by digest; environment-specific logical mappings are resolved from UAT-approved binding set and smoke tests run.
6. Release Operator requests PROD preflight; system validates manifest signatures, deployed compatible handlers, approvals, environment binding sets, bank control checks and separation of duties.
7. Only authorized Operations actor or approved automation activates the exact digest; audit records actor, UTC, environment, change reference, approvals and result.
8. Rollback activates prior approved package for **new runs**; it does not automatically reverse CyberArk writes already done.

## Release gates

A placeholder ticket, `approved:true` in a JSON fixture, or passing DEV tests is **not** authorization for PROD. If an actual bank CA/control remains unresolved, report it as a blocker; do not bypass. If the required dependency library isn't approved, cannot include it in release.

## Versions

- Workflow definition version: executable process semantics.
- AMIE ruleset version: fixed configuration and rule output contract.
- Capability operation contract version: stable IO shape and authorization rules.
- Capability binary version: deployed code implementing contract.
- Kafka message schema version: serialization compatibility.
- App configuration package digest: immutable collection of exact dependencies.

New runs reference pinned dependency lock. The engine must fail gracefully if a required deployed contract is unavailable.

<!-- END SOURCE 023: docs/architecture/09-RELEASE-PACKAGES.md -->

---

<!-- BEGIN SOURCE 024: docs/architecture/10-DCMS-VERTICAL-SLICE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 10 — DCMS Acceptance Scenario (Workload, NOT BOB Core)

**Business facts supplied by user:** CSV is imported into a table; table is grouped by batch number; each row receives a GUID; one row at a time is processed; matching CyberArk account is fetched; CSV custom attribute values are added/replaced **in memory**, then account add/update is submitted; final emailed report enumerates success/failure with reasons. Future ingest through API/approved DB source/AutoSys schedule is an idea, not current capability. Onboarding and hygiene are similar but configurable workloads.

## Configuration blueprint

- Application key `DCMS` (illustrative).
- Central workflow `DCMS.BatchCoordinator`: start -> ingest/stage -> start CyberArk embedded batch -> await correlated outcome -> aggregate persisted results -> Reporting Generate -> Email RequestNotification -> complete.
- Embedded workflow `DCMS.ProcessAccountRow` or `CyberArk.ProcessAccountBatch`: fetch staged row -> `CyberArk.GetAccount` -> `AMIE.Eligibility` -> gateway -> `AMIE.MapCustomAttributes` -> `CyberArk.ApplyCustomAttributesInMemory` -> `CyberArk.AddOrUpdateAccount` -> persist row result -> advance sequential iterator.
- Trigger P0: authorized BE CSV upload or API start; future API pull/DB integration/scheduler normalize to same workflow start envelope.
- Data owner: DCMS staging capability or approved Database Capability; **not** BOB core.

## Data model

`Batch` fields: `BatchNumber`, `ApplicationKey`, `InputArtifactRef`, `SubmittedBy`, `SubmittedAtUtc`, `Status`, `TotalRows`, `ConfigurationPackageDigest`, `RunId`.

`BatchRow`: `RowGuid`, `BatchNumber`, `SourceRowNumber`, `AccountRef`, `PayloadRef`, `RowStatus`, `AttemptCount`, `ReasonCode`, `SafeReason`, `CompletedAtUtc`, `ExternalOperationRef`, `LastKnownCyberArkRevision`, `CorrelationId`. SQL constraints: unique `(BatchNumber, RowGuid)`, unique `(BatchNumber, SourceRowNumber)`; resolve re-upload/idempotency by accepted business policy.

## Data flow and failure conditions

1. **Upload:** reject malformed CSV, invalid encodings, missing headers, over-limit size, unauthorized users, unsupported rows. Store original safely with retention policy. Record upload actor, digest and source.
2. **Stage:** assign batch number and row GUIDs; record counts. All-or-nothing staging preferred where feasible; failures return actionable result.
3. **Dispatch:** central BOB saves `BatchStarted` state + outbox, sends approved Kafka request referencing batch and pinned embedded workflow.
4. **Process:** embedded BOB sequentially claims rows via approved API/page; local account read -> AMIE decisions -> in-memory patch -> CyberArk write. Do **not** send entire staged dataset through Kafka.
5. **Record:** `Succeeded` after confirmed external outcome; `NoChange` if already matches; `Skipped` when explicitly allowed by business rule; `Rejected` invalid/unauthorized data; `Failed` confirmed failure; `UnknownExternalOutcome` if write may have succeeded but confirmation is lost.
6. **Recover:** on crash/duplicate event, inspect persisted row ID, external operation ID and target state before reattempt. Never auto-retry an uncertain CyberArk write.
7. **Finish:** report from **persisted row outcomes**, not from number of events emitted. Include counts, row IDs, safe failure reasons; policy for unresolved outcomes must be explicit, not hidden.
8. **Notify:** Reporting Capability returns secure artifact ref; Email Capability receives approved notification command and emits delivery outcome. Notification failure does not turn successful account updates into failures.

## UI walkthrough summary

See `docs/ui/03-DCMS-CONFIGURE-AND-RUN.md`: create DCMS application, assign ownership, import CSV schema, select ingest operation, bind CyberArk subworkflow, map AMIE input/output, bind reporting and Email Capability, publish DEV draft, start, inspect business counts, then inspect technical trace and results.

## Primary regression fixtures

Small CSV with 5 rows: one success, one no-change, one missing account, one invalid AMIE mapping, one uncertain write. Validate counts, no duplicate effects, per-row reason, report content, Kafka correlation, audit history, safe pause/restart, role restriction. Use mock CyberArk adapters in CI; reserved controlled integration tests require approved nonproduction account fixtures.

## Second application reuse

Hygiene/Policy Drift: inspect CyberArk accounts -> AMIE check policy -> optionally route to approved `MoveAccount` operation after explicit authorization -> persist compliance evidence. Reuse same registered `GetAccount` and BOB+AMIE runtime; policy-specific rules live in application package. If `MoveAccount` isn't implemented/approved, **only read-only detection** is a permissible demo.

<!-- END SOURCE 024: docs/architecture/10-DCMS-VERTICAL-SLICE.md -->

---

<!-- BEGIN SOURCE 025: docs/architecture/11-API-REGRESSION.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 11 — API-First Functional Regression Standard

**Every BE action must have a secured backend API.** Every capability operation must have a typed invocation contract and test fixture. Kafka message handling is contract-testable; read models provide query APIs. UI cannot be sole way to publish, start, inspect or operate.

## API route groups (illustrative; validate against existing routes)

- `GET /api/v1/capabilities`, `GET /api/v1/capabilities/{capabilityKey}/operations`, `GET /api/v1/operations/{key}/versions/{version}`.
- `POST /api/v1/workflow-drafts`, `PUT /api/v1/workflow-drafts/{id}`, `POST /api/v1/workflow-drafts/{id}/validate`, `GET /api/v1/workflow-definitions/{key}/versions`.
- `POST /api/v1/workflow-versions/{id}/submit-review`, `POST /api/v1/workflow-versions/{id}/publish` (after policy and approvals).
- `POST /api/v1/workflow-runs`, `GET /api/v1/workflow-runs/{runId}`, `GET /api/v1/workflow-runs/{runId}/activities`.
- `POST /api/v1/workflow-runs/{runId}/pause`, `/resume`, `/cancel`, `/retry`, `/restart` with expected revision, reason, actor context from auth, and commandId.
- `POST /api/v1/inputs/uploads`, `GET /api/v1/business-batches/{batchId}/summary`, `GET /api/v1/business-batches/{batchId}/rows` (paged, scoped).
- `GET /api/v1/audit/events?runId=...`, `GET /api/v1/controls/runbooks/{key}/versions`, `POST /api/v1/release-candidates/{id}/preflight`, `POST /api/v1/releases/{id}/activate`.

These represent *API families*, not a commitment to distinct controllers per family. Avoid overbuilding; use existing application conventions.

## Contract test layers

1. **Unit:** metadata builder, operation resolver, binding validator, BPMN parser/compiler, AMIE adapter with real engine, state machine.
2. **Component:** SDK handler invocation with DI, authorization, serialization, audit and idempotency; Blazor forms display schema-required fields.
3. **Integration:** Kafka broker fixtures, MSSQL migrations/outbox/inbox, process restart recovery, service identity permission checks.
4. **E2E:** BE API create workflow->validate->publish->start->status->audit->report/email with safe test capability.
5. **Negative:** unauthorized/cross-scope, unknown operation, schema drift, invalid BPMN element, missing rule version, invalid ticket/approval, duplicate command, uncertain write and resume races.
6. **UI:** browser clickthrough with accessible selectors, screenshot of error/success, reconnect after status push loss, non-technical progress dashboard and technical trace.

## Evidence capture

Attach redacted API request/response, expected/actual outcomes, exact package digest, test fixture version, run ID, service versions, UTC, CI build URL, screenshots for user flow, and rejection response for negative controls. Bank control evidence may require additional artifacts; get actual control owners to decide.

## Acceptance criterion

An automated test can exercise every action shown in the BE navigation **without clicking through UI**. Automated tests can also invoke the same operations through authorized APIs and verify audit and business projections. CI must fail on schema mismatch, missing policy, unsupported BPMN semantics or broken correlation.

<!-- END SOURCE 025: docs/architecture/11-API-REGRESSION.md -->

---

<!-- BEGIN SOURCE 026: docs/architecture/12-DELIVERY-BOUNDARIES.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# 12 — Delivery Boundaries and Deliberate Deferrals

## November demo P0

- Existing AMIE adapter, typed rule metadata and execution in embedded capability.
- One actual compiled capability handler, startup registration, approved manifest discovery, schema-rendered BE operation inspector.
- Validatable/executable BPMN 2.0 subset, central/embedded BOB same core, MSSQL state and event history, Kafka command/outcome.
- Blazor workflow library/designer usable enough to configure and save/validate/publish **supported** nodes, not fake unconnected buttons.
- Authorized start/upload/API, business progress dashboard, basic BPMN run monitor, operator pause/resume/cancel, useful audit and ServiceNow ticket metadata.
- DCMS vertical slice CSV->batch/row GUID->CyberArk read/map/in-memory write->persist row outcome->report/email.
- CI API, contract, negative auth, failure recovery tests, package/change evidence; one pilot demo.

## P1 target where feasible

- Second workflow (Hygiene or Onboarding) reusing same handlers and runtime unchanged.
- Retry/restart operator UI with full safety and reconciliation; schema-driven human task forms; basic timers and schedule trigger; richer runbook editor.
- Improved canvas polish, drag connections, templates and diagnostics after backend correctness.

## Later backlog

- All BPMN 2.0 constructs (parallel gateways and joins, compensations, signals, complex boundary events, collaboration/pools), advanced multi-instance, run migration, full ServiceNow and AutoSys integrations, full portable rule editor if existing AMIE UI lacking, additional DB providers (excluded for BOB), multi-region coordination, SQL Ledger if bank approves, visual diff and complex merge.

## Critical early decisions

1. Exact existing AMIE evaluation/serialization/version interfaces.
2. Real deployed CyberArk operations and authentication/approval boundaries.
3. Existing Kafka schema/consumer libraries + approved topic provisioning.
4. Existing approved BPMN designer components vs first-party Blazor SVG.
5. Exact business data owner and API for DCMS staging/rows.
6. Release authorizer/control owner, environments, evidence retention.

## Stop/go

No code release without real bank controls; no demo assertion of live integration if using mocks. If time forces cutbacks, remove P1 features before reducing safety-critical correctness, audit or authorization. Avoid a beautiful designer that cannot execute valid definitions.

<!-- END SOURCE 026: docs/architecture/12-DELIVERY-BOUNDARIES.md -->

---

<!-- BEGIN SOURCE 027: docs/ux/09-BLAZOR-SHELL-CATALOG.md -->

# UX 09 — Shared Blazor Shell, Application/Catalog Hierarchy and Navigation

## Design principles
Existing BE Blazor components/routes win if compatible; audit first. Standard shell: top bar `Unity | Environment | Application/Capability context | Search | My Tasks | Profile`; sidebar `Workbench, Applications, Capabilities, BOB Designer, AMIE, Run Monitor, Reports, Administration, Release Center, Audit`; breadcrumb and persistent detail-panel tabs. Keep filters when navigating back. Keyboard focus, accessible error summaries, empty/loading/forbidden states and correlation IDs on error. **All clickable controls must have a real authorized backend action**; clickable HTML prototype is only a mock.

### Catalog wireframe (desktop; responsive left drawer on small screens)
```text
+-------------------------------------------------------------------------------------------+
| Unity  [DEV v]  Scope:[PAM v]  Search [workflow/capability/rule ....]  [My Tasks] [User]    |
+---------------------+---------------------------------------------------------------------+
| Workbench           | Applications > PAM > Onboarding                   [New Workflow]    |
| Applications        | Filters: [L1/L2 v] [Category v] [Owner v] [Status v] [Search...]       |
|  PAM                | +---------------------+-------------------------------------------+ |
|   Onboarding        | | COLLECTIONS         | NAME / VERSION / STATUS / GROUPS / OWNER    | |
|   Hygiene           | | > Onboarding        | Account Onboarding  v2.1  Approved  PAM  | |
|   Governance        | | > Hygiene           | Safe Creation       v1.4  NonProd   PAM  | |
| Capabilities        | | > Governance        | ...                                       | |
|  CyberArk           | | > Shared Library    |                                           | |
| BOB Designer        | +---------------------+-------------------------------------------+ |
| AMIE                | [Open] [Duplicate Draft] [View Dependencies] [Access] [Versions]    |
| Run Monitor         | Detail: Overview | Operations | Rules | Groups | Runs | Audit       |
| Release Center      |                                                                     |
+---------------------+---------------------------------------------------------------------+
```

## Screen S09-01 — Workbench
**Purpose:** User finds permitted actions and active requests. **Entry:** shell default. **Tabs:** My Workflows, My Runs, My Approvals, My Reports. **Controls:** context selector; pinned apps; recent runs; New Request; Resume Draft; View Status; Search. **Interactions:** select application filters without changing auth; New Request only offered when Execute; My Approvals only eligible pending tasks; Refresh fetches authoritative run projection. **Negative test:** direct API returns 403 when user lacks entitlement even if route is typed manually.

## Screen S09-02 — Application workspace
**Purpose:** owner-scoped L1 workflows in configurable collections and tags. **List columns:** Name, Level, Category, Version, maturity/stage, Active environment, entitlement summary, owner, updated. **Actions:** New workflow draft, browse version history, select category, linked rules, export, open monitor, assign group (authorized admin). A workflow has one owning app but multiple consuming associations; move category without changing identity. **Empty/invalid:** no permission vs no workflows explicitly distinguished.

## Screen S09-03 — Capability workspace
**Purpose:** owner sees operations and L2 workflows together. **Tabs:** Overview, Operations, Workflows, AMIE Rules, Service Account/API Config, Versions, Permissions, Activity. **Actions:** Open operation inspector, Add owned workflow, Browse Shared Library; assign approved operation to workflow. **No giant global workflow list** until opt-in search. **Backend:** filter by stable capabilityId and authorized scope; do not infer from tags.

## Screen S09-04 — Collection/category administration
**Purpose:** create/edit tree of Onboarding, Hygiene, Governance, Policy Drift, Reporting and custom categories. **Fields:** categoryKey/display, owner scope, parent, sort order, allowed resource levels, status, description, tags. **Controls:** Add, Rename, Move, Retire, Preview affected resources; no permission inheritance by default. **Save:** optimistic concurrency, audit; reject duplicate key, cyclic parent, orphan removal without migration plan.

## Common admin UX
Every resource uses a consistent detail header with owner, environment, version, maturity-stage, activation and experimental warning. Standard tabs `Overview | Configuration | Dependencies | Groups | Versions | Tests | Audit`. Contextual toolbar `Save Draft / Validate / Test / Request Review / Promote`, with disabled reasons rather than silent hidden controls when appropriate. Audit diff with actor/time/changeRef and before/after redacted fields.

## Proposed API surface (verify against repo)
`GET /applications?scope`, `GET /catalog/resources?ownerId&level&category`, `GET /capabilities/{id}/workflows`, `POST /workflow-drafts`, `PUT /catalog/categories/{id}`, `GET /resources/{id}/dependencies`, `GET /me/entitlements`. All endpoints authorize per resource; pagination, ETag and stable IDs mandatory for mutations.

## Acceptance
From PAM Onboarding navigate to workflow, related CyberArk capability, its operation inspector, associated AMIE rule, and back without losing context; register new category without code change; standard 403 and empty states; no client-maintained list of all enterprise workflow definitions.

<!-- END SOURCE 027: docs/ux/09-BLAZOR-SHELL-CATALOG.md -->

---

<!-- BEGIN SOURCE 028: docs/ux/10-BPMN-DESIGNER-WIREFRAMES.md -->

# UX 10 — Full BPMN 2.0 Designer, Palette, Experimental Mode and Inspector Wireframes

## Designer shell
```text
+------------------------------------------------------------------------------------------------+
| PAM > Onboarding > Account Onboarding v2.2 (Draft)   [DEV] [Experimental OFF] [Save] [Validate] |
+-----------------------+---------------------------------------------------+--------------------+
| BPMN PALETTE          | CANVAS                                            | INSPECTOR          |
| [Search nodes...]     | Start --> Validate --> XOR --> Service --> End   | Selected: Service  |
| Events                |   (pool / lanes / DI coordinates)                 | Name, ID, scope    |
|  Start End Timer      | Parallel fork -> 2 tasks -> join                  | Capability         |
| Activities            | Boundary timer/error attachment circles          | Operation@version  |
|  Service BusinessRule | [Zoom][Fit][Undo][Redo][MiniMap]                  | Input/Output map   |
|  UserTask Call/Sub    |                                                   | Error/timer        |
| Gateways              |                                                   | Retry/policy       |
|  XOR Parallel         |                                                   | Group entitlements |
| Data / Pools / Lanes  |                                                   |                   |
| Experimental nodes*   |                                                   |                   |
+-----------------------+---------------------------------------------------+--------------------+
| Issues: 2 errors, 1 experimental warning | Versions | Rule Trace | Test Bench | Publish Review |
+------------------------------------------------------------------------------------------------+
```
**Implementation:** reuse/validate an approved BPMN modeling library (e.g. bpmn-js if compatible with existing Blazor framework and dependencies); do not build drag/drop BPMN geometry from scratch without an approved reason. Actual canvas uses BPMN XML/DI, not schematic node-order JSON.

## Full palette inventory and planned semantics
| BPMN group | Model/import and DI support | Phase 1 executable | Deferred/Experimental handling |
|---|---|---|---|
| Events | Start, End, message, timer, signal, conditional, error, escalation, terminate, link, compensation, cancel, multiple/parallel-multiple | Simple Start/End, intermediate Timer Catch, interrupting Timer Boundary, interrupting Error Boundary, current Kafka outcome wait | All other events tagged Experimental until handler passes conformance; precise subtype support matrix mandatory |
| Activities | Task, service, business rule, user, receive, send, script, manual, call, subprocess, event subprocess, transaction, ad hoc, multi-instance | Service, AMIE BusinessRule, minimum durable UserTask, Call, embedded subprocess, sequential multi-instance | Script/custom user code never executable; receive/send if not implemented; parallel multi-instance, event subprocess, transaction, ad hoc as experimental |
| Gateways | Exclusive, Parallel, Inclusive, Event-based, Complex | Exclusive, Parallel split/join | Inclusive/EventBased/Complex experimental, no fake XOR fallback |
| Collaboration | Pools, Participants, Lanes, message/sequence flows | Lane membership and sequence flow in single executable pool; Kafka outcome waiting mapped via registered adapter | Multiple executable participant orchestration/message flow behaviors experimental; preserve XML/DI |
| Data & artifacts | Data object/reference/store, properties, input/output associations, groups, text annotation | Typed variables, mappings, selected data objects | Preserve representation; semantic data-store execution only if explicit supported handler |
| Extensions | Extension elements/attributes, diagram geometry, BPMN XML namespaces | Approved Unity binding IDs + version refs | Preserve unrelated XML where safe; no arbitrary code or unknown execution fallback |

**Strict BPMN correctness:** sequence flow crosses lanes but not pools; message flow links participants; lanes do not inherently map to Kafka topics or execution hosts. Boundary event attached to an activity; noninterrupting boundary appears dashed as standard notation. DI must preserve coordinates, waypoints and stable IDs.

## Feature flag and visual treatment
`Experimental Mode` is an admin-authorized editor-level toggle: OFF hides/de-emphasizes unsupported palette creation; imported experimental nodes still show with warning. ON displays standard elements marked `(Experimental)` with amber badge and explanatory tooltip. A workflow including even one unapproved element displays persistent `Contains Experimental BPMN` banner, list of node IDs, Jira link and environment execution eligibility; save/export available but not PROD activate. A third state NonProd-Approved is maturity policy, not a new unsupported fallback.

## Inspector behavior by node type
- ServiceTask: select capability -> approved operation/version -> input JSON Schema fields -> output variable bindings -> auth/host/side-effect badge -> timeout/retry/error mapping -> test fixture.
- BusinessRuleTask: AMIE application/category filtered picker -> pinned rule version -> typed facts/output -> decision trace preview.
- UserTask: form/approval policy ref -> eligible group(s) -> any-one/all -> backup group -> due policy -> approve/reject response schema.
- ExclusiveGateway: labeled condition for every outgoing path and explicit default; condition authored as constrained expression/AMIE output binding, not arbitrary code.
- ParallelGateway: split/join usage and graph analysis; show warning on potentially unstructured synchronization paths.
- TimerCatch/Boundary: date/duration selector, UTC handling, due preview, interrupting icon, attached activity reference, cancellation warning.
- ErrorBoundary: matching BPMN error code mapping from operation/AMIE definition and outgoing flow; unmatched behavior.
- CallActivity: choose approved WorkflowDefinition@version, host requirements, typed in/out mapping, same/other scope and recursion detection.
- Pools/Lanes: add/rename participant or lane, move nodes, preserve DI; no implicit service binding.

## Top toolbar click contract
| Control | Preconditions | Expected server/UI outcome |
|---|---|---|
| New/Import | Create entitlement; valid XML format | Draft created with original BPMN IDs/DI, unsupported elements preserved/flagged |
| Save | ETag/revision | Persist XML+DI and bindings; 409 shows compare/recover screen |
| Validate | Any saved draft | Graph, schema, approvals, host, experimental, operation/rule/version checks with node links |
| DEV Test | Authorized + compatible handlers | Explicit fixture/live/mock label; runId, trace, token monitor |
| Experimental Toggle | Feature+role/environment policy | Palette visibility only; no runtime privilege change |
| Request Review | Valid draft/evidence | Human review workflow submission and audit |
| Export BPMN XML | Any authorized readable draft | Download `process.bpmn` with real BPMN XML+DI, not JSON-only mock |
| Export Unity Package | Approved package-draft permissions | BPMN XML+Unity manifest/bindings, content hashes; not auto-signed |

## Negative tests
Malformed XML does not replace draft; move node preserves ID/geometry; wrong cross-pool sequence flow rejected; missing service operation version blocks publish; unsupported event-based gateway prevents runtime despite saved drawing; imported experimental node flagged with correct Jira; timer boundary race returns exactly one path; XML roundtrip retains DI/lanes and unknown safe extension elements; keyboard/focus and screenreader support.

<!-- END SOURCE 028: docs/ux/10-BPMN-DESIGNER-WIREFRAMES.md -->

---

<!-- BEGIN SOURCE 029: docs/ux/11-CAPABILITY-ADMIN-WIREFRAMES.md -->

# UX 11 — Blazor Capability Administration, Operations and Lifecycle

## Intended one-page-first flow
`Capabilities list -> Open capability -> Overview -> Configuration (Operations/Workflows/API reference) -> Development -> Validation -> Approval -> Environment Activation`. All tabs share a persistent resource header with owner, version, combined status, active environment, warnings and last update. User may jump tabs; no forced wizard for ordinary review. For first-time onboarding, optional guided wizard follows same order.

### Screen C11-01 — Capability list
```text
+----------------------------------------------------------------------------------------------+
| Admin > Capabilities                [Search] [Classification v] [Stage v] [Owner v] [Register] |
| Key / Name          Owner          Version      Status                     Env       Actions   |
| CyberArk            PAM            2.0          Approved-ReleaseReady      DEV/UAT   [Open]    |
| Identity API        Identity       1.2          NonProd-Testing            DEV       [Open]    |
| Report Generator    Reporting      0.7          Experimental-InDev         DEV       [Open]    |
|                                                       [Export filtered list]                 |
+----------------------------------------------------------------------------------------------+
```
Examples are hypothetical, not actual environment capabilities. Actions: register draft, compare manifest, inspect operation, check owner and filtered status. No direct user assignment to external provider APIs.

### Screen C11-02 — Capability detail
```text
| Identity API v1.2 [NonProd-Testing]  Owner: Identity   Env: DEV   [Save] [Validate] [Review] |
| Overview | Operations | Workflows | AMIE Rules | API/Service Identity | Development | Audit  |
| Summary: 4 approved handlers / 1 experimental handler; last manifest digest; health status  |
| Operations [Search]  [GetUser@1] [CreateUser@1] [DisableUser@1 Experimental]                |
| Workflows: Local L2 recipes    [Add Workflow] [Browse approved shared recipes]              |
| Service API: Apigee onboarding [pending]  Credential reference [vault://... masked]         |
| Access: Register/Configure entitlement groups (Unity); service identity external grant      |
```

### Screen C11-03 — Development / Validation / Approval
`Development` selects classification Experimental, NonProd, Approved and stage InDev, Testing, Verified, ReleaseReady; shows combined status and required evidence/known limitations. `Validation` shows contract, unit/integration, dependency, authorization, broker, host and scope checks with machine-readable failures. `Approval` shows requested transition, current version owner, reviewer, evidence, request reason, decision and audit. Approval does not automatically activate. Show copyable Jira/milestone link without making ticket maintenance a UI prerequisite for every user action.

### Screen C11-04 — Operation inspector
Tabs: Input Schema / Output Schema / Permissions / API-Transport / AMIE Bindings / Retry and Reconcile / Version History / Tests. Required field editor generated from type schemas. Side effects visually clear (Read, LocalTransform, ExternalWrite, HighImpactExternalWrite). `Add to Workflow` inserts a service task with pinned operation ID and typed bindings; no free-form arbitrary HTTP or CLR class-name input. Test operation uses approved DEV fixtures and labels real external write versus simulated result.

### Screen C11-05 — Capability registration wizard
1. Select owning department/application and name/stable capability key.
2. Choose SDK registration or external REST/Kafka adapter; identify trusted deploy identity and contract schema.
3. Inspect generated handler manifest and operation versions; validate unique keys and schemas.
4. Configure environment and service-account/gateway *references*, topic/message descriptors, policy scope, redaction and health probe.
5. Validate with negative authorization/contract test; submit for review. Registry becomes discoverable only according to approval/activation policy.
6. Go to Workflows to create/view L2 recipes without opening all enterprise workflows.

### Screen C11-06 — Capability registration and configuration groups
Admin selects existing Unity group(s) for `Capability.Register` or `Capability.Configure` within owner scope; AMIE may add policy restrictions; these grants are distinct from users' workflow Execute/Read/Create. Show effective permission preview and audit. Do not require an external provider to add each human user to its service-account/API controls.

## Proposed server actions, to reconcile in code audit
`GET /capabilities`, `GET /capabilities/{id}/operations`, `POST /capabilities/manifests/drafts`, `POST /capabilities/{id}/validate`, `POST /capabilities/{id}/review-requests`, `POST /capabilities/{id}/activate`, `GET /capabilities/{id}/workflows`, `GET /capabilities/{id}/audit`.

## Error/empty behavior
Register collision, missing handler, untrusted manifest, disabled operation, service unreachable, API target unknown, UAT policy restriction, invalid status transition, stale ETag, or group denial all produce explicit actionable nonsecret errors. A Registered manifest without approved code/availability must not appear as executable operation.

## Acceptance
Admin can register example capability, approve one operation for DEV, mark another Experimental, bind approved operation to an L2 workflow and link to L1; unauthorized user cannot configure or invoke outside workflow; human entitlement scope is enforced independently from external service account access.

<!-- END SOURCE 029: docs/ux/11-CAPABILITY-ADMIN-WIREFRAMES.md -->

---

<!-- BEGIN SOURCE 030: docs/ux/12-AMIE-APPROVAL-WIREFRAMES.md -->

# UX 12 — Proposed AMIE Blazor Rule Library, Human Approvals and Group Assignment

**Review status:** design candidates for Matthew, not authoritative replacement of any working AMIE screen. Keep/modify/reject individually. Existing rules and groups are assumed to be implemented at least partially; inspect actual paths before extending.

### Screen A12-01 — AMIE rule library
```text
+-----------------------------------------------------------------------------------------------+
| Unity / AMIE  Context: [PAM v]  Search:[........]  Type:[Approval Policy v] [Version v] [New] |
+---------------------------+-------------------------------------------------------------------+
| Application/Capability    | Rule: PAM.CreateAccountEligibility @ 2.1 [NonProd-Verified]        |
| > PAM                     | Type: Eligibility     Owner: PAM      Consumer: 4 workflows        |
|    > Onboarding           | Inputs: Request.AccountType, Request.Owner; Outputs: Allow, Reason |
|      Eligibility          | [Conditions] [Facts] [Test] [Consumers] [Version History] [Audit] |
|      Approval Policies    | Linked workflow: PAM.AccountOnboarding v2.0   [Open in BPMN]        |
|      Mapping              |                                                                   |
|    > Hygiene              | [Save Draft] [Validate] [Request Review] [Compare Versions]       |
| > CyberArk Capability    |                                                                   |
| > Shared Rule Library     |                                                                   |
+---------------------------+-------------------------------------------------------------------+
```
Add filters by application, category, rule type, owner, approved environment, stage, and used-by. The list defaults to current application/capability, not all enterprise rules. Selected rule has schema-based conditions editor or links to Matthew's current editor; do not rewrite rule grammar. Versions immutable after publication.

### Screen A12-02 — Rule configuration and test
Fields owner, category, rule key/version, trigger/consumer type, typed input facts/output schema, conditions, policy dependencies, group restrictions, test cases, current version and change history. `Run Test` accepts redacted fixture and shows decision, reason codes, version, evaluation duration, trace ID; distinguish mock from live AMIE engine. `View Consumers` lists BOB workflow versions and capability recipes pinned to the rule.

### Screen A12-03 — Approval Policy builder
```text
| AMIE > Approval Policies > PAM.PrivilegedAccount.CreateApproval v2.0 [Draft]                  |
| Conditions: accountType=privileged, highRisk=True  [Test decision]                            |
| Stage 1: Application Owner  [Group:PAM.AppOwners v] [Backup:PAM.Backups v] [AnyOne v]        |
|           [Add backup] [Set SLA] [Reject path: Reject]                                        |
| Stage 2: Security           [Group:PAM.Security v]  [Backup:SecBackup v] [AllRequired v]     |
|           [Required count:2] [Change order] [Remove stage]                                   |
| Stage 3: Operations         [Group:PAM.Ops v]      [Optional based on rule]                   |
| [Add Stage] [Preview Approval Plan] [Validate] [Submit for Rule Review]                       |
```
AMIE rule returns typed approval stages. BOB creates durable HumanTask records and consumes decisions. BE work queue enforces eligible group + current actor, captures approve/reject and comment/reason, and resumes BOB after stage satisfied. Do not use AMIE as a second durable waiting engine.

### Screen A12-04 — Workflow-to-group assignment
On a workflow `Groups & Access` tab choose existing Unity group(s), role Read / Execute / Execute-Lead / Create, rule restriction (optional), env eligibility DEV/UAT/PROD, active dates/version and preview effective access. Show warning for policies that give lead visibility across unintended groups. Provide search/add/remove groups and impact review; changing grants never silently changes current workflow definition version.

### Screen A12-05 — Approval work queue
`My Approvals / My Group / History`, title, request ID, workflow version, current stage, eligible group, backup status, due date, initiator, allowed decision buttons. Clicking task shows redacted request, AMIE decision and rule version, prior stage outcomes, reason field. Unauthorized actor cannot approve through API even if link known; duplicate decision is idempotent; reject path clear. Backup assignment behavior tested, not inferred from UI.

### Screen A12-06 — Intake-to-execution trace (Printable)
AMIE intake message ID -> validated/enriched facts -> rule/version decision -> selected workflow/version -> BOB instance ID -> gateway/task decisions -> capability command/outcome IDs -> completion/report. Redact protected facts. Buttons `Copy Correlation ID`, `Print`, `Export Redacted Trace`, `Open BPMN Monitor`, `Open AMIE Rule`; resource-scoped authorizations. This is for troubleshooting and eventual policy drift evidence.

## Proposed click contract
| Control | Backend intent | Evidence and denial |
|---|---|---|
| AMIE New Rule | Create versioned draft in existing AMIE editor/registry | ETag, creator, authorized owner scope |
| Bind to BPMN | Request typed rule descriptor and pin exact version | Schema type check and dependency history |
| Approval Preview | Evaluate AMIE policy against redacted fixture | No durable approval task created |
| Submit Approval Request | Create BOB task using approved AMIE plan | BOB owns state, actor/time audit |
| Approve/Reject | Authorized decision against pending BOB task | Duplicate/unauthorized rejected, audit reason |
| Assign Group | Versioned entitlement association update through owning API | No direct group membership creation |
| Print Trace | Read authorized redacted AMIE/BOB/capability correlation | Download/print permission checked |

## Acceptance and review
Matthew marks each proposal `Keep Existing / Adopt / Modify / Reject` and identifies current route/component implementation. Phase 1 integrates via compatible existing APIs; source audit and later refactor separately planned. User guide must cover both rule authoring and workflow binding without requiring users to edit database tables.

<!-- END SOURCE 030: docs/ux/12-AMIE-APPROVAL-WIREFRAMES.md -->

---

<!-- BEGIN SOURCE 031: docs/ux/13-RUN-MONITOR-RELEASE-WIREFRAMES.md -->

# UX 13 — BPMN Run Monitor, Group Reports, Human Task Inbox and Production Import

### Screen R13-01 — Run monitor
```text
| Workflows > PAM.AccountOnboarding > Run 8f... [Running] [v2.1] [DEV]                         |
| [BPMN Diagram Overlay] [Timeline] [Variables (redacted)] [Commands] [Errors] [Audit]           |
| Active tokens: AD branch [Succeeded] / CyberArk branch [Waiting] / Reporting [Running]          |
| Timers: CyberArk timeout due 22:00Z   | Last Kafka outcome: command-7   | Join pending 2/3   |
| [Pause] [Resume] [Cancel with Reason] [Restart as New Run] [Export authorized trace]             |
```
Run status uses backend-authoritative snapshot; SignalR/SSE are change hints and reload after reconnection. Multiple concurrent tokens shown without implying ordered execution; boundary timer and error routes distinct from successful join. Unknown external outcome warning cannot be marked success from timer expiry. Pause/resume/cancel require authorized user, reason, safe checkpoint and audit.

### Screen R13-02 — Reports and Execute-Lead scope
`Mine | Group | All (authorized only)` tabs. Read sees permitted results, Execute sees its own run/report data, Execute-Lead sees authorized members of assigned groups but no unrelated group. Data owner may apply classification redaction. Row-level filters at API and projection service, not UI. Printable/downloadable report requires separate release of sensitive fields where classified.

### Screen R13-03 — Release center
```text
| Unity / Release Center                       Environment: [UAT v]                            |
| [Drafts] [Validation] [Packages] [Imports] [Activations] [History]                           |
| Package: PAM.AccountOnboarding v2.1 [Approved-ReleaseReady]                                 |
| process.bpmn XML+DI [OK] | Unity bindings.json [OK] | AMIE@2.0 [OK] | CyberArk@2.4 [OK]       |
| Hash [OK]  Signature [verified with trusted release key?] [pending if unavailable]            |
| Experimental nodes [NONE] | Test evidence [attached] | ServiceNow ID [CHG......]             |
| [Validate Import] [Request Review] [Import Artifact] [Activate Approved Version]              |
```
DEV/UAT import preview supports negative tests. PROD activation requires approved trusted signer/enterprise release mechanism, current eligible entitlements, required approvers and nonempty ServiceNow change ID. Field presence is validated, not live ServiceNow ticket status. **Import does not equal activate**. If signature/trust chain is unavailable, PROD import/activation remains unavailable rather than faking protection with a key embedded in XML.

### Screen R13-04 — Release history and rollback
List environment, activated immutable version, content digest, active alias, actor, approver, change ID, tests, old version and activation time. `Rollback` creates new authorized activation event pointing to prior approved content; no overwriting old artifacts or migrating current runs silently. Audit export and drift baseline supported.

### Screen R13-05 — Group resource administration
Search existing groups (Matthew's store in DEV; future Channel Secure mapped identities) with environment, description, source, active status and assigned resource counts. Select group to view permitted workflow scopes, capability Register/Configure, rules, preview effective permissions, changes. Admin can assign to workflows and rules, not manage external API users. Environment configuration import offers dry-run diff, validation, approval and audit.

## Error/empty state and tests
Mismatch BPMN+DI, missing rule/operation version, missing change ref, invalid signature, expired authorization, UAT-only resources in PROD, concurrent version change, non-eligible group, report forbidden, late Kafka result after interruption, and unverified readiness each have explicit blocked action and reason. No placeholder green check may be shown without verification.

<!-- END SOURCE 031: docs/ux/13-RUN-MONITOR-RELEASE-WIREFRAMES.md -->

---

<!-- BEGIN SOURCE 032: docs/contracts/14-EVENTS-APIS-AND-BINDINGS.md -->

# Contracts 14 — Type-Safe API, AMIE/BOB Intake, Kafka Commands and Registry Bindings

**Important:** Illustrative versioned contracts, not verified API routes. Reconcile existing SDK, AMIE, BOB and gateway conventions in M0; preserve compatibility. Never use a BPMN extension to execute arbitrary CLR class, URL, SQL statement or credential.

## 1. AMIE intake -> BOB request
```json
{
  "schemaVersion": "1.0",
  "requestId": "req-1001",
  "correlationId": "corr-1001",
  "idempotencyKey": "pam-create-1001",
  "environment": "DEV",
  "initiatorRef": "actor-ref-33",
  "source": "AMIE.Intake",
  "selectedWorkflow": {"key": "PAM.AccountOnboarding", "version": "2.1.0"},
  "decision": {"ruleSetKey": "PAM.IntakeRouting", "version": "1.7.0", "reasonCodes": ["ROUTE_PAM"]},
  "enriched": {"schemaRef": "PAM.AccountRequest@2", "dataRef": "redacted-approved-data-ref"}
}
```
Authenticated publisher, source schema, classifications, approved definition/version, environment and effective execution entitlement are verified again by BOB. Unknown version, spoofed initiator, replay or mismatch -> reject and audit. A rule may choose an active version alias only if BOB resolves and pins that approved version atomically at start.

## 2. BOB -> AMIE typed evaluation
```json
{
  "ruleKey": "PAM.CreateEligibility", "ruleVersion": "2.1.0",
  "factsSchema": "PAM.EligibilityFacts@2", "facts": {"accountClass": "service", "environment": "DEV"},
  "context": {"workflowRunId": "run-123", "activityId": "rule-4", "correlationId": "corr-1001"}
}
```
Result: decision enum and typed properties, safe reason codes, rule digest/version, trace ID. Use existing AMIE adapter's actual message format after reconciliation, with local cache permitted in embedded host.

## 3. Kafka approved operation command and outcome
```json
{
  "commandId": "cmd-901", "workflowRunId": "run-123", "scopeId": "scope-1", "tokenId": "token-4",
  "operation": {"capabilityKey": "CyberArk", "operationKey": "AddAccount", "version": "2.4.0"},
  "packageDigest": "sha256:...", "correlationId": "corr-1001", "causationId": "task-7",
  "idempotencyKey": "run-123-task-7", "deadlineUtc": "2026-11-16T18:00:00Z",
  "actorContextRef": "actor-ref-33", "payloadSchema": "CyberArk.AddAccountInput@2", "payloadRef": "protected-ref"
}
```
```json
{
  "commandId": "cmd-901", "correlationId": "corr-1001", "status": "Succeeded",
  "resultSchema": "CyberArk.AddAccountResult@2", "resultRef": "restricted-result-ref",
  "reasonCode": "CREATED", "externalOperationRef": "provider-op-777"
}
```
Expected outcomes `Succeeded`, `NoChange`, `Rejected`, `Failed`, `UnknownExternalOutcome`; BPMN error mapping is a separately declared typed policy. Late outcomes after cancelled activity update reconciliation record, not token advancement. Outbox/inbox persist at least once; business logical advancement once by transaction/idempotency.

## 4. Capability manifest sketch
```json
{
  "capabilityKey": "CyberArk", "manifestVersion": "2.4.0", "serviceOwner": "PAM",
  "operations": [{
    "operationKey": "AddAccount", "contractVersion": "2.4.0",
    "inputSchemaRef": "CyberArk.AddAccountInput@2", "outputSchemaRef": "CyberArk.AddAccountResult@2",
    "sideEffectClass": "ExternalWrite", "hosts": ["EmbeddedLocal", "KafkaCommand"],
    "bpmnErrorCodes": ["SAFE_NOT_FOUND", "POLICY_DENIED"],
    "idempotency": "ReconcileBeforeRetry", "serviceIdentityRef": "vault/identity-ref"
  }]
}
```
Registration is not approval or runtime availability. API gateway onboarding, service scopes, health, exact handler version, operation policy and environment activation all required to resolve an invocation.

## 5. Workflow binding example
```json
{
  "workflowKey": "PAM.AccountOnboarding", "version": "2.1.0",
  "bpmnFile": "process.bpmn",
  "bindings": [
    {"bpmnNodeId": "Task_Create", "operation": "CyberArk.AddAccount@2.4.0", "host": "KafkaCommand",
     "inputs": {"account": "${workflow.request.account}"}},
    {"bpmnNodeId": "Task_Eligibility", "rule": "PAM.CreateEligibility@2.1.0",
     "facts": {"accountClass": "${workflow.request.class}"}}
  ]
}
```
`${...}` placeholders here describe a constrained typed mapping syntax; select actual existing expression grammar rather than evaluating arbitrary JavaScript/C#.

## 6. Approval decision / human-task event
`ApprovalPlan {requestRef, ruleVersion, stages:[{eligibleGroupRefs,backupGroupRefs,decisionMode,requiredApprovals,timeoutPolicy}]}`; `HumanTask {taskId,runId,stageId,eligibleGroups,state,revision}`; `TaskDecision {taskId,actorRef,groupProofRef,decision,reason,revision,correlationId}`. Backend rejects stale/duplicate decision and unauthorized approver; BOB resumes when stage criteria satisfied.

## 7. Release artifact
`manifest.json` pins BPMN, AMIE rule, operation and called-workflow versions; `process.bpmn` is actual XML+DI; `bindings.json` contains typed references; `evidence.json` lists validation; digest/signature is generated/validated by trusted release machinery. PROD import requires valid ServiceNow change ID field and verified signer; package itself cannot establish trust by embedding a public/private key chosen by uploader.

## 8. API permission policy
Proposed routes must be reconciled: `GET /applications`, `GET /capabilities`, `POST /capabilities/manifests`, `POST /workflows/drafts`, `PUT /workflows/drafts/{id}`, `POST /workflows/drafts/{id}/validate`, `POST /runs`, `GET /runs/{id}`, `POST /human-tasks/{id}/decisions`, `POST /releases/imports`, `POST /releases/{id}/activate`, `GET /audit/trace/{correlationId}`. Require server-side resource authorization, ETag on writes, input schemas, correlation, audit, no browser-to-Kafka or direct client access to vault/database.

<!-- END SOURCE 032: docs/contracts/14-EVENTS-APIS-AND-BINDINGS.md -->

---

<!-- BEGIN SOURCE 033: docs/contracts/AMIE-RULE-DESCRIPTOR.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# AMIE Rule Descriptor and Typed Binding Contract

**Important:** AMIE is already substantially built. The following is an interoperability adapter target; do not replace its rule representation before JOB-00 source inspection.

- Rule descriptor: `ruleKey`, `version`, `owner`, `approvalState`, `inputSchema`, `outputSchema`, `dataClassification`, `requiredFacts`, `testFixtures`, `compatibleHost`, `dependencyHashes`.
- Evaluation: `Evaluate(existingAmieRequest, pinnedRule, executionContext)` returns typed `RuleOutcome` with `decision`, `reasonCode`, safe diagnostic, output DTO and version actually executed.
- Binding source kinds: `WorkflowInput`, `CurrentItem`, `PriorOperationOutput`, `PriorRuleOutput`, `ApprovedConstant`, `EnvironmentBinding`, `SecretReference` (server-only).
- Binding target: JSON schema path in next operation/rule. Both sides typed and classification checked at compilation and execution.
- Policy: AMIE may advise/update data transformation. It cannot override invocation authorization or a required external-write verification.

For DCMS, example rules `DCMS.AccountEligibility`, `DCMS.MapCustomAttributes`, and `DCMS.ShouldUpdate` map CSV custom attributes, account metadata, and approved update policy. Their actual names, DSL and serialized formats are **unverified**; configure these through existing AMIE authoring mechanisms.

**Acceptance:** changing approved AMIE configuration changes an operation's input/decision in a *new published package* with no BOB Core or CyberArk handler modification. A new rule version is pinned and produces audit evidence. Missing fact, incompatible type or restricted classification blocks publish. Embedded host evaluates locally and correctly.

<!-- END SOURCE 033: docs/contracts/AMIE-RULE-DESCRIPTOR.md -->

---

<!-- BEGIN SOURCE 034: docs/contracts/API-ENDPOINT-CATALOG.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# API Endpoint Catalog and Automation Naming

**Source baseline:** `history/v0.7/contracts/Unity_OpenAPI_Sketch_v0.7.yaml`. Routes here are proposed **families**, not implemented endpoints. Reconcile existing BE/API controllers in JOB-00 and keep OpenAPI accurate from actual implementation.

| Functional capability | Suggested API action | Default test |
|---|---|---|
| Capability discovery | GET /capabilities; GET operation version/schema | descriptor and role-scoped listing |
| Capability registration | POST /capability-manifests/validate; publisher action | wrong signature/owner rejected |
| Application catalog | GET/POST application blueprint/draft | scoped ownership |
| Workflow drafts | GET/POST/PUT draft, import/export BPMN | ETag conflict and XML safety |
| Workflow validation | POST draft/{id}/validate | incompatible AMIE field and unsupported node |
| Workflow lifecycle | submit review, approve, publish, activate, retire | immutable version and maker/checker |
| AMIE | list rules, describe rule, preview with safe fixture | typed outcome/pinned version |
| Triggers | create manual/API/CSV input intent | unauthorized upload/size rejected |
| Runs | POST run, GET run/activity timeline | correlation and pinned package |
| Operators | pause, resume, cancel, retry, restart | reason/role/ETag + audit |
| Business projections | GET batches/summary/rows/reports | user-scope filtering, paged |
| Audit | GET evidence events/export | redaction, no mutate |
| Runbooks and controls | GET versioned runbook and evidence refs | valid version/owner |
| Release | preflight and activate | unchanged digest and real approval |
| Regression | test harness fixtures via CI API | environment-isolated no-prod writes |

For each endpoint publish request/response JSON Schema, HTTP codes, authentication, scope, idempotency and audit requirements. All BE visual actions must map to backend API calls. Automated tests should not depend on UI clicking to prove business rules.

<!-- END SOURCE 034: docs/contracts/API-ENDPOINT-CATALOG.md -->

---

<!-- BEGIN SOURCE 035: docs/contracts/BPMN-WORKFLOW-BINDING.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BPMN XML + Unity Activity Binding Contract

## Data model

**Primary interchange:** OMG BPMN 2.0.2 XML including BPMN DI diagram layout. Use `unity` extension attributes or external signed binding document referencing the BPMN `id`. Do not store only renderer-private nodes and later hope to convert them reliably.

Example *conceptual* metadata for a standard BPMN service task:

```xml
<bpmn:serviceTask id="Task_GetAccount" name="Get account">
  <bpmn:extensionElements>
    <unity:operationBinding key="CyberArk.GetAccount" version="1.0"
                            execution="EmbeddedLocal" />
  </bpmn:extensionElements>
</bpmn:serviceTask>
```

This fragment requires proper BPMN and `unity` namespace declarations in a complete document; see `examples/` for full illustrative fixtures. `unity:operationBinding` is a **proposal**, not an existing runtime extension.

## Activity binding fields

`bpmnElementId`, `activityType`, `operationKey/version` OR `amieRuleKey/version` OR `subprocessKey/version`, `inputBindings`, `outputBindings`, `executionHost`, `timeoutPolicy`, `retryPolicy`, `auditPolicy`, `requiredPermission`. Disallow conflicting operation/rule references. All output bindings reference typed results.

## Compilation rules

Validate BPMN XML and DI; supported element subset; unique node IDs; reachability; token semantics; input/output graph; AMIE rule versions; operation contract versions; host compatibility; environment bindings; permission policy; external side-effect retry classification; no arbitrary scripts/method names/raw SQL; no mutable 'latest' references in published package.

## Result

Create immutable executable graph + dependency lock, tied to BPMN source digest. Core engine executes graph identically from central/embedded hosts; host adapters supply activity dispatch and persistence. Unsupported BPMN node -> publication rejection with `nodeId`, `errorCode`, user guidance.

## Regression fixtures

See `examples/DCMS_Batch_Illustrative_v0.7.bpmn` and `DCMS_Row_Illustrative_v0.7.bpmn`: source illustrations, NOT evidence of BOB execution/conformance. Add fresh executable tests for each engine element actually supported.

<!-- END SOURCE 035: docs/contracts/BPMN-WORKFLOW-BINDING.md -->

---

<!-- BEGIN SOURCE 036: docs/contracts/MESSAGING-CONTRACT.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Kafka Message / Subscription Contract

**Canonical envelope:** use `history/v0.7/contracts/Kafka_Envelope_Sample_v0.7.json` as baseline. `examples/Kafka_Command_Proposed.json` is a minimal redacted example.

Message `messageType`, `schemaVersion`, `messageId`, `correlationId`, `causationId`, `traceparent`, `runId`, `activityId`, application/workflow version, target capability/operation version, command id, idempotency key, payload or payload ref, and classification must survive service boundaries.

### Published contracts versus broker resources

Capability publishes a declared `MessageContractDescriptor` with `logicalTopicBinding`, `schemaKey/version`, consumer group binding, partition strategy, keying, auth policy and retention/classification. Platform Operations provisions actual topic, ACL, service account and secret reference for each environment. Service cannot create arbitrary subscriptions because an unreviewed manifest says so.

### Commands and outcomes

- `unity.capability.command.v1` -> request a single registered handler or approved embedded BOB workflow.
- `unity.capability.outcome.v1` -> correlate success, rejection, confirmed failure or uncertain outcome to command.
- `unity.process.status.v1` -> optional update for projections (authoritative data still SQL-backed).
- `unity.notification.requested.v1` -> Email Capability command; delivery outcome independent from prior business write.
- Operator commands arrive via authorized API and may be internally dispatched through durable commands; do not accept raw browser Kafka.

### Consumer behavior

Validate transport principal, schema, contract version, dispatch identity, idempotency, scopes and run state. Record inbox receipt and audit, execute only compiled known handlers, outbox outcome. If write result is uncertain, suspend/reconcile; do not replay blindly. Duplicated outcome must not advance BOB twice. Cross-batch concurrent processing must not violate account-level safety or sequential DCMS behavior.

### Test examples

Duplicate same command ID; same payload different ID; malformed schema; old schema; unauthorized producer; poison message; retry after consumer crash; late completion after cancel; broker temporarily offline; correlation collision; oversized data ref.

<!-- END SOURCE 036: docs/contracts/MESSAGING-CONTRACT.md -->

---

<!-- BEGIN SOURCE 037: docs/contracts/OPERATION-CONTRACT.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Capability Operation Contract v0.8 — Proposed and Testable

## Why this contract exists

A developer implements an operation once; the SDK advertises it, BE renders schema-driven configuration, BOB selects a stable operation key, AMIE supplies typed rules, and the service executes under authorized identity. This is the most important compatibility surface to freeze after repository discovery.

## Proposed shape

`CapabilityManifest` = signed/trusted, versioned description of one service's operations; `OperationDescriptor` = stable key/version, schemas, permissions, hosts, side effect, retry/reconcile policy, AMIE requirements, topic contracts, audit code, fixture IDs. `OperationInvocation` = validated typed inputs and execution context. `OperationOutcome` = result or structured safe failure. Do not expose CLR class names to BE.

### C# conceptual interfaces (not current code)

`/Unity.Capabilities.Contracts/Execution/UnityExecutionContext.cs`

```csharp
public sealed record UnityExecutionContext(
    string ApplicationKey, string WorkflowKey, string WorkflowVersion,
    Guid RunId, string ActivityId, string CorrelationId, string CommandId,
    string ActorContextRef, string PackageDigest, string IdempotencyKey,
    string? BatchId, Guid? RecordGuid, string? TraceParent);
```

`/Unity.Capabilities.Hosting/Execution/IUnityOperationHandler.cs`

```csharp
public interface IUnityOperationHandler<TInput, TOutput>
{
    Task<TOutput> ExecuteAsync(TInput input, UnityExecutionContext context, CancellationToken ct);
}
```

`/Unity.Capabilities.Contracts/Execution/OperationOutcome.cs`

```csharp
public enum OperationDisposition { Succeeded, NoChange, Rejected, Failed, UnknownExternalOutcome }
public sealed record OperationOutcome<T>(
    OperationDisposition Disposition, string ReasonCode, string SafeReason,
    T? Result, string? ExternalOperationRef, string? ResultHash);
```

Do not use the enum above as a full DCMS row status—business row projections also have Pending, InProgress and Skipped. The exact DTOs should follow repository style and existing AMIE conventions.

## Descriptor required fields

| Name | Purpose | Test |
|---|---|---|
| `operationKey` + `contractVersion` | Stable capability identity | Duplicate version rejected |
| `inputSchema`, `outputSchema` | Typed composition and UI | Missing or wrong field rejected |
| `permission` and scopes | Backend authorization | Unauthorized direct invocation denied |
| `executionModes` | Local or Kafka use | Unsupported mode rejected |
| `sideEffect` | Read / InMemoryTransform / ExternalWrite | Write requires idempotency policy |
| `retryPolicy` | SafeRetry / RequiresKey / ReconcileBeforeRetry / NeverAutoRetry | Duplicate and uncertain tests |
| `amieRequirements` | Required rule IDs / data types where appropriate | Missing rule/version rejected |
| `subscriptions`, `publications` | Logical Kafka contracts | Unknown topic binding rejected |
| `auditCategory`, `dataClassification` | Evidence and masking | Secrets never logged |
| `testFixtures` | Deterministic regression | CI exercise success + denial |

## Activation is two phase

`Service startup: compiled handler registered and metadata generated` -> `Deploy/publish: verified publisher registers manifest in Unity Registry` -> `Operational readiness: approved environment bindings + broker permissions + healthy version` -> `BOB calls after server-side policy checks`.

Never make `registered` mean `approved` or `available` by itself.

## Compatibility rule

Allow additive optional fields with stable contract when proven backward compatible. Any removed/renamed required field, changed meaning, changed authorization behavior or changed side-effect contract requires explicit new version and fixture. Compilation fails on unresolved operation dependency.

## Example manifest

See `examples/Capability_Manifest_Proposed.json` (draft, unsigned) and `history/v0.7/contracts/Capability_Manifest_Sample_v0.7.json` (original). DEVIN must adjust the schema to actual current library interfaces before implementing generators or runtime.

<!-- END SOURCE 037: docs/contracts/OPERATION-CONTRACT.md -->

---

<!-- BEGIN SOURCE 038: docs/contracts/SECURITY-AND-RELEASE-CONTRACT.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Release and Authorization API Contract

## Principals and scope

Use bank SSO/service identities and real group/claim mapping. Server-side policies combine action + application/workflow/capability + environment + data domain + ownership. Do not trust caller-supplied roles in a JSON body. Read-only audit roles never get mutation endpoints. One author cannot approve and release their own package when bank separation of duties requires independent review.

## Workflow asset lifecycle

Editable draft -> review -> approved -> published immutable version -> activated for **new starts** -> retired. Pending run state is separate from definition state. Material change stores actor, UTC, meaning/diff and approved ServiceNow change ID where required. Resuming existing run uses exact pinned definition.

## Release package fields

`packageKey/version`, `digest`, `publisher`, `signedAtUtc`, workflow XML digests, exact AMIE rule locks, exact operation/schema locks, trigger/form hashes, control/runbook refs, test evidence refs, `change.serviceNowChangeId`, author/reviewer/release operator identity refs, logical environment bindings. **Never secrets**.

## Activation gate

`POST /releases/{id}/activate` (proposed) runs actual authorization, signed digest, approved change/control evidence, deployed compatibility, environment-binding completeness, bank approval and prior UAT evidence. A placeholder ticket or fake `approved=true` is rejected in PROD. Operation service accepts new package only after activation is recorded. Rollback changes which package new runs start; it does not reverse previously committed CyberArk changes.

## Security tests

Direct API call with no UI permission; forged Kafka actor; external binding injection; script/SQL in BPMN extension; stale version; cross-application resource; publication with missing rule; duplicate approval by same actor; modified digest after UAT; PROD unauthorized deploy; audit export classification leak.

<!-- END SOURCE 038: docs/contracts/SECURITY-AND-RELEASE-CONTRACT.md -->

---

<!-- BEGIN SOURCE 039: docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Contracts - Workflow Trigger, NAS/EF Data API, Messaging and Dashboard

**Proposal until repository integration test.** Applies to DCMS, Account Delete, Policy Drift and any new capability. Use SDK versioned manifests. Name `NAS` comes from project request; its expansion, actual model/endpoint names and ownership are **unverified**.

## Unified trigger envelope

```json
{
  "triggerType": "ManualCsv|AuthenticatedApi|AutoSysJob|KafkaMessage|Form|Timer",
  "triggerContractVersion": "1.0",
  "applicationKey": "DCMS",
  "workflowKey": "DCMS.BatchEnrichment",
  "workflowVersion": "1.0.0",
  "requestId": "source-generated-idempotency-key",
  "source": {"system": "BE|AutoSys|API", "sourceRunId": "source-specific-run-id"},
  "actorContextRef": "trusted-identity-context-ref",
  "input": {"batchRef": "approved-record-reference", "fileRef": "optional-managed-upload-reference"}
}
```

Sender supplies authenticated identity; backend generates canonical `runId` and records definition, rules, capability version pins. `202 Accepted` includes run ID and business batch link; does **not** mean processing completed.

## NAS/EF Data API

**Do not assume NAS means network-attached storage.** The request names a `NAS API Database (EF backend and API)` but gives no verified controller URLs, EF entities, ownership or keys. DEVIN first inspects the existing NAS/API repository, Swagger/OpenAPI and EF migrations. Until then these are **logical** operation names, not code contracts:

| Logical registered operation | Inputs | Outputs | Storage behavior | Security |
|---|---|---|---|---|
| `NAS.StageBatch@1.0` | authorized fileRef, declared data contract | batchId, stagedCount, rejectedCount | owning EF service inserts batch and row GUIDs transactionally | `Data.Batch.Stage` |
| `NAS.GetBatch@1.0` | batchId | scoped batch metadata | owned EF query via API | `Data.Batch.Read` |
| `NAS.GetRowsPage@1.0` | batchId, cursor, maxPageSize | typed page of rows + cursor | server-side ordered EF query, no table name input | `Data.Batch.Read` |
| `NAS.MarkRowOutcome@1.0` | batchId, rowGuid, expectedVersion, outcome | write receipt | idempotent EF update/concurrency check | `Data.Row.Update` |
| `NAS.GetBatchSummary@1.0` | batchId | status counts and report refs | aggregate/projection | `Data.Batch.Read` |
| `NAS.GetPolicyBaseline@1.0` | normalized policyId | baseline metadata and version | only if existing NAS owns policy baseline | policy read |
| `NAS.SavePolicyRunResult@1.0` | sourceRunId, policyId, status, diffRef | write receipt | only if authorized policy-data owner | policy write |

An actual NAS service may not own all of these models; map each function to the real data owner, **not** a generic SQL proxy. EF Core DbContext remains in the owning service; other capabilities call typed APIs. No unrestricted SQL/filter/expression in BE or Kafka. Do not create a second database for the same business ownership without review.

## Capability operation descriptor mandatory fields

`capabilityKey`, `operationKey`, `contractVersion`, `inputSchema`, `outputSchema`, `dataOwner`, `permissions`, `classification`, `sideEffect`, `allowedHosts`, `timeoutPolicy`, `idempotencyPolicy`, `reconciliationPolicy`, `auditCategory`, `amieFactSchemaRefs`, `logicalMessageContracts`, `health/availability`, `deprecationState`, `approvedInEnvironments`.

## Kafka contracts

Logical commands: `Unity.WorkflowInvokeRequested.v1`, `CyberArk.ProcessBatchRequested.v1`, `CyberArk.DeleteAccountRequested.v1` (guarded), `Email.ReportRequested.v1`, `Data.BatchStageRequested.v1` (only when truly remote). Logical outcomes: `.Completed.v1`, `.Failed.v1`, `.RequiresReconciliation.v1`, plus `Unity.BusinessProgressChanged.v1`. Physical topic names are environment bindings assigned by approved infrastructure. Consumers must check schema, producer, target handler, permission, run correlation, inbox key and idempotent results; use outbox for reliable messages.

**No raw CSV, password, large file or arbitrary CyberArk account object in Kafka.** Send references and safe metadata. Partition by business aggregate ID when ordering matters (e.g., batchId). Correlation ID identifies entire run; causation/message ID links individual decisions.

## Dashboard projection

`BusinessBatchSummary` returns `{batchId,runId,total,pending,inProgress,succeeded,failed,skipped,requiresReview,completedAtUtc,lastUpdatedAtUtc,reportRef}`. Invariants: sum of row-status buckets equals total; terminal statuses `succeeded+failed+skipped+requiresReview` differ from overall process `Completed` until reporting/email policy finishes; distinguish rule-pass from external-write-confirmed. Internal row errors must have reason code and safe error message. Dashboard receives progress from backend projection, never the Kafka broker.

## AutoSys-to-Unity adapter

A supported AutoSys integration can initially use a bank-approved scheduler command/job that calls `POST /workflow-triggers/autosys` with authenticated job identity, `jobName`, `schedulerInstance`, `sourceRunId`, `scheduledAtUtc`, `inputRef`, `idempotencyKey`; Unity validates job allowlist and creates/returns run. Retry of same key returns same run ID. Full AutoSys AEWS REST adapter is a distinct, optionally later capability and depends on installed version and bank security approval. Official vendor reference: https://knowledge.broadcom.com/external/article/445384/rest-api-and-swagger-documentation-for.html.

## Account delete contract (HIGH IMPACT)

`CyberArk.DeleteAccount@version` should be a narrowly scoped handler with `accountId`, target environment, expected revision/verification token, approved request/ref, dryRun flag, authorization context, idempotency key. No delete from free-form account path. Required control: verify identity and current state; check policy eligibility; approved named actor(s) if required; show dry-run impact; human/operations approval for destructive action; perform via approved CyberArk API; confirm result; record immutable evidence; uncertain outcome does not retry blindly. Demo should use a safe mock or approved non-production test account unless explicit authorized scope exists.

<!-- END SOURCE 039: docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md -->

---

<!-- BEGIN SOURCE 040: docs/guides/17-ADMIN-USER-GUIDES.md -->

# Guides 17 — Administrator and Author Step-by-Step Configuration Manual

## A. First-time administrator: application, category and capability
1. In DEV open `Applications` with authorized admin group. Select existing app or `Create Draft`; enter stable key, display name, owner and description. Do not create duplicate existing app.
2. `Collections` > Add categories Onboarding, Hygiene, Governance, Reporting or another permitted name; preview tree before saving. Moving categories must not change workflow IDs or permissions.
3. `Capabilities` > Select existing owner service or Register Draft. Add owner/contacts, manifest/operation schema, service identity *reference*, host/transport and optional Apigee onboarding reference.
4. Confirm SDK local handler registration vs registry approval distinction. `Validate` checks duplicate operation keys, DTO schema, broker and auth references; `Request Review` begins approval workflow, not automatic activation.
5. In `Operations`, inspect each version and its side-effect classification. Use `Development` to set Experimental/NonProd/Approved and InDev/Testing/Verified/ReleaseReady with evidence. Add approved L2 recipe under this capability's Workflows tab.
6. Associate capability Register/Configure entitlement to authorized local Unity groups (Matthew's existing provider). Test effective access and audit. Do not assign external per-user API grants.

## B. Workflow author: create, configure and test a BPMN process
1. `Applications > PAM > Onboarding > New Workflow` selects L1; from `Capabilities > CyberArk > Workflows > New` selects L2. Enter owner, runbook and labels.
2. From designer `Start` choose trigger (BE form, CSV, API, AMIE/Kafka intake, approved scheduler adapter). Configure typed fields and validation.
3. Add ServiceTask from approved capability operation picker, pin operation version and map required inputs/outputs by schema. Use AMIE BusinessRuleTask and bind approved rule facts/version and outputs.
4. Add XOR/Parallel gateway, CallActivity, Timer or Error boundary and minimum UserTask as required. Verify scopes, default paths, error behavior, timezones and external-write reconciliation. Pools/lanes represent responsibilities only.
5. If future nodes needed, turn `Experimental Mode` ON (if authorized) to place/import and save; read warning. Never assume experimental mode enables execution.
6. `Save Draft` stores canonical `process.bpmn` XML+DI and Unity JSON bindings; `Validate` checks compiler, permissions, host availability, pinning, runtime support and experimental node list.
7. `Test DEV` uses fixture or explicitly approved live connection; inspect run monitor and AMIE decision trace; fix validation/operation errors; request review. Publish only under authorized environment and package lifecycle.

## C. AMIE rule and approval-policy author
1. `AMIE > [Application or Capability] > [Category]` selects existing Matthew editor, not a separate rules engine.
2. Add `Eligibility`, `ApprovalPolicy`, `Mapping` or other categorized rule with stable key, version, typed fact/output schema, owner, consumer and test fixtures.
3. For ApprovalPolicy define ordered stages, group primary/backup, required decision count and rejection path. Test policy against redacted sample and inspect typed approval plan.
4. Bind rule from BPMN inspector; verify pinned version and input mapping; deploy rule through approved environment configuration, inspect decisions in trace after run.
5. If missing group/rule permissions, admin links existing groups with effective access preview; do not fabricate enterprise AD membership.

## D. Business executor and approver
1. Select a workflow visible under own application permissions; `Read` can browse/report but cannot run; `Execute` and `Create` can run within scope.
2. Fill BE input or upload authorized CSV and press Start once; accepted runId is not completion. Monitor status and rule/capability results.
3. Execute-Lead may switch to Group Reports, limited to entitled group members only; others return forbidden.
4. Eligible approver opens My Approvals, reviews redacted request and prior stages, selects Approve/Reject with reason; BOB persists decision and advances after required approvals. Backup selection shown when policy allows.

## E. UAT import and PROD preparation
1. Export real BPMN 2.0 XML with DI and Unity manifest/binding package, record content digest and version.
2. In DEV run required negative/positive tests; authorized administrator requests review; promote identical approved package to UAT where permitted, resolve environmental config outside artifact and retest.
3. In Release Center upload `.unitypkg`, view validation: element support/experimental, dependency versions, group/permissions, signed digest, current authorization, approval evidence and required ServiceNow change ID.
4. A ServiceNow ID is required initially but **not externally checked**; entering the ID is not evidence that the ticket was approved.
5. Only authorized PROD operator may activate after verifying trusted signature or approved enterprise release mechanism, Channel Secure integration and other production gates. If absent, PROD activation remains disabled. A user with Create cannot self-promote to PROD merely by changing a form field.
6. Rollback is a new audited activation pointing to an earlier approved immutable version; running processes stay pinned unless an explicit migration policy exists.

## F. Troubleshooting quick reference
`Permission denied` -> view Effective Access to check group/rule/resource; `Missing operation version` -> inspect capability approved environment; `Experimental node` -> save allowed but runtime requires handler and policy; `Timeout` -> inspect external outcome reconciliation; `Rule facts mismatch` -> correct typed mapping; `Package failed signature` -> do not bypass verification; `Gateway join stuck` -> inspect branch token/history and graph validation; `No Channel Secure connection` -> DEV work possible, PROD go-live blocked.

## Documentation acceptance
Every guide step links to the corresponding Blazor screen/control and test ID, supports screenshots after actual UI exists, and distinguishes fixture/prototype from verified production system. No secret values in screenshots.

<!-- END SOURCE 040: docs/guides/17-ADMIN-USER-GUIDES.md -->

---

<!-- BEGIN SOURCE 041: docs/testing/15-ACCEPTANCE-REGRESSION.md -->

# Testing 15 — Regression, Failure Injection and Phase Gates

## Required evidence level
`Proposed -> code inspected -> unit test verified -> component/integration tested -> UAT proven -> PROD authorized`. A mock screenshot or SDK manifest registration is not evidence of real external execution. Every PR lists command/test results, actual paths, environment, real versus simulated backend, risk and remaining blockers.

## Core conformance matrix
| Test ID | Scenario | Expected result |
|---|---|---|
| BPM-01 | XML+DI import/export with pools/lanes and layout | Stable IDs, waypoints, lane membership and semantics retained |
| BPM-02 | Unsupported executable element with Experimental OFF | Draft preserves content; publication blocked with node ID |
| BPM-03 | Experimental ON in DEV | Author can add/configure/validate; execute only implemented approved test handler |
| BPM-04 | Experimental workflow to PROD | Block even if imported or flag toggled |
| BPM-05 | Exclusive gateway conditions/default | Deterministic route; invalid/no-default negative |
| BPM-06 | Parallel split into 3 | 3 tokens dispatched independently |
| BPM-07 | Parallel join out-of-order | Advances once after required arrivals |
| BPM-08 | Concurrent Kafka outcomes | No duplicate join / lost update |
| BPM-09 | Branch error bypasses join | Explicit modeled exception or validation blocks deadlock |
| BPM-10 | Timer one-shot after pod crash | Durable due recovered and logically fired once |
| BPM-11 | Two scheduler replicas claim same timer | Exactly one logical state transition |
| BPM-12 | Normal activity completes at boundary timer edge | Revision-guarded only one path wins |
| BPM-13 | Late capability completion after timeout | No advance of cancelled path; reconciliation record maintained |
| BPM-14 | Matching BPMN business error | Correct error boundary path selected |
| BPM-15 | Unmatched error nested subprocess | Correct propagation/uncaught policy |
| BPM-16 | Infrastructure failure | Not mislabeled as BPMN business error |
| BPM-17 | Sequential multi-instance 3 rows | Ordered and recovery safe without row duplication |
| BPM-18 | Call activity version pinning | Old running run remains pinned when new version published |
| BPM-19 | Human task multi-stage / backups | AMIE plan -> BOB tasks -> eligible decisions and resume |
| BPM-20 | Parallel branch + subprocess + timer + error | Combined-scopes conformance under restart |
| MSG-01 | Crash before Kafka publish | Transactional outbox replays durable intent |
| MSG-02 | Crash after publish/before outcome | Inbox/idempotency avoids duplicate logical side effect where supported |
| MSG-03 | Duplicate/late Kafka result | One logical transition; late outcome audited separately |
| SEC-01 | Read user direct POST execute | HTTP 403 and denied audit event |
| SEC-02 | Execute-Lead read group results | Own authorized group only, API row filter |
| SEC-03 | Unapproved Register/Configure | Cannot alter capability even via direct API |
| SEC-04 | Service account provider rights but unapproved workflow | No dispatch; provider rights do not override Unity admission |
| SEC-05 | Channel Secure mapped entitlement (before go-live) | SAML session+claims and group mapping verified; fail closed |
| REL-01 | PROD import lacks ServiceNow ID | Block; empty/whitespace invalid |
| REL-02 | Package hash/signature missing/altered | PROD activation blocked; no embedded key trust shortcut |
| REL-03 | UAT approved artifact import | Exact digest, resolved environment bindings and evidence |
| REL-04 | Active version rollback | New activation event; old runs preserve pinned version |
| REG-01 | Manifest discovered but unapproved | Not executable or visible in permitted operation picker |
| REG-02 | Operation version experimental within approved capability | Individual operation blocked according to policy |
| REG-03 | Capability used by two unrelated apps | Same operation handler and registry contract reused |
| UI-01 | Save conflict while dragging | Unsaved editor state preserved; 409 compare UI |
| UI-02 | AMIE->BOB decision trace | Rule/version, workflow/version, run and command correlation printable/redacted |
| UI-03 | BE reconnect | Server authoritative projection, no double-counting |
| UI-04 | Group administration/search | Authorized scope only, no accidental Prod/NonProd crossover |

## Testing level by milestone
M0 inventory and passing baseline/known failures; M1 SDK/catalog/group contracts; M2 AMIE/BOB human approvals; M3 expanded runtime semantics and failure injection; M4 Blazor screen/API/control tests; M5 integration contract & DEV/UAT package tests; M6 integrated pilot and UAT sign-off evidence. Later staged PROD evidence requires enterprise controls (Channel Secure/Apigee/Splunk etc.).

## Stop conditions
Unverified external endpoint/credential -> typed mock adapter and blocker; absent approval -> no privileged PROD operation; invalid BPMN -> draft allowed but no publish; missing signature trust root -> PROD upload disabled; missing Channel Secure integration -> not go-live ready; broad capability service credential does not waive application/operation admission.

<!-- END SOURCE 041: docs/testing/15-ACCEPTANCE-REGRESSION.md -->

---

<!-- BEGIN SOURCE 042: docs/testing/BPMN-DESIGNER-API-REGRESSION-MATRIX-v1.1.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BPMN Designer and Service Integration - API-First Regression Matrix v1.1

All tests below are **requirements for DEVIN**, not claims of passing tests in Unity's source repository. Every UI click maps to backend API contract `docs/ui/16-*`, and every result carries correlation, authorization, audit, and version evidence. Use automated headless browser tests for BE and authenticated API/integration tests for runtime.

| Test ID | Priority | Workflow or component | Input / action | Expected evidence and rejection condition |
|---|---|---|---|---|
| UI-001 | P0 | Workbench | Change app | Registry and runs scope changes; direct API cross-app 403 |
| UI-002 | P0 | Draft wizard | Create new and reload | Same immutable draftId, version/revision and metadata |
| UI-003 | P0 | Draft wizard | Duplicate key | HTTP 409, user input retained |
| UI-004 | P0 | BPMN canvas | Add node/connect/reposition | Stable IDs, DI geometry, undo/redo, save/reload |
| UI-005 | P0 | BPMN import | Import unsupported gateway | Visible element + publish blocker, not silent removal |
| UI-006 | P0 | BPMN export | Export/import roundtrip | Same graph, element IDs, DI and approved extensions |
| UI-007 | P0 | BPMN compiler | Unreachable node/default path missing | Per-node diagnostic with severity and exact ID |
| UI-008 | P0 | Property inspector | Select service task | Schema fields generated from approved descriptor |
| UI-009 | P0 | Property inspector | Change operation version | Input mappings revalidated; stale fact refs flagged |
| UI-010 | P0 | Typed binding | Connect mismatched source type | Structured `BIND_TYPE_MISMATCH`, no save/publish success |
| UI-011 | P0 | AMIE binding | Missing required fact | `BIND_REQUIRED` / rule unavailable blocks compile |
| UI-012 | P0 | AMIE rule test | Evaluate sample | Rule outcome and external side effect status separate |
| UI-013 | P0 | Workflow save | Two editors save same revision | HTTP 409/412 with compare and retained local changes |
| UI-014 | P0 | Workflow validation | Service not approved in target env | Backend denies publication even if front end button enabled |
| UI-015 | P0 | Versioning | Edit published workflow | New draft, original immutable version intact |
| UI-016 | P0 | Reusable UI | Different capability schemas | Same SchemaField and inspector render correctly without new Razor page |
| UI-017 | P0 | Security | Viewer invokes publish through API | Denied at backend; audit policy-denial event |
| UI-018 | P0 | Business dashboard | Subscribe + disconnect + reconnect | Snapshot reconciles counts and ordered event sequence |
| UI-019 | P0 | Operator controls | Pause mid external CyberArk call | PauseRequested until safe checkpoint; no fake rollback |
| UI-020 | P0 | Operator controls | Restart failed run | New linked runId, original audit remains, reconciliation required |
| SDK-001 | P0 | Capability SDK | Auto-register trusted compiled operation | Manifest validated; DI handler resolves; no auto-prod publication |
| SDK-002 | P0 | Registry | Duplicate operationKey@version | Startup/registration rejected with precise error |
| SDK-003 | P0 | Manifest | Sensitive schema property | UI shows logical ref; no raw credential in logs/messages |
| SDK-004 | P0 | Kafka | Duplicate command | Inbox returns same outcome without new external write |
| SDK-005 | P0 | Kafka | Worker crash after write | OutcomeUnknown/reconciliation; no blind retry |
| SDK-006 | P0 | AMIE + BOB | Embedded local execution | No central roundtrip for each record-level step |
| SDK-007 | P0 | MSSQL + BOB | Restart central host with waiting token | Run resumes from persisted checkpoint and correlation |
| DATA-001 | P0 | NAS/EF API | Query typed page | Allowed scope, pagination, no raw SQL input |
| DATA-002 | P0 | NAS/EF API | Retry MarkRowOutcome | Idempotent rowGuid/concurrency; no duplicate status counts |
| DATA-003 | P0 | NAS/EF API | Foreign app tries batch read | Backend denies even if caller knows batch ID |
| DCMS-001 | P0 | CSV trigger | Invalid/missing columns | Reject upload before starting run; show detailed row errors |
| DCMS-002 | P0 | Batch staging | 5-row fixture | One batch number and 5 unique row GUIDs |
| DCMS-003 | P0 | Sequential processing | 3-row order check | Concurrency exactly 1 in configured row subprocess |
| DCMS-004 | P0 | AMIE attribute mapping | Four sample custom attributes | In-memory changeset matches approved schema |
| DCMS-005 | P0 | CyberArk write | Confirmed outcome | Business SUCCESS only after actual write confirmation |
| DCMS-006 | P0 | CyberArk write | API timeout/uncertain | Requires reconciliation; never mark success or blind retry |
| DCMS-007 | P0 | Report/email | Email failure | Account outcomes unchanged, separate notification failure |
| DCMS-008 | P0 | Dashboard | Batch status counts | Sum of status buckets equals total, row reasons available |
| DELETE-001 | P1 | Guarded Delete | Missing approval | No delete API invocation, denied with audit |
| DELETE-002 | P1 | Guarded Delete | Changed target account after approval | Expected revision conflict, require reapproval |
| DELETE-003 | P1 | Guarded Delete | No approved DEV account | Use mock only; never PROD destructive request |
| DELETE-004 | P1 | Guarded Delete | API timeout | OutcomeUnknown + verified read before any retry |
| AUTOSYS-001 | P1 | Trusted schedule | Authorized sourceRunId trigger | 202 accepted with durable runId and source job audit |
| AUTOSYS-002 | P1 | Trusted schedule | Duplicate jobName/sourceRunId | Same runId, no second processing |
| AUTOSYS-003 | P1 | Trusted schedule | Unknown source job or identity | HTTP 403 and no BOB process created |
| POLICY-001 | P1 | Policy Drift | Nested ZIP + INI | All valid policies parsed with provenance |
| POLICY-002 | P1 | Policy Drift | Baseline equal | NO_DRIFT with evidence |
| POLICY-003 | P1 | Policy Drift | Changed values | DRIFT + exact difference output |
| POLICY-004 | P1 | Policy Drift | Missing baseline | MISSING_BASELINE, never NO_DRIFT |
| POLICY-005 | P1 | Policy Drift | Invalid PolicyId | Excluded with reason and original sanitizer evidence |
| POLICY-006 | P1 | Policy Drift | Original SQL vs EF API | Equivalent approved dataset results; mismatches reported |
| REL-001 | P0 | UAT/PROD promotion | Change artifact digest | Block activation after UAT if digest differs |
| REL-002 | P0 | PROD controls | Ticket entered, no real approval | PROD activation denied |
| AUD-001 | P0 | Audit | Reconstruct run and row | Actor, UTC, batch/row GUID, BPMN/rule/op versions, outcomes, changeRef |
| AUD-002 | P0 | Audit export | Classified field present | Mask/redact based on export permission; access recorded |

## Automated test harness recommendation

- Component tests: Blazor bUnit or existing approved component test setup; use `data-testid` stable selectors for browser tests.
- HTTP/API integration: reuse existing approved .NET test clients and CI runners, no unapproved dependencies added solely for demos.
- Kafka: broker simulator or approved DEV broker, duplicate and out-of-order test messages, bounded retries, service identity checks.
- SQL: DEV MSSQL isolated schema with migration/recovery and append-only event tests.
- External APIs: mocked stubs for destructive account actions, bank-approved non-prod credentials only for authorized reads/writes.
- BPMN: parse/DI roundtrip + graph validation + actual token execution + failure recovery separately; a valid XML document is insufficient.
- Evidence: exact build and code revision, run/row IDs, fixture hash, UTC, signed/approved package digest, expected/actual, redacted traces, screenshot and known open controls.

<!-- END SOURCE 042: docs/testing/BPMN-DESIGNER-API-REGRESSION-MATRIX-v1.1.md -->

---

<!-- BEGIN SOURCE 043: docs/testing/DEMO-SCRIPT.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# November 30 Demo Script and Release Readiness Gates

**Demo != production approval.** Live actions must be real and observed; mocks are permitted only when explicitly marked on screen and in evidence.

## 12-minute business narrative (suggested presentation order, not completion promise)

1. Sign in as workflow designer; show Capability Registry contains approved test operations (`CyberArk.GetAccount@1`, Data, Email). Open input/output contract metadata and owner/version.
2. Open DCMS draft in Workflow Library; BPMN 2.0 XML import/export, select service task, bind source row input, choose an existing AMIE mapping rule, validate and publish approved DEV version.
3. Switch to BusinessExecutor; start CSV upload (five-row fixture). Show unique batch number, row GUIDs and run ID.
4. Show central BOB Kafka command -> embedded CyberArk BOB runs AMIE locally; observe business counts changing and open technical BPMN run monitor.
5. Show one failure reason, one no-change, one confirmed success, and explicit uncertain status after an injected timeout; demonstrate no misleading 'passed'.
6. Show operator pause request -> checkpoint -> paused, resume with actor and reason audit; do not claim interrupt of in-flight write.
7. Show persisted report generated from outcomes, Email Capability Kafka notification and separate delivery result.
8. Open audit timeline by batch/run and ServiceNow change ID; show author, version, rule and handler references, message correlation.
9. Show a second Hygiene workflow using existing CyberArk read operation but different AMIE rule without recompiling BOB; if not ready, label as future target.
10. Show Release Center preflight, immutable package digest and simulated/actual controlled block when bank approval missing. Never click real PROD deployment in demo unless explicitly authorized.

## Technical gate

All P0 R01–R18 tests pass with evidence. Business batch/row counts match persisted data and report. Auth denials are real. BOB survives restart during wait. No unapproved library dependence. Version pins and audit reconstruct the run. Package release state truthfully shows approval status.

## Bank gate (separate)

Approved bank control owners, actual CA/ServiceNow workflows, PROD code/config reviews, service identities, secrets, network/Kafka ACLs and evidence retention are in place. Failing this gate blocks PROD, even if DEV demo passes.

<!-- END SOURCE 043: docs/testing/DEMO-SCRIPT.md -->

---

<!-- BEGIN SOURCE 044: docs/testing/FAILURE-AND-SECURITY-TESTS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Failure Injection, Security and Restart Tests

## Execution integrity

- Kill central BOB after outbox commit but before Kafka publish; restart: command eventually delivered, no missing run.
- Kill CyberArk capability after external write could have succeeded but before acknowledgment: row becomes `UnknownExternalOutcome`, reconciliation required, no blind auto-replay.
- Deliver duplicate command and duplicate outcome in arbitrary order; each run transition occurs once and external write does not duplicate.
- Pause immediately before row n; previously accepted write may finish but no next row begins after pause checkpoint. Resume version is pinned.
- Cancel while email pending; report accurately distinguishes business completion from notification status.
- Lose SignalR connection; UI reloads authoritative projection and does not show false complete.
- Corrupt/missing AMIE version in package; start rejected/suspended with evidence.
- Two workers claim same batch/row; lease and optimistic concurrency prevent two simultaneous external effects.

## Access and governance

- BusinessExecutor with app A token attempts app B batch read; deny and safe audit.
- WorkflowDesigner tries direct publish/activate REST; deny even if UI is hidden.
- Run operator supplies stale ETag or duplicates same commandId; idempotent reject/return original result.
- Kafka service uses allowed topic but forbidden operationKey; dispatch denies.
- Import BPMN XML with `scriptTask`, `external entity`, raw HTTP target or unapproved extension; reject safely.
- Tamper signed config package after UAT; PROD digest check fails.
- Supply ServiceNow-looking text with no validated approval; no PROD activation.
- Try to export privileged account material in audit; redaction holds.

## Required fault evidence

Pre/post MSSQL run state; in/out Kafka event IDs; audit sequence and UTC; worker restart logs; idempotency/reconciliation decision; explicit user-visible status; CI test result; absence of repeated CyberArk modification.

<!-- END SOURCE 044: docs/testing/FAILURE-AND-SECURITY-TESTS.md -->

---

<!-- BEGIN SOURCE 045: docs/testing/REGRESSION-MATRIX.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Automated Regression Matrix — Acceptance IDs

Every row is intended for a runnable test plus redacted evidence. Prioritize P0: R01–R18. Each test specifies its fixture in the implementation PR.

| ID | Component | Test and expected result | Priority |
|---|---|---|---|
| R01 | SDK | Compiled CyberArk handler registers with valid contract; duplicate key fails startup | P0 |
| R02 | Registry | Signed/attested publisher accepted; unapproved manifest never executable | P0 |
| R03 | Registry/BE | Schema renders required fields and output bindings; missing field blocks publish | P0 |
| R04 | AMIE | Real existing AMIE rule evaluates through adapter, pinned version reported | P0 |
| R05 | BOB | Start -> service -> rule -> exclusive gateway -> end executes correct path | P0 |
| R06 | BOB | BPMN XML+DI roundtrip stable IDs; unsupported node fails publish | P0 |
| R07 | BOB | Central and embedded share interpreter semantics | P0 |
| R08 | BOB | DCMS sequential 3 rows at most one active per batch | P0 |
| R09 | Kafka | Outbox persists command, published once or more without duplicate effect | P0 |
| R10 | Kafka | Duplicate/out-of-order outcome doesn't double advance | P0 |
| R11 | SQL | Restart central service during wait, load pinned run and resume | P0 |
| R12 | Auth | Unauthorized REST operation, forged Kafka identity and cross-scope read denied | P0 |
| R13 | Controls | Pause requested does not kill in-flight external write; next row gate respected | P0 |
| R14 | Audit | Reconstruct run+row+actor+rule+version+message+ticket from event history | P0 |
| R15 | Release | Modified digest / missing actual approval blocks PROD activation | P0 |
| R16 | DCMS | CSV stages unique batch/row IDs and processes confirmed outcomes | P0 |
| R17 | Email | Report from persisted outcomes sent via independent Email Capability | P0 |
| R18 | API-first | Every exposed BE action has tested authenticated API | P0 |
| R19 | Reuse | Hygiene reuses same `CyberArk.GetAccount` without BOB/CyberArk changes | P1 target |
| R20 | Triggers | API pull/AutoSys schedules normalize start intent | Later |
| R21 | BPMN | Parallel gateway token/join exact semantics | Later |
| R22 | BPMN | User task authorization/inbox/approval wait | P1 if pilot requires |

## Evidence schema per test

`testId`, `fixtureId/version`, `environment`, `testRunId`, `packageDigest`, `commit`, `executedAtUtc`, `result`, `redactedRequestResponseRef`, `auditQueryRef`, `CIArtifactRef`, `screenshotsRef`, `knownLimitations`. A green result without executed evidence is not a release qualification.

<!-- END SOURCE 045: docs/testing/REGRESSION-MATRIX.md -->

---

<!-- BEGIN SOURCE 046: docs/testing/WIREFRAME-V1-QA.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Wireframe v1.0 QA and Verification (2026-11-11)

## Tested

- Generated UI control registry: 19 named screens, **107 unique actions**, valid JSON and one stable ID per button.
- Headless Chromium `page.set_content` smoke: all 19 navigation destinations and all 107 controls rendered; each authorized control click produced visible result/error/modal; no JavaScript page exceptions.
- Target scenario: BPMN service binding and validation visibly reflected; batch mock progress and counts updated; operator action without reason denied, pause request followed by safe checkpoint then resume; PROD activate remained blocked in mock.
- Existing original v0.6/v0.7 prototypes: 33 distinct `data-action` values mapped to v1.0 destinations in `docs/ui/12-PREVIOUS-PROTOTYPE-CONTROL-CROSSWALK.md`.
- Five repo Skills validate and separately package as `skill.zip` files.
- New Markdown links resolve locally; JSON fixtures parse; BPMN examples parse as XML.

## Not tested and must not be inferred

- No connected Blazor app or production UI code, real BE API, BOB interpreter, AMIE engine execution, Kafka broker or CyberArk client.
- No actual SQL persistence, audit retention, SSO policy mapping, released signed config package, controls/CAs, ServiceNow approval or production authorization.
- BPMN XML well-formedness is not BPMN 2.0 semantic conformance. Browser mock passing is not regression pass in the Unity repo.
- Proposed C# interfaces/paths and endpoints must be reconciled against real existing source and approved dependencies.

## Reproduction

```bash
python wireframes/generate_docs.py
python wireframes/generate_html.py
python wireframes/validate_clickability.py
```

Requires Python + Playwright + installed Chromium for the last command. In environments without the browser, the JSON registry and Markdown contracts remain authoritative but browser test must be marked not run.

## Milestone for DEVIN

P0 success requires actual endpoint/handler implementation for each commissioned UI action, direct API role-deny tests, real BPMN compiler checks, AMIE adapter unit tests, durable Kafka/SQL restart proof and DCMS five-row results. New code/new libraries and Wells Fargo approvals need explicit code review and authorized sign-off.

<!-- END SOURCE 046: docs/testing/WIREFRAME-V1-QA.md -->

---

<!-- BEGIN SOURCE 047: docs/workflows/00-REUSABLE-WORKFLOW-PATTERNS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Workflow Examples - Reusable Platform Patterns

These are **example application compositions**, not application-specific branches in BOB, AMIE, BE or the Capability SDK. Statuses: `USER-DEFINED` denotes explicitly described current behavior; `PROPOSED` denotes planned reusable primitive; `VERIFY` requires actual repository/manifest; `DEFERRED` is not required for the initial demo.

## Common workflow blueprint

```mermaid
flowchart LR
  Trigger[Trigger Source] --> Normalize[Authorized Trigger Normalizer]
  Normalize --> Central[Central BOB Workflow]
  Central --> Data[Typed Data Capability or NAS EF API]
  Central --> Bus[Kafka Command]
  Bus --> Embedded[Embedded BOB at Capability]
  Embedded --> Rule[Existing AMIE Rule]
  Rule --> Handler[Registered Handler]
  Handler --> Outcome[Typed Outcome + Audit]
  Outcome --> Bus2[Kafka Outcome]
  Bus2 --> Central
  Central --> Report[Reporting + Email Capability]
  Central --> Project[Business Projection]
  Project --> BE[BE Business Dashboard]
```

For very short wholly local workflows, central BOB/Kafka hops can be omitted; local BOB shares the same interpreter. For cross-service work, durable dispatch/correlation is necessary. Rules decide; handlers perform externally verified side effects.

## Scenarios and feature reuse

| Application / test slice | Trigger | Data boundary | BOB shape | AMIE | Capability operations | Dashboard result |
|---|---|---|---|---|---|---|
| DCMS attribute enrichment | BE CSV now; API later | stage batch + GUID rows via data owner | central batch + embedded sequential row subprocess | eligibility + mapping + skip decision | stage/page/outcomes, GetAccount, ApplyAttributes, AddOrUpdate, Report, Email | counts per row and reasons |
| Account Delete | user/form/API after approval | account & request refs | approval wait -> guarded delete -> verification | eligibility, retention, delete policy | GetAccount, VerifyDelete, DeleteAccount, Notify | request status + approval + outcome |
| NAS/EF data workflow | user/API/BOB | owned EF DbContext behind typed NAS API | typed service tasks, pagination | validation and transform | typed GET/POST/Update only | batch/count summary |
| Policy Drift | AutoSys via approved trigger | EPV API ZIP/INI + policy baseline store | central trigger + ingestion/compare subprocess | normalization, compare, status | DownloadPolicyBundle, ParsePolicy, BaselineGet/Upsert, WriteDrift, Report/Email | policies processed/no drift/drift/missing |
| Account hygiene / safe move | schedule/manual | EVD/reporting metadata + CyberArk API | query -> rule -> approval -> move | safe-placement decision | GetAccount, MoveAccount, Verify, Report | compliance and remediation result |

## Critical invariants

1. No business app appears as an `if` inside generic BOB or AMIE engine.
2. Bound `operationKey@contractVersion` must be published/authorized and available in target environment.
3. AMIE cannot perform destructive writes; it outputs decisions or typed changesets, and capability handler enforces scope/side-effect controls.
4. Each async Kafka boundary has durable wait/correlation, inbox/outbox, idempotency and late-outcome rules.
5. Each workflow references pinned BPMN/rule/operation/contract versions; mid-flight version migration not MVP.
6. Process user-facing counts are projections of business data and result events; not inferred solely from BPMN token location.
7. Background schedulers must not be given unrestricted Kafka/DB credentials; use approved adapter identity and policy.
8. Unverified NAS entity names, CyberArk endpoints or AutoSys AEWS paths remain placeholders and must be sourced from real approved contracts.

## Failure state taxonomy

`REJECTED_INPUT`, `VALIDATION_FAILED`, `NOT_FOUND`, `SKIPPED_NO_CHANGE`, `BLOCKED_POLICY`, `AWAITING_APPROVAL`, `WRITE_CONFIRMED`, `WRITE_REJECTED`, `WRITE_OUTCOME_UNKNOWN`, `RETRYABLE_INFRA`, `FAILED_PERMANENT`, `COMPLETED_WITH_ERRORS`. Central workflow must distinguish batch business status from reporting/email send status.

<!-- END SOURCE 047: docs/workflows/00-REUSABLE-WORKFLOW-PATTERNS.md -->

---

<!-- BEGIN SOURCE 048: docs/workflows/01-DCMS-CSV-CYBERARK-ENRICHMENT.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Workflow 01 - DCMS CSV -> CyberArk Custom Attribute Enrichment

## Established business behavior

DCMS imports a CSV to a table, assigns the batch a number, gives each row a GUID, processes rows **one by one**, looks up the CyberArk account, updates/adds the platform custom attribute values **in memory**, calls CyberArk add/update, and emails a final report containing passed/failed/successful records and reasons. This is a workload using Unity; BOB does not hardcode DCMS.

## Required registered operation contracts (logical names)

| Step | Operation | Runtime location | AMIE inputs/outcomes | Expected result |
|---|---|---|---|---|
| Stage | `NAS.StageBatch@1` (data owner may differ) | Data/NAS EF API | validate CSV contract | batchId + N row GUIDs |
| Read | `NAS.GetRowsPage@1` | Data API from worker | row data in scoped context | cursor + typed row |
| Account | `CyberArk.GetAccount@1` | embedded CyberArk BOB | account and platform metadata | current account or NOT_FOUND |
| Validate | `DCMS.Eligibility@1` | existing AMIE | row/account/metadata | ALLOW, SKIP, REJECT + reason |
| Map | `DCMS.MapAttributes@1` | existing AMIE | four CSV fields, account and platform | allowed typed changeset |
| Apply | `CyberArk.ApplyCustomAttributes@1` | embedded local | approved change set | modified in-memory account |
| Write | `CyberArk.AddOrUpdateAccount@1` | embedded local | decision permits write | confirmed outcome or uncertain |
| Row outcome | `NAS.MarkRowOutcome@1` | Data API | status + reason | persisted idempotent result |
| Report | `Reporting.CreateBatchReport@1` | Reporting capability | aggregate result ref | reportRef |
| Email | `Email.SendReport@1` | Email capability via Kafka | recipients/template policy | message outcome |

These are **proposed interface names**. DEVIN must map them to already implemented CyberArk and data code, and add missing reusable primitives only.

## BE authoring procedure

1. Workbench > choose DCMS > Workflow Library > create `DCMS.BatchEnrichment` from Batch Template. Assign owner, scope, control/runbook.
2. Trigger Designer > Manual CSV > required account ID, platform ID and four attributes; choose approved staging operation and file validation policy.
3. Data Sources > bind the row-read and status-write operations from the owning NAS/EF/API capability; bind `batchId` and `rowGuid` fields explicitly.
4. BPMN Canvas > Start -> Stage -> Call/Dispatch ProcessRowBatch -> Wait for confirmed outcome -> Report -> Email -> End. Add failure path and report error behavior.
5. Embedded subprocess > sequential multi-instance (`concurrency=1`), GetAccount, AMIE Eligibility, XOR ALLOW/SKIP/REJECT, Map Attributes, Apply In Memory, AddOrUpdate, Persist Result.
6. For each task use operation inspector: `operationKey@version`, inputs (current row, prior outputs or AMIE output), host, timeout, side effect, audit policy. Add no raw CyberArk URL.
7. Validation > schema check and synthetic 5-row fixture; publish immutable DEV version. Choose UI roles for upload and viewing own batch only.
8. BE user uploads CSV; obtains accepted batch number + run link. Business dashboard moves through Pending, In Progress, Success/Skipped/Failed/Review. BPMN view restricted to support/operator.
9. Final report uses persisted row results, not inferred from rule output. Email send status is separately tracked.

## Detailed sequence

```mermaid
sequenceDiagram
  autonumber
  actor User as CVIS User
  participant UI as BE Blazor
  participant API as Unity API
  participant NAS as Data/NAS EF API
  participant BOB as Central BOB
  participant K as Kafka
  participant C as CyberArk Capability (Embedded BOB)
  participant A as AMIE
  participant EPV as CyberArk API
  participant E as Reporting / Email
  User->>UI: Upload CSV (approved schema)
  UI->>API: POST upload + start
  API->>NAS: StageBatch(fileRef)
  NAS-->>API: batchId, row GUIDs
  API->>BOB: Start pinned workflow
  API-->>UI: 202 runId, batchId
  BOB->>K: ProcessBatch command (outbox)
  K->>C: Deliver command
  loop Each staged row sequentially
    C->>NAS: GetRowsPage / next row
    C->>EPV: GetAccount(accountId)
    C->>A: Eligibility + MapAttributes
    A-->>C: Decision and changeset
    alt Allowed and needs write
      C->>EPV: AddOrUpdateAccount(modified account)
      EPV-->>C: Write outcome
    else Skip/reject
      Note over C: Persist safe reason
    end
    C->>NAS: MarkRowOutcome(rowGuid,status,reason)
    NAS-->>UI: Aggregate/projection refresh
  end
  C->>K: Completed/failed batch outcome
  K->>BOB: Correlate and resume wait
  BOB->>E: Create report + send via Email Capability
  E-->>BOB: ReportRef + delivery status
  BOB-->>UI: Completed or completed with errors
```

## Failure and recovery requirements

- CSV missing required data -> no run, user sees row/schema errors.
- Missing account -> configured SKIP/REJECT branch; no implicit create.
- Attribute mismatch -> AMIE validation result; no write; record reason.
- CyberArk timeout after request -> `WRITE_OUTCOME_UNKNOWN`, reconcile by approved read; do **not** automatically retry a potentially completed write.
- Row status update fails -> retry idempotent `rowGuid/version` command, preserve write outcome proof; do not re-write CyberArk.
- Kafka message duplicate -> inbox returns same accepted run; no second batch mutation.
- Report email failure -> account outcomes unchanged; email status failed/pending, operator can retry notification with idempotent message ref.
- Pause at row boundary, not mid-EPV request; stop scheduling next row.

## Acceptance fixture

Five rows: #1 write success, #2 no change, #3 missing account, #4 AMIE validation reject, #5 simulated EPV timeout / reconciliation. Verify total = terminal + in-progress + pending; rows retain GUIDs and reasons; report lists distinct validation and write outcomes; dashboard eventually updates from authoritative projection. Link all events by correlation and pinned versions.

<!-- END SOURCE 048: docs/workflows/01-DCMS-CSV-CYBERARK-ENRICHMENT.md -->

---

<!-- BEGIN SOURCE 049: docs/workflows/02-ACCOUNT-DELETE-GUARDED-WORKFLOW.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Workflow 02 - Guarded CyberArk Account Delete

## Intent and risk

Reusable application for a **high-impact privileged deletion**. Only approved roles and narrowly scoped identities may request or approve. This is not merely a `DeleteAccount` service task placed after a button click. If control/approval APIs or BPMN user-task semantics do not yet exist, demo the full screen and safe simulated backend outcome **without performing an actual deletion**. DEVIN may not assume bank authorization.

## BE configuration

1. Create application/workflow `PAM.AccountDeletion` with owner, runbook, change ticket policy and explicit deletion permission.
2. Trigger > authenticated request form (accountRef, reason, approved request ID, expected account state, dryRun=true default); optionally API with trusted caller.
3. Add CyberArk capability `GetAccount`, AMIE rule `AccountDelete.Eligibility@1` (ownership, retention, target, allowed environment, policy), `CyberArk.VerifyDeleteCandidate`, and a durable control approval step.
4. Designer > Start -> GetAccount -> Eligibility -> exclusive gateway -> Preview Impact -> Approval Wait -> guarded DeleteAccount -> Verify -> Report/Email -> End; Reject and failure branches go to audit.
5. Configure durable approval: if BPMN User Task is implemented and tested, use it; otherwise model `Control.RequestApproval` + correlated message catch/wait. Do not portray an unsupported user task as live.
6. Delete handler descriptor declares `ExternalDestructiveWrite`, required permission, `NoBlindRetry`, reconciliation method and high-impact audit category.
7. Save/validate/test using mock CyberArk response and a non-production fixture; require two separate identities where bank policy mandates segregation.
8. Publish DEV version and show status on business dashboard: Requested -> Evaluating -> Awaiting Approval -> Delete Pending -> Verified Deleted / Rejected / Failed / Outcome Unknown.

## BPMN process

```mermaid
flowchart TD
  A[Authorized request] --> B[Get CyberArk account]
  B --> C[AMIE delete eligibility]
  C --> D{Eligible?}
  D -->|No| X[Rejected / report + audit]
  D -->|Yes| P[Preview impact + explicit confirmation]
  P --> Q[Control request approval]
  Q --> W[Durable approval outcome wait]
  W --> R{Approved?}
  R -->|No| X
  R -->|Yes| S[Guarded CyberArk.DeleteAccount]
  S --> T[Verify deletion via approved read]
  T --> U{Confirmed?}
  U -->|Yes| V[Report and Email]
  U -->|Unknown| Y[Requires reconciliation + manual review]
  V --> Z[Complete]
```

## Integration and evidence

- BE -> API authorizes submit. Authenticated actor is a user, not an anonymous application input.
- BOB pins workflow and capability/rule versions; AMIE emits eligibility decision with reason.
- Control/approval service emits actor/role/ticket/time evidence. The receiver validates that this approval pertains to *this exact* account and request, not merely a reusable ticket ID.
- CyberArk Capability checks permissions **again**, captures expected current state and issues only the approved API delete operation. No direct EPV database mutation.
- Auditable external outcome and post-delete confirmation are distinct. If API timed out, the result may be unknown even if account is gone; reconcile before any retried delete.
- Kafka is used only if the operation is across services. The delete event should contain references and safe metadata, never credentials.
- Email is notification via Email Capability; failure to email does not reverse a confirmed delete.

## Regression

Unauthorized trigger denies; rule-denied request produces no delete call; approval by requester denied when separation required; approval replay for a different account denied; race (account changed after preview) aborts; timeout outcome becomes manual reconciliation; denied PROD config activation never sends delete command; test shows who/when/what version and ticket. Use mocks or bank-approved DEV test account only.

<!-- END SOURCE 049: docs/workflows/02-ACCOUNT-DELETE-GUARDED-WORKFLOW.md -->

---

<!-- BEGIN SOURCE 050: docs/workflows/03-NAS-EF-API-DATA-CAPABILITY.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Workflow 03 - NAS/EF Backend and API as a Reusable Unity Data Capability

## Grounded versus unknown

The user identifies a `NAS API Database (EF backend and API)` that Unity workflows should use. The **exact meaning of NAS, existing controllers, EF entities, schemas, authorization model and database ownership are not yet verified**. Preserve its name and the requested API/EF architecture; do not invent concrete controller names or table layouts as facts.

## Desired service separation

```mermaid
flowchart LR
  UI[BE Data Binding Picker] --> Reg[Capability Registry metadata]
  UI --> BOB[BPMN Service Task]
  BOB --> K[Kafka or Approved Service API]
  K --> NAS[NAS Data Capability API]
  NAS --> EF[EF Core DbContext / UoW]
  EF --> DB[(NAS owned MSSQL database)]
  NAS --> O[Typed result + audit]
  O --> BOB
```

If NAS has its **own** database, it may use local EF directly. Other services consume its approved API, **not** its DbContext or physical tables. This is distinct from BOB's MSSQL-only workflow persistence decision. If existing legacy APIs own the data, use those contracts instead of creating a redundant NAS store.

## Proposed operation families to inventory (not code claims)

| Family | Typed operations | Must not expose |
|---|---|---|
| Batch staging | StageBatch, GetBatchStatus, GetRowsPage, MarkRowOutcome | `query(tableName, sqlText)` |
| Account metadata | FindAccounts, GetAccountSnapshot, GetMetadataByKey | unrestricted EF joins to other service DBs |
| Policy baseline | GetBaseline, UpsertBaseline, SaveDriftResult | uncontrolled baseline overwrite |
| Report | GetBatchAggregates, GetPolicyRunSummary | unscoped classified exports |

## BE screens and dynamic behavior

1. Capability Catalog > filter `Data` > choose `NAS` > view approved service version/health and declared operations.
2. Inspect one operation: permissions, required input schema, output schema, side effect, owner, supported hosts, data classification.
3. In BPMN Designer add Service Task -> bind registered NAS operation; a schema-generated form appears. Bind `batchId` from trigger or previous stage output.
4. Test preview calls a safe fixture endpoint (or mocks) with redaction, not live production tables. Edit source binding, save and revalidate.
5. On backend run, BOB dispatches typed request via approved API/Kafka; NAS API performs EF query/transaction and returns typed response. The browser never supplies arbitrary SQL, table names, DB connection strings or credentials.

## DEVIN source audit instructions

- Find actual NAS project, API routes, OpenAPI schema, EF DbContext, entity ownership, migrations, DI setup, authentication, FluentValidation and transaction strategy. Record repository paths and versions.
- Reuse existing methods; implement only missing typed primitives. Ensure pagination, optimistic concurrency, idempotent writes, audit context forwarding, classified response handling.
- Register these approved operations via shared Capability SDK manifest; link `OperationDescriptor` to existing DTOs with schema tests.
- Add API-first regression and a second BOB workflow proving reuse without modifying NAS code.

## Acceptance

With a real approved NAS endpoint in DEV, user selects an operation in BE, sees its required parameters, maps them from workflow data, validates, tests and executes a BOB service task that roundtrips through the API and EF backend. Audit shows caller, operation version, source/run correlation, data owner and result, with no direct SQL exposed to consumers.

<!-- END SOURCE 050: docs/workflows/03-NAS-EF-API-DATA-CAPABILITY.md -->

---

<!-- BEGIN SOURCE 051: docs/workflows/04-AUTOSYS-POLICY-DRIFT-ZIP-INI.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Workflow 04 - AutoSys-Triggered Policy Drift (EPV ZIP/INI Baseline Comparison)

## Existing behavior and evidence boundary

Previous project work describes a Policy Drift process using scheduled EPV ZIP/API ingestion, recursive nested ZIP and INI parsing, PolicyId normalization, policy baseline comparisons, drift records and audit. The exact original SQL queries, EF entity classes, current AutoSys version/job IDs and approved endpoints **must be retrieved from the repository** before implementing handlers. Earlier design discussed `BaselinePolicy`, policy-evaluation records, and an audit/event history; use original SQL as an acceptance oracle rather than inventing LINQ equivalence. The policy status vocabulary includes `NO_DRIFT`, `DRIFT`, and `MISSING_BASELINE`; exceptions must retain reasons. This is NOT the same workflow as safe-move account hygiene.

## Trigger design - first workable integration

**Preferred initial path:** existing AutoSys job runs an approved script/command that calls a secured Unity trigger API with `jobName`, `schedulerInstance`, `sourceRunId`, `scheduledAtUtc`, and approved data/ZIP reference. The trigger service validates caller identity, allowlisted job and schema, dedupes on job + run ID, starts pinned central BOB definition, and returns `202 Accepted` with `runId`. AutoSys can record this ID; completion can be queried or signaled by approved contract if scheduling policy requires it.

**Alternative after review:** an AutoSys Capability consumes its AEWS REST API to discover run/job status. This depends on installed AutoSys 12.1/R24.1 (or actual version), its documentation, security approvals and connectivity; it is **not** assumed present. Vendor reference: https://knowledge.broadcom.com/external/article/445384/rest-api-and-swagger-documentation-for.html.

## BPMN / AMIE / capability stages

| Stage | Owner | Reusable operation/rule | Result + status |
|---|---|---|---|
| AutoSys execution | AutoSys / trusted trigger adapter | `WorkflowTrigger.StartByScheduler@1` | runId or rejected duplicate/role |
| Fetch policy data | EPV/CyberArk Capability | `CyberArk.DownloadPolicyBundle@1` OR existing approved data accessor | managed bundleRef; fatal retrieval error aborts run |
| Expand and parse | Policy Ingestion Capability | `Policy.ExtractNestedArchives@1`, `Policy.ParseIni@1` | typed policies, parse issues |
| Normalize | AMIE or existing sanitizer adapter | `Policy.NormalizePolicyId@1` | normalized PolicyID; must call existing real sanitizer |
| Load baseline | owning Data/EF API | `Policy.GetBaseline@1` | baseline snapshot / missing |
| Compare | AMIE | `Policy.CompareAttributes@1` | `NO_DRIFT`, `DRIFT`, `MISSING_BASELINE` and diffRef |
| Persist | owning EF API | `Policy.SaveEvaluation@1` | idempotent run/policy write and audit |
| Optional baseline update | controlled baseline operation | `Policy.UpdateBaseline@1` | approved mutation + version; must respect baseline-update override |
| Aggregate/report | Reporting capability | `Reporting.PolicyDriftSummary@1` | counts, error reasons, reportRef |
| Notify | Email capability | `Email.SendReport@1` | delivery outcome independent of drift result |

Example policy baseline file convention previously considered: `baseline update/{PolicyID}.txt`; check actual file path and source first. `MISSING_BASELINE` must not be silently classified as `NO_DRIFT`.

## BE configuration walkthrough

1. Application Studio > Policy Drift > Workflow Library > `Create from Scheduled Ingestion Template`.
2. Trigger Designer > `AutoSys Job` > choose approved logical job from registry, not free-text API credential/host; set schema, runId mapping, overlap policy, idempotency and failure notification.
3. Data Sources > bind EPV download and policy baseline operations from the correct data owner; verify actual EF model and API routes.
4. BPMN Designer > start -> download ZIP -> extract/parse subprocess -> sequential policies -> normalize -> baseline retrieve -> compare AMIE -> branch into `DRIFT`/`NO_DRIFT`/`MISSING_BASELINE` -> write result -> aggregate -> report/email -> end.
5. AMIE configuration > set attribute comparison and exclusion rule with reason; preserve normalization behavior; attach approved baseline version. Rule test panel runs 4 policy fixtures.
6. Configure failure paths: total download/unzip failure abort batch; individual invalid INI or policy writes produce per-policy failure and continue under approved policy; unknown policy ID flagged.
7. Test with nested ZIP/INI bundle, duplicate AutoSys start and restart; publish DEV version. UAT/PROD follow release gates and authorized Operations activation.
8. Business dashboard shows policies seen, processed, no-drift, drift, missing-baseline, excluded, failed and last-run status. Technical run monitor shows task/timer/adapter outcomes.

## Full flow

```mermaid
flowchart TD
  A[AutoSys job executes] --> B[Authorized Unity scheduler trigger]
  B --> C[Central BOB: start pinned workflow]
  C --> D[Download EPV ZIP / API data]
  D --> E{Bundle available?}
  E -->|No| F[Fail run + alert + audit]
  E -->|Yes| G[Extract nested ZIPs + parse INI]
  G --> H[For each policy]
  H --> I[Normalize PolicyId]
  I --> J{Policy valid?}
  J -->|No| N[Record excluded/parse reason]
  J -->|Yes| K[Get baseline via Data API]
  K --> L[AMIE compare policy fields]
  L --> M{Result}
  M -->|NO_DRIFT| O[Persist unchanged evaluation]
  M -->|DRIFT| P[Persist diff and evidence]
  M -->|MISSING_BASELINE| Q[Persist missing-baseline finding]
  N --> R{More policies?}
  O --> R
  P --> R
  Q --> R
  R -->|Yes| H
  R -->|No| S[Aggregate + Report]
  S --> T[Kafka Email Capability]
  T --> U[Dashboard + Audit + AutoSys status correlation]
```

## Failure, fallback and concurrency rules

- EPV download failure or total unzip failure abort batch with fatal reason.
- Missing/invalid PolicyID -> log row and continue according to runbook; do not silently delete it.
- Per-policy EF write failure retries idempotently and yields policy-level failed status; one failed policy should not masquerade as successful batch.
- If an approved fallback to a reporting database is used when EPV API returns errors, audit records fallback source, reason, freshness and confidence; no secret/privileged DB fallback.
- Baseline updates are governed mutations. Persist upsert/evaluation/event in a transaction when same DB; file deletion/archival follows after transaction and records failure separately.
- Duplicate scheduler `sourceRunId` must resolve to original run, not create new policy evaluations; overlap policy explicit (skip, queue, or concurrent by scope).
- Version pins preserve PolicyId sanitizer, AMIE compare, baseline schema and capability operation versions; no in-flight migrations required for initial pilot.

## Tests and evidence

Fixture 1 identical policy -> NO_DRIFT. Fixture 2 changed attributes -> DRIFT + diff. Fixture 3 no baseline -> MISSING_BASELINE. Fixture 4 invalid INI -> excluded with reason. Fixture 5 recursive nested ZIP. Fixture 6 invalid/untrusted source job -> 403. Fixture 7 duplicate AutoSys run -> same runId. Fixture 8 fatal EPV download -> FAILED + audit + no misleading email success. Fixture 9 original SQL vs new EF query equivalence using approved dataset; deviations explicitly flagged. Tests must not depend on real PROD policy dumps.

<!-- END SOURCE 051: docs/workflows/04-AUTOSYS-POLICY-DRIFT-ZIP-INI.md -->

---

<!-- BEGIN SOURCE 052: docs/workflows/05-HYGIENE-SAFE-MOVE-SEPARATE-EXAMPLE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Workflow 05 - Account Hygiene / Privileged Safe Move (Separate from Policy Drift)

This is a separate PAM compliance business workflow. Example: an account is found with privilege/safe placement inconsistent with approved rules; AMIE decides whether remediation is appropriate; a registered CyberArk operation may move it after controls/approval. It must not be conflated with ZIP/INI policy baseline drift or DCMS custom-attribute enrichment.

```mermaid
flowchart TD
  A[Manual / approved schedule / API] --> B[Query eligible accounts via approved Data/CyberArk capability]
  B --> C[GetAccount and current safe]
  C --> D[AMIE: placement rule / policy]
  D --> E{Violation?}
  E -->|No| F[Mark compliant]
  E -->|Yes| G[Propose target safe + reason]
  G --> H[Control / approval check]
  H -->|Denied| I[Finding only]
  H -->|Authorized| J[CyberArk.MoveAccount]
  J --> K[Read/verify target safe]
  K --> L[Row outcome + audit]
  F --> L
  I --> L
  L --> M[Report / optional Email / Business Dashboard]
```

BE config: select trigger, pick registered data enumeration/`GetAccount`, bind AMIE rule with permitted target safe list, add conditional gateway, attach required approval and safe-move operation, configure denial/outcome branch. On save validate safe permissions, account scope, target vault/safe, idempotency and reconciliation; publish approved DEV. User sees compliant, violations found, remediated, requires approval, failed/unknown. Audit captures who authorized the move and before/after safe references (classified). Demonstrates operation reuse from DCMS but a distinct configured app.

Initial demo can be read-only finding generation (no actual move), and should mark remediation capability as deferred if the underlying operation/security approval is not available.

<!-- END SOURCE 052: docs/workflows/05-HYGIENE-SAFE-MOVE-SEPARATE-EXAMPLE.md -->

---

<!-- BEGIN SOURCE 053: docs/workflows/16-PRACTICAL-EXAMPLES.md -->

# Workflows 16 — Practical Scenarios for Every Phase 1 and Deferred BPMN Construct

Each scenario is *illustrative*, not verified implementation. Select approved DEV/UAT fixtures; do not use production CyberArk destructive operations without explicit authorization.

| BPMN element | WF Unity example | Rule/capability/boundary |
|---|---|---|
| Start Event | BE user requests privileged account | AMIE intake selects workflow; BOB starts approved run |
| End Event | Provisioning completed/rejected | BOB publishes final outcome and BE projection |
| Service Task | Create Safe or GetAccount | Approved CyberArk capability operation@version |
| Business Rule Task | Is service account eligible? | AMIE eligibility@version returns typed decision |
| Exclusive Gateway | Does request require approval? | Route to approval or direct provisioning |
| Call Activity/Subprocess | Reuse `ProvisionPrivilegedAccount` recipe | Parent pins called process/version, maps outputs |
| Sequential Multi-instance | Process 100 CSV rows in order | Embedded capability L2 recipe or central L1 as appropriate |
| Kafka Wait | Await CyberArk command outcome | Persist correlation and resume on logical outcome |
| Parallel Gateway Split | Start AD, CyberArk and reporting independent tasks | BOB creates multiple execution tokens |
| Parallel Gateway Join | Wait for all required branch completions | Atomic join; error paths cannot count as success |
| Intermediate Timer Catch | Approved operation waits for 10 PM change window | Persistent UTC deadline, survives pod restart |
| Interrupting Timer Boundary | CyberArk provisioning exceeds 5 minutes | Alternate timeout/reconcile path; not proof external write cancelled |
| Interrupting Error Boundary | Capability emits `SAFE_NOT_FOUND` business error | AMIE authorization check -> create safe if permitted -> retry controlled |
| Minimum UserTask | Manager then Security approval | AMIE stages; BOB durable waiting; BE eligible approvals |
| Lanes | Security, Application, Operations responsibilities | Visual membership, not separate Kafka execution host |

## Example end-to-end PAM request
1. BE checks user's local group Execute entitlement; receives redacted form/CSV.
2. AMIE intake validates and enriches; chooses `PAM.AccountOnboarding@2.1`, reasons and ruleVersion.
3. BOB checks definition active and caller entitlement; creates run/scope and durable intake state.
4. AMIE eligibility rule returns whether manager/security approvals needed; BOB creates human-task stages and waits for eligible decisions.
5. Parallel gateway dispatches independent AD validation and CyberArk prerequisites; BOB joins only after required branch results.
6. Create account via approved CyberArk service task; interrupting timer and error boundary perform safe timeout/error routing.
7. BOB publishes final workflow outcome, redacted audit and BE report; Report reader vs Execute-Lead group visibility enforced.
8. Reconciliation required for any timed-out external write with unknown outcome.

## Capability-local recipe
`GetAccount -> AMIE ValidateAttributes -> Map/Transform -> AddOrUpdate -> Verify`, compiled to same supported interpreter with embedded host and approved handler versions. Reuse in different application without separate microservice orchestration architecture. Long approval waits or cross-service joins belong centrally.

## Deferred BPMN with modeled UX
| Deferred construct | Future use | Design-time treatment |
|---|---|---|
| Noninterrupting boundary | Remind approver without cancelling approval | Experimental event with visible warning |
| Inclusive gateway | Only selected subset of services run and join | Import/diagram/inspector but no fake XOR execution |
| Event-based gateway | Approval response versus timeout race | Only execute after atomic subscription handler conformance |
| Parallel multi-instance | 500 accounts max 10 concurrent | Need concurrency/rate limits, aggregation, recovery |
| Compensation | Revert approved account changes on later business failure | Require side-effect compensator, no pretend rollback |
| Event subprocess | Emergency revoke during onboarding | Scoped event activation and interruption |
| Multi-pool collaboration | Department-to-department message choreography | BPMN DI preserved; true multi-participant execution deferred |

## Distinct pilot paths
CyberArk onboarding as first integrated demonstration; second neutral unrelated workload (NAS/Policy Drift/legacy modernization) proves platform generality. Keep Policy Drift baseline ZIP/INI/PolicyId hygiene distinct from account hygiene Safe-Move; no domain-specific rules inside BOB core. AutoSys and cron source triggers tested through authorized adapter when source details arrive.

<!-- END SOURCE 053: docs/workflows/16-PRACTICAL-EXAMPLES.md -->

---

<!-- BEGIN SOURCE 054: jobs/18-DEVIN-IMPLEMENTATION-JOBS.md -->

# Jobs 18 — Dependency-Ordered Devin Work Packets and Evidence Gates

## Code-first inspection rule
No assumption a proposed C# class, Blazor page, EF schema, API or approved dependency exists. Devin's first job is read-only source reconciliation: read AGENTS.md, repo architecture, current AMIE/BOB contracts, BE components, capability SDK, Kafka infrastructure, CI tests and security conventions. Report exact file paths and working vs mock functionality. Missing third-party approvals or bank-controlled dependencies are blockers, not license to invent endpoints. Maintain one feature PR per dependency seam; report changed paths, tests, effect on existing code, risks, screenshots and unresolved issues.

## JOB-V2-00 — Baseline audit and release gate (M0)
Inspect original v1.1, SDK v1.0 and existing project implementation. Record real components/handlers/DbContexts/AMIE route/BE screens, code ownership, dependencies, test results and source reconciliation. Confirm whether all Phase 1 primitives already exist; do not duplicate. Output source audit, contract map, failed tests, dependency graph, open integration requirements and proposed PR plan. **Gate:** reviewers accept actual evidence and migration/compatibility plan.

## JOB-V2-01 — Versioned application and capability catalog (M1)
Implement `uty_catalog` and `uty_capability` schema changes only after M0. Context filters Application > Onboarding/Hygiene/Governance/Reporting, Capability > Operations/Workflows/Rules; stable IDs, versioned immutable definitions and association indexes. Test category moves and group permission invariance. Use actual existing EF contexts/migrations where possible.

## JOB-V2-02 — Trusted SDK registration, operation approval (M1)
Existing SDK compiled handler discovery -> typed manifest -> trusted service deploy identity -> registry approval -> operation picker. Support language-neutral REST/Kafka onboarding without duplicating engine. Wire Register/Configure authorization and per-operation maturity and environment activation. Test duplicate IDs, unsupported schemas, revoked operation and one handler reused in two workflows.

## JOB-V2-03 — Existing group policy and AMIE seams (M2)
Reuse Matthew auth/group and AMIE rule engine; link workflow groups with Read/Execute/Execute-Lead/Create, capability Register/Configure separately. Preview effective access; server-side enforcement and scope-filtered results. Preserve AMIE intake validation/enrichment/workflow selection, typed AMIE->BOB start contract; BOB->AMIE pinned rule adapter. Identify existing AMIE orchestration overlap and log deferred review without first-pilot rewrite.

## JOB-V2-04 — Durable human-task contract (M2)
AMIE returns multi-stage approval plan with eligible groups/backup groups/any-one or all; BOB persists work queue stages/decisions and resumes. BE displays tasks, decisions and audit. Test concurrent approvers, reject, backup and restart, permission denial. Avoid duplicate approval engine.

## JOB-V2-05 — Shared BPMN compiler and token engine (M3)
Preserve OMG XML+DI, support baseline nodes and typed versioned operation/rule/call bindings. Implement or verify token/scope state, atomic parallel split/join arrivals, SQL outbox/inbox correlation, pause/resume/cancel/restart. Reject unsupported topologies and non-durable embedded waits. Both central/embedded hosts pass same semantic fixture subset.

## JOB-V2-06 — Durable events and exception paths (M3)
Persist one-shot intermediate timers; attached interrupting timer boundary; typed error boundary; race/cancel safety; nested error scopes; late unknown external write reconciliation. Chaos test pod crashes and two-replica races. Include compiled BPMN element feature flags and maturity-state validation.

## JOB-V2-07 — Blazor authoring and capability admin (M4)
Implement responsive shared shell and catalog, capability administration and maturity stages, operation inspector, BPMN designer and experimental full palette, AMIE binding selection, group assignment and effective-access preview. XML/DI import/export truly works; UI warns on unsupported runtime execution. Use existing Blazor pages rather than parallel UI project. Capture screens and route/API controls.

## JOB-V2-08 — AMIE review candidate screens (M4)
Offer Matthew rule catalog/category, rule inspect/test, approval policy builder, intake trace and workflow AMIE-binding wireframes; adopt only approved parts and current editor. Keep separate `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` excluded from Ask. Provide user guides and screen acceptance scripts.

## JOB-V2-09 — Enterprise integration seams (M5)
For Channel Secure, Apigee, Splunk, AutoSys, NAS and cron, reconcile existing work, map to placeholder Jira, collect requirements/owners and implement approved contracts. Current auth/group continues in DEV; Channel Secure SAML/entitlements required before PROD go-live. No fake integration evidence and no invented credentials. Kafka service identity + gateway scopes independent of Unity human groups.

## JOB-V2-10 — Package release and environment controls (M5)
Package XML+DI + JSON bindings/rules/versions as immutable artifact; DEV/UAT import/validation, nonempty PROD ServiceNow reference, approved artifact, trusted signature or enterprise trust path, eligible operator. PROD upload/activation fails closed pending mandatory trust/Channel Secure. Implement stage gating and separate import/activate/rollback. No request to promote developer directly to PROD.

## JOB-V2-11 — End-to-end pilot and UAT evidence (M6)
Demonstrate BE -> existing AMIE routing -> central BOB -> approved capability SDK/Kafka -> embedded local AMIE/handler -> correlated outcome/report/BE monitor and multi-level approval. Include parallel AD/CyberArk demo with mock/approved DEV endpoints, timer/error paths and crash recovery. Validate one unrelated second workflow reuse. Resolve M5 production blockers before any go-live claim.

## Deferred architectural work after first pilot
MATTHEW review of AMIE durable orchestration overlap; event-based/inclusive/complex gateways, noninterrupting boundaries, parallel multi-instance, compensation, event subprocess, collaboration, advanced approval delegation and forms; ServiceNow API validation, automated policy drift, expanded department APIs. Preserve compatibility now; not hidden immediate P0 obligations unless required for actual pilot safety.

## PR acceptance template
`Job ID / Milestone / Jira placeholder / Existing paths touched / Old behavior / New behavior / Data migration / API/schema compatibility / Unit tests / Integration tests / Permission negative tests / UAT evidence / Actual vs Mock / Known blockers / Review and rollback`. One ticket is not complete solely because code compiles; linked milestone gate and acceptance evidence determine completion.

<!-- END SOURCE 054: jobs/18-DEVIN-IMPLEMENTATION-JOBS.md -->

---

<!-- BEGIN SOURCE 055: docs/00-START-HERE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Start Here — Integration Strategy and Immediate Assignment

## Objective

By **2026-11-30** demonstrate a narrowly scoped but **real** configuration-first Unity vertical slice: BE authoring, operation registry, AMIE mapping, executable BOB BPMN subset, capability execution, Kafka command/outcome, MSSQL run/audit history, business summary, user scopes, and failure handling. DCMS is the first business acceptance fixture; a second independently configured workload is a stretch goal. Bank production approval is a distinct release gate.

## First action for DEVIN

Run `jobs/JOB-00-reconcile-repository.md` immediately in read-only mode. Output `docs/decisions/REAL-REPOSITORY-MAP.md` with (a) what exists, (b) what works, (c) the exact AMIE integration seam, (d) actual capability and Blazor structures, (e) approved libraries, (f) broker and database conventions, (g) blockers. This task should precede mass scaffolding.

## Priority gates

- **A Contract gate:** one real handler + descriptor -> registry -> BE inspector -> AMIE adapter (use existing engine) -> BOB activity binding.
- **B Execution gate:** BPMN fixture executes in embedded and central hosts; cross-service command completes by Kafka; MSSQL checkpoint and audit survive restarts.
- **C UX gate:** BE can configure, validate and publish a supported workflow, start it as an authorized user, view business counts and inspect a technical timeline; operator controls reflect real state.
- **D Pilot gate:** DCMS CSV stages batch + row GUIDs, processes rows sequentially through CyberArk read/map/write, reports verified outcomes and notifications via Email Capability.
- **E Reuse gate:** second business process uses same engine and existing approved operations without BOB code changes. Validate separated from bank PROD authorization.

## What is already known, and what is not

[USER] AMIE is largely written; BOB is the bottleneck. Unity includes Blazor BE, embedded/central BOB, Kafka and independently owned capability services. DCMS uses CSV->staging->batch/row IDs->CyberArk enrichment->report/email. DEV/UAT->PROD configuration promotion by Operations is desired.

[VERIFY] Exact code/assembly names, deployed service interfaces, Kafka topic conventions, approved designer/paid libraries, SQL migrations, existing ServiceNow workflow, audit retention, SSO group names, CyberArk API behavior, current test harness. Do not fabricate these.

[PROPOSED] Names like `IUnityOperationHandler`, `CapabilityManifest`, `BOB.Run` and example OpenAPI routes are contracts for discussion, not authoritative until reconciled.

## Parallel job plan

After JOB-00 freezes the cross-team contracts: SDK/registry (JOB-01/02), BOB parser/runtime (JOB-04/05), Kafka (JOB-06), SQL/audit (JOB-07), BE designer (JOB-08/09), and testing/release (JOB-15/16) can proceed in **separate worktrees or branches** with contract fixtures. Pilot-specific CyberArk/Data (JOB-11/12) may progress independently once their interfaces are fixed. Integration (JOB-17) must wait on verified seams.

## Safe no-approval dependency fallback

Re-use bank-approved libraries already in repository. If no graphical BPMN library is approved, implement a limited first-party Blazor SVG canvas + small version-controlled JS pointer module, keeping BPMN XML/DI as the model and leaving BOB independent of canvas rendering. Any new dependency remains a bank review blocker, not an assumed shortcut.

## How to use skills in Devin

Copy `.agents/skills/` into the actual repository, commit through normal review, then invoke e.g. `@skills:unity-capability-service` for new microservice scaffolding. Devin's official documentation supports repo `SKILL.md` auto-discovery at `.agents/skills/<name>/SKILL.md`; ensure the connected repository/session exposes them. They are **instructions** and examples, not installed runtime SDK NuGet packages.

## Documentation navigation

- Architecture: `docs/architecture/01-PLATFORM-TOPOLOGY.md` through `12-DELIVERY-BOUNDARIES.md`.
- Machine contracts: `docs/contracts/`.
- Walkthroughs: `docs/ui/`.
- Tests: `docs/testing/`.
- Jobs and targets: `jobs/INDEX.md` and `docs/roadmap/DELIVERY-PLAN.md`.


## v1.0 detailed UX and SDK handoff addition

After the read-only source reconciliation, freeze the interface between registered capability descriptors, BE typed inspector, existing AMIE rule descriptors and the BOB activity compiler. New UI source is `wireframes/UI_CONTROL_REGISTRY_v1.0.json` (19 screens/102 controls). Detailed development work packets are at `jobs/interaction/INDEX.md`; they are **subtasks** of the original JOB plan, not a second independent engine roadmap. Use the browser HTML only to review intended state transitions; real implementation must pass API, auth, Kafka, MSSQL, BPMN and recovery tests.

## v1.1 priority additions

Read the [new v1.1 index](../INDEX.md) and [BPMN UI/end-to-end jobs](../jobs/bpmn/INDEX.md). First working app remains DCMS. New primary user flow is [UI 18](ui/18-FULL-BPMN-DESIGNER-UI-CONFIGURATION-AND-TEST-RUNBOOK.md). Sources and diagrams: [all workflows](workflows/00-REUSABLE-WORKFLOW-PATTERNS.md) and [18 diagrams](diagrams/DIAGRAMS.md). Account Delete mock and AutoSys Policy Drift are conditional second pilots; bank approvals and legacy code verification gate real execution.

<!-- END SOURCE 055: docs/00-START-HERE.md -->

---

<!-- BEGIN SOURCE 056: docs/decisions/DECISION-REGISTER.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Decision Register — Preserve User Decisions and Open Questions

| ID | Status | Decision or issue | Rationale / next proof |
|---|---|---|---|
| U-001 | User-established | Unity configuration-first; application cases stay outside BOB Core | Reuse across CVIS workloads |
| U-002 | User-established | Existing AMIE mostly written; do not rebuild | JOB-00 adapter reconnaissance |
| U-003 | User-established | BOB shared interpreter with central and embedded hosts | Avoid per-step network calls |
| U-004 | User-established | BOB supports BPMN 2.0 interchange | Explicit subset for MVP, no false full conformance |
| U-005 | User-established | BOB persistence MSSQL only | Not a requirement for every capability's business data |
| U-006 | User-established | BE is Blazor, visual and operational | API-first; strong designer |
| U-007 | User-established | Microservices publish reusable operations + AMIE requirements | SDK + registry, approval required |
| U-008 | User-established | Kafka interservice commands/outcomes; Email Capability independent | No email module inside BOB |
| U-009 | User-established | Audit, ServiceNow change ID, roles, runbooks, process controls | Exact bank control IDs pending |
| U-010 | User-established | Operations promotes versioned config without developer PROD access | Signed package / approved binding process |
| U-011 | User-established | DCMS process and one/two application demos by Nov 30 | DCMS is workload acceptance, not engine special case |
| P-012 | Proposed | API + operation descriptor shape and SDK assemblies | Test against current namespaces |
| P-013 | Proposed | Sequential multi-instance + durable Kafka wait in initial BPMN subset | DCMS pilot need |
| P-014 | Proposed | First-party Blazor SVG/JS editor if no approved library exists | Avoid approval delay; verify existing UI components |
| P-015 | Proposed | Append-only audit event table and state projection | Verify bank database audit policy |
| P-016 | Proposed | Workflow Draft -> Review -> Approved -> Published -> Active -> Retired | Verify controls and ownership |
| P-017 | Proposed | Role permission matrix | Map to real SSO/enterprise groups |
| X-018 | Verify | Real AMIE interface/version/DSL | JOB-00 source trace |
| X-019 | Verify | Existing CyberArk operations, API semantics, idempotency and approved test accounts | JOB-11 inventory |
| X-020 | Verify | Installed Kafka library, topics, ACL and outbox conventions | JOB-06 |
| X-021 | Verify | Approved BPMN designer component/paid library | JOB-08 design spike |
| X-022 | Verify | Which DCMS store owns batch/rows and upload | JOB-10 |
| X-023 | Verify | Actual Wells Fargo CA/change procedures, role groups and evidence retention | JOB-14 and bank control owner |
| X-024 | Verify | Actual repository build/deployment environment and CI scripts | JOB-00 |
| F-025 | Refined by v1.1 | Mid-flight migration, advanced BPMN and full ServiceNow deferred; limited approved AutoSys trigger is now P1 | Keep full AEWS adapter separate from MVP |
| U-026 | User-established v1.1 | Reusable BE/Blazor UI components and complete configurable BPMN workflow authoring from UI to backend | UI 13-18 and CMP-001..063 |
| U-027 | User-established v1.1 | NAS EF backend/API is a desired registered data capability | Actual NAS owner/controller/contracts unverified |
| U-028 | User-established v1.1 | Account Delete and AutoSys Policy Drift are illustrative initial application/workflow targets | Safe scope and existing legacy code must be verified |
| P-029 | Proposed v1.1 | AutoSys schedule trigger via approved command -> secured Unity trigger API first | Avoid assuming AEWS access; P1 |
| P-030 | Proposed v1.1 | Full BPMN palette visible but unsupported executable nodes fail publication | Separate visual and runtime conformance |
| X-031 | Verify v1.1 | Policy Drift original SQL, PolicyId sanitizer, ZIP/INI parser, baseline EF ownership | Compare with legacy acceptance oracle |
| X-032 | Verify v1.1 | Delete approval/retention policy and CyberArk delete operation | No PROD destructive demonstration absent approval |

## Change rule

If DEVIN changes any proposed contract or discovers a conflict, add a dated ADR decision with: existing evidence, alternatives, impacts, revised API/fixture, regression changes, owner, approval state. Do not quietly rename a contract in one service only.

<!-- END SOURCE 056: docs/decisions/DECISION-REGISTER.md -->

---

<!-- BEGIN SOURCE 057: docs/decisions/OPEN-REPOSITORY-QUESTIONS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Evidence Required Before Coding or Claiming a Release

DEVIN must answer these from repository/owner evidence during JOB-00 or mark as blockers:

1. What are **actual** AMIE libraries/classes for rule evaluation, validation, configuration version and persistence? Are rule descriptors available already?
2. What BOB source is implemented already? What BPMN parser/designer library is **approved**? Is the BOB core a blank project or incomplete runtime?
3. Which Unity capabilities currently exist, with which public DTOs, DI, Kafka topics and security? Can a CyberArk account be updated safely and idempotently?
4. What is actual DCMS CSV format, table schema and row-GUID semantics? Which service owns staging and report results?
5. Which Kafka .NET client/schema registry/outbox conventions and broker ACL provisioning are approved? Are topics already established?
6. Which MSSQL versions/provider/data access/migration conventions and audit controls are approved? Which service identity may append audit?
7. What BE Blazor hosting mode, state management, component libraries and auth providers already exist? Does it already have workflow or approval UI?
8. Which exact bank CAs, release checks, ServiceNow authorization process, approvers, audit retention and SIEM integrations apply? Who signs off?
9. Which CI/CD tools and automated test frameworks are approved and usable before November 30?
10. What two applications are realistic to demo with approved data and credentials? Who provides UAT acceptance?

For each answer record: evidence URL or actual file path, owner, last verified UTC, proposed code change impact, and unresolved risks. Avoid putting credentials/secrets into the document.

<!-- END SOURCE 057: docs/decisions/OPEN-REPOSITORY-QUESTIONS.md -->

---

<!-- BEGIN SOURCE 058: docs/diagrams/DIAGRAMS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Unity BPMN Designer - Editable Diagram Library

**Diagrams:** 18. All Mermaid sources are maintained as `.mmd` and rendered inline here for Markdown viewers that support Mermaid. The diagram is a specification, not live runtime proof.

## 01 Platform Topology
**Source:** [01-platform-topology.mmd](01-platform-topology.mmd)

```mermaid
flowchart TD
  BE[Blazor Business Enablement] --> API[Unity Backend APIs]
  API --> REG[Capability Registry]
  API --> BOB[Central BOB BPMN Core]
  API --> AUD[Audit / Control Services]
  BOB --> AMIE[AMIE Rule Adapter]
  BOB --> KA[Kafka Command / Outcome]
  KA --> CAP[Capability Service Hosting SDK]
  CAP --> LOCAL[Embedded BOB and AMIE]
  LOCAL --> NAS[NAS / Data EF API]
  LOCAL --> EPV[CyberArk Operations]
  CAP --> EMAIL[Email / Reporting]
  BOB --> SQL[(MSSQL BOB State)]
  AUD --> ASQL[(MSSQL Audit Events)]
  CAP --> EVT[Events / Traces]
  EVT --> AUD
  API --> DASH[Business/Run Projections]
```

## 02 Ui Workflow Creation
**Source:** [02-ui-workflow-creation.mmd](02-ui-workflow-creation.mmd)

```mermaid
sequenceDiagram
  autonumber
  actor Author
  participant BE as BE Workflow Wizard/Canvas
  participant API as Workflow Catalog API
  participant REG as Capability Registry
  participant AMIE as AMIE Rule Catalog
  participant VAL as BPMN Compiler/Validator
  participant DB as MSSQL Definition Store
  Author->>BE: Create draft under application
  BE->>API: POST /workflow-drafts
  API->>DB: Save draft and ETag
  DB-->>BE: draftId/revision
  Author->>BE: Add service task + select operation
  BE->>REG: GET typed operation descriptor
  REG-->>BE: schema/hosts/policy
  Author->>BE: Bind required fields
  BE->>AMIE: Browse rule descriptor
  AMIE-->>BE: fact/output schemas
  BE->>VAL: POST /bindings/validate
  VAL-->>BE: field issues or valid
  Author->>BE: Save BPMN XML+DI
  BE->>API: PUT /workflow-drafts with If-Match
  API->>DB: Save new revision and audit edit
  Author->>BE: Validate + test
  BE->>VAL: Compile executable graph
  VAL-->>BE: issues/test-run reference
  Author->>BE: Request review/publish
  BE->>API: Submit approved revision
  API->>DB: Immutable version + digest and audit
  API-->>BE: version and release readiness
```

## 03 Dynamic Node Binding
**Source:** [03-dynamic-node-binding.mmd](03-dynamic-node-binding.mmd)

```mermaid
flowchart LR
  PICK[Select BPMN Service Task] --> KEY[Choose Approved operationKey@version]
  KEY --> MAN[Fetch OperationDescriptor]
  MAN --> SCHEMA[Render SchemaField / BindingPicker]
  SCHEMA --> TYPE{Typed input compatible?}
  TYPE -->|No| ERR[Field error / jump to source]
  TYPE -->|Yes| HOST[Choose allowed host and retry policy]
  HOST --> AUTH[Check permission, data ownership, audit]
  AUTH --> VALID[Compile workflow binding]
  VALID --> SAVE[Save draft; invalidate prior validated badge]
```

## 04 Editor State And Versions
**Source:** [04-editor-state-and-versions.mmd](04-editor-state-and-versions.mmd)

```mermaid
stateDiagram-v2
  [*] --> NewDraft
  NewDraft --> Dirty: editor change
  Dirty --> SavedDraft: Save + ETag
  SavedDraft --> Dirty: edit
  SavedDraft --> Validated: compile + test
  Validated --> Dirty: any change
  Validated --> InReview: submit review
  InReview --> Approved: approved evidence
  InReview --> Dirty: revisions requested
  Approved --> Published: immutable version + digest
  Published --> Active: authorized release
  Active --> Retired: authorized retirement
  Active --> NewDraft: start next version
```

## 05 Canvas Events To Blazor
**Source:** [05-canvas-events-to-blazor.mmd](05-canvas-events-to-blazor.mmd)

```mermaid
sequenceDiagram
  actor Author
  participant JS as First-party Canvas JS
  participant BZ as Blazor BpmnCanvas
  participant STATE as Draft Editor State
  participant API as Workflow API
  Author->>JS: Drag task / pan / connect
  JS->>JS: Local pointer gesture preview
  JS->>BZ: Commit add/move/edge on pointer-up
  BZ->>STATE: Patch graph XML+DI and undo history
  STATE-->>BZ: Dirty + property inspector refresh
  Author->>BZ: Save draft
  BZ->>API: PUT draft + revision
  API-->>BZ: New ETag or 409/412 conflict
  BZ-->>Author: Saved or compare/resolve conflict
```

## 06 Csv Upload To Dashboard
**Source:** [06-csv-upload-to-dashboard.mmd](06-csv-upload-to-dashboard.mmd)

```mermaid
sequenceDiagram
  autonumber
  actor U as Business User
  participant UI as BE Blazor
  participant UP as Upload API
  participant NAS as NAS / Data EF API
  participant BOB as Central BOB
  participant PROJ as Business Projection
  participant PUSH as Auth SSE / SignalR
  U->>UI: Upload CSV and click Start
  UI->>UP: POST file upload
  UP->>NAS: StageBatch(fileRef)
  NAS-->>UP: batchId + row GUIDs
  UP->>BOB: Start published workflow
  UP-->>UI: 202 accepted runId and batchId
  BOB-->>PROJ: Workflow status event
  NAS-->>PROJ: Row outcomes / counts
  PROJ->>PUSH: Changed summary and sequence
  PUSH->>UI: Authorized progress notification
  UI->>PROJ: GET authoritative snapshot on reconnect
  UI-->>U: Progress counts, row reasons, report link
```

## 07 Dcms Central Embedded
**Source:** [07-dcms-central-embedded.mmd](07-dcms-central-embedded.mmd)

```mermaid
flowchart TD
  Start[Manual CSV / authenticated API] --> Stage[NAS/Data EF API StageBatch]
  Stage --> Top[Central BOB DCMS.BatchEnrichment]
  Top --> Dispatch[Kafka ProcessBatch command]
  Dispatch --> Emb[Embedded CyberArk BOB ProcessRows]
  Emb --> Row[Get next staged row]
  Row --> Account[CyberArk GetAccount]
  Account --> Rule[AMIE eligibility + mapping]
  Rule --> Allow{ALLOW + changed?}
  Allow -->|Yes| Update[Apply in memory + AddOrUpdate]
  Allow -->|No| Skip[Skip/reject with reason]
  Update --> Save[NAS MarkRowOutcome]
  Skip --> Save
  Save --> More{More rows?}
  More -->|Yes| Row
  More -->|No| Done[Kafka outcome to central BOB]
  Done --> Rep[Reporting Capability]
  Rep --> Mail[Email Capability]
  Done --> Dash[BE Dashboard projection]
```

## 08 Nas Ef Api Data Access
**Source:** [08-nas-ef-api-data-access.mmd](08-nas-ef-api-data-access.mmd)

```mermaid
sequenceDiagram
  participant BE as BE Schema Inspector
  participant REG as Registry
  participant BOB as BOB Service Task
  participant K as Kafka / Approved API Client
  participant NAS as NAS Data Capability API
  participant EF as EF Core DbContext
  participant SQL as Owned MSSQL Data
  BE->>REG: Get NAS operation schema
  REG-->>BE: Typed fields and policy
  BOB->>K: Invoke approved typed NAS operation
  K->>NAS: Authenticated operation call
  NAS->>NAS: Validate app/data scope
  NAS->>EF: Execute owned repository operation
  EF->>SQL: Parameterized query or transaction
  SQL-->>EF: Database result
  EF-->>NAS: Typed entity result
  NAS-->>BOB: Typed response + audit/correlation
```

## 09 Account Delete Safety
**Source:** [09-account-delete-safety.mmd](09-account-delete-safety.mmd)

```mermaid
sequenceDiagram
  actor Req as Authorized Requester
  participant BE as BE Account Delete Form
  participant BOB as Central BOB
  participant AMIE as AMIE Eligibility
  participant CTRL as Control Approval
  participant C as CyberArk Capability
  participant EPV as CyberArk API
  Req->>BE: Request deletion with reason/ticket
  BE->>BOB: Create scoped deletion workflow
  BOB->>C: GetAccount + verify current state
  C-->>BOB: Account snapshot
  BOB->>AMIE: Check eligibility/retention
  AMIE-->>BOB: Eligible/denied + explanation
  BOB->>CTRL: Request distinct approval if required
  CTRL-->>BOB: Correlated approval decision
  alt Denied or changed state
    BOB-->>BE: Rejected with audit
  else Authorized and state stable
    BOB->>C: Guarded DeleteAccount (idempotency key)
    C->>EPV: Approved DELETE API action
    EPV-->>C: Outcome
    C->>EPV: Read to verify deletion
    C-->>BOB: Confirmed / Unknown / Failed
    BOB-->>BE: Final status and evidence
  end
```

## 10 Autosys Job Trigger
**Source:** [10-autosys-job-trigger.mmd](10-autosys-job-trigger.mmd)

```mermaid
sequenceDiagram
  autonumber
  participant SCH as AutoSys Scheduled Job
  participant SCRIPT as Approved Trigger Script/Adapter
  participant API as Unity Trigger API
  participant BOB as Central BOB
  participant AUD as Audit/Run Projections
  SCH->>SCRIPT: Execute job with jobName/sourceRunId
  SCRIPT->>API: POST /workflow-triggers/autosys (auth)
  API->>API: Verify job allowlist/scope, dedupe sourceRunId
  alt Duplicate
    API-->>SCRIPT: Existing runId
  else New job run
    API->>BOB: Start pinned PolicyDrift workflow
    BOB->>AUD: Created/run correlation
    API-->>SCRIPT: 202 accepted + runId
  end
  BOB-->>AUD: Completion/event outcome
  Note over SCH,AUD: AutoSys completion feedback is separate and environment-specific
```

## 11 Policy Drift Zip Baselines
**Source:** [11-policy-drift-zip-baselines.mmd](11-policy-drift-zip-baselines.mmd)

```mermaid
flowchart TD
  Auto[AutoSys Trigger] --> Fetch[EPV policy ZIP / API download]
  Fetch --> Valid{Download/ZIP valid?}
  Valid -->|No| Fail[Fail batch + audit alert]
  Valid -->|Yes| Parse[Recursive nested ZIP + INI parse]
  Parse --> Next[Next policy entry]
  Next --> Norm[Normalize PolicyId using existing function]
  Norm --> Id{Valid PolicyId?}
  Id -->|No| Ex[Exclude with reason + evidence]
  Id -->|Yes| Baseline[EF owned API GetBaseline]
  Baseline --> Compare[AMIE compare normalized fields]
  Compare --> Result{Classification}
  Result -->|NO_DRIFT| No[Record unchanged]
  Result -->|DRIFT| Drift[Persist diff evidence]
  Result -->|MISSING_BASELINE| Missing[Record missing baseline]
  Ex --> More{More policies?}
  No --> More
  Drift --> More
  Missing --> More
  More -->|Yes| Next
  More -->|No| Report[Aggregate, email, dashboard]
```

## 12 Hygiene Safe Remediation
**Source:** [12-hygiene-safe-remediation.mmd](12-hygiene-safe-remediation.mmd)

```mermaid
flowchart TD
  A[Scheduled/API/Manual Trigger] --> B[Fetch eligible accounts]
  B --> C[Get CyberArk account/safe]
  C --> D[AMIE evaluates placement policy]
  D --> E{Violation?}
  E -->|No| F[Record compliant]
  E -->|Yes| G[Suggest safe + reason]
  G --> H{Approval and policy?}
  H -->|No| I[Finding only]
  H -->|Yes| J[CyberArk MoveAccount]
  J --> K[Verify actual safe]
  F --> L[Business result + audit]
  I --> L
  K --> L
  L --> M[Report + dashboard]
```

## 13 Kafka Durable Execution
**Source:** [13-kafka-durable-execution.mmd](13-kafka-durable-execution.mmd)

```mermaid
sequenceDiagram
  participant BOB as Central BOB
  participant SQL as MSSQL State + Outbox
  participant K as Kafka Broker
  participant IN as Capability Inbox
  participant C as Embedded BOB/Handler
  participant EPV as External CyberArk API
  BOB->>SQL: Commit PendingCommand + outbox + wait correlation
  SQL-->>K: Reliable outbox dispatch
  K->>IN: Deliver command (possible redelivery)
  IN->>IN: Verify producer, schema and idempotency
  alt First time
    IN->>C: Run local handler + pinned AMIE
    C->>EPV: External operation if approved
    EPV-->>C: Confirmed or uncertain outcome
    C->>IN: Store result, emit outbox outcome
  else Duplicate
    IN-->>K: Ack/replay prior outcome
  end
  IN-->>K: Outcome event
  K->>BOB: Correlate to waiting activity
  BOB->>SQL: Persist completion + audit exactly once per logical event
```

## 14 Run Operator Control
**Source:** [14-run-operator-control.mmd](14-run-operator-control.mmd)

```mermaid
stateDiagram-v2
  [*] --> Created
  Created --> Running
  Running --> PauseRequested: authenticated reasoned command
  PauseRequested --> Paused: checkpoint reached
  Paused --> Running: authorized Resume
  Running --> CancelRequested: reasoned Cancel
  Paused --> CancelRequested: reasoned Cancel
  CancelRequested --> Cancelled: no new activities
  Running --> Completed
  Running --> Failed
  Cancelled --> NewLinkedRun: authorized Restart + reconcile
  Failed --> NewLinkedRun: authorized Restart + reconcile
  NewLinkedRun --> Running
```

## 15 Release Approved Package
**Source:** [15-release-approved-package.mmd](15-release-approved-package.mmd)

```mermaid
flowchart TD
  D[DEV Draft + BPMN + AMIE + bindings] --> V[Validate schemas/operations/rules/BPMN]
  V --> T[DEV/API regression + negative controls]
  T --> P[Immutable package digest + version]
  P --> U[UAT deploy exact artifact with UAT bindings]
  U --> E[UAT evidence + control review]
  E --> SN[ServiceNow change and authorized approvals]
  SN --> OPS{Operations approval valid?}
  OPS -->|No| BLOCK[Block PROD activation]
  OPS -->|Yes| PROD[Ops activates same digest + approved PROD bindings]
  PROD --> AUD[Audit change actor / UTC / environment / digest]
```

## 16 Capability Service Onboarding
**Source:** [16-capability-service-onboarding.mmd](16-capability-service-onboarding.mmd)

```mermaid
sequenceDiagram
  actor DEV as Capability Developer
  participant SVC as Capability Microservice
  participant SDK as Unity Capability SDK
  participant REG as Trusted Capability Registry
  participant BE as BE Catalog/Composer
  participant BOB as BOB Dispatcher
  DEV->>SVC: Implement typed operation handler
  SVC->>SDK: Discover trusted compiled handlers on startup
  SDK->>SDK: Validate unique operation key/schema/permissions
  SDK-->>SVC: Local DI dispatcher and manifest
  Note over SVC,REG: Service deployment approval is separate from local discovery
  SVC->>REG: Publish manifest using trusted deploy identity
  REG-->>BE: Approved operationKey@version, schemas, hosts
  BE->>BE: Generate dynamic inspector and typed bindings
  BE->>BOB: Publish immutable workflow binding
  BOB->>SVC: Invoke approved operation through local handler or Kafka
```

## 17 Workflow Authoring Complete
**Source:** [17-workflow-authoring-complete.mmd](17-workflow-authoring-complete.mmd)

```mermaid
flowchart TD
  App[Select app in BE] --> Create[New workflow draft or template]
  Create --> Trigger[Select trigger CSV / form / API / AutoSys]
  Trigger --> Data[Bind NAS/Data source + typed schema]
  Data --> Catalog[Choose approved capability operations]
  Catalog --> Canvas[Draw BPMN nodes + DI]
  Canvas --> Rule[Bind AMIE rules/typed output]
  Rule --> Validate[Backend compile + validation]
  Validate -->|Invalid| Canvas
  Validate -->|Valid| Test[DEV test bench fixtures + failure injection]
  Test -->|Fail| Canvas
  Test -->|Pass| Review[Review/change ticket/approve]
  Review --> Publish[Publish immutable version]
  Publish --> Release[UAT/PROD package promotion]
  Release --> Execute[Run by BE/API/AutoSys/Kafka]
  Execute --> Monitor[Business dashboard + BPMN overlay]
  Monitor --> Audit[Reconstruct events/control evidence]
```

## 18 Business Dashboard Reconnect
**Source:** [18-business-dashboard-reconnect.mmd](18-business-dashboard-reconnect.mmd)

```mermaid
sequenceDiagram
  participant CAP as Capability Handler
  participant K as Kafka Outcome
  participant BOB as BOB State
  participant PROJ as Business Projection
  participant PUSH as SignalR/SSE Gateway
  actor UI as Browser Dashboard
  CAP->>K: Typed row outcome (safe metadata)
  K->>BOB: Correlated task outcome
  K->>PROJ: Business progress changed
  PROJ->>PUSH: sequence N / batchId
  PUSH-->>UI: Scope-filtered update hint
  UI->>PROJ: GET batch snapshot (ETag)
  PROJ-->>UI: Authoritative counts and reasons
  Note over UI,PROJ: On reconnect or gap, always GET snapshot
```

<!-- END SOURCE 058: docs/diagrams/DIAGRAMS.md -->

---

<!-- BEGIN SOURCE 059: docs/roadmap/BACKLOG-POST-MVP.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# After November 30 — Prioritized Backlog

**P1** where actual business need emerges: rich human approval tasks, timers/schedules, AutoSys adapter, API/DB connector for DCMS input, generic parallel multi-instance, advanced BOB subprocess visual tooling, rule test cases managed within BE, graphical comparison of workflow versions, reusable configuration templates and marketplace, extensive runbook authoring.

**P2** if justified: complete BPMN 2.0 support and conformance test suite, process instance migration between versions, compensation/saga primitives, comprehensive ServiceNow ticket/approval integration after bank review, advanced observability, SQL Server Ledger if allowed, performance and multi-region fault tolerance, compile-time SDK manifest source generator.

Do not add legacy database provider support to BOB merely because OptimaJet offers it. Revisit business capability data providers according to actual service needs.

<!-- END SOURCE 059: docs/roadmap/BACKLOG-POST-MVP.md -->

---

<!-- BEGIN SOURCE 060: docs/roadmap/DELIVERY-PLAN.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# November 11–30, 2026 — Critical Path and Immediate Roadmap

**Start state:** AMIE mostly exists; BOB is an architectural/implementation bottleneck; BE is Blazor; v0.7 HTML is a prototype; production controls require Wells Fargo approval. **Confidence in full target before code audit:** unverified. Dates are planning checkpoints, not confirmed engineer availability or release promises.

## Calendar gates

| Window | Gate | Critical deliverable | Parallel work |
|---|---|---|---|
| Nov 11–12 | G0 Inventory | JOB-00 source/AMIE mapping, approved dependencies, demo pilot confirmation | Read-only technical discovery |
| Nov 12–13 | G1 Contract | JOB-01 stable operation/rule/BPMN/message/error/audit/release contracts | Prepare isolated fixtures |
| Nov 13–18 | G2 Foundation | SDK+manifest+registry; AMIE bridge; BPMN compiler; Kafka/SQL prototypes | JOB-02..05,07,08,09 |
| Nov 18–22 | G3 Thin vertical slice | Central->Kafka->embedded BOB+AMIE->handler->MSSQL history->BE status | JOB-06,10–14 |
| Nov 22–26 | G4 DCMS process | Batch/row GUIDs; sequential CyberArk; report/email; RBAC and operator controls | JOB-11–18; release gates |
| Nov 26–29 | G5 Regression / reuse | P0 test matrix; crash/duplicate/auth; second application if feasible | JOB-17,19,20 |
| Nov 30 | G6 Demo decision | Demonstrable integrated DEV/UAT configuration and documented gaps | Security/control owner decides bank PROD eligibility separately |

## Dependency graph

```mermaid
flowchart LR
  J0[JOB-00 Inventory] --> J1[JOB-01 Contracts]
  J1 --> SDK[JOB-02 SDK]
  SDK --> REG[JOB-03 Registry]
  J1 --> AMIE[JOB-04 AMIE]
  J1 --> BPMN[JOB-05 BPMN]
  BPMN --> HOST[JOB-06 Hosts]
  SDK --> HOST
  AMIE --> HOST
  J1 --> K[JOB-07 Kafka]
  J1 --> SQL[JOB-08 MSSQL]
  BPMN --> UI[JOB-09 Designer]
  REG --> INS[JOB-10 Inspector]
  UI --> INS
  J1 --> DATA[JOB-11 Ingest]
  SDK --> PAM[JOB-12 CyberArk]
  K --> EMAIL[JOB-13 Report/Email]
  SQL --> MON[JOB-14 Monitor]
  HOST --> OPS[JOB-15 Controls]
  UI --> RELEASE[JOB-16 Release]
  HOST --> DCMS[JOB-18 DCMS Pilot]
  K --> DCMS
  DATA --> DCMS
  PAM --> DCMS
  EMAIL --> DCMS
  MON --> DCMS
  DCMS --> DEMO[JOB-20 Demo]
  DCMS --> REUSE[JOB-19 Second app]
  TEST[JOB-17 Regression] --> DEMO
```

## Execution lanes

**Lane A — SDK/registry:** JOB-01 -> JOB-02 -> JOB-03, plus CyberArk handler inventory JOB-12.  
**Lane B — Engine:** JOB-05 -> JOB-06 with AMIE bridge JOB-04.  
**Lane C — Infrastructure:** JOB-07 Kafka, JOB-08 SQL/audit.  
**Lane D — Experience:** JOB-09/10 Blazor designer/inspector; JOB-14 dashboard/monitor, JOB-15 operators.  
**Lane E — Workload:** JOB-11 ingest, JOB-12 CyberArk, JOB-13 Email/Reporting, JOB-18 integrated DCMS; JOB-19 second use case.  
**Lane F — QA/Controls:** JOB-17 continuous regression, JOB-16 versioned promotion, JOB-20 demo.

## First integration spike (absolute priority)

One compiled approved **safe** handler exposed by SDK manifest -> registry API -> BE schema inspector -> BPMN service task + AMIE rule reference -> embedded execution -> Kafka correlated completion -> durable MSSQL run/audit -> BE status. The handler can be test-only until actual CyberArk adapter is authorized. No fake claims of real CyberArk operations.

## Cut order if deadline at risk

1. Drop P1 advanced BPMN, full visual polish, AutoSys, rich user tasks, full ServiceNow API, parallel batch and version migration.
2. Narrow to exactly one approved data source and one registered operation family, one report/email adapter.
3. Keep required safety: server auth, immutable version, correlation, idempotency/reconciliation, durable audit, API regression, truthful status.
4. Present second app only if same primitives genuinely reused with tests; otherwise show as planned demo not completed.

## Stop/go proof

G1: contract fixture unit tests pass, real AMIE adapter seam mapped.  
G2: compiler/SDK/registry startup tests pass, handler discoverable.  
G3: crash/duplicate run resumes and BE shows it.  
G4: DCMS five-row fixture, persisted outcomes, report and email status agree.  
G5: all P0 regression R01–R18 pass; bank review blockers visible.  
G6: demo works from a clean environment and cannot bypass authorization. PROD decision belongs to authorized bank controls.

## Ownership and deliverables

Each lane owns its PR(s). Integration owner merges after cross-team tests; control owner validates bank-specific gates. Every JOB file includes copy-ready DEVIN prompt, proposed path boundaries, criteria and negative tests. Do not start all twenty jobs concurrently without contract review—parallelize only after G1 to avoid incompatible SDKs.


## v1.0 workstream refinements (target date unchanged: Nov 30, 2026)

**Gate 0 (immediate):** SDK-10 source reconciliation + original JOB-00. Produce exact AMIE and BOB seams, approved dependencies and current CVIS service inventory; do not refactor working AMIE blindly.

**Gate 1:** original JOB-01 freezes `OperationDescriptor`, AMIE rule descriptor, typed binding, message envelope, workflow package/audit schema, and BE action API convention. Use schema fixtures and cross-team sign-off.

**Gate 2:** SDK-11/12/13 parallelize handler DI/registry and existing AMIE adapter; SDK-14/15/16 stabilize BOB dispatch, Kafka outbox/inbox and audit. UI-10 shell, UI-11 catalog/inspector, UI-12 library, UI-13 BPMN designer can run alongside once contracts freeze.

**Gate 3:** UI-14 typed AMIE/trigger forms, UI-15 business/run views, UI-16 operator/audit and UI-17 regression/release. Produce a single BOB service-task binding from BE, execute it via existing AMIE and a real registered handler in DEV.

**Gate 4:** SDK-18 DCMS 5-row fixture: CSV staging, batch number, row GUIDs, sequential embedded CyberArk processing, actual outcome persistence, Reporting+Email messaging, business dashboard and audit replay. Second workload reuse is stretch if timeline permits.

**Risk/cut:** defer advanced BPMN, arbitrary user forms, AutoSys integration, full live ServiceNow API, UI styling beyond usable wireframes, parallel batch and mid-flight version migration. Do not cut backend auth, schema validation, safe writes, audit, transport dedup/recovery or bank release gates.

Per-button and per-component acceptance: `docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md`; SDK tests: `docs/sdk/08-SDK-API-REGRESSION-SUITE.md`; detailed DEVIN assignments: `jobs/interaction/INDEX.md`.

<!-- END SOURCE 060: docs/roadmap/DELIVERY-PLAN.md -->

---

<!-- BEGIN SOURCE 061: docs/roadmap/END-TO-END-BPMN-NOVEMBER-ROADMAP-v1.1.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Roadmap - End-to-End BPMN UI, SDK and Four Pilot Configurations

**Planning date:** November 11, 2026. **Target demo:** November 30, 2026. These are proposed checkpoints, not claims of completed work. DEV demo != security, CA, runbook, ServiceNow or production approval.

## Dependency and parallelization map

```mermaid
flowchart LR
  A[JOB-00: Source audit] --> B[JOB-01: Contract freeze]
  B --> C[SDK-31: Handler/registry]
  B --> D[BOB-37: Shared interpreter]
  B --> E[BOB-38: Existing AMIE adapter]
  B --> F[BE-21/22: Reusable UI + wizard]
  C --> G[SDK-32/33: NAS/CyberArk]
  C --> H[BE-24/25: Dynamic inspector + binding]
  D --> I[BE-23: BPMN canvas]
  E --> H
  I --> J[BE-27/28: Validate/test/publish]
  H --> J
  G --> K[INT-39: DCMS end to end]
  J --> K
  D --> K
  K --> L[BE-29/30: Dashboard + audit]
  K --> M[QA-40: Regression, demo]
  L --> M
  G --> N[SDK-34: Account Delete mock]
  C --> O[SDK-35: AutoSys adapter]
  O --> P[SDK-36: Policy Drift compare]
  N --> M
  P --> M
```

## Priority cutline

| Priority | Scope | Demo proof | Defer when needed |
|---|---|---|---|
| P0 foundation | SDK registered operation, existing AMIE adapter, shared BOB BPMN subset, Kafka command/outcome, MSSQL checkpoints and audit | one registered operation discoverable and executable through BE/BOB/AMIE | advanced BPMN elements |
| P0 designer | Blazor shell, new draft, trigger CSV, service/rule picker, diagram, typed inspector, validate, test, save/publish DEV version | supported BPMN import/export XML+DI, 5-row fixture | full general-purpose forms builder |
| P0 DCMS | CSV -> staged batch + row GUID -> CyberArk attributes -> outcome -> report/email + dashboard | actual approved DEV integration or clearly marked external stub | scheduling API/AutoSys for DCMS |
| P0 observability | business count cards, run overlay, role-denial API, control/audit reconstruction | correlation across BOB/AMIE/capability/Kafka/SQL | advanced analytics |
| P1 Account Delete | guarded approval, dry-run, controlled delete operation with verification | mock or approved nonprod only | real destructive execution without approval |
| P1 AutoSys Policy Drift | approved scheduler trigger -> ZIP/INI ingestion + policy baseline compare | secure adapter trigger + representative policy fixtures | full AEWS integration and exhaustive legacy migration |
| P1 NAS actual service | reconcile existing API, EF Core model, operation registration, typed mappings | real DEV data-owner API read with correct scope | new generic DB query service |
| P2 future | parallel joins, advanced gateways, compensation, process instance version migration, full BPMN conformance | documented supported vs planned | all P2 deferred |

## Work calendar targets

| Dates (Nov 2026) | Checkpoint | Go/no-go evidence |
|---|---|---|
| 11-13 | Repository audit + contract freeze | existing AMIE and BE paths identified, approved dependencies enumerated, SDK/BPMN schemas agreed |
| 13-17 | SDK registry + BOB graph + base Blazor components | typed operation auto-discovered; mock BPMN service task parsed/validated; UI loads manifest |
| 17-21 | End-to-end draft authoring/test and durable execution | sample rule bound, tested, local/remote dispatch reconciles; cross-service trace |
| 21-25 | DCMS 5-row DEV integration, reporting/email, business progress | real evidence and failure paths, no double writes, dashboards update |
| 25-28 | AutoSys adapter/Policy Drift fixture and guarded Delete demo conditional; harden RBAC/audit | second distinct configuration reuses primitives, no false destructive/PROD claims |
| 28-30 | Freeze for demo and evidence | regression report, BOM/dependency approval status, runbooks/control gaps, known issues and fallback demo |

No human/DEVIN activity is assumed started. Adjust immediately after source audit; do not chase full BPMN palette at expense of a working verified vertical slice.

## Engineering release gates

- **G0 Source reality:** actual repo, AMIE implementations, service manifests, NAS meaning/owner, AutoSys version/job, approved CyberArk operations identified. Without source, docs only.
- **G1 Shared contract:** no incompatible SDK/BOB/BE DTO forks; operation key/version, rule refs and message envelope stabilized.
- **G2 BPMN behavior:** XML + DI roundtrip, graph parser, executing P0 subset, unsupported rejection, sequential/async wait semantics tested.
- **G3 Service execution:** one operation from BE through real authorized API/BOB/AMIE -> handler with proper audit/correlation.
- **G4 DCMS regression:** 5-row fixture, row GUID and reasons, failure recovery, report/email status separate, live business dashboard.
- **G5 Security/control:** direct API denial, per-app scope, sourceRunId dedupe, high-impact approval gate, no raw credentials, reconstructable audit.
- **G6 Demo:** fresh DEV deployment, runbook and operator-controlled restart/pause path, test evidence and outstanding controls honestly listed.

## Evidence packages per DEVIN PR

Source paths and modifications, typed contract diff, API/manifest update, BPMN XML fixture and expected trace, tests/run log (unit/API/integration/role-deny), screenshot or screen recording, audit event examples with masked data, rollback, ServiceNow/control requirements still open, and clear `New / Updated / Deleted / No Change` file summary.

## Dependencies and blockers to resolve rapidly

`NAS` actual API/EF model unknown, original Policy Drift SQL and PolicyId sanitizer require retrieval, AutoSys job identity/adapter requires policy approval, CyberArk delete API and dual-control rules require security approval, paid BPMN renderer depends on previously approved library inventory, existing AMIE interface must be reused, actual BE project and namespace unknown. Do not turn any of these assumptions into undocumented production facts.

<!-- END SOURCE 061: docs/roadmap/END-TO-END-BPMN-NOVEMBER-ROADMAP-v1.1.md -->

---

<!-- BEGIN SOURCE 062: docs/roadmap/STATUS-BOARD-TEMPLATE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# Implementation Status Board — Update in Actual Repository

**Snapshot at handoff (2026-11-11):** design delivered, no actual Unity repository inspected by this handoff. No job may be marked Done until implementation artifacts/tests are verified.

| Job IDs | State | Owner | PR | Latest test run | Blocker |
|---|---|---|---|---|---|
| JOB-00 / 01 | Not started | Assign | — | — | Actual repo/AMIE interfaces |
| JOB-02 / 03 | Not started | Assign | — | — | Frozen operation contracts |
| JOB-04 / 05 / 06 | Not started | Assign | — | — | Frozen AMIE/BOB semantics |
| JOB-07 / 08 | Not started | Assign | — | — | Kafka/SQL conventions |
| JOB-09 / 10 | Not started | Assign | — | — | Approved Blazor components |
| JOB-11 / 12 / 13 | Not started | Assign | — | — | DCMS/CyberArk/Email owners |
| JOB-14 / 15 / 16 | Not started | Assign | — | — | IAM/bank controls |
| JOB-17 | Not started | Assign | — | — | CI/repo test harness |
| JOB-18 / 19 / 20 | Not started | Assign | — | — | Integrated dependencies |

**State vocabulary:** Backlog, Ready (dependencies verified), In Progress, In Review, Blocked, Done (evidence confirmed). A green mock screen without backend implementation does not mean Done. For each transition record actor, UTC, commit/PR and failing tests.

<!-- END SOURCE 062: docs/roadmap/STATUS-BOARD-TEMPLATE.md -->

---

<!-- BEGIN SOURCE 063: docs/sdk/00-SDK-PURPOSE-SERVICE-BOUNDARIES.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 00 - Why a Unity Capability Service Exists

Status: DESIGN PROPOSAL built on user-established Unity architecture. Before coding, DEVIN MUST inspect the actual repo in JOB-00. Do not interpret proposed namespaces as implemented APIs.

## 1. Purpose and non-goals

A capability service is an independently deployed .NET service exposing approved, reusable business-system primitives through versioned typed contracts. It performs operations that require privileged access, domain validation, network or SDK interaction, or domain data ownership. It **does not own an application's end-to-end business workflow**.

Examples:
- CyberArk: GetAccount, FindAccount, ReadPlatform, ApplyAllowedAttributePatch, AddOrUpdateAccount, MoveAccount (only if separately implemented and authorized).
- Data/ingestion: ValidateCsv, StageBatch, GetPage, RecordRowOutcome, ReadBatchSummary. The owner owns business staging data, not BOB's workflow state.
- Email: SendApprovedNotification using template and recipient policies; the email transport is not inside BOB.
- Reporting: ComposeBatchReport, return access-controlled artifact reference; not automatically send email.
- Identity: ResolveUser/Group within approved scope; not a generic privileged directory browser.
- Legacy: Typed facade over a reviewed API; not arbitrary service method invocation.

Do not put DCMS-specific branches in CyberArk handlers, author AMIE rules in source code just for DCMS, create unrestricted SQL/HTTP operation handlers, or let BE submit arbitrary CLR assembly names or Kafka topics.

## 2. Platform responsibility matrix

| Concern | Source of truth | How consumers access it | Prohibited coupling |
|---|---|---|---|
| Workflow definition / version | BOB/Unity configuration package | BE designer + workflow API | Capability inventing its own private workflow format |
| Token execution / checkpoints | BOB shared interpreter | Embedded/central BOB host | Different semantics per host |
| Business decision/mapping | Existing AMIE runtime / published rule package | Typed AMIE adapter | BOB duplicating rule grammar |
| Compiled primitive/permissions | Capability release + manifest | Registry/dispatcher/worker | BE invoking arbitrary C# type |
| Event transport | Kafka with approved logical contracts | Shared SDK outbox/inbox | Browser talking to Kafka directly |
| Operational current state | Workload data owner and BOB projection | Authorized APIs/BE view | All capabilities reading one shared DB |
| Immutable audit history | Append-only MSSQL event store | Scope-filtered audit API | Audit derived only from ephemeral logs |
| Visualization, authorization UX | BE (Blazor) | API-first UI | Hiding buttons as sole security control |
| Release and approvals | Operations/change-control process | Release API + immutable package | Developer direct PROD access |

MSSQL is the sole **BOB persistence** target for MVP; capability-owned business data may use its approved datastore or API. No cross-service direct table access is implied.

## 3. Minimum contracts every service must supply

1. **Service identity**: capability key, code release/version, service owner, deploy identity and health.
2. **Operation descriptors**: stable `capability.operation@major.minor` identity, request and result schema, classification, required permission/scope, side effect, retry/reconcile mode, supported execution hosts, timeout, fixture identifiers.
3. **Message descriptors**: logical inbound command/outbound outcome identities, schema, partition key, idempotency key construction, consumer group and permitted environment bindings. Kafka physical topic names and credentials are never authored in workflow tasks.
4. **AMIE binding descriptors**: each rule's expected facts and typed decision/output; operation descriptions cannot guarantee a rule is installed.
5. **Invocation boundary**: authenticated `OperationInvocation` with process/activity IDs, pinned package digest, actor/service identity references, correlation/causation IDs and idempotency key.
6. **Execution outcome**: `Succeeded`, `NoChange`, `Rejected`, `Failed`, `UnknownExternalOutcome`, with safe reason code and trace reference. Distinguish operation disposition from business row status.
7. **Audit**: structured evidence for invocation, authorization, decision, dispatch, attempt, external action, completion/reconciliation, without raw credentials or sensitive account objects.
8. **Diagnostics**: health/registry status, effective operation version, schema/contract mismatch errors, safe test fixtures; no health signal alone authorizes invocation.

## 4. Two registration events - must not be confused

- **Local registration** on trusted service startup: approved compiled operation handlers are discovered/explicitly registered in DI, validated, and made callable by the local dispatcher.
- **Enterprise publication** on approved deployment: trusted service identity submits a signed or attested manifest to registry; registry checks owner, environment compatibility, release approval, schema and permissions; only then may BE discover executable operations for its assigned scope.

An operation is useable only when the published manifest is compatible, the running service is healthy, environment bindings are configured, required auth is satisfied, and the operation is explicitly allowed for the application and workflow package.

## 5. Three execution shapes

1. **Local**: Embedded BOB invokes handler via DI, AMIE through existing local adapter. Avoid per-step central roundtrips.
2. **Remote command**: Central BOB persists an outstanding activity/command + outbox; broker delivers command to owning capability; worker validates and executes; correlated outcome resumes central BOB once.
3. **Capability subworkflow**: One approved message invokes a pinned embedded subworkflow (e.g. process staged batch rows sequentially). Worker performs several local handler/AMIE steps and emits aggregate/progress events; central host does not schedule every row's local steps.

## 6. Definition of reusable success

A safe operation registered once can appear in the BE catalog, bind to a published BPMN service task and AMIE rule, execute in its authorized host, produce consistent run/audit evidence and then be reused in a **second unrelated workflow without a new handler or BOB Core change**.

## 7. Immediate acceptance proof / no fake completion

DEVIN must show: actual handler class in repo, DI registration, manifest metadata and API response, registry approval state, BE operation inspector with typed inputs, a runnable approved BPMN path, existing AMIE runtime invocation, an outcome and audit event, a negative direct-API permission test, and replay/restart tests. Demo fixtures do not prove a real CyberArk integration.

<!-- END SOURCE 063: docs/sdk/00-SDK-PURPOSE-SERVICE-BOUNDARIES.md -->

---

<!-- BEGIN SOURCE 064: docs/sdk/01-SDK-CONTRACTS-AND-STATES.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 01 - Canonical Contracts, Identity, and State Machines

Status: PROPOSED until reconciled to existing repo. Dependencies: `docs/contracts/OPERATION-CONTRACT.md`, `docs/contracts/MESSAGING-CONTRACT.md`, `docs/architecture/04-AMIE-BINDINGS.md`.

## 1. Contract boundaries and proposed assembly paths

- `/Unity.Capabilities.Contracts/CapabilityManifest.cs`: metadata only; no executable classes in serialized payload.
- `/Unity.Capabilities.Contracts/OperationDescriptor.cs`: operation key/version, schema, permission, side effect, auth scope, retry/reconciliation, transport, AMIE requirements, examples.
- `/Unity.Capabilities.Contracts/OperationInvocation.cs`: request DTO + authenticated execution context.
- `/Unity.Capabilities.Contracts/OperationOutcome.cs`: typed disposition, safe reason, result and external reconciliation reference.
- `/Unity.Capabilities.Hosting/IUnityOperationHandler.cs`: compile-time typed operation interface.
- `/Unity.Capabilities.Hosting/OperationDispatcher.cs`: verified allowlist routing to DI handler; no client-provided CLR name resolution.
- `/Unity.Capabilities.Registry/ManifestPublisher.cs`: deployment/privileged registry action, NOT triggered merely by runtime scanning.
- `/Unity.Capabilities.Kafka/CommandConsumer.cs`: schema/auth/inbox/dispatch, outcome and outbox.
- `/Unity.Capabilities.BOB/EmbeddedWorkflowAdapter.cs`: bridge to shared interpreter.
- `/Unity.Capabilities.AMIE/AmieRuleAdapter.cs`: thin adapter to current existing rule engine.

Choose final project names only after JOB-00 inventory. Namespace conventions must follow existing services.

## 2. Proposed C# interface sketches

```csharp
public interface IUnityOperationHandler<TRequest, TResponse>
{
    Task<OperationOutcome<TResponse>> ExecuteAsync(
        TRequest input, UnityExecutionContext context,
        CancellationToken cancellationToken);
}

public sealed record UnityExecutionContext(
    string ApplicationKey, string DefinitionKey, string DefinitionVersion,
    Guid RunId, string ActivityId, string CorrelationId, string CausationId,
    string ActorContextRef, string PackageDigest, string IdempotencyKey,
    string? BatchId, Guid? RecordGuid, string? TraceParent);

public enum OperationDisposition
{
    Succeeded, NoChange, Rejected, Failed, UnknownExternalOutcome
}

public sealed record OperationOutcome<T>(
    OperationDisposition Disposition, string ReasonCode, string SafeReason,
    T? Result, string? ExternalOperationRef, string? ResultHash);
```

These are examples for contract alignment, NOT source already available. An input DTO contains business data; the execution context contains provenance and auth references. Data types must be serializable and compatible with existing library conventions.

## 3. Required OperationDescriptor fields

| Group | Required property | Validation |
|---|---|---|
| Identity | capabilityKey, operationKey, contractVersion | Unique key + compatible version; names cannot shadow another capability |
| Service | codeVersion, owner, manifestDigest | Code/manifest release must agree |
| Data | input/output JSON Schema, required fields, classification, fixture IDs | Validate examples and required fields; never generate schema from untrusted runtime input |
| Authentication | policy name, permitted resource scopes, service audience | Fail closed at registry and worker; no trust from UI alone |
| Side effects | Read / LocalTransform / ExternalWrite / HighImpactExternalWrite | Write has idempotency/reconciliation and control references |
| Execution | EmbeddedLocal / KafkaCommand, timeout and cancellation | At least one supported mode; no unapproved direct route |
| AMIE | required rule/data descriptor versions | Rule must resolve, pin and type-check before publish |
| Messaging | inbound/outbound logical types, partition/correlation/idempotency strategy | Broker binding checked per environment |
| Evidence | audit code, redaction profile, safe test fixture | No secrets or raw sensitive account payload in audit |

## 4. Lifecycle / state transitions

### Operation manifest

`CodeWritten -> BuiltAndTested -> ServiceApproved -> Deployed -> ManifestSubmitted -> Registered -> Available -> Deprecated -> Retired`.

- `Registered` is metadata-only. `Available` also requires healthy compatible service, environment ACL/policy and permitted application scope.
- Code release and configuration release are separate. A workflow can only invoke an operation available in its deployment environment and compatible with its pinned contract.
- Removing an operation from available list does NOT delete historical manifest metadata used for audit.

### Workflow definition

`Draft -> InReview -> Approved -> Published -> Active -> Retired`.

- Editing Published or Active creates a new Draft/version; all existing runs stay pinned.
- Publication requires BPMN subset/compiler validation, typed bindings, rule and operation compatibility, approved roles and change evidence.
- `Approved` is not `Active`; Operations owns activation according to real bank controls.

### Process run

`Created -> Running -> PauseRequested -> Paused -> Running`, plus `CancelRequested -> Cancelled`, `Completed`, `Failed`, and `AwaitingOutcome`/`ReconciliationRequired` substates as needed.

- Pause is cooperative at safe checkpoint; active CyberArk HTTP call cannot be magically stopped/undone.
- Cancel is cooperative; terminal `Cancelled` only when known work has settled or is explicitly marked unresolved.
- RetryFailedStep is permitted only where the dispatcher can establish prior outcome or safely reconcile it.
- RestartAsNewRun creates a fresh RunId and linkage to previous RunId; never erases original audit history.

## 5. Contract version pinning and backwards compatibility

- Workflow package pins explicit `operationKey@contractVersion`, AMIE `ruleKey@version`, called-subworkflow version, source schemas and package digest.
- Additive optional DTO fields may be compatible only after contract tests; removing required inputs or changing side-effect semantics is a breaking version.
- At runtime, no implicit fallback to `latest`. If pinned dependency is absent, fail start or enter `BlockedByDependency` with audit.
- Service code versions are tracked separately from operation contract versions; a new service deployment may preserve the contract only if compatibility tests pass.

## 6. API contracts (all future routes proposed)

- `GET /api/v1/capabilities`, `GET /api/v1/capabilities/{key}/operations`, `GET /api/v1/operations/{key}/versions/{version}`.
- `POST /api/v1/manifests/validate`, `POST /api/v1/manifests/submit`, `POST /api/v1/manifests/{id}/approve`, `GET /api/v1/manifests/{id}/readiness`.
- `POST /api/v1/operation-tests/{key}/execute` (non-PROD approved fixture only, separate test permission).
- `POST /api/v1/workflow-drafts/{id}/validate`, `POST /api/v1/workflows/{key}/runs` and authorized lifecycle endpoints.

Every endpoint must be OpenAPI-described and tested directly without a browser, including denied and invalid requests. Never let a generic test endpoint execute arbitrary operations or reach PROD.

<!-- END SOURCE 064: docs/sdk/01-SDK-CONTRACTS-AND-STATES.md -->

---

<!-- BEGIN SOURCE 065: docs/sdk/02-AUTOMATIC-REGISTRATION-AND-NEW-SERVICE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 02 - Automatic Registration, Service Bootstrap and Registry Publication

Status: implementation design; current AMIE/capability conventions are unknown until source audit.

## 1. Creating a service (dev workflow)

1. Select the domain owner and service archetype: CyberArk/PAM, Data, Email, Reporting, Identity or Legacy. Determine data owner, environment policies, and broker requirements.
2. Create the service from an approved .NET service template; reference shared Unity.Contracts and Unity.Hosting packages already reviewed by Wells Fargo.
3. Implement typed handlers. Write handler metadata (`UnityOperation` attribute or equivalent compile-time registration) and DTOs; no dynamic code execution. Handler must be DI-constructible and in an allowlisted compiled assembly.
4. Classify each operation: read, local transform, external write or high-impact external write; define permission, timeouts, idempotency and result reconciliation.
5. Implement adapter clients and secret refs through approved DI; do not put credentials in handlers/manifests.
6. Add AMIE rule descriptors only as **references/typed bindings**. Existing AMIE compiler/evaluator remains authoritative.
7. Declare logical command/outcome contracts; environment settings map logical keys to authorized Kafka topics/consumer groups.
8. Register handlers in startup; on failure in production registration fail fast with deterministic diagnostic (duplicate key, invalid schema, missing policy, wrong major version).
9. Generate manifest + JSON Schema + examples + OpenAPI metadata as build outputs; verify against approved fixtures.
10. Run CI tests, create/approve ordinary service-code release, deploy via approved pipeline, submit manifest via privileged service identity.
11. Registry checks signature/provenance, service release, owner, compatibility, policies, and environmental readiness; BE discovers only the properly scoped descriptors.
12. Reuse the operation from an authorized workflow; observe correlated audit and repeat in a second workflow without code changes.

## 2. Example registration (illustrative, not verified repo API)

`/Unity.Capability.CyberArk/Program.cs`

```csharp
builder.Services
  .AddUnityCapabilityHost(o => o.CapabilityKey = "CyberArk")
  .RegisterApprovedOperations(typeof(GetAccountHandler).Assembly)
  .UseExistingAmieAdapter()
  .UseEmbeddedBob()
  .UseKafkaContracts()
  .UseStructuredAudit();
```

The implementation must scan **only** assemblies allowed by the deployed service configuration or use compile-time generator registration. Do not accept assembly names or method names from the network or manifest consumers.

`/Unity.Capability.CyberArk/Operations/GetAccountHandler.cs`

```csharp
[UnityOperation("CyberArk.GetAccount", "1.0",
   Policy = "PAM.Account.Read", SideEffect = "Read")]
public sealed class GetAccountHandler
    : IUnityOperationHandler<GetAccountRequest, GetAccountResponse>
{
    private readonly ICyberArkClient _client;
    public GetAccountHandler(ICyberArkClient client) => _client = client;

    public async Task<OperationOutcome<GetAccountResponse>> ExecuteAsync(
        GetAccountRequest request, UnityExecutionContext context,
        CancellationToken ct)
    {
        // Actual adapter, error mapping and authorization must be implemented
        // against the existing service. No mock production client.
        var account = await _client.GetAccountAsync(request.AccountRef, ct);
        return new(OperationDisposition.Succeeded, "ACCOUNT_FOUND",
                   "Account read succeeded", new(account), null, null);
    }
}
```

Example intentionally omits credentials and concrete SDK/library details. Real code must use existing policy, cancellation, retry and audit interceptors.

## 3. Startup validation algorithm

1. Discover allowed handler type and declaration.
2. Verify exactly one expected typed interface and DI registration.
3. Verify unique operation key/version and permitted compatibility major.
4. Validate input/output JSON schemas against DTOs, fixtures and declared classification.
5. Ensure required permission/scope and side-effect policy are supplied.
6. For writes, require idempotency behavior and `UnknownExternalOutcome` reconciliation strategy.
7. Check message contract names, required fields, correlation and partition key.
8. Validate AMIE descriptor references are resolvable for declared runtime where needed.
9. Construct immutable manifest with deterministic digest; emit startup diagnostic state.
10. Expose metadata to authenticated deployment/registry agent, but DO NOT self-approve.

## 4. Manifest publication lifecycle

Build CI produces manifest artifact and approved service release -> release pipeline deploys binary -> signed deployment identity submits manifest -> Registry validates owner, signature, compatible handler/codeVersion, exact schema, environment ACL -> Registry marks `Registered` -> operational readiness checks mark `Available` -> BE discovery is scope filtered -> BOB can bind only `Available` approved operations. Republish or revoke under control; no arbitrary end-user registration from BE.

## 5. New primitive vs configuration decision

Ask in order:

- Is there an approved operation that already produces the required output? Reuse it.
- Can a combination of existing operations, BOB control flow and AMIE mapping produce the result without bypassing security? Configure it.
- Is a new domain primitive required (e.g. verified safe movement)? Implement once in owning capability with a reviewed code release, schema, policy and tests.
- Is the proposed primitive unbounded (generic REST executor, arbitrary SQL, direct C# eval)? Reject and replace with typed approved operation.

## 6. DEVIN coding boundaries

- Preserve existing DI host style, .NET version, project names and namespace conventions.
- Do not generate a new central AMIE runtime or duplicated BOB interpreter.
- Do not hardcode physical topic names or endpoints into descriptors.
- Do not include DCMS as a capability kind. DCMS is an application/workload config.
- Publish PR with actual `/Project/Folder/File.cs` paths and New/Updated/Deleted/No Change summary.
- Add unit/contract tests and a demo showing operation discoverable in BE and reject unauthorized direct call.

<!-- END SOURCE 065: docs/sdk/02-AUTOMATIC-REGISTRATION-AND-NEW-SERVICE.md -->

---

<!-- BEGIN SOURCE 066: docs/sdk/03-BOB-AMIE-KAFKA-EXECUTION.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 03 - BOB, AMIE, Capability and Kafka Interaction Protocol

This is the interaction contract DEVIN must implement or map to existing code. It is a **proposed architecture**, not a verified current runtime.

## 1. Central versus embedded host boundary

```mermaid
sequenceDiagram
  participant BE as BE API / Designer
  participant CB as Central BOB
  participant SQL as MSSQL state and outbox
  participant K as Kafka
  participant CH as Capability Host / Embedded BOB
  participant AM as Existing AMIE
  participant H as Approved handler
  participant AU as Audit
  BE->>CB: Start approved workflow package
  CB->>SQL: Persist run + waiting command + outbox atomically
  SQL-->>K: Outbox dispatcher emits authorized command
  K-->>CH: Deliver command (may be repeated)
  CH->>CH: Verify auth, digest, inbox key, compatibility
  CH->>AM: Evaluate pinned rule locally
  AM-->>CH: Typed decision + reason
  CH->>H: Execute handler using typed mapped input
  H-->>CH: Outcome incl external reference
  CH->>AU: Append safe operation/decision evidence
  CH->>K: Publish correlated outcome via outbox
  K-->>CB: Deliver outcome (may be repeated)
  CB->>SQL: Compare-and-swap complete waiting activity
  CB-->>BE: Status projection / secured near-real-time hint
```

Embedded BOB uses the **same** BPMN parser/compiler/interpreter as central BOB; its host adapter selects local DI, AMIE, and storage/transport. Central BOB may wait durably in MSSQL. Do not implement an application-specific local workflow engine inside the CyberArk adapter.

## 2. Compilation of a workflow designed in BE

1. Load BPMN 2.0 XML + BPMN DI geometry; reject malformed XML, unsupported semantic elements, unreachable branches, missing IDs and ambiguous joins.
2. Parse vendor-neutral service tasks / business rule tasks; read Unity extension bindings (operationKey@version, ruleKey@version, input/output mapping, host, retry policy).
3. Resolve approved Capability Registry manifest and AMIE rule descriptor, including ownership, availability, schemas, permission and side effect.
4. Type-check every source (trigger field, item field, prior task output, rule output, constant, environment ref, secret ref) against required input. Null/default/classification policy must be explicit.
5. Resolve child/call activity and sequential multi-instance semantics. Pin exact dependency versions and output a deterministic package lock/digest.
6. Check configured execution host can access the requested local handler and AMIE rule; otherwise require remote command mode. Reject silent transport fallback.
7. Enforce allowable concurrency, timeouts, cancellation and retry/reconciliation behavior; no unsafe automatic retry for CyberArk external writes.
8. Emit prepublish validation results by BPMN element ID, field path, severity, code, description and suggested action. Only error-free approved definitions can publish.

## 3. On executing a local task

1. Shared BOB evaluates task input binding in a typed workflow context.
2. Before a privileged handler, authorize service identity and the signed actor context/scope at dispatch; BOB's previous validation alone is not sufficient.
3. Dispatcher resolves an allowlisted `operationKey@contractVersion` to a DI handler. It never reflects untrusted CLR method names.
4. Invoke with `UnityExecutionContext`, cancellation token, per-operation timeout and safe telemetry scope.
5. Validate output schema, redact classified data, persist outcome/audit and advance token exactly once.
6. For local AMIE business-rule task, call existing AMIE API, not a new rule interpreter; obtain typed decision and safe reason. Version pin is mandatory.

## 4. On remote task through Kafka

Before publish, persist *both* pending command state and outbox record in one BOB-owned transaction. Kafka producer publishes pending outbox. The capability consumer validates schema, broker principal, caller audience, policy, idempotency key and package version, then checks inbox. For duplicates, replay prior stable outcome or reject safely. Execute handler and persist outcome in same capability-controlled transaction when possible; external CyberArk writes are not part of that transaction and require reconciliation.

The outcome envelope includes command ID, causation/correlation ID, run ID, activity ID, operation key/version, status, reason code and safe result reference. The BOB outcome consumer updates its waiting activity only once by optimistic concurrency. Out-of-order and late messages are recorded; they do not advance the wrong run.

## 5. Failures and reconciliation

| Failure | Required behavior | Forbidden behavior |
|---|---|---|
| Invalid input schema | Reject before dispatch, audit safe error | Invoke handler with half-built DTO |
| AMIE rule false | Follow configured BPMN branch, record rule reason | Treat false as CyberArk write failure |
| Handler returns NoChange | Persist business NoChange and continue | Report update success without a write |
| CyberArk returns clear failure | Record Failed with safe reason/retry policy | Infinite unbounded retry |
| Network timeout after write request | `UnknownExternalOutcome`; reconcile with external reference/state | Blindly retry a possibly successful write |
| Kafka message duplicate | Inbox dedup, replay stable outcome | Execute same write twice |
| Kafka outcome lost | Keep durable waiting state, retry transport or query correlation | Move token to success without evidence |
| Worker crashes mid-batch | Resume at checkpoint and reconcile current row | Restart batch from row one without checking outcomes |
| Pause while write in flight | Set PauseRequested, stop new steps at safe checkpoint | Kill ongoing HTTP call and claim rollback |
| Cancel | Cooperative stop, mark unfinished work explicitly | Delete history or claim external rollback |
| Retired rule/handler after start | Keep pinned version if still available or mark dependency blocked | Replace with newest rule without review |

## 6. DCMS as application-level sequence

Central BOB: authorized manual CSV / future API start -> Data capability stage -> create batch and row GUIDs -> send `ExecuteEmbeddedWorkflow` to CyberArk capability -> wait for result -> report generation -> Email Capability -> summarize and close. Embedded BOB: get bounded page -> sequential multi-instance row loop -> CyberArk.GetAccount -> AMIE eligibility -> AMIE mapping -> CyberArk ApplyAllowedPatch in memory -> CyberArk AddOrUpdate -> row outcome persist -> next row -> aggregate completion. This is a **configured** workflow, not special code in BOB or SDK.

## 7. Evidence contract

At minimum emit `WorkflowStarted`, `TaskScheduled`, `RuleEvaluated`, `OperationRequested`, `OperationCompleted|UnknownOutcome`, `RowOutcomeRecorded`, `WorkflowPaused|Resumed|Cancelled|Completed`, `NotificationRequested`, `NotificationOutcome`, `ConfigurationPublished|Activated`, and `ControlAction` with actor, UTC, version digest, correlation, run/activity, source references and safe summary.

<!-- END SOURCE 066: docs/sdk/03-BOB-AMIE-KAFKA-EXECUTION.md -->

---

<!-- BEGIN SOURCE 067: docs/sdk/04-DATA-SCHEMAS-AND-UI-BINDINGS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 04 - Schema-driven BE Forms and AMIE/BOB Binding

## 1. Why the descriptor is a UI contract

When capability publishes a `GetAccount@1.0` descriptor, BE should automatically render: operation title, required/optional input fields, data types, source binding controls, output variables, execution host choices, permissions/side effects, timeout/retry and test fixture. No CyberArk-specific Razor form should be required for each operation.

## 2. Unified typed binding descriptor (proposed)

```json
{
  "targetField": "accountRef",
  "sourceKind": "CurrentItem",
  "sourcePath": "item.accountRef",
  "expectedSchemaRef": "schema://cyberark/account-ref/1.0",
  "nullable": false,
  "onMissing": "ValidationError",
  "dataClassification": "Internal"
}
```

Supported source kinds for MVP: WorkflowInput, CurrentItem, PriorOperationOutput, AmieRuleOutput, ConstantAllowlisted, EnvironmentBinding, SecretReferenceServerSide. The user sees logical references only; raw secrets must never be resolved into browser fields or BPMN XML.

## 3. Binding builder behavior

1. User selects an operation in Capability Catalog and clicks Add to Workflow.
2. Designer inserts a service task with stable BPMN element ID and pinned operation key/version.
3. Inspector fetches operation descriptor from authorized API and dynamically renders input slots.
4. For each slot, user picks source kind; picker offers only in-scope upstream outputs with a compatible JSON schema/data classification.
5. A missing required field is visibly invalid. An incompatible type is invalid even if a fake preview happens to work.
6. On adding AMIE rule, inspector loads rule descriptor and offers required facts from available workflow context; resolved decisions become branch conditions.
7. User chooses permissible host (Local vs Kafka) only from operation manifest and workflow deployment constraints.
8. Save persists a Draft (ETag/optimistic concurrency), Validate calls backend BOB compiler and AMIE adapter validator, Preview runs only deterministic DEV fixtures.
9. A published package locks exact manifests/rules/BPMN/subprocess versions; designer previews do not grant production execution.

## 4. Dynamic form generation

Inputs may have `type`, `format`, `enum`, `required`, `minLength`, `maxLength`, `maximum`, `pattern`, `description`, `classification` and optional approved UI hints. Required data is derived from the schema, never from the decorative mockup. The form engine supports hidden fields only for security/data dependency, server-side validation and structured error display. It must not expose an unrestricted JavaScript expression or C# editor to end users.

## 5. Example DCMS bindings

| Task | Field | Source | Validation |
|---|---|---|---|
| StageBatch | uploadedCsvRef | trigger.uploadRef | Authorized non-secret file ref, file passed safety checks |
| GetPage | batchId | steps.stage.output.batchId | Typed batch identifier, paginated bounds |
| GetAccount | accountRef | item.accountRef | Required, correct scope |
| AMIE.AccountEligibility | row, account | item + steps.get.output.account | Pinned rule and fact schemas match |
| AMIE.AttributeMap | row, platform | item + steps.get.output.platform | Only allowed custom attributes emitted |
| ApplyAllowedPatch | account, patch | previous account + rules.map.output.patch | Platform-specific patch schema validated |
| AddOrUpdate | modifiedAccount | steps.apply.output.account | Write authorization + reconcile policy |
| RecordRowOutcome | recordGuid, result | item.guid + steps.upsert.output | Side-effect outcome distinct from rule-pass |
| ComposeBatchReport | batchId | workflow.input.batchId | Counts reconciled against terminal rows |
| RequestNotification | reportRef, recipientPolicyRef | steps.report + config | Permission and recipient allowlist |

## 6. Designer error contract

Return errors as `{code, severity, bpmnElementId, fieldPath, message, suggestedAction}`. Required examples: `BIND_REQUIRED`, `BIND_TYPE_MISMATCH`, `BIND_UNAUTHORIZED_SCOPE`, `RULE_VERSION_UNAVAILABLE`, `OPERATION_NOT_APPROVED`, `HOST_MODE_UNSUPPORTED`, `BPMN_ELEMENT_UNSUPPORTED`, `DUPLICATE_OPERATION_KEY`. BE must display them on the affected node and in a keyboard-accessible issue list. A disabled Publish button is not a substitute for backend rejection.

## 7. Example data source GUI

- Node selected: `Task_GetAccount`.
- Operation inspector: `CyberArk.GetAccount@1.0`; permission `PAM.Account.Read`.
- Required `accountRef` -> choose Current Item -> `DCMS.Row.AccountRef`.
- Output `AccountRecord` -> name `account`.
- Test contract -> sanitized fixture only (DEV); result visible with safe event IDs.
- Validate -> green only if BE/backend schema, AMIE dependencies, host and permissions agree.

## 8. Explicit design alternatives

For MVP, an auto-generated property inspector plus a controlled binding picker is more feasible than a full no-code generalized forms builder. Advanced expression editing, custom renderers, full human-task form designer and advanced BPMN elements remain backlog unless first pilot proves they are required.

<!-- END SOURCE 067: docs/sdk/04-DATA-SCHEMAS-AND-UI-BINDINGS.md -->

---

<!-- BEGIN SOURCE 068: docs/sdk/05-SECURITY-AUDIT-PROMOTION.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 05 - Security, Audit, Operator Controls, and Release Promotion

## 1. Least privilege / identity

Every invocation checks backend API auth, workflow/app scope, resource scope, service identity and operation permission, **again in the capability worker**. A user may view only their own batch without permission to view the BPMN process, inspect safe audit events or operate runs. BE controls visibility but does not enforce security alone. Align bank roles to actual SSO groups after owner review.

Proposed roles: BusinessRequester, BusinessExecutor, WorkflowDesigner, RuleMaintainer, CapabilityMaintainer, WorkflowReviewer, ProcessOperator, ReleaseOperator, Auditor and PlatformAdministrator. Role names are placeholders pending enterprise mapping. No shared wildcard admin role for ordinary users.

## 2. Audit storage strategy

MSSQL append-only events are the operational source for reconstruction. Tables for current run/batch status are projections for fast reads. Preserve event version, eventId, UTC event/record time, run/activity, message/correlation/causation, actor/service identities, operation/rule/package version references, batch/row GUID, reason/outcome, resource scope, relevant ServiceNow ticket and runbook/control ID, and payload hash/protected reference. Prevent update/delete for normal service roles; consider write-once controls, retention and ledger separately with bank approval.

Audit export is a controlled, scope-filtered API; redact credentials, raw account content, tokens and sensitive CSV data. The event history is not a secret copy of source payloads.

## 3. Operator semantics

| Command | Precondition | Result / audit | Forbidden |
|---|---|---|---|
| Pause | Running, ProcessOperator for scope, reason, current revision | PauseRequested; reach Paused at safe boundary, emit reason/time | Pretend to reverse a started write |
| Resume | Paused, compatible pinned dependencies, authorized | Running, queue next task, audit | Resume incompatible retired dependency silently |
| Cancel | Running/Paused, authorized reason | CancelRequested; settle or reconcile outstanding, then Cancelled | Remove historical evidence |
| RetryFailedStep | Failed at safely retryable step, reconciled prior attempt | New attempt on same run with linkage | Blind retry on unknown CyberArk write |
| RestartAsNewRun | Terminal run, authorized and policy allows | New runId linked to old, new explicit input selection | Reuse old runId or alter original outcomes |
| Export audit | Scoped auditor access | Evidence export with redaction and audit of export | Leaks raw secret/sensitive fields |

All mutating actions require expected revision/ETag to prevent two operators issuing conflicting commands. UI shows pending acknowledgement and refreshes from server; local click is not authoritative success.

## 4. Release and production control flow

- Author creates/validates draft in DEV. BPMN, AMIE rules, capability contract versions and bindings manifest are locked into immutable package digest.
- Reviewer checks diff, complete test evidence, maker/checker separation where required, and change ticket. Approval is an authoritative backend event, not a typed ticket field.
- UAT deploys **exact package bytes**, substitutes only allowlisted environment refs, executes regression and captures evidence.
- Release Center production preflight checks signature/digest, compatible live service manifests, Kafka ACL, secrets refs without exposing values, rule versions, approved CA/control evidence and user rights.
- Operations-controlled pipeline activates package; developer does not need PROD access. Existing runs stay pinned, new runs receive new active version.
- Rollback selects previously approved package for **future** starts. It does not roll back external CyberArk writes.

## 5. Controls vs software permissions

Runbooks/controls specify required operational procedure, permitted exception path, required evidence, escalation and owner. Roles specify who may invoke which API. Both must be represented and validated separately. Actual Wells Fargo CAs, control IDs, retention and ServiceNow integration are UNKNOWN until verified by authorized owner. Never invent them or mark a mock ticket as bank approval.

## 6. Production-safe testing

- Developer/tester fixtures run only in isolated DEV/UAT with approved test accounts and test broker bindings.
- Destructive or external writes must use approved fake server/test tenant or explicit owner permission.
- No API Regression button executes production writes or creates broker subscriptions from arbitrary user input.
- Negative tests: denied direct API, altered manifest digest, wrong environment binding, duplicate command, timeout during external write, cross-tenant data disclosure, self-approval and missing control evidence.

<!-- END SOURCE 068: docs/sdk/05-SECURITY-AUDIT-PROMOTION.md -->

---

<!-- BEGIN SOURCE 069: docs/sdk/06-DCMS-EXAMPLE-END-TO-END.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 06 - DCMS: End-to-End Composition, Configuration, Execution and Evidence

**Purpose:** Use the user-described DCMS behavior to prove the generic Unity platform. DCMS must remain a workload/application, not SDK/BOB special code. Field names, CyberArk DTOs and API return codes must be confirmed in repo.

## 1. Source-described business process (do not reinterpret)

- User uploads CSV containing new values for account/platform custom attributes.
- Import rows into a data-owned table. Assign **one batch number** to the import and a **GUID to every row**.
- Process each row sequentially for the initial workflow.
- Locate the corresponding CyberArk account.
- Replace/add the specified custom attribute values **in account memory first**.
- Execute add/update account API call.
- Record per-row success/failure/pass/skipped and human-useful reason.
- After batch completion, generate report with all pass/fail/success reasons and send via Email Capability.
- Future (NOT currently implemented): approved API ingestion, scheduled AutoSys/DB API pull, additional trigger sources; leave extension seams rather than implementing prematurely.

## 2. Service inventory and compile-time primitives

| Primitive (proposed stable key) | Owner | Input -> Output | Side effect | Required protection |
|---|---|---|---|---|
| Data.ValidateUpload | Data/ingestion | uploadRef -> validation | Read | file policy, schema, classification |
| Data.StageBatch | Data/ingestion | validatedRef -> batchId, rowCount | DB write | idempotent upload key |
| Data.GetBatchPage | Data/ingestion | batchId, pageCursor -> page rows | Read | owner-scope, pagination |
| CyberArk.GetAccount | CyberArk | accountRef -> accountRecord | Read | PAM.Account.Read |
| CyberArk.ApplyAllowedAttributePatch | CyberArk | accountRecord, patch -> modifiedRecord | In-memory transform | platform allowlist |
| CyberArk.AddOrUpdateAccount | CyberArk | modifiedRecord + revision -> writeOutcome | External write | PAM.Account.Update, reconciliation |
| Data.RecordRowOutcome | Data/ingestion | rowGuid, disposition, reason -> persisted status | DB write | expected revision + idempotency |
| Reporting.ComposeBatchReport | Reporting | batchId -> secureReportRef | Artifact write | scope, redaction |
| Email.SendApprovedNotification | Email | reportRef, recipientsPolicyRef -> delivery outcome | External send | recipient policy + deduplication |

All keys are **candidates**. Existing CyberArk and data operations in the repo must be mapped, not rewritten.

## 3. AMIE descriptors (proposed, not current source names)

- `DCMS.ValidateAccount@1`: facts CurrentRow+GetAccountResult+Platform; result Eligible/Skip/Reject with reasonCode.
- `DCMS.MapAttributes@1`: facts CurrentRow+Platform; result typed `CyberArkAttributePatch` of four allowed custom attributes.
- `DCMS.ShouldUpdate@1`: facts original account + proposed patch; result Update/NoChange and reason.
- `DCMS.ClassifyBusinessResult@1`: facts validation+actual external outcome; result business status/reason (do not conflate with successful validation).

Rules are configuration. No static `if application == DCMS` in CyberArk or BOB. AMIE evaluator is existing code; use adapter.

## 4. UI configuration click path

1. **Application Studio** -> New application -> enter `DCMS`, owner, allowed scopes, process template and business display settings -> Save draft.
2. **Capability Catalog** -> inspect `Data.StageBatch@ver`, `Data.GetBatchPage@ver`, `CyberArk.GetAccount@ver`, `CyberArk.AddOrUpdateAccount@ver`, `Reporting.ComposeBatchReport@ver`, `Email.SendApprovedNotification@ver` -> check availability and permission.
3. **Workflow Library** -> Create Draft from `Batch + Sequential Rows` template -> name `DCMS.Batch` -> select Central BOB.
4. **BOB Designer** -> configure start trigger (CSV upload), stage task, embedded CyberArk subworkflow task (Kafka dispatch), await correlated result, report task, email task, end event; link connections; save.
5. **Embedded subworkflow** -> sequential multi-instance over data-owned page iterator; GetAccount -> AMIE.Validate -> exclusive gateway; Map -> ApplyPatch -> AddOrUpdate -> RecordRowOutcome. Continue on configured row failure after recording outcome.
6. **AMIE Rules** -> bind rule descriptors to typed facts. Map each source CSV column to target platform custom attribute; configure missing-value policy and NoChange decision; execute fixture preview.
7. **Triggers & Forms** -> choose Manual CSV; generate required data input schema and file metadata; future API/AutoSys trigger marked planned/not active.
8. **Kafka Contracts** -> view logical command/outcome types, required correlation, partition policy; no freeform topic editing.
9. **Environment Bindings** -> choose `DEV` approved CyberArk endpoint ref, staging API, broker logical topic and test recipients; verify dependencies, no credential values.
10. **Validate Draft** -> backend BPMN/compiler/schema/rule/operation/host/permission checks; fix errors on node inspector.
11. **API Regression** -> test 5-row success+failure fixture, duplicate command, missing account, declined rule, uncertain write, row checkpoint, email failure and role denial.
12. **Workflow Library** -> Submit Review -> independent approve -> Publish immutable version. **Release Center** -> UAT exact digest, then production only after real bank approvals and Operations activation.
13. **Business Work Queue** -> upload CSV (authorized user) -> start batch; see counts and record reasons. **Run Monitor** for authorized staff -> diagram overlay, correlation, activity detail. **Audit** -> reconstruct run and report evidence.

## 5. Runtime logical sequence

```mermaid
flowchart TD
  U[Authorized CSV upload] --> S[Data validates and stages batch/row GUID]
  S --> CB[Central BOB starts pinned DCMS.Batch]
  CB --> OUT[Persist command/outbox; Kafka dispatch]
  OUT --> EB[CyberArk Embedded BOB receives batchRef]
  EB --> PAGE[Data-owned paginated row fetch]
  PAGE --> ROW[Sequential row iteration]
  ROW --> GET[CyberArk.GetAccount]
  GET --> RULE[Existing AMIE Validate / Map / ShouldUpdate]
  RULE --> DEC{Eligible and change?}
  DEC -->|Yes| PATCH[Apply allowed changes in memory]
  PATCH --> WRITE[CyberArk AddOrUpdate]
  DEC -->|No| RESULT[Persist skipped/nochange/rejected reason]
  WRITE --> RESULT
  RESULT --> NEXT{More rows?}
  NEXT -->|Yes| ROW
  NEXT -->|No| DONE[Publish correlated batch outcome]
  DONE --> REPORT[Reporting composes artifact]
  REPORT --> EMAIL[Email Capability sends approved report]
  EMAIL --> END[Central BOB records terminal business status]
```

## 6. Exact example fixture

- CSV source: 5 rows `accountRef,platformKey,application,costCenter,owner,businessUnit` (illustrative column names).
- Batch: `BATCH-DCMS-0001` with five row GUIDs generated at staging.
- Expected: row 1 updated; row 2 no change; row 3 rejected missing account; row 4 skipped by AMIE rule; row 5 external call timed out after request, marked UnknownExternalOutcome pending reconciliation.
- Per-row invariants: batchId stable, unique rowGuid, one active claim per row, no second write for duplicate command without reconcile, reason code persisted, audit has rule/operation/package versions.
- Aggregate counts **must reconcile** to all rows. `Total = Succeeded + NoChange + Rejected + Skipped + Failed + UnknownOutcome + InProgress + Pending`; terminal count should exclude unknown states until resolution policy says otherwise.
- Report contains status and human-readable reason per row, not raw credentials. Email status is separate from CyberArk update outcome.

## 7. Recovery and release proof

- Crash after row two: after restart rows 1 and 2 are not blindly processed again; row three is resumed or claimed safely.
- Broker delivers `ExecuteEmbeddedWorkflow` twice: inbox prevents duplicate batch side effects.
- Timeout after CyberArk write: query/reconcile external state before retry; do not assume failure.
- Pause mid-row: complete or reconcile current external write, then pause at checkpoint; show PauseRequested until actually paused.
- Replace AMIE version in DEV: new draft package required; existing batch remains pinned.
- Trigger source changes later from CSV to approved API: input adapter changes, downstream staged-row contract and BOB/AMIE composition remain stable.

## 8. Demonstration success criteria

Present in BE: source/upload -> batch + row GUIDs -> configured BPMN with registered operations -> AMIE mapping/eligibility -> one real/approved nonprod CyberArk update or clearly marked stub -> final persisted row reasons -> report/email outcome -> live business dashboard -> technical run overlay -> audit reconstruction. Also demonstrate a second workflow (Hygiene) reusing at least one capability operation without source edits; if second pilot not complete, mark it pending, not demonstrated.

<!-- END SOURCE 069: docs/sdk/06-DCMS-EXAMPLE-END-TO-END.md -->

---

<!-- BEGIN SOURCE 070: docs/sdk/07-DEVIN-SERVICE-CONSTRUCTION-RECIPE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 07 - DEVIN New Capability Service Construction Recipe

## A. Inputs DEVIN must obtain

- Existing Unity repository, root `AGENTS.md`, current solution, approved .NET target and CI templates.
- Service name, domain owner, purpose, source data owner, external API/contracts and approved dev/test tenant.
- List of primitives required; do not guess operations from a workflow screenshot.
- Existing AMIE interfaces and BOB embedded hosting types; current Kafka contract/envelope/ACL conventions.
- Required permissions, data classification, timeout, side effects, reconciliation policy and bank controls.

If any key input is absent, report a gap with evidence and propose the smallest safe stub for testing; do not silently invent a production implementation.

## B. Build steps

1. **Inspect first:** Find existing capability framework, handlers, SDK conventions, AMIE runtime. Record reuse vs changes in `JOB-00` audit.
2. **Agree contracts:** Define operation descriptor, DTO/schema, auth policy, messaging, AMIE facts and expected outcomes. Freeze with JSON fixtures and tests before concurrent PRs.
3. **Create service template:** approved .NET service project with health, DI, logging, controlled configuration. Do not add unapproved libraries.
4. **Write domain adapter:** smallest typed client with cancellation, timeouts, exception normalization and test fake. No generic arbitrary HTTP/SQL executor.
5. **Write handler:** implements SDK interface; input/output strongly typed, stable key/version and declared side effect; return structured outcome.
6. **Register:** use trusted assembly registration/compile-generated registry. Startup rejects duplicate keys and malformed metadata. Add test for missing handler registration.
7. **AMIE bridge:** declare needed facts and output schemas, resolve approved published rule via existing AMIE engine; support local evaluation in embedded host.
8. **BOB bridge:** expose handler to local dispatcher and (if needed) remote Kafka execution using same manifest. Confirm exact version pinning.
9. **Broker integration:** subscribe only to allowed logical inbound messages, verify schema/auth/inbox, publish outcome via outbox; derive partition key and correlation fields.
10. **Audit:** emit safe events for request, rule, handler execution and outcome. Audit should reassemble an operation by run/activity IDs.
11. **Public contract:** generate metadata + fixture + OpenAPI test endpoints; backend must be testable without UI.
12. **BE integration:** verify registry lists operation, inspector renders inputs automatically, binding picker type-checks and can insert into BPMN draft.
13. **Regression:** unit, API, schema, denied, duplicate, timeout/crash, redaction, version mismatch and second-workflow reuse.
14. **Submit PR:** source paths, build/test evidence, before/after, restrictions, approval gaps, file summary. No direct PROD deployment.

## C. Reusable PR checklist

- [ ] API contract and `operationKey@contractVersion` stable.
- [ ] Service/class names follow current repository conventions.
- [ ] Local registration tests green, no duplicate/undeclared handler.
- [ ] Manifest published only by approved deployment identity.
- [ ] `InputSchema`/`OutputSchema` and fixtures match compiled DTOs.
- [ ] Auth checked at API **and** worker invocation.
- [ ] AMIE rule metadata typed, rule version pinned; no duplicate AMIE parser.
- [ ] Kafka command/outcome contracts versioned, correlation/idempotency included.
- [ ] In-memory local workflow uses shared BOB core and DI.
- [ ] External write reconciliation specified; retries cannot cause duplicate mutations.
- [ ] Evidence append-only with no secrets/raw sensitive payload.
- [ ] BE inspector configures operation from descriptor, not hardcoded page.
- [ ] OpenAPI regression includes denied/invalid paths.
- [ ] At least two workflow fixtures reuse the same handler.
- [ ] Reviewer receives actual file summary and outstanding CA/approval gaps.

## D. What a handoff from BE should give DEVIN for a missing operation

The designer should export an **Operation Development Request** containing: capability owner, proposed operation key/version, business intent, preconditions, input/output JSON Schema, example fixtures, permissions/resource scope, side effects, mandatory AMIE facts, expected error/outcome codes, external client dependency, timeout, retry/reconcile policy, logical Kafka contracts, audit category, acceptance tests, requested environment and code-review/change ticket references. This is a specification, not automatically executable code.

## E. Correct file path format in PRs

`/Unity.Capability.CyberArk/Operations/GetAccountHandler.cs`
`/Unity.Capabilities.Contracts/OperationDescriptor.cs`
`/Unity.Capabilities.Hosting/Registration/CapabilityRegistrationExtensions.cs`
`/Unity.Capability.CyberArk.Tests/GetAccountHandlerTests.cs`

Follow real repository paths after discovery; above paths are illustrative.

## F. Files and Structure Summary (required in PR response)

New: list paths; Updated: list paths; Deleted: list paths; No Change: related untouched modules; Tests: commands+results; Known gaps: approval/control/library/repo uncertainties.

<!-- END SOURCE 070: docs/sdk/07-DEVIN-SERVICE-CONSTRUCTION-RECIPE.md -->

---

<!-- BEGIN SOURCE 071: docs/sdk/08-SDK-API-REGRESSION-SUITE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK 08 - Required API / Contract / Runtime Regression

All BE interactions must have server APIs. Test semantics through API/worker even when a UI screen is not yet built. The routes below are proposed families; align with actual API surfaces from repository inspection.

| ID | Test request / setup | Expected behavior / rejection | Owner |
|---|---|---|---|
| SDK-01 | Start service with two handlers same key/version | Startup fails diagnostic, no ambiguous registration | SDK |
| SDK-02 | Valid compiled handler + manifest fixture | Deterministic schema and registry descriptor | SDK |
| SDK-03 | Manifest submitted by untrusted caller | 403 / no registry state change, audit denial | Registry |
| SDK-04 | Manifest has invalid schema or missing permission | 422 structured field errors | Registry |
| SDK-05 | Registry `Registered` but service incompatible/unhealthy | BE sees unavailable; BOB denies execution | Registry |
| SDK-06 | GET operations as scoped user | Only permitted descriptors/details returned | API/RBAC |
| SDK-07 | GET operation input schema | Required fields/types and classification match DTO | SDK/BE |
| SDK-08 | Bind string to complex object input | Compiler returns BIND_TYPE_MISMATCH and BPMN element ID | BOB |
| SDK-09 | AMIE rule missing required fact | Compiler error; no publish | AMIE bridge |
| SDK-10 | AMIE evaluates valid fixture in embedded host | Typed output and pinned rule version | AMIE bridge |
| SDK-11 | Local handler via BOB | No central per-step HTTP roundtrip | Embedded host |
| SDK-12 | Kafka remote handler invocation | Correlated persisted command/outcome, token resumes once | Kafka/BOB |
| SDK-13 | Duplicate Kafka command | No duplicate write; stable outcome | Capability worker |
| SDK-14 | Timeout after external write sent | UnknownExternalOutcome; reconciliation gate | CyberArk worker |
| SDK-15 | Worker restart after two DCMS rows | Resume remaining rows; no duplicate outcomes | Embedded host |
| SDK-16 | Paused mid-CyberArk write | PauseRequested, safe checkpoint, no false rollback | BOB/operator |
| SDK-17 | Wrong role invokes operator API | 403, state unchanged, denial event | Security |
| SDK-18 | Different user reads batch outside scope | 403/404, no sensitive metadata | BE API |
| SDK-19 | Published workflow edited in place | Reject conflict; copy to new draft required | Definition API |
| SDK-20 | Approved UAT package changed before PROD | Digest mismatch blocks activation | Release |
| SDK-21 | Typed ServiceNow ticket but no approval evidence | PROD preflight blocked | Release |
| SDK-22 | DCMS five-row fixture | Correct per-row and aggregate statuses, reasons and report | DCMS |
| SDK-23 | Email fails after account processing | Account outcomes preserved; email separate | Email |
| SDK-24 | Reuse same GetAccount operation in Hygiene and DCMS | No BOB core or CyberArk handler code change | Integration |
| SDK-25 | Simulate broker reconnect during monitor | Business projection refreshes from API, no ghost state | BE |
| SDK-26 | Audit export with restricted account details | Redacted, scope-limited, export event logged | Audit |
| SDK-27 | Unsupported BPMN element | Validation/publish error, not silent skip | BOB |
| SDK-28 | Disallowed physical Kafka topic from UI | Reject; only approved logical bindings | SDK/Security |

## Response conventions

- 200/201 success with correlation, revision and stable schema.
- 202 accepted async run/control request; do not misrepresent as completed.
- 400 syntax, 401 unauthenticated, 403 unauthorized, 404 scoped invisible, 409 revision/dependency conflict, 422 semantic/schema errors, 503 unavailable dependency. Exact codes must be finalized with existing API conventions.
- Negative tests assert no side effects and audit denial. Positive tests assert actual state, not merely HTTP status.
- Regression results must record test identity, time, environment, package/manifest digest and evidence URI. Fixtures cannot contain real passwords or live account identifiers.

## CI lanes

- PR: build, static security checks, SDK registration and schema fixtures, BOB parser/compiler semantics, AMIE adapter unit tests, API authorization, deterministic UI interaction tests.
- DEV integration: Kafka consumer/outbox/inbox, MSSQL database migrations/checkpoint/audit, fake CyberArk external client, crash/restart and duplicate tests, BE UI+API E2E.
- UAT: exact approved package digest, compatible service versions, controlled test tenant, bank-required CA evidence and smoke test.

Do not label tests as passing without execution evidence in the actual repository pipeline.

<!-- END SOURCE 071: docs/sdk/08-SDK-API-REGRESSION-SUITE.md -->

---

<!-- BEGIN SOURCE 072: docs/sdk/LEGACY-CONSOLIDATED-SDK-v1.0.md -->

> **v2.1 SDK reconciliation note:** Retained technical detail only; current SDK/registry security, ownership, approval and maturity rules in `docs/architecture/02-CAPABILITY-SDK-REGISTRY.md` and current contracts take priority. Verify real SDK class names in repository.

# Unity Capability SDK - Consolidated Specification v1.0

This is a readable combined reference of the nine modular SDK files. If sections conflict, the modular source and actual Unity code review take precedence.

## Table of contents

1. [00-SDK-PURPOSE-SERVICE-BOUNDARIES](#sdk-section-1)
2. [01-SDK-CONTRACTS-AND-STATES](#sdk-section-2)
3. [02-AUTOMATIC-REGISTRATION-AND-NEW-SERVICE](#sdk-section-3)
4. [03-BOB-AMIE-KAFKA-EXECUTION](#sdk-section-4)
5. [04-DATA-SCHEMAS-AND-UI-BINDINGS](#sdk-section-5)
6. [05-SECURITY-AUDIT-PROMOTION](#sdk-section-6)
7. [06-DCMS-EXAMPLE-END-TO-END](#sdk-section-7)
8. [07-DEVIN-SERVICE-CONSTRUCTION-RECIPE](#sdk-section-8)
9. [08-SDK-API-REGRESSION-SUITE](#sdk-section-9)

---


<a id="sdk-section-1"></a>

# SDK 00 - Why a Unity Capability Service Exists

Status: DESIGN PROPOSAL built on user-established Unity architecture. Before coding, DEVIN MUST inspect the actual repo in JOB-00. Do not interpret proposed namespaces as implemented APIs.

## 1. Purpose and non-goals

A capability service is an independently deployed .NET service exposing approved, reusable business-system primitives through versioned typed contracts. It performs operations that require privileged access, domain validation, network or SDK interaction, or domain data ownership. It **does not own an application's end-to-end business workflow**.

Examples:
- CyberArk: GetAccount, FindAccount, ReadPlatform, ApplyAllowedAttributePatch, AddOrUpdateAccount, MoveAccount (only if separately implemented and authorized).
- Data/ingestion: ValidateCsv, StageBatch, GetPage, RecordRowOutcome, ReadBatchSummary. The owner owns business staging data, not BOB's workflow state.
- Email: SendApprovedNotification using template and recipient policies; the email transport is not inside BOB.
- Reporting: ComposeBatchReport, return access-controlled artifact reference; not automatically send email.
- Identity: ResolveUser/Group within approved scope; not a generic privileged directory browser.
- Legacy: Typed facade over a reviewed API; not arbitrary service method invocation.

Do not put DCMS-specific branches in CyberArk handlers, author AMIE rules in source code just for DCMS, create unrestricted SQL/HTTP operation handlers, or let BE submit arbitrary CLR assembly names or Kafka topics.

## 2. Platform responsibility matrix

| Concern | Source of truth | How consumers access it | Prohibited coupling |
|---|---|---|---|
| Workflow definition / version | BOB/Unity configuration package | BE designer + workflow API | Capability inventing its own private workflow format |
| Token execution / checkpoints | BOB shared interpreter | Embedded/central BOB host | Different semantics per host |
| Business decision/mapping | Existing AMIE runtime / published rule package | Typed AMIE adapter | BOB duplicating rule grammar |
| Compiled primitive/permissions | Capability release + manifest | Registry/dispatcher/worker | BE invoking arbitrary C# type |
| Event transport | Kafka with approved logical contracts | Shared SDK outbox/inbox | Browser talking to Kafka directly |
| Operational current state | Workload data owner and BOB projection | Authorized APIs/BE view | All capabilities reading one shared DB |
| Immutable audit history | Append-only MSSQL event store | Scope-filtered audit API | Audit derived only from ephemeral logs |
| Visualization, authorization UX | BE (Blazor) | API-first UI | Hiding buttons as sole security control |
| Release and approvals | Operations/change-control process | Release API + immutable package | Developer direct PROD access |

MSSQL is the sole **BOB persistence** target for MVP; capability-owned business data may use its approved datastore or API. No cross-service direct table access is implied.

## 3. Minimum contracts every service must supply

1. **Service identity**: capability key, code release/version, service owner, deploy identity and health.
2. **Operation descriptors**: stable `capability.operation@major.minor` identity, request and result schema, classification, required permission/scope, side effect, retry/reconcile mode, supported execution hosts, timeout, fixture identifiers.
3. **Message descriptors**: logical inbound command/outbound outcome identities, schema, partition key, idempotency key construction, consumer group and permitted environment bindings. Kafka physical topic names and credentials are never authored in workflow tasks.
4. **AMIE binding descriptors**: each rule's expected facts and typed decision/output; operation descriptions cannot guarantee a rule is installed.
5. **Invocation boundary**: authenticated `OperationInvocation` with process/activity IDs, pinned package digest, actor/service identity references, correlation/causation IDs and idempotency key.
6. **Execution outcome**: `Succeeded`, `NoChange`, `Rejected`, `Failed`, `UnknownExternalOutcome`, with safe reason code and trace reference. Distinguish operation disposition from business row status.
7. **Audit**: structured evidence for invocation, authorization, decision, dispatch, attempt, external action, completion/reconciliation, without raw credentials or sensitive account objects.
8. **Diagnostics**: health/registry status, effective operation version, schema/contract mismatch errors, safe test fixtures; no health signal alone authorizes invocation.

## 4. Two registration events - must not be confused

- **Local registration** on trusted service startup: approved compiled operation handlers are discovered/explicitly registered in DI, validated, and made callable by the local dispatcher.
- **Enterprise publication** on approved deployment: trusted service identity submits a signed or attested manifest to registry; registry checks owner, environment compatibility, release approval, schema and permissions; only then may BE discover executable operations for its assigned scope.

An operation is useable only when the published manifest is compatible, the running service is healthy, environment bindings are configured, required auth is satisfied, and the operation is explicitly allowed for the application and workflow package.

## 5. Three execution shapes

1. **Local**: Embedded BOB invokes handler via DI, AMIE through existing local adapter. Avoid per-step central roundtrips.
2. **Remote command**: Central BOB persists an outstanding activity/command + outbox; broker delivers command to owning capability; worker validates and executes; correlated outcome resumes central BOB once.
3. **Capability subworkflow**: One approved message invokes a pinned embedded subworkflow (e.g. process staged batch rows sequentially). Worker performs several local handler/AMIE steps and emits aggregate/progress events; central host does not schedule every row's local steps.

## 6. Definition of reusable success

A safe operation registered once can appear in the BE catalog, bind to a published BPMN service task and AMIE rule, execute in its authorized host, produce consistent run/audit evidence and then be reused in a **second unrelated workflow without a new handler or BOB Core change**.

## 7. Immediate acceptance proof / no fake completion

DEVIN must show: actual handler class in repo, DI registration, manifest metadata and API response, registry approval state, BE operation inspector with typed inputs, a runnable approved BPMN path, existing AMIE runtime invocation, an outcome and audit event, a negative direct-API permission test, and replay/restart tests. Demo fixtures do not prove a real CyberArk integration.

---


<a id="sdk-section-2"></a>

# SDK 01 - Canonical Contracts, Identity, and State Machines

Status: PROPOSED until reconciled to existing repo. Dependencies: `docs/contracts/OPERATION-CONTRACT.md`, `docs/contracts/MESSAGING-CONTRACT.md`, `docs/architecture/04-AMIE-BINDINGS.md`.

## 1. Contract boundaries and proposed assembly paths

- `/Unity.Capabilities.Contracts/CapabilityManifest.cs`: metadata only; no executable classes in serialized payload.
- `/Unity.Capabilities.Contracts/OperationDescriptor.cs`: operation key/version, schema, permission, side effect, auth scope, retry/reconciliation, transport, AMIE requirements, examples.
- `/Unity.Capabilities.Contracts/OperationInvocation.cs`: request DTO + authenticated execution context.
- `/Unity.Capabilities.Contracts/OperationOutcome.cs`: typed disposition, safe reason, result and external reconciliation reference.
- `/Unity.Capabilities.Hosting/IUnityOperationHandler.cs`: compile-time typed operation interface.
- `/Unity.Capabilities.Hosting/OperationDispatcher.cs`: verified allowlist routing to DI handler; no client-provided CLR name resolution.
- `/Unity.Capabilities.Registry/ManifestPublisher.cs`: deployment/privileged registry action, NOT triggered merely by runtime scanning.
- `/Unity.Capabilities.Kafka/CommandConsumer.cs`: schema/auth/inbox/dispatch, outcome and outbox.
- `/Unity.Capabilities.BOB/EmbeddedWorkflowAdapter.cs`: bridge to shared interpreter.
- `/Unity.Capabilities.AMIE/AmieRuleAdapter.cs`: thin adapter to current existing rule engine.

Choose final project names only after JOB-00 inventory. Namespace conventions must follow existing services.

## 2. Proposed C# interface sketches

```csharp
public interface IUnityOperationHandler<TRequest, TResponse>
{
    Task<OperationOutcome<TResponse>> ExecuteAsync(
        TRequest input, UnityExecutionContext context,
        CancellationToken cancellationToken);
}

public sealed record UnityExecutionContext(
    string ApplicationKey, string DefinitionKey, string DefinitionVersion,
    Guid RunId, string ActivityId, string CorrelationId, string CausationId,
    string ActorContextRef, string PackageDigest, string IdempotencyKey,
    string? BatchId, Guid? RecordGuid, string? TraceParent);

public enum OperationDisposition
{
    Succeeded, NoChange, Rejected, Failed, UnknownExternalOutcome
}

public sealed record OperationOutcome<T>(
    OperationDisposition Disposition, string ReasonCode, string SafeReason,
    T? Result, string? ExternalOperationRef, string? ResultHash);
```

These are examples for contract alignment, NOT source already available. An input DTO contains business data; the execution context contains provenance and auth references. Data types must be serializable and compatible with existing library conventions.

## 3. Required OperationDescriptor fields

| Group | Required property | Validation |
|---|---|---|
| Identity | capabilityKey, operationKey, contractVersion | Unique key + compatible version; names cannot shadow another capability |
| Service | codeVersion, owner, manifestDigest | Code/manifest release must agree |
| Data | input/output JSON Schema, required fields, classification, fixture IDs | Validate examples and required fields; never generate schema from untrusted runtime input |
| Authentication | policy name, permitted resource scopes, service audience | Fail closed at registry and worker; no trust from UI alone |
| Side effects | Read / LocalTransform / ExternalWrite / HighImpactExternalWrite | Write has idempotency/reconciliation and control references |
| Execution | EmbeddedLocal / KafkaCommand, timeout and cancellation | At least one supported mode; no unapproved direct route |
| AMIE | required rule/data descriptor versions | Rule must resolve, pin and type-check before publish |
| Messaging | inbound/outbound logical types, partition/correlation/idempotency strategy | Broker binding checked per environment |
| Evidence | audit code, redaction profile, safe test fixture | No secrets or raw sensitive account payload in audit |

## 4. Lifecycle / state transitions

### Operation manifest

`CodeWritten -> BuiltAndTested -> ServiceApproved -> Deployed -> ManifestSubmitted -> Registered -> Available -> Deprecated -> Retired`.

- `Registered` is metadata-only. `Available` also requires healthy compatible service, environment ACL/policy and permitted application scope.
- Code release and configuration release are separate. A workflow can only invoke an operation available in its deployment environment and compatible with its pinned contract.
- Removing an operation from available list does NOT delete historical manifest metadata used for audit.

### Workflow definition

`Draft -> InReview -> Approved -> Published -> Active -> Retired`.

- Editing Published or Active creates a new Draft/version; all existing runs stay pinned.
- Publication requires BPMN subset/compiler validation, typed bindings, rule and operation compatibility, approved roles and change evidence.
- `Approved` is not `Active`; Operations owns activation according to real bank controls.

### Process run

`Created -> Running -> PauseRequested -> Paused -> Running`, plus `CancelRequested -> Cancelled`, `Completed`, `Failed`, and `AwaitingOutcome`/`ReconciliationRequired` substates as needed.

- Pause is cooperative at safe checkpoint; active CyberArk HTTP call cannot be magically stopped/undone.
- Cancel is cooperative; terminal `Cancelled` only when known work has settled or is explicitly marked unresolved.
- RetryFailedStep is permitted only where the dispatcher can establish prior outcome or safely reconcile it.
- RestartAsNewRun creates a fresh RunId and linkage to previous RunId; never erases original audit history.

## 5. Contract version pinning and backwards compatibility

- Workflow package pins explicit `operationKey@contractVersion`, AMIE `ruleKey@version`, called-subworkflow version, source schemas and package digest.
- Additive optional DTO fields may be compatible only after contract tests; removing required inputs or changing side-effect semantics is a breaking version.
- At runtime, no implicit fallback to `latest`. If pinned dependency is absent, fail start or enter `BlockedByDependency` with audit.
- Service code versions are tracked separately from operation contract versions; a new service deployment may preserve the contract only if compatibility tests pass.

## 6. API contracts (all future routes proposed)

- `GET /api/v1/capabilities`, `GET /api/v1/capabilities/{key}/operations`, `GET /api/v1/operations/{key}/versions/{version}`.
- `POST /api/v1/manifests/validate`, `POST /api/v1/manifests/submit`, `POST /api/v1/manifests/{id}/approve`, `GET /api/v1/manifests/{id}/readiness`.
- `POST /api/v1/operation-tests/{key}/execute` (non-PROD approved fixture only, separate test permission).
- `POST /api/v1/workflow-drafts/{id}/validate`, `POST /api/v1/workflows/{key}/runs` and authorized lifecycle endpoints.

Every endpoint must be OpenAPI-described and tested directly without a browser, including denied and invalid requests. Never let a generic test endpoint execute arbitrary operations or reach PROD.

---


<a id="sdk-section-3"></a>

# SDK 02 - Automatic Registration, Service Bootstrap and Registry Publication

Status: implementation design; current AMIE/capability conventions are unknown until source audit.

## 1. Creating a service (dev workflow)

1. Select the domain owner and service archetype: CyberArk/PAM, Data, Email, Reporting, Identity or Legacy. Determine data owner, environment policies, and broker requirements.
2. Create the service from an approved .NET service template; reference shared Unity.Contracts and Unity.Hosting packages already reviewed by Wells Fargo.
3. Implement typed handlers. Write handler metadata (`UnityOperation` attribute or equivalent compile-time registration) and DTOs; no dynamic code execution. Handler must be DI-constructible and in an allowlisted compiled assembly.
4. Classify each operation: read, local transform, external write or high-impact external write; define permission, timeouts, idempotency and result reconciliation.
5. Implement adapter clients and secret refs through approved DI; do not put credentials in handlers/manifests.
6. Add AMIE rule descriptors only as **references/typed bindings**. Existing AMIE compiler/evaluator remains authoritative.
7. Declare logical command/outcome contracts; environment settings map logical keys to authorized Kafka topics/consumer groups.
8. Register handlers in startup; on failure in production registration fail fast with deterministic diagnostic (duplicate key, invalid schema, missing policy, wrong major version).
9. Generate manifest + JSON Schema + examples + OpenAPI metadata as build outputs; verify against approved fixtures.
10. Run CI tests, create/approve ordinary service-code release, deploy via approved pipeline, submit manifest via privileged service identity.
11. Registry checks signature/provenance, service release, owner, compatibility, policies, and environmental readiness; BE discovers only the properly scoped descriptors.
12. Reuse the operation from an authorized workflow; observe correlated audit and repeat in a second workflow without code changes.

## 2. Example registration (illustrative, not verified repo API)

`/Unity.Capability.CyberArk/Program.cs`

```csharp
builder.Services
  .AddUnityCapabilityHost(o => o.CapabilityKey = "CyberArk")
  .RegisterApprovedOperations(typeof(GetAccountHandler).Assembly)
  .UseExistingAmieAdapter()
  .UseEmbeddedBob()
  .UseKafkaContracts()
  .UseStructuredAudit();
```

The implementation must scan **only** assemblies allowed by the deployed service configuration or use compile-time generator registration. Do not accept assembly names or method names from the network or manifest consumers.

`/Unity.Capability.CyberArk/Operations/GetAccountHandler.cs`

```csharp
[UnityOperation("CyberArk.GetAccount", "1.0",
   Policy = "PAM.Account.Read", SideEffect = "Read")]
public sealed class GetAccountHandler
    : IUnityOperationHandler<GetAccountRequest, GetAccountResponse>
{
    private readonly ICyberArkClient _client;
    public GetAccountHandler(ICyberArkClient client) => _client = client;

    public async Task<OperationOutcome<GetAccountResponse>> ExecuteAsync(
        GetAccountRequest request, UnityExecutionContext context,
        CancellationToken ct)
    {
        // Actual adapter, error mapping and authorization must be implemented
        // against the existing service. No mock production client.
        var account = await _client.GetAccountAsync(request.AccountRef, ct);
        return new(OperationDisposition.Succeeded, "ACCOUNT_FOUND",
                   "Account read succeeded", new(account), null, null);
    }
}
```

Example intentionally omits credentials and concrete SDK/library details. Real code must use existing policy, cancellation, retry and audit interceptors.

## 3. Startup validation algorithm

1. Discover allowed handler type and declaration.
2. Verify exactly one expected typed interface and DI registration.
3. Verify unique operation key/version and permitted compatibility major.
4. Validate input/output JSON schemas against DTOs, fixtures and declared classification.
5. Ensure required permission/scope and side-effect policy are supplied.
6. For writes, require idempotency behavior and `UnknownExternalOutcome` reconciliation strategy.
7. Check message contract names, required fields, correlation and partition key.
8. Validate AMIE descriptor references are resolvable for declared runtime where needed.
9. Construct immutable manifest with deterministic digest; emit startup diagnostic state.
10. Expose metadata to authenticated deployment/registry agent, but DO NOT self-approve.

## 4. Manifest publication lifecycle

Build CI produces manifest artifact and approved service release -> release pipeline deploys binary -> signed deployment identity submits manifest -> Registry validates owner, signature, compatible handler/codeVersion, exact schema, environment ACL -> Registry marks `Registered` -> operational readiness checks mark `Available` -> BE discovery is scope filtered -> BOB can bind only `Available` approved operations. Republish or revoke under control; no arbitrary end-user registration from BE.

## 5. New primitive vs configuration decision

Ask in order:

- Is there an approved operation that already produces the required output? Reuse it.
- Can a combination of existing operations, BOB control flow and AMIE mapping produce the result without bypassing security? Configure it.
- Is a new domain primitive required (e.g. verified safe movement)? Implement once in owning capability with a reviewed code release, schema, policy and tests.
- Is the proposed primitive unbounded (generic REST executor, arbitrary SQL, direct C# eval)? Reject and replace with typed approved operation.

## 6. DEVIN coding boundaries

- Preserve existing DI host style, .NET version, project names and namespace conventions.
- Do not generate a new central AMIE runtime or duplicated BOB interpreter.
- Do not hardcode physical topic names or endpoints into descriptors.
- Do not include DCMS as a capability kind. DCMS is an application/workload config.
- Publish PR with actual `/Project/Folder/File.cs` paths and New/Updated/Deleted/No Change summary.
- Add unit/contract tests and a demo showing operation discoverable in BE and reject unauthorized direct call.

---


<a id="sdk-section-4"></a>

# SDK 03 - BOB, AMIE, Capability and Kafka Interaction Protocol

This is the interaction contract DEVIN must implement or map to existing code. It is a **proposed architecture**, not a verified current runtime.

## 1. Central versus embedded host boundary

```mermaid
sequenceDiagram
  participant BE as BE API / Designer
  participant CB as Central BOB
  participant SQL as MSSQL state and outbox
  participant K as Kafka
  participant CH as Capability Host / Embedded BOB
  participant AM as Existing AMIE
  participant H as Approved handler
  participant AU as Audit
  BE->>CB: Start approved workflow package
  CB->>SQL: Persist run + waiting command + outbox atomically
  SQL-->>K: Outbox dispatcher emits authorized command
  K-->>CH: Deliver command (may be repeated)
  CH->>CH: Verify auth, digest, inbox key, compatibility
  CH->>AM: Evaluate pinned rule locally
  AM-->>CH: Typed decision + reason
  CH->>H: Execute handler using typed mapped input
  H-->>CH: Outcome incl external reference
  CH->>AU: Append safe operation/decision evidence
  CH->>K: Publish correlated outcome via outbox
  K-->>CB: Deliver outcome (may be repeated)
  CB->>SQL: Compare-and-swap complete waiting activity
  CB-->>BE: Status projection / secured near-real-time hint
```

Embedded BOB uses the **same** BPMN parser/compiler/interpreter as central BOB; its host adapter selects local DI, AMIE, and storage/transport. Central BOB may wait durably in MSSQL. Do not implement an application-specific local workflow engine inside the CyberArk adapter.

## 2. Compilation of a workflow designed in BE

1. Load BPMN 2.0 XML + BPMN DI geometry; reject malformed XML, unsupported semantic elements, unreachable branches, missing IDs and ambiguous joins.
2. Parse vendor-neutral service tasks / business rule tasks; read Unity extension bindings (operationKey@version, ruleKey@version, input/output mapping, host, retry policy).
3. Resolve approved Capability Registry manifest and AMIE rule descriptor, including ownership, availability, schemas, permission and side effect.
4. Type-check every source (trigger field, item field, prior task output, rule output, constant, environment ref, secret ref) against required input. Null/default/classification policy must be explicit.
5. Resolve child/call activity and sequential multi-instance semantics. Pin exact dependency versions and output a deterministic package lock/digest.
6. Check configured execution host can access the requested local handler and AMIE rule; otherwise require remote command mode. Reject silent transport fallback.
7. Enforce allowable concurrency, timeouts, cancellation and retry/reconciliation behavior; no unsafe automatic retry for CyberArk external writes.
8. Emit prepublish validation results by BPMN element ID, field path, severity, code, description and suggested action. Only error-free approved definitions can publish.

## 3. On executing a local task

1. Shared BOB evaluates task input binding in a typed workflow context.
2. Before a privileged handler, authorize service identity and the signed actor context/scope at dispatch; BOB's previous validation alone is not sufficient.
3. Dispatcher resolves an allowlisted `operationKey@contractVersion` to a DI handler. It never reflects untrusted CLR method names.
4. Invoke with `UnityExecutionContext`, cancellation token, per-operation timeout and safe telemetry scope.
5. Validate output schema, redact classified data, persist outcome/audit and advance token exactly once.
6. For local AMIE business-rule task, call existing AMIE API, not a new rule interpreter; obtain typed decision and safe reason. Version pin is mandatory.

## 4. On remote task through Kafka

Before publish, persist *both* pending command state and outbox record in one BOB-owned transaction. Kafka producer publishes pending outbox. The capability consumer validates schema, broker principal, caller audience, policy, idempotency key and package version, then checks inbox. For duplicates, replay prior stable outcome or reject safely. Execute handler and persist outcome in same capability-controlled transaction when possible; external CyberArk writes are not part of that transaction and require reconciliation.

The outcome envelope includes command ID, causation/correlation ID, run ID, activity ID, operation key/version, status, reason code and safe result reference. The BOB outcome consumer updates its waiting activity only once by optimistic concurrency. Out-of-order and late messages are recorded; they do not advance the wrong run.

## 5. Failures and reconciliation

| Failure | Required behavior | Forbidden behavior |
|---|---|---|
| Invalid input schema | Reject before dispatch, audit safe error | Invoke handler with half-built DTO |
| AMIE rule false | Follow configured BPMN branch, record rule reason | Treat false as CyberArk write failure |
| Handler returns NoChange | Persist business NoChange and continue | Report update success without a write |
| CyberArk returns clear failure | Record Failed with safe reason/retry policy | Infinite unbounded retry |
| Network timeout after write request | `UnknownExternalOutcome`; reconcile with external reference/state | Blindly retry a possibly successful write |
| Kafka message duplicate | Inbox dedup, replay stable outcome | Execute same write twice |
| Kafka outcome lost | Keep durable waiting state, retry transport or query correlation | Move token to success without evidence |
| Worker crashes mid-batch | Resume at checkpoint and reconcile current row | Restart batch from row one without checking outcomes |
| Pause while write in flight | Set PauseRequested, stop new steps at safe checkpoint | Kill ongoing HTTP call and claim rollback |
| Cancel | Cooperative stop, mark unfinished work explicitly | Delete history or claim external rollback |
| Retired rule/handler after start | Keep pinned version if still available or mark dependency blocked | Replace with newest rule without review |

## 6. DCMS as application-level sequence

Central BOB: authorized manual CSV / future API start -> Data capability stage -> create batch and row GUIDs -> send `ExecuteEmbeddedWorkflow` to CyberArk capability -> wait for result -> report generation -> Email Capability -> summarize and close. Embedded BOB: get bounded page -> sequential multi-instance row loop -> CyberArk.GetAccount -> AMIE eligibility -> AMIE mapping -> CyberArk ApplyAllowedPatch in memory -> CyberArk AddOrUpdate -> row outcome persist -> next row -> aggregate completion. This is a **configured** workflow, not special code in BOB or SDK.

## 7. Evidence contract

At minimum emit `WorkflowStarted`, `TaskScheduled`, `RuleEvaluated`, `OperationRequested`, `OperationCompleted|UnknownOutcome`, `RowOutcomeRecorded`, `WorkflowPaused|Resumed|Cancelled|Completed`, `NotificationRequested`, `NotificationOutcome`, `ConfigurationPublished|Activated`, and `ControlAction` with actor, UTC, version digest, correlation, run/activity, source references and safe summary.

---


<a id="sdk-section-5"></a>

# SDK 04 - Schema-driven BE Forms and AMIE/BOB Binding

## 1. Why the descriptor is a UI contract

When capability publishes a `GetAccount@1.0` descriptor, BE should automatically render: operation title, required/optional input fields, data types, source binding controls, output variables, execution host choices, permissions/side effects, timeout/retry and test fixture. No CyberArk-specific Razor form should be required for each operation.

## 2. Unified typed binding descriptor (proposed)

```json
{
  "targetField": "accountRef",
  "sourceKind": "CurrentItem",
  "sourcePath": "item.accountRef",
  "expectedSchemaRef": "schema://cyberark/account-ref/1.0",
  "nullable": false,
  "onMissing": "ValidationError",
  "dataClassification": "Internal"
}
```

Supported source kinds for MVP: WorkflowInput, CurrentItem, PriorOperationOutput, AmieRuleOutput, ConstantAllowlisted, EnvironmentBinding, SecretReferenceServerSide. The user sees logical references only; raw secrets must never be resolved into browser fields or BPMN XML.

## 3. Binding builder behavior

1. User selects an operation in Capability Catalog and clicks Add to Workflow.
2. Designer inserts a service task with stable BPMN element ID and pinned operation key/version.
3. Inspector fetches operation descriptor from authorized API and dynamically renders input slots.
4. For each slot, user picks source kind; picker offers only in-scope upstream outputs with a compatible JSON schema/data classification.
5. A missing required field is visibly invalid. An incompatible type is invalid even if a fake preview happens to work.
6. On adding AMIE rule, inspector loads rule descriptor and offers required facts from available workflow context; resolved decisions become branch conditions.
7. User chooses permissible host (Local vs Kafka) only from operation manifest and workflow deployment constraints.
8. Save persists a Draft (ETag/optimistic concurrency), Validate calls backend BOB compiler and AMIE adapter validator, Preview runs only deterministic DEV fixtures.
9. A published package locks exact manifests/rules/BPMN/subprocess versions; designer previews do not grant production execution.

## 4. Dynamic form generation

Inputs may have `type`, `format`, `enum`, `required`, `minLength`, `maxLength`, `maximum`, `pattern`, `description`, `classification` and optional approved UI hints. Required data is derived from the schema, never from the decorative mockup. The form engine supports hidden fields only for security/data dependency, server-side validation and structured error display. It must not expose an unrestricted JavaScript expression or C# editor to end users.

## 5. Example DCMS bindings

| Task | Field | Source | Validation |
|---|---|---|---|
| StageBatch | uploadedCsvRef | trigger.uploadRef | Authorized non-secret file ref, file passed safety checks |
| GetPage | batchId | steps.stage.output.batchId | Typed batch identifier, paginated bounds |
| GetAccount | accountRef | item.accountRef | Required, correct scope |
| AMIE.AccountEligibility | row, account | item + steps.get.output.account | Pinned rule and fact schemas match |
| AMIE.AttributeMap | row, platform | item + steps.get.output.platform | Only allowed custom attributes emitted |
| ApplyAllowedPatch | account, patch | previous account + rules.map.output.patch | Platform-specific patch schema validated |
| AddOrUpdate | modifiedAccount | steps.apply.output.account | Write authorization + reconcile policy |
| RecordRowOutcome | recordGuid, result | item.guid + steps.upsert.output | Side-effect outcome distinct from rule-pass |
| ComposeBatchReport | batchId | workflow.input.batchId | Counts reconciled against terminal rows |
| RequestNotification | reportRef, recipientPolicyRef | steps.report + config | Permission and recipient allowlist |

## 6. Designer error contract

Return errors as `{code, severity, bpmnElementId, fieldPath, message, suggestedAction}`. Required examples: `BIND_REQUIRED`, `BIND_TYPE_MISMATCH`, `BIND_UNAUTHORIZED_SCOPE`, `RULE_VERSION_UNAVAILABLE`, `OPERATION_NOT_APPROVED`, `HOST_MODE_UNSUPPORTED`, `BPMN_ELEMENT_UNSUPPORTED`, `DUPLICATE_OPERATION_KEY`. BE must display them on the affected node and in a keyboard-accessible issue list. A disabled Publish button is not a substitute for backend rejection.

## 7. Example data source GUI

- Node selected: `Task_GetAccount`.
- Operation inspector: `CyberArk.GetAccount@1.0`; permission `PAM.Account.Read`.
- Required `accountRef` -> choose Current Item -> `DCMS.Row.AccountRef`.
- Output `AccountRecord` -> name `account`.
- Test contract -> sanitized fixture only (DEV); result visible with safe event IDs.
- Validate -> green only if BE/backend schema, AMIE dependencies, host and permissions agree.

## 8. Explicit design alternatives

For MVP, an auto-generated property inspector plus a controlled binding picker is more feasible than a full no-code generalized forms builder. Advanced expression editing, custom renderers, full human-task form designer and advanced BPMN elements remain backlog unless first pilot proves they are required.

---


<a id="sdk-section-6"></a>

# SDK 05 - Security, Audit, Operator Controls, and Release Promotion

## 1. Least privilege / identity

Every invocation checks backend API auth, workflow/app scope, resource scope, service identity and operation permission, **again in the capability worker**. A user may view only their own batch without permission to view the BPMN process, inspect safe audit events or operate runs. BE controls visibility but does not enforce security alone. Align bank roles to actual SSO groups after owner review.

Proposed roles: BusinessRequester, BusinessExecutor, WorkflowDesigner, RuleMaintainer, CapabilityMaintainer, WorkflowReviewer, ProcessOperator, ReleaseOperator, Auditor and PlatformAdministrator. Role names are placeholders pending enterprise mapping. No shared wildcard admin role for ordinary users.

## 2. Audit storage strategy

MSSQL append-only events are the operational source for reconstruction. Tables for current run/batch status are projections for fast reads. Preserve event version, eventId, UTC event/record time, run/activity, message/correlation/causation, actor/service identities, operation/rule/package version references, batch/row GUID, reason/outcome, resource scope, relevant ServiceNow ticket and runbook/control ID, and payload hash/protected reference. Prevent update/delete for normal service roles; consider write-once controls, retention and ledger separately with bank approval.

Audit export is a controlled, scope-filtered API; redact credentials, raw account content, tokens and sensitive CSV data. The event history is not a secret copy of source payloads.

## 3. Operator semantics

| Command | Precondition | Result / audit | Forbidden |
|---|---|---|---|
| Pause | Running, ProcessOperator for scope, reason, current revision | PauseRequested; reach Paused at safe boundary, emit reason/time | Pretend to reverse a started write |
| Resume | Paused, compatible pinned dependencies, authorized | Running, queue next task, audit | Resume incompatible retired dependency silently |
| Cancel | Running/Paused, authorized reason | CancelRequested; settle or reconcile outstanding, then Cancelled | Remove historical evidence |
| RetryFailedStep | Failed at safely retryable step, reconciled prior attempt | New attempt on same run with linkage | Blind retry on unknown CyberArk write |
| RestartAsNewRun | Terminal run, authorized and policy allows | New runId linked to old, new explicit input selection | Reuse old runId or alter original outcomes |
| Export audit | Scoped auditor access | Evidence export with redaction and audit of export | Leaks raw secret/sensitive fields |

All mutating actions require expected revision/ETag to prevent two operators issuing conflicting commands. UI shows pending acknowledgement and refreshes from server; local click is not authoritative success.

## 4. Release and production control flow

- Author creates/validates draft in DEV. BPMN, AMIE rules, capability contract versions and bindings manifest are locked into immutable package digest.
- Reviewer checks diff, complete test evidence, maker/checker separation where required, and change ticket. Approval is an authoritative backend event, not a typed ticket field.
- UAT deploys **exact package bytes**, substitutes only allowlisted environment refs, executes regression and captures evidence.
- Release Center production preflight checks signature/digest, compatible live service manifests, Kafka ACL, secrets refs without exposing values, rule versions, approved CA/control evidence and user rights.
- Operations-controlled pipeline activates package; developer does not need PROD access. Existing runs stay pinned, new runs receive new active version.
- Rollback selects previously approved package for **future** starts. It does not roll back external CyberArk writes.

## 5. Controls vs software permissions

Runbooks/controls specify required operational procedure, permitted exception path, required evidence, escalation and owner. Roles specify who may invoke which API. Both must be represented and validated separately. Actual Wells Fargo CAs, control IDs, retention and ServiceNow integration are UNKNOWN until verified by authorized owner. Never invent them or mark a mock ticket as bank approval.

## 6. Production-safe testing

- Developer/tester fixtures run only in isolated DEV/UAT with approved test accounts and test broker bindings.
- Destructive or external writes must use approved fake server/test tenant or explicit owner permission.
- No API Regression button executes production writes or creates broker subscriptions from arbitrary user input.
- Negative tests: denied direct API, altered manifest digest, wrong environment binding, duplicate command, timeout during external write, cross-tenant data disclosure, self-approval and missing control evidence.

---


<a id="sdk-section-7"></a>

# SDK 06 - DCMS: End-to-End Composition, Configuration, Execution and Evidence

**Purpose:** Use the user-described DCMS behavior to prove the generic Unity platform. DCMS must remain a workload/application, not SDK/BOB special code. Field names, CyberArk DTOs and API return codes must be confirmed in repo.

## 1. Source-described business process (do not reinterpret)

- User uploads CSV containing new values for account/platform custom attributes.
- Import rows into a data-owned table. Assign **one batch number** to the import and a **GUID to every row**.
- Process each row sequentially for the initial workflow.
- Locate the corresponding CyberArk account.
- Replace/add the specified custom attribute values **in account memory first**.
- Execute add/update account API call.
- Record per-row success/failure/pass/skipped and human-useful reason.
- After batch completion, generate report with all pass/fail/success reasons and send via Email Capability.
- Future (NOT currently implemented): approved API ingestion, scheduled AutoSys/DB API pull, additional trigger sources; leave extension seams rather than implementing prematurely.

## 2. Service inventory and compile-time primitives

| Primitive (proposed stable key) | Owner | Input -> Output | Side effect | Required protection |
|---|---|---|---|---|
| Data.ValidateUpload | Data/ingestion | uploadRef -> validation | Read | file policy, schema, classification |
| Data.StageBatch | Data/ingestion | validatedRef -> batchId, rowCount | DB write | idempotent upload key |
| Data.GetBatchPage | Data/ingestion | batchId, pageCursor -> page rows | Read | owner-scope, pagination |
| CyberArk.GetAccount | CyberArk | accountRef -> accountRecord | Read | PAM.Account.Read |
| CyberArk.ApplyAllowedAttributePatch | CyberArk | accountRecord, patch -> modifiedRecord | In-memory transform | platform allowlist |
| CyberArk.AddOrUpdateAccount | CyberArk | modifiedRecord + revision -> writeOutcome | External write | PAM.Account.Update, reconciliation |
| Data.RecordRowOutcome | Data/ingestion | rowGuid, disposition, reason -> persisted status | DB write | expected revision + idempotency |
| Reporting.ComposeBatchReport | Reporting | batchId -> secureReportRef | Artifact write | scope, redaction |
| Email.SendApprovedNotification | Email | reportRef, recipientsPolicyRef -> delivery outcome | External send | recipient policy + deduplication |

All keys are **candidates**. Existing CyberArk and data operations in the repo must be mapped, not rewritten.

## 3. AMIE descriptors (proposed, not current source names)

- `DCMS.ValidateAccount@1`: facts CurrentRow+GetAccountResult+Platform; result Eligible/Skip/Reject with reasonCode.
- `DCMS.MapAttributes@1`: facts CurrentRow+Platform; result typed `CyberArkAttributePatch` of four allowed custom attributes.
- `DCMS.ShouldUpdate@1`: facts original account + proposed patch; result Update/NoChange and reason.
- `DCMS.ClassifyBusinessResult@1`: facts validation+actual external outcome; result business status/reason (do not conflate with successful validation).

Rules are configuration. No static `if application == DCMS` in CyberArk or BOB. AMIE evaluator is existing code; use adapter.

## 4. UI configuration click path

1. **Application Studio** -> New application -> enter `DCMS`, owner, allowed scopes, process template and business display settings -> Save draft.
2. **Capability Catalog** -> inspect `Data.StageBatch@ver`, `Data.GetBatchPage@ver`, `CyberArk.GetAccount@ver`, `CyberArk.AddOrUpdateAccount@ver`, `Reporting.ComposeBatchReport@ver`, `Email.SendApprovedNotification@ver` -> check availability and permission.
3. **Workflow Library** -> Create Draft from `Batch + Sequential Rows` template -> name `DCMS.Batch` -> select Central BOB.
4. **BOB Designer** -> configure start trigger (CSV upload), stage task, embedded CyberArk subworkflow task (Kafka dispatch), await correlated result, report task, email task, end event; link connections; save.
5. **Embedded subworkflow** -> sequential multi-instance over data-owned page iterator; GetAccount -> AMIE.Validate -> exclusive gateway; Map -> ApplyPatch -> AddOrUpdate -> RecordRowOutcome. Continue on configured row failure after recording outcome.
6. **AMIE Rules** -> bind rule descriptors to typed facts. Map each source CSV column to target platform custom attribute; configure missing-value policy and NoChange decision; execute fixture preview.
7. **Triggers & Forms** -> choose Manual CSV; generate required data input schema and file metadata; future API/AutoSys trigger marked planned/not active.
8. **Kafka Contracts** -> view logical command/outcome types, required correlation, partition policy; no freeform topic editing.
9. **Environment Bindings** -> choose `DEV` approved CyberArk endpoint ref, staging API, broker logical topic and test recipients; verify dependencies, no credential values.
10. **Validate Draft** -> backend BPMN/compiler/schema/rule/operation/host/permission checks; fix errors on node inspector.
11. **API Regression** -> test 5-row success+failure fixture, duplicate command, missing account, declined rule, uncertain write, row checkpoint, email failure and role denial.
12. **Workflow Library** -> Submit Review -> independent approve -> Publish immutable version. **Release Center** -> UAT exact digest, then production only after real bank approvals and Operations activation.
13. **Business Work Queue** -> upload CSV (authorized user) -> start batch; see counts and record reasons. **Run Monitor** for authorized staff -> diagram overlay, correlation, activity detail. **Audit** -> reconstruct run and report evidence.

## 5. Runtime logical sequence

```mermaid
flowchart TD
  U[Authorized CSV upload] --> S[Data validates and stages batch/row GUID]
  S --> CB[Central BOB starts pinned DCMS.Batch]
  CB --> OUT[Persist command/outbox; Kafka dispatch]
  OUT --> EB[CyberArk Embedded BOB receives batchRef]
  EB --> PAGE[Data-owned paginated row fetch]
  PAGE --> ROW[Sequential row iteration]
  ROW --> GET[CyberArk.GetAccount]
  GET --> RULE[Existing AMIE Validate / Map / ShouldUpdate]
  RULE --> DEC{Eligible and change?}
  DEC -->|Yes| PATCH[Apply allowed changes in memory]
  PATCH --> WRITE[CyberArk AddOrUpdate]
  DEC -->|No| RESULT[Persist skipped/nochange/rejected reason]
  WRITE --> RESULT
  RESULT --> NEXT{More rows?}
  NEXT -->|Yes| ROW
  NEXT -->|No| DONE[Publish correlated batch outcome]
  DONE --> REPORT[Reporting composes artifact]
  REPORT --> EMAIL[Email Capability sends approved report]
  EMAIL --> END[Central BOB records terminal business status]
```

## 6. Exact example fixture

- CSV source: 5 rows `accountRef,platformKey,application,costCenter,owner,businessUnit` (illustrative column names).
- Batch: `BATCH-DCMS-0001` with five row GUIDs generated at staging.
- Expected: row 1 updated; row 2 no change; row 3 rejected missing account; row 4 skipped by AMIE rule; row 5 external call timed out after request, marked UnknownExternalOutcome pending reconciliation.
- Per-row invariants: batchId stable, unique rowGuid, one active claim per row, no second write for duplicate command without reconcile, reason code persisted, audit has rule/operation/package versions.
- Aggregate counts **must reconcile** to all rows. `Total = Succeeded + NoChange + Rejected + Skipped + Failed + UnknownOutcome + InProgress + Pending`; terminal count should exclude unknown states until resolution policy says otherwise.
- Report contains status and human-readable reason per row, not raw credentials. Email status is separate from CyberArk update outcome.

## 7. Recovery and release proof

- Crash after row two: after restart rows 1 and 2 are not blindly processed again; row three is resumed or claimed safely.
- Broker delivers `ExecuteEmbeddedWorkflow` twice: inbox prevents duplicate batch side effects.
- Timeout after CyberArk write: query/reconcile external state before retry; do not assume failure.
- Pause mid-row: complete or reconcile current external write, then pause at checkpoint; show PauseRequested until actually paused.
- Replace AMIE version in DEV: new draft package required; existing batch remains pinned.
- Trigger source changes later from CSV to approved API: input adapter changes, downstream staged-row contract and BOB/AMIE composition remain stable.

## 8. Demonstration success criteria

Present in BE: source/upload -> batch + row GUIDs -> configured BPMN with registered operations -> AMIE mapping/eligibility -> one real/approved nonprod CyberArk update or clearly marked stub -> final persisted row reasons -> report/email outcome -> live business dashboard -> technical run overlay -> audit reconstruction. Also demonstrate a second workflow (Hygiene) reusing at least one capability operation without source edits; if second pilot not complete, mark it pending, not demonstrated.

---


<a id="sdk-section-8"></a>

# SDK 07 - DEVIN New Capability Service Construction Recipe

## A. Inputs DEVIN must obtain

- Existing Unity repository, root `AGENTS.md`, current solution, approved .NET target and CI templates.
- Service name, domain owner, purpose, source data owner, external API/contracts and approved dev/test tenant.
- List of primitives required; do not guess operations from a workflow screenshot.
- Existing AMIE interfaces and BOB embedded hosting types; current Kafka contract/envelope/ACL conventions.
- Required permissions, data classification, timeout, side effects, reconciliation policy and bank controls.

If any key input is absent, report a gap with evidence and propose the smallest safe stub for testing; do not silently invent a production implementation.

## B. Build steps

1. **Inspect first:** Find existing capability framework, handlers, SDK conventions, AMIE runtime. Record reuse vs changes in `JOB-00` audit.
2. **Agree contracts:** Define operation descriptor, DTO/schema, auth policy, messaging, AMIE facts and expected outcomes. Freeze with JSON fixtures and tests before concurrent PRs.
3. **Create service template:** approved .NET service project with health, DI, logging, controlled configuration. Do not add unapproved libraries.
4. **Write domain adapter:** smallest typed client with cancellation, timeouts, exception normalization and test fake. No generic arbitrary HTTP/SQL executor.
5. **Write handler:** implements SDK interface; input/output strongly typed, stable key/version and declared side effect; return structured outcome.
6. **Register:** use trusted assembly registration/compile-generated registry. Startup rejects duplicate keys and malformed metadata. Add test for missing handler registration.
7. **AMIE bridge:** declare needed facts and output schemas, resolve approved published rule via existing AMIE engine; support local evaluation in embedded host.
8. **BOB bridge:** expose handler to local dispatcher and (if needed) remote Kafka execution using same manifest. Confirm exact version pinning.
9. **Broker integration:** subscribe only to allowed logical inbound messages, verify schema/auth/inbox, publish outcome via outbox; derive partition key and correlation fields.
10. **Audit:** emit safe events for request, rule, handler execution and outcome. Audit should reassemble an operation by run/activity IDs.
11. **Public contract:** generate metadata + fixture + OpenAPI test endpoints; backend must be testable without UI.
12. **BE integration:** verify registry lists operation, inspector renders inputs automatically, binding picker type-checks and can insert into BPMN draft.
13. **Regression:** unit, API, schema, denied, duplicate, timeout/crash, redaction, version mismatch and second-workflow reuse.
14. **Submit PR:** source paths, build/test evidence, before/after, restrictions, approval gaps, file summary. No direct PROD deployment.

## C. Reusable PR checklist

- [ ] API contract and `operationKey@contractVersion` stable.
- [ ] Service/class names follow current repository conventions.
- [ ] Local registration tests green, no duplicate/undeclared handler.
- [ ] Manifest published only by approved deployment identity.
- [ ] `InputSchema`/`OutputSchema` and fixtures match compiled DTOs.
- [ ] Auth checked at API **and** worker invocation.
- [ ] AMIE rule metadata typed, rule version pinned; no duplicate AMIE parser.
- [ ] Kafka command/outcome contracts versioned, correlation/idempotency included.
- [ ] In-memory local workflow uses shared BOB core and DI.
- [ ] External write reconciliation specified; retries cannot cause duplicate mutations.
- [ ] Evidence append-only with no secrets/raw sensitive payload.
- [ ] BE inspector configures operation from descriptor, not hardcoded page.
- [ ] OpenAPI regression includes denied/invalid paths.
- [ ] At least two workflow fixtures reuse the same handler.
- [ ] Reviewer receives actual file summary and outstanding CA/approval gaps.

## D. What a handoff from BE should give DEVIN for a missing operation

The designer should export an **Operation Development Request** containing: capability owner, proposed operation key/version, business intent, preconditions, input/output JSON Schema, example fixtures, permissions/resource scope, side effects, mandatory AMIE facts, expected error/outcome codes, external client dependency, timeout, retry/reconcile policy, logical Kafka contracts, audit category, acceptance tests, requested environment and code-review/change ticket references. This is a specification, not automatically executable code.

## E. Correct file path format in PRs

`/Unity.Capability.CyberArk/Operations/GetAccountHandler.cs`
`/Unity.Capabilities.Contracts/OperationDescriptor.cs`
`/Unity.Capabilities.Hosting/Registration/CapabilityRegistrationExtensions.cs`
`/Unity.Capability.CyberArk.Tests/GetAccountHandlerTests.cs`

Follow real repository paths after discovery; above paths are illustrative.

## F. Files and Structure Summary (required in PR response)

New: list paths; Updated: list paths; Deleted: list paths; No Change: related untouched modules; Tests: commands+results; Known gaps: approval/control/library/repo uncertainties.

---


<a id="sdk-section-9"></a>

# SDK 08 - Required API / Contract / Runtime Regression

All BE interactions must have server APIs. Test semantics through API/worker even when a UI screen is not yet built. The routes below are proposed families; align with actual API surfaces from repository inspection.

| ID | Test request / setup | Expected behavior / rejection | Owner |
|---|---|---|---|
| SDK-01 | Start service with two handlers same key/version | Startup fails diagnostic, no ambiguous registration | SDK |
| SDK-02 | Valid compiled handler + manifest fixture | Deterministic schema and registry descriptor | SDK |
| SDK-03 | Manifest submitted by untrusted caller | 403 / no registry state change, audit denial | Registry |
| SDK-04 | Manifest has invalid schema or missing permission | 422 structured field errors | Registry |
| SDK-05 | Registry `Registered` but service incompatible/unhealthy | BE sees unavailable; BOB denies execution | Registry |
| SDK-06 | GET operations as scoped user | Only permitted descriptors/details returned | API/RBAC |
| SDK-07 | GET operation input schema | Required fields/types and classification match DTO | SDK/BE |
| SDK-08 | Bind string to complex object input | Compiler returns BIND_TYPE_MISMATCH and BPMN element ID | BOB |
| SDK-09 | AMIE rule missing required fact | Compiler error; no publish | AMIE bridge |
| SDK-10 | AMIE evaluates valid fixture in embedded host | Typed output and pinned rule version | AMIE bridge |
| SDK-11 | Local handler via BOB | No central per-step HTTP roundtrip | Embedded host |
| SDK-12 | Kafka remote handler invocation | Correlated persisted command/outcome, token resumes once | Kafka/BOB |
| SDK-13 | Duplicate Kafka command | No duplicate write; stable outcome | Capability worker |
| SDK-14 | Timeout after external write sent | UnknownExternalOutcome; reconciliation gate | CyberArk worker |
| SDK-15 | Worker restart after two DCMS rows | Resume remaining rows; no duplicate outcomes | Embedded host |
| SDK-16 | Paused mid-CyberArk write | PauseRequested, safe checkpoint, no false rollback | BOB/operator |
| SDK-17 | Wrong role invokes operator API | 403, state unchanged, denial event | Security |
| SDK-18 | Different user reads batch outside scope | 403/404, no sensitive metadata | BE API |
| SDK-19 | Published workflow edited in place | Reject conflict; copy to new draft required | Definition API |
| SDK-20 | Approved UAT package changed before PROD | Digest mismatch blocks activation | Release |
| SDK-21 | Typed ServiceNow ticket but no approval evidence | PROD preflight blocked | Release |
| SDK-22 | DCMS five-row fixture | Correct per-row and aggregate statuses, reasons and report | DCMS |
| SDK-23 | Email fails after account processing | Account outcomes preserved; email separate | Email |
| SDK-24 | Reuse same GetAccount operation in Hygiene and DCMS | No BOB core or CyberArk handler code change | Integration |
| SDK-25 | Simulate broker reconnect during monitor | Business projection refreshes from API, no ghost state | BE |
| SDK-26 | Audit export with restricted account details | Redacted, scope-limited, export event logged | Audit |
| SDK-27 | Unsupported BPMN element | Validation/publish error, not silent skip | BOB |
| SDK-28 | Disallowed physical Kafka topic from UI | Reject; only approved logical bindings | SDK/Security |

## Response conventions

- 200/201 success with correlation, revision and stable schema.
- 202 accepted async run/control request; do not misrepresent as completed.
- 400 syntax, 401 unauthenticated, 403 unauthorized, 404 scoped invisible, 409 revision/dependency conflict, 422 semantic/schema errors, 503 unavailable dependency. Exact codes must be finalized with existing API conventions.
- Negative tests assert no side effects and audit denial. Positive tests assert actual state, not merely HTTP status.
- Regression results must record test identity, time, environment, package/manifest digest and evidence URI. Fixtures cannot contain real passwords or live account identifiers.

## CI lanes

- PR: build, static security checks, SDK registration and schema fixtures, BOB parser/compiler semantics, AMIE adapter unit tests, API authorization, deterministic UI interaction tests.
- DEV integration: Kafka consumer/outbox/inbox, MSSQL database migrations/checkpoint/audit, fake CyberArk external client, crash/restart and duplicate tests, BE UI+API E2E.
- UAT: exact approved package digest, compatible service versions, controlled test tenant, bank-required CA evidence and smoke test.

Do not label tests as passing without execution evidence in the actual repository pipeline.

---

<!-- END SOURCE 072: docs/sdk/LEGACY-CONSOLIDATED-SDK-v1.0.md -->

---

<!-- BEGIN SOURCE 073: docs/source-detail/v1.1/DEVIN-DISPATCH-AND-PR-PROTOCOL.md -->

> **v2.1 preserved historical reference:** Current acceptance, environments, milestones and release controls in the root v2.1 documents override conflicting original statements.

# Copy-ready DEVIN Dispatch Prompts and Merge Protocol

This repo handoff gives DEVIN repeatable context. **Before asking for implementation, copy into the actual Unity repo and commit via review**: `AGENTS.md`, `.agents/skills/*`, `docs/*`, and `jobs/*`. Do not commit `history/` if bank policy prohibits attaching prior artifacts; preserve it in an approved knowledge area instead. The current files are proposals, not verified enterprise deployment instructions.

## Session A — Immediate inventory (run first, read-only)

> Read `AGENTS.md`, `docs/00-START-HERE.md`, and `jobs/JOB-00-reconcile-repository.md`. Inventory current Unity, AMIE, BOB, CyberArk, Kafka, MSSQL and BE Blazor code, naming real file paths and existing tests. Do not modify source. Output the REAL-REPOSITORY-MAP, actual approved dependencies, exact AMIE interface contracts and blockers. Never claim a proposed class already exists unless source proves it. Stop at a recommended minimal contract freeze.

Review findings with architect/owner. Resolve discrepancies via ADRs and then authorize Session B. Do not ask multiple sessions to invent their own conflicting SDK contracts.

## Session B — Contract freeze (after A)

> Implement `JOB-01-freeze-contracts.md` using the actual existing AMIE and service code. Produce versioned shared operation/AMIE/BPMN/Kafka/audit/release contracts and failing negative tests. Keep names compatible with current namespaces. No major runtime implementation. Return changed files and API test evidence.

## Session C — SDK and Registry (parallel once B is merged)

> @skills:unity-capability-service Implement JOB-02 and, in a separate PR after contract tests, JOB-03. Reuse current hosting/DI conventions. Make a safe compiled test handler appear in authorized BE registry schema APIs through trusted manifest publication. No dynamic user code, no unapproved Kafka topics. Prove operation can be referenced twice without new handler code.

## Session D — AMIE adapter (parallel)

> @skills:unity-amie-bindings Implement JOB-04 using existing AMIE evaluator and rule serializer. Show one real rule decision with typed inputs, version pin, schema mismatch rejection and local embedded execution. Do not write a replacement rule engine. Submit tested adapter contract and metadata APIs.

## Session E — BOB Core + Hosts (two PRs, parallel with C/D)

> @skills:unity-bob-bpmn Implement JOB-05 parser/compiler and BPMN semantic fixtures using approved existing dependencies. Then implement JOB-06 common interpreter with central and embedded hosts against frozen SDK/AMIE contracts. Reject unsupported BPMN at publish. Demonstrate sequential multi-instance and durable Kafka wait without DCMS-specific engine logic.

## Session F — Messaging and SQL (parallel)

> Implement JOB-07 and JOB-08 in separate PRs using the enterprise's current Kafka and MSSQL conventions. Supply inbox/outbox deduplication, correlation, durable checkpoints, append-only safe audit and status projections. Test broker outage and worker restart, do not claim exactly-once external CyberArk writes.

## Session G — BE design and composition (after contracts, can mock APIs briefly)

> @skills:unity-be-blazor Implement JOB-09 and JOB-10 using existing Blazor project and approved UI libraries. Create Workflow Library, SVG BPMN canvas, registry-backed typed operation inspector and AMIE rule picker, with actual backend validation and XML/DI persistence. Use v0.7 HTML as visual reference only. Remove mocks before demo and keep features accessible to role-scoped users only.

## Session H — DCMS capabilities (parallel with G)

> @skills:unity-capability-service Implement JOB-11, JOB-12 and JOB-13 in separate code ownership branches. Map the existing DCMS database tables, CyberArk adapter operations and corporate email. Ensure batch number + row GUID staging, sequential account processing, AMIE mapping, in-memory patch, confirmed add/update, persisted reason, Reporting/Email via Kafka. Mark any unapproved integration mock truthfully.

## Session I — Operations, controls and regression (start early, integrate continuously)

> @skills:unity-release-regression Implement JOB-14 through JOB-17 as isolated PRs. Every BE function needs secured API; enforce role scopes and operator safe controls. Create immutable release package and bank approval gates without pretending a ServiceNow ID proves approval. Execute P0 tests R01-R18 and failure injection, store redacted evidence with exact run and package version.

## Session J — Integration and demo

> Integrate JOB-18 DCMS against real accepted contracts and tests; then attempt JOB-19 second reuse workload without modifying BOB Core. Complete JOB-20 with clean-environment build, BE clickthrough demo, API regression and an audit timeline. Explicitly separate **DEV demonstration**, **UAT tested**, and **bank PROD approved** states; record release blockers.

## PR merge protocol

- Freeze contracts and generate implementation fixtures first; API/DTO changes require owner review and updating all consumers + tests.
- Use separate worktrees/branches per lane; no parallel edits to the same shared contract file without coordinated merge.
- A test-only stub must be named as such and removed or explicitly marked before real integration demo.
- After each PR, re-run contract + namespace/manifest tests and update roadmap status ledger.
- Every PR includes actual project/folder/file summary, unit/contract/integration tests, unauthorized cases, audit sample, known limits and next dependent job.
- No direct developer PROD access, uncontrolled third-party package, blind retry of uncertain CyberArk update or unreviewed signed release bypass.

## Distinct artifacts

The `.agents/skills` files teach DEVIN repeatable engineering procedures. They do **not** automatically install or implement the runtime Unity Capability SDK. `JOB-02` creates/adapts that SDK; each future service then consumes the approved SDK NuGet/project package.

<!-- END SOURCE 073: docs/source-detail/v1.1/DEVIN-DISPATCH-AND-PR-PROTOCOL.md -->

---

<!-- BEGIN SOURCE 074: docs/source-detail/v1.1/QA-BPMN-v1.1.md -->

> **v2.1 preserved historical reference:** Current acceptance, environments, milestones and release controls in the root v2.1 documents override conflicting original statements.

# QA - Unity BPMN End-to-End Design Handoff v1.1

## Scope verified in this handoff

- Source corpus: existing v1.0 current implementation package preserved; new v1.1 docs, job packets and first-party interactive mock added.
- **New interactive prototype:** Chrome/Chromium Playwright in-memory HTML test (no remote dependencies): 8 navigation groups, four workflow scenario presets, click node -> inspector, add capability operation -> canvas, save trigger, validate, start mock fixture, dashboard count update, release/audit view and role switching. Browser test reported **zero JavaScript page errors**.
- Screenshots: `wireframes/screenshots/01-*.png` through `09-*.png` plus `v1.1-contact-sheet.png`.
- **18 Mermaid diagrams:** editable `.mmd` files and inline Markdown render source. Mermaid syntax was reviewed but **not independently compiled by a Mermaid renderer**.
- **3 illustrative new BPMN XML fixtures** (NAS query, guarded delete, scheduled Policy Drift) plus 2 previously included DCMS fixtures: XML parse passes; **XML parse alone is not BPMN 2.0 XSD, executable or token-conformance proof**.
- **JSON fixtures:** parse, placeholders are marked PROPOSED and source code/API verification required.
- **OpenAPI draft:** YAML parses, 14 proposed endpoint families; not a live service definition.
- **Skills:** existing repository Skills retained; three affected Skills (BE Blazor, BOB BPMN and Capability Service) repackaged successfully through skill validation. The other two existing Skills unchanged.
- **Documents/jobs:** link and file-existence checks in current pack; new job references and plan resolve.

## Not verified

- Actual Unity source compile/test, installed AMIE interface, BOB runtime conformance, EF API NAS owner/controller/routes, CyberArk endpoint behavior, AutoSys installed job/version, MSSQL migration/state, Kafka outbox/inbox, approved commercial UI library, Wells Fargo access/change/control approvals, PROD activation, live UI/backend API.
- Safety of real external account delete. Prototype never makes a delete call.
- Full BPMN 2.0 executable coverage. Explicitly document supported subset and reject unimplemented elements.

## Definitive next test gates (DEVIN)

1. Source audit (JOB-00/01): actual project names, approved SDKs, pre-existing operations, AMIE engine, AutoSys and NAS contracts.
2. BPMN XSD/DI schema validation and actual interpreter semantic tests, including external wait/duplicate and sequential multi-instance.
3. Real API regression, policy-denial, version/concurrency, typed AMIE operation binding.
4. Authorized DEV DCMS 5-row fixture with verified outcome, report/email, dashboard and redacted audit reassembly.
5. Conditional second pilot: guarded delete mock or AutoSys Policy Drift test trigger; no fabricated PROD or destructive execution.

<!-- END SOURCE 074: docs/source-detail/v1.1/QA-BPMN-v1.1.md -->

---

<!-- BEGIN SOURCE 075: docs/source-detail/v1.1/QA_HANDOFF_REPORT.md -->

> **v2.1 preserved historical reference:** Current acceptance, environments, milestones and release controls in the root v2.1 documents override conflicting original statements.

# Unity v0.8 Handoff QA Report

- Source reference: v0.6/v0.7 artifacts retained under `history/`; original Unity repository NOT inspected.
- Markdown documents: 73
- DEVIN job packets: 21
- Devin repository Skills: 5 (all packaged through skill-creator validator)
- JSON fixtures including historical references: 6; parsed successfully: True
- BPMN fixtures: 4; XML wellformed: True
- Markdown local links unresolved: 0
- Overall bundle zip integrity: True
- Bundle size: 210,801 bytes

## Limits

**Not tested:** real C# compilation, Blazor UI in a connected repository, Kafka broker, MSSQL migrations, runtime BPMN conformance, CyberArk integration, AMIE real adapter, ServiceNow approval or bank compliance. These are implementation jobs; fixtures are illustrative.

## Observations

Local links in generated markdown resolve.

<!-- END SOURCE 075: docs/source-detail/v1.1/QA_HANDOFF_REPORT.md -->

---

<!-- BEGIN SOURCE 076: docs/ui/01-CAPABILITY-ONBOARDING.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI Runbook 01 — Register and Verify a New Capability

**Audience:** capability developer, service owner, authorized publisher. **Screen names are proposed Blazor BE destinations** based on v0.6/v0.7 prototypes; actual routes require implementation. **Do not use a live enterprise system in regression fixtures.**

## Developer preparation (before BE)

1. Use `@skills:unity-capability-service`. Inspect repo and real SDK first. Identify reusable primitive: operation key, input/output DTO, read/write nature, security policy, schema, AMIE data requirements, Kafka logical contracts, audit and test fixtures.
2. Implement typed handler in service, register with SDK DI, add tests for success, schema-invalid request, denied caller, duplicate command, and uncertainty after an external write.
3. Build signed/trusted-attested manifest; run manifest schema/contract validation in CI. Do not publish automatically because startup found a class.
4. Deploy to **approved nonproduction** environment, complete code controls, and publish manifest using service identity.

## BE click path

1. Sign in as authorized capability owner. Navigate **BE → Capability Registry → My Capability**.
2. Search capability key; inspect **Manifest Version**, owner, deployment, readiness and permissions. If absent, use registration diagnostics; do not bypass with a raw URL.
3. Open **Operations** and choose the declared operation (e.g. `CyberArk.GetAccount@1.0`).
4. Inspect inputs (required fields, types, classification), outputs, execution host modes, AMIE required facts, Kafka subscriptions/publications, retry policy and permission.
5. Choose **Test contract** in DEV with approved nonproduction fixture, pass `AccountRef`, inspect safe response and audit/correlation.
6. Choose **Add to workflow**. BE inserts a service task with operation reference; input field editor auto-populates from schema.
7. Save draft, validate wiring. Successful registration means handler exists + manifest/health/policy are compatible—not that production use is approved.

## Negative demonstration

Change one required field type, reference an unapproved operation, or remove required permission; validation must fail with actionable code and node ID. A direct API invocation must also fail, not just the UI button.

## Required evidence

Manifest version/digest; handler source path; CI build, SDK registration tests; service health; operation schema; API request/response (redacted); denied-call test; BE screenshot; ServiceNow code release evidence where applicable.

<!-- END SOURCE 076: docs/ui/01-CAPABILITY-ONBOARDING.md -->

---

<!-- BEGIN SOURCE 077: docs/ui/02-WORKFLOW-DESIGN-AND-AMIE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI Runbook 02 — Compose a BPMN Workflow with an AMIE Rule

**Audience:** WorkflowDesigner, RuleMaintainer, Reviewer. **Goal:** no new microservice code when operations already exist.

1. Sign in to **BE → Workflow Library → New Draft** (or clone an approved template). Enter application key, description, owner, logical input contract, optional ServiceNow draft reference.
2. In **Designer**, select **Start Event**, **Service Task**, **Business Rule Task**, **Exclusive Gateway**, **Service Task**, **End Event**. Connect valid sequence flows, labels and default branch.
3. Click first service task; open **Capability Operation** palette. Search only **approved compatible** operations. Choose `CyberArk.GetAccount@1.0` as example.
4. Inspect auto-generated required inputs; set `accountRef ← input.accountRef` or `item.accountRef`. Output `account` to `steps.getAccount.output.account`.
5. Click Business Rule Task; select an **existing approved AMIE rule**, inspect its required facts/expected output. Map account object and source data from typed binding selector. Example result `eligible` and `reasonCode`.
6. Click gateway, choose rule outcome binding; configure eligible branch and explicit rejected/skipped branch. Do not paste C# into the gateway.
7. Click write service task if permitted; bind AMIE mapping/modified account result to the operation. Show write side-effect warning, permission and reconciliation policy.
8. Choose **Validate Draft**. Confirm backend compiler checks BPMN 2.0/DI, supported elements, flow reachability, data types, rule/handler versions, host mode, retry, authorization and missing environment keys.
9. Save (ETag/revision check); preview rule with **safe fixtures**, no real CyberArk mutation.
10. Submit for review; reviewer checks manifest versions and audit/control changes; approved publisher creates immutable version.
11. Author starts only DEV/approved environment test run through authorized API; inspect Run Monitor and complete event chain.

## Expected UX behavior

Palette shows operation owner/version/side-effect and compatibility. Right inspector renders typed input editors and source binding dropdowns. Validation uses node IDs and provides exact missing field. Published packages are immutable. Re-edit requires clone draft, not in-place mutation.

## Regression

Unknown operation; rule missing; bad field mapping; unsupported BPMN element; missing gateway default; unauthorized writer; stale draft; forbidden secret in form field; render XML->BPMN DI->XML roundtrip.

<!-- END SOURCE 077: docs/ui/02-WORKFLOW-DESIGN-AND-AMIE.md -->

---

<!-- BEGIN SOURCE 078: docs/ui/03-DCMS-CONFIGURE-AND-RUN.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI Runbook 03 — Configure and Execute DCMS in DEV

**This is a business workload used to prove platform reuse, not application code inside BOB.** Before a real test, reconcile actual DCMS table schema, AMIE rule names, CyberArk safe test accounts, Email/Reporting integrations and data owner. Mock any unapproved external dependency and label clearly.

## Configure once

1. **BE → Application Studio → Create/Open DCMS**. Set owner, user scopes, allowed trigger and application-specific data contract.
2. **Data source:** select `CSV Upload` trigger; bind configured CSV schema, allowed headers, safe file storage, max rows and required validation. Future API/database/AutoSys sources all normalize to a start intent (P1, not currently present).
3. **Central BOB draft:** create `DCMS.BatchCoordinator`; add `StageImport` capability activity, `CreateBatch`, cross-service `ExecuteEmbeddedWorkflow`, durable wait, `Reporting.GenerateBatchReport`, and `Email.RequestNotification`.
4. **CyberArk embedded BOB:** create/reuse sequential multi-instance row workflow; `GetAccount` -> AMIE eligibility -> AMIE custom-attribute mapping -> in-memory patch -> `AddOrUpdateAccount` -> persist result. Map batch and row GUID to each outcome; only one row at a time.
5. **AMIE:** select existing rule definitions or create approved rule configurations through current AMIE tools. Bind the four illustrative CSV fields to correct CyberArk platform custom-attribute targets. Ensure platform metadata validates allowed attributes. Missing account policy must be explicit: fail/skip/create only if create is approved.
6. **Email:** configure report recipient/template policy in AMIE and bind `Reporting.GenerateBatchReport` output reference to Email capability; do not put SMTP in BOB.
7. **Runbook:** attach batch control owner, accepted failure thresholds, what Pause/Cancel mean, and reconciliation procedure for unknown writes.
8. Validate and publish approved DEV package with exact versions. Do not assume it can go to PROD because it runs in DEV.

## Execute a controlled 5-row fixture

1. Sign in as BusinessExecutor with DCMS scope; choose **Business Work Queue → DCMS → Upload CSV**.
2. Upload safe fixture (success / no change / missing account / invalid AMIE mapping / uncertain write). Confirm batch number and **unique row GUID per row** are created.
3. Choose **Start**. BE calls authorized API and shows run ID; central BOB stores run and sends Kafka command.
4. Watch **Business Batch** summary: pending/in progress/succeeded/failed/skipped/no change/unknown totals and a last update time. Percent = terminal count / total staged; unresolved unknown outcomes must not be hidden.
5. As Operator, open **BPMN Run Monitor**: trace central message, embedded workflow, AMIE decision version, capability result, row GUID and audit event.
6. Confirm every row reaches final or explicitly unresolved classification; generate report from stored row results, not message count. Confirm email requested through Email Capability and delivery recorded separately.
7. Download redacted report, inspect reasons for failures and no change; compare report counts to DB/API; inspect audit by batch number and correlation.

## Negative/UAT controls

Test unauthorized upload; duplicate file import; conflicting batch number; duplicate Kafka command; CyberArk timeout after possible write; pause after row 2 (no row 3 starts until resume); cancel/restart linked run; unexpected email failure; audit unavailable; rule version missing; service ACL denied. No blind external write retry.

## Success evidence

CSV fixture hash, batch/row GUIDs, published package digest, API trace, Kafka command/outcome IDs, AMIE rule versions, CyberArk operation reference or mock marker, persisted row status table, report checksum, email outcome, audit reconstruction screenshot, runbook revision.

<!-- END SOURCE 078: docs/ui/03-DCMS-CONFIGURE-AND-RUN.md -->

---

<!-- BEGIN SOURCE 079: docs/ui/04-OPERATIONS-ACCESS-MONITOR.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI Runbook 04 — Roles, Monitoring and Safe Process Controls

**Audience:** access admin, business user, operator, auditor. These role labels are proposals to map to real Wells Fargo entitlements.

## Assign scope

1. Access admin uses approved IAM integration, not UI-created fake enterprise roles. Map corporate identities/groups to permission+scope for application, workflow, data owner and environment.
2. Show a matrix in BE **Access Policies**: Designer (draft), Reviewer (approve), Executor (start/upload), Operator (run controls), Auditor (read evidence), ReleaseOperator (activate). Enforce policy via API and worker dispatch.
3. Test a BusinessExecutor sees **own assigned batches**, report and minimal reasons; cannot access run control, raw audit export or other team's batches.
4. Test ProcessOperator sees authorized runs, state, activity detail, pending Kafka command and runbook; cannot edit published workflow.
5. Test Auditor sees immutable history, permitted masked evidence and change request but no mutation.

## Monitor

1. Open Business Work Queue: summary counters and report link; confirm **no BPMN expertise required**.
2. Open technical Run Monitor as authorized support: select process ID, see activity overlay and event timeline, message IDs and safe AMIE decision reason; verify audit query yields same chain.
3. Temporarily disconnect SignalR/SSE in nonproduction: API reload reconciles current state on reconnect, avoiding stale badges.

## Pause

1. In Operator Console select live run, inspect `expectedRevision` and runbook.
2. Enter reason and approved change reference if required; choose Pause.
3. UI receives `PauseRequested`, **not** immediately `Paused`. Existing CyberArk call may finish; no next row should start after checkpoint acknowledgement.
4. Confirm transition event actor, UTC and reason. Resume with same run version and checkpoint, not new definition.

## Cancel/Retry/Restart

- Cancel requests no future work; does not automatically roll back external changes. Record partially successful rows.
- Retry only after failure classification; unknown external outcome blocks automatic write replay pending reconciliation.
- Restart creates **new run** linked to old; original evidence remains. A stale ETag, denied role or concurrent command returns explicit rejection.

## Runbook acceptance

Each operator action exposes the correct runbook version, required reason/ticket, expected consequences, escalation owner and evidence checklist. Bank control owners must approve exact process.

<!-- END SOURCE 079: docs/ui/04-OPERATIONS-ACCESS-MONITOR.md -->

---

<!-- BEGIN SOURCE 080: docs/ui/05-RELEASE-PROMOTION.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI Runbook 05 — DEV / UAT / PROD Configuration Promotion

**Audience:** workflow author, reviewer, release operator, control owner. This document defines a desired controlled release interface; current actual bank CAs and ServiceNow integration are not verified.

1. **DEV / Workflow Library:** author creates immutable candidate from validated draft, with exact BPMN, AMIE rules and operation contract lock file. Record author, UTC and review request.
2. **DEV / Regression:** execute API, BPMN semantics, role-denial and DCMS acceptance suites. Capture CI evidence and package digest; fail if missing rule/deployed operation version.
3. **Review:** designated reviewer compares diff and operational control/runbook changes. Link actual ServiceNow ticket and approval evidence from bank-authorized process. Prevent self-approval where required.
4. **Release Center → Candidate:** verify signature/digest and full dependency manifest; inspect allowed environment bindings (logical topic key/approved service endpoint/vault ref). Actual secrets not exposed.
5. **UAT:** authorized pipeline installs exact bytes/digest, resolves UAT logical bindings and runs smoke/E2E. UAT users sign off evidence.
6. **Release Center → PROD Preflight:** backend checks trusted issuer, exact UAT-approved digest, current service compatibility, broker access, binding completeness, real bank approvals, segregation of duties and required CAs.
7. **Operations Activation:** authorized ReleaseOperator (not developer) activates exact package; backend records actor/ticket/environment/digest/UTC and emits audit. If a gate fails, display **Blocked** with evidence rather than an enabled deploy button.
8. **Observe:** new runs use new version; existing runs stay pinned. Rollback selects prior approved version for new runs; never promise to undo CyberArk writes.

## Tests

Tampered package digest; missing ticket; ticket string without approval; author same as reviewer in restricted control; unavailable operation; retired AMIE version; wrong environment binding; worker ACL failure; UAT version differs from PROD candidate; developer attempts PROD; rollback while old run active.

## Records for auditors

Candidate diff, precise digest, actor/reviewer/deployer identities, timestamps, ServiceNow change ID and authoritative approval reference, test result evidence, environment bindings version and activation/rollback events. No secrets in package or UI screenshots.

<!-- END SOURCE 080: docs/ui/05-RELEASE-PROMOTION.md -->

---

<!-- BEGIN SOURCE 081: docs/ui/06-UI-AND-API-TESTING.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI Runbook 06 — How QA Tests the Finished Unity System

**Test both API and Blazor, never UI alone.** Use approved nonproduction identity, test data and broker/database resources. Do not run external CyberArk writes against PROD.

## BE test inventory

| Screen | Happy path | Negative path |
|---|---|---|
| Capability Registry | Manifest visible with schema and health | Unapproved operation cannot be invoked |
| Operation Inspector | Required inputs generated and mapped | Missing field/type or forbidden scope blocks validate |
| BPMN Designer | Drag supported nodes, save XML+DI, validate, publish | Unsupported gateway/invalid diagram rejected |
| AMIE Picker | Pinned approved rule evaluates | Missing/mismatched rule version errors |
| Trigger | Authorized CSV/API starts run | Malformed CSV/unauthorized/duplicate start denied |
| Business Queue | Correct counts and report | Other user's rows hidden; reconnect refresh |
| Run Monitor | Same BPMN with state overlay | Late/duplicate Kafka outcome doesn't duplicate transition |
| Operator Console | Pause->Paused->Resume; cancel/restart audited | In-flight write unaffected; stale revision refused |
| Audit | By run/batch/change ID reconstruct timeline | Restricted fields redacted; no mutate |
| Release Center | Same digest UAT->PROD after approval | Unapproved/fake ticket blocked |

## Regression sequence

1. Run unit/contract test suite after each SDK/core change.
2. Validate BPMN fixture XML and semantics of supported nodes, AMIE adapter and operation resolution.
3. Use authenticated API to create/save/validate/review/publish/start. Query run and audit via APIs.
4. Run DCMS five-row fixture with a mock or approved test CyberArk adapter, compare persisted batch rows with report and business projection.
5. Simulate Kafka duplicate, network failure, crash after possible external write, restart and concurrent operators.
6. Exercise role deny and scope partition for every mutation/read route; check redaction.
7. Run browser walkthrough, capture desktop screenshot, console errors and API evidence; don't substitute mock frontend state for real API responses.
8. Attach CI/environment/package digest/test evidence to release candidate; mark bank authorization separately.

## Acceptance threshold

No hidden unsafe retry, unauthorized operation, mismatched version, false terminal status, missing mandatory audit, or fake PROD approval. If any persists, block release and report exact failing scenario.

<!-- END SOURCE 081: docs/ui/06-UI-AND-API-TESTING.md -->

---

<!-- BEGIN SOURCE 082: docs/ui/07-SCREEN-BY-SCREEN-WIREFRAMES.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 07 - BE Screen-by-Screen Wireframe Specification

> Canonical interaction source: `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. This specification is a **proposal grounded in v0.9 architecture**, not evidence that the Blazor app implements these screens.

## Global UI shell and behavior

```text
+--------------------------------------------------------------------------+
| UNITY BE     Application [scope]    Environment [DEV/UAT/PROD]   [role]   |
+---------------------+----------------------------------------------------+
| Workbench           | Breadcrumb / page title / status of last fetch    |
| Registry            | Contextual actions and global validation/errors   |
| Onboarding          | ------------------------------------------------  |
| Studio / Library    | Search/list / visual work surface / detail panel  |
| BOB / AMIE          | (responsive, role-filtered, keyboard accessible)  |
| Delivery / Release  |                                                    |
| Business / Monitor  | Persistent save/review state, correlation footer  |
| Ops / Audit / Tests |                                                    |
+---------------------+----------------------------------------------------+
```

Navigation is a route change, not a security privilege. The API decides which pages and records can be read. Data refresh must preserve selection and filters; auth denial must be distinct from no matching records. In wireframe, role selector is only a simulated persona selector.

## Shared rules

- Every visible action has a stable control ID in the click catalog; no inert production buttons.
- Every mutating action uses backend API, role and resource-scope verification, expected revision/ETag, and correlation ID.
- Buttons showing `202 Accepted` must display Pending until server-confirmed completion.
- Destructive/high-impact controls require reason and review/runbook gate; no side effects in the standalone prototype.
- Draft editors show Unsaved changes, Validation errors (anchored to BPMN node/field), save revision, and pinned dependency versions.
- Form generation uses operation/rule JSON schemas. Sensitive fields use protected server references, never values in browser.
- UI success toasts are informative, not proof of durable writes. The actual backend state is authoritative.
- All data-heavy tables use server-side pagination, empty state and row-level scope filtering.

## Screen layouts and interactions

### workbench: Unity Workbench

**Purpose:** Find assigned applications, actions and runs

**Layout:** Summary tiles + recent executions + pinned applications; launch actions at upper right.

**Data contract:** `GET /api/v1/me/dashboard`

**Inputs:** application selector; favorite filter

**Roles:** All authenticated users

**Empty state:** No applications in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| WB-01 | Browse capabilities | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/capabilities` | Open registry scoped to current role |
| WB-02 | Open Application Studio | Designer,Reviewer,Operations | `GET /api/v1/applications` | Open assigned application configurations |
| WB-03 | My work | All authenticated users | `GET /api/v1/batches?scope=mine` | Open authorized batch list |
| WB-04 | Refresh status | All authenticated users | `GET /api/v1/me/dashboard` | Reload counts and last-updated time |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### catalog: Capability Registry

**Purpose:** Discover approved operations and service health

**Layout:** Left capability filter + middle operation table + right readiness summary.

**Data contract:** `GET /api/v1/capabilities; GET /api/v1/operations`

**Inputs:** search query; capability filter; availability filter

**Roles:** Designer,Capability Owner,Operations,Auditor

**Empty state:** No operations available in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| CAT-01 | Search / filter | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/capabilities?q=&status=` | Table is filtered without altering registry |
| CAT-02 | Inspect operation | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/operations/{key}/versions/{version}` | Open descriptor inspector at exact contract version |
| CAT-03 | Use in workflow | Designer | `POST /api/v1/workflow-drafts/{id}/activities` | Insert bound service task with stable key/version |
| CAT-04 | Refresh health | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/capabilities/{key}/readiness` | Fetch current readiness and compatibility |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### operation: Operation Inspector

**Purpose:** Inspect versioned schema and prepare reusable binding

**Layout:** Operation key/version title + contract tabs (Inputs, Outputs, Permissions, Messages, AMIE, Tests) + bind action.

**Data contract:** `GET /api/v1/operations/{key}/versions/{version}`

**Inputs:** operation selector; contract version; test fixture

**Roles:** Designer,Capability Owner,Operations,Auditor

**Empty state:** Operation removed or not in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| OP-01 | Back to Registry | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/capabilities` | Return to same catalog filters |
| OP-02 | View input/output schemas | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/operations/{key}/schemas` | Show required inputs, outputs, permissions and side effects |
| OP-03 | Test with DEV fixture | Capability Owner,Designer | `POST /api/v1/operation-tests/{key}/execute` | Non-PROD fixture result with reason/correlation shown |
| OP-04 | Add to BOB workflow | Designer | `POST /api/v1/workflow-drafts/{id}/activities` | Append service task using selected descriptor |
| OP-06 | Download contract manifest | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/operations/{key}/manifest` | Download approved manifest with schema refs but no secrets |
| OP-05 | Request missing primitive | Designer,Capability Owner | `POST /api/v1/operation-development-requests` | Generate typed DEVIN operation request, not code execution |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### onboarding: Capability Onboarding

**Purpose:** Review and publish typed compiled operations

**Layout:** Manifest wizard: service identity -> operations -> schemas/policy -> validation -> release evidence.

**Data contract:** `GET /api/v1/capability-manifests/drafts`

**Inputs:** capability key; operation key; owner; input schema ref; permission; side effect

**Roles:** Capability Owner,Reviewer,Operations

**Empty state:** No manifest drafts. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| ON-01 | Create manifest draft | Capability Owner | `POST /api/v1/capability-manifests/drafts` | Create local metadata draft; no executable registration yet |
| ON-02 | Add operation declaration | Capability Owner | `POST /api/v1/capability-manifests/drafts/{id}/operations` | Attach typed operation metadata to draft |
| ON-03 | Validate manifest | Capability Owner,Reviewer | `POST /api/v1/capability-manifests/drafts/{id}/validate` | Display schema/security/version checks |
| ON-04 | Submit service release evidence | Capability Owner | `POST /api/v1/capability-manifests/drafts/{id}/submit` | Send draft for privileged review, not auto-approve |
| ON-05 | Approve registry publication | Reviewer | `POST /api/v1/capability-manifests/{id}/approve` | Approve compatible manifest; no auto handler creation |
| ON-06 | Check deployed readiness | Capability Owner,Reviewer,Operations | `GET /api/v1/capability-manifests/{id}/readiness` | Show registered vs actually available separately |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### apps: Application Studio

**Purpose:** Compose application from workflows/capabilities

**Layout:** Application header and tabs: modules, capability deps, workflow, scopes, env refs.

**Data contract:** `GET /api/v1/applications`

**Inputs:** application name; owner; scope; selected modules

**Roles:** Designer,Reviewer,Operations

**Empty state:** No assigned applications. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| APP-01 | Create application draft | Designer | `POST /api/v1/applications` | New app blueprint with owner and scope |
| APP-02 | Add capability dependency | Designer | `POST /api/v1/applications/{id}/capabilities` | Add stable approved contract dependency |
| APP-03 | Save configuration | Designer | `PUT /api/v1/applications/{id}/draft` | Persist revision and ETag |
| APP-05 | Select application module | Designer,Reviewer,Operations | `GET /api/v1/applications/{id}/modules/{key}` | Switch composition tab with selected workflow and capability dependencies |
| APP-04 | Open workflow library | Designer,Reviewer,Operations | `GET /api/v1/workflow-definitions?application=` | Show workflows for selected app |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### library: Workflow Library

**Purpose:** Manage immutable definitions and lifecycle

**Layout:** Filter bar + definition/version table + lifecycle timeline and diff inspector.

**Data contract:** `GET /api/v1/workflow-definitions`

**Inputs:** search; application; lifecycle filter; selected definition

**Roles:** Designer,Reviewer,Operations,Auditor

**Empty state:** No definitions in filter. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| LIB-01 | New draft from template | Designer | `POST /api/v1/workflow-drafts` | Create draft and initial BPMN IDs |
| LIB-02 | Open selected version | Designer,Reviewer,Operations,Auditor | `GET /api/v1/workflow-definitions/{key}/versions/{version}` | Open editor if draft or read-only if published |
| LIB-03 | Compare versions | Designer,Reviewer,Operations,Auditor | `GET /api/v1/workflow-definitions/{key}/diff?from=&to=` | Show BPMN/rules/contracts/change diff |
| LIB-04 | Clone as new draft | Designer | `POST /api/v1/workflow-definitions/{key}/clone` | New editable version referencing parent |
| LIB-05 | Submit for review | Designer | `POST /api/v1/workflow-drafts/{id}/review` | Draft moves to InReview with ticket and evidence |
| LIB-06 | Approve version | Reviewer | `POST /api/v1/workflow-reviews/{id}/approve` | Independently approve candidate |
| LIB-07 | Publish immutable version | Reviewer | `POST /api/v1/workflow-definitions/{key}/publish` | Published with digest and pinned dependencies |
| LIB-08 | Retire selected version | Operations | `POST /api/v1/workflow-definitions/{key}/retire` | Prevent new runs but retain evidence |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### designer: BOB BPMN Designer

**Purpose:** Edit standard BPMN and type-safe Unity bindings

**Layout:** 3-column work surface: BPMN palette | SVG canvas | typed node inspector; issue panel below.

**Data contract:** `GET/PUT /api/v1/workflow-drafts/{id}/bpmn`

**Inputs:** node selection; operation; input binding; rule; host; flow path

**Roles:** Designer,Reviewer,Operations

**Empty state:** Empty BPMN canvas with Start and End. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| DES-01 | Add service task | Designer | `POST /api/v1/workflow-drafts/{id}/activities` | New BPMN service task with stable node ID |
| DES-02 | Add business rule task | Designer | `POST /api/v1/workflow-drafts/{id}/activities` | New BPMN business-rule task |
| DES-03 | Add exclusive gateway | Designer | `POST /api/v1/workflow-drafts/{id}/elements` | BPMN XOR gateway with branch conditions |
| DES-04 | Connect selected nodes | Designer | `PUT /api/v1/workflow-drafts/{id}/bpmn` | Directed sequence flow with new ID |
| DES-05 | Bind selected task input | Designer | `PUT /api/v1/workflow-drafts/{id}/bindings` | Typed mapping to input/current row/prior output |
| DES-06 | Save draft | Designer | `PUT /api/v1/workflow-drafts/{id}` | Persist BPMN XML + DI + inspector data with ETag |
| DES-07 | Validate BPMN and contracts | Designer,Reviewer | `POST /api/v1/workflow-drafts/{id}/validate` | Highlight node errors and publish readiness |
| DES-08 | Preview safe execution | Designer | `POST /api/v1/workflow-drafts/{id}/simulate` | DEV fixture preview with explicit mock label |
| DES-09 | Submit workflow review | Designer | `POST /api/v1/workflow-drafts/{id}/review` | Submit validated draft to reviewer |
| DES-10 | Import BPMN XML | Designer | `POST /api/v1/workflow-drafts/{id}/import` | Parse BPMN XML + DI and show unsupported elements |
| DES-11 | Export BPMN XML | Designer,Reviewer,Operations | `GET /api/v1/workflow-drafts/{id}/export` | Download BPMN 2.0 XML with DI/extension refs |
| DES-12 | Undo edit | Designer | `local editor; persist on Save` | Revert most recent uncommitted canvas edit |
| DES-14 | Switch central / embedded workflow | Designer,Reviewer,Operations | `GET /api/v1/workflow-definitions/{key}/execution-contexts` | Change designer context, loading pinned central or CyberArk embedded subworkflow |
| DES-13 | Redo edit | Designer | `local editor; persist on Save` | Reapply reverted canvas edit |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### amie: AMIE Rule Picker and Binding

**Purpose:** Reuse existing typed rules without rebuilding AMIE

**Layout:** Rule version list + required facts picker + decision preview and validation errors.

**Data contract:** `GET /api/v1/amie/rules`

**Inputs:** rule key/version; fact binding; output binding; safe fixture

**Roles:** Designer,Rule Maintainer,Reviewer

**Empty state:** No compatible AMIE rules. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| AMI-01 | Select rule version | Designer,Rule Maintainer,Reviewer | `GET /api/v1/amie/rules/{key}/versions/{version}` | Show required facts/decision types |
| AMI-02 | Map required facts | Designer,Rule Maintainer | `PUT /api/v1/workflow-drafts/{id}/rule-bindings` | Bind typed input facts and output references |
| AMI-03 | Preview rule with fixture | Designer,Rule Maintainer | `POST /api/v1/amie/rules/{key}/preview` | Existing AMIE evaluator returns typed safe result |
| AMI-04 | Save rule binding | Designer,Rule Maintainer | `PUT /api/v1/workflow-drafts/{id}/rule-bindings` | Persist pinned rule version and ETag |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### triggers: Triggers and Forms

**Purpose:** Declare validated manual/API/schedule inputs

**Layout:** Trigger type selector + generated form schema editor + CSV validation panel.

**Data contract:** `GET /api/v1/triggers`

**Inputs:** trigger type; CSV input; required column schema; application scope

**Roles:** Designer,Business User,Operations

**Empty state:** No configured trigger. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| TRI-01 | Choose trigger type | Designer,Operations | `GET /api/v1/triggers/types` | Display manual CSV/API/schedule capabilities and readiness |
| TRI-02 | Add required input field | Designer | `PUT /api/v1/workflow-drafts/{id}/trigger-schema` | New typed schema field for BE form |
| TRI-03 | Validate sample CSV | Designer,Business User | `POST /api/v1/ingestion/validate` | Return schema/row errors, no live write |
| TRI-04 | Save trigger mapping | Designer | `PUT /api/v1/workflow-drafts/{id}/trigger` | Persist trigger schema and source adapter ref |
| TRI-05 | Open business start form | Business User,Designer | `GET /api/v1/workflows/{key}/start-form` | Open role-scoped start UI |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### contracts: Kafka Contract Explorer

**Purpose:** Inspect logical message contracts and mappings

**Layout:** Message list + envelope schema and producer/consumer/ACL inspector.

**Data contract:** `GET /api/v1/messaging/contracts`

**Inputs:** message search; schema version; logical topic

**Roles:** Designer,Capability Owner,Operations,Auditor

**Empty state:** No declared messages. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| KAF-01 | Inspect message schema | Designer,Capability Owner,Operations,Auditor | `GET /api/v1/messaging/contracts/{key}` | Show producer/consumer/required fields/versions |
| KAF-02 | Validate correlation envelope | Designer,Capability Owner,Operations | `POST /api/v1/messaging/contracts/validate` | Check commandId/runId/activityId/idempotency/partition |
| KAF-03 | Check environment bindings | Designer,Capability Owner,Operations | `GET /api/v1/environment-bindings` | Show approved logical-to-physical resolutions |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### bindings: Environment Bindings

**Purpose:** Resolve approved logical endpoint/topic/secret references

**Layout:** Environment selector + logical ref table + redacted target/health panel.

**Data contract:** `GET /api/v1/environment-bindings`

**Inputs:** environment DEV/UAT/PROD; selected logical reference

**Roles:** Designer,Operations,Release Operator,Auditor

**Empty state:** No approved bindings. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| ENV-01 | Select target environment | Designer,Operations,Release Operator,Auditor | `GET /api/v1/environment-bindings?env=` | Show redacted refs for selected environment |
| ENV-02 | Inspect binding dependency | Designer,Operations,Release Operator,Auditor | `GET /api/v1/environment-bindings/{key}` | Show reference/type/version/owner not secret value |
| ENV-03 | Validate readiness | Operations,Release Operator | `POST /api/v1/environment-bindings/validate` | Report unresolved refs, ACL/health incompatibility |
| ENV-04 | Request binding change | Operations | `POST /api/v1/environment-bindings/change-requests` | Create controlled binding change request |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### releases: Release Center

**Purpose:** Review signed package and operations-controlled promotion

**Layout:** Package overview + dependency/preflight checklist + approvals + Ops-only gated actions.

**Data contract:** `GET /api/v1/releases`

**Inputs:** candidate version; target environment; change ticket; approval refs

**Roles:** Reviewer,Operations,Release Operator,Auditor

**Empty state:** No release candidates. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| REL-01 | Inspect candidate digest | Reviewer,Operations,Release Operator,Auditor | `GET /api/v1/releases/{id}` | Show diff, exact package digest and pinned deps |
| REL-02 | Run preflight | Reviewer,Operations,Release Operator | `POST /api/v1/releases/{id}/preflight` | Show signed evidence, approvals, bindings, health and tests |
| REL-03 | Request UAT promotion | Release Operator | `POST /api/v1/releases/{id}/promote?target=UAT` | Stage exact digest for approved UAT pipeline |
| REL-04 | Inspect approvals | Reviewer,Operations,Release Operator,Auditor | `GET /api/v1/releases/{id}/approvals` | Show authoritative approval evidence, not ticket string only |
| REL-05 | Activate PROD (gated) | Release Operator | `POST /api/v1/releases/{id}/activate?target=PROD` | Only real backend controls can authorize; demo always blocked |
| REL-07 | Build immutable release candidate | Reviewer,Operations | `POST /api/v1/releases/candidates` | Bundle published BPMN, AMIE and operation lock into signed candidate digest |
| REL-06 | Rollback for NEW runs (gated) | Release Operator | `POST /api/v1/releases/{id}/rollback` | Select previously approved digest for future runs only |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### business: Business Work Queue

**Purpose:** User-scoped batch counts and outcome reports

**Layout:** My batches table + summary counters + progress + paged row reasons and report.

**Data contract:** `GET /api/v1/batches?scope=mine`

**Inputs:** batch selection; CSV fixture; status filter

**Roles:** Business User,Designer,Operations,Auditor

**Empty state:** No authorized batches. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| BUS-01 | Start CSV request (mock) | Business User,Designer | `POST /api/v1/workflows/DCMS.Batch/runs` | Create mock batch with batch number, row GUIDs and queued state |
| BUS-02 | Select batch | Business User,Designer,Operations,Auditor | `GET /api/v1/batches/{id}/summary` | Show selected batch counts by status |
| BUS-03 | Refresh progress | Business User,Designer,Operations,Auditor | `GET /api/v1/batches/{id}/summary` | Refresh from source; show last-updated timestamp |
| BUS-04 | View outcome reasons | Business User,Designer,Operations,Auditor | `GET /api/v1/batches/{id}/rows` | Show paged per-row reason codes with classification mask |
| BUS-05 | Open report | Business User,Designer,Operations,Auditor | `GET /api/v1/batches/{id}/reports` | Show generated secure report refs only when terminal |
| BUS-06 | Advance fixture 5 rows | Business User,Designer,Operations | `mock only (no production API)` | Advance simulated queue safely and counts reconcile |
| BUS-07 | Technical run (authorized) | Operations,Designer,Auditor | `GET /api/v1/runs/{runId}` | Open BPMN overlay and correlation evidence |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### runs: BPMN Run Monitor

**Purpose:** Near-real-time task overlay and correlated timeline

**Layout:** Version-pinned BPMN overlay + activity inspector + correlated event timeline.

**Data contract:** `GET /api/v1/runs/{id}; GET /api/v1/runs/{id}/events`

**Inputs:** run selector; event filter; activity ID

**Roles:** Operations,Designer,Auditor

**Empty state:** No run in permitted scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| RUN-01 | Choose run | Operations,Designer,Auditor | `GET /api/v1/runs/{id}` | Load pinned BPMN version and activity states |
| RUN-02 | Inspect activity | Operations,Designer,Auditor | `GET /api/v1/runs/{id}/activities/{activityId}` | Show task inputs redacted, handler/rule/correlation/outcome |
| RUN-03 | Filter event timeline | Operations,Designer,Auditor | `GET /api/v1/runs/{id}/events?type=` | Filter event types while preserving sequence |
| RUN-04 | Refresh now | Operations,Designer,Auditor | `GET /api/v1/runs/{id}/events?after=` | Query authoritative state after push/reconnect |
| RUN-05 | Open Operator Console | Operations | `GET /api/v1/runs/{id}/controls` | Show authorized state transitions |
| RUN-07 | Inspect correlated Kafka event | Operations,Designer,Auditor | `GET /api/v1/runs/{id}/events/{eventId}` | Show command/outcome envelope metadata, message IDs and safe result |
| RUN-06 | Open audit history | Operations,Designer,Auditor | `GET /api/v1/audit?runId=` | Open filtered immutable evidence |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### operators: Operator Console

**Purpose:** Privileged checkpoint-safe process controls

**Layout:** Selected run/status + allowed transition controls + reason/runbook + status feedback.

**Data contract:** `GET /api/v1/runs/{id}/controls`

**Inputs:** run selector; reason; expected run revision

**Roles:** Operations

**Empty state:** No operable runs. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| CTL-01 | Select run | Operations | `GET /api/v1/runs/{id}/controls` | Show current state, revision and allowed actions |
| CTL-02 | Pause | Operations | `POST /api/v1/runs/{id}/pause` | Running -> PauseRequested -> Paused at safe checkpoint |
| CTL-03 | Resume | Operations | `POST /api/v1/runs/{id}/resume` | Paused -> Running, pins checked |
| CTL-04 | Cancel | Operations | `POST /api/v1/runs/{id}/cancel` | Request cooperative cancellation with linked evidence |
| CTL-05 | Retry failed step | Operations | `POST /api/v1/runs/{id}/retry` | Reconcile before retry; increment attempt |
| CTL-06 | Restart as new run | Operations | `POST /api/v1/runs/{id}/restart` | New linked run ID; old run remains intact |
| CTL-07 | Read controlling runbook | Operations | `GET /api/v1/runbooks/by-run/{id}` | Open procedures and control owner |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### runbooks: Controls and Runbooks

**Purpose:** Read operational procedures and evidence requirements

**Layout:** Control/runbook list + versioned procedure + evidence and acknowledgement.

**Data contract:** `GET /api/v1/runbooks`

**Inputs:** runbook selection; control ID; version

**Roles:** Operations,Auditor,Reviewer

**Empty state:** No runbooks assigned. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| RB-01 | Select runbook | Operations,Auditor,Reviewer | `GET /api/v1/runbooks/{id}/versions/{v}` | Open read-only procedure and version |
| RB-02 | View procedure and exceptions | Operations,Auditor,Reviewer | `GET /api/v1/runbooks/{id}` | Show what to do, when to stop, escalation, owner |
| RB-03 | Acknowledge procedure | Operations | `POST /api/v1/runbooks/{id}/ack` | Record operator acknowledgement when required |
| RB-04 | View related control evidence | Operations,Auditor,Reviewer | `GET /api/v1/audit?controlId=` | Open control-specific audit events |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### access: Role and Scope Policies

**Purpose:** View permissions and test actual denial paths

**Layout:** Role-by-action matrix + scope filter + denial test record.

**Data contract:** `GET /api/v1/access/policies`

**Inputs:** selected application; permission query

**Roles:** Operations,Reviewer,Auditor

**Empty state:** No policies in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| ACC-01 | Inspect role-policy matrix | Operations,Reviewer,Auditor | `GET /api/v1/access/policies` | Show action, role, scope, separation requirements |
| ACC-02 | Test denied API fixture | Operations,Reviewer | `POST /api/v1/test/authorization/denial` | Show isolated negative API test contract |
| ACC-03 | Request policy change | Operations | `POST /api/v1/access/change-requests` | Open controlled policy change request |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### audit: Audit and Traceability

**Purpose:** Reconstruct what ran and who changed it

**Layout:** Filter/search bar + immutable chronological event list + safe detail/export.

**Data contract:** `GET /api/v1/audit`

**Inputs:** runId; batchId; changeId; actor; timeframe

**Roles:** Operations,Auditor,Reviewer

**Empty state:** No events in scope. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| AUD-01 | Search evidence | Operations,Auditor,Reviewer | `GET /api/v1/audit?run=&batch=&change=` | Filtered append-only timeline, stable order |
| AUD-02 | Inspect event detail | Operations,Auditor,Reviewer | `GET /api/v1/audit/{eventId}` | Show actor, versions, UTC, correlation, safe result |
| AUD-03 | Export scoped evidence (mock) | Auditor | `POST /api/v1/audit/exports` | Create redacted, traceable export request |
| AUD-04 | Follow run correlation | Operations,Auditor | `GET /api/v1/runs/{id}` | Open technical run view at matching correlation |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---

### apitests: API Functional Regression

**Purpose:** Plan and review API-first test gates

**Layout:** Suite selector + regression cases + environment gate + evidence/result panel.

**Data contract:** `GET /api/v1/regression/suites`

**Inputs:** suite selector; environment; fixture

**Roles:** Designer,Capability Owner,Operations,Reviewer,Auditor

**Empty state:** No test suites available. **Loading:** Skeleton/list loading state. **Errors:** Show structured API error with correlation ID.

| Control | Button/interaction | Role | API call | Immediate visible result |
|---|---|---|---|---|
| TST-01 | Select suite | Designer,Capability Owner,Operations,Reviewer,Auditor | `GET /api/v1/regression/suites/{id}` | Show cases and required environment/fixture |
| TST-02 | Preview test plan | Designer,Capability Owner,Operations,Reviewer,Auditor | `GET /api/v1/regression/suites/{id}/cases` | Show positive, denied, failure injection cases |
| TST-03 | Run mock fixture test | Designer,Capability Owner,Operations | `POST /api/v1/regression/runs (nonprod only)` | Simulate test results with explicit MOCK marker |
| TST-04 | Inspect failed case | Designer,Capability Owner,Operations,Reviewer,Auditor | `GET /api/v1/regression/runs/{id}/cases/{caseId}` | Show assertion, expected and actual, evidence ref |
| TST-05 | Open DEVIN job index | Designer,Capability Owner,Operations,Reviewer,Auditor | `local docs/jobs/INDEX.md` | Show relevant workstream and acceptance mapping |

**Keyboard/accessibility:** All actions reachable by keyboard; focus moves to created item/modal; validation summary links to element or field. All status is textual in addition to color; error code/correlation remains copyable.

---


<!-- END SOURCE 082: docs/ui/07-SCREEN-BY-SCREEN-WIREFRAMES.md -->

---

<!-- BEGIN SOURCE 083: docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 08 - Click-by-Click Action Contract Catalog

Canonical source `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. All 107 controls in this table have an implemented *mock* handler in `wireframes/Unity_BE_Clickable_Wireframes_v1.0.html`. The prototype does not execute backend work.

## Binding rule for all controls

On click: 1) require correct role/resource scope; 2) validate field inputs; 3) call designated API with correlation and expected revision for mutation; 4) display pending state for async requests; 5) confirm from backend response; 6) surface structured error; 7) record indicated audit event; 8) preserve selection. In the HTML prototype, these outcomes are visibly simulated and permissions are not security enforcement.

## Unity Workbench

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **WB-01** Browse capabilities | `GET /api/v1/capabilities` | Designer,Capability Owner,Operations,Auditor | Open registry scoped to current role | 403 or no authorized capabilities | Read view only |
| **WB-02** Open Application Studio | `GET /api/v1/applications` | Designer,Reviewer,Operations | Open assigned application configurations | 403 if not owner or delegated | Read view only |
| **WB-03** My work | `GET /api/v1/batches?scope=mine` | All authenticated users | Open authorized batch list | No work in permitted scope | Read view only |
| **WB-04** Refresh status | `GET /api/v1/me/dashboard` | All authenticated users | Reload counts and last-updated time | Retain stale-data warning and correlation ID | Read view only |

## Capability Registry

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **CAT-01** Search / filter | `GET /api/v1/capabilities?q=&status=` | Designer,Capability Owner,Operations,Auditor | Table is filtered without altering registry | Return empty state with clear filters | Read view only |
| **CAT-02** Inspect operation | `GET /api/v1/operations/{key}/versions/{version}` | Designer,Capability Owner,Operations,Auditor | Open descriptor inspector at exact contract version | Unavailable/unauthorized contract shows status | Read view only |
| **CAT-03** Use in workflow | `POST /api/v1/workflow-drafts/{id}/activities` | Designer | Insert bound service task with stable key/version | No writable draft or unavailable op -> block | WorkflowDraftActivityAdded |
| **CAT-04** Refresh health | `GET /api/v1/capabilities/{key}/readiness` | Designer,Capability Owner,Operations,Auditor | Fetch current readiness and compatibility | Mark unknown/unavailable, never assume available | Read view only |

## Operation Inspector

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **OP-01** Back to Registry | `GET /api/v1/capabilities` | Designer,Capability Owner,Operations,Auditor | Return to same catalog filters | Retain prior selection | Read view only |
| **OP-02** View input/output schemas | `GET /api/v1/operations/{key}/schemas` | Designer,Capability Owner,Operations,Auditor | Show required inputs, outputs, permissions and side effects | Missing schema blocks binding | Read view only |
| **OP-03** Test with DEV fixture | `POST /api/v1/operation-tests/{key}/execute` | Capability Owner,Designer | Non-PROD fixture result with reason/correlation shown | PROD/live writes forbidden; invalid fixture rejected | OperationTestAttempt |
| **OP-04** Add to BOB workflow | `POST /api/v1/workflow-drafts/{id}/activities` | Designer | Append service task using selected descriptor | Draft not owned/contract unavailable | WorkflowDraftActivityAdded |
| **OP-06** Download contract manifest | `GET /api/v1/operations/{key}/manifest` | Designer,Capability Owner,Operations,Auditor | Download approved manifest with schema refs but no secrets | Unknown/unapproved contract -> deny export | OperationManifestDownloaded |
| **OP-05** Request missing primitive | `POST /api/v1/operation-development-requests` | Designer,Capability Owner | Generate typed DEVIN operation request, not code execution | Missing owner/schema or permission blocks submit | OperationDevelopmentRequested |

## Capability Onboarding

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **ON-01** Create manifest draft | `POST /api/v1/capability-manifests/drafts` | Capability Owner | Create local metadata draft; no executable registration yet | Missing service owner/key -> 422 | ManifestDraftCreated |
| **ON-02** Add operation declaration | `POST /api/v1/capability-manifests/drafts/{id}/operations` | Capability Owner | Attach typed operation metadata to draft | Duplicate key/version or schema missing | ManifestDraftChanged |
| **ON-03** Validate manifest | `POST /api/v1/capability-manifests/drafts/{id}/validate` | Capability Owner,Reviewer | Display schema/security/version checks | Invalid input/scope fails with field code | ManifestValidation |
| **ON-04** Submit service release evidence | `POST /api/v1/capability-manifests/drafts/{id}/submit` | Capability Owner | Send draft for privileged review, not auto-approve | CI digest/code-release evidence missing | ManifestSubmitted |
| **ON-05** Approve registry publication | `POST /api/v1/capability-manifests/{id}/approve` | Reviewer | Approve compatible manifest; no auto handler creation | Cannot self-approve; missing release proof | ManifestApproved |
| **ON-06** Check deployed readiness | `GET /api/v1/capability-manifests/{id}/readiness` | Capability Owner,Reviewer,Operations | Show registered vs actually available separately | Unhealthy/unapproved still blocked | Read view only |

## Application Studio

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **APP-01** Create application draft | `POST /api/v1/applications` | Designer | New app blueprint with owner and scope | Owner/scope required | ApplicationDraftCreated |
| **APP-02** Add capability dependency | `POST /api/v1/applications/{id}/capabilities` | Designer | Add stable approved contract dependency | Unavailable contract or incompatible version | ApplicationDependencyAdded |
| **APP-03** Save configuration | `PUT /api/v1/applications/{id}/draft` | Designer | Persist revision and ETag | 409 on concurrent edit | ApplicationDraftSaved |
| **APP-05** Select application module | `GET /api/v1/applications/{id}/modules/{key}` | Designer,Reviewer,Operations | Switch composition tab with selected workflow and capability dependencies | Unknown or unauthorized module -> clear empty state | Read view only |
| **APP-04** Open workflow library | `GET /api/v1/workflow-definitions?application=` | Designer,Reviewer,Operations | Show workflows for selected app | Missing app scope -> 403 | Read view only |

## Workflow Library

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **LIB-01** New draft from template | `POST /api/v1/workflow-drafts` | Designer | Create draft and initial BPMN IDs | No template permission | WorkflowDraftCreated |
| **LIB-02** Open selected version | `GET /api/v1/workflow-definitions/{key}/versions/{version}` | Designer,Reviewer,Operations,Auditor | Open editor if draft or read-only if published | Definition not visible or immutable | Read view only |
| **LIB-03** Compare versions | `GET /api/v1/workflow-definitions/{key}/diff?from=&to=` | Designer,Reviewer,Operations,Auditor | Show BPMN/rules/contracts/change diff | Missing comparison version | Read view only |
| **LIB-04** Clone as new draft | `POST /api/v1/workflow-definitions/{key}/clone` | Designer | New editable version referencing parent | Retired source allowed only under policy | WorkflowDraftCloned |
| **LIB-05** Submit for review | `POST /api/v1/workflow-drafts/{id}/review` | Designer | Draft moves to InReview with ticket and evidence | Validation errors or no change request | WorkflowReviewRequested |
| **LIB-06** Approve version | `POST /api/v1/workflow-reviews/{id}/approve` | Reviewer | Independently approve candidate | Maker/checker or missing tests | WorkflowApproved |
| **LIB-07** Publish immutable version | `POST /api/v1/workflow-definitions/{key}/publish` | Reviewer | Published with digest and pinned dependencies | Unapproved or missing capabilities | WorkflowPublished |
| **LIB-08** Retire selected version | `POST /api/v1/workflow-definitions/{key}/retire` | Operations | Prevent new runs but retain evidence | Active dependency/runs require policy check | WorkflowRetired |

## BOB BPMN Designer

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **DES-01** Add service task | `POST /api/v1/workflow-drafts/{id}/activities` | Designer | New BPMN service task with stable node ID | No approved operation available | DraftActivityAdded |
| **DES-02** Add business rule task | `POST /api/v1/workflow-drafts/{id}/activities` | Designer | New BPMN business-rule task | No AMIE descriptor available | DraftActivityAdded |
| **DES-03** Add exclusive gateway | `POST /api/v1/workflow-drafts/{id}/elements` | Designer | BPMN XOR gateway with branch conditions | Unsupported element/invalid graph | DraftElementAdded |
| **DES-04** Connect selected nodes | `PUT /api/v1/workflow-drafts/{id}/bpmn` | Designer | Directed sequence flow with new ID | Cycle/invalid branch rejected | DraftFlowChanged |
| **DES-05** Bind selected task input | `PUT /api/v1/workflow-drafts/{id}/bindings` | Designer | Typed mapping to input/current row/prior output | Missing source or wrong schema | DraftBindingChanged |
| **DES-06** Save draft | `PUT /api/v1/workflow-drafts/{id}` | Designer | Persist BPMN XML + DI + inspector data with ETag | 409 stale revision, preserve local edits | WorkflowDraftSaved |
| **DES-07** Validate BPMN and contracts | `POST /api/v1/workflow-drafts/{id}/validate` | Designer,Reviewer | Highlight node errors and publish readiness | Unsupported BPMN/AMIE/operation denies publish | WorkflowValidation |
| **DES-08** Preview safe execution | `POST /api/v1/workflow-drafts/{id}/simulate` | Designer | DEV fixture preview with explicit mock label | Real external writes forbidden in preview | WorkflowSimulationRequested |
| **DES-09** Submit workflow review | `POST /api/v1/workflow-drafts/{id}/review` | Designer | Submit validated draft to reviewer | Required ticket/digest/tests missing | WorkflowReviewRequested |
| **DES-10** Import BPMN XML | `POST /api/v1/workflow-drafts/{id}/import` | Designer | Parse BPMN XML + DI and show unsupported elements | Invalid XML or unsupported semantics fail | WorkflowDraftImported |
| **DES-11** Export BPMN XML | `GET /api/v1/workflow-drafts/{id}/export` | Designer,Reviewer,Operations | Download BPMN 2.0 XML with DI/extension refs | Draft not accessible | Read view only |
| **DES-12** Undo edit | `local editor; persist on Save` | Designer | Revert most recent uncommitted canvas edit | Nothing to undo | Read view only |
| **DES-14** Switch central / embedded workflow | `GET /api/v1/workflow-definitions/{key}/execution-contexts` | Designer,Reviewer,Operations | Change designer context, loading pinned central or CyberArk embedded subworkflow | Unavailable embedded definition or host compatibility rejected | Read view only |
| **DES-13** Redo edit | `local editor; persist on Save` | Designer | Reapply reverted canvas edit | Nothing to redo | Read view only |

## AMIE Rule Picker and Binding

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **AMI-01** Select rule version | `GET /api/v1/amie/rules/{key}/versions/{version}` | Designer,Rule Maintainer,Reviewer | Show required facts/decision types | Unavailable version, no implicit latest | Read view only |
| **AMI-02** Map required facts | `PUT /api/v1/workflow-drafts/{id}/rule-bindings` | Designer,Rule Maintainer | Bind typed input facts and output references | Mismatch/missing fact or unauthorized scope | RuleBindingChanged |
| **AMI-03** Preview rule with fixture | `POST /api/v1/amie/rules/{key}/preview` | Designer,Rule Maintainer | Existing AMIE evaluator returns typed safe result | Missing facts or unsafe fixture | RulePreviewed |
| **AMI-04** Save rule binding | `PUT /api/v1/workflow-drafts/{id}/rule-bindings` | Designer,Rule Maintainer | Persist pinned rule version and ETag | Conflict or unpublished rule | RuleBindingSaved |

## Triggers and Forms

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **TRI-01** Choose trigger type | `GET /api/v1/triggers/types` | Designer,Operations | Display manual CSV/API/schedule capabilities and readiness | AutoSys/API not yet implemented -> planned | Read view only |
| **TRI-02** Add required input field | `PUT /api/v1/workflow-drafts/{id}/trigger-schema` | Designer | New typed schema field for BE form | Unsupported data type/duplicate field | TriggerSchemaChanged |
| **TRI-03** Validate sample CSV | `POST /api/v1/ingestion/validate` | Designer,Business User | Return schema/row errors, no live write | Bad extension, oversize, missing cols | UploadValidation |
| **TRI-04** Save trigger mapping | `PUT /api/v1/workflow-drafts/{id}/trigger` | Designer | Persist trigger schema and source adapter ref | Missing owner/scope and unmapped data | TriggerMappingSaved |
| **TRI-05** Open business start form | `GET /api/v1/workflows/{key}/start-form` | Business User,Designer | Open role-scoped start UI | No execute permission | Read view only |

## Kafka Contract Explorer

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **KAF-01** Inspect message schema | `GET /api/v1/messaging/contracts/{key}` | Designer,Capability Owner,Operations,Auditor | Show producer/consumer/required fields/versions | Unknown logical message | Read view only |
| **KAF-02** Validate correlation envelope | `POST /api/v1/messaging/contracts/validate` | Designer,Capability Owner,Operations | Check commandId/runId/activityId/idempotency/partition | Missing required IDs or unapproved schema | MessageContractValidated |
| **KAF-03** Check environment bindings | `GET /api/v1/environment-bindings` | Designer,Capability Owner,Operations | Show approved logical-to-physical resolutions | No approved topic ACL | Read view only |

## Environment Bindings

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **ENV-01** Select target environment | `GET /api/v1/environment-bindings?env=` | Designer,Operations,Release Operator,Auditor | Show redacted refs for selected environment | PROD sensitive values never shown | Read view only |
| **ENV-02** Inspect binding dependency | `GET /api/v1/environment-bindings/{key}` | Designer,Operations,Release Operator,Auditor | Show reference/type/version/owner not secret value | Unauthorized value access denied | Read view only |
| **ENV-03** Validate readiness | `POST /api/v1/environment-bindings/validate` | Operations,Release Operator | Report unresolved refs, ACL/health incompatibility | Missing binding fails preflight | EnvironmentReadinessChecked |
| **ENV-04** Request binding change | `POST /api/v1/environment-bindings/change-requests` | Operations | Create controlled binding change request | Direct PROD edit denied | EnvironmentChangeRequested |

## Release Center

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **REL-01** Inspect candidate digest | `GET /api/v1/releases/{id}` | Reviewer,Operations,Release Operator,Auditor | Show diff, exact package digest and pinned deps | Tampered/missing package -> reject | Read view only |
| **REL-02** Run preflight | `POST /api/v1/releases/{id}/preflight` | Reviewer,Operations,Release Operator | Show signed evidence, approvals, bindings, health and tests | Any control missing => Blocked | ReleasePreflightChecked |
| **REL-03** Request UAT promotion | `POST /api/v1/releases/{id}/promote?target=UAT` | Release Operator | Stage exact digest for approved UAT pipeline | No DEV validation/owner approval | ReleasePromotionRequested |
| **REL-04** Inspect approvals | `GET /api/v1/releases/{id}/approvals` | Reviewer,Operations,Release Operator,Auditor | Show authoritative approval evidence, not ticket string only | Missing approval explicitly shown | Read view only |
| **REL-05** Activate PROD (gated) | `POST /api/v1/releases/{id}/activate?target=PROD` | Release Operator | Only real backend controls can authorize; demo always blocked | No real bank CA/approval; no operation in prototype | ReleaseActivationAttempt |
| **REL-07** Build immutable release candidate | `POST /api/v1/releases/candidates` | Reviewer,Operations | Bundle published BPMN, AMIE and operation lock into signed candidate digest | Unpublished workflow or missing dependency blocks build | ReleaseCandidateCreated |
| **REL-06** Rollback for NEW runs (gated) | `POST /api/v1/releases/{id}/rollback` | Release Operator | Select previously approved digest for future runs only | No hidden rollback of CyberArk side effects | ReleaseRollbackAttempt |

## Business Work Queue

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **BUS-01** Start CSV request (mock) | `POST /api/v1/workflows/DCMS.Batch/runs` | Business User,Designer | Create mock batch with batch number, row GUIDs and queued state | Invalid upload/permission or missing input contract | WorkflowStartRequested |
| **BUS-02** Select batch | `GET /api/v1/batches/{id}/summary` | Business User,Designer,Operations,Auditor | Show selected batch counts by status | Out-of-scope batch invisible | Read view only |
| **BUS-03** Refresh progress | `GET /api/v1/batches/{id}/summary` | Business User,Designer,Operations,Auditor | Refresh from source; show last-updated timestamp | Disconnected stream shows stale status | Read view only |
| **BUS-04** View outcome reasons | `GET /api/v1/batches/{id}/rows` | Business User,Designer,Operations,Auditor | Show paged per-row reason codes with classification mask | No sensitive raw account fields | Read view only |
| **BUS-05** Open report | `GET /api/v1/batches/{id}/reports` | Business User,Designer,Operations,Auditor | Show generated secure report refs only when terminal | Nonterminal batch shows pending report | Read view only |
| **BUS-06** Advance fixture 5 rows | `mock only (no production API)` | Business User,Designer,Operations | Advance simulated queue safely and counts reconcile | Never claim real operation success | DemoFixtureAdvanced |
| **BUS-07** Technical run (authorized) | `GET /api/v1/runs/{runId}` | Operations,Designer,Auditor | Open BPMN overlay and correlation evidence | Business-only user denied | Read view only |

## BPMN Run Monitor

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **RUN-01** Choose run | `GET /api/v1/runs/{id}` | Operations,Designer,Auditor | Load pinned BPMN version and activity states | Unavailable run denied | Read view only |
| **RUN-02** Inspect activity | `GET /api/v1/runs/{id}/activities/{activityId}` | Operations,Designer,Auditor | Show task inputs redacted, handler/rule/correlation/outcome | Protected fields masked | Read view only |
| **RUN-03** Filter event timeline | `GET /api/v1/runs/{id}/events?type=` | Operations,Designer,Auditor | Filter event types while preserving sequence | Empty filter state | Read view only |
| **RUN-04** Refresh now | `GET /api/v1/runs/{id}/events?after=` | Operations,Designer,Auditor | Query authoritative state after push/reconnect | Show stale indicator when unavailable | Read view only |
| **RUN-05** Open Operator Console | `GET /api/v1/runs/{id}/controls` | Operations | Show authorized state transitions | Insufficient control permission | Read view only |
| **RUN-07** Inspect correlated Kafka event | `GET /api/v1/runs/{id}/events/{eventId}` | Operations,Designer,Auditor | Show command/outcome envelope metadata, message IDs and safe result | Missing event or sensitive payload masked | Read view only |
| **RUN-06** Open audit history | `GET /api/v1/audit?runId=` | Operations,Designer,Auditor | Open filtered immutable evidence | Scope-restricted events masked | Read view only |

## Operator Console

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **CTL-01** Select run | `GET /api/v1/runs/{id}/controls` | Operations | Show current state, revision and allowed actions | Unknown run/role denied | Read view only |
| **CTL-02** Pause | `POST /api/v1/runs/{id}/pause` | Operations | Running -> PauseRequested -> Paused at safe checkpoint | Not running, missing reason or stale revision | RunPauseRequested |
| **CTL-03** Resume | `POST /api/v1/runs/{id}/resume` | Operations | Paused -> Running, pins checked | Not paused or missing dependencies | RunResumeRequested |
| **CTL-04** Cancel | `POST /api/v1/runs/{id}/cancel` | Operations | Request cooperative cancellation with linked evidence | Missing reason; may require reconciliation | RunCancelRequested |
| **CTL-05** Retry failed step | `POST /api/v1/runs/{id}/retry` | Operations | Reconcile before retry; increment attempt | Unknown write outcome or incorrect state | RunRetryRequested |
| **CTL-06** Restart as new run | `POST /api/v1/runs/{id}/restart` | Operations | New linked run ID; old run remains intact | Missing authorization/terminal status | RunRestartRequested |
| **CTL-07** Read controlling runbook | `GET /api/v1/runbooks/by-run/{id}` | Operations | Open procedures and control owner | No applicable runbook => block command if required | Read view only |

## Controls and Runbooks

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **RB-01** Select runbook | `GET /api/v1/runbooks/{id}/versions/{v}` | Operations,Auditor,Reviewer | Open read-only procedure and version | Retired version remains readable for history | Read view only |
| **RB-02** View procedure and exceptions | `GET /api/v1/runbooks/{id}` | Operations,Auditor,Reviewer | Show what to do, when to stop, escalation, owner | Missing real CA/control clearly marked | Read view only |
| **RB-03** Acknowledge procedure | `POST /api/v1/runbooks/{id}/ack` | Operations | Record operator acknowledgement when required | Wrong version or role rejected | RunbookAcknowledged |
| **RB-04** View related control evidence | `GET /api/v1/audit?controlId=` | Operations,Auditor,Reviewer | Open control-specific audit events | Scope denied | Read view only |

## Role and Scope Policies

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **ACC-01** Inspect role-policy matrix | `GET /api/v1/access/policies` | Operations,Reviewer,Auditor | Show action, role, scope, separation requirements | No global bypass roles | Read view only |
| **ACC-02** Test denied API fixture | `POST /api/v1/test/authorization/denial` | Operations,Reviewer | Show isolated negative API test contract | Never use PROD write endpoints | SecurityTestExecuted |
| **ACC-03** Request policy change | `POST /api/v1/access/change-requests` | Operations | Open controlled policy change request | No direct role grant in UI | SecurityChangeRequested |

## Audit and Traceability

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **AUD-01** Search evidence | `GET /api/v1/audit?run=&batch=&change=` | Operations,Auditor,Reviewer | Filtered append-only timeline, stable order | Missing filter returns authorized scope only | Read view only |
| **AUD-02** Inspect event detail | `GET /api/v1/audit/{eventId}` | Operations,Auditor,Reviewer | Show actor, versions, UTC, correlation, safe result | Sensitive payloads masked | Read view only |
| **AUD-03** Export scoped evidence (mock) | `POST /api/v1/audit/exports` | Auditor | Create redacted, traceable export request | Unauthorized caller denied; no raw secrets | AuditExportRequested |
| **AUD-04** Follow run correlation | `GET /api/v1/runs/{id}` | Operations,Auditor | Open technical run view at matching correlation | Dangling run reference shown | Read view only |

## API Functional Regression

| ID / action | Proposed endpoint | Authorized role | Success interaction | Invalid/denied path | Audit / evidence |
|---|---|---|---|---|---|
| **TST-01** Select suite | `GET /api/v1/regression/suites/{id}` | Designer,Capability Owner,Operations,Reviewer,Auditor | Show cases and required environment/fixture | Unknown suite | Read view only |
| **TST-02** Preview test plan | `GET /api/v1/regression/suites/{id}/cases` | Designer,Capability Owner,Operations,Reviewer,Auditor | Show positive, denied, failure injection cases | No production test execution | Read view only |
| **TST-03** Run mock fixture test | `POST /api/v1/regression/runs (nonprod only)` | Designer,Capability Owner,Operations | Simulate test results with explicit MOCK marker | No live run, unknown env, or unsafe scenario | RegressionFixtureRun |
| **TST-04** Inspect failed case | `GET /api/v1/regression/runs/{id}/cases/{caseId}` | Designer,Capability Owner,Operations,Reviewer,Auditor | Show assertion, expected and actual, evidence ref | No result yet | Read view only |
| **TST-05** Open DEVIN job index | `local docs/jobs/INDEX.md` | Designer,Capability Owner,Operations,Reviewer,Auditor | Show relevant workstream and acceptance mapping | Document missing -> provide path | Read view only |

## Control wiring implementation rules

- Preserve stable `data-control-id` matching table IDs in Blazor component tests and UI telemetry.
- For filters, the data-source API must apply scope server-side; client-side filtering alone is not sufficient.
- For mutations, a UI confirmation or optimistic immediate badge is not the server state. Wait for durable result or poll status.
- Use business disposition wording in business queue. Technical operation or broker outcomes appear only for authorized roles in run monitor.
- Browser file upload uses approved API with size/type/schema checks and tokenized blob reference; do not send CSV payload in Kafka.
- For actions marked `mock only`, there must be **no** production API counterpart. They exist solely to demonstrate state changes in the static prototype.
- Production activation and rollback remain disabled in the prototype, irrespective of selected persona.


<!-- END SOURCE 083: docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md -->

---

<!-- BEGIN SOURCE 084: docs/ui/09-USER-JOURNEYS-AND-STATE-MACHINES.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 09 - User Journeys and Visible State Transitions

This is the design flow specification for DEVIN. Screen/control IDs correspond to `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. The HTML wireframe simulates the interaction; all durable effects require actual APIs.

## Journey A - Register a new CyberArk primitive once, reuse everywhere

| Step | Persona | Page -> click | Required input / check | UI must show |
|---|---|---|---|---|
| 1 | Capability Owner | Onboarding `ON-01` Create manifest draft | capability key, owner, code-release metadata | New Draft identity and version |
| 2 | Capability Owner | `ON-02` Add operation declaration | `CyberArk.FindAccount` key, typed schemas, policy, side effect, transports | Operation in manifest draft, local validation issues |
| 3 | Capability Owner | `ON-03` Validate manifest | handler exists in compiled release, no duplicate key, sample fixtures | Detailed schema/policy/compatibility result |
| 4 | Capability Owner | `ON-04` Submit service evidence | signed/attested build, CI, source release | InReview; cannot self-approve |
| 5 | Reviewer | `ON-05` Approve manifest | independent owner/release checks | Approved; still not automatically Available |
| 6 | Operations | `ON-06` Check readiness | deployed binary/version, health, Kafka ACL, environment binding | Registered vs Available separately |
| 7 | Designer | Catalog `CAT-01` search, `CAT-02` inspect | application scope, exact operation version | Typed inputs and outputs, permission and host |
| 8 | Designer | Operation `OP-04` add | writable workflow draft | BPMN ServiceTask with operationKey@version |
| 9 | Designer | Designer `DES-05` bind, `DES-07` validate | schema-compatible data source | No unresolved required fields |
| 10 | Designer | AMIE `AMI-01`, `AMI-02`, `AMI-03` | rule version, required facts, sanitized fixture | Typed rule decision and output binding |
| 11 | Designer/Reviewer | `DES-09`, `LIB-06`, `LIB-07` | validation, ticket, maker/checker, immutability | Published version/digest, no post-publish editing |
| 12 | Business User | `BUS-01` execute approved workflow | allowed application/input schema | Run ID/correlation, non-technical summary |
| 13 | Designer | Reuse same registered operation in Hygiene | different AMIE rule / workflow | Second application works without new CyberArk handler |

No new manifest should be required for steps 8-13 if the existing operation contract is sufficient. Creating genuinely missing CyberArk behavior still requires a normal code release and security policy.

## Journey B - DCMS configuration through UI

1. Workbench `WB-02` -> App Studio `APP-01`: configure `DCMS`, owner and scope; `APP-02` add approved Data/CyberArk/Reporting/Email dependencies; `APP-03` save.
2. Library `LIB-01`: create Batch + Sequential Rows BPMN draft.
3. Designer `DES-01` add service tasks: stage data, invoke pinned CyberArk embedded subworkflow, report, send email. `DES-02` add AMIE business rule tasks in embedded workflow, `DES-03` configure exclusive gateway, `DES-04` connect paths. Unsupported BPMN elements must yield a semantic error, not run silently.
4. Operation inspector `OP-02` verifies typed fields and side effects. Designer `DES-05` binds `CurrentItem`, prior output and AMIE rule result to operation inputs; `DES-06` saves XML+DI.
5. AMIE `AMI-01` select rule version, `AMI-02` bind required facts (CSV values, account and platform), `AMI-03` preview on fixture, `AMI-04` save binding.
6. Triggers `TRI-01` choose Manual CSV (future API/AutoSys displayed as unavailable), `TRI-02` define columns, `TRI-03` validate safe sample, `TRI-04` save trigger.
7. Kafka Contracts `KAF-01` inspect command/outcome schema, `KAF-02` verify correlation/idempotency; Environment Bindings `ENV-01/03` confirm allowed DEV topic/endpoint/secret references, never values.
8. Designer `DES-07` validates BPMN, AMIE, contracts and permissions; `DES-08` previews fixture; `DES-09` submits. Library `LIB-06/07` approves/publishes only after back-end evidence.
9. Release `REL-01/02` checks digest, tests, binding, ServiceNow evidence; `REL-03` requests controlled UAT. `REL-05` PROD activation must be actually denied in wireframe and cannot be assumed approved in real code.
10. Business `BUS-01` uploads approved CSV/starts batch. Data stage creates one batch number and unique GUID per row; central BOB sends Kafka command. Embedded BOB/AMIE process rows sequentially and persist actual outcomes. `BUS-03/04/05` show status/reasons/report, `BUS-07` opens technical monitor only for authorized role. Audit `AUD-01/02` reconstructs decisions, operations and change references.

## Journey C - Business user with minimal technical privileges

- On Workbench `WB-03` open My Work; Business `BUS-01` starts approved request only for owned app; `BUS-02/03` select and refresh batch; `BUS-04` read row failures with safe reason codes; `BUS-05` access report only when prepared.
- `BUS-07` technical monitor is not available unless an explicit additional role is granted. User never sees raw account passwords, broker topic internals, API authorization tokens or other batches.
- Distinguish `Pending/InProgress` from terminal `Succeeded/NoChange/Skipped/Rejected/Failed`. Unknown external outcome is not success and cannot be counted as a confirmed completed update.

## Journey D - Operator handling an in-flight CyberArk write

1. Operations opens Run Monitor `RUN-01` and `RUN-02` to inspect current task/evidence; `RUN-05` opens controls.
2. Operator selects a running run `CTL-01`, enters reason, clicks `CTL-02 Pause` with expected revision.
3. API returns 202/accepted and UI shows `PauseRequested`; **do not show Paused** until durable checkpoint reached. If write is still in flight, external outcome must be confirmed or reconciled first.
4. Run Monitor `RUN-04` refresh/push eventually shows `Paused` and exact waiting activity.
5. Operator reviews `RB-02` runbook, then `CTL-03 Resume` with reason and new revision. UI shows Running only after backend confirms.
6. For Failed external write, `CTL-05 Retry` is permitted only if prior outcome is known or reconciliation has completed; otherwise deny with `RECONCILIATION_REQUIRED`.
7. For Cancel `CTL-04`, UI shows CancelRequested while in-flight work settles. Restart `CTL-06` creates a **new RunId** and links original history, no deletion.
8. Audit `AUD-01/02` must show each control action, actor, reason, expected revision, result and UTC time.

## Journey E - Operations-only production promotion

1. Reviewer/Operations chooses exact candidate `REL-01` and checks manifest/rule/operation lock/digest.
2. `REL-02` preflight checks real controls/CA requirements, signed artifact, tests, UAT digest, service health and logical bindings; **a typed change ticket is not approval**.
3. Authorized Release Operator `REL-03` promotes identical artifact to UAT and records approver/evidence.
4. On PROD, `REL-05` is authorized only if server-side bank policy passes and Operations identity is allowed. This mock ALWAYS blocks it.
5. Rollback `REL-06` selects previously approved package **for new runs**; previous CyberArk writes are not undone.

## State machines used by the UI

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> InReview: Submit (valid + ticket)
  InReview --> Approved: Independent review
  Approved --> Published: Immutable package
  Published --> Active: Operations activates
  Active --> Retired: Retire for new runs
  Published --> Retired
  InReview --> Draft: Request changes
```

```mermaid
stateDiagram-v2
  [*] --> Running
  Running --> PauseRequested: Pause API accepted
  PauseRequested --> Paused: Safe checkpoint confirmed
  Paused --> Running: Resume confirmed
  Running --> CancelRequested: Cancel API accepted
  Paused --> CancelRequested: Cancel API accepted
  CancelRequested --> Cancelled: Known/settled state
  Running --> Failed
  Running --> Completed
  Failed --> Running: Safe retry after reconciliation
  Failed --> RestartedLink: New run with distinct ID
  Cancelled --> RestartedLink: New run with distinct ID
  Completed --> RestartedLink: New run with distinct ID
```

## User-visible error policy

- Permission denied: show requested action not authorized, no sensitive resource names. Log denial; direct API 403 test required.
- Validation error: show field/node ID, code and remediation; preserve unsaved draft.
- Revision conflict: show server and local revision, offer controlled reload/diff; never silently overwrite.
- Request accepted/pending: show pending with correlation; do not treat transport acknowledgement as side-effect success.
- Dependency unavailable: show exact logical dependency/version/health with no secret values, block publish or execution as applicable.
- Unknown external outcome: preserve visible reconciliation-required state, never count as success or restart blindly.

<!-- END SOURCE 084: docs/ui/09-USER-JOURNEYS-AND-STATE-MACHINES.md -->

---

<!-- BEGIN SOURCE 085: docs/ui/10-BLAZOR-WIREFRAME-IMPLEMENTATION.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 10 - Translating Wireframes to Blazor Implementation

## 1. Baseline and sources

- Previous v0.7 browser prototype is visual inspiration; `wireframes/Unity_BE_Clickable_Wireframes_v1.0.html` is the actionable **behavior model** with stable 107 action IDs, simulated role switching and state changes.
- Existing Blazor solution/routers/services must be discovered in JOB-00. The file paths below are **proposed** component boundaries, not current source tree.
- Backend contract spec: `docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md` and `wireframes/UI_CONTROL_REGISTRY_v1.0.json`.

## 2. Component decomposition (proposed paths)

| Path | Responsibility | Test boundary |
|---|---|---|
| `/BusinessEnablement/Components/Layout/UnityShell.razor` | Nav, app/env context, role-scoped current user, status/error region | Route access not granted by hiding |
| `/BusinessEnablement/Components/Capabilities/CapabilityCatalog.razor` | Search, filter, readiness, scoped registry records | CAT-01 to CAT-04 |
| `/BusinessEnablement/Components/Capabilities/OperationInspector.razor` | schema-derived inputs, output, host, permission, test & add | OP-01 to OP-05 |
| `/BusinessEnablement/Components/Capabilities/CapabilityOnboarding.razor` | metadata draft + validation + approval status | ON-01 to ON-06 |
| `/BusinessEnablement/Components/Applications/ApplicationStudio.razor` | select app, deps and role scope | APP-01 to APP-04 |
| `/BusinessEnablement/Components/Workflows/WorkflowLibrary.razor` | template/version lifecycle and diff | LIB-01 to LIB-08 |
| `/BusinessEnablement/Components/Workflows/BpmnDesigner.razor` | visual SVG canvas and BPMN DI/typed binding model | DES-01 to DES-13 |
| `/BusinessEnablement/wwwroot/js/bpmnCanvas.js` | small reviewed JS module for high-rate drag/pan/zoom gestures | commits only through Blazor interop |
| `/BusinessEnablement/Components/Rules/AmieBindingInspector.razor` | rules and typed facts, sample preview | AMI-01 to AMI-04 |
| `/BusinessEnablement/Components/Triggers/TriggerEditor.razor` | schema-driven start forms, CSV source, future adapters | TRI-01 to TRI-05 |
| `/BusinessEnablement/Components/Messaging/ContractExplorer.razor` | logical topic/envelope, redacted bindings | KAF-01 to KAF-03 |
| `/BusinessEnablement/Components/Release/EnvironmentBindings.razor` | approved refs, readiness; no secret values | ENV-01 to ENV-04 |
| `/BusinessEnablement/Components/Release/ReleaseCenter.razor` | digest, approvals, UAT/prod gates | REL-01 to REL-06 |
| `/BusinessEnablement/Components/Business/BatchQueue.razor` | scoped business counts and reasons | BUS-01 to BUS-07 |
| `/BusinessEnablement/Components/Monitoring/RunMonitor.razor` | pinned BPMN overlay, activity details, events | RUN-01 to RUN-06 |
| `/BusinessEnablement/Components/Monitoring/OperatorConsole.razor` | safe process controls, reason/runbook | CTL-01 to CTL-07 |
| `/BusinessEnablement/Components/Controls/RunbookLibrary.razor` | operational procedures and evidence | RB-01 to RB-04 |
| `/BusinessEnablement/Components/Security/AccessPolicies.razor` | read-only role/scope views and policy requests | ACC-01 to ACC-03 |
| `/BusinessEnablement/Components/Audit/AuditExplorer.razor` | append-only event query/export | AUD-01 to AUD-04 |
| `/BusinessEnablement/Components/Tests/ApiRegression.razor` | read CI test evidence and suites | TST-01 to TST-05 |
| `/BusinessEnablement/Services/UnityApiClient.cs` | Typed HTTP clients to real API endpoints | bearer policy and status mapping |
| `/BusinessEnablement/Components/Shared/UiActionState.razor` | loading, pending, errors, revision conflict and correlation | reusable status behavior |

Adjust paths to actual `DashboardApp-main`/Blazor project layout if existing; do not accidentally create a second BE app. Use existing FluentValidation convention if available and approved.

## 3. BPMN canvas architecture

- Maintain one in-memory editor document (BPMN graph + BPMN DI geometry + Unity extension references). No dual hidden "diagram JSON" that drifts from BPMN XML.
- JS owns pointermove, drag preview, connect preview, snap guides, pan/zoom; Blazor owns authoritative graph, validation, selection, dialog state and saves. JS calls Blazor with **committed** actions, not every mouse pixel.
- Palette restricts initial supported executable elements. Unsupported elements imported from external BPMN remain visible with an explicit validation error; never silently drop them.
- Right inspector loads manifest/rule JSON Schema and pins versions. Bindings are typed references, not arbitrary expressions.
- Undo/redo affects editor draft history only, never deployed workflow/production run state. Save requires revision/ETag. Import/export must retain BPMN IDs/DI and generated extension elements; roundtrip tests mandatory.
- Provide keyboard accessible list/table alternative for selected nodes and connections; diagram color is not sole indicator.

## 4. API-first client state

Blazor UI calls typed HTTP endpoints; it must not access BOB MSSQL tables, invoke AMIE directly from browser, or subscribe to Kafka. For longer operations, API responds 202 with operation ID, and UI awaits authoritative status. For near-real-time: server-side projection -> authorized SignalR/SSE -> UI event; reconnect triggers GET snapshot to correct missed updates. Use ETag for drafts/control actions; 409 conflicts preserve user edits.

## 5. Form and data handling

- Data-driven field components derive from approved input schemas and UI hints. Validate required data in UI for UX and on backend for security.
- CSV upload: inspect file metadata and size, upload via authorized backend, receive signed/ref token; do not put CSV contents in messages.
- No secret values, password fields, raw sensitive account JSON, auth tokens or unrestricted endpoints in wireframe, telemetry, log or audit export.
- Show exact business row statuses separately from technical BPMN status. Terminal count definitions are documented in DCMS spec.

## 6. Visual and interaction details per control

Every button includes stable `data-control-id` from registry, matching automated test selector. Disabled buttons explain permission/state and preserve keyboard context. Modal/drawer focus is trapped and restored. Before mutation show required reason, change ticket or required input. Pending state is not success. Show service error code and correlation ID with safe message. Support loading/empty/error/permission denied states for every screen as documented in UI 07. Names and UI text must be reviewed against actual bank conventions.

## 7. Done means proven by API and UI

- Screens render data from real, authenticated backend (not hardcoded fixture) in DEV; mock-only UI is not completion.
- Each control's positive and negative API test passes; backend enforces scope independent of button state.
- BPMN canvas design -> save -> reload -> import/export -> compile -> execute works for approved subset.
- SDK-registered operation appears dynamically with schema; AMIE rule output maps to handler input; no CyberArk-specific Razor form coding.
- Business counts match staged row outcomes; tech monitor reconstructs run and audit; pause/resume correctly follows safe checkpoint.
- Production controls remain blocked unless real bank approval is proven. No accessibility-blocking keyboard issues or JS console exceptions.

<!-- END SOURCE 085: docs/ui/10-BLAZOR-WIREFRAME-IMPLEMENTATION.md -->

---

<!-- BEGIN SOURCE 086: docs/ui/11-UI-API-ACCEPTANCE-SCRIPTS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 11 - Automated Functional / Visual Acceptance Scripts

Each step references the stable `data-control-id` and backend route in `wireframes/UI_CONTROL_REGISTRY_v1.0.json`. Use Blazor component/bUnit tests (if approved), Playwright E2E, HTTP contract tests and direct worker tests. This is an acceptance plan, not evidence of execution against Unity.

## Scenario UI-E2E-01 - Operation registration and schema-driven use

**Given** trusted CyberArk handler and deployment release fixture; **when** Capability Owner uses ON-01/02/03/04; Reviewer uses ON-05; Operations checks ON-06; Designer opens CAT-02/OP-02/OP-04; **then** typed input fields render from manifest, version pins, and handler can be inserted into BPMN without a new editor component. **Negative:** duplicate key, untrusted publisher, unavailable service, missing permission all deny; direct API 403 also tested.

## Scenario UI-E2E-02 - BPMN drafting and AMIE wiring

**Given** a writable DCMS Draft and approved manifest/rule; **when** Designer creates service task DES-01, rule DES-02, gateway DES-03, connects flows DES-04, binds required input DES-05, saves DES-06, validates DES-07, and previews DES-08; **then** visible graph IDs, DI geometry, typed binding and rule outcomes persist after reload; compiler reports no errors and fixture cannot write to PROD. **Negative:** type mismatch, missing fact, unsupported BPMN, stale ETag, inaccessible rule version; error anchored to node.

## Scenario UI-E2E-03 - Workflow lifecycle and exact release

**Given** valid draft with exact operation/rule versions; **when** author submits LIB-05, independent reviewer approves LIB-06, publishes LIB-07, release operator runs REL-02 and requests UAT REL-03; **then** package digest immutable and target bindings safe. **Negative:** self approval, ticket without real CA, altered package bytes, missing service manifest, developer PROD attempt; REL-05 must remain blocked in wireframe.

## Scenario UI-E2E-04 - User CSV and business progress

**Given** assigned Business User; **when** TRI-03 validates CSV, BUS-01 starts DCMS, BUS-03 refreshes, BUS-04 reads outcome reasons, BUS-05 opens report; **then** staged batch number and row GUIDs are unique, records remain scoped, counts reconcile, final report includes reasons and email result separate from account writes. **Negative:** invalid CSV, duplicate uploaded batch, another user's batch ID, report before terminal, no raw CSV in Kafka.

## Scenario UI-E2E-05 - Operator control and audit

**Given** a running workflow with an in-flight external CyberArk write; **when** Operations opens RUN-05, provides reason and clicks CTL-02, and later CTL-03 or CTL-04; **then** UI shows PauseRequested until safe checkpoint, authoritative state on refresh, and immutable evidence for actor/reason/time/revision. **Negative:** no reason, unauthorized user, concurrent revision, unknown prior write, cancel requested during unsettled write, restart reuses old ID.

## Scenario UI-E2E-06 - Audit and regression

**Given** a test batch and known correlation; **when** Auditor searches AUD-01, inspects AUD-02, exports AUD-03; **then** sequence can be reconstructed, sensitive fields redacted, export event recorded. API regression suite TST-01/02/03 runs isolated tests only; UI test result is not proof that CI ran.

## Browser and accessibility checks

- Every authorized `data-control-id` can be activated by pointer and keyboard; no handler throws JS exception.
- Screen titles, status live region, error summary, confirm modals, focus restoration and text-based diagram status work.
- Navigation grants no additional resource scope. Denied screen should not reveal data when direct API called.
- Resize to 1280x800, 768x1074 and 390x844; major controls remain operable and data table scroll/paginates.
- No secrets in URL/query/body logging, DOM snapshots, downloadable mock results or audit export.
- Check reconnection from disconnected signal: GET authoritative snapshot, no ghost completed state.

## Explicit success evidence for DEVIN PR

Provide screenshots before/after, video only if useful, per-control test pass/fail, API request/response with redaction, CI job URL, contract/schema diff, DB evidence and actual file summary. Do not claim mock images are functional delivery.

<!-- END SOURCE 086: docs/ui/11-UI-API-ACCEPTANCE-SCRIPTS.md -->

---

<!-- BEGIN SOURCE 087: docs/ui/12-PREVIOUS-PROTOTYPE-CONTROL-CROSSWALK.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 12 - Preserve Earlier v0.6/v0.7 Prototype Click Behavior

Source: earlier user-approved visual prototypes `Unity_BE_Capability_Composer_Prototype_v0.6.html` and `Unity_BE_Prototype_v0.7.html`. These are **concept prototypes**, not backend code. Original files are preserved in the separate COMPLETE archive. This crosswalk prevents dropping a visible earlier interaction when building v1.0 Blazor UI.

## Original prototype control -> version 1.0 contract

| v0.6/v0.7 `data-action` | v1.0 action ID | Behavior to preserve |
|---|---|---|
| `add-component` | APP-02, DES-01 | Add approved reusable module or service task; do not generate new CyberArk code |
| `add-node` | DES-01 / DES-02 / DES-03 | Insert supported BPMN element with stable ID, save and validate |
| `build-candidate` | REL-07 | Build immutable package with pinned dependencies only from published workflow |
| `check-bindings` | ENV-03 | Readiness for topic/endpoint/secret refs and service compatibility |
| `close-modal` | UI local close | Close with focus return; no backend mutation |
| `designer-scope` | DES-14 | Switch between central BOB process and embedded CyberArk subworkflow |
| `download-manifest` | OP-06 | Export approved operation schema/manifest without credentials |
| `edit-composition` | APP-03, APP-05 | Select app module, edit and save configuration revision |
| `evaluate-rule` | AMI-03 | Preview existing AMIE evaluation in safe DEV fixture |
| `export-draft` | DES-11 | Export BPMN 2.0 XML + DI and Unity references |
| `open-capability` | CAT-02 | Open capability/operation inspector for exact version |
| `open-embedded` | DES-14 | Display embedded BOB subworkflow with its local handler sequence |
| `open-run-event` | RUN-07 | Inspect event contract IDs, safe outcome and broker correlation |
| `preview-prod` | REL-02, REL-05 | Preflight display and hard production gate; mock must never activate |
| `save-demo-draft` | DES-06 | Persist a versioned draft, ETag, safe conflict handling (mock saves locally) |
| `save-rule` | AMI-04 | Save pinned rule binding; does not modify AMIE core code |
| `select-module` | APP-05 | Switch application module/version without losing state |
| `select-operation` | OP-02 | Select exact operation, inspect typed schema and permissions |
| `select-rule` | AMI-01 | Choose existing AMIE rule by key and version |
| `stage-uat` | REL-03 | Operations-controlled UAT staging of exact package digest |
| `use-operation` | OP-04, CAT-03 | Insert operation into authorized BPMN draft |
| `v7-control` | CTL-02..CTL-06 | Pause/resume/cancel/retry/restart safe run-state transitions |
| `v7-inspect-workflow` | LIB-02 / LIB-03 | Open historical version and change diff |
| `v7-report` | BUS-04 / BUS-05 | Show paginated row reasons and secured report |
| `v7-runbook` | RB-02 | View controlling procedure and exception steps |
| `v7-select-batch` | BUS-02 | Select business batch scoped to current user |
| `v7-select-run` | RUN-01 / CTL-01 | Select technical execution and control permissions |
| `v7-start-mock` | BUS-01 | Authorized business start with data requirements and batch reference |
| `v7-tech-run` | BUS-07 | Move business user to technical monitor **only if authorized** |
| `v7-tests` | TST-02 / TST-03 | Inspect API regression plan and run isolated fixture (mock) |
| `v7-topic` | KAF-01 | Inspect logical Kafka contract/schema and message flow |
| `validate-descriptor` | ON-03 | Validate declared service handler metadata and schemas |
| `validate-workflow` | DES-07 | Backend BPMN + operation/AMIE binding validation |

All 33 distinct old `data-action` tokens have a v1.0 disposition above. The old navigation group is mapped to the 19 current routes; Operation Inspector is now a distinct screen. Buttons marked `mock` in earlier prototypes do not become production behaviors without implementing, securing and testing their corresponding real API.

## Blazor acceptance for prototype preservation

Run `wireframes/validate_clickability.py`: all 107 current action IDs must render and trigger a meaningful mock state, validation error or information modal with no JavaScript exceptions. This is UI-behavior smoke evidence **only**. Complete each backend action with `docs/ui/08-CLICK-BY-CLICK-ACTION-CATALOG.md` and `docs/ui/11-UI-API-ACCEPTANCE-SCRIPTS.md`.

<!-- END SOURCE 087: docs/ui/12-PREVIOUS-PROTOTYPE-CONTROL-CROSSWALK.md -->

---

<!-- BEGIN SOURCE 088: docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 13 - End-to-End BPMN Workflow Authoring Journey

**Status:** Proposed implementation contract for DEVIN; retain v1.0 contracts, do not invent completed source code. **Deadline:** November 30, 2026 DEV demo; bank release approvals are separate.

## Objectives and non-goals

A Business Enablement (BE) user must create, configure, validate, test, version, publish and observe a reusable BPMN 2.0 workflow without programming a new application. Approved CyberArk, NAS/Data, Reporting, Email and scheduling operations are discovered through typed capability manifests. AMIE rules add configured decisions and mappings. BOB executes the BPMN definition via shared core in embedded/central hosts. Kafka only crosses relevant service boundaries. The browser never contacts Kafka, SQL or CyberArk directly.

**Not an MVP requirement:** execute the full BPMN 2.0 surface, arbitrary code editor, in-flight migration, dynamic SQL, dynamic arbitrary HTTP, a new unapproved commercial design library, real PROD activation from a prototype.

## End-to-end path

```mermaid
flowchart LR
  S1[Select Application] --> S2[Create Workflow Draft]
  S2 --> S3[Choose Trigger and Input Contract]
  S3 --> S4[Browse Approved Capability Operations]
  S4 --> S5[Draw BPMN Process]
  S5 --> S6[Bind Data and AMIE Rules]
  S6 --> S7[Validate and Test]
  S7 -->|Errors| S5
  S7 -->|Pass| S8[Review and Publish Version]
  S8 --> S9[Bind Environments and Approvals]
  S9 --> S10[Initiate or Schedule]
  S10 --> S11[Business Dashboard + BPMN Monitor]
  S11 --> S12[Report + Audit + Runbook]
```

## Screen-by-screen navigation map

| Screen/route (proposed) | User intent | Key controls | Backend read/write | Next step |
|---|---|---|---|---|
| U01 Workbench `/be` | Find owned apps/jobs | app selector, status cards, create | GET `/applications`, `/summary` | U02/U14 |
| U02 Application Studio `/be/apps/{app}` | Scope business package | add dependency, owner, role, launch workflow | GET/PUT `/applications/{id}` | U03 |
| U03 Workflow Library `/be/workflows` | Templates, versions, lifecycle | create, clone, compare, retire | GET/POST `/workflows`, GET `/versions` | U04 |
| U04 New Workflow Wizard `/be/workflows/new` | Define title, ownership, scope | 4-step wizard, cancel, create | POST `/workflows/drafts` | U05 |
| U05 Trigger Designer `/be/workflows/{id}/triggers` | Manual CSV, form, API, AutoSys adapter, Kafka | type cards, schema picker, preview test | GET `/trigger-types`; PUT `/drafts/{id}/trigger` | U06 |
| U06 Data Sources `/be/workflows/{id}/data` | NAS API, staging, outputs | source selector, schema, policy scope, preview | GET `/capabilities`, `/schemas`, `/bindings` | U07 |
| U07 Capability Catalog `/be/capabilities` | Discover approved operations | search, filter, status, version | GET `/capabilities` + `/operations` | U08 |
| U08 Operation Inspector `/be/operations/{key}` | Understand handler | inputs, outputs, permissions, host, side effects | GET `/operations/{key}/versions/{ver}` | U09 |
| U09 BPMN Designer `/be/workflows/{id}/design` | Model process and subprocesses | palette, canvas, undo/redo, connect, inspector | GET/PUT `/drafts/{id}/bpmn` | U10 |
| U10 Binding Inspector | Wire inputs/outputs/rules | binding picker, schema preview, rule selection | GET `/binding-sources`, `/rules`; POST `/bindings/validate` | U11 |
| U11 Validation Panel | Confirm executable definition | validate, issue list, jump-to-node | POST `/drafts/{id}/validate` | U12 |
| U12 Test Bench | Use fixtures and stubs in DEV | dry-run, inspect step/outcomes, replay failure | POST `/drafts/{id}/tests` | U13 |
| U13 Version Review `/be/workflows/{id}/versions` | Diff and publish approved draft | compare, lock, publish | POST `/drafts/{id}/publish` | U16 |
| U14 Business Work Queue `/be/work` | Batch and record progress | filter, detail, download report | GET `/business/batches` | U15 |
| U15 Run Monitor `/be/runs/{runId}` | Technical BPMN overlay and timeline | time/step selector, view events | GET `/runs/{id}`, stream via authorized projection | U17 |
| U16 Release Center `/be/releases` | UAT/PROD configuration promotion | package digest, checks, approval evidence, activate | POST `/releases`, `/activations` | U18 |
| U17 Operations Console `/be/operations/runs` | Safe pause/resume/cancel/restart | reason, runbook, confirmation | POST `/runs/{id}/commands` | U18 |
| U18 Audit and Controls `/be/audit` | Reconstruct who/what/when/why | search, export, runbook link | GET `/audit/events`, `/controls` | U01 |
| U19 API Regression `/be/tests` | Prove UI and service behavior | suite list, tests, fixtures, evidence | GET `/test-runs` | U03 |

**Routes are proposed.** Reconcile existing Blazor routes during JOB-00. Initial pages can share existing BE shell and app selectors rather than new infrastructure.

## Main designer layout

```text
+----------------------------------------------------------------------------------------------------------------+
| Application: DCMS  [DEV]  Workflow: DCMS.BatchEnrichment  [Draft v4]  Saved  [Undo] [Redo] [Validate] [Test] |
| [Save Draft] [Review] [Publish] [Import BPMN] [Export BPMN]  [Help/Controls]  Role: WorkflowAuthor              |
+----------------------+-----------------------------------------------------------------+-----------------------+
| PALETTE              | CANVAS (semantic BPMN graph + BPMN DI geometry)                | INSPECTOR             |
| Start / End          | [Start] -> [Stage CSV] -> [Subprocess: Process Rows] -> [Email] | General               |
| Service Tasks        |                 selection, anchors, connectors, pan/zoom         | Inputs / Outputs      |
| AMIE Rule Tasks      |                                                                 | AMIE / Conditions     |
| Gateways             |                                                                 | Execution / Retry     |
| Subprocess / Call    |                                                                 | Security / Audit      |
| Wait / Events        |                                                                 | Validation/Readiness  |
| Swimlanes            |                                                                 |                       |
+----------------------+-----------------------------------------------------------------+-----------------------+
| BOTTOM PANEL: Problems [2] | Data Context | Rule Test | BPMN XML | Run Preview | Change History                         |
+----------------------------------------------------------------------------------------------------------------+
```

## Reusable UI interaction state machine

- Every data-loading component has `Idle -> Loading -> Loaded | Empty | Denied | Error` and can `Retry` without losing local draft edits.
- Every mutation has `Editing -> Dirty -> Submitting -> Accepted | Rejected | Conflict`; an HTTP 202 means *accepted* not *completed*.
- Every editor draft has `New -> Dirty -> SavedDraft -> Validated -> InReview -> Approved -> Published -> Active -> Retired`. Invalidating changes clear the *validated* badge. A published version is immutable; new edits create a new draft.
- State transitions depend on **backend** permission; hiding or disabling a control is only a UI affordance.
- Reason, ServiceNow change ID and approvals are required on mutation actions according to control policy; invalid ticket shape is not approval.
- Cross-service operations use a durable correlated command/outcome and may remain pending. UI shows the actual confirmed state and a delayed/unknown status rather than optimistic success.

## Create-from-scratch walkthrough

1. Workbench > choose `DCMS` > Workflow Library > `Create workflow`. Confirm app and write permission.
2. Wizard > enter workflow name/key, owner, purpose, scope and a reusable template. Leave no hardcoded CyberArk details in BOB.
3. Trigger > select Manual CSV > choose approved input schema > map file reference and batch metadata to workflow inputs. Optionally save trigger templates for later API/AutoSys binding.
4. Data > add NAS/Data API binding for stage, page, mark outcome (requires actual approved endpoint contracts).
5. Designer > insert Start, Stage CSV service task, embedded Process Rows call/subprocess, Report, Email and End; attach default and failure paths.
6. Service task inspector > select approved `operationKey@version`; map required inputs using `BindingPicker`, map output into scoped context; choose host local or Kafka based on manifest.
7. AMIE task inspector > select pinned rule key/version, inspect required facts, map current row/account, view sample rule output and typed change-set output.
8. Sequential multi-instance > bind row collection, cap concurrency=1, define per-record outcome aggregation and continue-on-row-error policy.
9. Validation > fix unsupported elements, bad bindings, missing rule version, missing operation authorization, absent environment binding, unreachable nodes or dangerous retry policy.
10. Test Bench > use 5-row sample (success, unchanged, account missing, rule reject, write error/uncertain); prove outcomes and event timeline. Use mocks for destructive effects.
11. Save and compare draft > reviewer sees diff and controls > publish immutable version if policy passes.
12. In DEV trigger via BE/API. Dashboard shows per-batch status; technical Run Monitor shows pinned BPMN node statuses; Audit shows event causality.
13. UAT/PROD transfer is **separate**, exact package digest and approved environment bindings, authorized Operations activation. No developer PROD access.

## UX obligations per screen

- **Field states:** default, focused, dirty, required-missing, invalid-format, type-conflict, unauthorized-value, not-supported, async-checking, checking-failed, valid. Preserve user's input on transient network errors.
- **Accessibility:** keyboard operable node list + accessible property panels, visible focus, proper labels/error summary, diagram not sole carrier of meaning, modal focus restore, clear dialog cancellation, logical tab order.
- **Large data:** virtualized/paginated operations and batch rows, lazy schema loading, request cancellation for search, not all batch records shipped to browser.
- **Performance:** local canvas gestures in reviewed JS module; commit changes into Blazor state after gesture; no per-pointermove Blazor Server roundtrips.
- **Audit:** designer edits and published changes get actor/time/ServiceNow references according to policy; raw file contents, secrets and credentials are excluded from browser logs.

## Acceptance

A new app is authorable end-to-end with the same UI components, and BE shows dynamically discovered NAS/Data, CyberArk, Reporting, Email operations with typed binding forms. Save/import/export preserves BPMN XML IDs/DI. A central/embedded workflow passes real DEV API regression, and a business user can see counts without seeing private audit/technical detail. A denied user cannot bypass the UI by calling backend endpoints directly.

<!-- END SOURCE 088: docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md -->

---

<!-- BEGIN SOURCE 089: docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 14 - BPMN Palette, Element Inspectors and Dynamic Configuration

**Source of truth:** BPMN 2.0.2 XML + BPMN DI; BE never owns a separate executable DSL. Unity bindings use stable BPMN element IDs and typed operation/rule references, with exact versions pinned at publish. **Supported visually** is distinct from **executable**.

## Inspector tabs (every node)

| Tab | Dynamic fields | Data source | Change impact |
|---|---|---|---|
| General | name, immutable ID, description, element type, lane, documentation | workflow draft | BPMN XML + DI |
| Inputs | required/optional schema properties, binding source, transforms, type and scope | operation or rule descriptor | Unity bindings |
| Outputs | strongly typed result properties, target context path, secrecy classification | operation descriptor | context graph |
| Rule | pinned AMIE rule/version, input facts, sample evaluation, branch output | AMIE catalog | rule binding |
| Execution | local vs cross-capability, timeout class, concurrency, idempotency, wait | operation manifest, BOB host | runtime binding |
| Errors | structured error category, retry limit/backoff, timeout/boundary path, manual review | operation policy + BOB | BPMN edges + policy |
| Security | permission, application scope, runner service identity, approver roles | registry + RBAC | authorization snapshot |
| Audit | evidence category, safe payload fields, control/runbook references, version | approved control catalog | audit policy |
| Testing | test fixture, mock vs live DEV, sample output, expected failure | test catalog | test definitions |

### Palette and executable coverage decision table

| BPMN 2.0 element family | Inspector/config details | Target | Publish behavior |
|---|---|---|---|
| None/message Start Event | trigger source, normalized typed input, caller scope | P0: manual/API/Kafka normalizer | permit only implemented start form |
| Timer Start Event | schedule definition/owner/timezone/misfire | P1 unless scheduler approved | show but block unsupported timer |
| End Event | completion outcome, business status projection | P0 | confirm reachable termination |
| Service Task | operation picker + schema-driven typed mapping + host | P0 | reject unknown/unapproved operation |
| Business Rule Task | AMIE rule/version and fact/output bindings | P0 | reject missing rule or type mismatch |
| Exclusive Gateway | predicate references, named branches, deterministic default | P0 | require unambiguous default |
| Parallel Gateway | token split/join, join semantics | P1 | reject execution until verified |
| Inclusive / Event-based / Complex Gateways | branch/join and event semantics | P2 | visualize/import, not executable until conformance |
| Subprocess / Call Activity | reusable workflow key/version, input/output mapping, host boundary | P0 (call/subprocess selected) | reject recursion/version conflict |
| Sequential Multi-instance | collection expression, concurrency=1, aggregation, fail policy | P0 DCMS | require bounded input/page references |
| Parallel Multi-instance | concurrency/ordering/joins | P1 | block until token semantics tested |
| Intermediate Message Catch / Receive Task | correlation selector, expected schema, timeout, late-event policy | P0 for Kafka outcome wait; approval if required | reject missing correlation |
| Message Throw / Send Task | logical message/operation, outcome handling | P0 through approved capability | no direct topic permissions in browser |
| User Task | eligible role, assignment, form schema, due time, escalation | P1 or P0 if Account Delete demo requires real approval | cannot fake approval as ordinary task |
| Timer/Error Boundary | attached activity, interrupting behavior, timeout/error branches | P1 or minimal P0 for selected exceptions | block unverified form |
| Terminate / Error End | containment/termination rules, error code | P1 | block unsupported scope behavior |
| Lanes / Pools / Participants | actor, lane metadata, collaboration rendering | P0 visual; collaboration semantics P2 | do not treat message-flow as sequence-flow |
| Data Objects, Stores, Annotations | data refs, classification, comments | P0 visual | not executable independently |
| Compensation / Transactions / Choreography / Conversation | handlers/correlation/semantic rules | P2 | import/render with explicit unsupported badge |
| Event Subprocess, Escalation, Signal, Conditional, Link, Cancel Events | specialized event metadata | P2 | explicit unsupported on publish |

**Do not claim full BPMN 2.0 execution.** OMG distinguishes model conformance from executable process semantics. See https://www.omg.org/spec/BPMN/2.0.2.

## Capability Service Task - field-generation algorithm

1. User selects task. Read `operationKey`, `contractVersion` from current draft; if missing, display approved operation picker with app/scope filters.
2. Fetch `OperationDescriptor` (stable contract version, input/output JSON schemas, UI hints, permission, side-effect class, allowed execution hosts, retry/reconciliation policy, audit).
3. For each input schema property build `SchemaField` or `BindingPicker` by format and type; required fields cannot be empty; classify secret references server-side; validate on backend.
4. Show available typed context sources: `WorkflowInput`, `CurrentItem`, `PriorOutput`, `AMIEOutput`, approved constant, environment binding, secret reference (ref only).
5. Reject invalid source type (e.g., list bound to account ID), missing scope, prohibited secret, stale version, or untrusted manifest.
6. Output fields choose destination path and scope (workflow/subprocess/item); mark PII/sensitive values; do not show raw CyberArk account/password in audit tab.
7. Execution mode defaults to operation-approved local when handler resides in embedded host; interservice goes via approved Kafka command/outcome. User cannot force host mode unsupported by descriptor.
8. SideEffect=ExternalWrite exposes reconciliation and approval policy; unsafe retries disabled by default; no arbitrary backoff override for bank-controlled operations.
9. `Save` updates draft revision, records actor and diff. Any change invalidates previous `Validated` state.

## AMIE business-rule task dynamic fields

- Select pinned `amieRuleKey@version` and inspect declared fact/output schema from existing AMIE engine (through adapter, do not rewrite engine).
- Bind required facts to known workflow data; build optional decision branches from enumerated result e.g. `ALLOW`, `SKIP`, `REJECT`, `REQUIRES_APPROVAL`.
- Provide sample test inputs and output preview, **labeled as simulated or executed**. Separate `ruleEvaluated` from `capabilityWriteConfirmed`.
- Editor must allow field mappings from uploaded CSV rows to typed CyberArk change set, with type compatibility and null/overwrite policy explicit.
- If rule needs a fact not available from prior tasks, display `MISSING_FACT` and offer to add an approved provider operation, not arbitrary new C#.

## Data/variable binding picker component contract

```json
{
  "destination": "CyberArk.AddOrUpdateAccount.input.account",
  "expectedType": "CyberArkAccountDto@v1",
  "classification": "Restricted",
  "allowedSources": [
    {"kind":"OperationOutput", "reference":"Task_ApplyAttributes.result.account", "type":"CyberArkAccountDto@v1"},
    {"kind":"AMIEOutput", "reference":"Rule_MapAttributes.result.changeSet", "type":"AttributeChangeSet@v1"}
  ],
  "currentSelection": null
}
```

This is an illustrative picker descriptor. Backend type-checks source-to-destination against pinned schemas. No arbitrary code eval in browser or BPMN.

## Start trigger inspector

- **Manual CSV:** app, file-schema, max size, MIME/CSV delimiter policy, upload endpoint, staging operation, permitted role, duplicate batch policy. User dashboard linked to batch ID immediately after accepted staging.
- **Form:** form-schema ref, defaults, validators, run-as policy, human identity + ticket when required.
- **API:** authenticated caller service, request schema, idempotency header, request/response contract, async 202+runId.
- **AutoSys:** authorized scheduler job identity, sourceRunId, jobName allowlist, replay window, mapping to workflow input, acknowledgement response. No broad AEWS credentials in BE.
- **Kafka:** logical inbound message, schema version, trusted producer identities, correlation, dedupe and DLQ policy.
- **Timer:** only if scheduling feature/host actually implemented; AutoSys schedules can be external triggers and **do not require** BOB timer-start support in MVP.

## Designer gestures and control semantics

| Gesture/control | State mutation | Required behavior |
|---|---|---|
| Drag BPMN item into canvas | add node + stable ID + DI bounds | snap grid, undo, dirty state |
| Click node/edge | selection | inspector swaps to matching schema; no save |
| Connect anchors | add sequence flow | prevent illegal edges, create ID and waypoints |
| Rename node | draft metadata | debounce optional, validation invalidated |
| Pan, zoom, fit, snap | view transform | preview JS local, persisted DI on commit only |
| Inline add `+` | add task between flows | rewire sequence paths atomically in draft |
| Delete node | remove node + incident flows | confirm if mappings/references affected |
| Duplicate/copy | new IDs, new safe binding refs | never reuse original BPMN ID |
| Undo/redo | local draft revision | never mutate published/running versions |
| Save / CTRL+S | PUT with ETag | 409/412 conflict opens compare dialog |
| Import BPMN | parse XML, preserve unknown extensions | report unsupported executable nodes; do not drop silently |
| Export BPMN | XML + DI + pinned bindings | no env secrets; stable roundtrip |
| Validate | backend compiler | precise issue bpmnId/path/code + jump-to-node |
| Test | safe DEV harness | fixture/stub vs live explicitly visible |
| Publish | immutable version + control gate | approval/time/version; backend RBAC |
| Add external connector | choose registered operation | no arbitrary URL/SQL editor |

## Error taxonomies

`BPMN_PARSE`, `BPMN_UNSUPPORTED_NODE`, `BPMN_GRAPH`, `BPMN_UNREACHABLE`, `BIND_REQUIRED`, `BIND_TYPE_MISMATCH`, `BIND_FORBIDDEN`, `OPERATION_NOT_APPROVED`, `HOST_MODE_UNSUPPORTED`, `AMIE_RULE_UNAVAILABLE`, `SCHEMA_VERSION_CONFLICT`, `DATA_OWNER_SCOPE`, `APPROVAL_REQUIRED`, `UNSAFE_RETRY`, `EXPIRED_DRAFT`, `REVISION_CONFLICT`, `POLICY_DENIED`.

Every issue includes `{code, severity, bpmnElementId, fieldPath, message, proposedFix}`; warnings do not silently become executable support.

<!-- END SOURCE 089: docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md -->

---

<!-- BEGIN SOURCE 090: docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 15 - Reusable Blazor Component Library for BE

## Principle

The UI is schema- and descriptor-driven, not CyberArk/DCMS-specific Razor pages. Components work for DCMS, Account Delete, Policy Drift, onboarding and future capability services. No new UI vendor library is required until the bank approves it. Reconcile the actual BE Blazor project and namespace before adding a second app; paths below are logical targets.

## Component tree / ownership

```text
/BusinessEnablement/Components/
  Layout/UnityShell.razor
  Shared/AsyncStateView.razor
  Shared/ScopedPermissionAction.razor
  Shared/CorrelationBanner.razor
  Shared/EntityVersionSelector.razor
  Shared/SchemaField.razor
  Shared/TypedBindingPicker.razor
  Shared/JsonSchemaSummary.razor
  Shared/ValidationIssueList.razor
  Shared/ChangeTicketInput.razor
  Shared/EnvironmentBindingRef.razor
  Shared/RoleGate.razor
  Shared/ConfirmSideEffectDialog.razor
  Shared/ApiResultToast.razor
  Workflows/WorkflowWizard.razor
  Workflows/WorkflowLibrary.razor
  Workflows/BpmnDesignerShell.razor
  Workflows/BpmnPalette.razor
  Workflows/BpmnCanvas.razor
  Workflows/BpmnNodeInspector.razor
  Workflows/BpmnSequenceInspector.razor
  Workflows/BpmnNodeList.razor
  Workflows/WorkflowDiffViewer.razor
  Workflows/WorkflowValidationPanel.razor
  Workflows/WorkflowTestBench.razor
  Workflows/WorkflowPublishWizard.razor
  Workflows/WorkflowRuntimeOverlay.razor
  Triggers/TriggerTypePicker.razor
  Triggers/CsvUploadSchemaEditor.razor
  Triggers/ApiTriggerEditor.razor
  Triggers/AutosysTriggerEditor.razor
  Data/DataSourcePicker.razor
  Data/NasOperationInspector.razor
  Capabilities/CapabilityCatalog.razor
  Capabilities/OperationInspector.razor
  Rules/AmieRulePicker.razor
  Rules/AmieRuleTestPanel.razor
  Messaging/KafkaContractInspector.razor
  Business/BatchStatusCard.razor
  Business/BatchDetailGrid.razor
  Monitoring/ActivityTimeline.razor
  Monitoring/RunControlPanel.razor
  Audit/AuditEvidenceTable.razor
  Release/ReleaseGateStatus.razor
  Release/PromotePackageWizard.razor
  Shared/RunbookReference.razor
/BusinessEnablement/Services/
  IWorkflowCatalogApi.cs / ICapabilityRegistryApi.cs / IRuntimeApi.cs
/BusinessEnablement/wwwroot/js/bpmnCanvas.js
```

These are **proposed** paths. Follow existing project folder pattern, e.g. `/DashboardApp-main/...` where that is actual BE project. Use `FluentValidation` under `/DashboardApp-main/Validation` if the existing application uses that convention; do not introduce DataAnnotations as parallel validation policy.

## Reusable component requirements

| Component | Inputs (parameter model) | Emits/output | Async, empty and error behavior | A11y + test |
|---|---|---|---|---|
| `AsyncStateView<T>` | request status, result, error, retry | load/retry | skeleton/empty/permission/error | announce status changes |
| `ScopedPermissionAction` | policy, resource, enabled-state, action | authorized click intent | disabled reason, server 403 | keyboard + denial test |
| `SchemaField` | JSON schema property, UI hints, value, classification | typed change | required/format/type errors | label/error ids |
| `TypedBindingPicker` | destination type, allowed sources, selected source | validated binding | forbidden/incompatible source excluded with reason | keyboard combobox |
| `AmieRulePicker` | scope, required facts, schema, versions | immutable rule ref | no compatible rule -> clear exception | role filtered |
| `OperationInspector` | operation key/version | add operation, inspect descriptor | deprecation/conflict/read-only | no secret values |
| `BpmnPalette` | supported element catalog, host conformance | selected draggable element | unsupported visible but blocked | list alternative |
| `BpmnCanvas` | draft BPMN XML+DI, bindings, selection | add/move/connect/selection commits | error banner, unsaved state | keyboard node list |
| `BpmnNodeInspector` | node + descriptor + rule catalog | typed property edits | dependency fetch stale -> preserve draft | tab semantics |
| `ValidationIssueList` | codes/severity/nodeRefs | focus affected element | warnings vs blockers | error summary |
| `WorkflowTestBench` | fixtures, runMode, permissions | test run ref | fake vs live label, timeout/pending | test ids |
| `WorkflowRuntimeOverlay` | published DI + activity states | selected activity | stale/reconnect -> snapshot GET | non-color labels |
| `TriggerTypePicker` | authorized trigger types | new trigger contract | unavailable AutoSys adapter labeled pending | cards/radio semantics |
| `CsvUploadSchemaEditor` | CSV columns/schema/policy | staged file ref | size/CSV parse/rejected rows | file input test |
| `NasOperationInspector` | approved NAS/data API manifest | typed data binding | schema/API version mismatch | no raw SQL editor |
| `BatchStatusCard` | aggregate counts/runId | drilldown | progress snapshot on reconnect | aria progress |
| `RunControlPanel` | run status, role, runbook | reasoned operator command | safe checkpoint/202 pending | confirmation focus |
| `ReleaseGateStatus` | package hash, approvals/roles | activate request | cannot bypass real authorization | blocked reason |

## Contract example for schema field wrapper

```csharp
public sealed record FieldUiDescriptor(
    string Name,
    string JsonType,
    bool Required,
    string? DisplayLabel,
    string? Description,
    string Classification,
    IReadOnlyList<string>? AllowedBindings);
```

A real implementation should honor the existing DTO naming and serializer conventions; this is a specification sketch, **not** compiled application code.

## Reusable API-facing state object

```csharp
public sealed record UiLoadState<T>(
    string Status, // Idle, Loading, Ready, Empty, Forbidden, Failed
    T? Data,
    string? ErrorCode,
    string? CorrelationId,
    string? Revision);
```

Do not use this string status as an authorization mechanism. Auth remains backend enforced.

## Dynamic dependency chain

`Capability Manifest` -> `Operation Picker` -> `SchemaField / TypedBindingPicker` -> `BPMN Unity binding` -> `Validation` -> `Test` -> `Published package` -> `Runtime overlay`.

`AMIE Descriptor` -> `Rule Picker` -> `Fact Binding` -> `Rule Test` -> `Business Rule Task` -> `Decision routing`.

`Trigger Contract` -> `Upload/Form/API/AutoSys picker` -> `Input schema` -> `BPMN Start` -> `Run ID + Business Dashboard`.

## BE component regression contract

Each component is unit/component tested for: loading, empty, errors, forbidden, stale versions, changed dependent schema, conflicting edits, keyboard focus, input validation, escaped error messages, data classification, localization fallback, and disconnected/reconnect state. End-to-end Playwright tests use stable `data-testid` attributes, not text selectors; direct API-denial tests are mandatory.

**Canvas implementation:** JS owns high-rate drag/pan/zoom and reports committed changes through JS interop to Blazor. Blazor maintains model, selection, inspector and save API. Do not modify Blazor-owned DOM from JS. Reference: https://learn.microsoft.com/en-us/aspnet/core/blazor/javascript-interoperability/?view=aspnetcore-10.0.

<!-- END SOURCE 090: docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md -->

---

<!-- BEGIN SOURCE 091: docs/ui/16-EDITOR-ACTIONS-API-AND-TEST-CATALOG.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 16 - BPMN Composer Click-to-Backend Action Contract

**Maintains** existing 107-action v1.0 registry (`wireframes/UI_CONTROL_REGISTRY_v1.0.json`) as baseline. These are **new grouped v1.1 composer actions**; names are proposed until JOB-00 reconciles existing API routing. Each action must have a backend API; front-end display-only actions may use GET or local state rather than pretend persistence.

## HTTP and state conventions

- Every mutation carries `X-Correlation-ID`, authenticated actor, app/resource scope, `If-Match` revision for drafts and immutable operation IDs for async actions. Service authorization is enforced at both gateway and worker.
- `200/201` => confirmed result; `202` => queued/accepted, poll or push for final result; `400/422` => validation; `401/403` => auth/permission; `404` => scoped absence; `409/412` => revision conflict; `429/503` => backoff and retry guidance with no duplicate mutation; `5xx` => uncertain status, reconcile via run ID.
- Field-level errors are rendered next to fields and in a keyboard-accessible summary; all API errors return stable error code and correlation ID. Never treat a disabled button as a security control.
- Published versions are immutable; draft editing changes revision. Run control commands have `commandId`, `reasonCode`, `requestedAtUtc`, `actor`, runbook/control id.

## Action contract matrix

| Action ID | Screen/control | Input / permission | Proposed call | UI change + audit / negative test |
|---|---|---|---|---|
| CMP-001 | Workbench: select app | app ID / `App.View` | GET `/apps/{id}` | scope filters all downstream operations; deny cross-app |
| CMP-002 | Library: new workflow | app, title / `Workflow.Edit` | POST `/workflow-drafts` | draft created; duplicate key 409 |
| CMP-003 | Library: clone template | template version / `Workflow.Edit` | POST `/workflow-drafts/from-template` | new IDs and draft; no inherited secrets |
| CMP-004 | Library: compare version | definition A/B / `Workflow.View` | GET `/workflows/{id}/diff` | structural diff and rule/operation pin diff |
| CMP-005 | Wizard: save identity | name, owner, scope / edit | PUT `/workflow-drafts/{id}/metadata` | updated ETag; required owner |
| CMP-006 | Wizard: choose trigger | start binding / edit | PUT `/workflow-drafts/{id}/trigger` | selected mode and input schema; disallow unsupported |
| CMP-007 | Trigger: manual CSV | input schema, size, file / execute | POST `/uploads` | returns fileRef; invalid CSV no run created |
| CMP-008 | Trigger: form | schema and values / execute | POST `/workflow-starts` | runId; backend revalidates fields |
| CMP-009 | Trigger: API definition | auth/schema/idempotency / edit | PUT `/workflow-drafts/{id}/trigger` | returns draft binding, never actual credentials |
| CMP-010 | Trigger: AutoSys definition | allowed job, sourceRunId schema / edit | PUT `/workflow-drafts/{id}/trigger` | unknown/unauthorized job rejected |
| CMP-011 | Trigger: Kafka definition | logical message ref/schema / edit | PUT `/workflow-drafts/{id}/trigger` | producer/contract validated |
| CMP-012 | Trigger: timer selection | schedule/timezone / edit | POST `/workflow-drafts/{id}/validate` | clearly unsupported if host not ready |
| CMP-013 | Data: browse NAS source | app scope / view | GET `/capabilities/NAS/operations` | typed approved operations only |
| CMP-014 | Data: inspect schema | operation/version / view | GET `/operations/{key}/versions/{v}` | fields and classifications; no table browse without policy |
| CMP-015 | Data: sample preview | masked fixture / `Data.Preview` | POST `/operations/{key}/preview` | redacted sample; no raw arbitrary queries |
| CMP-016 | Palette: insert node | BPMN type/position / edit | local edit, then PUT `/workflow-drafts/{id}/bpmn` | new BPMN id + DI, undo, validation stale |
| CMP-017 | Canvas: connect nodes | source/target IDs / edit | local edit, PUT draft | graph edge validated; reject illegal connection |
| CMP-018 | Canvas: select node | BPMN id / view | local; optional GET descriptor | inspector reflects current selection |
| CMP-019 | Canvas: move / zoom | bounds/waypoints / edit | local preview, save draft on commit | no pointermove API flood |
| CMP-020 | Canvas: duplicate node | original BPMN id / edit | local then save | generates new IDs, no stale bindings |
| CMP-021 | Canvas: delete node | BPMN id / edit | local then save | warn if dependent edge/data link exists |
| CMP-022 | Canvas: undo / redo | editor history / edit | local only | no change to published version |
| CMP-023 | Canvas: import BPMN | XML and DI / edit | POST `/workflow-drafts/{id}/imports` | issues show unknown elements, preserve extensions |
| CMP-024 | Canvas: export BPMN | version/draft / view | GET `/workflow-drafts/{id}/export` | exact XML+DI, no credentials |
| CMP-025 | Inspector: choose operation | key/version / edit | GET descriptor; PUT draft binding | pinned version and host restrictions |
| CMP-026 | Inspector: change input | field/source / edit | POST `/bindings/validate`; PUT draft | type issue at field path; no invalid silent conversion |
| CMP-027 | Inspector: output binding | destination/path / edit | PUT draft binding | classified output projected safely |
| CMP-028 | Inspector: execution host | mode / edit | POST `/bindings/validate` | disallow remote/local mode not in manifest |
| CMP-029 | Inspector: timeout/retry | policy / edit | POST `/bindings/validate`; PUT draft | unsafe external-write retry blocked |
| CMP-030 | Inspector: boundary event | event type and attached node / edit | PUT draft BPMN | reject if unsupported semantic |
| CMP-031 | AMIE: browse rule | app/facts/version / view | GET `/amie/rules` | scope/version filter |
| CMP-032 | AMIE: bind rule | key/version/inputs / edit | POST `/bindings/validate`; PUT draft | mismatched facts deny |
| CMP-033 | AMIE: sample test | redacted fixture / `Rule.Test` | POST `/amie/rules/{key}/tests` | result marked simulation/test, no external writes |
| CMP-034 | Multi-instance: set collection | source/concurrency/failure mode / edit | PUT binding; POST validate | MVP only sequential verified |
| CMP-035 | Error path: add branch | error code/target / edit | PUT draft BPMN | deterministic error mapping |
| CMP-036 | Save Draft | XML, DI, bindings + ETag / edit | PUT `/workflow-drafts/{id}` | saved revision; 409 merge dialog |
| CMP-037 | Validate | draftId+revision / edit | POST `/workflow-drafts/{id}/validate` | issue list with element links; no publish if blockers |
| CMP-038 | Navigate to issue | bpmnElementId / view | local editor action | inspector selects field; accessible focus |
| CMP-039 | Test / dry run | fixture, mock/live DEV mode / `Workflow.Test` | POST `/workflow-drafts/{id}/test-runs` | result contains runRef/evidence; mock labeled |
| CMP-040 | Inspect test step | testRunId, stepId / test view | GET `/test-runs/{id}/events` | fact/side-effect status separated |
| CMP-041 | Request review | draft, control refs, ticket / edit | POST `/workflow-drafts/{id}/reviews` | frozen review snapshot |
| CMP-042 | Approve review | reviewer, evidence / `Workflow.Approve` | POST `/reviews/{id}/decisions` | server prevents self-approval if policy says so |
| CMP-043 | Publish version | approved review + ETag / publish | POST `/workflow-drafts/{id}/publish` | immutable version, digest, audit |
| CMP-044 | Mark active version | version + env binding / release | POST `/workflow-activations` | approved deployment only |
| CMP-045 | Execute manual CSV | uploadRef, draft/active version / `App.Execute` | POST `/workflow-runs` | 202 with runId and batch link |
| CMP-046 | Business: filter batch | owner/scope/status/page / `Business.View` | GET `/business/batches` | role-scoped counts, masked row data |
| CMP-047 | Business: inspect row | batchId, rowGuid / `Business.View` | GET `/business/batches/{id}/rows/{guid}` | reason and status; no raw credentials |
| CMP-048 | Business: download report | reportRef / `Report.Download` | GET `/reports/{id}` | authorization and export audit |
| CMP-049 | Monitor: live overlay | runId / `Runtime.View` | GET `/runs/{id}/snapshot`; SSE/SignalR | reconnect GET snapshot; no direct Kafka |
| CMP-050 | Monitor: activity details | runId/elementId / `Runtime.Detail` | GET `/runs/{id}/activities/{node}` | timeline, retry count, correlation |
| CMP-051 | Operator: pause | runId, reason, ETag / `Run.Pause` | POST `/runs/{id}/commands` | 202 pause requested; wait checkpoint |
| CMP-052 | Operator: resume | runId, reason / `Run.Resume` | POST `/runs/{id}/commands` | only valid Paused -> Running |
| CMP-053 | Operator: cancel | runId, reason / `Run.Cancel` | POST `/runs/{id}/commands` | cooperative; no undo of write |
| CMP-054 | Operator: restart | runId, reason, reconciliation / `Run.Restart` | POST `/runs/{id}/restarts` | NEW linked run ID, old audit retained |
| CMP-055 | Release: bind NAS endpoint | environment binding ref / `Release.Config` | PUT `/releases/{id}/bindings` | no raw PROD credentials in UI |
| CMP-056 | Release: preflight | immutable artifact digest / `Release.View` | POST `/releases/{id}/preflight` | roles/compatibility/approvals checked |
| CMP-057 | Release: activate | digest/ticket/approval / `Release.Activate` | POST `/releases/{id}/activations` | PROD denied without real controls |
| CMP-058 | Audit: reconstruct run | runId / `Audit.View` | GET `/audit/runs/{id}/events` | cross-service causality and version pins |
| CMP-059 | Audit: export evidence | scoped query / `Audit.Export` | POST `/audit/exports` | classified export, immutable export event |
| CMP-060 | Runbook: open instructions | runbook key/version / `Controls.View` | GET `/runbooks/{key}/versions/{v}` | exact operator procedure version |
| CMP-061 | API regression: suite | env, suite / `Test.View` | GET `/test-runs?tag=bpmn` | test evidence and failing cases |
| CMP-062 | Registry: new handler published | trusted service manifest / service identity | POST `/capability-manifests` | only approved registered operations visible |
| CMP-063 | Registry: inspect capability | key/version / app view | GET `/capabilities/{key}/versions/{v}` | data requirements, topic contracts, security |

## Mandatory test matrix per action

For each non-local action create an API regression that checks valid request, missing required field, bad schema type, cross-app/role denial, stale version/revision, timeout/retry, and audit event presence. For local canvas gestures test undo/redo, save round-trip, clipboard ID uniqueness, keyboard navigation, and import/export DI geometry. Keep v1.0's 107-control tests and map IDs to these contract families; **63 new entries do not mean 63 new backend services**.

<!-- END SOURCE 091: docs/ui/16-EDITOR-ACTIONS-API-AND-TEST-CATALOG.md -->

---

<!-- BEGIN SOURCE 092: docs/ui/17-UI-RUNTIME-PROJECTIONS-AND-ACCESS.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 17 - BE Runtime Projections, State, Security and Operational Monitoring

## User perspectives

- **Business submitter:** upload CSV/start approved run; see batch ID, counts, ETA only if measured, row reasons and report; no need to know BPMN internals.
- **Workflow author:** create/test draft and inspect source-compatible operations/rules; no PROD execution permission merely from design rights.
- **Operations:** authorized run controls, runbook and ServiceNow change association; can see operational errors and correlation; no arbitrary rule edits.
- **Auditor/control owner:** immutable version graph, actor, rule decision, external side effect, change ticket, UTC timestamps, history reassembly, export with classification.
- **Platform engineer:** capability health/contracts, Kafka DLQ/outbox, BOB instances, AMIE versions; support trace under separation of duties.

## State projections (separate write/read models)

| Projection | Source events/data | Audience | Refresh | Security |
|---|---|---|---|---|
| `BusinessBatchSummary` | staged row results + workflow status | batch owner | on record outcome / periodic aggregation | own app/batch scope |
| `BusinessRowDetail` | row GUID, validation/write outcome, reason | submitter/support | page on request | classified fields masked |
| `BpmnRunSnapshot` | BOB durable token/checkpoint | runtime viewer | event-driven + resume GET | technical runtime scope |
| `RunTimeline` | BOB, Kafka, AMIE, capability evidence | operator/auditor | append query/SSE hint | redacted by policy |
| `ReleaseReadiness` | signed digest and approvals | author/release operator | after gate check | no prod secrets |
| `OperationalControl` | runbook version, operator reason and command result | operations/audit | append on action | immutable evidence |

## Publish/update protocol

1. Authorized API receives request, verifies app scope and data owner, writes business state and outbox atomically (where same transaction feasible).
2. Outbox publishes logical business progress event; projection worker updates read model or cache and emits notification with sequence number.
3. BE server delivers authorized SignalR/SSE message containing `{runId,batchId,revision,changedFields}` not raw account data.
4. Browser applies monotonic sequence updates; if gap/reconnect occurs, fetch snapshot with ETag; never trust UI count as source of truth.
5. Business user filters by own batch. Runtime viewer may open technical BPMN overlay. Auditor sees append-only events, not raw Kafka payloads.

## Run operator state machine

```mermaid
stateDiagram-v2
    [*] --> Created
    Created --> Running
    Running --> PauseRequested
    PauseRequested --> Paused: safe checkpoint
    PauseRequested --> Running: request denied or rolled back
    Paused --> Running: resume authorized
    Running --> CancelRequested
    Paused --> CancelRequested
    CancelRequested --> Cancelled: cooperative checkpoint
    Running --> Completed
    Running --> Failed
    Failed --> Restarted: new linked run
    Cancelled --> Restarted: new linked run
    Restarted --> Running
```

- Pause/cancel does not revoke a request already sent to CyberArk. Run detail must show `InFlightExternalWrite` and any `OutcomeUnknown` state.
- Restart must never resurrect an uncertain external write without reconciliation. New run IDs link back to original with runbook decision, actor and UTC time.
- User tasks/approvals must be real durable waits if implemented; no one-click UI-only approval simulating BPMN task completion.

## Security and audit controls

Backend enforcement includes SSO groups, application scope, role+operation permission, acting service identity, data classification, operation side-effect level, runbook, change management, UAT/PROD separation, and redaction. Every code change or configuration publication includes actor/version/time, ServiceNow change ID as appropriate, verified review approval (not only ticket string). Do not store secret values in BPMN XML, Kafka payloads, audit row, preview or browser logs.

## Required error UI

- Blocked publication: list exact BPMN node/error with link and remedy. No vague "invalid workflow".
- Backend permission failure: 403 with safe message + correlation, not 404 exposing existence across scopes.
- Kafka timeout/delivery uncertainty: show `PendingOutcome` / `AwaitingReconciliation`; do not mark succeeded.
- AutoSys duplicate source run ID: show existing workflow run link rather than creating second run.
- NAS API unavailable: show read-only retry/reconcile instruction, no direct SQL fallback from BE.
- Missing AMIE rule version: disable executable publish; view-only historic version remains viewable.

## Regression gates

1. 2 users own different batches: no cross-scope row/audit leakage.
2. 2 simultaneous draft editors: ETag conflict, no lost updates.
3. 1 worker crashes after CyberArk write but before completion: unknown outcome, reconciliation gate.
4. Client disconnect/reconnect during 250-row batch: counters fetched from authoritative API.
5. Repeat AutoSys trigger with same job/sourceRunId: one workflow run, both acknowledgments resolve consistently.
6. Auditor exports event history: row GUID, rule versions, operation outcome, actor UTC and change ticket appear with proper masking.

<!-- END SOURCE 092: docs/ui/17-UI-RUNTIME-PROJECTIONS-AND-ACCESS.md -->

---

<!-- BEGIN SOURCE 093: docs/ui/18-FULL-BPMN-DESIGNER-UI-CONFIGURATION-AND-TEST-RUNBOOK.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI 18 - Full User/Developer/Operations Runbook: Create BPMN Workflow Start to Finish

**Purpose:** DEVIN uses this as UI click acceptance script AND backend API regression. All endpoint names are proposed, not verified against the Unity repository. This guide is executable as a manual test only after the referenced services exist; the supplied wireframe is a simulation. Use DEV data, approved test identities and non-destructive substitutes unless explicitly authorized.

## Roles / test accounts

`WorkflowAuthor` may draft, configure, test and request review in scoped DEV applications. `WorkflowApprover` reviews and records required evidence. `ApplicationExecutor` may execute approved workflow for owned app/scope and view business status. `Operations` may activate approved releases and request pause/resume/cancel/restart subject to runbooks. `Auditor` may query redacted immutable evidence. `CapabilityDeveloper` may write handlers but does not inherit production deployment rights. These are proposed role names, reconcile with bank SSO/RBAC.

## Walkthrough A - New DCMS workflow from empty canvas

| Step | Exact BE interaction | Data configured | Expected server result and UI reaction | Test proof |
|---|---|---|---|---|
| A01 | Workbench > App selector `DCMS` | app scope | `GET /apps/DCMS`, role-scoped modules | unauthorized app hidden AND API 403 |
| A02 | Workflow Library > New > Blank BPMN | name `DCMS.BatchEnrichment`, owner, runbook | POST draft -> draftId/revision | app-specific catalog record, no shared code edit |
| A03 | Create Wizard > Trigger | `Manual CSV` + `CsvSchema.DCMS@1` | PUT trigger, form schema active | missing column blocks start |
| A04 | Triggers > Input mapper | `FileRef`, `RequestedBy`, `BatchCorrelation` | required fields bound | mappings survive reload |
| A05 | Data Sources > Add | Data/NAS stage operation (actual owner verified) | registry operation descriptor/permissions | no table/SQL editor |
| A06 | Data Sources > Configure | fileRef -> StageBatch fileRef; result batchId -> workflow context | typed binding validation | mismatch highlights field |
| A07 | Canvas > Add Start | `BPMN StartEvent` | stable ID + DI bounds | import/export preserves |
| A08 | Canvas > Add Service Task | `StageBatch` approved operation/version | Inspector shows required fileRef, output batchId | unknown op prohibited |
| A09 | Canvas > Connect Start -> Stage | sequence flow | draft graph edit, no backend side effect | undo/redo reverses |
| A10 | Canvas > Add Call Activity | `CyberArk.ProcessRows@v1`, embedded target | pins subprocess inputs, host, outputs | missing subprocess blocks publish |
| A11 | Embedded Workflow Editor > open subprocess | sequential multi-instance, collection pageRef, concurrency=1 | local BOB schema/graph | 3 rows ordered test |
| A12 | Canvas > Add GetAccount | CyberArk.GetAccount from capability registry | accountId from `CurrentRow.AccountId` | same handler reusable elsewhere |
| A13 | Canvas > Add AMIE Rule | DCMS.Eligibility from existing AMIE | facts CurrentRow, Account, Platform; output ALLOW/SKIP/REJECT | rule pinned, sample test |
| A14 | Canvas > Add XOR Gateway | ALLOW -> Map; SKIP/REJECT -> PersistReason | named/default flows | invalid branching blocked |
| A15 | Canvas > Add AMIE Mapping | approved custom attribute mapping rule | four inputs to changeSet; null overwrite behavior | typed changeSet |
| A16 | Canvas > Add ApplyInMemory | CyberArk.ApplyCustomAttributes | account + changeSet -> modifiedAccount | no external write yet |
| A17 | Canvas > Add AddOrUpdate | CyberArk.AddOrUpdateAccount | modified account; Write classification + no blind retry | outcome confirmed vs unknown |
| A18 | Canvas > Add RowOutcome | Data/NAS MarkRowOutcome | batchId, rowGuid, validation, write outcome, reason | one terminal row record |
| A19 | Canvas > connect loop back | next row until all processed | BOB sequential multi-instance | no duplicate row on resume |
| A20 | Central canvas > Add durable wait | Kafka correlated process outcome by run+command ID | published version pins/wait token persisted | duplicate event ignored |
| A21 | Central canvas > Reporting + Email | reportRef to Email via Kafka | separate send status | email fail not account fail |
| A22 | Canvas > Add End and failure branches | result and error classification | reachable and deterministic | graph checker passes |
| A23 | Toolbar > Save Draft | XML, DI, bindings + ETag | new revision | 409 concurrent edit works |
| A24 | Toolbar > Validate | BPMN graph, all operations/rules, scopes, retry | issue list / valid summary | no fake green for missing handler |
| A25 | Toolbar > Test | five-row DEV fixture | accepted test run, activity and outcome evidence | mock versus live labeled |
| A26 | Workflow > Review > Publish | changeRef, approver, digest | immutable version in DEV | cannot self-publish if policy forbids |
| A27 | Workbench > DCMS > Upload CSV | selected active version + fixture CSV | fileRef, batchId, runId | 202 != completed |
| A28 | Dashboard > Batch 81492 | counts/rows/report | GET projection + SignalR/SSE hint | refresh / reconnect works |
| A29 | Monitor > Run details | BPMN node overlay/causation | GET snapshot/timeline | technical permission separately enforced |
| A30 | Audit > reconstruct | runId and rowGuid | versions, actor, rule outcome, write outcome, changeRef | full trace with masking |

## Walkthrough B - NAS EF API integration

**Before UI demo:** SDK registry shows approved NAS service and operations. Inspect existing NAS source/Swagger to confirm names/DTOs/EF entities. Test `NAS.GetRowsPage` or equivalent end-to-end with a minimal authorized DEV batch.

1. BE > Capability Catalog > search `NAS` > select service > see owner, contract version, health, operation list and permitted environments.
2. Operation Inspector > choose GetRowsPage / equivalent; automatically display batch ID, page/cursor and maxPageSize from manifest schema.
3. Click Add to Workflow > service task appears with binding inspector; map prior `StageBatch.result.batchId` to required field; choose approved execution mode.
4. Click Preview > use redacted fixture; compare output schema fields to `CurrentRow` type in AMIE facts.
5. Click Validate > schema + data owner + permission policy check; publish DEV version; run and prove EF backend via API telemetry, without direct external table access.

## Walkthrough C - Account Delete (safe DEV)

1. App Studio > Create `PAM.AccountDeletion`; Workflow Library > template Guarded Write.
2. Trigger > Form / API; require `accountRef`, `reasonCode`, approved change/request ref, `dryRun=true` default.
3. Add CyberArk.GetAccount and AMIE DeleteEligibility; choose result path, denial outcome and details.
4. Add approval wait: only enable real BPMN User Task if supported; otherwise registered Control.RequestApproval + durable message wait with correlation and human form.
5. Add CyberArk.DeleteAccount operation; inspector displays destructive write warning, permission, no blind retry and verification. Require explicit confirmation in UI.
6. Validate denial cases and stale account revision. Run with stub/non-production approved fixture; status flow shows AwaitingApproval, Approved, DeletePending, Verified/Rejected/Unknown.
7. Audit export contains authorized actor, separate approver, change ID and confirmed outcome; no production account deletion in test fixture.

## Walkthrough D - AutoSys Policy Drift

1. App Studio > Policy Drift > New > Scheduled Policy Ingestion template.
2. Trigger Designer > AutoSys Job > choose approved job key/version from registry (not free text); assign `sourceRunId`, jobName, scheduled timestamp, dedupe window, overlap mode and inputRef schema.
3. Data Sources > choose EPV policy bundle acquisition and baseline EF API operations. Rule Editor > PolicyId sanitizer + attribute comparison + `MISSING_BASELINE` branch.
4. BPMN canvas > download ZIP, recursively parse INI, sequential per-policy evaluate, persist reasons/diffs, report/email; implement fatal download/unzip failure path and row-level invalid PolicyID behavior.
5. Validate > tests for nested ZIP, same-policy NO_DRIFT, changed DRIFT, missing baseline, invalid PolicyID, wrong AutoSys service identity and duplicate sourceRunId.
6. DEV adapter calls secured Unity trigger endpoint as AutoSys would. BE runtime shows accepted run and final summary; second identical call returns same runId, no second processing.
7. Complete evidence: scheduler job ID, Unity run ID, exact definitions/rules, source input hash/ref, EF result and report/email status.

## Failure and denial walkthroughs (all scenarios)

- User without Workflow.Edit clicks Create/Publish via direct HTTP: API 403 and audit policy-denial event.
- Operation disappeared or version disabled after editing: Validation blocker; published historic version remains viewable.
- Import malformed BPMN: per-element error; editor unchanged; no truncation of current draft.
- Network disconnect while dragging: canvas local state preserved; no repeated per-pointer remote requests.
- `If-Match` conflict during Save: compare revisions, preserve unsaved client changes, user resolves; never blind overwrite.
- Rule facts missing: highlight source field and suggested approved provider operation; no expression eval fallback.
- AutoSys double-trigger: same run ID returned; audit records deduplicated delivery.
- Kafka outcome late/duplicate after restart: no duplicate workflow token advancement or CyberArk write.
- CyberArk outcome unknown after timeout: require read/reconciliation, no automatic destructive retry.
- No real ServiceNow approval: PROD activation blocked, even if ticket text was typed.
- Business dashboard reconnect after 100 updates: counts from authoritative GET, not cumulative UI increments.

## Completion proof for DEVIN

Attach CI test run, exact source repository PR/commit and paths, approved dependency list, screenshots of each UI and error state, 5-row DCMS fixture result, API traces, screenshot of empty/forbidden/error states, audit SQL reconstruction without raw secrets, pinned package hash, and explicit list of BPMN elements supported versus not supported. No claim of production compliance or release approval without bank signoff.

<!-- END SOURCE 093: docs/ui/18-FULL-BPMN-DESIGNER-UI-CONFIGURATION-AND-TEST-RUNBOOK.md -->

---

<!-- BEGIN SOURCE 094: jobs/INDEX.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# DEVIN Job Index — Independent, Mergeable Work Packets

Every job is a PR-sized scope or a clearly separable Epic. Distinct owners/worktrees; do not assign one giant all-platform task. Dependencies require reviewed contracts/fixtures, not just an open PR. Refer to `docs/roadmap/DELIVERY-PLAN.md` for gates and staffing.

| Job | Priority | Lane | Depends on | Proposed target |
|---|---|---|---|---|
| [JOB-00 — Reconcile actual repo, working code, approved dependencies](JOB-00-reconcile-repository.md) | P0 | Platform architecture | None | Nov 11–12 |
| [JOB-01 — Freeze minimum cross-team contracts and acceptance fixtures](JOB-01-freeze-contracts.md) | P0 | Platform / SDK / BOB owners | JOB-00 | Nov 12–13 |
| [JOB-02 — Implement common capability SDK and DI operation registration](JOB-02-capability-sdk.md) | P0 | Capability SDK | JOB-01 | Nov 13–17 |
| [JOB-03 — Create trusted registry, approval/health view and operation descriptor APIs](JOB-03-registry-contracts.md) | P0 | Platform Registry / BE API | JOB-01, JOB-02 | Nov 14–18 |
| [JOB-04 — Integrate existing AMIE rule evaluation and metadata into Unity](JOB-04-amie-adapter.md) | P0 | AMIE bridge | JOB-00, JOB-01 | Nov 13–17 |
| [JOB-05 — Build BPMN 2.0 XML parser/compiler with explicit MVP semantics](JOB-05-bpmn-compiler.md) | P0 | BOB Core | JOB-01 | Nov 13–18 |
| [JOB-06 — Implement shared BOB execution core with central/embedded hosts](JOB-06-bob-hosts.md) | P0 | BOB Runtime | JOB-01, JOB-02, JOB-04, JOB-05 | Nov 15–20 |
| [JOB-07 — Implement Kafka command/outcome, outbox/inbox, correlation and dedupe](JOB-07-kafka-sdk.md) | P0 | Messaging | JOB-01, JOB-02 | Nov 14–20 |
| [JOB-08 — Implement MSSQL workflow state, audit timeline and projections](JOB-08-sql-audit.md) | P0 | Persistence / Audit | JOB-01, JOB-05 | Nov 14–20 |
| [JOB-09 — Implement Blazor Workflow Library and BPMN canvas](JOB-09-be-designer.md) | P0 | BE UX | JOB-01, JOB-05 | Nov 14–22 |
| [JOB-10 — Implement BE capability inspector, AMIE binding and schema-driven forms](JOB-10-be-composition.md) | P0 | BE composition | JOB-03, JOB-04, JOB-05, JOB-09 | Nov 16–22 |
| [JOB-11 — Build CSV/API trigger and DCMS batch/row staging interface](JOB-11-input-trigger-staging.md) | P0 | Ingestion / Data Owner | JOB-01, JOB-08 | Nov 15–21 |
| [JOB-12 — Reconcile CyberArk primitives and implement missing reusable handlers](JOB-12-cyberark-operations.md) | P0 | CyberArk capability | JOB-00, JOB-02, JOB-04 | Nov 15–22 |
| [JOB-13 — Connect reporting aggregation and independent Email Capability](JOB-13-reporting-email.md) | P0 | Reporting / Email | JOB-02, JOB-07, JOB-11 | Nov 18–23 |
| [JOB-14 — Implement business progress, BPMN run monitor and near-real-time updates](JOB-14-be-monitor.md) | P0 | BE monitoring | JOB-07, JOB-08, JOB-09 | Nov 19–24 |
| [JOB-15 — Implement policy enforcement, run controls and runbooks](JOB-15-rbac-operator.md) | P0 | Security / Operations | JOB-06, JOB-08, JOB-14 | Nov 19–25 |
| [JOB-16 — Build immutable config package, approval and Operations promotion gates](JOB-16-release-package.md) | P0 design / PROD gated | Release / Compliance | JOB-01, JOB-08, JOB-09 | Nov 20–26 |
| [JOB-17 — Build full API, BPMN, role-denial and fault-injection regression](JOB-17-regression-ci.md) | P0 | QA / Integration | JOB-01, JOB-02, JOB-05; integrate others as arrive | Nov 14–29 |
| [JOB-18 — Integrate and validate real DCMS end-to-end vertical slice](JOB-18-dcms-e2e.md) | P0 | DCMS pilot / Integration | JOB-02 through JOB-15 as relevant | Nov 21–27 |
| [JOB-19 — Prove configuration reuse with Hygiene or Onboarding](JOB-19-second-workload.md) | P1 target | Application / Reuse | JOB-18 | Nov 24–29 |
| [JOB-20 — Perform integrated demo, review readiness, record gaps and owners](JOB-20-demo-handoff.md) | P0 | Integration / Program | JOB-17, JOB-18; JOB-19 optional | Nov 27–30 |

## Parallelization and coordination

JOB-00 and JOB-01 precede broad writes. SDK/registry, BOB, AMIE, Kafka, SQL and BE teams can work in separate worktrees after the contract gate. Reserve one integration owner for cross-service fixtures and merging. API and contract tests start with the first PR; JOB-17 is continuous, not a final-week afterthought.

## Acceptance and triage

P0 first: a truthful single DCMS demonstration beats multiple disconnected mock screens. If capacity falls short, defer P1 and UI polish rather than weaken authorization, audit, idempotency, versioning, safety or contract tests. PROD depends on actual bank controls.


## UI + SDK v1.0 detailed subtasks

See [17 scoped interaction and SDK task packets](interaction/INDEX.md). They expand original jobs rather than duplicating project ownership. Complete JOB-00 and JOB-01 before parallel code generation.

## v1.1 detailed designer/workflow tasks

See [jobs/bpmn/INDEX.md](bpmn/INDEX.md) for 20 actionable design/execution/fixture tasks BE-21 through QA-40. They refine existing jobs rather than creating another BOB or AMIE engine. Original 21 jobs and earlier interaction subtasks remain valid unless a reviewed contract decision supersedes one.

<!-- END SOURCE 094: jobs/INDEX.md -->

---

<!-- BEGIN SOURCE 095: jobs/JOB-00-reconcile-repository.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-00 — Reconcile actual repo, working code, approved dependencies

**Priority:** P0  
**Dependencies:** None  
**Suggested lane:** Platform architecture  
**Planning target:** Nov 11–12 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Read-only inventory first. Locate real solution/projects, entrypoints, AMIE interfaces and rule format, any existing BOB parser/engine, Kafka producers/consumers, Blazor BE pages, CyberArk operations, existing SQL schemas, CI pipeline and approved UI libraries. Trace at least one real invocation end-to-end. Mark each proposed concept Existing / Adapt / Build / Unknown. Publish a single source-of-truth current-to-proposed contract map and blockers.

## Proposed target file groups (validate actual repo names first)

/docs/decisions/REAL-REPOSITORY-MAP.md; /docs/decisions/DEPENDENCY-APPROVALS.md; /docs/decisions/AMIE-INTERFACE-MAP.md

## Definition of done / acceptance evidence

Actual namespaces, file paths, tests, build commands, API definitions, package versions, Kafka topic conventions, CyberArk auth boundaries and control owners recorded with file evidence; no code invented or overwritten.

## Functional, API and negative regression

Run existing build and tests without altering PROD. Demonstrate a real existing AMIE evaluation or mark unavailable; verify every claimed implemented operation against source.

## Guardrails / explicitly out of scope

No speculative new engine or SDK scaffolding in this job.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-00: Reconcile actual repo, working code, approved dependencies. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 095: jobs/JOB-00-reconcile-repository.md -->

---

<!-- BEGIN SOURCE 096: jobs/JOB-01-freeze-contracts.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-01 — Freeze minimum cross-team contracts and acceptance fixtures

**Priority:** P0  
**Dependencies:** JOB-00  
**Suggested lane:** Platform / SDK / BOB owners  
**Planning target:** Nov 12–13 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Reconcile proposed `OperationDescriptor`, invocation context, outcome/error taxonomy, AMIE adapter, BPMN extension, Kafka envelope, release lock, audit event and API route families against real code. Establish schema version conventions, unambiguous operation key resolution and approved host modes. Record ADRs for conflicts. Commit fixture + contract test project before parallel implementation.

## Proposed target file groups (validate actual repo names first)

/Unity.Capabilities.Contracts/Descriptors/*.cs; /Unity.BOB.Contracts/Bindings/*.cs; /Unity.Contracts.Tests/*.cs; /docs/decisions/CONTRACT-LOCK.md

## Definition of done / acceptance evidence

A sample safe test operation resolves through a descriptor and a typed sample AMIE output feeds its input; broker envelope schema and run context are approved by owners; contract tests fail incompatibility.

## Functional, API and negative regression

Duplicate operation key, missing required field, downgraded version and unauthorized caller rejected; reconcile v0.7 fixture names to actual code.

## Guardrails / explicitly out of scope

Don't freeze a duplicate AMIE DSL; don't build a registry application before the data contracts are stable.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-01: Freeze minimum cross-team contracts and acceptance fixtures. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 096: jobs/JOB-01-freeze-contracts.md -->

---

<!-- BEGIN SOURCE 097: jobs/JOB-02-capability-sdk.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-02 — Implement common capability SDK and DI operation registration

**Priority:** P0  
**Dependencies:** JOB-01  
**Suggested lane:** Capability SDK  
**Planning target:** Nov 13–17 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Implement typed handler interface and registration extension integrated with existing DI. Discover vetted compiled handlers by explicit registration/approved assembly only. Build immutable manifest from descriptors; expose health/manifest endpoint; enforce duplicate/key/schema/policy checks at startup. Implement handler dispatch with execution context and cancellation. Add registration and auth tests.

## Proposed target file groups (validate actual repo names first)

/Unity.Capabilities.Contracts/; /Unity.Capabilities.Hosting/; /Unity.Capabilities.Tests/

## Definition of done / acceptance evidence

A real safe handler registers once; descriptor, input schema, output schema, required permission, execution host and side-effect policy are discoverable; same key can be bound by two test workflows without code changes.

## Functional, API and negative regression

Unknown handler, duplicate key, bad schema, missing permission, unauthorized direct dispatch and unsupported version fail deterministically.

## Guardrails / explicitly out of scope

No network-based dynamic code loading; no arbitrary C# class names in published configuration.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-02: Implement common capability SDK and DI operation registration. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 097: jobs/JOB-02-capability-sdk.md -->

---

<!-- BEGIN SOURCE 098: jobs/JOB-03-registry-contracts.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-03 — Create trusted registry, approval/health view and operation descriptor APIs

**Priority:** P0  
**Dependencies:** JOB-01, JOB-02  
**Suggested lane:** Platform Registry / BE API  
**Planning target:** Nov 14–18 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Receive trusted published manifest from capability deploy identity; validate signature/attestation and contract compatibility; store version + owner + availability state, separate from permission/health. Expose paginated authorized APIs to enumerate capability, operations, input/output schemas, AMIE dependencies, messaging declarations. Reject conflicting manifests.

## Proposed target file groups (validate actual repo names first)

/Unity.Registry/; /Unity.Registry.API/; /Unity.Registry.Tests/

## Definition of done / acceptance evidence

BE/API can list `CyberArk.GetAccount@1.0` with correct schema after approved nonproduction publication; unavailable/unapproved entries cannot be invoked; registry accepts multiple capability services.

## Functional, API and negative regression

Unsigned publisher, wrong owner, duplicate version/content conflict, incompatible upgrade, stale health and forbidden scope rejected or correctly marked.

## Guardrails / explicitly out of scope

Do not provision enterprise Kafka topics or ACLs merely because manifest requests them.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-03: Create trusted registry, approval/health view and operation descriptor APIs. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 098: jobs/JOB-03-registry-contracts.md -->

---

<!-- BEGIN SOURCE 099: jobs/JOB-04-amie-adapter.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-04 — Integrate existing AMIE rule evaluation and metadata into Unity

**Priority:** P0  
**Dependencies:** JOB-00, JOB-01  
**Suggested lane:** AMIE bridge  
**Planning target:** Nov 13–17 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Map existing AMIE evaluate/version/serialization/dependency APIs to the typed BOB adapter, exposing rule descriptor, input/output schema, validated data binding and safe decision result. Integrate embedded host and BE rule picker. Ensure no network roundtrip per local row and no second evaluator. Add rule version pin tests.

## Proposed target file groups (validate actual repo names first)

/Unity.Capabilities.AMIE/; /Unity.BOB.Contracts/Rules/; /Unity.AMIE.Integration.Tests/

## Definition of done / acceptance evidence

Real existing AMIE rule evaluates under local capability context; output feeds typed operation; rule version and safe decision audit recorded; new config can be published without changing operation handler.

## Functional, API and negative regression

Missing input, wrong type, unauthorized data, missing pinned version, incompatible rule output and privilege escalation through rule are rejected.

## Guardrails / explicitly out of scope

No new rule language or compile-from-UI arbitrary C#.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-04: Integrate existing AMIE rule evaluation and metadata into Unity. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 099: jobs/JOB-04-amie-adapter.md -->

---

<!-- BEGIN SOURCE 100: jobs/JOB-05-bpmn-compiler.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-05 — Build BPMN 2.0 XML parser/compiler with explicit MVP semantics

**Priority:** P0  
**Dependencies:** JOB-01  
**Suggested lane:** BOB Core  
**Planning target:** Nov 13–18 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Implement BPMN 2.0 XML+DI import/serialize, secure XML parsing, stable node IDs, supported element graph compiler, node-to-registered-operation/rule binding validation. P0 start/end, service task, business-rule task, exclusive gateway, flow, call/subprocess, sequential multi-instance and Kafka wait; reject unsupported elements. Add fixtures per actual semantic behavior.

## Proposed target file groups (validate actual repo names first)

/Unity.BOB.Core/Bpmn/; /Unity.BOB.Core/Compilation/; /Unity.BOB.Core.Tests/

## Definition of done / acceptance evidence

Real BPMN fixture roundtrips and compiles to tested graph; gateway picks right branch; call activity passes outputs; sequential rows execute in order; unsupported element rejected with node ID.

## Functional, API and negative regression

XXE/DTD, invalid graph, ambiguous gateway, missing default, invalid rule or handler, unsupported boundary/parallel cases rejected.

## Guardrails / explicitly out of scope

Do not claim full BPMN 2.0 conformance from XML parsing.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-05: Build BPMN 2.0 XML parser/compiler with explicit MVP semantics. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 100: jobs/JOB-05-bpmn-compiler.md -->

---

<!-- BEGIN SOURCE 101: jobs/JOB-06-bob-hosts.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-06 — Implement shared BOB execution core with central/embedded hosts

**Priority:** P0  
**Dependencies:** JOB-01, JOB-02, JOB-04, JOB-05  
**Suggested lane:** BOB Runtime  
**Planning target:** Nov 15–20 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Create common interpreter token/state transition and dispatch abstraction. Embedded uses DI for local handlers and existing AMIE; central uses persistent command wait/outcome mapping. Include process version pinning, status event emission, run controls at safe points and durable local sequential batch mode as required. Write host parity tests.

## Proposed target file groups (validate actual repo names first)

/Unity.BOB.Core/Execution/; /Unity.BOB.Embedded/; /Unity.BOB.Central/; /Unity.BOB.Tests/

## Definition of done / acceptance evidence

Same compiled workflow executes under both hosts with identical business step decisions; central returns to durable wait after Kafka dispatch; local run avoids per-operation Kafka; restart resumes pinned process.

## Functional, API and negative regression

Double result, pause during write, cancellation, missing version, timeout, worker crash and concurrent advancement pass tests.

## Guardrails / explicitly out of scope

Never add DCMS-specific branches or hardwire CyberArk into BOB.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-06: Implement shared BOB execution core with central/embedded hosts. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 101: jobs/JOB-06-bob-hosts.md -->

---

<!-- BEGIN SOURCE 102: jobs/JOB-07-kafka-sdk.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-07 — Implement Kafka command/outcome, outbox/inbox, correlation and dedupe

**Priority:** P0  
**Dependencies:** JOB-01, JOB-02  
**Suggested lane:** Messaging  
**Planning target:** Nov 14–20 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Adapt existing approved Kafka library. Serialize versioned envelope; route by approved logical bindings, map to allowed physical broker topics via environment config. Implement SQL transactional outbox with owning state, consumer inbox dedupe, completion correlation, DLQ policy, traceparent propagation and worker authorization. Integrate with BOB host and SDK.

## Proposed target file groups (validate actual repo names first)

/Unity.Capabilities.Kafka/; /Unity.BOB.Central/Messaging/; /Unity.Messaging.Tests/

## Definition of done / acceptance evidence

Central BOB command reaches test capability; outcome resumes correct run/activity once; duplicate command/outcome causes no duplicate state; broker outage can be recovered without losing committed command.

## Functional, API and negative regression

Wrong producer identity, malformed schema, unauthorized operation, old schema, poison message, late cancel, crash-after-write/unknown outcome handled.

## Guardrails / explicitly out of scope

Do not assert exactly-once external CyberArk writes; no full CSV on Kafka.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-07: Implement Kafka command/outcome, outbox/inbox, correlation and dedupe. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 102: jobs/JOB-07-kafka-sdk.md -->

---

<!-- BEGIN SOURCE 103: jobs/JOB-08-sql-audit.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-08 — Implement MSSQL workflow state, audit timeline and projections

**Priority:** P0  
**Dependencies:** JOB-01, JOB-05  
**Suggested lane:** Persistence / Audit  
**Planning target:** Nov 14–20 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Map existing SQL conventions; build workflow definitions/versions/runs/tokens/activity/command state tables, outbox/inbox if not owned by messaging, append-only audit schema, current status projection, optimistic concurrency/lease. Add migrations and audit read APIs. Enforce redaction/classification and actor/ServiceNow fields.

## Proposed target file groups (validate actual repo names first)

/Unity.BOB.Persistence.MSSQL/; /DatabaseScripts/; /Unity.Audit/; /Unity.Persistence.Tests/

## Definition of done / acceptance evidence

Run starts, checkpoints, survives service restart and reconstructs actor/rule/version/message/correlation/ticket/outcome; projections reproduce state after rebuild; restricted exports redacted.

## Functional, API and negative regression

Audit down, rollback state, concurrent lease, duplicate events, stale version, missing evidence and unauthorized writes tested.

## Guardrails / explicitly out of scope

No new non-MSSQL BOB provider; don't move DCMS row payload to engine database.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-08: Implement MSSQL workflow state, audit timeline and projections. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 103: jobs/JOB-08-sql-audit.md -->

---

<!-- BEGIN SOURCE 104: jobs/JOB-09-be-designer.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-09 — Implement Blazor Workflow Library and BPMN canvas

**Priority:** P0  
**Dependencies:** JOB-01, JOB-05  
**Suggested lane:** BE UX  
**Planning target:** Nov 14–22 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Reuse existing Blazor project, nav/layout and approved controls. Implement Workflow Library draft/version/status, a usable supported-BPMN SVG canvas, task palette, connections, property panel shell, save/import/export BPMN XML+DI, validation diagnostics, version lifecycle API bindings. Use approved designer library only if already permitted; otherwise first-party SVG+small JS module.

## Proposed target file groups (validate actual repo names first)

/Unity.BE/Components/Pages/WorkflowLibrary.razor; /Unity.BE/Components/Pages/BpmnDesigner.razor; /Unity.BE/wwwroot/js/workflowCanvas.js; /Unity.BE/Services/WorkflowApiClient.cs

## Definition of done / acceptance evidence

Designer can create BPMN supported graph, persist draft via real API, roundtrip XML+DI, reload intact, display backend errors and prepare publish; no fake save buttons.

## Functional, API and negative regression

Dangling flows, unsupported elements, stale draft ETag, unauthorized editing, XSS in labels, zoom/drag and API failures tested.

## Guardrails / explicitly out of scope

Avoid unapproved new UI NuGet/npm libraries and building a full diagramming engine before vertical slice.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-09: Implement Blazor Workflow Library and BPMN canvas. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 104: jobs/JOB-09-be-designer.md -->

---

<!-- BEGIN SOURCE 105: jobs/JOB-10-be-composition.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-10 — Implement BE capability inspector, AMIE binding and schema-driven forms

**Priority:** P0  
**Dependencies:** JOB-03, JOB-04, JOB-05, JOB-09  
**Suggested lane:** BE composition  
**Planning target:** Nov 16–22 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Consume real registry and AMIE metadata APIs; render operation inputs/outputs, source picker (workflow/current row/prior step/AMIE/approved bindings), inspect version, permission, side effects, retry and audit. On save call backend binding compiler and expose actionable field/node diagnostics. Reuse AMIE rule editing if it exists.

## Proposed target file groups (validate actual repo names first)

/Unity.BE/Components/Workflow/OperationInspector.razor; /Unity.BE/Components/Workflow/AmieRulePicker.razor; /Unity.BE/Services/CapabilityCatalogApiClient.cs

## Definition of done / acceptance evidence

Drag an approved CyberArk operation, render required fields, select AMIE rule and wire output into next operation, validate and save without changing capability code.

## Functional, API and negative regression

Wrong source type, missing rule, forbidden operation, missing environment binding, secret field leak, stale descriptor tested.

## Guardrails / explicitly out of scope

Do not make mock arrays look like real registry or duplicate AMIE designer implementation.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-10: Implement BE capability inspector, AMIE binding and schema-driven forms. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 105: jobs/JOB-10-be-composition.md -->

---

<!-- BEGIN SOURCE 106: jobs/JOB-11-input-trigger-staging.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-11 — Build CSV/API trigger and DCMS batch/row staging interface

**Priority:** P0  
**Dependencies:** JOB-01, JOB-08  
**Suggested lane:** Ingestion / Data Owner  
**Planning target:** Nov 15–21 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Determine actual DCMS data owner/schema and approved upload/storage. Implement secure CSV validation/import, batch number allocation, GUID per row, transactionally staged row states, paged authorized read and outcome update APIs, idempotent upload. Generalize trigger envelope for manual and API initiation; leave AutoSys/DB polling as future adapter.

## Proposed target file groups (validate actual repo names first)

/Unity.Capability.Data/; /Unity.DCMS/Import/; /Unity.DCMS/Storage/; /Unity.DCMS.Tests/

## Definition of done / acceptance evidence

BE or API uploads safe CSV; DB stores batch+unique row IDs; queried status matches row outcomes; duplicate upload policy is deterministic; no CSV body shipped over Kafka.

## Functional, API and negative regression

Malformed headers/quotes, encoding, duplicate account keys, oversized upload, unauthorized data access, partially staged batch tested.

## Guardrails / explicitly out of scope

No arbitrary SQL capability and no unapproved production file import.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-11: Build CSV/API trigger and DCMS batch/row staging interface. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 106: jobs/JOB-11-input-trigger-staging.md -->

---

<!-- BEGIN SOURCE 107: jobs/JOB-12-cyberark-operations.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-12 — Reconcile CyberArk primitives and implement missing reusable handlers

**Priority:** P0  
**Dependencies:** JOB-00, JOB-02, JOB-04  
**Suggested lane:** CyberArk capability  
**Planning target:** Nov 15–22 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Inventory existing real CyberArk integration. Expose vetted GetAccount, in-memory custom attribute patch, and AddOrUpdateAccount as registered handlers where missing. Require platform-supported attribute validation, revision checks, privileges, structured failures, reconciliation when API response lost. Host embedded sequential BOB subworkflow or adapt existing worker to shared interpreter.

## Proposed target file groups (validate actual repo names first)

/Unity.Capability.CyberArk/Operations/; /Unity.Capability.CyberArk/Runtime/; /Unity.Capability.CyberArk.Tests/

## Definition of done / acceptance evidence

A test row reads account, AMIE maps attributes, in-memory patch is validated, authorized add/update occurs and outcome carries external reference; primitives appear in registry and are reusable by another workflow.

## Functional, API and negative regression

No account found, forbidden safe, unsupported custom attribute, revision conflict, timeout after possible write, duplicate batch row and permission denied handled.

## Guardrails / explicitly out of scope

Do not hardcode DCMS process order or AMIE decisions in CyberArk service; no PROD account mutation without approval.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-12: Reconcile CyberArk primitives and implement missing reusable handlers. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 107: jobs/JOB-12-cyberark-operations.md -->

---

<!-- BEGIN SOURCE 108: jobs/JOB-13-reporting-email.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-13 — Connect reporting aggregation and independent Email Capability

**Priority:** P0  
**Dependencies:** JOB-02, JOB-07, JOB-11  
**Suggested lane:** Reporting / Email  
**Planning target:** Nov 18–23 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Inventory existing Email capability; implement or adapt typed `Reporting.GenerateBatchReport` and `Email.RequestNotification` operation descriptors and Kafka contracts. Report reads persisted batch row states through owner API, includes success/failure/no-change/skipped/unknown plus reason. AMIE picks approved template/recipients; email outcome independent from CyberArk updates.

## Proposed target file groups (validate actual repo names first)

/Unity.Capability.Reporting/; /Unity.Capability.Email/; /Unity.Reporting.Tests/; /Unity.Email.Tests/

## Definition of done / acceptance evidence

Five-row DCMS test generates report identical to stored results; Kafka email command accepted and outcome recorded with correlation; no SMTP/email handling in BOB.

## Functional, API and negative regression

Unknown row outcomes, restricted data in report, recipient policy denial, duplicate notification request, SMTP failure and email late completion tested.

## Guardrails / explicitly out of scope

Do not assume actual corporate email adapter or transport is approved; use marked simulator if not.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-13: Connect reporting aggregation and independent Email Capability. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 108: jobs/JOB-13-reporting-email.md -->

---

<!-- BEGIN SOURCE 109: jobs/JOB-14-be-monitor.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-14 — Implement business progress, BPMN run monitor and near-real-time updates

**Priority:** P0  
**Dependencies:** JOB-07, JOB-08, JOB-09  
**Suggested lane:** BE monitoring  
**Planning target:** Nov 19–24 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Create authorized read APIs/projection for batch/row counts and technical run/activity/correlation timeline. Implement role-specific Business Work Queue and BPMN Run Monitor; integrate SignalR/SSE only to push changes, reload authoritative SQL-backed state after reconnect. Mask privileged data and paginate row results.

## Proposed target file groups (validate actual repo names first)

/Unity.BE/Components/Pages/BusinessWorkQueue.razor; /Unity.BE/Components/Pages/RunMonitor.razor; /Unity.BE/Services/RunMonitorApiClient.cs

## Definition of done / acceptance evidence

Business user sees meaningful batch counts/percent/reasons without workflow graph; support sees same process on BPMN overlay with accurate Kafka/AMIE/handler evidence; status remains correct after reconnect.

## Functional, API and negative regression

Other user's batch read denied, lagged projection timestamp clear, duplicate live update, reconnect and 1000-row pagination tested.

## Guardrails / explicitly out of scope

Do not subscribe browser directly to Kafka or treat SignalR as audit store.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-14: Implement business progress, BPMN run monitor and near-real-time updates. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 109: jobs/JOB-14-be-monitor.md -->

---

<!-- BEGIN SOURCE 110: jobs/JOB-15-rbac-operator.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-15 — Implement policy enforcement, run controls and runbooks

**Priority:** P0  
**Dependencies:** JOB-06, JOB-08, JOB-14  
**Suggested lane:** Security / Operations  
**Planning target:** Nov 19–25 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Map real SSO roles to resource-scoped action permissions; protect all API/microservice dispatches. Add Operator Console with PauseRequested/Paused, Resume, Cancel, guarded Retry/Restart; compare-and-swap revision, command ID dedupe, actor/reason/change metadata, runbook version and audit. Add read-only audit view.

## Proposed target file groups (validate actual repo names first)

/Unity.BE/Components/Pages/OperationsConsole.razor; /Unity.BOB.Central/Controls/; /Unity.Security/Policies/; /Unity.Controls/Runbooks/

## Definition of done / acceptance evidence

End user cannot operate or view unauthorized scopes; operator controls reflect actual safe transitions; restart creates linked run; all actions leave audit event with actor and time.

## Functional, API and negative regression

Pause in-flight CyberArk write, forged role, stale ETag, double-click, retry uncertain write, self-approval and auditor mutation denied.

## Guardrails / explicitly out of scope

Actual bank control IDs and runbook authority must be obtained; not fabricated.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-15: Implement policy enforcement, run controls and runbooks. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 110: jobs/JOB-15-rbac-operator.md -->

---

<!-- BEGIN SOURCE 111: jobs/JOB-16-release-package.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-16 — Build immutable config package, approval and Operations promotion gates

**Priority:** P0 design / PROD gated  
**Dependencies:** JOB-01, JOB-08, JOB-09  
**Suggested lane:** Release / Compliance  
**Planning target:** Nov 20–26 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Package BPMN, AMIE rule versions, operation/message dependency locks, logical bindings, owner/runbook refs and test evidence into immutable signed digest. Add draft/review/approve/publish/activate/retire APIs and BE Release Center. Integrate bank's existing change/approval process when available; role-separated Operations promotion, not developer PROD login.

## Proposed target file groups (validate actual repo names first)

/Unity.Release/; /Unity.BE/Components/Pages/ReleaseCenter.razor; /Unity.Release.Tests/

## Definition of done / acceptance evidence

Exact package bytes have same digest DEV and UAT; only approved environment bindings differ; unauthorized or unsigned PROD activation is blocked and audited; rollback selects previous version for new runs.

## Functional, API and negative regression

Tampered manifest, missing AMIE/capability version, fake ServiceNow ticket, wrong deployer, missing UAT evidence, inaccessible secrets/bindings and self-approval fail preflight.

## Guardrails / explicitly out of scope

Do not claim automatic production deployment before actual Wells Fargo controls and CI/CD integrations exist.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-16: Build immutable config package, approval and Operations promotion gates. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 111: jobs/JOB-16-release-package.md -->

---

<!-- BEGIN SOURCE 112: jobs/JOB-17-regression-ci.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-17 — Build full API, BPMN, role-denial and fault-injection regression

**Priority:** P0  
**Dependencies:** JOB-01, JOB-02, JOB-05; integrate others as arrive  
**Suggested lane:** QA / Integration  
**Planning target:** Nov 14–29 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Create CI test projects for R01–R18 from regression matrix: manifest+schema+policy, parser semantics, AMIE adapter, Kafka duplicate, SQL restart, auth, controls, DCMS 5-row fixture, report/email. Publish OpenAPI and test results. Add browser Playwright-equivalent using already approved tools; screenshots and audit evidence.

## Proposed target file groups (validate actual repo names first)

/Unity.Tests.Contracts/; /Unity.Tests.Integration/; /Unity.Tests.E2E/; /.github/workflows/ or bank-approved CI pipeline

## Definition of done / acceptance evidence

All implemented BE actions are exercised through API; test evidence includes fixture/version/commit/digest/UTC; CI fails contract drift and known unsafe cases; no silent mock behavior.

## Functional, API and negative regression

Run fault injection, unauthorized APIs, broker outage, crash-after-write, cross-scope reads, unsupported BPMN, missing rule and release-gate checks.

## Guardrails / explicitly out of scope

Avoid introducing unapproved CI plugins or writing secrets to build logs.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-17: Build full API, BPMN, role-denial and fault-injection regression. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 112: jobs/JOB-17-regression-ci.md -->

---

<!-- BEGIN SOURCE 113: jobs/JOB-18-dcms-e2e.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-18 — Integrate and validate real DCMS end-to-end vertical slice

**Priority:** P0  
**Dependencies:** JOB-02 through JOB-15 as relevant  
**Suggested lane:** DCMS pilot / Integration  
**Planning target:** Nov 21–27 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Configure DCMS in BE from registered primitives; upload CSV, stage batch and row GUIDs, start central BOB, run sequential embedded CyberArk BOB with existing AMIE mapping, persist confirmed row results, publish progress, generate report and send via Email capability through Kafka. Label simulator vs actual integration.

## Proposed target file groups (validate actual repo names first)

/Unity.DCMS/Configurations/; /Unity.DCMS.Tests/; /docs/testing/DCMS-RUN-EVIDENCE.md

## Definition of done / acceptance evidence

Five-row fixture produces correct audit, counts, per-row reasons and report; one safe actual approved nonprod CyberArk update if available; no modification required in BOB Core for DCMS.

## Functional, API and negative regression

Unknown external write does not blindly retry; failure report accurate; role/cancel/restart/concurrent batch tests pass; email failure separate.

## Guardrails / explicitly out of scope

No implicit promise of PROD release or access to live PAM accounts.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-18: Integrate and validate real DCMS end-to-end vertical slice. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 113: jobs/JOB-18-dcms-e2e.md -->

---

<!-- BEGIN SOURCE 114: jobs/JOB-19-second-workload.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-19 — Prove configuration reuse with Hygiene or Onboarding

**Priority:** P1 target  
**Dependencies:** JOB-18  
**Suggested lane:** Application / Reuse  
**Planning target:** Nov 24–29 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Pick second workload matching existing capability data and approvals. Configure different AMIE rule and BPMN flow that reuses `CyberArk.GetAccount` or another primitive. For Policy Drift moving accounts to safes, use read-only finding until `MoveAccount` exists and authorization/reconcile policy is approved.

## Proposed target file groups (validate actual repo names first)

/Unity.Hygiene/Configurations/ or /Unity.Onboarding/Configurations/; /Unity.Reuse.Tests/

## Definition of done / acceptance evidence

Second end-to-end workflow built through BE by reusing exact handler/service versions; zero app-specific BOB Core change and zero required CyberArk handler change; separate business summary and audit.

## Functional, API and negative regression

Unauthorized remediation, missing operation, wrong safe, rule denial, new app data scope and audit visibility tested.

## Guardrails / explicitly out of scope

No rushed high-risk privileged mutations solely to claim a second demo.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-19: Prove configuration reuse with Hygiene or Onboarding. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 114: jobs/JOB-19-second-workload.md -->

---

<!-- BEGIN SOURCE 115: jobs/JOB-20-demo-handoff.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# JOB-20 — Perform integrated demo, review readiness, record gaps and owners

**Priority:** P0  
**Dependencies:** JOB-17, JOB-18; JOB-19 optional  
**Suggested lane:** Integration / Program  
**Planning target:** Nov 27–30 (2026; target, not delivery promise).  
**Status:** Not started / not verified from provided handoff; update against actual repository.

## Objective and precise work

Execute agreed UI/API demonstration script, rerun P0 regressions against exact demo package, reconcile docs with actual codepaths, collect bank control blockers, prepare clean build instructions and rollback/runbook. Mark which integrations are real, simulated, or future. Deliver evidence/known defects and next-step priority with owners.

## Proposed target file groups (validate actual repo names first)

/docs/testing/DEMO-EVIDENCE.md; /docs/roadmap/KNOWN-GAPS.md; /docs/decisions/REAL-REPOSITORY-MAP.md

## Definition of done / acceptance evidence

An authorized tester can build/run demo from clean instructions, show real package digest, automated results and audit, validate DCMS scenarios, and explain bank PROD gates honestly.

## Functional, API and negative regression

Cold-start run, missing service, expired identity, UI auth denial, lost Kafka and replay/run-control data correctness tested.

## Guardrails / explicitly out of scope

Do not describe a mock as release-ready or a pending CA as approved.

## Required PR report

1. Actual file paths in `/Project/Folder/File.cs` format; New / Updated / Deleted / No Change.
2. Existing interfaces reused, especially AMIE, DI/Blazor patterns and Kafka infrastructure.
3. OpenAPI additions/changes, schema/contract compatibility and version diff.
4. Tests run with exact commands, outcomes, screenshots/trace and failure cases; link CI evidence.
5. Safety/security validation, bank control blockers, unresolved assumptions, and integration handoff to dependent jobs.

## Copy-ready DEVIN instruction

> Execute JOB-20: Perform integrated demo, review readiness, record gaps and owners. Read AGENTS.md, docs/00-START-HERE.md and the relevant architecture/contract/UI/testing documents. First inspect existing source and map the conceptual paths to real paths, avoiding duplicate AMIE/BOB components. Implement only this scope and its verified dependencies, add API/contract/negative tests, and submit a PR with actual file paths, evidence, blockers and Files and Structure Summary. Do not change unrelated workloads or bypass bank release controls.

<!-- END SOURCE 115: jobs/JOB-20-demo-handoff.md -->

---

<!-- BEGIN SOURCE 116: jobs/bpmn/BE-21-shared-blazor-component-foundation.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-21 - Shared Blazor component foundation

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** JOB-00, UI-10

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

BE shell, reusable async/field/permission/binding components.

## Implementation actions

Implement reusable SchemaField, TypedBindingPicker, AsyncStateView, ScopedPermissionAction, validation issue list, modal confirmation; follow existing Blazor/FluentValidation style.

## API / message contracts

GET contracts; POST binding validation. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Component tests for Loading/Empty/Denied/Error, keyboard labels, classified data redaction, API 403, no hardcoded DCMS fields.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 116: jobs/bpmn/BE-21-shared-blazor-component-foundation.md -->

---

<!-- BEGIN SOURCE 117: jobs/bpmn/BE-22-workflow-wizard-and-library-lifecycle.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-22 - Workflow wizard and library lifecycle

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-21, JOB-01, UI-12

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

New/clone/save/revision/compare/library owner and workflow lifecycle.

## Implementation actions

Create scoped new workflow wizard; application/owner/purpose/template; draft creation; ETag edits; immutable version listing; handling of unsaved changes, revision conflicts and no permission.

## API / message contracts

POST/PUT /workflow-drafts; GET /workflows /versions /diff. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Save/reload roundtrip; duplicate name 409; conflict 412 preserves client edits; only authorized authors can edit.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 117: jobs/bpmn/BE-22-workflow-wizard-and-library-lifecycle.md -->

---

<!-- BEGIN SOURCE 118: jobs/bpmn/BE-23-first-party-bpmn-canvas-xml-plus-di.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-23 - First-party BPMN canvas XML plus DI

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-21, JOB-05

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

BPMN graph, SVG canvas, DI positions, connections and undo/redo.

## Implementation actions

Use approved existing component if present; otherwise in-repo SVG renderer + small JS gesture module. Add stable BPMN IDs, snap/pan/zoom, connectors, copy/delete, basic swimlanes, node list keyboard fallback, import/export. Keep XML/DI as source.

## API / message contracts

GET/PUT draft BPMN XML and ETag; import/export. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

XML+DI lossless supported roundtrip; no per-pointer Blazor interop; duplicate node IDs prevented; unknown import elements visible as unsupported.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 118: jobs/bpmn/BE-23-first-party-bpmn-canvas-xml-plus-di.md -->

---

<!-- BEGIN SOURCE 119: jobs/bpmn/BE-24-bpmn-palette-and-node-specific-inspector.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-24 - BPMN palette and node-specific inspector

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-23, SDK-31, BOB-37

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Element catalog with supported/unsupported badge and tabs General/Inputs/Outputs/Execution/Errors/Audit.

## Implementation actions

Implement inspectors for Start, End, ServiceTask, BusinessRuleTask, XOR, Call/Subprocess, sequential multi-instance and message wait. Display full BPMN families visually but block unsupported elements at publish.

## API / message contracts

GET element catalog, operation descriptor, rule descriptor; PUT draft binding. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Required host/timeout fields only for relevant types; publish rejection for unsupported; node selection switches inspector.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 119: jobs/bpmn/BE-24-bpmn-palette-and-node-specific-inspector.md -->

---

<!-- BEGIN SOURCE 120: jobs/bpmn/BE-25-schema-driven-data-binding-and-amie-rule-editor.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-25 - Schema-driven data binding and AMIE rule editor

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-24, BOB-38

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Dynamic typed field mappings and rule fact/output configuration.

## Implementation actions

Build versioned schema selectors and binding-source browser (workflow input, current row, prior output, AMIE output, env binding ref); show rule tests, type errors, secret masking; no arbitrary source code/SQL.

## API / message contracts

POST /bindings/validate, GET /amie/rules, POST /amie/tests. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Source type conflict blocks validate; missing AMIE fact highlighted; rule test cannot make CyberArk write; save/publish pins versions.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 120: jobs/bpmn/BE-25-schema-driven-data-binding-and-amie-rule-editor.md -->

---

<!-- BEGIN SOURCE 121: jobs/bpmn/BE-26-triggers-and-input-forms-builder.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-26 - Triggers and input forms builder

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-21, SDK-32, SDK-35

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Manual CSV, form, authenticated API, Kafka, AutoSys job-type configuration.

## Implementation actions

Implement trigger picker with schema hints. CSV upload uses managed fileRef; API outputs 202 runId; AutoSys job allowlist and sourceRunId mapping. Timer mode visually deferred unless implemented.

## API / message contracts

GET /trigger-types; PUT draft trigger; POST /uploads; POST /workflow-starts. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Invalid CSV rejected, API unauth denied, duplicate scheduler sourceRunId maps to same run, secrets hidden.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 121: jobs/bpmn/BE-26-triggers-and-input-forms-builder.md -->

---

<!-- BEGIN SOURCE 122: jobs/bpmn/BE-27-compiler-validation-panel-and-dev-test-bench.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-27 - Compiler validation panel and DEV test bench

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-24, BE-25, BOB-37

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Backend validate, per-node issue navigation, fixture-based safe test execution.

## Implementation actions

Show compiler issue codes by node/field and severity; link to selected inspector; add test mode fixtures for 5-row DCMS and guarded delete; mock/live DEV explicit; async status and test evidence.

## API / message contracts

POST /drafts/{id}/validate and /test-runs. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Nonexistent operation, wrong rule version, unsupported node, retry unsafe all block publish; tests preserve fixture mode.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 122: jobs/bpmn/BE-27-compiler-validation-panel-and-dev-test-bench.md -->

---

<!-- BEGIN SOURCE 123: jobs/bpmn/BE-28-workflow-version-review-and-release-wiring.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-28 - Workflow version review and release wiring

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-22, BE-27, JOB-16

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Version diff, approval, publish digest, environment binding refs.

## Implementation actions

Implement immutable publish wizard, revision comparison, ServiceNow change reference, approval evidence and release readiness; PROD activation backend blocked absent real controls.

## API / message contracts

POST /reviews, /publish, /releases/preflight, /activations. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Reviewer roles enforced; no self-approval when prohibited; digest unchanged DEV/UAT/PROD; direct API bypass denied.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 123: jobs/bpmn/BE-28-workflow-version-review-and-release-wiring.md -->

---

<!-- BEGIN SOURCE 124: jobs/bpmn/BE-29-business-work-queue-and-near-real-time-dashboard.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-29 - Business work queue and near-real-time dashboard

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-21, SDK-32, BOB-37

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Upload confirmation, batch cards/row reasons, progress and report links.

## Implementation actions

Use authorized projection APIs and SignalR/SSE updates with ordered revisions; GET snapshot on reconnect; status counts by app/batch; link technical monitor only to permitted roles.

## API / message contracts

GET /business/batches, /rows, /reports; authorized stream. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Counts sum to total; 250-row mock pagination; reconnect correct; business user cannot see private run details.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 124: jobs/bpmn/BE-29-business-work-queue-and-near-real-time-dashboard.md -->

---

<!-- BEGIN SOURCE 125: jobs/bpmn/BE-30-bpmn-runtime-monitor-controls-and-audit-views.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-30 - BPMN runtime monitor, controls and audit views

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-23, BOB-37, JOB-08, JOB-15

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Pinned BPMN diagram overlay, activity event timeline, pause/resume/cancel/restart, audit search.

## Implementation actions

Render status by BPMN node ID; query timeline with correlation; safe command dialogs with reason/runbook; show uncertain writes and distinct restart run; audit export masks secrets.

## API / message contracts

GET /runs snapshots /audit; POST /runs commands/restart. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Pause at checkpoints, not midwrite; 202 pending not success; unauthorized command denied; audit reconstructs actor/versions/ticket.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 125: jobs/bpmn/BE-30-bpmn-runtime-monitor-controls-and-audit-views.md -->

---

<!-- BEGIN SOURCE 126: jobs/bpmn/BOB-37-bpmn-2.0-compiler-shared-runtime-central-embedded-wait.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BOB-37 - BPMN 2.0 compiler, shared runtime, central/embedded wait

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** JOB-01, JOB-05, JOB-06, JOB-07, JOB-08

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Supported subset semantics + state durability + Kafka waits.

## Implementation actions

Validate BPMN XML/DI and executable graph; start/end, service/rule, XOR, call, sequential multi-instance, correlated message wait; share core interpreter; central MSSQL persistence + embedded host; safe run commands and audit.

## API / message contracts

POST validate, start, events, safe run control endpoints. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Unsupported node blocks publish; 3-row ordered; crash/restart + duplicate event does not replay writes; pause at safe checkpoint.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 126: jobs/bpmn/BOB-37-bpmn-2.0-compiler-shared-runtime-central-embedded-wait.md -->

---

<!-- BEGIN SOURCE 127: jobs/bpmn/BOB-38-existing-amie-adapter-and-typed-binding-graph.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BOB-38 - Existing AMIE adapter and typed binding graph

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** JOB-00, JOB-04, SDK-31

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Use already written AMIE engine in BOB and capability host.

## Implementation actions

Inspect actual AMIE rule/manifest API; expose metadata with existing engine; build typed fact/outcome adapter and version pinning; no duplicate evaluator or arbitrary expression execution.

## API / message contracts

GET rule descriptors and rule test API; BOB rule task executor. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Correct rule outputs; missing version blocks; local AMIE calls need no central per-row roundtrip.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 127: jobs/bpmn/BOB-38-existing-amie-adapter-and-typed-binding-graph.md -->

---

<!-- BEGIN SOURCE 128: jobs/bpmn/INDEX.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# DEVIN BPMN / UI / Capability Work Packets v1.1

Use **JOB-00 and JOB-01 first**. These are refinements to existing `jobs/` and `jobs/interaction/`, not competing architecture. `/BusinessEnablement/` paths in specs are proposed; use actual repo locations found in read-only source audit.

| ID | Priority | Dependencies | Task |
|---|---|---|---|
| [BE-21](BE-21-shared-blazor-component-foundation.md) | P0 | JOB-00, UI-10 | Shared Blazor component foundation |
| [BE-22](BE-22-workflow-wizard-and-library-lifecycle.md) | P0 | BE-21, JOB-01, UI-12 | Workflow wizard and library lifecycle |
| [BE-23](BE-23-first-party-bpmn-canvas-xml-plus-di.md) | P0 | BE-21, JOB-05 | First-party BPMN canvas XML plus DI |
| [BE-24](BE-24-bpmn-palette-and-node-specific-inspector.md) | P0 | BE-23, SDK-31, BOB-37 | BPMN palette and node-specific inspector |
| [BE-25](BE-25-schema-driven-data-binding-and-amie-rule-editor.md) | P0 | BE-24, BOB-38 | Schema-driven data binding and AMIE rule editor |
| [BE-26](BE-26-triggers-and-input-forms-builder.md) | P0 | BE-21, SDK-32, SDK-35 | Triggers and input forms builder |
| [BE-27](BE-27-compiler-validation-panel-and-dev-test-bench.md) | P0 | BE-24, BE-25, BOB-37 | Compiler validation panel and DEV test bench |
| [BE-28](BE-28-workflow-version-review-and-release-wiring.md) | P0 | BE-22, BE-27, JOB-16 | Workflow version review and release wiring |
| [BE-29](BE-29-business-work-queue-and-near-real-time-dashboard.md) | P0 | BE-21, SDK-32, BOB-37 | Business work queue and near-real-time dashboard |
| [BE-30](BE-30-bpmn-runtime-monitor-controls-and-audit-views.md) | P0 | BE-23, BOB-37, JOB-08, JOB-15 | BPMN runtime monitor, controls and audit views |
| [SDK-31](SDK-31-operation-registry-and-automatic-be-schema-integration.md) | P0 | JOB-00, JOB-01, JOB-02, JOB-03 | Operation registry and automatic BE schema integration |
| [SDK-32](SDK-32-nas-ef-core-owned-data-api-integration.md) | P0 | JOB-00, SDK-31 | NAS EF Core owned-data API integration |
| [SDK-33](SDK-33-cyberark-dcms-reusable-primitives.md) | P0 | SDK-31, BOB-38, JOB-12 | CyberArk DCMS reusable primitives |
| [SDK-34](SDK-34-cyberark-guarded-account-delete-operation.md) | P1 | SDK-33, BOB-37, BE-30 | CyberArk guarded Account Delete operation |
| [SDK-35](SDK-35-autosys-scheduler-trigger-adapter.md) | P1 | JOB-00, BE-26, SDK-31 | AutoSys scheduler trigger adapter |
| [SDK-36](SDK-36-policy-drift-reusable-zip-ini-ef-operations.md) | P1 | SDK-32, SDK-35, BOB-38 | Policy Drift reusable ZIP/INI/EF operations |
| [BOB-37](BOB-37-bpmn-2.0-compiler-shared-runtime-central-embedded-wait.md) | P0 | JOB-01, JOB-05, JOB-06, JOB-07, JOB-08 | BPMN 2.0 compiler, shared runtime, central/embedded wait |
| [BOB-38](BOB-38-existing-amie-adapter-and-typed-binding-graph.md) | P0 | JOB-00, JOB-04, SDK-31 | Existing AMIE adapter and typed binding graph |
| [INT-39](INT-39-dcms-integrated-ui-to-kafka-to-email-proof.md) | P0 | BE-26, BE-27, BE-29, SDK-32, SDK-33, BOB-37, BOB-38 | DCMS integrated UI-to-Kafka-to-email proof |
| [QA-40](QA-40-complete-ui-api-flow-and-second-workload-regression.md) | P0 | BE-21..30, SDK-31..36 as enabled, INT-39 | Complete UI/API flow and second-workload regression |

## Suggested parallel lanes

1. **Contract gate:** JOB-00, JOB-01, SDK-31 and BOB-38 contract reconciliation. Do not create incompatible interfaces in parallel.
2. **Foundation lane:** BOB-37, SDK-31/32/33, BE-21/22/23 and platform Kafka/audit jobs.
3. **Composition lane:** BE-24/25/26/27/28 and operation/rule registry.
4. **Proof lane:** BE-29/30, INT-39, QA-40 and one second no-code workflow reuse.
5. **Second-pilot lane (conditional):** SDK-35+36 Policy Drift; SDK-34 account-delete mock, all gated by safe scopes.

## Stop conditions

- No real NAS controllers/EF owner verified -> implement mock/adapter interface only and report blocked real NAS integration.
- No approved CyberArk delete scope -> only mock/non-destructive account-delete demo.
- No AutoSys access -> demonstrate secure adapter contract using a signed/dev test trigger, not invent live scheduler integration.
- Any missing bank control approval -> DEV demo remains separate from PROD release.

<!-- END SOURCE 128: jobs/bpmn/INDEX.md -->

---

<!-- BEGIN SOURCE 129: jobs/bpmn/INT-39-dcms-integrated-ui-to-kafka-to-email-proof.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# INT-39 - DCMS integrated UI-to-Kafka-to-email proof

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-26, BE-27, BE-29, SDK-32, SDK-33, BOB-37, BOB-38

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

One real vertical slice from CSV to dashboard and report.

## Implementation actions

Wire BE upload to data staging and central BOB, Kafka to embedded CyberArk BOB, AMIE mappings, rows/outcome/audit, report/email capability and progress projections. Start with 5-row fixture; mark mock EPV effects.

## API / message contracts

POST upload/start; run progress/event/report APIs. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

All 5 row cases, batch count equality, Kafka idempotence, report/email separate, audit reconstruction, role-denial regression.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 129: jobs/bpmn/INT-39-dcms-integrated-ui-to-kafka-to-email-proof.md -->

---

<!-- BEGIN SOURCE 130: jobs/bpmn/QA-40-complete-ui-api-flow-and-second-workload-regression.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# QA-40 - Complete UI/API flow and second-workload regression

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** BE-21..30, SDK-31..36 as enabled, INT-39

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Validate reusability and demo readiness.

## Implementation actions

Automate all new CMP actions and prior 107 controls; BPMN import/export + DI; mocked side-effect tests; integrated DCMS; second configured workflow (read-only hygiene, NAS or Policy Drift if adapter ready); collect evidence.

## API / message contracts

CI suite, signoff-ready test matrix, demo runbook. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Evidence proves no new handler changes for second configured workflow; all failures/denials/audit; report explicit scope not executed.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 130: jobs/bpmn/QA-40-complete-ui-api-flow-and-second-workload-regression.md -->

---

<!-- BEGIN SOURCE 131: jobs/bpmn/SDK-31-operation-registry-and-automatic-be-schema-integration.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-31 - Operation registry and automatic BE schema integration

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** JOB-00, JOB-01, JOB-02, JOB-03

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Register compiled handlers and publish trusted manifest; resolve in BE.

## Implementation actions

Inspect existing capability SDK; implement strongly typed operation/descriptor; DI handler registration via trusted assembly; manifest validation; approved release publication; deprecation and compatibility.

## API / message contracts

POST capability manifest with deploy identity; GET registry operations. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

New approved operation shows in BE without Razor change; duplicate key rejected; scan alone never activates PROD.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 131: jobs/bpmn/SDK-31-operation-registry-and-automatic-be-schema-integration.md -->

---

<!-- BEGIN SOURCE 132: jobs/bpmn/SDK-32-nas-ef-core-owned-data-api-integration.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-32 - NAS EF Core owned-data API integration

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** JOB-00, SDK-31

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Find actual NAS API EF models and publish typed data operations.

## Implementation actions

Audit NAS code/Swagger/DbContext/owner; reuse existing EF API operations; add StageBatch/GetRowsPage/MarkOutcome only where missing/authorized; concurrency and pagination; avoid cross-service DbContext.

## API / message contracts

Typed NAS capability endpoints and operation manifest. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

One BE-configured service task roundtrips real DEV API/EF; auth failure; repeat outcome idempotent; no raw SQL API.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 132: jobs/bpmn/SDK-32-nas-ef-core-owned-data-api-integration.md -->

---

<!-- BEGIN SOURCE 133: jobs/bpmn/SDK-33-cyberark-dcms-reusable-primitives.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-33 - CyberArk DCMS reusable primitives

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** SDK-31, BOB-38, JOB-12

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Expose GetAccount/ApplyCustomAttributes/AddOrUpdate with verified handler contracts.

## Implementation actions

Inventory existing CyberArk client; build typed versioned operations and side-effect/reconciliation policy; AMIE maps custom fields; preserve in-memory update before API.

## API / message contracts

CyberArk operation manifest + local dispatcher. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

5-row DCMS passes; timeout marks UNKNOWN; account write confirmed separately from rule pass; no DCMS conditionals inside generic service.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 133: jobs/bpmn/SDK-33-cyberark-dcms-reusable-primitives.md -->

---

<!-- BEGIN SOURCE 134: jobs/bpmn/SDK-34-cyberark-guarded-account-delete-operation.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-34 - CyberArk guarded Account Delete operation

**Priority:** P1 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** SDK-33, BOB-37, BE-30

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Narrow external destructive operation with approval and verification.

## Implementation actions

Inspect supported CyberArk API endpoint; declare destructive operation with permission/reason/change and expected state; enforce approval token scope; mock first; verification read and uncertain reconcile.

## API / message contracts

Delete operation descriptor + approvals/wait contract. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

No delete for unapproved/changed account; mock nonprod green path; duplicate command no double side effect.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 134: jobs/bpmn/SDK-34-cyberark-guarded-account-delete-operation.md -->

---

<!-- BEGIN SOURCE 135: jobs/bpmn/SDK-35-autosys-scheduler-trigger-adapter.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-35 - AutoSys scheduler trigger adapter

**Priority:** P1 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** JOB-00, BE-26, SDK-31

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Secure job-triggered workflow start (not full AEWS product rewrite).

## Implementation actions

Find actual AutoSys job command and version; build approved script/HTTP adapter and allowlisted endpoint with job name, sourceRunId, correlation; optionally defer AEWS polling; log source identity.

## API / message contracts

POST /workflow-triggers/autosys and idempotency schema. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Duplicate job run returns same runId, forged identity forbidden, overlap policy recorded; no scheduler PROD access in demo.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 135: jobs/bpmn/SDK-35-autosys-scheduler-trigger-adapter.md -->

---

<!-- BEGIN SOURCE 136: jobs/bpmn/SDK-36-policy-drift-reusable-zip-ini-ef-operations.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-36 - Policy Drift reusable ZIP/INI/EF operations

**Priority:** P1 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** SDK-32, SDK-35, BOB-38

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

Preserve Policy Drift existing logic behind registered operations.

## Implementation actions

Find legacy parser, real PolicyId sanitizer, original SQL baseline query; wrap nested ZIP extraction/INI parse, normalize, compare, EF result save and reasons. Do not invent new policy model; compare original SQL to proposed EF logic.

## API / message contracts

Policy capability manifest, rule definitions and scheduled workflow binding. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

NO_DRIFT, DRIFT, MISSING_BASELINE, invalid INI, nested ZIP, duplicate and failure tests; no silent exclusion.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.

<!-- END SOURCE 136: jobs/bpmn/SDK-36-policy-drift-reusable-zip-ini-ef-operations.md -->

---

<!-- BEGIN SOURCE 137: jobs/interaction/INDEX.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI + SDK v1.0 Detailed DEVIN Job Index

These are **subtask refinements** of existing JOB-00..JOB-20, not a competing roadmap. Actual source paths and namespaces must be confirmed during SDK-10/JOB-00. Do not run all tickets in parallel before JOB-01 contract freeze.

| Ticket | Priority | Existing jobs | Dependencies | Goal |
|---|---|---|---|---|
| [SDK-10](SDK-10-repo-and-contract-seam-audit.md) | P0 | JOB-00, JOB-01 | None | Repo and contract seam audit |
| [SDK-11](SDK-11-trusted-handler-registration-and-di-sdk.md) | P0 | JOB-02 | SDK-10 | Trusted handler registration and DI SDK |
| [SDK-12](SDK-12-capability-registry-and-trusted-publication.md) | P0 | JOB-03 | SDK-11 | Capability registry and trusted publication |
| [SDK-13](SDK-13-existing-amie-adapter-and-rule-metadata.md) | P0 | JOB-04 | SDK-10, SDK-11 | Existing AMIE adapter and rule metadata |
| [SDK-14](SDK-14-shared-bob-operation-dispatcher-and-host-modes.md) | P0 | JOB-05, JOB-06 | SDK-11, SDK-13 | Shared BOB operation dispatcher and host modes |
| [SDK-15](SDK-15-kafka-inbox-outbox-and-command-contracts.md) | P0 | JOB-07 | SDK-11, SDK-14 | Kafka inbox/outbox and command contracts |
| [SDK-16](SDK-16-audit,-authorization-and-operational-controls.md) | P0 | JOB-08, JOB-15 | SDK-11, SDK-14 | Audit, authorization and operational controls |
| [SDK-17](SDK-17-capability-service-template-and-reusable-skill-update.md) | P0 | JOB-02, JOB-12, JOB-13 | SDK-11, SDK-12 | Capability service template and reusable skill update |
| [SDK-18](SDK-18-dcms-vertical-slice-plus-second-workload-reuse-proof.md) | P0 | JOB-11..JOB-13, JOB-18, JOB-19 | SDK-12, SDK-13, SDK-14, SDK-15, SDK-16, UI-15 | DCMS vertical slice plus second-workload reuse proof |
| [UI-10](UI-10-be-shell,-screen-routing-and-role-scoped-api-clients.md) | P0 | JOB-09, JOB-15 | SDK-10 | BE shell, screen routing and role-scoped API clients |
| [UI-11](UI-11-capability-catalog,-inspector-and-onboarding-wizard.md) | P0 | JOB-03, JOB-10 | UI-10, SDK-12 | Capability Catalog, inspector and onboarding wizard |
| [UI-12](UI-12-application-studio-and-workflow-library-lifecycle.md) | P0 | JOB-10, JOB-16 | UI-10, SDK-12 | Application Studio and Workflow Library lifecycle |
| [UI-13](UI-13-blazor-bpmn-2.0-canvas-and-typed-operation-inspector.md) | P0 | JOB-09, JOB-05 | UI-10, SDK-14 | Blazor BPMN 2.0 canvas and typed operation inspector |
| [UI-14](UI-14-amie-binding-picker-and-trigger-forms-editor.md) | P0 | JOB-04, JOB-10, JOB-11 | UI-10, SDK-13, UI-13 | AMIE binding picker and trigger/forms editor |
| [UI-15](UI-15-business-work-queue-and-bpmn-run-monitor.md) | P0 | JOB-14, JOB-18 | UI-10, SDK-14, SDK-16 | Business Work Queue and BPMN Run Monitor |
| [UI-16](UI-16-operator-controls,-runbooks-and-audit-screens.md) | P0 | JOB-15, JOB-08 | UI-10, SDK-16 | Operator controls, runbooks and audit screens |
| [UI-17](UI-17-environment-release-regression-+-107-control-proof.md) | P0 | JOB-16, JOB-17, JOB-20 | UI-10, SDK-12, SDK-16 | Environment/Release/Regression + 107-control proof |

## Parallel delivery lanes

- Lane 0 (gate): SDK-10/JOB-00 source audit -> JOB-01 contract freeze.
- Lane 1 (SDK): SDK-11 -> SDK-12; in parallel SDK-13 after source audit; SDK-14 after SDK-11/13; SDK-15/16 after host model.
- Lane 2 (Blazor): UI-10 -> UI-11/12/13; UI-14 after rule and designer contracts; UI-15/16 after real read/control APIs.
- Lane 3 (pilot): SDK-18 only after registry, BOB host, Kafka, audit and data/handlers viable; five-row fixture first.
- Lane 4 (QA/release): UI-17 and JOB-17 continuous, no late-stage bolt-on.

## Priority cuts under deadline pressure

P0: typed operation registration -> registry -> AMIE/BOB binding -> Kafka -> durable audit -> BE minimal designer and business dashboard -> DCMS five-row fixture. Keep RBAC, safe side effects, API regression and real control gate nonnegotiable.

P1 later: full designer gestures/custom rendering polish, advanced BPMN gateways, parallel batch processing, version migration in-flight, AutoSys ingestion, live ServiceNow integration and generic human forms.


<!-- END SOURCE 137: jobs/interaction/INDEX.md -->

---

<!-- BEGIN SOURCE 138: jobs/interaction/SDK-10-repo-and-contract-seam-audit.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-10 - Repo and contract seam audit

**Priority:** P0. **Refines original jobs:** JOB-00, JOB-01. **Dependencies:** None. **Status:** Proposed / repository verification required.

## Purpose and scope

Read-only repo map; crosswalk v0.9 proposed IUnityOperationHandler / actual AMIE, BOB, Kafka and CVIS services.

## Engineering implementation instructions

Inspect root AGENTS and actual solution, codebase references; map existing AMIE API/methods and data access patterns; inventory CyberArk operations and approved libraries; propose exact DTO and namespaces; identify duplicate abstractions to avoid.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.Contracts (actual path discovered); docs/decisions/OPEN-REPOSITORY-QUESTIONS.md

## Definition of done / measurable proof

A source-cited mapping exists for every proposed interface; maintain a gap list with owner and PR dependencies.

## Negative / security / recovery criteria

No source edits; reject claims that proposed SDK APIs already exist.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-10: Repo and contract seam audit. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 138: jobs/interaction/SDK-10-repo-and-contract-seam-audit.md -->

---

<!-- BEGIN SOURCE 139: jobs/interaction/SDK-11-trusted-handler-registration-and-di-sdk.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-11 - Trusted handler registration and DI SDK

**Priority:** P0. **Refines original jobs:** JOB-02. **Dependencies:** SDK-10. **Status:** Proposed / repository verification required.

## Purpose and scope

Typed handler + execution context + error taxonomy; approved assembly scanning or compiled registration; startup validation; version compatibility.

## Engineering implementation instructions

Implement common interface and registration; scan only compiled approved types; DI resolve by stable key/version; add manifest builder; validate duplicate key, missing schema/policy, write reconcile mode; instrument invocation and cancellation.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.Hosting/Registration/CapabilityRegistrationExtensions.cs; /Unity.Capabilities.Contracts/OperationDescriptor.cs

## Definition of done / measurable proof

Test handler appears locally by version and dispatches typed request; first operation does not require BE code.

## Negative / security / recovery criteria

Duplicate operation key prevents startup, arbitrary CLR name from workflow rejected, invalid schema rejected.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-11: Trusted handler registration and DI SDK. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 139: jobs/interaction/SDK-11-trusted-handler-registration-and-di-sdk.md -->

---

<!-- BEGIN SOURCE 140: jobs/interaction/SDK-12-capability-registry-and-trusted-publication.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-12 - Capability registry and trusted publication

**Priority:** P0. **Refines original jobs:** JOB-03. **Dependencies:** SDK-11. **Status:** Proposed / repository verification required.

## Purpose and scope

Versioned manifest publisher/registry admission/readiness and secure discovery APIs.

## Engineering implementation instructions

Implement manifest validation/publisher identity, code-release provenance/digest, register vs available states; GET capability/operation/version/schema/readiness with role and scope filtering; provide diagnostics.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.Registry/ManifestController.cs; /Unity.Capabilities.Registry/ManifestAdmissionService.cs

## Definition of done / measurable proof

An approved deployed service is discoverable with schemas, correct readiness and stable contract version.

## Negative / security / recovery criteria

Unapproved manifest or unhealthy deployment not executable; missing policy blocks publication; no auto-prod authorization.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-12: Capability registry and trusted publication. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 140: jobs/interaction/SDK-12-capability-registry-and-trusted-publication.md -->

---

<!-- BEGIN SOURCE 141: jobs/interaction/SDK-13-existing-amie-adapter-and-rule-metadata.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-13 - Existing AMIE adapter and rule metadata

**Priority:** P0. **Refines original jobs:** JOB-04. **Dependencies:** SDK-10, SDK-11. **Status:** Proposed / repository verification required.

## Purpose and scope

Thin wrapper around existing AMIE rules, metadata and schema; typed fact binding; exact rule version.

## Engineering implementation instructions

Read existing AMIE API; implement adapter to evaluate typed facts locally; publish rule descriptor; compile type validation; pinned version and reason output; tests for false/skip/NoChange.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.AMIE/AmieRuntimeAdapter.cs; docs/contracts/AMIE-RULE-DESCRIPTOR.md

## Definition of done / measurable proof

DCMS.AttributeMap rule fixture maps source row to approved typed patch via existing evaluator; embedded host has no central per-row roundtrip.

## Negative / security / recovery criteria

Do not build second AMIE runtime; missing facts/version or illegal field rejects publish; rule pass not treated as side-effect success.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-13: Existing AMIE adapter and rule metadata. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 141: jobs/interaction/SDK-13-existing-amie-adapter-and-rule-metadata.md -->

---

<!-- BEGIN SOURCE 142: jobs/interaction/SDK-14-shared-bob-operation-dispatcher-and-host-modes.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-14 - Shared BOB operation dispatcher and host modes

**Priority:** P0. **Refines original jobs:** JOB-05, JOB-06. **Dependencies:** SDK-11, SDK-13. **Status:** Proposed / repository verification required.

## Purpose and scope

One interpreter, local DI and central Kafka dispatch adapters; typed context and safe checkpoints.

## Engineering implementation instructions

Wire compiler operation binding to registry resolution, pinned version and host; local handler execution; durable central wait; sequential multi-instance and child workflow; pause/resume/cancel contract; schema mapping and optimistic concurrency.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BOB.Core/Runtime/WorkflowExecutor.cs; /BOB.Embedded/Execution/LocalOperationDispatcher.cs

## Definition of done / measurable proof

3-row sequential BPMN fixture follows same token semantics embedded and central; service task reaches registered handler and returns outcome.

## Negative / security / recovery criteria

Unsupported BPMN, missing rule/handler, duplicate outcome, pause-in-write and stale revision all safe.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-14: Shared BOB operation dispatcher and host modes. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 142: jobs/interaction/SDK-14-shared-bob-operation-dispatcher-and-host-modes.md -->

---

<!-- BEGIN SOURCE 143: jobs/interaction/SDK-15-kafka-inbox-outbox-and-command-contracts.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-15 - Kafka inbox/outbox and command contracts

**Priority:** P0. **Refines original jobs:** JOB-07. **Dependencies:** SDK-11, SDK-14. **Status:** Proposed / repository verification required.

## Purpose and scope

Transport for cross-service BOB tasks: logical topic contract, auth, correlation, idempotency, retry/reconcile and DLQ.

## Engineering implementation instructions

Integrate approved broker library; envelope schema; outbox with BOB waiting state; worker consumer verifies identity/permission/version; inbox dedup; correlated outcome; partitioning and trace; broker test harness.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.Kafka/CommandConsumer.cs; /BOB.Central/Messaging/OutcomeConsumer.cs

## Definition of done / measurable proof

Crash/retry fixture eventually completes exactly one workflow activity from a duplicated command; no duplicate side-effect invocation.

## Negative / security / recovery criteria

Cross-run correlation mismatch, poison message, topic ACL denial, unknown outcome and out-of-order events rejected/held.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-15: Kafka inbox/outbox and command contracts. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 143: jobs/interaction/SDK-15-kafka-inbox-outbox-and-command-contracts.md -->

---

<!-- BEGIN SOURCE 144: jobs/interaction/SDK-16-audit,-authorization-and-operational-controls.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-16 - Audit, authorization and operational controls

**Priority:** P0. **Refines original jobs:** JOB-08, JOB-15. **Dependencies:** SDK-11, SDK-14. **Status:** Proposed / repository verification required.

## Purpose and scope

Append-only MSSQL audit event schema, safe projections, direct auth checks, pause/resume/cancel/retry/restart APIs.

## Engineering implementation instructions

Implement read/write policy per app/scope; audit event append with UTC/version/change/correlation/run/row; runbook references; control reason and expected revision; work queue projection; denied-call events.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BOB.Persistence.MSSQL/Audit/AuditEventRepository.cs; /BOB.Central/Api/RunControlController.cs

## Definition of done / measurable proof

Rebuild one DCMS run and rule/write decisions from DB; operator pause reaches safe checkpoint; restart preserves original run.

## Negative / security / recovery criteria

Role spoofing, missing reason, stale ETag, secret leakage, uncertain write retry denied.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-16: Audit, authorization and operational controls. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 144: jobs/interaction/SDK-16-audit,-authorization-and-operational-controls.md -->

---

<!-- BEGIN SOURCE 145: jobs/interaction/SDK-17-capability-service-template-and-reusable-skill-update.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-17 - Capability service template and reusable skill update

**Priority:** P0. **Refines original jobs:** JOB-02, JOB-12, JOB-13. **Dependencies:** SDK-11, SDK-12. **Status:** Proposed / repository verification required.

## Purpose and scope

Reusable new service archetype/template and updated repository Skill for CyberArk, Email, Data, Reporting, Identity and Legacy.

## Engineering implementation instructions

Provide approved project scaffold with handler, DTO, manifest, Kafka wiring, AMIE/BOB adapters, health/audit tests and README; update .agents/skills/unity-capability-service with exact repo-validated conventions.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capability.Template/; /.agents/skills/unity-capability-service/SKILL.md

## Definition of done / measurable proof

Generate sample safe capability, compile/tests pass, manifest auto-discovers, BE inspector can bind with no special Razor code.

## Negative / security / recovery criteria

Template never generates PROD secret, arbitrary SQL/REST operation, unbounded broker subscription or assumed CA approval.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-17: Capability service template and reusable skill update. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 145: jobs/interaction/SDK-17-capability-service-template-and-reusable-skill-update.md -->

---

<!-- BEGIN SOURCE 146: jobs/interaction/SDK-18-dcms-vertical-slice-plus-second-workload-reuse-proof.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-18 - DCMS vertical slice plus second-workload reuse proof

**Priority:** P0. **Refines original jobs:** JOB-11..JOB-13, JOB-18, JOB-19. **Dependencies:** SDK-12, SDK-13, SDK-14, SDK-15, SDK-16, UI-15. **Status:** Proposed / repository verification required.

## Purpose and scope

End-to-end configured DCMS batch and one small Hygiene reuse scenario.

## Engineering implementation instructions

Stage CSV with batch number/row GUID, sequential row workflow; local CyberArk read/map/patch/upsert in non-prod; persist outcomes and report; Email capability via Kafka; show BE counts, BPMN overlay and audit; reuse GetAccount in a second configured process.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capability.CyberArk/Operations/; /Unity.Applications.DCMS/Configuration/ (actual paths discovered)

## Definition of done / measurable proof

5-row fixture with success/nochange/reject/skip/unknown yields reconciled results, restart no duplicate writes, independent email outcome.

## Negative / security / recovery criteria

No DCMS-specific SDK/BOB branches, no false real CyberArk test claims, no unsafe retry.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-18: DCMS vertical slice plus second-workload reuse proof. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 146: jobs/interaction/SDK-18-dcms-vertical-slice-plus-second-workload-reuse-proof.md -->

---

<!-- BEGIN SOURCE 147: jobs/interaction/UI-10-be-shell,-screen-routing-and-role-scoped-api-clients.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI-10 - BE shell, screen routing and role-scoped API clients

**Priority:** P0. **Refines original jobs:** JOB-09, JOB-15. **Dependencies:** SDK-10. **Status:** Proposed / repository verification required.

## Purpose and scope

Blazor nav/app context, typed API clients, busy/error/empty states, security checks, action IDs.

## Engineering implementation instructions

Build layout and route pages from UI-07; role/scope policy from backend; live region status with correlation; global env selection safe; action test selectors; no direct Kafka/SQL in browser.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Layout/UnityShell.razor; /BusinessEnablement/Services/UnityApiClient.cs

## Definition of done / measurable proof

19 route shells load scoped data and show denied state, proper keyboard/focus; real API behind each control.

## Negative / security / recovery criteria

Persona switcher wireframe never becomes auth bypass; direct unauthorized API is 403.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-10: BE shell, screen routing and role-scoped API clients. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 147: jobs/interaction/UI-10-be-shell,-screen-routing-and-role-scoped-api-clients.md -->

---

<!-- BEGIN SOURCE 148: jobs/interaction/UI-11-capability-catalog,-inspector-and-onboarding-wizard.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI-11 - Capability Catalog, inspector and onboarding wizard

**Priority:** P0. **Refines original jobs:** JOB-03, JOB-10. **Dependencies:** UI-10, SDK-12. **Status:** Proposed / repository verification required.

## Purpose and scope

CAT-01..04 OP-01..05 ON-01..06; searchable operations, schema/host/policy and approval/health distinction.

## Engineering implementation instructions

Implement registry querying, paging, manifest draft wizard, rule/operation schema renderer, safe DEV fixture test, request-new-primitive workflow.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Capabilities/CapabilityCatalog.razor; /BusinessEnablement/Components/Capabilities/OperationInspector.razor

## Definition of done / measurable proof

Published operation appears dynamically and insert service task reference; approved vs available shown separately.

## Negative / security / recovery criteria

Unapproved operation cannot bind; unknown side-effect/reconcile policy flagged; forbidden API denies.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-11: Capability Catalog, inspector and onboarding wizard. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 148: jobs/interaction/UI-11-capability-catalog,-inspector-and-onboarding-wizard.md -->

---

<!-- BEGIN SOURCE 149: jobs/interaction/UI-12-application-studio-and-workflow-library-lifecycle.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI-12 - Application Studio and Workflow Library lifecycle

**Priority:** P0. **Refines original jobs:** JOB-10, JOB-16. **Dependencies:** UI-10, SDK-12. **Status:** Proposed / repository verification required.

## Purpose and scope

APP-01..04 LIB-01..08; app composition, version diff, immutable lifecycle, ServiceNow metadata.

## Engineering implementation instructions

Build scoped application blueprint UI, library filters, draft clone/import, reviewer diff, submit/approve/publish/retire with separate identity and ETags.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Applications/ApplicationStudio.razor; /BusinessEnablement/Components/Workflows/WorkflowLibrary.razor

## Definition of done / measurable proof

Published version immutable, exact dependency lock displayed, new draft from clone.

## Negative / security / recovery criteria

Cannot self-approve, edit published, publish invalid, or bind unavailable version.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-12: Application Studio and Workflow Library lifecycle. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 149: jobs/interaction/UI-12-application-studio-and-workflow-library-lifecycle.md -->

---

<!-- BEGIN SOURCE 150: jobs/interaction/UI-13-blazor-bpmn-2.0-canvas-and-typed-operation-inspector.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI-13 - Blazor BPMN 2.0 canvas and typed operation inspector

**Priority:** P0. **Refines original jobs:** JOB-09, JOB-05. **Dependencies:** UI-10, SDK-14. **Status:** Proposed / repository verification required.

## Purpose and scope

DES-01..13; first-party SVG/JS canvas or already approved library; interoperable XML+DI.

## Engineering implementation instructions

Implement palette approved subset, drag/connect/pan/zoom, inspector selection, undo/redo, typed operation binding, save/validate/preview/export and error overlay; JS handles high-rate pointer events.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Workflows/BpmnDesigner.razor; /BusinessEnablement/wwwroot/js/bpmnCanvas.js

## Definition of done / measurable proof

Import/export preserves BPMN IDs and DI; backend compiles bound tasks; keyboard accessible node list; all 13 controls have tests.

## Negative / security / recovery criteria

Unsupported elements reject; invalid schema anchored; save 409 conflict preserves edits.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-13: Blazor BPMN 2.0 canvas and typed operation inspector. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 150: jobs/interaction/UI-13-blazor-bpmn-2.0-canvas-and-typed-operation-inspector.md -->

---

<!-- BEGIN SOURCE 151: jobs/interaction/UI-14-amie-binding-picker-and-trigger-forms-editor.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI-14 - AMIE binding picker and trigger/forms editor

**Priority:** P0. **Refines original jobs:** JOB-04, JOB-10, JOB-11. **Dependencies:** UI-10, SDK-13, UI-13. **Status:** Proposed / repository verification required.

## Purpose and scope

AMI-01..04 TRI-01..05; typed fact binding, rule preview, trigger schema and CSV validation.

## Engineering implementation instructions

Implement rule picker version+facts, compatible paths, approved fixture preview; manual CSV trigger schema, validation and upload; optional future triggers visible but unavailable.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Rules/AmieBindingInspector.razor; /BusinessEnablement/Components/Triggers/TriggerEditor.razor

## Definition of done / measurable proof

AMIE output maps to GetAccount/Upsert DTO; missing required fact returns node-specific error; CSV stages only by authorized API.

## Negative / security / recovery criteria

No arbitrary rule code, API source not implemented, raw CSV not in Kafka.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-14: AMIE binding picker and trigger/forms editor. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 151: jobs/interaction/UI-14-amie-binding-picker-and-trigger-forms-editor.md -->

---

<!-- BEGIN SOURCE 152: jobs/interaction/UI-15-business-work-queue-and-bpmn-run-monitor.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI-15 - Business Work Queue and BPMN Run Monitor

**Priority:** P0. **Refines original jobs:** JOB-14, JOB-18. **Dependencies:** UI-10, SDK-14, SDK-16. **Status:** Proposed / repository verification required.

## Purpose and scope

BUS-01..07 RUN-01..06; business aggregate view vs technical overlay, scoped live status.

## Engineering implementation instructions

Implement read APIs, paged row reasons, terminal count logic, report link; authorized technical BPMN overlay from published version and event timeline; SignalR or approved push plus GET refresh on reconnect.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Business/BatchQueue.razor; /BusinessEnablement/Components/Monitoring/RunMonitor.razor

## Definition of done / measurable proof

Business sees progress and reasons without technical details; Operators see exact activity/correlation; no fake percent.

## Negative / security / recovery criteria

Cross-user batch and sensitive payload redacted; reconnect corrects missed events.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-15: Business Work Queue and BPMN Run Monitor. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 152: jobs/interaction/UI-15-business-work-queue-and-bpmn-run-monitor.md -->

---

<!-- BEGIN SOURCE 153: jobs/interaction/UI-16-operator-controls,-runbooks-and-audit-screens.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI-16 - Operator controls, runbooks and audit screens

**Priority:** P0. **Refines original jobs:** JOB-15, JOB-08. **Dependencies:** UI-10, SDK-16. **Status:** Proposed / repository verification required.

## Purpose and scope

CTL-01..07 RB-01..04 ACC-01..03 AUD-01..04; privileged run actions and immutable evidence.

## Engineering implementation instructions

Implement reason+confirmation+ETag; PauseRequested pending UI; runbook per workflow/control; scope-filtered audit search/inspect/export; role matrix shows permissions but not grants.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Monitoring/OperatorConsole.razor; /BusinessEnablement/Components/Audit/AuditExplorer.razor

## Definition of done / measurable proof

Operator actions show request until checkpoint; auditor reconstructs full trace, export redacted.

## Negative / security / recovery criteria

No direct API access to unauthorized run; unknown writes block retries; no fake bank CA IDs.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-16: Operator controls, runbooks and audit screens. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 153: jobs/interaction/UI-16-operator-controls,-runbooks-and-audit-screens.md -->

---

<!-- BEGIN SOURCE 154: jobs/interaction/UI-17-environment-release-regression-+-107-control-proof.md -->

> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# UI-17 - Environment/Release/Regression + 107-control proof

**Priority:** P0. **Refines original jobs:** JOB-16, JOB-17, JOB-20. **Dependencies:** UI-10, SDK-12, SDK-16. **Status:** Proposed / repository verification required.

## Purpose and scope

ENV-01..04 REL-01..06 TST-01..05 plus all 107 control API tests.

## Engineering implementation instructions

Implement redacted environment refs, digest dependency preflight, controlled UAT request, PROD auth gate, regression suite evidence; automated Playwright and API tests from JSON registry.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/BusinessEnablement/Components/Release/ReleaseCenter.razor; /BusinessEnablement.Tests/Functional/

## Definition of done / measurable proof

All 107 controls have screen/API ownership and test, release blocked without real bank approvals, no inert buttons.

## Negative / security / recovery criteria

Manifest forged/ETag conflict/approval missing, offline monitor, wrong role all safe.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement UI-17: Environment/Release/Regression + 107-control proof. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.

<!-- END SOURCE 154: jobs/interaction/UI-17-environment-release-regression-+-107-control-proof.md -->

---

<!-- BEGIN SOURCE 155: wireframes/README.md -->

# Blazor wireframes — current concepts and original v1.1 references

- **Current v2.1 design:** `Unity_v2_0_Concept_Blazor.html` (interactive illustrative concept, not a deployed application) and authoritative `../docs/ux/09...13` detailed text screens.
- **Original v1.1 prototypes retained:** `Unity_BPMN_Configurator_Clickable_v1.1.html` and `Unity_BE_Clickable_Wireframes_v1.0.html`, plus screenshots under `screenshots/`.
- **Original drawings:** archived exactly under `../reference-archive/v1.1-complete-original/wireframes/` and `../reference-archive/v1.1-complete-original/previews/`.
- Buttons in prototypes are demonstrations only; production must bind Blazor controls to backend APIs with server-side authorization, revision checks and error states. The v1.1 JSON export is not executable BPMN XML+DI.

<!-- END SOURCE 155: wireframes/README.md -->
