#!/usr/bin/env python3
"""Verify a WF Unity v2.1 package extracted from the single handoff ZIP."""
from pathlib import Path
import hashlib, json, sys
root=Path(__file__).resolve().parent.parent
manifest=json.loads((root/'MANIFEST-v2.1.json').read_text())
checks=[]
def sha(x):return hashlib.sha256(x).hexdigest()
for ent in manifest['ask_source_files']:
    p=root/ent['path']
    checks.append((p.exists() and sha(p.read_bytes())==ent['sha256'],ent['path']))
ask=(root/'ASK-MODE-HANDOFF.md').read_bytes()
checks.append((ask==(root/'DEVIN-ASK.md').read_bytes(),'Ask/Devin Ask equality'))
checks.append((sha(ask)==manifest['ask_sha256'],'Ask digest'))
checks.append((b'# WF Unity v2.0 - Questions for Matthew: AMIE, BOB, Groups and BE' not in ask,'Matthew questions excluded'))
for name,digest in manifest['source_complete_files_sha256'].items():
    p=root/'reference-archive'/'v1.1-complete-original'/name
    checks.append((p.exists() and sha(p.read_bytes())==digest,'original:'+name))
p=root/manifest['original_current_manifest_path']
checks.append((p.exists() and sha(p.read_bytes())==manifest['original_current_manifest_sha256'],'Current v1.1 manifest'))
excl={'ASK-MODE-HANDOFF.md','DEVIN-ASK.md','docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md'}
actual={str(p.relative_to(root)) for p in root.rglob('*.md') if str(p.relative_to(root)) not in excl and not str(p.relative_to(root)).startswith('reference-archive/')}
listed={x['path'] for x in manifest['ask_source_files']}
checks.append((actual==listed,'Ask current source inventory'))
failed=[x for ok,x in checks if not ok]
if failed:
    print('FAIL',len(failed),failed[:30]);sys.exit(1)
print('PASS:',len(checks),'checks; current Ask docs',len(listed),'exact source originals',len(manifest['source_complete_files_sha256']))
