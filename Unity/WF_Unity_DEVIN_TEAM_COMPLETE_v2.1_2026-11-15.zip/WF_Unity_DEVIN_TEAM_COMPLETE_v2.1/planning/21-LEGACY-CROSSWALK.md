# Original v1.1 Job / Source Crosswalk into v2.1 Milestones

**Rule:** The original job packets are retained so Devin does not lose implementation detail. Each is a **detailed acceptance reference**, not a new Jira story automatically. Create the Jira work once using the current `planning/milestones-stories.md`, map useful details from the old packets, and reconcile with real repository code. Avoid duplicated tickets and do not interpret old P1 deferrals as superseding the expanded Phase 1 execution scope.

| Original detailed packet | Owning v2.1 milestone | Instruction |
|---|---|---|
| `jobs/INDEX.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-00-reconcile-repository.md` | M0 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-01-freeze-contracts.md` | M0 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-02-capability-sdk.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-03-registry-contracts.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-04-amie-adapter.md` | M2 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-05-bpmn-compiler.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-06-bob-hosts.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-07-kafka-sdk.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-08-sql-audit.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-09-be-designer.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-10-be-composition.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-11-input-trigger-staging.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-12-cyberark-operations.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-13-reporting-email.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-14-be-monitor.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-15-rbac-operator.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-16-release-package.md` | M5 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-17-regression-ci.md` | M5 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-18-dcms-e2e.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-19-second-workload.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/JOB-20-demo-handoff.md` | M5 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-21-shared-blazor-component-foundation.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-22-workflow-wizard-and-library-lifecycle.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-23-first-party-bpmn-canvas-xml-plus-di.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-24-bpmn-palette-and-node-specific-inspector.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-25-schema-driven-data-binding-and-amie-rule-editor.md` | M2 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-26-triggers-and-input-forms-builder.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-27-compiler-validation-panel-and-dev-test-bench.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-28-workflow-version-review-and-release-wiring.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-29-business-work-queue-and-near-real-time-dashboard.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BE-30-bpmn-runtime-monitor-controls-and-audit-views.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BOB-37-bpmn-2.0-compiler-shared-runtime-central-embedded-wait.md` | M3 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/BOB-38-existing-amie-adapter-and-typed-binding-graph.md` | M2 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/INDEX.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/INT-39-dcms-integrated-ui-to-kafka-to-email-proof.md` | M5 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/QA-40-complete-ui-api-flow-and-second-workload-regression.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-31-operation-registry-and-automatic-be-schema-integration.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-32-nas-ef-core-owned-data-api-integration.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-33-cyberark-dcms-reusable-primitives.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-34-cyberark-guarded-account-delete-operation.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-35-autosys-scheduler-trigger-adapter.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/bpmn/SDK-36-policy-drift-reusable-zip-ini-ef-operations.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/INDEX.md` | M6 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-10-repo-and-contract-seam-audit.md` | M0 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-11-trusted-handler-registration-and-di-sdk.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-12-capability-registry-and-trusted-publication.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-13-existing-amie-adapter-and-rule-metadata.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-14-shared-bob-operation-dispatcher-and-host-modes.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-15-kafka-inbox-outbox-and-command-contracts.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-16-audit,-authorization-and-operational-controls.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-17-capability-service-template-and-reusable-skill-update.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/SDK-18-dcms-vertical-slice-plus-second-workload-reuse-proof.md` | M1 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-10-be-shell,-screen-routing-and-role-scoped-api-clients.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-11-capability-catalog,-inspector-and-onboarding-wizard.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-12-application-studio-and-workflow-library-lifecycle.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-13-blazor-bpmn-2.0-canvas-and-typed-operation-inspector.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-14-amie-binding-picker-and-trigger-forms-editor.md` | M2 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-15-business-work-queue-and-bpmn-run-monitor.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-16-operator-controls,-runbooks-and-audit-screens.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |
| `jobs/interaction/UI-17-environment-release-regression-+-107-control-proof.md` | M4 | Reconcile against current M0–M6 story scope; retain detailed acceptance evidence, not old release assumptions |

## Explicit v2.1 changes applied to every original job

1. Channel Secure/SAML/enterprise entitlements and Apigee, Splunk, AutoSys, NAS and cron integrations are early development and go-live dependencies (M5), not optional vague future work.
2. Workflow access (Read/Execute/Execute-Lead/Create) is enforced inside Unity; capability Register/Configure is separate; external departments authenticate only the Unity service account, not individual Unity website users.
3. AMIE existing intake/route/enrichment by Matthew is retained for the initial two-week delivery; do not rewrite it without an agreed later refactor.
4. BPMN expanded Phase 1 includes parallel fork/join, durable intermediate timers, interrupting timer/error boundaries and minimum durable human tasks; compiler must reject unsupported execution semantics.
5. Maintain full-modeling experimental palette, save/import/export XML+DI, and environment-gated execution; do not confuse JSON metadata with executable BPMN XML.
6. `Experimental/NonProd/Approved` classification and `InDev/Testing/Verified/ReleaseReady` stage are independent and versioned; activation per environment is separate.
7. DEV, UAT and PROD only. PROD change ID presence is required without ServiceNow API validation initially; release trust and go-live identity controls still required.
8. v2.1 `planning/milestones-stories.md` controls Jira milestone grouping. Each story must belong to one milestone.
9. All proposed code paths, endpoints and integrations require source audit; do not claim verified implementation from wireframes.
