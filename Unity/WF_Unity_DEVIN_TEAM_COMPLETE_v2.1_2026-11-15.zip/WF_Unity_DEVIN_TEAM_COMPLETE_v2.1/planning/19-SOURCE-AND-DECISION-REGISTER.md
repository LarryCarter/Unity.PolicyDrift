# Planning 19 — Provenance, Adopted Decisions, Remaining Questions and Source Limitations

## Status and provenance
This is the **v2.1 reconciled master handoff**, based on approved conversation decisions, v2.0 current specifications, and the complete original v1.1 archives supplied on November 15, 2026. **Both v1.1 source ZIP archives were inspected and reconciled.** No repository deployment, real Jira completion, signed bank release, or enterprise integration is asserted. Source audit remains mandatory.

## Accessible historic sources reviewed or incorporated
- `Unity_Capability_SDK_Specification_v1.0.md` — typed operation contracts, local DI vs trusted registry publication, Kafka, AMIE/BOB embedded adapters and API regression concepts.
- `Unity_BE_Wireframe_Screens_v1.0.md` — existing detailed BE shell, screen-by-screen controls and negative tests.
- `Unity_BE_Click_Action_Contracts_v1.0.md` — proposed click/API behavior; route names remain illustrative until code audit.
- `18-FULL-BPMN-DESIGNER-UI-CONFIGURATION-AND-TEST-RUNBOOK.md` — detailed source workflow walkthrough, XML+DI validation, DCMS/NAS/AutoSys examples.
- `DEVIN-BPMN-END-TO-END-START-PROMPT-v1.1.md`, `INDEX.md` and `DIAGRAMS.md` — prior v1.1 handoff structure, dependency jobs, release promotion and SDK onboarding flow.
- Conversation-uploaded `Pasted text.txt` — BOB Phase 1 expanded parallel/timer/error boundary dependencies and regression requirements.
- Earlier conversation-generated WF Unity BOB November 15 update (`WF_Unity_BOB_Handoff_2026-11-15`) and Matthew review draft.

**Source preservation verification:** The original `Unity_DEVIN_BPMN_EndToEnd_Complete_v1.1.zip` contains 262 files and the original `Unity_DEVIN_BPMN_EndToEnd_Current_v1.1.zip` contains 224 files. All 224 file names occur in Complete; 223 identical byte-for-byte, one `MANIFEST.sha256` differs because package content differs; Complete adds 38 historical/preview/reference files. The complete 262-file tree is preserved byte-for-byte under `reference-archive/v1.1-complete-original/` and file-level hashes can be checked. Separate retained active detailed `.md` jobs/docs are annotated at top with v2.1 precedence rules; the original v1.1 historical versions are not the current implementation authority. All current Markdown normative/detailed documents, except the deliberately excluded Matthew-only review file, are included verbatim in Ask Mode. The 6.25 MB prior workflowengine API reference, other legacy history documents and skills live in the archive and are excluded from Ask because they are reference evidence, not current implementation instructions.

## Explicit decisions superseding earlier draft language
| Topic | Final decision |
|---|---|
| Package | Full v2.1 complete package, not supplemental; separate `.md` and two flattened Ask docs; separate Matthew review excluded |
| Environments | DEV (non-prod), UAT (pre-prod), PROD only |
| Group login | Reuse Matthew standalone implementation for development; Channel Secure SAML/entitlements before go-live |
| External providers | Authenticate Unity service accounts, often via Apigee; no per-human external department grants |
| Human permissions | Per workflow Read / Execute / Execute-Lead / Create; Register/Configure for capability admin separately |
| AMIE intake | Retain classify/enrich/select/publish to BOB for initial pilot; typed boundary, future correction documented |
| Approval workflow | AMIE policy + BOB durable human tasks + BE Blazor approvals, multi-stage/backup |
| SQL schemas | All lowercase `uty_` prefixes, one approved SQL database per environment, separate schema/context ownership |
| Workflow catalog | Application functional collections and capability-own L2 workflows; stable associations and versions |
| BPMN runtime | Expanded Phase 1 parallel/timer/error and minimum human tasks; full modeling via experimental flagged save/import |
| Status | Experimental / NonProd / Approved with InDev / Testing / Verified / ReleaseReady separately versioned; activation separate |
| PROD release | Mandatory ServiceNow change ID presence initially, not API-verified; trusted package verification needed before PROD activation |
| Enterprise integrations | Channel Secure, Apigee, Splunk, AutoSys, NAS, cron and others in M5 and go-live blockers; verify existing status |
| Jira | `milestones-stories.md` has milestone-owned stories for Megan; old real tickets can be recreated/mapped by user |

## Open verification questions (M0 only, not unresolved product-direction votes)
1. Exact paths/classes and working behavior of current AMIE, BOB, capability SDK, BE and standalone group subsystem.
2. Approved standard API/EF naming and existing `uty_` migrations, support for hosted BPMN engine and licensed third-party modeling libraries.
3. Available DEV/UAT Channel Secure and Apigee contacts, gateway products, security controls, Splunk output format, AutoSys trigger, NAS contracts, cron conventions.
4. Trusted signer/enterprise release mechanism for PROD; actual ticket template and separation-of-duty policy.
5. Which existing Jira stories already cover M0-M6 integration placeholders.
6. Actual initial pilot fixture and necessary production go-live date/criteria.

## Priority / critical path
Source audit and contract freeze -> typed registry + existing auth/rules -> BOB durable execution and approval -> Blazor paths -> integration and DEV/UAT release validation -> UAT end-to-end proof -> PROD go-live gate. The immediate two-week objective is working DEV architecture and demonstrable integration, not an ungrounded guarantee that external bank dependencies will be provisioned.
