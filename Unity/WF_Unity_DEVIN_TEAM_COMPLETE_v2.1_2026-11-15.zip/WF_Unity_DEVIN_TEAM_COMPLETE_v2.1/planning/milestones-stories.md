# `milestones-stories.md` — Megan Milestones and Jira-Ready Work Breakdown
**Purpose:** waterfall-style milestone reporting with detailed, explicitly linked Jira stories. Existing Jira issue keys are unknown and may be replaced; proposed `WF-Mx-yy` identifiers are planning placeholders only. Do not infer story completion. One accepted story counts to its milestone, but milestone itself requires gate acceptance.
## Reporting rules
- Every story has exactly one owning milestone and may depend on other milestones; Jira AI should create link relationships and milestone grouping.
- Suggested Jira types: Milestone/epic/feature as supported by Wells Fargo project; Story tasks linked via native parent or configured milestone field. Keep implementation evidence and blocked dependencies visible.
- Milestone progress = accepted stories / total stories, plus gate PASS/FAIL; counts not supplied as real progress. Track blocked, underway, accepted using actual Jira statuses.
- A placeholder for an integration does not mean that integration is missing: M0 maps preexisting implementations/stories before new ones are created.
- Show milestone dates/target teams as TBD pending actual team planning rather than fabricate delivery dates. Two-week goal prioritizes pilot, not completion guarantees for unknown enterprise integrations.

## M0 — Repository and architecture reconciliation
**Objective:** Inventory existing BOB, AMIE, BE, SDK and deployed interfaces; baseline accepted before rework.
**Milestone acceptance gate:** Approved audit, actual paths/test baseline, freeze critical contracts, ranked blockers; no duplicate rebuild.
**Story count:** 4 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M0-01` | Source inventory and source-of-truth contract map | Locate real files, services, migrations, topics, provider configs; mark mock vs verified. |
| `WF-M0-02` | Current AMIE/BOB and auth flow assessment | Demonstrate Matthew existing login/group/intake/rule routing and any durable orchestration overlaps. |
| `WF-M0-03` | BPMN and SDK gap matrix | Compare expanded Phase 1 element semantics, handlers, and SDK contracts to existing code/tests. |
| `WF-M0-04` | Environment and integration ownership register | Confirm DEV/UAT/PROD, owners, existing Jira, missing Channel Secure/Apigee/Splunk/AutoSys/NAS/cron details. |

### WF-M0-01 — Source inventory and source-of-truth contract map
**Milestone:** M0. **Story objective / scope:** Locate real files, services, migrations, topics, provider configs; mark mock vs verified.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M0-02 — Current AMIE/BOB and auth flow assessment
**Milestone:** M0. **Story objective / scope:** Demonstrate Matthew existing login/group/intake/rule routing and any durable orchestration overlaps.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M0-03 — BPMN and SDK gap matrix
**Milestone:** M0. **Story objective / scope:** Compare expanded Phase 1 element semantics, handlers, and SDK contracts to existing code/tests.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M0-04 — Environment and integration ownership register
**Milestone:** M0. **Story objective / scope:** Confirm DEV/UAT/PROD, owners, existing Jira, missing Channel Secure/Apigee/Splunk/AutoSys/NAS/cron details.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M1 — Catalog, SDK and capability governance
**Objective:** Working context-specific catalog with capability onboarding and versioning.
**Milestone acceptance gate:** Approved operations visible only when enabled; two workflows reuse handler; category move retains identity and access.
**Story count:** 6 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M1-01` | Application and capability catalog taxonomy | Application collections Onboarding/Hygiene/Governance; capability owns Operations and L2 Workflows; stable IDs. |
| `WF-M1-02` | Scoped `uty_` SQL migration plan | Align existing DbContexts; implement catalog/capability version associations non-destructively. |
| `WF-M1-03` | SDK handler manifest registration | Compile-time typed operations, deployment-trusted manifest, approve and activate separately. |
| `WF-M1-04` | Capability Register/Configure policy | Only entitled admin group can register/configure capabilities; no external per-user API assignments. |
| `WF-M1-05` | Version maturity and status controls | Experimental/NonProd/Approved + InDev/Testing/Verified/ReleaseReady, transitions audited. |
| `WF-M1-06` | Cross-language and Apigee capability contract | Stable schema/REST/Kafka/MCP policy surface; no invented enterprise endpoint. |

### WF-M1-01 — Application and capability catalog taxonomy
**Milestone:** M1. **Story objective / scope:** Application collections Onboarding/Hygiene/Governance; capability owns Operations and L2 Workflows; stable IDs.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-02 — Scoped `uty_` SQL migration plan
**Milestone:** M1. **Story objective / scope:** Align existing DbContexts; implement catalog/capability version associations non-destructively.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-03 — SDK handler manifest registration
**Milestone:** M1. **Story objective / scope:** Compile-time typed operations, deployment-trusted manifest, approve and activate separately.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-04 — Capability Register/Configure policy
**Milestone:** M1. **Story objective / scope:** Only entitled admin group can register/configure capabilities; no external per-user API assignments.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-05 — Version maturity and status controls
**Milestone:** M1. **Story objective / scope:** Experimental/NonProd/Approved + InDev/Testing/Verified/ReleaseReady, transitions audited.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M1-06 — Cross-language and Apigee capability contract
**Milestone:** M1. **Story objective / scope:** Stable schema/REST/Kafka/MCP policy surface; no invented enterprise endpoint.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M2 — AMIE bindings, groups, and durable approvals
**Objective:** Preserved current AMIE intake plus typed decision links, workflow access and human tasks.
**Milestone acceptance gate:** End-to-end approved rule selection, group denial, multi-stage human approval, no regression of Matthew functionality.
**Story count:** 6 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M2-01` | Use Matthew existing local user/group mechanism | Reconcile existing group and rule configuration; avoid duplicate auth stack. |
| `WF-M2-02` | Workflow resource entitlements | Read/Execute/Execute-Lead/Create with multiple groups, effective access and group-report scoping. |
| `WF-M2-03` | Typed AMIE intake -> BOB binding | Preserve enrich/classify/select workflow, add versioned correlation and BOB admission checks. |
| `WF-M2-04` | BOB and embedded capability AMIE adapters | Pinned facts/results, no independent long-running orchestration created. |
| `WF-M2-05` | Multi-level approval policy + BOB human tasks | Sequential stages, backup group, any-one/all, durable wait, authorized decisions. |
| `WF-M2-06` | AMIE decision trace and review feedback | Correlated printable trace; Matthew screen candidates can be selected/rejected individually. |

### WF-M2-01 — Use Matthew existing local user/group mechanism
**Milestone:** M2. **Story objective / scope:** Reconcile existing group and rule configuration; avoid duplicate auth stack.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-02 — Workflow resource entitlements
**Milestone:** M2. **Story objective / scope:** Read/Execute/Execute-Lead/Create with multiple groups, effective access and group-report scoping.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-03 — Typed AMIE intake -> BOB binding
**Milestone:** M2. **Story objective / scope:** Preserve enrich/classify/select workflow, add versioned correlation and BOB admission checks.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-04 — BOB and embedded capability AMIE adapters
**Milestone:** M2. **Story objective / scope:** Pinned facts/results, no independent long-running orchestration created.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-05 — Multi-level approval policy + BOB human tasks
**Milestone:** M2. **Story objective / scope:** Sequential stages, backup group, any-one/all, durable wait, authorized decisions.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M2-06 — AMIE decision trace and review feedback
**Milestone:** M2. **Story objective / scope:** Correlated printable trace; Matthew screen candidates can be selected/rejected individually.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M3 — Expanded BPMN 2.0 Phase 1 engine
**Objective:** Concurrent, timer-driven, error-aware durable BOB execution with common central/embedded semantics.
**Milestone acceptance gate:** BPMN regression matrix and crash/race failure-injection gate passes with evidence.
**Story count:** 7 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M3-01` | Canonical BPMN XML+DI compiler and support registry | Preserve IDs/geometry; separate modeling/import/compiler/execution feature support. |
| `WF-M3-02` | Token scope, atomic branch and parallel join | Multi-token fork/join, optimistic concurrency and deadlock validation. |
| `WF-M3-03` | Durable timer scheduler and intermediate timer | One-shot date/duration, crash restart and multi-replica claim tests. |
| `WF-M3-04` | Interrupting timer boundary and reconciliation | Atomic race vs activity completion; reconcile late external outcome. |
| `WF-M3-05` | Typed error boundary and propagation | Explicit BPMN codes, nested scope handling, unhandled failure. |
| `WF-M3-06` | Kafka wait, outbox/inbox, pause/cancel/restart proof | Exactly-once logical advancement under at-least-once transport. |
| `WF-M3-07` | Common interpreter host compatibility | Central/embedded fixtures and reject non-durable embedded timers/waits. |

### WF-M3-01 — Canonical BPMN XML+DI compiler and support registry
**Milestone:** M3. **Story objective / scope:** Preserve IDs/geometry; separate modeling/import/compiler/execution feature support.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-02 — Token scope, atomic branch and parallel join
**Milestone:** M3. **Story objective / scope:** Multi-token fork/join, optimistic concurrency and deadlock validation.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-03 — Durable timer scheduler and intermediate timer
**Milestone:** M3. **Story objective / scope:** One-shot date/duration, crash restart and multi-replica claim tests.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-04 — Interrupting timer boundary and reconciliation
**Milestone:** M3. **Story objective / scope:** Atomic race vs activity completion; reconcile late external outcome.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-05 — Typed error boundary and propagation
**Milestone:** M3. **Story objective / scope:** Explicit BPMN codes, nested scope handling, unhandled failure.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-06 — Kafka wait, outbox/inbox, pause/cancel/restart proof
**Milestone:** M3. **Story objective / scope:** Exactly-once logical advancement under at-least-once transport.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M3-07 — Common interpreter host compatibility
**Milestone:** M3. **Story objective / scope:** Central/embedded fixtures and reject non-durable embedded timers/waits.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M4 — Blazor user experience and administrative wireframes
**Objective:** Smooth contextual setup from application/capability into BPMN/AMIE/permissions and running status.
**Milestone acceptance gate:** BE flow usable end-to-end in DEV and action registry behavior verified; no inert production controls.
**Story count:** 6 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M4-01` | Unified Blazor shell and catalog search | Context, folders, filters, details, version/group permission overview. |
| `WF-M4-02` | Capability administration and status workflow | Register, Configure, Development, Validation, Approval, activation tabs and status badges. |
| `WF-M4-03` | BPMN designer with full experimental palette | Save XML+DI; per-node inspector, flag, validation and experimental warnings. |
| `WF-M4-04` | AMIE candidate screens for Matthew | Rule catalog, approval policy, group assign, decision trace; adopt only approved changes. |
| `WF-M4-05` | Work queue, run monitor, group reports | Human task inbox, parallel branch overlay, timer/error, lead group-filtered report. |
| `WF-M4-06` | Administrator user-guide and UI click evidence | Stepwise setup, empty/error states, API role tests, screenshots. |

### WF-M4-01 — Unified Blazor shell and catalog search
**Milestone:** M4. **Story objective / scope:** Context, folders, filters, details, version/group permission overview.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-02 — Capability administration and status workflow
**Milestone:** M4. **Story objective / scope:** Register, Configure, Development, Validation, Approval, activation tabs and status badges.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-03 — BPMN designer with full experimental palette
**Milestone:** M4. **Story objective / scope:** Save XML+DI; per-node inspector, flag, validation and experimental warnings.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-04 — AMIE candidate screens for Matthew
**Milestone:** M4. **Story objective / scope:** Rule catalog, approval policy, group assign, decision trace; adopt only approved changes.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-05 — Work queue, run monitor, group reports
**Milestone:** M4. **Story objective / scope:** Human task inbox, parallel branch overlay, timer/error, lead group-filtered report.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M4-06 — Administrator user-guide and UI click evidence
**Milestone:** M4. **Story objective / scope:** Stepwise setup, empty/error states, API role tests, screenshots.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M5 — Enterprise integrations and release controls
**Objective:** Bridge existing integrations, identify outstanding external dependencies; test package import through UAT.
**Milestone acceptance gate:** Per integration existing/partial/awaiting/verified recorded; DEV/UAT import tests; PROD blocked until SSO/trust requirements satisfied.
**Story count:** 9 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M5-01` | INT-CHSEC Channel Secure SAML + entitlements | Audit existing auth seam; integrate/verify before PROD go-live; requirements pending. |
| `WF-M5-02` | INT-APIGEE gateway onboarding and service auth | Confirm existing API product/scope access; test allow/deny in approved environment. |
| `WF-M5-03` | INT-SPLUNK structured logging and audit | Correlated safe telemetry, redaction, forwarding and query proof. |
| `WF-M5-04` | INT-AUTOSYS trigger adapter | Schedule-to-BOB trigger schema, replay/authorization, existing code first. |
| `WF-M5-05` | INT-NAS data capability integration | Owned EF/data APIs, schema/row staging and permissions, no direct cross-service DB. |
| `WF-M5-06` | INT-CRON scheduler integration | Approved schedule ownership, timer distinction and audit. |
| `WF-M5-07` | BPMN XML + Unity package import/export | DEV/UAT dry run, test malformed/missing dependencies; no mock-only JSON export. |
| `WF-M5-08` | Release review, ServiceNow reference, trust mechanism | Mandatory PROD change ID presence, signature/approved trust, group and environment validation. |
| `WF-M5-09` | Activation and rollback controls | PROD import != activate; approved operator and immutable digest; rollback recorded. |

### WF-M5-01 — INT-CHSEC Channel Secure SAML + entitlements
**Milestone:** M5. **Story objective / scope:** Audit existing auth seam; integrate/verify before PROD go-live; requirements pending.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-02 — INT-APIGEE gateway onboarding and service auth
**Milestone:** M5. **Story objective / scope:** Confirm existing API product/scope access; test allow/deny in approved environment.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-03 — INT-SPLUNK structured logging and audit
**Milestone:** M5. **Story objective / scope:** Correlated safe telemetry, redaction, forwarding and query proof.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-04 — INT-AUTOSYS trigger adapter
**Milestone:** M5. **Story objective / scope:** Schedule-to-BOB trigger schema, replay/authorization, existing code first.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-05 — INT-NAS data capability integration
**Milestone:** M5. **Story objective / scope:** Owned EF/data APIs, schema/row staging and permissions, no direct cross-service DB.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-06 — INT-CRON scheduler integration
**Milestone:** M5. **Story objective / scope:** Approved schedule ownership, timer distinction and audit.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-07 — BPMN XML + Unity package import/export
**Milestone:** M5. **Story objective / scope:** DEV/UAT dry run, test malformed/missing dependencies; no mock-only JSON export.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-08 — Release review, ServiceNow reference, trust mechanism
**Milestone:** M5. **Story objective / scope:** Mandatory PROD change ID presence, signature/approved trust, group and environment validation.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M5-09 — Activation and rollback controls
**Milestone:** M5. **Story objective / scope:** PROD import != activate; approved operator and immutable digest; rollback recorded.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## M6 — Integrated demonstration, UAT and production readiness
**Objective:** Prove enterprise orchestration value and document remaining go-live blockers.
**Milestone acceptance gate:** Jira stories accepted + milestone conformance/UAT evidence; no unsupported production-ready claim.
**Story count:** 5 (all currently unverified; link actual Jira keys after creation).

| Placeholder | Jira story summary | Acceptance focus |
|---|---|---|
| `WF-M6-01` | CyberArk first end-to-end pilot | BE -> AMIE -> BOB -> Kafka -> embedded capability -> outcome/report, with safe fixtures. |
| `WF-M6-02` | Parallel, timer, error, approval demo | Multi-branch, boundary events, multi-level approval and crash recovery. |
| `WF-M6-03` | Second unrelated workflow reuse proof | Use same shared SDK, BOB, AMIE core without workload-specific changes. |
| `WF-M6-04` | Security UAT and operational failure injection | Direct API deny, group report scope, launch/retry/reconcile, log/audit verification. |
| `WF-M6-05` | Production readiness and release evidence review | Verify Channel Secure, Apigee, Splunk, scheduled sources, NAS and signature readiness; outstanding blockers visible. |

### WF-M6-01 — CyberArk first end-to-end pilot
**Milestone:** M6. **Story objective / scope:** BE -> AMIE -> BOB -> Kafka -> embedded capability -> outcome/report, with safe fixtures.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M6-02 — Parallel, timer, error, approval demo
**Milestone:** M6. **Story objective / scope:** Multi-branch, boundary events, multi-level approval and crash recovery.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M6-03 — Second unrelated workflow reuse proof
**Milestone:** M6. **Story objective / scope:** Use same shared SDK, BOB, AMIE core without workload-specific changes.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M6-04 — Security UAT and operational failure injection
**Milestone:** M6. **Story objective / scope:** Direct API deny, group report scope, launch/retry/reconcile, log/audit verification.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

### WF-M6-05 — Production readiness and release evidence review
**Milestone:** M6. **Story objective / scope:** Verify Channel Secure, Apigee, Splunk, scheduled sources, NAS and signature readiness; outstanding blockers visible.
**Definition of done:** Implementation or verified existing work is linked to actual repository paths, current API/schema contracts, relevant unit/negative/contract or UI tests, evidence screenshot/log with secrets redacted, and reviewer acceptance. Attach blocker if external contract unknown.
**Dependencies:** This milestone and preceding architecture/contracts as mapped in `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`; adjust Jira links during audit without inventing ticket keys.

## Megan reporting view
| Milestone | Total planning stories | Accepted from Jira | Blocked | Milestone gate |
|---|---:|---:|---:|---|
| M0 — Repository and architecture reconciliation | 4 | TBD | TBD | Not yet verified |
| M1 — Catalog, SDK and capability governance | 6 | TBD | TBD | Not yet verified |
| M2 — AMIE bindings, groups, and durable approvals | 6 | TBD | TBD | Not yet verified |
| M3 — Expanded BPMN 2.0 Phase 1 engine | 7 | TBD | TBD | Not yet verified |
| M4 — Blazor user experience and administrative wireframes | 6 | TBD | TBD | Not yet verified |
| M5 — Enterprise integrations and release controls | 9 | TBD | TBD | Not yet verified |
| M6 — Integrated demonstration, UAT and production readiness | 5 | TBD | TBD | Not yet verified |

## Suggested import to Jira
Assign a milestone field or parent epic to every story using the Milestone column. Maintain parent/child relationships, standard completion criteria and cross-milestone dependency links. Existing tickets may be deleted/recreated by project owner; avoid claiming any ticket exists before Jira confirms it.
