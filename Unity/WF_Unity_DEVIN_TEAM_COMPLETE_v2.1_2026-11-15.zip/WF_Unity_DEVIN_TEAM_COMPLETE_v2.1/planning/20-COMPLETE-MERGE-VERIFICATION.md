# Source archive comparison and preservation verification — v2.1

## Originals supplied and inspected

| Source | Files | Uncompressed | Result |
|---|---:|---:|---|
| `Unity_DEVIN_BPMN_EndToEnd_Complete_v1.1.zip` | 262 | 19,915,189 bytes | Entire original tree copied byte-for-byte into `reference-archive/v1.1-complete-original/` |
| `Unity_DEVIN_BPMN_EndToEnd_Current_v1.1.zip` | 224 | 4,864,296 bytes | Every file already represented in Complete, except its own manifest differs |

**Comparison:** 224 same-name entries, 223 byte-identical and 1 different (`MANIFEST.sha256`). Both manifest versions are preserved. Complete adds 38 files, mainly prior versions, previews and third-party reference. The sole differing manifest is separately preserved at `reference-archive/v1.1-current-manifest/MANIFEST.sha256`. No Current-only file names.

**Check:** Source SHA256 Complete `2235d4a4208c8bcae3b693ae6a3f0aadce914a8dbfd93c7b4458daaeabc8de42`; Current `e92e72431d0b18582fb07000e1c0790bb8730d43a8f51fd2ffc959742aebf3ef`.

## Active documents reconciled
- `144` original detailed docs/jobs/diagram files copied to their original relative locations as annotated reference. Their v2.1 header identifies current instructions that take precedence.
- `27` current v2.0 source files adopted, then corrected where v1.1 source preservation had previously been unverified.
- Original source material preserved exactly under archive; updated original text is a non-destructive copy with a preface, **not** a byte-identical original.
- Original screenshot/HTML wireframes remain accessible. Visual simulation does not prove working BPMN XML+DI export or BE integration.
- `docs/architecture/03-BOB-BPMN-RUNTIME.md` is deliberately updated v2.1 content; original v1.1 at `reference-archive/v1.1-complete-original/docs/architecture/03-BOB-BPMN-RUNTIME.md`.

## Source precedence
1. Current approved `00-START-HERE.md`, eight current `docs/architecture`, five `docs/ux`, current contracts/testing/jobs and milestone decisions.
2. Detailed annotated original docs/jobs for test cases and implementation granularity only.
3. Original unchanged source ZIP tree in `reference-archive/`, for historical/technical reference only.

## Explicitly not verified
No user repository, deployed environment, role configuration, live integration, actual Jira story, signing service or UAT acceptance was inspected. Production compatibility remains conditional on the M0 source audit and required enterprise controls. There is no statement of production compliance.
