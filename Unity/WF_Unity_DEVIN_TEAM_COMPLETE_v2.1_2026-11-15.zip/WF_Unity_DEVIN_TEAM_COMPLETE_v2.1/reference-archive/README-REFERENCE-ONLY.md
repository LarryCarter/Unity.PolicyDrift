# Historic originals — DO NOT assign as Devin active instructions

`v1.1-complete-original/` contains all 262 files from the exact uploaded v1.1 Complete ZIP, including 224 shared Current items, 38 additional history/preview/reference items and the original archived MANIFEST. Its files are retained unchanged so no historical wireframe, job document, skill, screen, diagram, source archive or third-party API reference is lost.

**Canonical current instructions are at the ZIP root**, beginning `00-START-HERE.md`, `START-DEVIN.md`, then current modern docs and `planning/milestones-stories.md`. Earlier design choices and mock endpoints may have been superseded. See `planning/21-LEGACY-CROSSWALK.md`.
