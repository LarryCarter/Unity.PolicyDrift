# Devin Start Prompt — WF Unity v2.1 Definitive Complete Handoff

You are working on an existing enterprise Unity implementation, NOT creating a new greenfield BOB/AMIE/BE architecture. Read `00-START-HERE.md`, `INDEX.md`, the master architecture/UX/contracts/testing documents and `planning/milestones-stories.md`, then read repository `AGENTS.md` and actual existing code. Source paths, classes, UI routes, Jira keys and API examples in handoff are **proposals** to reconcile rather than claims of verified implementation.

## First PR: M0 read-only reconciliation
Identify actual AMIE intake/enrichment/routing, BOB compiler/host/execution state, existing Matthew auth/groups and rule pages, SDK operation manifest/register, central Kafka/outbox, Blazor BE pages, existing SQL Server `DbContext`/migration history, producer/consumer schemas, environments and current tests. Capture exact `/Project/Path/File.cs` references. Verify live work vs prototypes, licensing/approved SDK packages, and cross-language contracts. Both original v1.1 ZIPs are now available and source-preserved. Read current v2.1 before detailed references; do not mistakenly follow original v1.1 scope where superseded. Do not create duplicate interfaces or rewrite functioning AMIE intake for first pilot.

## Execute dependency-ordered milestones
M0 Audit -> M1 Catalog/SDK -> M2 AMIE/group/human approval -> M3 Expanded BPMN shared runtime -> M4 Blazor workflow/admin/screens -> M5 Enterprise integration and DEV/UAT promotion -> M6 Pilot and UAT. Use `planning/milestones-stories.md`: every story has one milestone; create links/parents in Jira but do not invent existing issue IDs or claim real ticket completion. Use detailed `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` as engineering task breakdown.

## Non-negotiables
Preserve BPMN XML+DI; feature visibility != runtime support; experimental workflow can be saved/imported/exported without publishing; implemented experimental handler in DEV only with policy; PROD cannot execute experimental; actual PROD import needs trusted artifact verification and nonempty ServiceNow change ID plus authorized release; PROD Channel Secure SAML+entitlements is required before go-live. Existing standalone auth and groups are reused during development. Human workflow entitlements are separate from technical capability service-account API grants. Shared interpreter avoids duplicated enterprise orchestration in capability microservices. AMIE policies are decisions; BOB persists workflow/token/human-task state. Avoid fabricated enterprise integrations and unapproved production side effects. No secrets in artifacts, Kafka or logs.

## Every PR report
Milestone + story IDs; real repository paths; interfaces/migrations changed; behavior before/after; compatibility and rollback; tests and actual outputs; negative security tests; screens/user-guide changes; external requirements and blockers; evidence level and source/mock classification. No production-ready status without verified Channel Secure, Apigee, Splunk and applicable enterprise release requirements.

`docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` is a separate internal review file intentionally excluded from both Devin Ask compilations. Do not silently treat its unapproved screen suggestions as committed code changes.

## Reconciled detailed implementation references
Retained v1.1 `jobs/JOB-*`, `jobs/bpmn/*` and `docs/ui/*` contain extensive test and screen scripts; apply them only after reading the v2.1 precedence notice at their top and matching to `planning/21-LEGACY-CROSSWALK.md`. Original unchanged files live under `reference-archive/` for forensic comparison.

## Only delivery artifact
This entire folder comes from the single definitive ZIP. Do not request the older Complete/Current ZIPs, as all 262 original Complete files and the modern canonical set are already present.
