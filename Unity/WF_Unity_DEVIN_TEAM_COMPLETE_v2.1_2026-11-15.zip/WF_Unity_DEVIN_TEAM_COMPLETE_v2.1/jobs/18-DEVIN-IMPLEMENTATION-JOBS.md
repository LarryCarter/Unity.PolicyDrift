# Jobs 18 — Dependency-Ordered Devin Work Packets and Evidence Gates

## Code-first inspection rule
No assumption a proposed C# class, Blazor page, EF schema, API or approved dependency exists. Devin's first job is read-only source reconciliation: read AGENTS.md, repo architecture, current AMIE/BOB contracts, BE components, capability SDK, Kafka infrastructure, CI tests and security conventions. Report exact file paths and working vs mock functionality. Missing third-party approvals or bank-controlled dependencies are blockers, not license to invent endpoints. Maintain one feature PR per dependency seam; report changed paths, tests, effect on existing code, risks, screenshots and unresolved issues.

## JOB-V2-00 — Baseline audit and release gate (M0)
Inspect original v1.1, SDK v1.0 and existing project implementation. Record real components/handlers/DbContexts/AMIE route/BE screens, code ownership, dependencies, test results and source reconciliation. Confirm whether all Phase 1 primitives already exist; do not duplicate. Output source audit, contract map, failed tests, dependency graph, open integration requirements and proposed PR plan. **Gate:** reviewers accept actual evidence and migration/compatibility plan.

## JOB-V2-01 — Versioned application and capability catalog (M1)
Implement `uty_catalog` and `uty_capability` schema changes only after M0. Context filters Application > Onboarding/Hygiene/Governance/Reporting, Capability > Operations/Workflows/Rules; stable IDs, versioned immutable definitions and association indexes. Test category moves and group permission invariance. Use actual existing EF contexts/migrations where possible.

## JOB-V2-02 — Trusted SDK registration, operation approval (M1)
Existing SDK compiled handler discovery -> typed manifest -> trusted service deploy identity -> registry approval -> operation picker. Support language-neutral REST/Kafka onboarding without duplicating engine. Wire Register/Configure authorization and per-operation maturity and environment activation. Test duplicate IDs, unsupported schemas, revoked operation and one handler reused in two workflows.

## JOB-V2-03 — Existing group policy and AMIE seams (M2)
Reuse Matthew auth/group and AMIE rule engine; link workflow groups with Read/Execute/Execute-Lead/Create, capability Register/Configure separately. Preview effective access; server-side enforcement and scope-filtered results. Preserve AMIE intake validation/enrichment/workflow selection, typed AMIE->BOB start contract; BOB->AMIE pinned rule adapter. Identify existing AMIE orchestration overlap and log deferred review without first-pilot rewrite.

## JOB-V2-04 — Durable human-task contract (M2)
AMIE returns multi-stage approval plan with eligible groups/backup groups/any-one or all; BOB persists work queue stages/decisions and resumes. BE displays tasks, decisions and audit. Test concurrent approvers, reject, backup and restart, permission denial. Avoid duplicate approval engine.

## JOB-V2-05 — Shared BPMN compiler and token engine (M3)
Preserve OMG XML+DI, support baseline nodes and typed versioned operation/rule/call bindings. Implement or verify token/scope state, atomic parallel split/join arrivals, SQL outbox/inbox correlation, pause/resume/cancel/restart. Reject unsupported topologies and non-durable embedded waits. Both central/embedded hosts pass same semantic fixture subset.

## JOB-V2-06 — Durable events and exception paths (M3)
Persist one-shot intermediate timers; attached interrupting timer boundary; typed error boundary; race/cancel safety; nested error scopes; late unknown external write reconciliation. Chaos test pod crashes and two-replica races. Include compiled BPMN element feature flags and maturity-state validation.

## JOB-V2-07 — Blazor authoring and capability admin (M4)
Implement responsive shared shell and catalog, capability administration and maturity stages, operation inspector, BPMN designer and experimental full palette, AMIE binding selection, group assignment and effective-access preview. XML/DI import/export truly works; UI warns on unsupported runtime execution. Use existing Blazor pages rather than parallel UI project. Capture screens and route/API controls.

## JOB-V2-08 — AMIE review candidate screens (M4)
Offer Matthew rule catalog/category, rule inspect/test, approval policy builder, intake trace and workflow AMIE-binding wireframes; adopt only approved parts and current editor. Keep separate `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` excluded from Ask. Provide user guides and screen acceptance scripts.

## JOB-V2-09 — Enterprise integration seams (M5)
For Channel Secure, Apigee, Splunk, AutoSys, NAS and cron, reconcile existing work, map to placeholder Jira, collect requirements/owners and implement approved contracts. Current auth/group continues in DEV; Channel Secure SAML/entitlements required before PROD go-live. No fake integration evidence and no invented credentials. Kafka service identity + gateway scopes independent of Unity human groups.

## JOB-V2-10 — Package release and environment controls (M5)
Package XML+DI + JSON bindings/rules/versions as immutable artifact; DEV/UAT import/validation, nonempty PROD ServiceNow reference, approved artifact, trusted signature or enterprise trust path, eligible operator. PROD upload/activation fails closed pending mandatory trust/Channel Secure. Implement stage gating and separate import/activate/rollback. No request to promote developer directly to PROD.

## JOB-V2-11 — End-to-end pilot and UAT evidence (M6)
Demonstrate BE -> existing AMIE routing -> central BOB -> approved capability SDK/Kafka -> embedded local AMIE/handler -> correlated outcome/report/BE monitor and multi-level approval. Include parallel AD/CyberArk demo with mock/approved DEV endpoints, timer/error paths and crash recovery. Validate one unrelated second workflow reuse. Resolve M5 production blockers before any go-live claim.

## Deferred architectural work after first pilot
MATTHEW review of AMIE durable orchestration overlap; event-based/inclusive/complex gateways, noninterrupting boundaries, parallel multi-instance, compensation, event subprocess, collaboration, advanced approval delegation and forms; ServiceNow API validation, automated policy drift, expanded department APIs. Preserve compatibility now; not hidden immediate P0 obligations unless required for actual pilot safety.

## PR acceptance template
`Job ID / Milestone / Jira placeholder / Existing paths touched / Old behavior / New behavior / Data migration / API/schema compatibility / Unit tests / Integration tests / Permission negative tests / UAT evidence / Actual vs Mock / Known blockers / Review and rollback`. One ticket is not complete solely because code compiles; linked milestone gate and acceptance evidence determine completion.
