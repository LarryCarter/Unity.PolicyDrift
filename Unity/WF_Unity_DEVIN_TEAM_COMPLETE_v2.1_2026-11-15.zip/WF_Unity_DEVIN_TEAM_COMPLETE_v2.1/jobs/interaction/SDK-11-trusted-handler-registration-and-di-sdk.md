> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-11 - Trusted handler registration and DI SDK

**Priority:** P0. **Refines original jobs:** JOB-02. **Dependencies:** SDK-10. **Status:** Proposed / repository verification required.

## Purpose and scope

Typed handler + execution context + error taxonomy; approved assembly scanning or compiled registration; startup validation; version compatibility.

## Engineering implementation instructions

Implement common interface and registration; scan only compiled approved types; DI resolve by stable key/version; add manifest builder; validate duplicate key, missing schema/policy, write reconcile mode; instrument invocation and cancellation.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capabilities.Hosting/Registration/CapabilityRegistrationExtensions.cs; /Unity.Capabilities.Contracts/OperationDescriptor.cs

## Definition of done / measurable proof

Test handler appears locally by version and dispatches typed request; first operation does not require BE code.

## Negative / security / recovery criteria

Duplicate operation key prevents startup, arbitrary CLR name from workflow rejected, invalid schema rejected.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-11: Trusted handler registration and DI SDK. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
