> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# SDK-18 - DCMS vertical slice plus second-workload reuse proof

**Priority:** P0. **Refines original jobs:** JOB-11..JOB-13, JOB-18, JOB-19. **Dependencies:** SDK-12, SDK-13, SDK-14, SDK-15, SDK-16, UI-15. **Status:** Proposed / repository verification required.

## Purpose and scope

End-to-end configured DCMS batch and one small Hygiene reuse scenario.

## Engineering implementation instructions

Stage CSV with batch number/row GUID, sequential row workflow; local CyberArk read/map/patch/upsert in non-prod; persist outcomes and report; Email capability via Kafka; show BE counts, BPMN overlay and audit; reuse GetAccount in a second configured process.

1. Inspect existing code, using `AGENTS.md`, SDK and UI specs; list actual files before adding anything.
2. Create or update API/schema/DTO fixtures first; align naming to actual source, not just proposed examples.
3. Implement only this ticket's boundary. Use shared interfaces and preserve AMIE code already written.
4. Add positive, negative and failure-injection regression to the same PR.
5. Connect relevant Blazor UI interaction IDs with backend API and typed results (if screen-scoped).
6. Supply a reproducible verification sequence and evidence. Record new/updated/deleted/no-change file summary.

## Proposed impacted paths (not verified)

/Unity.Capability.CyberArk/Operations/; /Unity.Applications.DCMS/Configuration/ (actual paths discovered)

## Definition of done / measurable proof

5-row fixture with success/nochange/reject/skip/unknown yields reconciled results, restart no duplicate writes, independent email outcome.

## Negative / security / recovery criteria

No DCMS-specific SDK/BOB branches, no false real CyberArk test claims, no unsafe retry.

## Completion artifacts

- Focused PR, actual build/test logs, link to running DEV fixture, OpenAPI change, updated manifest/BPMN/rule fixtures and screenshots if UI.
- Name of real reviewer/owner; unresolved bank library, SSO group, Kafka ACL or CA approvals are recorded as gaps, never invented.
- If dependency is not ready, provide a tested stub contract with explicit mock labeling; do not present stub as integrated completion.

## DEVIN assignment prompt

> Implement SDK-18: DCMS vertical slice plus second-workload reuse proof. Use the existing Unity project and the current `AGENTS.md`. First map existing classes. Preserve v0.9 architecture and v1.0 UI+SDK contracts. Own only the boundaries listed in this job; coordinate contract changes through JOB-01. Add positive, negative and crash/authorization tests as applicable. Report actual paths, diffs, build/test output and unmet approvals. Do not deploy to PROD.
