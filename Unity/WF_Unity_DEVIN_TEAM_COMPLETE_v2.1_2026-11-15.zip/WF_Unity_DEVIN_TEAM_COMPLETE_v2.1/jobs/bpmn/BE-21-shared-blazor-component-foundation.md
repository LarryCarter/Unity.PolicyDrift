> **v2.1 DETAILED-REFERENCE RULE — READ FIRST:** This original v1.1 document is retained for its detailed contracts, wireframes, test scenarios and job acceptance cases. It is not independent authority for scope, maturity, credentials, environments, publication, AMIE intake, or the BPMN executable subset. When wording differs, apply `00-START-HERE.md`, the current v2.1 architecture/UX/contracts, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` and `planning/milestones-stories.md`. **Approved changes:** DEV/UAT/PROD only; Matthew existing authentication/groups/intake reused; enterprise Channel Secure/Apigee/Splunk/AutoSys/NAS/cron readiness before go-live; L1/L2/L3 workflows; approved versioned capability registry; parallel gateways, timers, interrupting timer/error boundaries, and minimal durable human tasks in Phase 1; experimental BPMN modeling with gated non-production execution; workflow-group entitlements separate from department API service accounts; BPMN XML+DI canonical; production ticket ID presence without initial ServiceNow API verification; production deployment gated by other actual authorization and trusted-artifact controls. This document is **reconciliation input**, not a request to recreate verified existing code. See `planning/21-LEGACY-CROSSWALK.md`.**

# BE-21 - Shared Blazor component foundation

**Priority:** P0 (deadline Nov 30 DEV demo; bank release approvals separate)  
**Existing job cross-reference / dependencies:** JOB-00, UI-10

## Read first

Read before work: `AGENTS.md`, `INDEX.md`, `docs/ui/13-END-TO-END-BPMN-WORKFLOW-EXPERIENCE.md`, `docs/ui/14-BPMN-PALETTE-NODE-INSPECTORS-DYNAMIC-BINDINGS.md`, `docs/ui/15-REUSABLE-BLAZOR-COMPONENT-CATALOG.md`, `docs/contracts/TRIGGER-NAS-KAFKA-DASHBOARD-CONTRACTS-v1.1.md`, relevant `docs/workflows/*.md` and `docs/diagrams/DIAGRAMS.md`. Existing source repository, actual approved libraries and owner controls override proposed file names, not user architecture. Preserve AMIE code and existing manifests.

## Objective / scope

BE shell, reusable async/field/permission/binding components.

## Implementation actions

Implement reusable SchemaField, TypedBindingPicker, AsyncStateView, ScopedPermissionAction, validation issue list, modal confirmation; follow existing Blazor/FluentValidation style.

## API / message contracts

GET contracts; POST binding validation. Use existing actual API names when source reconciliation establishes them; update contract docs if different.

## Acceptance tests

Component tests for Loading/Empty/Denied/Error, keyboard labels, classified data redaction, API 403, no hardcoded DCMS fields.

Additionally test 401/403, invalid schema, stale version or ETag, timeout, audit event, no secret exposure, and at least one negative failure branch whenever the task crosses a trust boundary.

## PR deliverable

List exact changed files as `/Project/Folder/File.cs` (and `.razor`, `.js` or `.md` as relevant), tests/commands executed, evidence and failures, risk/rollback, open bank control approvals and a **Files and Structure Summary (New/Updated/Deleted/No Change)**. Do not claim real integration because a standalone HTML wireframe passed.
