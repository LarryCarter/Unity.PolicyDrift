# Blazor wireframes — current concepts and original v1.1 references

- **Current v2.1 design:** `Unity_v2_0_Concept_Blazor.html` (interactive illustrative concept, not a deployed application) and authoritative `../docs/ux/09...13` detailed text screens.
- **Original v1.1 prototypes retained:** `Unity_BPMN_Configurator_Clickable_v1.1.html` and `Unity_BE_Clickable_Wireframes_v1.0.html`, plus screenshots under `screenshots/`.
- **Original drawings:** archived exactly under `../reference-archive/v1.1-complete-original/wireframes/` and `../reference-archive/v1.1-complete-original/previews/`.
- Buttons in prototypes are demonstrations only; production must bind Blazor controls to backend APIs with server-side authorization, revision checks and error states. The v1.1 JSON export is not executable BPMN XML+DI.
