# WF Unity v2.1 — Definitive Complete Devin + Team Handoff

**Status:** Approved design direction for implementation planning; no repository implementation, production approval, access or successful external integration is claimed. **Environments:** DEV (non-prod), UAT (pre-prod), PROD. **Package role:** complete reconciled v2.1 design handoff, incorporating the original Complete/Current v1.1 archives, updated canonical specifications, and detailed historical cases. **Sources:** current conversation decisions plus inspected original Complete and Current v1.1 archives; see `planning/19-SOURCE-AND-DECISION-REGISTER.md` for source parity proof.

## First instructions for Devin
1. Read repository `AGENTS.md`, existing platform docs, all real implementations, migrations and tests; run the current baseline. Do **not** infer code exists from these specifications.
2. Preserve Matthew's existing authentication, group configuration, AMIE rules, intake/enrichment/routing and BE screens; reconcile and extend. This two-week engineering window is not approval for a wholesale rewrite.
3. Record actual codepaths, APIs, schema names, installed libraries, permissions and contract differences in the M0 audit; no new incompatible duplicate platform.
4. Deliver small dependency-ordered PRs corresponding to `planning/milestones-stories.md`; report tests, screenshots, migration impact, files, blockers and readiness evidence. Never declare integrations operational without live evidence.
5. Distinguish design/demo from DEV execution, UAT proof, and PROD authority. No production activation without verified entitlement and required release gates.

## Architecture in one paragraph
Unity is a reusable enterprise platform. AMIE evaluates business rules, performs initial request validation/enrichment and selects workflow definitions for BOB, and evaluates pinned rules during workflow or capability execution. BOB owns all durable workflow token/event/time/human-task orchestration and dispatches approved versioned operations to department-owned capability services using central Kafka commands or bounded embedded recipes. The SDK makes typed operation registration and schema-driven BE composition easy across languages. The BE Blazor site controls human-facing workflow Create, Execute, Execute-Lead and Read, plus capability Register/Configure and approval/release functions. External APIs authenticate Unity service identities via approved channels (often Apigee), not every end user. SQL Server organizes platform objects in lowercase `uty_` schemas with component ownership and version pinning.

## Critical decisions
- **One engine, two execution profiles:** shared BPMN interpreter, central durable BOB and approved local embedded host. Avoid competing orchestration in every microservice.
- **Three workflow/operation levels:** L1 enterprise business workflow; L2 bounded capability-owned technical workflow; L3 atomic approved operation. All categorized and discoverable contextually.
- **BPMN 2.0.2 XML plus DI** is canonical process source; Unity JSON describes typed operation/rule bindings and release metadata. An interactive mock JSON export does NOT count as BPMN XML export.
- **Phase 1 expanded executable subset:** start/end, service tasks, business-rule tasks, exclusive gateways, call activities/subprocesses, sequential multi-instance, durable Kafka wait, parallel split/join, intermediate timer catch, interrupting timer boundary, interrupting error boundary, and a minimal durable human-task/approval contract.
- **Full BPMN modeling direction:** all standard BPMN 2.0 elements visible behind experimental mode where not supported; draft save/import/export always allowed if XML is valid and preserved; execution only after element, environment and workflow approval and full validation.
- **Approval classification plus stage:** Experimental / NonProd / Approved, each independently InDev / Testing / Verified / ReleaseReady; defined on each version, not automatically inherited by children. Environment activation is separate.
- **Production:** required ServiceNow change ID (presence only for initial implementation), authorized approver/operator, immutable package and trusted release verification. File-import flow first in DEV/UAT; production upload disabled until mandatory trust mechanism exists. No developer-to-PROD direct publish.
- **Identity:** work with Matthew's current standalone auth/group approach now; Channel Secure SAML SSO and entitlement integration is a pre-go-live dependency. No external department should administer Unity individual workflow users to allow capability use.
- **Three environments only:** DEV, UAT, PROD. Do not invent a separate TEST environment.
- **AMIE intake flow:** retain for initial delivery and document a later review of orchestration-boundary refinements. Dedicated questions for Matthew remain outside both Ask documents.
- **Enterprise integrations:** Channel Secure, Apigee, Splunk, AutoSys, NAS and cron are milestone/Jira dependencies; verify existing work before creating duplicate jobs.

## Reading order
1. `docs/architecture/01-PLATFORM-CATALOG-BOUNDARIES.md` through `08-RELEASE-EXPERIMENTAL-PROMOTION.md`
2. `docs/ux/09-BLAZOR-SHELL-CATALOG.md` through `13-RUN-MONITOR-RELEASE-WIREFRAMES.md`
3. `docs/contracts/14-EVENTS-APIS-AND-BINDINGS.md`; `docs/testing/15-ACCEPTANCE-REGRESSION.md`; `docs/workflows/16-PRACTICAL-EXAMPLES.md`
4. `docs/guides/17-ADMIN-USER-GUIDES.md`, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`, and `planning/milestones-stories.md`
5. `planning/19-SOURCE-AND-DECISION-REGISTER.md`; `wireframes/Unity_v2_0_Concept_Blazor.html`
6. Internal-only `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` (excluded from Ask)

## Delivery formats
Every normative source Markdown file stays separately navigable; `ASK-MODE-HANDOFF.md` and `DEVIN-ASK.md` are byte-identical flattened documents assembled from these source Markdown files. No source is summarized; file-boundary delimiters are included. The internal Matthew review is deliberately not in either Ask document. `manifest.json` lists hashes and exclusions.

## Definitive source hierarchy and paths
1. **Current authoritative material:** This `00-START-HERE.md`, `INDEX.md`, `START-DEVIN.md`, the eight current `docs/architecture/*` files, five `docs/ux/*` files, current contracts/testing/guides/workflows, `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md`, and `planning/milestones-stories.md`.
2. **Detailed implementation references:** Retained `docs/ui/`, `docs/sdk/`, `docs/contracts/` legacy names, `docs/workflows/` legacy names, `jobs/JOB-*`, `jobs/bpmn/*` and old diagram text, each marked with a v2.1 precedence notice. Use these for exact click/test cases **after** the current decisions; do not recreate already verified code.
3. **Original evidence:** `reference-archive/v1.1-complete-original/` contains the literal 262 original files including historical archives, image and diagram assets. No instructions there override current v2.1.
4. **Internal review:** `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` is for Matthew only and **excluded from both Ask compilations**, as requested.
5. **Ask Mode:** `ASK-MODE-HANDOFF.md` and `DEVIN-ASK.md` contain identical concatenated unabridged text of all *active* `.md` documents (including amended v1.1 detail docs); the full historical archive is excluded to prevent superseded instructions and a 6 MB third-party API reference from overrunning paste limits.

## Single-package instruction
**Distribute only `WF_Unity_DEVIN_TEAM_COMPLETE_v2.1_2026-11-15.zip`.** Prior source ZIPs and v2.0 draft should not be separately assigned to Devin. Use `planning/milestones-stories.md` to hand Megan the milestone grouping; Matthew's questions are deliberately separate.
