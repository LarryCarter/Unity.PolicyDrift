# WF Unity v2.1 — Single Current Handoff Index

**Hand only this complete ZIP to Devin and the team.** It includes the original Complete v1.1 material plus modern v2.1 canonical decisions. No supplemental ZIP is required.

## Step 1 — Read before starting
- `00-START-HERE.md` — authority, approved decisions, source precedence.
- `START-DEVIN.md` — first assignment and PR protocol.
- `planning/milestones-stories.md` — Megan milestones, exactly mapped Jira stories, completion gates.
- `planning/19-SOURCE-AND-DECISION-REGISTER.md` — what has been verified, what remains unverified.
- `planning/20-COMPLETE-MERGE-VERIFICATION.md` — source archive comparison and packaging.
- `planning/21-LEGACY-CROSSWALK.md` — how to use original work packets without conflicting with v2.1.

## Step 2 — Current authoritative architecture and contracts
- `docs/architecture/01-PLATFORM-CATALOG-BOUNDARIES.md`
- `docs/architecture/02-CAPABILITY-SDK-REGISTRY.md`
- `docs/architecture/03-BOB-BPMN-RUNTIME.md`
- `docs/architecture/04-AMIE-APPROVAL-AND-INTAKE.md`
- `docs/architecture/05-SECURITY-ENTITLEMENTS.md`
- `docs/architecture/06-SQL-VERSIONED-ENTITIES.md`
- `docs/architecture/07-ENTERPRISE-INTEGRATION-READINESS.md`
- `docs/architecture/08-RELEASE-EXPERIMENTAL-PROMOTION.md`
- `docs/contracts/14-EVENTS-APIS-AND-BINDINGS.md`

## Step 3 — Blazor and workflows
- `docs/ux/09-BLAZOR-SHELL-CATALOG.md` through `13-RUN-MONITOR-RELEASE-WIREFRAMES.md`.
- `docs/guides/17-ADMIN-USER-GUIDES.md` — user setup instructions.
- `docs/workflows/16-PRACTICAL-EXAMPLES.md` — Phase 1 and deferred BPMN scenarios.
- `docs/testing/15-ACCEPTANCE-REGRESSION.md` — required proof.
- `wireframes/Unity_v2_0_Concept_Blazor.html` — updated concept mock, NOT a live Blazor application.
- `wireframes/Unity_BPMN_Configurator_Clickable_v1.1.html`, `wireframes/screenshots/*`, `previews/*` — original visual references, not live runtime proof.

## Step 4 — Implementation packets, crosswalk and Jira
- `jobs/18-DEVIN-IMPLEMENTATION-JOBS.md` — CURRENT dependency-ordered implementation sequence.
- `jobs/JOB-*` and `jobs/bpmn/*` — detailed original tasks retained with v2.1 precedence banners.
- `planning/milestones-stories.md` — milestone-linked story definitions and gates.
- `planning/21-LEGACY-CROSSWALK.md` — translation of old job IDs to current milestones and authoritative docs.

## Step 5 — Alternative Devin Ask Mode
- `ASK-MODE-HANDOFF.md` — one complete flattened CURRENT instructional Markdown document.
- `DEVIN-ASK.md` — byte-identical alias of the same content.
- The Matthew questions file remains outside Ask content by express decision.
- `reference-archive/` is deliberately not copied into Ask: original source, histories, third-party API text and skills are archival evidence and older directives must not override current design.

## Step 6 — Internal review only
- `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` — circulate for Matthew's independent approve/tweak/reject review; deferred refactor is NOT an immediate work requirement.

## Non-negotiable scope summary
One shared BOB engine central/embedded. AMIE intake preserved initially. Capability service API access separate from BE user workflows/groups. Full BPMN 2.0 modeling with experimental flags, expanded Phase 1 executable semantics. DEV/UAT/PROD only. Channel Secure and required enterprise integration work tracked prior to go-live. Production trusted artifact and authorization before activation. Every Jira story belongs to one milestone; no claims of real completion without repository evidence.
