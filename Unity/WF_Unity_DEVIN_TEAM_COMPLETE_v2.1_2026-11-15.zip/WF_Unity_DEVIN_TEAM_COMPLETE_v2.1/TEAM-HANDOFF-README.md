# Give the team ONE file: WF Unity v2.1 Complete

The delivery is the ZIP `WF_Unity_DEVIN_TEAM_COMPLETE_v2.1_2026-11-15.zip`, **not** the old v1.1 Complete/Current ZIPs and not the earlier partial v2.0 ZIP.

**Devin implementing code:** open `INDEX.md` then `START-DEVIN.md`. Begin with M0 read-only repo audit. The modern architecture and jobs are authoritative; the original 61 detailed `jobs/` files and full original v1.1 source tree are included to preserve all instructions and visuals, but older language is subordinate to current decisions.

**Devin Ask Mode:** paste `ASK-MODE-HANDOFF.md` (or `DEVIN-ASK.md`, identical). The contents are all CURRENT annotated Markdown documents, not a summary. Only archived historical sources and Matthew's internal review are excluded by design. It may be long; the file uses explicit source delimiters to support copying/pasting in the tool's supported context size.

**Megan:** review `planning/milestones-stories.md` for M0–M6 milestone descriptions, story links and acceptance gates; all story keys are proposals until added to Jira. No fabricated progress.

**Matthew:** use `docs/review/MATTHEW-AMIE-BOB-QUESTIONS.md` for the proposed AMIE interface review. This file is separate and not in Ask Mode.

**UI team:** modern detailed `docs/ux/09...13` and interactive v2.0 concept mock; v1.1 click catalogs and screenshots remain available for source review. Wireframes are not proof of implemented APIs.

**Production release:** DEV/UAT/PROD, signed/trusted artifact requirement, mandatory nonempty ServiceNow reference initially, no ticket status API integration yet, secure environment activation, Channel Secure and required enterprise integrations verified before go-live. Unverified PROD blockers may never be bypassed with only a placeholder ID.
