# WF Unity - Complete Current Architecture, Demo and Devin Handoff

**Version:** 4.0-review. **Date:** November 20, 2026.

This is the self-contained current implementation specification. It combines the agreed rationale, requirements, explicit source conflicts, UX/serialization/runtime contracts, outstanding register, milestone-linked stories, user guides and actual verification results. No older handoff needs to be reconciled to understand the requested direction.

**Preserve and extend existing working contracts.** The delivered HTML is a functional offline prototype, not the enterprise implementation. Source verification and required integration/production gates remain explicit.

## Complete reading order

1. `README-START-HERE.md`
2. `INDEX.md`
3. `DEVIN-START.md`
4. `OUTSTANDING.md`
5. `docs/00-DECISIONS-RATIONALE-AND-PRESERVATION.md`
6. `docs/01-ARCHITECTURE-AND-OWNERSHIP.md`
7. `docs/02-CAPABILITY-SDK-CYBERARK-EMAIL.md`
8. `docs/03-BOB-EXECUTION-AND-COMPILER.md`
9. `docs/04-AMIE-RULES-AND-APPROVALS.md`
10. `docs/05-DATA-CONTRACTS-LINEAGE-AND-ONE-CLICK.md`
11. `docs/06-TRIGGERS-SCHEMA-IMPORT-AND-INGESTION.md`
12. `docs/07-BPMN-XSD-NATIVE-ARTIFACTS-AND-ROUNDTRIP.md`
13. `docs/08-STUDIO-UX-CONTROLS-AND-COMMANDS.md`
14. `docs/09-GROUPS-MATURITY-AND-SECURITY.md`
15. `docs/10-RELEASE-PROMOTION-AND-CONFIGURATION-IMPORT.md`
16. `docs/11-OBSERVABILITY-AUDIT-AND-OPERATIONAL-VIEWS.md`
17. `docs/12-ENTERPRISE-INTEGRATIONS-AND-WORKBENCH.md`
18. `docs/13-LEGACY-EXTRACTION-AND-AI-READINESS.md`
19. `docs/14-ACCEPTANCE-EVIDENCE-AND-IMPLEMENTATION-BOUNDARIES.md`
20. `docs/15-CONFIGURATION-AND-USER-GUIDES.md`
21. `docs/16-SOURCES-GLOSSARY-AND-CHANGE-DISCIPLINE.md`
22. `planning/milestones-stories.md`
23. `DEMO-RUNBOOK.md`
24. `schemas/README.md`
25. `examples/README.md`
26. `demo/samples/README.md`
27. `qa/README.md`
28. `qa/QA-REPORT.md`

The following sections contain the complete text of those source documents. Matthew's separate review questions and historical archives are excluded. Generated aliases have identical bytes.


---

<!-- BEGIN SOURCE: README-START-HERE.md -->

# WF Unity - Complete current handoff v4

**Date:** November 20, 2026. **One current package:** complete decisions/specification, an offline demo, outstanding work, linked milestones/stories, reference schemas/examples, source and test evidence. This is not a claim that the enterprise implementation is finished.

## Open first

Extract the ZIP and open **START.html**. It links the current Modeling Studio, Capability Studio, readable handoff, demo runbook, outstanding register and milestone plan. You do not need an older ZIP as a separate handoff.

For the presentation, use **DEMO-RUNBOOK.md** and **demo/OPEN.html**. The demo has no backend connection and needs no credentials. The previous v3 editor is retained as a checkpoint, not a competing design.

For Devin, use **DEVIN-START.md**, then **WF-UNITY-COMPLETE-HANDOFF.md**. The master is self-contained and brings the decisions and rationale to the front. Individual files under docs/ remain available for implementation. ASK-MODE-HANDOFF.md, DEVIN-ASK.md and ASK.md contain identical complete master text. The file is intentionally large; its fit within any particular Devin paste limit has not been verified.

For Megan, use **planning/milestones-stories.md**. All 50 planning stories have an owning milestone: 46 initial-scope stories across M0-M6 and four next-phase stories under M7. No actual Jira issue keys, tickets, completion percentages or estimates are fabricated.

## What changed in this package

The current authoring specification incorporates the full platform direction and recent trigger/schema/data-lineage discussions, rather than appending conflicting notices to old jobs. The actual working v3 contextual editor was extended, not replaced. New demo behavior includes separated entry tabs, shared schema with per-adapter mappings, sample inference/locked merge, scheduled context/ingestion, a unified File entry point, and business/Ops views of local traces.

The explicit reconciliation register prevents source drift: AMIE native XML/JSON is source-verified, not replaced; multiple categories remain; no mandatory Application workspace returns; correlation is separate from dedupe; write retry safety, broker retention assumptions and production trust remain real implementation gates.

## Preservation is non-negotiable

Before production code changes, inspect and reuse working BOB, AMIE, SDK, auth/group, messaging and serializer contracts. Adapt the Studio to verified interfaces, not the other way around. The prototype's names, fixtures and XSD namespaces are proposals, not established enterprise contracts.

## Current versus historical content

- Root master and current docs/planning/QA: current implementation handoff.
- demo/: actual offline interaction/reference code. Fixture behavior is labeled.
- schemas/ and examples/: proposed/reference serialization profile and tests.
- review/MATTHEW-QUESTIONS.md: internal review, excluded from Ask copies.
- source-reference/: exact source proposal and older archives retained for provenance only; no need to reconcile their superseded requirements.

Read OUTSTANDING.md before calling any live integration complete. See qa/QA-REPORT.md for verification that was actually performed.

<!-- END SOURCE: README-START-HERE.md -->



---

<!-- BEGIN SOURCE: INDEX.md -->

# Current package index

| Need | Open |
|---|---|
| One visual starting point | START.html |
| Interactive current workflow/source designer | demo/OPEN.html |
| Capability developer/provider prototype | demo/CAPABILITY-STUDIO.html |
| Exact presentation steps | DEMO-RUNBOOK.md |
| Remaining work and blockers | OUTSTANDING.md |
| Complete authoritative current handoff | WF-UNITY-COMPLETE-HANDOFF.md |
| Devin execution instructions | DEVIN-START.md |
| Paste-ready identical master | ASK-MODE-HANDOFF.md / DEVIN-ASK.md / ASK.md |
| Milestones and story-level acceptance | planning/milestones-stories.md |
| Machine-readable milestone/story mapping | planning/milestones-stories.json |
| Current architecture and feature documents | docs/00 through docs/16 |
| Current verification evidence | qa/QA-REPORT.md and machine-readable results |
| XML schemas and examples | schemas/ and examples/ |
| Samples for the demonstration | demo/samples/ |
| Separate Matthew review (not in Ask) | review/MATTHEW-QUESTIONS.md |
| Unchanged historical sources | source-reference/ |

Every active specification is consolidated into the master in a stated reading order. Historical archives and Matthew's questionnaire are excluded. Browser-readable versions of the Markdown documents are under read/ and linked from START.html.

<!-- END SOURCE: INDEX.md -->



---

<!-- BEGIN SOURCE: DEVIN-START.md -->

# Start Devin here - WF Unity Complete Handoff v4

You are implementing the agreed Unity architecture, not designing an alternative platform. Read `WF-UNITY-COMPLETE-HANDOFF.md` as the current self-contained specification. It incorporates the rationale, current decisions, explicit source conflicts, interfaces, user journeys, test gates and milestone-linked stories. Historical archives under `source-reference/` are provenance only; do not reconcile their superseded instructions as competing requirements.

**First invariant: preserve and extend existing working AMIE, BOB, Capability SDK, auth/groups, broker, EF and serialization contracts.** Begin with M0 read-only source reconciliation. Read repository AGENTS.md. Identify actual paths, interfaces, versions, tests and completed work. Do not implement speculative duplicate services or native schemas from prototype fixture code.

## First deliverable

Provide a source-backed M0 report that maps each current subsystem requirement to retain/extend/adapt/defer. Resolve the native AMIE XML/JSON discrepancy through actual source and artifacts. Record any missing integration requirements without guessing. Existing local auth and groups remain usable while Channel Secure is completed before go-live.

## Build order

Use `planning/milestones-stories.md`. Every story belongs to a milestone. Implement the generic operation contract and CyberArk read operation, existing AMIE integration and shared BOB local host. Extract the Email operation as the second service. Then prove the whole data-hydration/update/no-change/verify path and reuse the same operations in another process. Studio work should bind those contracts, not hardcode CyberArk-specific rule logic into generic controls.

The approved runtime Phase 1 includes parallel gateways, durable intermediate timers, interrupting timer/error boundaries and minimum durable human tasks in addition to the earlier core. Do not reduce it to the demo's export/simulation subset. Defer the explicitly listed advanced constructs until implemented and validated.

## UI baseline

`demo/OPEN.html` is a functional offline interaction reference. Preserve its useful edit/mapping/rule menus and contextual BPMN orientation. The extension adds source-specific setup, universal schema/sample import, shared mappings, native-artifact preservation and example operational views. None is proof of server RBAC, deployed subscriptions, native AMIE compatibility or production readiness. Use `docs/14-ACCEPTANCE-EVIDENCE-AND-IMPLEMENTATION-BOUNDARIES.md` to separate demonstration from required implementation.

## Before claiming a story is complete

Attach actual changed paths and commits, old/new behavior, positive and negative tests, dependency/release impact and remaining limitations. Add compile/type/schema/runtime/integration evidence at the appropriate layer. Run preservation regressions before and after changes. A browser test is not an enterprise API acceptance test.

Do not silently replace BPMN with JSON, AMIE with a fixture evaluator, embedded BOB with another engine, or group policy with client-side hiding. Do not assume a registration activates a capability. Do not retry an uncertain external write blindly. Do not treat a ServiceNow ID as externally validated approval. Do not use a prototype schema as a mandate to overwrite an established production contract.

For necessary deviations, record: reason/source evidence, smallest compatible change, affected decisions and stories, regression/rollback plan and required approval. Then update the current source MD and regenerate the master and Ask copies together.

## Entry files

- `OUTSTANDING.md`: what is demonstrated versus still required/unknown.
- `DEMO-RUNBOOK.md`: exact demonstration path and honest presentation boundaries.
- `planning/milestones-stories.md`: 46 initial-scope stories and four next-phase stories, planning IDs only.
- `qa/QA-REPORT.md`: results actually run, reproduction commands, exclusions.
- `review/MATTHEW-QUESTIONS.md`: internal review questionnaire; excluded from Ask copies.

<!-- END SOURCE: DEVIN-START.md -->



---

<!-- BEGIN SOURCE: OUTSTANDING.md -->

# Outstanding work and demo-readiness register

**Date:** 2026-11-20. **Scope:** Complete current Unity implementation handoff plus an offline review demo. This register separates demonstrable behavior from enterprise work whose implementation status has not been inspected. An item listed here may already exist in the user's repositories; **verify before rebuilding**.

## The practical answer

The demo can show the central experience: one workflow; contextual BPMN, data and rule editing; source-specific configuration separate from the shared schema; CSV/JSON/Avro schema candidates; locked-field preservation; lookup-assisted hydration; local test traces; and native artifact preservation. It does not call CyberArk, Email, Kafka, AMIE, AutoSys or any bank infrastructure. It does not activate production.

The biggest remaining implementation risks are actual **native AMIE compatibility**, **BOB runtime/compiler integration**, **trusted capability registration and API behavior**, **server authorization**, and **enterprise release/integration controls**. The source audit determines how much of each is already complete. Neither the existence of a polished prototype nor the new story list means those systems must be rebuilt.

## A. Available for the demo

| Area | Evidence delivered | Boundary to say aloud |
|---|---|---|
| Existing editable BPMN/data/rule context | Re-run inherited 48-check browser suite | Structured local fixture profile, not complete BPMN engine conformance |
| Two-tab entry inspector | New source configuration and contract editor | Transport settings are saved locally, not registered on infrastructure |
| Paste/upload sample workflow | CSV/JSON/Avro schema candidate parsing and review | Bounded supported formats; not all schema dialects or production file sizes |
| Locked fields and per-adapter mappings | Shared field IDs survive re-import and source changes | Full schema evolution and registry migration remain production work |
| Scheduler example | Run context -> explicit ingestion -> business record -> Get Account | One row is simulated; no real file watcher or scheduler |
| Data-rule insertion | Visible AMIE task plus mapped field and shared Undo/Redo | Local fixture evaluator only, not Matthew's rule engine |
| Test, business portal and Ops | Same local run trace, counts and redacted audit preview | Persona navigation is not RBAC; no durable SQL/Splunk persistence |
| BPMN export/import | Example XML with native BPMN/DI and tested Unity extension profile | General unknown-content editing, official BPMN validation and native AMIE acceptance are separate gates |
| Capability Studio | Prior onboarding/configuration prototype, connected by navigation | Registry, approvals and service identities are illustrative |

**Use the QA report for exact current counts.** Sample XML and browser tests prove only the layers they actually test.

## B. Source-verification blockers before production implementation

| ID | Outstanding verification | Why it matters | Evidence required | Story / proposed owner |
|---|---|---|---|---|
| O-01 | Existing repository paths, interfaces, versions and regression suite | Prevent a speculative rewrite of working functionality | Source map and baseline build/tests | UTY-M0-01 / platform lead + Devin |
| O-02 | AMIE XML versus JSON, actual native editor/evaluator/serializer | The supplied v4 draft says JSON; earlier discussion says XML. Neither is verified here | Real rule, serializer round-trip and evaluator parity | UTY-M0-02 / Matthew |
| O-03 | Existing BOB compiler, shared runtime, persistence and Phase 1 support | A smaller demo must not shrink the approved runtime scope | Compiler/host behavior and feature evidence | UTY-M0-01, UTY-M2-01 / BOB owner |
| O-04 | Existing SDK, local auth/groups and operation descriptors | Reuse the implemented patterns rather than introduce parallel APIs | Descriptor, admission and auth traces | UTY-M0-03 / SDK and BE owners |
| O-05 | Actual CyberArk installed API, wrapper, authentication and custom fields | Public API research is not an installed contract | Sanitized installed API/schema export and wrapper fixtures | UTY-M1-03, UTY-M1-04 / CyberArk owner |
| O-06 | Actual Policy Drift Email implementation and SMTP outcome semantics | Preserve behavior and avoid duplicate uncertain sends | Source extraction plus existing mail regression | UTY-M1-05 / Email/Policy Drift owner |
| O-07 | Existing generated legacy BPMN and extracted rules | Reuse prior work but establish what can execute | Artifact readiness and behavioral characterization | UTY-M0-05 / application owner |

These are missing evidence, not evidence that the corresponding code is missing. No new production interface should be frozen until these checks are completed.

## C. Production implementation and acceptance still required

| ID | Work remaining to verify/complete | Current demo contribution | Acceptance gate |
|---|---|---|---|
| O-08 | Native BPMN compiler semantics: scopes, parallel joins, loops, timer/error races, durable human tasks | Illustrative supported-profile diagrams and tests | UTY-M2-01 through 07, live crash/race evidence |
| O-09 | Full Data Contract Resolver for arbitrary supported graphs | Structured sequential/branch fixture checks and one-click examples | UTY-M3-05: identity, branch, iteration, nullability and freshness tests |
| O-10 | Production source adapters and ingestion | Configuration and sample normalization UI | UTY-M3-03/04 and integration owner tests |
| O-11 | Comprehensive schema/model editor | Nested field grid, source bindings and safe sample merge | UTY-M3-02: arrays/item models, enum/range/default semantics, format variants and migrations |
| O-12 | General preservation-capable importer | Known-profile round-trip; unsupported input preserved/rejected rather than flattened | UTY-M3-01: supported editing and quarantined unknown data fixtures |
| O-13 | Official BPMN 2.0.2 XSD validation | Unity schemas and reference checks only | Approved official local schema bundle; run the supplied validation option |
| O-14 | Actual Blazor components and backend atomic commands | Working HTML interaction contracts | UTY-M3-06/07/08: native components + optimistic concurrency + API enforcement |
| O-15 | Trusted manifest registration, lifecycle and active environments | Capability registration concept | UTY-M1-01/02/06: source-backed SDK/service tests |
| O-16 | Server-enforced permissions, group result filtering and approval decisions | Persona views and policy design | UTY-M2-07/08, UTY-M4-01: direct API negative tests |
| O-17 | Durable inbox/outbox, external uncertainty and safe interventions | Fixture outcomes, visible blocked restart/replay | UTY-M2-05, UTY-M4-03: failure/reconciliation evidence |
| O-18 | Append-only audit persistence, run projections and telemetry | Redacted local audit preview | UTY-M4-02 and UTY-M5-03: database/monitoring evidence beyond broker retention |
| O-19 | Actual signed release/configuration import, approvals and activation | Blocked production screen and complete contract | UTY-M5-07/08/09: tamper, privilege, dependency and rollback tests |
| O-20 | Generalized deploy-once API workbench | Source/mapping/fixture pieces reusable | UTY-M4-04: live approved payload/chain/credential-reference tests |
| O-21 | Actual usability/accessibility/performance validation | Browser interaction, dark/light and narrow layout checks | UTY-M6-04: observed users, accessibility audit and measured load/recovery |

## D. Enterprise readiness dependencies (required before go-live where in pilot scope)

| Placeholder | Current evidence state | Details still needed / verification | Story |
|---|---|---|---|
| INT-CHSEC | Existing work reported; verify | Channel Secure SAML/entitlements, group mapping, revocation, environment restrictions | UTY-M5-01 |
| INT-APIGEE | Existing/onboarding status unknown | Approved route/security policies and service-account rights | UTY-M5-02 |
| INT-SPLUNK | Existing status unknown | Sink/field/redaction configuration, dashboards and operational owner | UTY-M5-03 |
| INT-AUTOSYS | Existing status unknown | Job/box, trusted trigger adapter, occurrence identity and result reporting | UTY-M5-04 |
| INT-CRON | Existing status unknown | Scheduler ownership, timezone, overlap/misfire and monitoring | UTY-M5-05 |
| INT-NAS | Meaning/owner to verify | File storage, owned data APIs or both; staging/import and permissions | UTY-M5-06 |
| INT-OTHER | To identify | Additional pilot-specific access, deployment, network and operational obligations | UTY-M0-04 |

No separate TEST environment is assumed: current environments are DEV, UAT and PROD. Unknown integration details do not stop local authoring development, but mandatory production dependencies are not waived. Reuse actual existing tickets when the user supplies them; no live Jira change is performed by this package.

## E. Source conflicts and safeguards resolved explicitly in the handoff

The current specification records, rather than hides, these differences from the supplied v4 draft:

- Preserve verified native AMIE; do not declare JSON the replacement for XML or vice versa.
- Retain optional categorization and actual L2 service ownership; do not restore a mandatory Application/Business Space field.
- Keep source extraction paths per adapter, not inside a supposedly transport-independent shared field definition.
- Keep correlation and deduplication separate. A trace ID does not automatically make repeated work safe.
- Do not treat every reachable node as having a producer's output; successful execution and path availability matter.
- Do not default every external write to three retries, compensation or DLQ. Those are distinct policies/semantics.
- Treat the reported four-day Kafka retention as unverified environment information; durable audit is independent from the beginning.
- Keep the agreed small UML/object/logic subset; a general UML state-machine runtime is not included.
- Preserve unknown imported data but distinguish preservation, editability and executability.
- An allowUserRestart flag is not authorization, reconciliation or idempotency.

These are labeled implementation reconciliations in `docs/00-DECISIONS-RATIONALE-AND-PRESERVATION.md`, not claims that the source said something different.

## F. Explicit next phase

UTY-M7-01: refine any confirmed overlapping AMIE durable orchestration after the first compatible release. UTY-M7-02: ServiceNow API integration; initially only a change-reference field is required. UTY-M7-03: AI/MCP co-design and automated policy-drift alerts under normal admission controls. UTY-M7-04: activate deferred BPMN/UML features only with concrete need and complete tests.

## Demo release decision

**Permitted:** demonstrate offline configuration, local draft edits, controlled fixture execution and the documented development plan. **Not demonstrated:** completed enterprise capability integration, native AMIE/BOB execution, real RBAC, official full BPMN conformance, safe live replay, production signing/activation, or verified migration-completion percentage.

The demo is useful precisely because it exposes the intended journey and remaining blockers. Do not hide the distinction to make the presentation sound more finished.

<!-- END SOURCE: OUTSTANDING.md -->



---

<!-- BEGIN SOURCE: docs/00-DECISIONS-RATIONALE-AND-PRESERVATION.md -->

# 00. Product intent, decisions, rationale, and preservation contract

Status: current engineering handoff, 4.0.0-review, November 20, 2026. This is a specification and offline demonstration, not a claim that the enterprise platform is implemented. The user's latest authorization permits this complete package. Earlier instructions to listen prevented changes at that time; they are not development requirements.

## The product, in one paragraph

WF Unity lets an authorized person construct business behavior from reusable, SDK-registered capability operations, AMIE decisions, and BOB workflows. Developers implement or adapt the technical primitives once. Authors subsequently change supported business conditions, mappings, sequences, branches, and local service processes through the BE designers, without recompiling those primitives. CyberArk is the primary capability and reference case; Email, extracted from Policy Drift's existing send-results implementation, is the second. A COTS API is wrapped by an approved capability service where necessary. The same contract model is intended for other departments and languages; it is not a CyberArk-only platform.

## The rule that comes before every implementation job

**Inspect and extend working AMIE, BOB, SDK, authentication, group, messaging, persistence, and serialization implementations. Never replace or duplicate them simply to fit a new UI, example, schema, or handoff.**

Devin must first locate actual repository paths, AGENTS.md, existing tests, registrations, native AMIE reader/writer, BOB persistence and host adapters, and the deployed capability clients. Proposed names in this packet are logical responsibilities, not evidence that matching classes exist. For each change produce: existing behavior and evidence; necessary extension; compatibility mechanism; regression tests; changed files. A genuine incompatibility is a decision request with alternatives and impact, not permission for a silent rewrite. Preserve the old path behind an adapter until its replacement, if explicitly authorized, proves parity.

## What the repeated wireframe iterations taught us

The original collection of many similar screens fragmented a single authoring task. A subsequent minimal prototype removed useful editing and lost the BPMN context. The accepted solution is neither extreme: retain the useful builder and add progressively deeper editable perspectives. The process remains visible while a user examines an activity, an object, a field, or an AMIE rule. Context menus, larger selection popovers, readable explanations, and one history stack make these perspectives a single tool.

Screen count, component count, file count, and ZIP integrity do not prove functional completeness. Completion is demonstrated by an end-to-end user journey and executable acceptance evidence. The original archives remain provenance only. Current requirements are stated here rather than delegated to a historical precedence notice.

## Ratified decision register

| ID | Decision | Why / constraint |
|---|---|---|
| D01 | One BOB core, central and embedded hosts | Do not create departmental orchestration engines. Local service operations and AMIE evaluations need not round-trip to central BOB. |
| D02 | BPMN 2.0.2 XML is authoritative for process and workflow-owned mappings | JSON editor state is not the only interchange format. Use native BPMN data and DI structures plus documented Unity extensions. |
| D03 | Keep native AMIE semantics and serialization | Neither this document nor an offline fixture is authority to invent a replacement rules engine. |
| D04 | Process, Rule, and Data are synchronized perspectives | No separately editable duplicate process or mapping graph. Selection, validation, history, IDs, and revision are shared. |
| D05 | Adopt only the UML concepts solving current problems | Typed objects, nested properties, multiplicity, relationships, and field connections; not a general UML/XMI/state-machine implementation. |
| D06 | Data/rule detail is a contextual zoom under BPMN | Keep enclosing process, branch, and selected activity visible. L2 authors may spend most time in this view. |
| D07 | Capabilities expose operations with typed contracts | An operation is the callable primitive; a service is its owner and execution boundary. Registration must describe inputs, outputs, versions, effects, and host eligibility. |
| D08 | Registration, approval, and environment activation are separate | Discovery is not permission to execute. Sensitive operations remain governed. |
| D09 | Human access and service-account access are separate | Departments authorize service identities, not every Unity website user. Unity controls human workflow rights and approved bindings. |
| D10 | Reuse Matthew's current authentication and groups | Do not build another local identity/group system. Channel Secure integration is pre-go-live, not an indefinite future enhancement. |
| D11 | Multiple business categories; no mandatory owning Application workspace | Classification is many-to-many and does not change access. Capability ownership of an L2 workflow remains real. |
| D12 | DEV, UAT, PROD only for current deployment | Do not invent a separate TEST environment. Testing is an activity within DEV/UAT. |
| D13 | Three maturity classes and four development stages | Experimental / NonProd / Approved, independently InDev / Testing / Verified / ReleaseReady, per resource version. |
| D14 | Experimental modeling and execution are different | Save unsupported drafts; block unsupported execution. Implemented experimental handlers may run in authorized lower environments, never because a visibility toggle bypasses checks. |
| D15 | Expanded Phase 1 BPMN remains committed | Parallel gateways, durable intermediate timers, interrupting timer/error boundaries and minimum durable human tasks are not removed by a smaller demo profile. |
| D16 | AMIE owns decisions; BOB owns durable control flow | Keep existing AMIE intake/routing for the initial delivery; assess overlapping orchestration and correct in a subsequent planned phase. |
| D17 | Approvals are BOB workflows with AMIE policies | Multilevel stages, multiple approvers, backups, and durable decision state; BE is the human interaction surface. |
| D18 | API workbench remains in scope | Reuse authentication, chain calls, use sample/CSV data, change payloads, inspect outcomes without redeploying for each experiment. |
| D19 | Business logic migrates from legacy applications into rules and BPMN | Devin accelerates extraction. Behavioral parity and side-effect safety still require proof; do not assert 90-99% readiness without inspecting artifacts. |
| D20 | Runtime requirements are not all external input requirements | Requests, previous operation outputs, rule outputs, safe defaults, and approved lookup calls all supply data. |
| D21 | Data mappings require control-flow availability | A compatible field on a later or sibling path does not satisfy a required input now. |
| D22 | One-click producer insertion is an atomic draft edit | No live API call. Reuse an eligible existing producer first; insert only when input, placement, identity, host, and type are unambiguous. |
| D23 | A rule inserted between data fields is a BPMN rule task | Never hide a second AMIE execution inside the mapper. The data card and BPMN task are one activity. |
| D24 | Enrichment owns reusable transformation expertise, not orchestration | Local pure mappings need not make a network hop. External retrieval remains an explicitly authorized capability operation executed by BOB. |
| D25 | Ordinary mappings version with their workflow | Recipes initially expand as templates into explicit tasks/mappings. No independent release lifecycle for every wire. |
| D26 | Transport is separate from shared schema | Trigger-specific mechanics, universal field definitions, and inference provenance are distinct. Source extraction binds into the shared contract. |
| D27 | Two tabs and two on-demand overlays | Trigger / Data Contract; Sample Importer; Field Detail. No permanent stack of transport, raw samples, fields, and validation. |
| D28 | Schedulers introduce run context, ingestion introduces business data | run.* is not the CSV row. Business data becomes available only after the ingestion activity succeeds. |
| D29 | Sample inference proposes, author accepts | Manual locks survive re-import. Examples are not proof of requiredness or universal types. |
| D30 | BPMN and AMIE export support normal post-release authoring | New supported business behavior should not require a return to Devin. New technical primitives can still require code. |
| D31 | Production release uses governed artifact import | Trusted origin/integrity, approved versions, groups, dependency checks, and a mandatory nonempty ServiceNow change reference. Ticket API validation is later. |
| D32 | A secret in the uploaded file is not release authorization | Signing keys stay outside packages. Import and activation are different operations. An unsigned demo is never production-ready. |
| D33 | Lower environments exercise production-style import controls | Test tampering, missing references, wrong environment, wrong entitlements, and rollback. |
| D34 | Use lowercase uty_ database schemas | Reconcile with existing EF ownership/migrations; do not force destructive renaming. |
| D35 | Enterprise dependencies have milestone/story placeholders | Channel Secure, Apigee, Splunk, AutoSys, NAS, Cron and further required integrations; existing work is verified before duplicated. |
| D36 | Each Jira story has one owning milestone | Megan can see accepted work, remaining work, blockers, and milestone gates. Placeholder IDs are not actual Jira issues. |
| D37 | Preserve full current content in one master and Ask copies | Separate documents remain available; Matthew's internal review stays outside Ask content. |
| D38 | Operational views follow the user's task and entitlements | Business portal for jobs/results, designer for authoring, Ops for diagnostics; visual personas are not security enforcement. |
| D39 | Durable audit outlives broker retention | Store mandatory evidence independently of Kafka; redacted payloads, controlled retention and access, no arbitrary table write instruction in a workflow. |
| D40 | AI-ready, not AI-dependent | Document grammar, semantics, examples and validation. Future MCP authoring is scoped, authorized, reviewable and cannot bypass release gates. |

## Decisions requiring explicit reconciliation, not silent substitution

The submitted v4 proposal is retained verbatim as `source-reference/USER-V4-PROPOSAL.txt`. It is input to this handoff, not a declaration of existing code. These resolutions preserve the agreed design while making uncertainty visible.

| Proposal or earlier assumption | Current treatment | Evidence needed |
|---|---|---|
| AMIE is native JSON, versus earlier native XML understanding | Use a format-preserving native AMIE adapter. Do not convert or assume either. Demo JSON is labeled fixture-only. | Matthew's actual serializer, schema, rule example and round-trip test. |
| Mandatory businessSpace/ownerDepartment | Optional classification/administrative metadata; no mandatory authoring workspace. Multiple categories persist. | Existing ownership fields and policy requirements. |
| SourceLocation/path embedded in universal fields | Shared field identity/type stays transport-independent; bindings carry per-adapter source location/path. Grid projects both. | Existing intake schema to adapt without breakage. |
| correlationKeyPath supplies idempotency | Separate business correlation and dedupe identity. They may use the same field only by an explicit ingress policy. | Existing consumer/inbox keys and replay policy. |
| Every reachable node gets a producer's output | Only paths where the producer is guaranteed successful have that value. Unknown/not-found/failure outcomes do not hydrate it. | Compiler control/data-flow implementation. |
| Three retries and DLQ/compensate defaults | No generic write retries or compensation assumption. Operation-specific safety and supported BPMN profile govern. | CyberArk adapter outcome/reconciliation behavior. |
| Kafka always retains exactly four days | Treat four days as a reported environment assumption; configuration is not inspected. Audit starts at admission, not after four days. | Broker/topic policy and operational owner. |
| General UML Activity/State drill-down | Keep the approved small object/logic subset. No second state-machine interpreter in Phase 1. | New requirement and design approval before expanding. |
| Lossless import means all BPMN can execute | Preserve import bytes/unknown content; mark unsupported semantics. Lossless storage, editable support, and executable support are separate. | Independent fixtures and actual compiler evidence. |
| AllowUserRestart=true means safe restart | Flag is a policy input, not authorization or proof of side-effect safety. | Entitlements, prior outcomes, reconciliation and distinct run ID. |
| targetTable chosen in workflow | Bind an approved audit sink identifier owned by the platform, not arbitrary SQL/table names. | Existing audit service and uty_audit mapping. |
| Registration automatically exposes everything | Approved compiled/adapter operation allowlist; candidate registration does not activate runtime routes. | SDK trust and deployment identity checks. |

## What may be adapted without changing the decisions

Repository paths, existing interface names, serialization plumbing, approved UI component library, database migration shape, topic names, service identities, and enterprise gateway routing must follow source evidence. The capabilities, responsibilities, preserve-existing rule, approval boundaries, and required user outcomes are not optional. An adaptation record connects the semantic requirement to its actual implementation.

## Definition of completion

An author can configure a source from sample data, bind an existing operation, supply a missing model through a lookup, place a rule in context, test all selected branches, preserve everything through export/import, and submit a governed release. Developers can expose the two first capabilities without duplicating transport or business orchestration. Operations can diagnose failures without trusting broker retention as an audit database. Each claim needs its own evidence; the offline demonstration covers only its explicitly tested subset.

<!-- END SOURCE: docs/00-DECISIONS-RATIONALE-AND-PRESERVATION.md -->



---

<!-- BEGIN SOURCE: docs/01-ARCHITECTURE-AND-OWNERSHIP.md -->

# 01. Architecture and ownership

## One platform, three levels of composition

L1 is an enterprise BOB process coordinating capabilities, waits, human tasks, outcomes and release-governed definitions. L2 is a capability-owned BPMN process using the same BOB interpreter with local operation dispatch and the existing AMIE adapter. L3 is a typed compiled operation or an approved typed API adapter. L3 is not another workflow engine. A single SMTP send need not become its own elaborate BPMN process.

Logical path: BE or approved external producer -> intake/authentication -> durable admission -> BOB -> approved capability operation or L2 workflow -> outcome -> BOB -> result projection. Existing AMIE intake may classify, enrich and select a workflow before admission; retain it until the planned ownership refinement has been reviewed. In-workflow rule tasks also use AMIE. There is no requirement for an embedded CyberArk step to call central BOB and AMIE once per local function.

## Control plane versus execution plane

The control plane governs operation descriptors, definitions, native rule artifacts, mappings, approval evidence and environment activation. Published definitions are immutable. The execution plane uses an admitted immutable dependency snapshot, evaluates local rules through supported adapters, invokes approved handlers, and checkpoints state. Cached definitions do not authorize stale permissions indefinitely: permission and revocation policy must be explicit. A central outage may permit already-approved bounded local work only under the verified cache/authorization policy; it does not mean uncontrolled offline execution.

## Components and data ownership

| Owner | Owns | Does not own |
|---|---|---|
| BE / Modeling Studio | Human authoring, contextual views, typed forms, test UI, portals | Browser-side external API credentials, Kafka producers, policy authority |
| Registry / SDK | Trusted operation descriptors, compiled handler wiring, model metadata, compatibility | Arbitrary class instantiation from XML or arbitrary API proxy URLs |
| BOB | Tokens, scopes, scheduling, waits, activity lifecycle, replay-safe coordination | Vendor authentication implementation; another rule language |
| AMIE | Existing decision evaluation, validation/mapping rules, approval plans | A new competing durable orchestrator introduced by this handoff |
| CyberArk capability | Credential/session lifecycle, vendor calls, typed result translation, guarded writes | Ownership of all Unity users, unrelated Email orchestration |
| Email capability | Existing SMTP/report-send implementation, attachment handling, send outcomes | Re-running the source business process when delivery is uncertain |
| Data/NAS owner | File staging, row identities, schema-normalized data access, data permissions | Arbitrary cross-service database access by BOB or BE |
| Enrichment capability | Approved reusable converters and mapping recipes | Implicit fetching, unbounded recursive API calls, another interpreter |
| Audit/operations | Durable evidence, projections, intervention policy, retention | Treating mutable log text as execution state |

## SQL and EF ownership

The agreed logical schemas are `uty_catalog`, `uty_security`, `uty_capability`, `uty_bob`, `uty_amie`, `uty_be`, `uty_release`, and `uty_audit`. They can share the governed SQL Server database for an environment, but ownership is not shared write access. The actual repository may already have schemas or contexts; propose a compatible migration plan rather than renaming production tables to match this document. BOB persistence is MSSQL; do not add alternative workflow persistence providers without a decision.

Minimum logical objects: WorkflowDefinition (stable identity); WorkflowRevision (draft snapshot/ETag); PublishedWorkflowVersion (immutable XML/digest); WorkflowCategoryLink (many-to-many); OperationDescriptorVersion; CapabilityService; NativeRuleArtifactReference; Activation; TriggerBinding; SchemaContract; HumanTask; WorkflowInstance; ExecutionScope; Token; ActivityAttempt; Timer; Inbox; Outbox; AuditEvent; RunProjection; ReleaseArtifact. These are responsibilities, not prescribed duplicate tables. Use existing equivalents first.

A schema contract or mapping owned only by a workflow is revisioned with that workflow. A shared service operation and native AMIE rule retain their independent approved version identities. Category labels are not execution routing, security scopes or schema identity. A folder move cannot change references.

## Identity continuity

Preserve original initiator identity, current execution identity, workflow version, correlation ID, source record ID and service-account reference through commands and audit. Do not put passwords, tokens or real secret values into those records. Inbound caller claims are verified at admission; a message field asserting `Approved=true` is not approval. The capability service validates that the command comes through the approved execution boundary and targets an activated operation; it need not resolve each human's AD membership in the external vendor API.

## What gets reused

The same descriptor drives code admission, registry discovery, operation selection, generated input controls, compiler binding and runtime dispatch. There should not be six manually maintained definitions of an operation. The model includes parameter constraints and output presence guarantees; platform-specific metadata may add conditional requirements through an approved resolver. Designer discovery does not execute those operations.

## The first coherent increment

Start with the existing CyberArk client and Email send-results code. Expose one read-only account operation with typed data. Use it inside a local BOB process with an existing AMIE rule. Change a rule/flow through supported definitions, not recompilation. Then have central BOB invoke the local process and Email. Controlled writes follow with explicit idempotency, uncertainty and verification. This is a proof sequence, not removal of the expanded Phase 1 requirements.

<!-- END SOURCE: docs/01-ARCHITECTURE-AND-OWNERSHIP.md -->



---

<!-- BEGIN SOURCE: docs/02-CAPABILITY-SDK-CYBERARK-EMAIL.md -->

# 02. Capability SDK and the first two services

## Developer experience

A developer implements or adapts a typed business primitive, registers it through trusted startup/DI, and supplies the small amount of semantics that cannot be inferred from code. The SDK should supply standard admission, correlation, schema publication, transport adapters, tracing and outcome wiring. The desired experience does not require hand-writing a Kafka consumer, registry JSON, and BE form for each new operation.

Do not implement hypothetical interfaces in parallel to the actual SDK. In M0 find the closest existing handler and registration pattern. The proposed names below describe the required contract only.

| Descriptor member | Required meaning |
|---|---|
| serviceId, operationKey, contractVersion | Stable provider/operation identity; display names may change without breaking references. |
| group/controller/category | Browsing under Service -> API group -> Operation; not a runtime permission grant. |
| inputSchema/outputSchema | Types, nested fields, cardinality, nullable versus missing, constraints, semantics and security classification. |
| effect | Read, pure transform, owned-state write, external write, destructive or secret-returning. |
| outcomes | Success output guarantees, business rejection, not found, retryable failure, permanent failure, unknown external effect. |
| host eligibility | Local embedded, remote capability dispatch, or a defined supported combination. |
| producer relationships | Which semantic values can be supplied; required lookup key, target/service scope, cardinality, freshness, no inferred identity aliasing. |
| retry/reconciliation | What is demonstrably safe; no generic automatic retry for uncertain writes. |
| availability | Approved immutable descriptor version, installed handler compatibility, enabled environments and operating status. |
| auth references | Logical service identity/connection/policy reference; no credentials in manifest. |

Registration validates duplicate keys, schema compatibility, handler existence, supported host and trusted deploy identity. It publishes a candidate only from an approved service release path. Approval and activation are independent. A newer version does not modify existing runs. The same handler must be reusable directly and through an L2 workflow; do not duplicate it for each application.

## CyberArk scope and sample vocabulary

The source research inventory is preserved under source-reference. It is a candidate catalog, not proof of the installed API version. Reconcile against the actual deployed API/Swagger, approved existing client and platform definitions. Distinguish GetAccount (one identified account) from listing/searching accounts (collection, pagination and ambiguous matches). A String is not automatically a valid Account ID.

Initial categories: Accounts (read/search/create/patch/verify), Platforms (read definitions/conditional fields), Safes (read/validate), and additional operations already approved in the existing inventory. Secret retrieval, password actions, account deletion and Safe administration remain separately governed. Do not expose all vendor endpoints merely because they were discovered.

Account models returned to BOB should contain only needed non-secret properties. The underlying connection, rotation-password retrieval and session authentication remain capability internals. Reuse the existing approved authentication sequence. Cache/refetch only according to its policy, redact credentials, and distinguish API login/session failures from a business rule rejecting an account.

## Reference case A: update four custom account fields

Business inputs are Account ID plus four desired values; the names Owner, BusinessUnit, CostCenter, Application are illustrative labels, not assertions about the deployed platform. The CSV is staged under its owning service and mapped to one typed row request. Kafka can carry that normalized row or an authorized stable reference. Keep batchId, rowId, messageId, correlationId and dedupe key distinct.

The local flow is Get current account -> AMIE compare permitted fields -> Changes? -> PATCH approved differences -> Get account again -> Verify expected changes -> typed outcome. NoChange skips the write. Rejected inputs retain a reason. A timeout after a write creates an unknown-effect state and reconciliation, not automatic failure/retry.

The CyberArk-maintained adapter example uses PATCH for account changes [EXT-CYBERARK]. The installed endpoint's exact payload, per-property add/replace/remove semantics and permissions are source-verification items. Do not turn an update into a full-object replacement. A first GET provides comparison context; it does not prove concurrency safety or force every current field to be sent back. A second GET must be a post-write observation for the same account/target, not reuse of the pre-write snapshot.

The compare rule decides whether and which approved business fields should change. A typed change set carries op/path/value under an adapter-enforced allowlist. Missing, null, blank and explicit remove are distinct. Default policy for omitted updates is preserve; clearing must be deliberate, supported and authorized. Concurrent modification protection uses only mechanisms actually available in the installed API; where conditional write support is absent, document residual race and reconciliation rather than imply atomicity.

## Reference case B: account onboarding

AddAccount may need many values supplied by the request, plus Safe, Platform, and platform-dependent properties. Selecting the operation exposes those requirements dynamically. Safe/Platform lookups may supply or validate them, but selecting a Safe or target is a policy decision, not a fuzzy name match. If several safe candidates or account identities match, require explicit author or runtime decision logic. If platform is runtime-selected, validate all constrained variants or add a runtime typed validation gate before the write. No silent claim that a design-time sample covers every platform.

A lookup result is usable only if its contract is compatible, the target/service scope is correct, it executes on the current path, its result cardinality is appropriate, and its freshness meets the consuming operation's need. A collection of accounts cannot satisfy a single Account input without explicit selection or For Each.

## Email extraction

Reuse the existing Policy Drift code responsible for SMTP transport, HTML report formatting where already implemented, attachments and send results. Extract the reusable primitive without moving Policy Drift-specific decisions into the generic Email handler. The service can expose SendReport/SendMessage according to existing interfaces; the final operation names come from source.

Inputs include approved recipients or recipient-policy reference, subject/template, body or report reference, attachment references, and a logical notification identity. Report/attachment ownership and access are checked server-side; do not allow arbitrary file paths, URLs or credentials from the browser. Sending is an external side effect. SMTP acceptance does not prove recipient delivery. An uncertain send requires a dedupe/reconciliation policy; an attempt counter alone does not provide exactly-once email. Do not resend the CyberArk change because its notification failed.

The first Email operation may remain a single compiled handler. Embedded BOB is available for genuine multi-step Email behavior, not mandatory ceremony for every send.

## API-first and multilingual onboarding

Code-first registration and approved API-definition import converge on the same operation descriptor. OpenAPI supplies useful shape information, but not complete business authorization, idempotency, freshness, or custom-platform rules. An imported route is a candidate until those semantics are reviewed. Restrict origins and methods; no unrestricted URL/method/header proxy controlled by an author.

Other languages use language-neutral registration and invocation contracts. Prioritize the two concrete services; do not build full SDKs for every language before proving them. Publish a conformance example so a Java/Python service can onboard later without changing BOB's business model. Existing Apigee onboarding remains a pre-go-live dependency for required service paths.

## Capability Studio user journey

Connect/reuse approved service -> inspect discovered groups and operations -> review one operation's inputs, outputs, effects and availability -> test with fixtures or authorized DEV data -> submit candidate -> authorized review/activation -> see the same operation in the workflow picker. Keep this within the service detail context. Tabs may be Operations, Local workflows, Rules, Configuration, and Review; do not create a separate page per metadata field.

A service-local workflow library defaults to that capability's L2 definitions and associated rules. Enterprise workflows remain searchable by multiple categories. The capability owner can expose an approved L2 workflow as a callable operation with its own typed input/output contract, without shipping internal function names to authors.

## Acceptance evidence

Prove that two different processes reuse the same account handler; Email uses the same registration mechanism; registration alone cannot execute; invalid manifest/schema/host is rejected; external credentials never appear in UI/XML/audit; new versions coexist with pinned old runs; compatible rule/flow changes require no capability binary rebuild; a new unsupported vendor function still requires a reviewed implementation. Show the actual files changed and before/after API behavior.

<!-- END SOURCE: docs/02-CAPABILITY-SDK-CYBERARK-EMAIL.md -->



---

<!-- BEGIN SOURCE: docs/03-BOB-EXECUTION-AND-COMPILER.md -->

# 03. BOB execution profile and compiler contract

## Current scope, not merely the browser's subset

Retain start/end events, service tasks, AMIE Business Rule Tasks, exclusive gateways and sequence flows, call activities and subprocesses, sequential multi-instance, and durable Kafka outcome waits. Add parallel split/join gateways, intermediate timer catches, interrupting timer boundaries, interrupting error boundaries, and minimum durable human tasks. Provide equivalent supported semantics in central and embedded hosts where host capabilities allow them. A local in-memory host cannot pretend to support a durable wait.

Defer non-interrupting boundary execution, inclusive/event-based gateways, parallel multi-instance, compensation and event subprocesses unless separate implementation evidence changes their status. Pools, lanes, annotations and data modeling need authoring/preservation support, not an invented execution effect. Unsupported draft features must remain identifiable and block execution; never silently become no-op tasks. The full modeling catalog is broader than the runtime profile.

## Compiler stages

1. Parse securely: reject DTD/external entities, enforce size/depth limits, validate XML and namespace/version policy without fetching arbitrary schema URLs.
2. Preserve original document and opaque extensions. Identify known BPMN, Unity extension and native AMIE references. Editing support is not inferred from successful parsing.
3. Resolve stable IDs, scope, sequence flows, data associations, input/output definitions, operation descriptors, rule artifacts and mapping references.
4. Normalize into the existing BOB execution representation or a compatible extension. No new interpreter merely because an example has a different DTO.
5. Validate node support, host eligibility, version dependencies, allowed operations, typed bindings, branch availability, wait correlation, safe failure paths and permissions.
6. Produce a deterministic dependency snapshot, diagnostic list and compiled plan. The diagnostic links to the original BPMN node/field/edge.
7. At activation, recheck deployed versions, environment policies and trust. At runtime, validate actual payloads and authority; design-time checks are not sufficient.

Errors are stable codes with severity, node/field identity, explanation and remedy. Examples: UNBOUND_OPERATION, RULE_ARTIFACT_UNRESOLVED, DATA_SOURCE_UNAVAILABLE, TYPE_MISMATCH, CONDITIONAL_FIELD_UNRESOLVED, UNSUPPORTED_EXECUTION, WRITE_RECONCILIATION_REQUIRED. Draft save/export may remain available while publish/run is blocked. Do not equate zero UI warnings with production acceptance.

## Token/scope model

A run is identified independently of a definition version. Tokens reference execution scope, activity occurrence and branch activation. Parallel joins count the required incoming tokens for the correct activation, not just the first result or a globally shared counter. Nested calls, loop iterations and repeat visits to a gateway must not mix their join state. Commit state transitions with optimistic concurrency and deterministic terminal outcomes. Concurrent responses can advance an activity logically once.

At an exclusive decision, AMIE evaluation occurs as a Business Rule Task; the gateway routes on its typed outcome. It never performs a hidden capability action. Conditions and default paths must be explicit. An enum decision cannot silently become a Boolean Yes/No gate. An error boundary catches a declared BPMN error outcome; not every exception should be mapped to an anticipated business error.

## Timers and interruption

Persist timer due time, timezone normalization and ownership/cancellation state. A timer callback and a successful task outcome may race; one wins the scoped transition atomically. Interrupting a task's workflow path does not prove the external API call stopped. Late outcomes are recorded, correlated and reconciled without reopening a completed scope by accident. Intermediate timers resume after restart using durable state, not a sleeping HTTP request or UI timer.

Duration UI uses amount plus unit and translates to the supported representation. Timeout means a maximum permitted wait; retry delay and scheduled due date are different concepts. Do not offer free text that looks like a working error branch when no BPMN edge/event exists.

## Loops and collections

For Each maps to supported sequential multi-instance for the initial profile. Declare collection type, item variable, item identity, output aggregation and ordering. A zero-element collection may skip the activity; outputs must not be assumed present afterward. A body-produced value cannot satisfy the first iteration's required input without an initializer. Parallel iteration is not implied by showing a collection card. Arbitrary cycles, Repeat Until and advanced loop syntax require verified compiler semantics and bounded-run policy before activation.

## Durable messaging

Persist admission/inbox dedupe and the workflow's initial state before committing the corresponding consumer progress according to the existing broker integration. For remote dispatch, commit pending command + correlation + outbox consistently, then publish. Receiving capabilities validate trusted producer, operation/version/host, request schema and dedupe identity. Duplicate commands replay known outcomes rather than replaying arbitrary writes. The outcome consumer deduplicates before advancing the BOB token.

Keep messageId (delivery identity), businessCorrelationId (business conversation), executionId, activityInstanceId, commandId, attemptId, idempotencyKey and batch/row identity distinct. Correlation groups related events; it is not automatically a uniqueness constraint. A restart is a new run linked to the old one. A retry is a new attempt under a defined logical operation policy. A broker redelivery is neither by itself.

## Operations: pause, resume, cancel, restart

Pause cooperatively at safe checkpoints. Resume the admitted version/continuation after rechecking policy. Cancel prevents further work but cannot erase an external side effect. Restart creates a distinct run and records what is reprocessed. Replay-from-step requires proof that preceding outputs remain available and trustworthy and that target effects can safely be repeated or reconciled. A friendly BE restart button is policy-controlled; it is not an unrestricted instruction to resubmit a destructive request.

## Required regression cases

Parallel branch race and restart; timer-completion race; boundary-error propagation from a nested subprocess; duplicate/lost/out-of-order outcomes; timeout after successful vendor write; cancellation with late result; first/zero/multiple loop iterations; old instance after a new definition activates; lower-host durability rejection; unapproved operation dispatch; missing mapping on one branch; failure outcome with no success object; rule success followed by external write failure. Report the exact supported subset and failing cases. No blanket BPMN-conformance claim follows from an XSD check.

<!-- END SOURCE: docs/03-BOB-EXECUTION-AND-COMPILER.md -->



---

<!-- BEGIN SOURCE: docs/04-AMIE-RULES-AND-APPROVALS.md -->

# 04. AMIE integration, rules and approvals

## Existing AMIE is the authority

The conversation initially described native AMIE XML, while the submitted v4 draft describes native AMIE JSON. Neither establishes the actual serializer without source evidence. Preserve whichever format(s) Matthew's implementation supports; do not translate native logic into invented XML attributes or a new JSON rule language. The handoff's native-artifact reference includes format, engine/schema version, immutable rule identity/version, digest, and artifact location. Format is verified by an adapter, not guessed from a filename.

The offline prototype's comparison/normalization functions and any JSON shown in its preview are fixtures. They demonstrate UI behavior, not the production AMIE evaluator. This is an explicit outstanding blocker for real import/activation, not a reason to halt UI and contract development.

## AMIE catalog and authoring

Rules can be grouped by service/capability, multiple business categories, and rule family: eligibility, classification, validation, mapping, routing, approval policy and notification policy. Avoid a mandatory application/workspace gate. Display description, input facts, output outcomes, approved version, maturity, consumers, and review history. A larger searchable popover is appropriate for inspecting a rule; a small dropdown cannot adequately describe complex logic.

Selecting a Business Rule Task in BPMN opens the same rule in context. Facts map through the same binding graph used by Data view. Changing a rule version preserves the task ID and compatible mappings, flags incompatible ports and invalidates prior test evidence. Editing a shared approved rule starts a draft; it does not mutate all consuming workflows. A workflow-local edit needs its own release-supported native rule artifact or an existing AMIE local-parameter mechanism, not an untracked hidden script.

The visual editor may use decision tables, conditions and expression forms supported by the real engine. It must preserve precedence, defaults, missing/null behavior and output types. Raw native content is an optional advanced view; syntax validity alone is not semantic validation. Do not force general UML state diagrams or DMN conformance into AMIE.

## Rules between mapped fields

For a pure compatible rule, the author selects a connection or target field, opens its three-dot menu, chooses Insert rule, examines required facts, and confirms. The command inserts an explicit BPMN Business Rule Task, connects source -> rule input -> rule output -> original target, and rewires control flow on a valid path. One Undo reverses all changes. The original parent-object mapping remains; the selected child becomes an override. Removing the rule can restore the source after type/availability checks.

A multi-fact, multi-output or side-effecting rule does not fit a compact single-value slot. Open a normal Business Rule Task fact mapper instead. The UI must show when required additional inputs are missing. Never execute the rule both as a data transformation and as a BPMN task.

## Initial intake and future ownership correction

Retain the current AMIE intake behavior for the first delivery: inspect/classify/enrich the request, select an approved workflow, and send it to BOB's intake. BOB independently admits the selected workflow/version and owns execution, waits and recovery. If source review finds AMIE maintaining overlapping durable orchestration, record it and implement a compatible correction in the next phase. Do not force a broad rewrite of functioning intake as a prerequisite to the first CyberArk/Email increment.

Use a typed decision envelope carrying workflow selection, rule/version evidence, normalized facts or approved reference, reason codes, original identity and correlation. A decision may reject, route, enrich, or request more data; it cannot bypass a production entitlement or activate an unapproved operation.

## Approval policy and execution

AMIE determines whether approval is needed and emits a typed approval plan. BOB creates and persists human tasks and stages. BE displays only tasks the user is eligible to act on. The authorization boundary validates every decision independently of a visible button. Multilevel stages are ordered; initial stage semantics are AnyOne and AllRequired with multiple eligible approvers and approved backup groups. Backups do not double-count an individual, override rejection policy or silently expand privileges.

Persist task identity, stage revision, eligible groups/policy snapshot, claimant where applicable, decision, reason, actor, timestamp and completion evidence. Concurrent approvals must not advance the stage twice. Define rejection, expiry, cancelled request, late response and changed entitlement behavior. Four-eyes/separation policy comes from existing governance and AMIE, not a hardcoded UI job title. Self-approval must be checked where policy forbids it.

Future ServiceNow approval integration is a capability/adaptor, not replacement of BOB's task state. Initial production changes require a nonempty ServiceNow reference, without external ticket-status validation. The reference is traceability, not independent approval proof.

## Rule tests and user explanation

Each published rule needs fixtures for matched, unmatched, boundary, missing/null and invalid-type inputs. The trace identifies rule/version and facts used, not only a Boolean result. Mask sensitive values and show business reason codes. The user should be able to inspect why an account was skipped without reading C# or knowing Kafka. Preserve available existing AMIE traces rather than build a competing trace format.

<!-- END SOURCE: docs/04-AMIE-RULES-AND-APPROVALS.md -->



---

<!-- BEGIN SOURCE: docs/05-DATA-CONTRACTS-LINEAGE-AND-ONE-CLICK.md -->

# 05. Data contracts, progressive hydration, and one-click connection

## Four related contracts, one authoring model

A source schema describes what arrives: CSV columns, message body/key/headers, form values, API body/path/query, or scheduler context. A workflow input contract describes normalized values admitted into a process. Each activity has an authoritative provider-owned input/output contract. The working data graph records values acquired and produced along each execution path. These are related models, not four independent copies of the workflow.

An operation's requirement is not automatically a required external input. Account ID plus four desired fields can satisfy a workflow that retrieves current account data itself. Onboarding can require many incoming fields plus lookup-derived Safe/Platform information. Resolve the full flow before proposing the external contract. Authors can also add business fields such as justification and business reference, even when no capability currently consumes them. Removing a step removes its outputs and revalidates consumers; it must not automatically delete author-declared request fields.

## Canonical field metadata

Stable field ID; display name/path; type or registered model reference; semantic identity; requiredness; nullability; scalar/collection cardinality; constraints; sensitivity; default policy; provenance. Nested object and array-item definitions are explicit. Required means the property must be present; nullable means a present value may be null. Empty String is not missing, null, or permission to remove a remote value. Defaults are applied by a declared stage, not assumed by a schema validator. A sample value is test data, not a default.

Source extraction is an adapter-specific binding: adapter ID + source location + path/column identity -> stable normalized field ID + optional approved conversion. Shared field schemas do not store a single Kafka path that becomes meaningless when a CSV adapter is added. The grid can display Type and Source together, but their persistence is separate. Changing the adapter preserves field IDs and exposes incompatible bindings for repair.

## Runtime value identity

A value's type alone does not identify the entity it describes. Lineage must carry producing activity occurrence, input identity, service/target scope, iteration/record identity, schema/version, outcome presence, and observation point where relevant. A CyberArk account read for account A cannot satisfy a request about B. A pre-write snapshot cannot verify a post-write change. A collection cannot silently become its first element. A value inside one loop iteration does not populate all other iterations.

Keep producer outputs immutable from the consumer's perspective. Whole-object mappings copy/project into a target object; field overrides change that target, not the upstream snapshot or another consumer. Detect conflicting whole-object/field writes and define override order explicitly. Mark whether a child mapping is inherited, explicit, intentionally unmapped, defaulted, computed, or conditionally available.

## Resolver result states

| State | Meaning | UI action |
|---|---|---|
| Connected | Existing binding meets type and availability checks | Inspect source or change mapping |
| Ready to connect | One compatible available source exists but no binding yet | Connect existing data |
| Needs mapping | Compatible information requires an explicit conversion/projection | Choose mapping/recipe |
| Can be obtained | An approved producer can provide the model and has satisfiable inputs | Add producer and connect, or review options |
| Conditional | Data is present only for certain outcomes/branches | Add guard/default or move the consumer |
| Missing | No acceptable binding plan exists | Explain missing field and offer external input/lookup choices |
| Invalid | Existing binding references a removed step, wrong type/entity/host | Highlight exact source/target and remedy |

Suggestions are metadata analysis, never live API calls. Registry search is scoped by service, environment, maturity, authoring permission, host and semantic contract. Semantic compatibility is declared by the provider or an approved mapping; fuzzy field-name similarity is a recommendation requiring review, not runtime proof.

## Exact Add Get Account and Connect interaction

Precondition: selected AMIE comparison needs currentAccount. The request supplies one semantically valid Account ID and desired fields. No suitable current account object is available. The compact inspector shows: `Current account - Missing` and `Get Account can provide this using Request.Account ID`. Primary action: **Add Get Account and Connect**. Secondary link: **Choose another source**. Full lineage stays closed.

On click, compute an insertion plan against the current draft revision. Confirm operation/version/activation eligibility, host adapter, account identity/target, required inputs, source uniqueness, success-only output guarantee, acceptable insertion scope and no circular dependency. First search for an existing eligible Get Account producer. Reuse it only if entity, target, freshness and path are correct. Multiple candidates require the larger source popover.

For a new producer, insert one Service Task immediately before the consumer on its valid control path. Bind request.accountRef -> GetAccount.accountRef. Bind its successful account output -> Compare.currentAccount. Preserve the desired-fields mapping. Add native input/output associations and corresponding fine-grained Unity binding records. Recalculate downstream availability. Show `Connected - supplied by Get current account` and a short success message with Undo. Keep the comparison selected and highlight the inserted task in the BPMN context strip.

This is one command/history unit, one draft revision and, in production, one atomic backend mutation. It must be conditional on an ETag/revision, with command ID for safe reapplication. Validation failure, stale revision or cancelled choice leaves the draft unchanged. Browser Undo/Redo preserves stable IDs. Runtime credentials and external calls are never touched by this authoring command.

If the consumer can be reached without the producer, no safe single insertion is possible until topology is resolved. A parallel sibling's output is not available merely because both branches are visible. A producer on an error path cannot supply success data. No recursive suggestion may introduce a write as an implicit lookup.

## Compiler data-flow analysis

For ordinary sequence, propagate only guaranteed outputs after successful completion. For XOR merges, compute availability across feasible incoming paths; fields missing on one path require an explicit optional/guarded contract. For parallel joins, combine guaranteed completed branch outputs with unique identities and collision handling, not the same rule used for XOR. Non-joined concurrent branches cannot assume each other's values. Nested subprocesses export only declared outputs. Iteration scopes and zero-iteration paths need explicit aggregation. Error, timeout, cancellation and unknown-effect paths have their own outcome contracts.

A production resolver needs graph-aware analysis over the actual BOB IR, with termination bounds and diagnostics. The demo's structured list traversal is not that full analysis. Do not infer completeness from a happy-path fixture. Registry producer search should have a configured depth/cost limit, cycle detection, deterministic ranking and an explanation of each proposed plan. Human choice is required when safe alternatives remain ambiguous.

## Enrichment and mapping recipes

Reuse the proposed Enrichment capability for approved transformations, normalization, projection and object composition. Pure local conversions can run locally through the shared adapter; do not force a network service hop for every String conversion. Lookup calls remain explicit operations. AMIE owns business-dependent comparison, permission and policy logic; do not split the same decision between a mapping language and a new rules engine.

Recipes initially act as authoring templates: choose, preview, expand into explicit mappings/tasks, review, save in the BPMN workflow. The workflow revision owns the generated content. A later live reusable transformation dependency must be pinned and approved; it is not required for every ordinary wire. No arbitrary JavaScript, C#, SQL, file access or HTTP calls embedded in a mapping expression.

## Data view behavior

Blue available sources -> violet rules/conversions -> teal selected target. Whole objects display as one connection until expanded. Selecting an object, field or connector opens its own three-dot/right-click menu. Actions include change source, use parent mapping, leave unmapped, insert compatible rule, inspect lineage and remove connection. Explain why incompatible sources are disabled. Context persists through popovers. Keyboard selection and Connect are alternatives to dragging; color never carries meaning alone.

Full lineage is on demand and shows source adapter, normalized field, producing step/outcome, transformations, consumers, type and any conditional availability. It edits the same mappings. A data connection does not silently reorder BPMN: any required topology change is a named atomic command with a before/after explanation.

<!-- END SOURCE: docs/05-DATA-CONTRACTS-LINEAGE-AND-ONE-CLICK.md -->



---

<!-- BEGIN SOURCE: docs/06-TRIGGERS-SCHEMA-IMPORT-AND-INGESTION.md -->

# 06. Triggers, shared contracts, samples and two-stage ingestion

## The separation that fixes the clutter

A Trigger Adapter determines how a process wakes up. A Shared Schema Contract describes the information the workflow consumes. Sample provenance records what was inferred, from which authoring source, and which fields the user subsequently locked. Source-to-contract bindings connect the adapter's raw message/columns to normalized fields. The UI has two tabs, not four permanent editors: Trigger and Data Contract. Sample Importer and Field Detail open only on demand.

Multiple configured launch methods can target the same workflow. Each validates its own extraction against the admitted contract. Switching adapter type does not erase the schema, silently remap sources, or create another business process. Configuration can reference a centrally governed connection, endpoint or scheduler; an author is not necessarily authorized to provision it.

## Kafka: mechanics, gate, extraction and admission

Trigger tab: approved connection reference; topic/subscription identity; consumer group/ownership; initial offset-reset policy; payload decoder/schema reference; message gate; business correlation extraction; dedupe extraction and scope. Passwords/certificates are managed through approved connections, not pasted into the inspector.

Gate input may come from a decoded payload field, header or verified schema identity. A Schema Registry subject/version is not interchangeable with a numeric wire schema ID. A topic is transport, not a business type. A malformed decoder/schema mismatch must fail or quarantine under explicit policy before the business gate is evaluated. An unmatched gate is a recorded non-start, not necessarily an error or a new run.

Correlation describes a business conversation. Idempotency identifies a logical admission/write. They may coincide only under a declared producer contract. Persist dedupe state before advancing consumer progress. Two workflows using the same consumer group may compete for deliveries; the subscription owner must choose shared-dispatch versus independent subscriptions deliberately. Do not create consumer groups casually from each UI tab.

Offset reset applies when a valid committed position is absent/out of range, not a command to replay every existing message each time [EXT-KAFKA]. Expose replay as a distinct governed operation. Confirm topic retention and compaction policies; a displayed four-day example is not a guaranteed message expiry timestamp.

## CSV/file input

Trigger tab: authorized connection/directory/bucket reference, file mask, delimiter, header mode, encoding and completion detection. A file-created event is not proof the file is completely written. Ownership must define atomic landing/rename, marker or another reliable completeness mechanism. Define no-file, malformed-file, duplicate-file, duplicate-row and partial-row policies separately.

Data Contract tab: shared fields and bindings to source column name/index. Paste/upload sample supports quoted delimiters, escaped quotes, CRLF, BOM, empty cells, duplicate headers and uneven rows. Preview representative records and inference warnings. Leading-zero identifiers must not become integers silently. A headerless sample requires explicitly named source columns. A changed column order is detected by stable name where available; ordinal fallback is explicit.

The intake flow can stage a file on NAS, persist rows under its data-owner service, and emit one normalized record/request or stable row reference. It may also use a batch request with declared page/iteration semantics. A CSV file is not automatically one account. Preserve file/batch/row IDs and mapping version so the result can be traced back to the source row. A bad row is handled according to chosen policy; do not silently discard it or stop all rows without explaining the configured behavior.

## API and BE forms

API/webhook transport includes approved route/method/auth mode/content type and request size policy. Source bindings distinguish body, path, query and headers. Authentication/authorization remain server-side. An OpenAPI snippet can seed a candidate schema, not grant an endpoint or connection.

BE forms use the existing form/auth stack. Form fields can be generated from or mapped to a shared contract, with constraints and friendly labels. Persist the submitted request under the owning service and publish a durable start command according to the platform path. A form's convenience client validation does not replace server validation. Inferred fields from example JSON or an existing DTO must be reviewed. HTML/DTO parsing is a proposed extended importer, not arbitrary code execution.

## AutoSys and Cron: two-stage data introduction

The initial output is RunContext: runId, jobName, scheduledUtc, scheduledDate, timezone, and approved static parameters as applicable. The scheduled date is calculated using the declared business timezone; retain UTC timestamp separately. Actual start/late execution time must not silently replace intended scheduled time. DST and misfires need an explicit scheduler policy.

AutoSys identifies an existing job/box/invocation configuration. Cron identifies a schedule and timezone owned by the chosen scheduler integration. Do not run the same schedule in both without deliberate dedupe ownership. The UI configures a binding; it does not claim to deploy AutoSys jobs.

The next activity, such as Ingest CSV or Read Data API, consumes run context and emits a new Business Data Contract. Example: run.scheduledDate fills an approved path parameter, then ingestion outputs ingest.records or an item-scoped ingest.record. The universal field grid and Sample Importer are reused for this output contract. Data becomes available after that producer succeeds; run.* and ingest.* must not be collapsed into a fictitious incoming payload.

A dynamic path/URL uses constrained typed bindings through an approved source, not arbitrary String concatenation. Prevent traversal and unauthorized destinations. A SQL-related option means a parameterized owner-managed query capability, never arbitrary SQL entered into BOB/BE. Missing file options are fail, explicit skip outcome or bounded retry; do not invent success data after a skip.

## Sample-to-Schema interaction

1. Open Paste / Upload Sample; choose format or inspect detection. No raw sample box stays on the main inspector.
2. Parse within size/depth/row limits. Produce candidates, sample values, detected nulls, warnings and proposed types. JSON recursive objects/arrays and Avro schema input are different parsing modes; an Avro schema is not a runtime record example.
3. Review each candidate. Select additions/updates, rename normalized fields, choose conversions, and inspect source bindings. Inferring all rows have a value does not prove `required=true`; absence in a sample does not prove an optional contract never includes it.
4. Apply a previewed merge atomically. Preserve stable IDs and locked manual changes, add approved new fields, retain omitted existing fields until explicitly removed, flag type conflicts rather than widen destructively. No re-inference deletes downstream mappings by accident.
5. Validate examples against the accepted contract, save and expose the resulting fields to lineage. Sensitive raw samples are not required production artifacts; apply redaction and retention controls.

Field Detail edits type, semantic identity, required/nullable, default policy, enum/pattern/range, sample and per-adapter source binding. Default values must be typed and validate; a blank default field means no default unless explicitly selected. Locked protects against automatic sample merge, not authorized manual editing. Root array shape and item type must be explicit; an empty array cannot identify the element model.

## Required acceptance fixtures

CSV with quoted comma and newline; leading-zero account ID; header rename/reorder; duplicate headers; non-UTF8 encoding declaration; all-empty column; mixed type column; nested JSON and array of objects; empty array; JSON null versus missing; Avro nullable union and logical type; forbidden recursive/unsupported schema; locked field changed by a sample; sample omitting an existing field; Kafka body/key/header mapping; API path plus body; scheduler context followed by ingestion; no-file retry exhaustion; run.* cannot be mistaken for account data.

<!-- END SOURCE: docs/06-TRIGGERS-SCHEMA-IMPORT-AND-INGESTION.md -->



---

<!-- BEGIN SOURCE: docs/07-BPMN-XSD-NATIVE-ARTIFACTS-AND-ROUNDTRIP.md -->

# 07. XML, XSD, native artifacts and preservation

## Format authority

BPMN 2.0.2 XML stores process semantics and standard DI. Use native data objects, item definitions, input/output specification and data associations where appropriate. Unity extensions express typed operation bindings, fine-grained field paths, shared-contract metadata, source adapters, mapping semantics and contextual-view layout not covered by native elements. AMIE rule logic remains in its verified native artifact; BPMN stores rule location/reference/version and fact/result binding.

BPMN provides sanctioned extension locations [EXT-BPMN]. An XSD validates allowed structure; it does not teach a renderer which object card to draw, enforce workflow authorization or define all execution semantics. Each extension must have a schema rule, semantic validation rule, UI command and runtime owner. No imported schema URI is automatically fetched/executed.

## Storage and versioning

Drafts may use an in-memory graph/JSON projection for editing, but BPMN XML plus its native dependencies is the portable source artifact. Ordinary workflow mappings are serialized with the workflow and versioned as part of it. A read-only compiled cache may have its own digest/compatibility marker without becoming a competing editable source. Mapping recipes expand into explicit workflow content unless a deliberately pinned shared dependency is chosen.

Schema namespace version identifies tooling grammar, not a new independent business approval for every field. Old workflow versions remain immutable; a compatible edit creates a draft/new release. Existing source contracts take precedence over the proposed prototype namespace after documented reconciliation.

## Proposed extension surface

The runnable demo retains its tested v3 activity/type/field mapping profile and adds a clearly named v4 entry-configuration extension. The extension is a review profile, not the enterprise contract. A generated v3 request summary is a compatibility projection of the one v4 shared contract; import rejects disagreement. Production should converge on one verified schema model rather than maintain independently editable duplicate declarations.

| Concept | Native BPMN | Unity/native addition |
|---|---|---|
| Process order | sequenceFlow, events, activities, gateways | No hidden order inside a data wire |
| Operation call | serviceTask and input/output definitions | Approved operation/version/host reference |
| Business evaluation | businessRuleTask | Native AMIE rule reference/digest, fact/result binding |
| Whole object availability | dataObject/itemDefinition/dataAssociation | Schema/semantic identity, outcome guarantee, field projection |
| Field override | Relevant native association retained | Source/target stable field refs and explicit override/transform policy |
| Entry launch | Supported start event/admission path | Independent trigger bindings, source schema and normalization mappings |
| Data-context layout | BPMN DI for BPMN geometry | Object-card expansion, positions and selected context; presentation only |
| Workflow classification | Optional standard documentation/grouping | Multiple business-category references, no implicit access grant |
| Observability | Process/activity identities | Approved logging/audit policy references, no arbitrary table destination |

`schemas/unity-entry-v4.xsd` describes the demo entry configuration. `schemas/unity-modeling-v3.xsd` is preserved to validate the inherited modeling layer. These schemas do not replace native AMIE, the BOB compiler or the future production extension contract. Examples under examples/ are flagged non-executable review artifacts.

## Native AMIE preservation

A release dependency record describes ruleId/version, media type (`application/xml` or `application/json` as actually supported), engine/schema version, content digest and immutable location. Preserve bytes for opaque native artifacts until the real adapter can parse/serialize them. CDATA is a storage convenience, not a JSON validator, executable trust or a promise of original bytes. External artifact files with digests are preferable for clear integrity and reuse. Do not author a fake AMIE rules file and call it native.

An imported native rule that cannot be interpreted remains retained with a blocker. No activation until the verified adapter validates both syntax and semantics. User editing in raw mode affects a draft and invalidates prior evidence; it never mutates a shared approved artifact in place.

## Lossless has three separate meanings

**Byte preservation:** retain the original upload unchanged for evidence/rollback. **Model preservation:** save/export retains known executable meaning, IDs, references, layout and unknown content without dropping it. **Editable support:** the UI can safely change a declared subset. These are not equivalent to universal execution support.

An incomplete but supported document loads with an actionable checklist: unbound capability, missing form mapping, unresolved native rule or unsupported host. Unknown extensions and unsupported topology must be preserved in a restricted/read-only envelope if safe editing cannot be guaranteed. Export original remains available; execution stays blocked. Never flatten unknown content into the nearest supported task.

The demo demonstrates editable round-trip only for its documented structured profile. It also provides an explicit preserved-original path for other safe XML. That path does not claim editable or executable semantic support. Production needs an AST/DOM preservation layer, migration registry, namespace handling and fixture suite before claiming general lossless editing.

## Mapping source of truth and consistency

Changes from Process, Data or Rule view enter the same command store and update one binding graph. Native associations and extension field mappings are generated together. Validate they reference real ports and do not disagree. A hand-edited XML file that changes a native flow but leaves a contradictory extension must be diagnosed, not resolved by secretly preferring whichever representation is convenient.

When native BPMN or DI cannot represent the richer visual details, store presentation metadata under a distinct extension. Changing theme or zoom does not alter execution semantics. Stable element and field IDs survive rename, movement, rule rebinding and view switches. Graph layout is not the control-flow ordering algorithm.

## XML security and validation levels

Reject DTD/entities and externally resolved resource references; use local allowlisted schemas. Apply archive traversal, compressed-size and expansion limits to packages. Check XML parse, Unity XSD, official BPMN XSD, native cross-references, typed semantic compilation, host/security admission and actual runtime execution independently. A green extension-schema result does not prove the full BPMN file validates or executes.

The supplied QA scripts distinguish these results. Official OMG XSD validation requires an approved local complete bundle including BPMN20.xsd, Semantic.xsd, BPMNDI.xsd, DC.xsd and DI.xsd. External retrieval was unavailable in this build environment; no full-standard validation result is asserted. The exact command and failing/skipped status are documented instead of substituting a homemade BPMN schema.

<!-- END SOURCE: docs/07-BPMN-XSD-NATIVE-ARTIFACTS-AND-ROUNDTRIP.md -->



---

<!-- BEGIN SOURCE: docs/08-STUDIO-UX-CONTROLS-AND-COMMANDS.md -->

# 08. Studio UX and command contract

## One journey, progressively deeper layers

Define -> Build -> Test -> Release remains the primary workflow journey. Do not implement the older 55 screen sketches as 55 mandatory authoring routes. They are historical coverage evidence; their useful functions are consolidated here. Keep task-focused business views and privileged administration separate from routine authoring.

Define names the workflow, description, multiple categories, owner/contact metadata where applicable, contract and independently configured entry adapters. No required Application workspace. Build combines guided steps/BPMN with contextual Data and Rule detail. Test uses supplied fixtures or separately authorized DEV integration tests. Release reports evidence and produces a governed artifact; exporting is not activation.

## Entry inspector contract

The selected Start/entry binding opens two tabs: Trigger and Data Contract (Run Context for a scheduler). Trigger shows only source-specific mechanics and gates. Data Contract shows a compact field grid with Add Field and Paste / Upload Sample. Clicking a field or Edit opens a detail slide-over; closing returns to the same field row and scroll position. Sample Importer is an on-demand overlay with detection, preview, locked merge and Apply/Cancel. Existing context is not destroyed.

For scheduled ingestion, reuse the same grid/importer under the ingestion activity's Output Data Contract. Source Config contains bound path/API arguments and no-file/failure handling. A schedule is not silently converted into a CSV transport by selecting a sample.

## Contextual modeling

Select a BPMN activity -> inspect its inputs -> zoom into objects/fields -> inspect or insert a rule. The enclosing BPMN strip highlights the current activity and displays branches. Breadcrumbs identify workflow / subprocess / activity / field. Clicking a rail node moves context; Back returns without duplicating state. Advanced whole-workflow lineage opens on demand; it is another projection of the same mappings, not another application.

Use blue for available data, violet for AMIE/transformation, teal for target input; amber for conditional/review and red for blockers. Labels/icons accompany color. Light/dark switches are preferences and do not bump workflow revision. A small-screen layout preserves keyboard access and avoids inaccessible offscreen dialogs; full graph authoring may require a larger viewport but must say so honestly.

## Basic editing must not regress

Every step has a real three-dot menu, right-click equivalent and keyboard path. Menus contain only actions applicable to the current object: configure, change binding, insert before/after, duplicate, move, remove, unbind, inspect inputs/outputs/lineage, and context-specific rule/mapping actions. Disabled actions explain why. Escape closes the topmost menu/dialog and returns focus; opening a rule chooser retains selected target and pending source.

Remove step removes its occurrence and revalidates dependents, never the catalog operation. Remove + reconnect is offered only for a safe topology (simple one-in/one-out without hidden boundaries, branches or loops). Unbind preserves the BPMN task and ID. Duplicate rewrites internal occurrence IDs and internal references while retaining allowed external sources; it does not accidentally point to the original rule's local draft. Move revalidates availability. One-click insertion and rule insertion are atomic Undo/Redo units.

Inline + at a connector offers intent categories: Capability action, Rule/Mapping, Route/Loop/Wait, and supported recovery patterns. The small intent menu can open a larger contextual resource picker when detail is necessary. This reconciles the v4 desire for inline insertion with the user's explicit need for larger rule popovers; the design does not ban all dialogs.

## Capability and rule discovery

Capability picker groups Service -> API group/controller -> Operation, with search across name/description and a detail preview. It shows inputs/outputs, effect, version, maturity and availability. A long undifferentiated list is not acceptable. An L2 context defaults to local compatible operations and exposes cross-service boundaries explicitly.

Rule picker is a larger popover/slide-over with category filters, description, facts, outcomes, native format status, version and In Use/consumer references. No hidden capability invocation inside a gateway. An authoring shortcut may add an AMIE task plus gateway together, but both appear in the BPMN model and are explained as two nodes.

Patterns contain a small business example, what it creates, required data and limitations. Use Pattern expands into reviewable activities/mappings under the workflow revision; it does not create a mutable hidden reference. Full advanced BPMN palette groups events, tasks, gateways, subprocesses, data and collaboration with recognizable symbols, explanations and independent modeling/execution status.

## Shared components, not a framework explosion

Reuse existing Blazor controls first. Logical shared components are EntryInspector, UniversalSchemaGrid, SampleImporter, FieldDetail, SourceBindingPicker, OperationPicker, RulePicker, ContextMenu, BPMNContextRail, ObjectCard, MappingConnection, ReadinessPanel, DurationPicker, TracePanel and ArtifactImportReview. A logical component does not mandate a new assembly or standalone route. Page-specific orchestration remains in a cohesive editor state/service.

## Command model

Every command supplies draft identity/revision, actor, selected object IDs, intent and proposed patch. Validate preconditions; snapshot/commit graph+bindings+presentation together; invalidate stale test/release evidence; emit audit; update all views. On server conflict, retain the user's unsaved intent and display reload/compare options; do not overwrite someone else's work.

Examples: AddEntryBinding, ChangeTransport, AcceptInferredFields, EditContractField, RemoveFieldWithImpact, ConnectMapping, UseInheritedMapping, InsertProducerAndConnect, InsertRuleBetweenFields, ReplaceOperation, ConfigureBoundary, RemoveStep, ImportSupportedModel, PreserveUnsupportedImport and CreateReleaseCandidate. An action that only changes view, theme, filters or zoom does not mutate the workflow.

## Feature-to-serialization matrix

| UI feature | Authoritative model effect | Validation / runtime owner |
|---|---|---|
| Category multiselect | Workflow category references | Catalog; no permission inference |
| Add adapter | TriggerBinding + shared contract reference | Intake owner; no live subscription until authorized |
| Change Kafka gate | Adapter gate expression | Decoder/gate admission before start |
| Paste CSV | Proposed source schema + merge plan | Parser; no mutation before Apply |
| Add/edit field | Shared field identity/type/constraints | Resolver + runtime schema validation |
| Map source column | Per-adapter binding to field ID | Intake normalizer |
| Add Get Account | ServiceTask + sequence rewiring + typed associations | BOB compiler and operation adapter |
| Connect object | Whole-object association/projection | Typed mapping layer |
| Override field | Explicit child binding over parent projection | Mapping semantics, no source mutation |
| Insert AMIE data rule | BusinessRuleTask + fact/result associations | Existing AMIE adapter |
| Change rule | Native artifact/version reference | Existing AMIE draft/serializer |
| Timeout | Supported duration/boundary configuration | BOB timer/attempt policy |
| Retry | Operation-specific permitted retry policy | Capability/BOB reconciliation |
| View lineage | No new data definition | Resolver projection |
| Save recipe | Approved authoring template | Enrichment/catalog governance |
| Native import | Preserved XML/artifacts + known parsed model | Importer, XSD, compiler |
| Export | BPMN XML + native dependencies | Serializer, not approval |
| Restart job | New authorized linked execution request | BOB and policy, not UI flag alone |

## User-understandable diagnostics

Say `Current account is missing. Get Account can supply it using Request.Account ID` rather than `unsatisfied model edge`. Say `This value is only available on the Yes branch` rather than `dominance failure`. Advanced details may include stable codes, schema versions and compiler traces. The simple message and technical diagnosis must refer to the same issue.

<!-- END SOURCE: docs/08-STUDIO-UX-CONTROLS-AND-COMMANDS.md -->



---

<!-- BEGIN SOURCE: docs/09-GROUPS-MATURITY-AND-SECURITY.md -->

# 09. Groups, entitlements, maturity and security

## Reuse current identity and group implementation

Matthew already has authentication/group behavior. Inspect and reuse it. Standalone development continues through that setup while Channel Secure SAML/entitlement integration is completed before go-live. No requirement to connect directly to AD now or build another identity store. Later enterprise group mapping must preserve current resource grants and stable identity references.

Production allows only approved production entitlement mappings. Existing naming patterns help recognize Prod versus Non-Prod; persist/validate an explicit environment classification as well. Workflow configuration stores references, not proof that a group exists or that the current user belongs to it. Registration of a directory name alone grants no access.

## Resource-specific roles

| Role | Intended rights | Limit |
|---|---|---|
| Read | View authorized workflow information/results/reports | Scope must be explicit; never assume enterprise-wide visibility |
| Execute | Launch permitted workflow and view own/authorized results | No capability registration or production activation implied |
| Execute-Lead | Execute plus authorized group-run/report view | Filter by configured group scope, not every departmental run |
| Create | Create/edit permitted drafts, Execute and Read | No implicit approval, grants administration or production activation |
| Approver | Decide eligible human/release tasks | Existing AMIE and separation policy still applies |
| Capability Register/Configure | Onboard/configure approved service operations | Separate from consumer workflow rights |
| Release Operator | Import/activate authorized artifact | Requires all release gates; not merely a job title |
| Administrator | Scoped catalog/grant/environment maintenance | Cannot bypass approval/audit policy |

AMIE configures applicable group/rule restrictions; the backend enforces them. The website may hide controls for clarity, but BE APIs, BOB admission and privileged capability dispatch independently enforce their own boundaries. The external department sees the approved service identity. Do not force it to provision per-human Unity groups for every API call.

## Maturity, stage and activation

Store classification separately from stage: Experimental, NonProd, Approved; InDev, Testing, Verified, ReleaseReady. Display combined values. The confirmed normal progression is Experimental-InDev -> Experimental-Testing -> Experimental-Verified -> NonProd-Testing -> NonProd-Verified -> NonProd-ReleaseReady -> Approved-Verified -> Approved-ReleaseReady. Evidence and authority govern transitions; never infer deployment from the label.

These attach to a specific version. Capability v1 may be active Approved-ReleaseReady while v2 is NonProd-InDev. Operations can have different status from their parent service. A stable service does not make its new destructive operation stable. Experimental-ReleaseReady means ready for an explicitly permitted experimental environment, not production.

Separate visible modeling, implemented handler support, authorized execution, and environment activation. Unsupported experimental constructs can be saved/preserved, but no flag creates a missing runtime handler. Production rejects unapproved experimental dependencies. Catalog UI includes approval/status, experimental controls, per-environment activation, versions and audit, kept within the service context.

## Sensitive data boundaries

Use approved connection and credential references. Never place rotating passwords, SMTP credentials, API tokens, cookies or private signing keys in manifests, BPMN, samples, trace output or downloadable reports. Data classification follows mappings and transformations. A rule cannot downgrade sensitivity just by renaming a field. Redaction is enforced centrally; optional developer logging cannot disable mandatory security audit.

Use constrained paths/selectors, strict decoder limits, no arbitrary SQL/URL/class name execution from configuration. Native artifacts and imported XML are untrusted until validated. A schema declaring authMode=bearer is a design setting, not authentication evidence. For test modes, show Mock clearly and disallow a one-click switch to production connections.

## Governance without overcomplicating Jira

Jira/story references are planning traceability, not runtime authorization. Keep owner, milestone, remaining work and evidence understandable. Every story has one milestone; do not require a new tracking subsystem for every small mapping. Group/import configuration changes use the same governed artifact process as workflow/rule changes, with environment diff and reviewed privilege impact.

<!-- END SOURCE: docs/09-GROUPS-MATURITY-AND-SECURITY.md -->



---

<!-- BEGIN SOURCE: docs/10-RELEASE-PROMOTION-AND-CONFIGURATION-IMPORT.md -->

# 10. Release, promotion and configuration import

## Three environments, one tested content set

DEV authors and tests. UAT imports and validates pre-production behavior. PROD imports and activates through authorized groups. There is no separate TEST environment in the current plan. Environment connection references may resolve differently, but approved workflow/rule/mapping content remains immutable. Avoid editing the production BPMN to change a host URL; use reviewed environment bindings outside business logic.

A release package contains BPMN XML + DI + workflow-owned Unity mappings/entry declarations; native AMIE artifacts or immutable verified references; operation/contract dependency lock; test evidence references; approved environment-binding/configuration references; manifest and integrity/trust material. Actual package extension/naming follows enterprise tooling. The offline demo export is unsigned and marked non-executable; it is not that release.

## Promotion sequence

Save draft -> validate full compiler profile -> run fixture and authorized integration tests -> submit review -> produce immutable candidate with content digest -> import into UAT -> record acceptance evidence -> authorize production change -> PROD import/preflight -> separately activate -> monitor. Do not make Import itself execute a workflow or change active definitions.

Production requires trusted artifact origin/integrity, compatible deployed handlers/rules, validated BPMN and Unity semantics, no unauthorized experimental features, approved environment/group bindings, required review policy, and a nonempty ServiceNow ID. Initial implementation stores the ID and optionally a safe ticket link; it does not call ServiceNow or imply status is approved. The production authorization is from platform controls and AMIE policy, not the presence of the ticket string alone.

## Cryptographic trust and the requested key

The user asked for an approved key/protection mechanism so arbitrary XML cannot go live accidentally. Implement trusted signing/verification or an already-approved enterprise equivalent. A reusable secret inside the uploaded file is not that protection: it can be copied with the artifact. Keep signing private keys in approved infrastructure. Production trust is configured independently; an attacker-supplied public key in the archive cannot authorize itself.

If the required production trust mechanism is unavailable on day one, keep production activation blocked or use the explicitly approved existing release path. This must not block building/import-testing in DEV/UAT. Record the missing mechanism as a pre-go-live story, not a hidden future enhancement.

## Group and environment configuration imports

Use the same preflight/approval/activation pattern for group references, resource entitlements, rules and connection bindings. Preview additions/removals/privilege increases; reject incompatible environment roles; preserve stable IDs and descriptions. EF migrations create owned schema structure; environment configuration imports populate real approved references. Do not seed fake AD memberships or execute privilege changes from a sample file. Names containing Prod/Non-Prod help human review but do not replace verified scope.

## Rollback and in-flight instances

Reactivation of an older approved release controls new starts. Existing runs retain pinned definitions and rule/operation versions unless a separately reviewed migration explicitly moves them. Availability of old handler versions must be checked before rollback. Rollback of configuration does not undo a CyberArk write or delivered email. Such external effects require reconciliation or an explicitly supported authorized reverse operation; generic compensation remains deferred.

## Release UX

Display package identity/digest, native rule format status, required dependencies, environment diff, experimental flags, evidence and required change reference. Distinguish Parse OK, Schema OK, Executable OK, Approved and Active. Each failed gate links to a specific node/configuration or owner. The operator can import a quarantined/review-only package without activation where policy permits. Unsafe/unknown content is not silently normalized into an executable approximation.

## Negative tests

Changed byte after approval; wrong signing identity; missing trust chain; missing ServiceNow ID; unauthorized actor; non-production group mapping in PROD; missing operation version; unknown required extension; unresolved rule format; unsigned fixture; environment URL substitution outside approved binding; zip-slip/path traversal; duplicate manifest members; missing artifact hash; package exceeding limits; rollback missing old handler; in-flight version changes. Record exactly which gates were exercised in DEV/UAT and which depend on enterprise integration.

<!-- END SOURCE: docs/10-RELEASE-PROMOTION-AND-CONFIGURATION-IMPORT.md -->



---

<!-- BEGIN SOURCE: docs/11-OBSERVABILITY-AUDIT-AND-OPERATIONAL-VIEWS.md -->

# 11. Observability, audit and operational views

## Three different consumers

The BE business portal answers: What did I request? What is running? What succeeded, failed or needs attention? Can I see my group's results? Modeling Studio answers: What is the program? What data/rules does it use? Can I test and publish a changed definition? Ops Diagnostics answers: Which attempt failed? What is its technical cause? What can safely be retried, reconciled, paused or cancelled? Do not put BPMN/UML editing controls in every business user's job list.

These are entitlement-filtered views over common identities and projections, not new independent workflow databases. The offline persona switch only demonstrates navigation; it is never evidence of RBAC enforcement. Server APIs must recheck identity, environment, resource and effective policy for every operation, query and streamed event.

## Business portal

Show friendly process name, execution reference, submitted time, requester, approved group scope, state, progress/counts with definitions, recent activity, outcome and report links. Distinguish Queued, Running, Waiting for approval, Waiting for outcome, Paused, Completed, Failed, Cancelled and Needs reconciliation. A batch's total, processed, skipped, rejected and failed counts must reconcile under a declared counting policy. A workflow waiting normally on a timer is not necessarily stuck.

Execute-Lead can see only the configured group's runs/results. Department is a label, not a blanket access rule. Read scope must be explicit for reports; exports and attachments receive the same server filtering as the grid. On reconnect, fetch an authoritative projection snapshot and resume event updates by sequence; do not trust only a browser's missed stream history.

## Ops diagnostics

Provide the execution, scope, task occurrence, attempt, correlation, operation/rule versions, message/command identity, last checkpoint, timer, retry schedule, typed error/outcome and redacted input/output evidence. Clicking a failed step navigates to the same BPMN activity; it does not mutate the definition used by that run.

Safe controls include requested pause/resume/cancel and reviewed restart/reconciliation. Replay-from-step is not enabled solely because the UI has a button. The backend must verify previous data availability, external side-effect status, environment grants and idempotency/reconciliation policy. A new run links to the old one; the old audit is retained. DLQ management requires authority and a specific replay reason, not a generic resend-all command.

## Durable audit design

Write audit/evidence from admission onward, independently of Kafka retention. The submitted draft's four-day broker retention is an unverified environment value; never wait until four days expire before persisting evidence. Broker retention/compaction/configuration and data arrival times do not guarantee an exact per-record countdown. UI may show configured policy and uncertainty, not fabricated expiry precision.

Minimum event attributes: immutable event ID; UTC observed time; environment; workflow/version/digest; execution and parent execution; scope/activity/attempt; initiator identity reference; service execution identity reference; event kind; business outcome/reason; correlation/message/command/idempotency references; artifact/approval/change references; redaction/classification; integrity metadata where required. Store searchable indexed envelope columns plus governed JSON details through the audit owner. Actual table names and EF mappings must be reconciled with existing `uty_audit` objects.

Diagnostic logging is configurable within policy; mandatory security/release events cannot be disabled by a workflow flag. Authors select an approved audit profile/sink, never arbitrary database/table/SQL. Do not retain raw passwords or secret-bearing API responses. Sensitive sample data has its own access/retention policy. Redaction must apply in traces, exports, exceptions, logs and support tools.

Define retention, purge/legal-hold requirements, volume, backpressure and failure mode with the bank's owners. Durable audit failure may block sensitive actions under policy; never silently drop mandatory evidence. Projection rebuilding and long-term report generation must not rely on messages that may already have left Kafka.

## Test-stage audit preview

The local fixture runner shows events at the same activity IDs as the designer. It can preview a redacted audit record and feed the demo business/Ops views. That record is explicitly local browser evidence, not a write to the enterprise audit database or Splunk. Acceptance of real telemetry requires an integrated run and persistence/query verification.

<!-- END SOURCE: docs/11-OBSERVABILITY-AUDIT-AND-OPERATIONAL-VIEWS.md -->



---

<!-- BEGIN SOURCE: docs/12-ENTERPRISE-INTEGRATIONS-AND-WORKBENCH.md -->

# 12. Enterprise integration readiness and API workbench

## Required work is tracked now, not invented or postponed indefinitely

The user clarified that enterprise integration is needed before go-live, even while developers use existing local mechanisms. Some integration work may already be complete. Every entry starts Existing - Verify, Partially Implemented, Awaiting Requirements, Ready for Integration or Verified only when evidence supports it. Do not create duplicate stories or replace existing components merely because their details are absent from this conversation.

| Integration | Facts/decisions retained | Required evidence before production |
|---|---|---|
| Channel Secure | Handles SAML SSO and entitlements; requested in parallel; reuse Matthew's current setup during development | Claims/group mapping, session lifecycle, environment grants, unauthorized tests and regression evidence |
| Apigee | Department APIs may require service onboarding and declared service-account access | Approved route/policy, request limits, credential integration and correlation/error behavior |
| Splunk | Structured logging/trace/audit visibility is required | Forwarding path, indexes, redaction, search by run/step and operational alerts |
| AutoSys | External scheduler can launch through an approved adapter | Job/box ownership, execution-context payload, overlap/misfire handling and status feedback |
| Cron | Supported scheduling source, not a second implicit workflow runtime | Scheduler owner, timezone/DST/misfire/overlap policy, durable trigger admission |
| NAS / owned Data capability | User describes CSV landing/staging and data access | Exact meaning and existing owner/API, permissions, completeness, row identity, paging and read results |
| Other enterprise dependencies | Keep explicit placeholder, owner and decision date | Go-live relevance, contracts/access and acceptance test |

NAS has been used ambiguously in earlier drafts as both file storage and a named data capability. Preserve the user's file/staging scenario without assuming a new external API. Confirm what the actual system provides and keep file access behind its owning adapter.

## Dependency tracking fields

Integration ID; milestone/story; business outcome; existing ticket reference if supplied; technical/business owner (unconfirmed when unknown); existing implementation path; missing requirements/access; target environment; test fixtures; go-live blocking status; evidence and last verified time. No invented Jira keys or completion percentage. A requirements gap remains visible even if a demo uses mocks successfully.

## API capability workbench

The original requirement remains: deploy the service once, then test different approved API payloads, expressions and call chains without repeatedly redeploying for each request edit. Reuse the existing rotating credential/session sequence securely. The author can choose an approved operation, supply a typed sample/model/CSV mapping, run an authorized DEV test, inspect redacted output, bind that output to another call, and compare assertions/results. An arbitrary Internet HTTP proxy is not the workbench.

Use the same registry descriptors, schema controls, AMIE adapter, BOB local composition and trace vocabulary as production workflows. The workbench is a sandboxed authoring/test surface. When a useful chain is saved for reuse, expand it into a supported L2 workflow with typed contract, dependencies and tests; do not introduce another proprietary recipe execution language.

Examples: Get Account -> compare four fields -> patch approved differences -> verify; authenticate internally -> get accounts -> inspect typed response; CSV row -> account lookup -> rule -> report notification. Report/CSV export must mask sensitive fields. A fake success result or sampled response is labeled Mock. Running a real operation requires explicit environment and scope; potentially destructive requests need the relevant approval/safe test target.

## Workbench acceptance

Change a sample request without redeploying code; reuse approved authentication without copying credentials into the UI; chain output into the next operation; show type mismatch before run; distinguish mock and real DEV call; persist a reusable test definition without secrets; correlate failures; prevent arbitrary URLs/SQL/class names; prevent inadvertent PROD usage; reuse the successful flow in BOB with equivalent outcomes. Existing services and external permissions still need their ordinary onboarding/deployment processes.

<!-- END SOURCE: docs/12-ENTERPRISE-INTEGRATIONS-AND-WORKBENCH.md -->



---

<!-- BEGIN SOURCE: docs/13-LEGACY-EXTRACTION-AND-AI-READINESS.md -->

# 13. Legacy-to-Unity extraction and later AI assistance

## Existing legacy analysis is an input, not work to redo

The user has already used Devin to inspect legacy applications, extract business rules and generate BPMN XML. Treat those artifacts as valuable evidence. Inspect them first; do not re-discover every process just because this handoff is newer. They may represent much of the modeling work. Their existence does not quantify runtime migration completion without checking bindings, native rules, error paths, data semantics and parity tests.

## Repeatable extraction package

For each application produce: source location and revision; operation inventory linked to existing registered primitives; rule inventory with source conditions/precedence/defaults; process/control-flow model including loops/errors/waits; typed data and source/consumer bindings; native AMIE artifacts using the verified serializer; mapping from source behavior to BPMN node/rule ID; regression fixtures; known ambiguity and intentional deviations. Keep security/technical invariants in the execution boundary even if a legacy conditional contains them.

Classify a code block as technical operation, business decision or business sequence. Reuse the technical API client; express decisions in AMIE; express sequence/control in supported BOB BPMN. Avoid wrapping an entire legacy hardcoded program in a handler and calling it configurable. Conversely, do not split every simple function into a workflow for appearances.

## Preserve behavior before refactoring it

Use characterization fixtures for normal, edge, missing/null, error, timeout and duplicate cases. Compare observable outputs and intended external effects, not just similar diagrams. Match original precedence, data normalization, locale/time assumptions, implicit defaults, transaction boundaries, exception handling and authorization. Record surprising legacy behavior for review rather than silently fixing it in the migration. Safe mock/dry-run comparison precedes real writes.

Pilot order: CyberArk custom-field update; Email extraction; central orchestration across the two; account onboarding with conditional Safe/Platform requirements. Retain separate playbooks for DCMS/CMDB, Policy Drift ZIP/INI comparison, guarded deletion and Hygiene/Safe-move. Do not conflate Policy Drift with account hygiene or invent vendor operations from examples.

## Partial-readiness import

An unbound service task, unresolved native rule, incomplete BE form binding or missing source mapping should be a visible readiness item. Supported structure loads editably; unsupported content is retained with clear limitations. Each item links to the task/schema/adapter and a specific remedy. Draft review/export is allowed; unvalidated execution is not. The handoff requires a robust preservation-capable production importer even where the demo provides only a supported subset plus preserved-original fallback.

## Future MCP and AI co-design

AI should use the same schemas, catalogs, validation and commands as a person. Potential tools: list authorized operations/rules; inspect contract; propose a bounded edit; validate draft; apply a reviewed command with revision; export a draft; inspect redacted trace. No AI tool receives raw service credentials or bypasses approval. Production activation remains a separately authorized action. MCP is an interface to existing platform services, not a new orchestrator.

The specifically named future AI product remains unverified; do not create an integration dependency around guessed branding. The extension schema, semantics and examples make the design AI-ready without making routine authoring AI-dependent.

## Rationale to give the next developer

BPMN is the common executable/process language. The UML-inspired view helps humans understand objects and mappings; it is not a second model to reconcile. AMIE is retained because its rules already exist. SDK descriptors connect reusable code to both the compiler and UI. The value is changing business behavior through governed configuration after release, not merely generating diagrams from source code.

<!-- END SOURCE: docs/13-LEGACY-EXTRACTION-AND-AI-READINESS.md -->



---

<!-- BEGIN SOURCE: docs/14-ACCEPTANCE-EVIDENCE-AND-IMPLEMENTATION-BOUNDARIES.md -->

# 14. Acceptance evidence and implementation boundaries

## Four evidence layers

1. Browser interaction: controls change a local draft and show the expected state.
2. Structural artifact validation: XML parses, Unity XSD validates, IDs and references are coherent; official BPMN XSD is a distinct gate.
3. Production compiler semantics: graph execution, types/availability, policies, host boundaries and dependency locks are implemented in actual BOB/SDK/AMIE adapters.
4. Enterprise observation: deployed services and infrastructure execute the expected operation with security, durability and operational evidence.

The included prototype proves selected cases in layers 1 and 2. It does not prove layers 3 or 4. The QA report records exact test results and omissions; previous run results are not blindly copied as current evidence.

## Feature matrix for the delivered demo

| Feature | Demonstrated here | Still required for enterprise implementation |
|---|---|---|
| Existing contextual BPMN/Data/Rule editing | Preserved local model, menus, nested fields, rule insertion, Undo/Redo | Bind to repository components and native contracts |
| Multiple launch bindings | Editable source-specific settings and shared field definition | Real subscription/route/scheduler registration and server validation |
| CSV/JSON/Avro sample import | Local candidates, target mapping, locked merge, normalized first-row preview | Full schema variants, production-scale limits, approved parsers, schema registry and charset handling |
| Custom field editing | Types/required/null/lock/pattern/default/source bindings | Full model registry, enum/range/array item UI and compatibility migrations |
| Scheduler example | Execution context -> explicit one-row ingestion fixture -> account lookup | AutoSys/Cron/NAS scheduling, file completion, batch paging and retry policies |
| Data resolver | Existing fixture types/path checks, one-click account producer | Full arbitrary BPMN parallel/loop/error/freshness/security analysis |
| Native AMIE | Opaque XML/JSON preservation path; local fixture rules | Matthew's real format, editor, evaluator and serializer integration |
| XML export/import | Documented structured profile with entry extensions and DI | General preservation-capable editing, official XSD, migration contracts |
| Partial/unrecognized import | Original preserved with unsupported-profile explanation | Editable unknown-content retention and complete actionable analyzer |
| Business portal/Ops | Local traces feed separate example views; audit JSON preview | Authenticated server filtering, durable projections, real broker state, safe intervention |
| Capability Studio | Prior provider onboarding prototype connected to current builder | Trusted SDK registration, contracts, deployed endpoints, activation enforcement |
| Production release | Explicitly blocked and documented | Full trust, approvals, dependencies, changes, UAT and activation |

No simulated catalog record proves that an approved operation, schema, service account or permission exists in the actual enterprise. The sample API properties and namespace names are illustrative. The current UI makes that boundary visible.

## Production regression suite

**REG-01 Preserve existing contracts:** run old API/rule/workflow fixtures unchanged through the adapted path; demonstrate no duplicate evaluators/consumers/stores. **REG-02 Same operation reused:** two independent workflows and an L2 process use one registered handler. **REG-03 No-recompile change:** approved AMIE/BPMN definition changes affect new runs without changing the capability binary, while old runs remain pinned.

**DATA-01 Source mapping:** CSV/form/API/Kafka variants normalize to equivalent typed requests. **DATA-02 Locks:** updated sample never overwrites locked field definition/binding without explicit action. **DATA-03 Availability:** missing producer, later producer, sibling branch, zero-loop and failed lookup are diagnosed. **DATA-04 Identity:** account/target/iteration mismatch is blocked. **DATA-05 Freshness:** pre-write object cannot verify post-write state. **DATA-06 Shapes:** nested object, array, required/null/default conflicts and semantic conversion are tested.

**BOB-01 Concurrency:** parallel activations/joins race without double advancement. **BOB-02 Timers:** durable restart and boundary race. **BOB-03 Errors:** scoped error propagation and not-found/business-reject/unknown-write distinction. **BOB-04 Messaging:** outbox/inbox crash tests, duplicate/out-of-order outcomes and idempotency scope. **BOB-05 Human tasks:** stages, backups, concurrent decisions and authorization changes.

**SEC-01 Access:** Read/Execute/Create/Execute-Lead scope, including exports and push updates. **SEC-02 Service boundary:** no per-human vendor group requirement; trusted command and approved operation still enforced. **SEC-03 Data protection:** secrets redacted everywhere, sample retention and arbitrary input destinations blocked. **SEC-04 Production:** wrong groups, unsigned/tampered package, missing ticket/native artifact/handler and experimental execution fail closed.

**UX-01 A-to-Z:** non-programmer configures source, binds operations/rule, resolves missing data, tests both branches and prepares release without unrelated admin detours. **UX-02 Context:** UML/Data view retains BPMN orientation and shared history. **UX-03 Basic edits:** insert/delete/replace/unbind/move/duplicate/connect/undo/redo work, including impact messages. **UX-04 Accessibility:** keyboard alternatives, labels, focus, contrasts, light/dark, screen widths and error explanation. These require actual usability/accessibility validation, not only absence of JS errors.

**IMPORT-01 Round-trip:** known semantics, native rule bytes, IDs, DI and extensions preserved. **IMPORT-02 Partial model:** unbound artifacts remain visible and non-executable. **IMPORT-03 Unknown extension:** preserve/restrict or explicitly reject without data loss. **IMPORT-04 XML trust:** DTD/entities, archive traversal and oversized inputs blocked.

## Completion record per story

Record source commit/build, test command/output, fixture identity, environment, expected versus actual behavior, reviewer, defects and remaining limitations. A closed Jira item is not sufficient if its milestone gate is still failing. Do not label a production story Done merely because its browser prototype is demonstrated.

<!-- END SOURCE: docs/14-ACCEPTANCE-EVIDENCE-AND-IMPLEMENTATION-BOUNDARIES.md -->



---

<!-- BEGIN SOURCE: docs/15-CONFIGURATION-AND-USER-GUIDES.md -->

# 15. Configuration and user guides

## G01 - Capability owner: expose and review an operation

Open Capability Studio for the service, not a generic global workflow list. Reuse the approved connection/code registration. Review discovered service/group/operation descriptors. Choose one operation, inspect its typed input/output/effect/host, and identify any missing business semantics. Run an authorized fixture/DEV test. Submit for review. An authorized reviewer approves the specific version and permitted environment; activation remains separate. Confirm the same descriptor now appears in the workflow picker. A missing handler/version is an integration blocker, not a UI permission fix.

## G02 - Author: create an entry contract from a CSV

Create/select workflow -> Define -> add CSV launch binding -> select approved landing/staging source and parser settings -> Data Contract -> Paste / Upload Sample -> inspect columns/types -> choose normalized field targets or add business inputs -> protect deliberate edits with locks -> Apply -> preview normalized records and fix errors. Confirm that mapped source columns satisfy required fields. Save the source configuration with the workflow revision. Missing data produced later by an activity is not added to the incoming CSV contract just to make a warning disappear.

## G03 - Add Kafka or API as another launch method

Keep the shared normalized contract. Add another binding, configure approved transport and authentication, and map body/key/header/path/query fields to the existing stable field IDs. Configure dedupe and business correlation independently. Test a representative message/request. An incompatible source mapping is flagged; changing source type does not erase the schema. Confirm that the same business process receives equivalent normalized data.

## G04 - Scheduler-driven ingestion

Choose existing AutoSys/Cron binding and timezone. Inspect run context. Add an ingestion activity using an approved file/data/API source. Bind the intended scheduled date or other context value through a constrained parameter. Configure no-source and failure behavior. Use the same Sample Importer on the ingestion output contract. If results are a collection, configure supported iteration and item scope before consuming a single record. Verify lineage shows business data beginning at ingestion, not at the schedule start.

## G05 - Build the CyberArk custom-field update

Use an account-row request. Add/choose Get current account. Bind its Account ID from the normalized request. Select the existing AMIE compare rule and bind current account plus desired fields. On a changed outcome, invoke the approved patch operation with the allowed change set. Add a fresh Get Account and verification rule. NoChange ends without write; mismatch/not-found/unknown outcomes are explicit. Add Email at the appropriate enterprise process boundary using sanitized result/report data. Reuse the same primitive in another workflow to prove the abstraction.

## G06 - Repair a missing model in one click

Select Compare and inspect Missing current account. Review the proposed Get Account and incoming ID. If the action is unambiguous, click Add Get Account and Connect. Observe the inserted BPMN task and resolved object mapping without leaving the activity. Undo/Redo restores all graph and mapping changes together. Multiple identities, wrong host or an existing eligible producer change the offered action; the UI never guesses a privileged target.

## G07 - Insert a rule into a mapping

Expand target desired.Owner, open its three-dot/right-click menu and choose Insert rule. Inspect its facts/results. Choose a compatible pure rule and insert. Observe the rule card and matching BPMN Business Rule Task. Edit its draft parameters through the verified AMIE editor in production (fixture editor in the demo), preview, then test. Retain other inherited object fields. Removing the rule and reconnecting must revalidate the original source.

## G08 - Configure onboarding

Select Add Account from CyberArk/Accounts. Supply request fields and inspect unmet requirements. Resolve Safe and Platform through authorized request/configuration/lookup sources. Apply selected-platform requirements; if selected at runtime, constrain possible platforms or validate dynamically before creation. Configure business rules, approval need and error behavior. Do not pretend an account's full current object exists before it has been created.

## G09 - Approval user

Open My approvals in the authorized BE view. Inspect business request, relevant redacted data, current stage and requested decision. Approve/reject with required reason; the backend rechecks eligibility and stage revision. A backup acts only under configured policy. A stale or already-decided task is explained rather than silently accepted. View resulting status/history without acquiring designer or capability-admin rights.

## G10 - Operator and release user

For a failed run, inspect the technical outcome and uncertainty before replaying anything. Pause/cancel/restart only through approved commands. For release, import the reviewed package, inspect digest/dependencies/environment diff, provide the required change reference and complete approvals. Activate separately. Verify new starts use the activated version and existing runs remain pinned. Retain rollback evidence and never mistake a configuration rollback for reversal of vendor effects.

## G11 - Administrator

Maintain real group references/descriptions and scoped resource-role mappings through existing mechanisms. Review effective access, production/non-production scope and AMIE restrictions. Manage approved connection references and capability statuses. Import environment configuration through the same controlled mechanism; avoid fictional seed memberships. Categories are searchable classification, not security. Record every privilege-changing action with its authority and before/after evidence.

<!-- END SOURCE: docs/15-CONFIGURATION-AND-USER-GUIDES.md -->



---

<!-- BEGIN SOURCE: docs/16-SOURCES-GLOSSARY-AND-CHANGE-DISCIPLINE.md -->

# 16. Sources, glossary and change discipline

## Source basis and precedence

The current user conversation is the approval record for product decisions. The exact supplied v4 draft is retained verbatim as `source-reference/USER-V4-PROPOSAL.txt`. The earlier canonical v2.2 archive contains the prior platform handoff and historical assets; the v3 archive contains the actual editable modeling prototype. The new current specification integrates the decisions rather than asking Devin to read conflicting historical jobs. Source hashes are recorded in `source-reference/source-checkpoint.json`.

Earlier generated specifications are not evidence that code exists. The user-described existing AMIE, auth/groups and services must be verified in the repository. Readiness and implementation status remain explicit. The complete original archives are retained for traceability, not as a second implementation instruction set. Matthew's separate questions are deliberately excluded from consolidated Ask content; the relevant integration constraints are fully stated in the current normative sections.

## Public references used only to verify narrow technical distinctions

- **EXT-BPMN:** OMG, BPMN 2.0.2 machine-readable file index: https://www.omg.org/spec/BPMN/machine-readable and https://www.omg.org/spec/BPMN/2.0.2 . This establishes the official schema bundle location; it does not prove Unity's conformance. Access checked November 20, 2026.
- **EXT-KAFKA:** Apache Kafka consumer configuration, `auto.offset.reset`: https://kafka.apache.org/40/configuration/consumer-configs/ . Used to distinguish initial/out-of-range offset behavior from an explicit replay command. The deployed broker/client version remains unverified.
- **EXT-CYBERARK:** CyberArk-maintained account adapter source: https://github.com/cyberark/ansible-security-automation-collection/blob/master/plugins/modules/cyberark_account.py . Used as a primary implementation example of account PATCH construction, not as a substitute for the deployed CyberArk API contract. The prior supplied research inventory remains a reference only.

No outside source changes user-approved architecture automatically. Public technical facts and proposed safety clarifications are separated from source-derived requirements in the reconciliation table. Official XSD download was not available to the local validator in this environment; that gate is explicitly not run.

## Glossary

Capability service: registered provider/ownership boundary. Operation: typed reusable callable primitive. L1: enterprise process. L2: capability-owned local process on the same BOB core. L3: compiled/adapted operation. Trigger: how a start signal is admitted. Source schema: raw input shape. Shared contract: normalized field model consumed by the process. Binding: source-to-target data relationship. Hydration: acquisition of required context during execution. Lineage: identity/provenance/transform/consumer path. Recipe: reusable authoring template, not a new runtime language. Business Rule Task: explicit BPMN activity invoking AMIE. Contextual zoom: deeper editing while the BPMN selection/scope stays visible. Readiness: scoped validation status, not production approval. ReleaseReady: development stage, not activation. Unknown effect: an external write may have happened and must be reconciled.

## Change discipline

A change to a material decision updates rationale, model contract, screen command, serializer/XSD mapping, runtime owner, test and milestone story together. Do not hide the change in a new ZIP or a precedence sentence. Use an explicit supersession record stating what changed, why, user authorization, compatibility, migration and evidence. Actual source incompatibilities are proposals until reviewed. Maintain a small field/schema migration registry rather than rewriting every previous artifact.

The master and Ask aliases are generated from the same ordered current Markdown sources. Never hand-edit one alias. The manifest records included/excluded files and SHA-256 digests. Content changes invalidate the old manifest and QA report. A package is complete as a handoff when its current requirements, source assumptions, demo scope, unresolved work and acceptance evidence are all present; that is not a claim of completed production implementation.

<!-- END SOURCE: docs/16-SOURCES-GLOSSARY-AND-CHANGE-DISCIPLINE.md -->



---

<!-- BEGIN SOURCE: planning/milestones-stories.md -->

# Milestones and Jira-ready stories

**Package:** WF Unity Complete Handoff v4, 2026-11-20. **Planning identifiers are not Wells Fargo Jira issue keys.** No tickets were created, deleted or queried.

Every story below has one owning milestone. Dependencies may cross milestones, but do not double-count a story. The offline demo is evidence of interface behavior, not completion of enterprise implementation. Existing work must be verified before assigning new build work. All initial repository status values are **Not assessed**; none is labeled Done merely because a prototype test passed.

## Megan reporting view

| Milestone | Story count | Acceptance gate | Current implementation evidence |
|---|---:|---|---|
| M0 - Baseline and contract reconciliation | 5 | A reviewed evidence map identifies existing/extend/adapt/defer for each subsystem; no replacement contracts are assumed. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M1 - Capability foundation: CyberArk and Email | 6 | Both services expose approved typed operations and a second workflow reuses an unchanged implementation. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M2 - BOB, AMIE and execution guarantees | 8 | Shared-host regression, durability, boundary, approval and authorization evidence passes for the pilot scope. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M3 - Studio, source contracts and data intelligence | 8 | An author maps a sample source, inserts a lookup/rule, tests two outcomes and round-trips the same workflow artifact without losing data. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M4 - Business operations, observability and reusable testing | 5 | Business access is scoped server-side; operators can diagnose and safely recover a run using durable evidence beyond broker retention. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M5 - Enterprise integration and controlled promotion | 9 | Each integration is verified or explicitly not required for the selected pilot; no unaccepted production blocker remains. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M6 - Integrated acceptance and production readiness | 5 | Business, technical, security and operations acceptance evidence is attached; production activation is separately authorized. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M7 - Next-phase improvements, not initial-release blockers | 4 | Each improvement is separately scoped and admitted after the initial capability/Studio foundation is verified. | Not assessed against enterprise repository; prototype evidence in QA is separate |

**Initial scope:** 46 stories across M0-M6. **Next phase:** four M7 stories. This is a dependency plan, not a promise that unknown access, approvals or integration work fits a two-week calendar. Scope sequencing should be adjusted against source audit and external availability, not by silently omitting runtime safety.

For each milestone report: accepted stories / total in-scope stories; remaining stories by Ready/Active/Blocked/Verify-existing; blocking dependency and owner; milestone gate evidence. Counts describe completion, not a reliable effort estimate when stories differ in size. Use estimates only after team review. A closed ticket without accepted evidence does not close the milestone.

## Relationship to the supplied Studio v4 milestone proposal

| Supplied draft milestone | Current platform mapping | Reason |
|---|---|---|
| Draft 1: schema, round-trip, partial readiness | M0-02; M3-01; M3-08; M5-07 | Preserve actual native AMIE and separate import/edit readiness from release |
| Draft 2: resolver and sample import | M3-02 through M3-05 | Shared field model, source bindings and execution-aware provenance |
| Draft 3: Studio UX and catalog | M3-06; M3-07 | Extend existing contextual editor; preserve menus and approved minimal UML scope |
| Draft 4: observability, test and RBAC | M2-08; M3-08; M4-01 through M4-05 | Browser views do not implement server authorization or durable audit |
| Draft 5: Phase 2 AI/MCP | M7-03 | Contract-first future enhancement; not a first-release prerequisite |

Older WF-M0..WF-M6 identifiers remain historical references only. Use the current UTY-M* identifiers when drafting the replacement tickets. Preserve any actual Jira keys the user later provides as external references; this file does not instruct deletion of live tickets.

## M0 - Baseline and contract reconciliation

**Objective:** The actual repositories, approved serializers, existing SDK/auth, and environment dependencies are mapped before changes.
**Milestone acceptance:** A reviewed evidence map identifies existing/extend/adapt/defer for each subsystem; no replacement contracts are assumed.

### UTY-M0-01 - Inventory repositories and preservation boundaries

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Give Devin an evidence-based map of what already works.

**Implementation scope:** Read AGENTS.md and actual BOB, AMIE, BE, SDK, broker, EF, auth and release code; record paths/commits and existing tests.

**Dependencies:** None; first audit activity.

**Acceptance criteria:**
1. Each claimed existing contract cites a concrete source location and revision.
2. Every proposed change is classified retain/extend/adapt/defer, including impacted consumers.
3. No branch, schema migration or replacement evaluator is introduced as part of this audit.

**Required evidence:** Read-only inventory, source-to-spec map, baseline build/test output and gap decisions.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M0-02 - Verify AMIE native format and current intake ownership

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Resolve the XML/JSON conflict without rewriting Matthew's rule system.

**Implementation scope:** Inspect real rule artifacts, serializer, editor/evaluator APIs, local caching and intake-to-BOB behavior; preserve original bytes.

**Dependencies:** UTY-M0-01

**Acceptance criteria:**
1. A real rule is read/written/evaluated through the existing adapter with equivalent results.
2. The verified native format and permitted inline/reference packaging are recorded; fixtures are not treated as native evidence.
3. Any overlapping durable AMIE orchestration is recorded for M7 rather than forced into the first release.

**Required evidence:** Native artifact fixture, serializer/evaluator regression and ownership trace.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M0-03 - Verify capability and identity contracts

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use the existing SDK and Matthew's authentication/groups rather than duplicate them.

**Implementation scope:** Inspect registration, operation IDs, schemas, grant resolution, local host calls, transport envelope and service identity boundaries.

**Dependencies:** UTY-M0-01

**Acceptance criteria:**
1. Existing registration and authentication tests run before extension work.
2. Website human grants are distinguished from external service-account rights.
3. Required extensions identify actual APIs/classes rather than invented prototype names.

**Required evidence:** Contract map, local authorization trace and SDK compatibility checklist.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M0-04 - Inventory integration work and go-live dependencies

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep unknown and already-completed enterprise work visible without assuming either.

**Implementation scope:** Inventory Channel Secure, Apigee, Splunk, AutoSys, NAS, cron and other pilot dependencies; collect optional existing Jira links.

**Dependencies:** UTY-M0-01

**Acceptance criteria:**
1. Each dependency has a named owner or Owner TBD and evidence-based state.
2. DEV/UAT/PROD requirements are separate; no fictitious TEST environment appears.
3. Unverified Kafka retention and ambiguous NAS ownership are explicitly flagged.

**Required evidence:** Integration register accepted by responsible owners; existing ticket mapping when supplied.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M0-05 - Characterize legacy behavior and imported model readiness

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use Devin's existing extraction as input while proving what is executable.

**Implementation scope:** Choose one legacy CyberArk process and Policy Drift email path; inventory rules, side effects, defaults, failures and generated BPMN.

**Dependencies:** UTY-M0-01, UTY-M0-02

**Acceptance criteria:**
1. Source behavior and BPMN/AMIE activities are traceable with documented omissions.
2. Expected success, no-change, reject and uncertain-write cases have fixtures.
3. A percentage of migration completion is not reported without an explicit denominator and evidence.

**Required evidence:** Characterization test suite, rule/process crosswalk and partial-readiness report.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M1 - Capability foundation: CyberArk and Email

**Objective:** One generic SDK/registry contract makes existing technical functions reusable in code, embedded BOB and central workflows.
**Milestone acceptance:** Both services expose approved typed operations and a second workflow reuses an unchanged implementation.

### UTY-M1-01 - Extend the generic operation descriptor and SDK

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Expose existing compiled handlers with minimal Unity-specific boilerplate.

**Implementation scope:** Add only missing typed input/output, semantic identity, side effect, host, error and version metadata; retain existing DI registration.

**Dependencies:** UTY-M0-03

**Acceptance criteria:**
1. Duplicate operation/version registrations fail deterministically.
2. The same descriptor drives discovery, forms, bindings and handler lookup.
3. No arbitrary CLR names, scripts, unrestricted HTTP or SQL are accepted from workflow configuration.

**Required evidence:** SDK unit/component tests, example handler and generated descriptor comparison.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-02 - Implement trusted registration, maturity and activation

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Make discovery automatic without making it authorization.

**Implementation scope:** Persist reviewed manifests, operation versions, Experimental/NonProd/Approved classification, stage and independent environment activation.

**Dependencies:** UTY-M1-01

**Acceptance criteria:**
1. A discovered operation cannot execute merely because it registered.
2. An Approved parent cannot promote an Experimental child operation.
3. A new InDev version does not change the currently active published version.

**Required evidence:** Registry lifecycle/API tests, privilege-negative tests and immutable audit evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-03 - Expose CyberArk Get Account with safe authentication reuse

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prove the first reusable CyberArk operation end-to-end.

**Implementation scope:** Wrap the existing approved client and rotating-credential/session provider; distinguish account lookup from paginated account search.

**Dependencies:** UTY-M1-01, UTY-M0-04

**Acceptance criteria:**
1. A valid authorized account ID resolves to the declared account model.
2. NotFound, denied, transport failure and invalid schema remain distinct outcomes.
3. Credentials and secrets are absent from descriptors, Kafka business payloads, fixture exports and logs.

**Required evidence:** Adapter tests using mocks plus approved DEV connection evidence when available.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-04 - Expose custom-field PATCH and onboarding metadata

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Provide the operations needed for update and create scenarios without scenario-specific handlers.

**Implementation scope:** Bind actual installed CyberArk PATCH contracts, allowed paths, Safe/Platform lookup and platform-dependent account-create requirements.

**Dependencies:** UTY-M1-03

**Acceptance criteria:**
1. Only requested permitted changed properties are written; unspecified properties are not cleared.
2. Blank/null/removal behavior is explicit and technical allowlists cannot be bypassed by AMIE.
3. Create Account shows unmet Safe/Platform and conditional properties; lookup selections are never silently guessed.

**Required evidence:** Payload fixtures, allowed-field negatives, create-contract tests and uncertain-write reconciliation trace.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-05 - Extract the reusable Email operation

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Reuse Policy Drift's email behavior as a second capability.

**Implementation scope:** Extract transport/HTML/attachment functions without importing Policy Drift decisions into the generic email handler.

**Dependencies:** UTY-M1-01, UTY-M0-05

**Acceptance criteria:**
1. Two different workflows send sanitized report content through the same handler.
2. SMTP accepted, delivered if evidenced, failed and unknown remain distinct.
3. A retry cannot silently duplicate an uncertain send; attachment references and recipient policies are authorized.

**Required evidence:** Existing-email parity fixtures, descriptor tests and safe duplicate/timeout tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-06 - Support capability-owned workflows and language-neutral onboarding

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep L2 local composition and future enterprise API reuse generic.

**Implementation scope:** Expose service-owned workflow contracts and approved adapter/OpenAPI candidate path; document non-.NET registration without promising every language SDK.

**Dependencies:** UTY-M1-01, UTY-M1-02

**Acceptance criteria:**
1. The local handler and same BOB core can be used without a central call per step.
2. OpenAPI discovery produces reviewable candidates, not inferred retry or authorization policies.
3. Capability -> API group/controller -> operation browsing and L2 ownership are consistent across code and catalog.

**Required evidence:** C# local example, language-neutral contract fixture and second-service descriptor proof.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M2 - BOB, AMIE and execution guarantees

**Objective:** Implement missing approved runtime behavior without replacing working BOB or AMIE.
**Milestone acceptance:** Shared-host regression, durability, boundary, approval and authorization evidence passes for the pilot scope.

### UTY-M2-01 - Reconcile BPMN compiler and shared host execution

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep one interpreter and the expanded approved Phase 1 scope.

**Implementation scope:** Extend typed bindings, operation/rule/subprocess references and host adapters; preserve IDs, scopes and immutable versions.

**Dependencies:** UTY-M0-01, UTY-M1-01

**Acceptance criteria:**
1. Central and embedded conformance fixtures agree on supported semantics.
2. Unsupported executable constructs are diagnosed before execution rather than treated as pass-through.
3. Local compiled handlers stay in their owning service, not copied into central BOB.

**Required evidence:** Compiler fixtures, host conformance report and reference-resolution tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-02 - Implement parallel tokens and durable joins

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Run independent work concurrently and join it once.

**Implementation scope:** Use activation-scoped tokens and transactionally persisted split/join state, with conflict-safe branch outcomes.

**Dependencies:** UTY-M2-01

**Acceptance criteria:**
1. A duplicate branch outcome cannot advance the join twice.
2. Restart after partial completion preserves remaining branch waits.
3. A failed/interrupted branch has an explicit join consequence and cannot leave an unexplained wait.

**Required evidence:** Parallel race, crash/restart, duplicate and nested-scope tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-03 - Implement intermediate and interrupting boundary timers

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Make waiting and deadlines durable, including external uncertainty.

**Implementation scope:** Persist due time, ownership/leases and atomic completion-vs-timeout resolution; retain original activity/correlation identity.

**Dependencies:** UTY-M2-01

**Acceptance criteria:**
1. Restart resumes an overdue timer once.
2. Timeout winning blocks the normal continuation; late external results remain auditable.
3. Interrupting a task is not represented as proof of cancelling an external CyberArk call.

**Required evidence:** Clock-controlled tests, completion/timer race and late-outcome evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-04 - Implement typed error boundaries and propagation

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Route modeled business errors without swallowing technical failures.

**Implementation scope:** Define operation outcome-to-error mapping, scoped matching and propagation across supported calls/subprocesses.

**Dependencies:** UTY-M2-01

**Acceptance criteria:**
1. A matching error takes its handler and does not also continue normally.
2. An unmatched error surfaces a classified incident or parent propagation.
3. Authorization failures cannot be converted into unconditional success by a generic catch.

**Required evidence:** Boundary match/non-match, nested propagation and security-negative fixtures.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-05 - Complete Kafka durability and recovery contracts

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prevent message loss and duplicate logical progression across services.

**Implementation scope:** Use existing outbox/inbox with command, attempt, correlation and idempotency identities; checkpoint waits before publish.

**Dependencies:** UTY-M2-01

**Acceptance criteria:**
1. Crash at each commit/publish boundary recovers without lost pending work.
2. Redelivery reuses a recorded outcome or waits on the original execution.
3. Unknown external write outcomes reconcile before repeat; pause/cancel/restart preserve pinned definitions.

**Required evidence:** Failure injection, dedupe replay, outbox lag and operator lifecycle tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-06 - Bind existing AMIE for local and central decisions

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use AMIE for decisions and mappings without another evaluator.

**Implementation scope:** Add typed fact/result adapter, native artifact reference and local approved definition cache as supported by existing implementation.

**Dependencies:** UTY-M0-02, UTY-M2-01

**Acceptance criteria:**
1. A business-rule task receives the expected snapshot and returns typed results.
2. A rule inserted in a mapping executes exactly once as its visible task.
3. Newly published rules cannot alter an already pinned running instance.

**Required evidence:** Native AMIE adapter tests, task trace and version-coexistence proof.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-07 - Implement durable multilevel approvals and backups

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Execute AMIE-defined approval plans through BOB human tasks.

**Implementation scope:** Use ordered any-one/all-required stages, eligibility and backup groups, reasoned rejection, timeout and concurrent-decision controls.

**Dependencies:** UTY-M2-06, UTY-M2-05

**Acceptance criteria:**
1. Concurrent responses cannot complete a stage twice.
2. Only eligible current principals can decide; a creator cannot self-approve when policy forbids it.
3. Restart preserves pending tasks and backup eligibility without inventing delegation policy.

**Required evidence:** Approval state-machine tests, RBAC negatives and BE decision evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-08 - Enforce workflow and capability-administration grants

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep human website access separate from service identities.

**Implementation scope:** Reuse groups/AMIE policies for Read, Execute, Execute-Lead, Create and explicit admin/approval/release permissions.

**Dependencies:** UTY-M0-03, UTY-M1-02

**Acceptance criteria:**
1. Execute-Lead sees only permitted group results; guessed record IDs do not widen access.
2. Create does not grant production activation or capability registration.
3. The capability validates trusted command admission without requiring external departments to manage every Unity user.

**Required evidence:** API/data-filter tests and end-to-end authorization decisions with audit.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M3 - Studio, source contracts and data intelligence

**Objective:** Make the approved authoring journey work end-to-end against actual adapters, not just the offline demo.
**Milestone acceptance:** An author maps a sample source, inserts a lookup/rule, tests two outcomes and round-trips the same workflow artifact without losing data.

### UTY-M3-01 - Implement compatible XML profile and partial-readiness import

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Preserve models while making incomplete imports actionable.

**Implementation scope:** Reconcile proposed extensions against existing serializers, retain standard DI and native AMIE artifacts, and separate editable/quarantined/executable states.

**Dependencies:** UTY-M0-02, UTY-M2-01

**Acceptance criteria:**
1. Supported export/import retains IDs, structure, mappings, categories, launch bindings and rule references.
2. Unknown content is preserved or explicitly quarantined, never silently dropped.
3. An unbound task loads as a draft with a clickable blocker; malicious DTD/external entities are rejected.

**Required evidence:** Official BPMN and Unity XSD results, native serializer proof and positive/negative round-trip corpus.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-02 - Implement universal schema and safe sample importer

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Create contracts from samples without letting inference silently redefine business meaning.

**Implementation scope:** Build one nested field editor shared by entry and ingestion; paste/upload CSV, JSON and supported Avro schema; preview merge/targets and locks.

**Dependencies:** UTY-M3-01

**Acceptance criteria:**
1. Quoted CSV, leading-zero IDs, nullable values and nested objects produce editable candidate fields.
2. Re-import preserves locked IDs/types/validation and appends new fields only after review.
3. Renames retain stable field identity; required/nullable/default are distinct; ambiguous arrays/unions are diagnosed.

**Required evidence:** Parser fixtures, merge diff, field-edit tests and sample data redaction tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-03 - Implement per-source setup and shared contract bindings

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Configure transport once without duplicating field-definition systems.

**Implementation scope:** Implement two tabs and on-demand overlays for all six source types; keep schema shared and extraction bindings adapter-specific.

**Dependencies:** UTY-M3-02

**Acceptance criteria:**
1. Kafka and CSV adapters target the same field IDs with different source paths.
2. Changing transport preserves the shared contract and identifies invalid old bindings.
3. Correlation, dedupe, decoding, gate and subscription each have distinct configuration and validation.

**Required evidence:** Guided source walkthroughs, normalized record fixtures and adapter-negative tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-04 - Implement scheduled context and ingestion task handoff

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Introduce business data only when ingestion produces it.

**Implementation scope:** Use run context/static parameters for AutoSys/cron, typed path/URL bindings and approved file/data/API capabilities with explicit per-row/batch outputs.

**Dependencies:** UTY-M3-03, UTY-M1-01

**Acceptance criteria:**
1. The scheduled start has no invented account payload.
2. A downstream rule cannot reference ingestion output before successful ingestion.
3. No-file, parse-error, partial-row and retry outcomes are distinguishable and visible.

**Required evidence:** Scheduler-context fixtures, row/batch cardinality tests and lineage screenshot/trace.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-05 - Implement typed resolver and one-click producer insertion

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Help users satisfy missing data without guessing execution or identity.

**Implementation scope:** Analyze required fields, guaranteed sources, semantic IDs, nullability, collection cardinality, freshness, scope and allowed hosts.

**Dependencies:** UTY-M3-01, UTY-M1-03, UTY-M2-01

**Acceptance criteria:**
1. Missing currentAccount offers eligible existing data first, then Add Get Account and Connect when unambiguous.
2. Insertion/mappings/control-flow change is atomic and one undo unit; deleting producer invalidates dependents.
3. Stale pre-write data, alternate-branch data and wrong account/vault identities are rejected.

**Required evidence:** One-click positive/negative suite, branch/loop/parallel dataflow analysis and bounded suggestion-cycle tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-06 - Implement editable contextual BPMN/data/rule depth

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep the useful existing builder while making deeper views genuinely editable.

**Implementation scope:** Retain guided/BPMN perspective, highlighted breadcrumb context, object/field selection, whole-object overrides, rule chooser and common history.

**Dependencies:** UTY-M3-05, UTY-M2-06

**Acceptance criteria:**
1. The same mapping changes in Process, Data and Rule perspectives without copying configuration.
2. Three-dot/right-click menus, replacement/removal and Undo/Redo continue working.
3. Inserting a field rule creates one visible BPMN Business Rule Task; shared AMIE rules are not mutated without explicit new drafts.

**Required evidence:** Inherited browser regression plus typed rule-insertion and serialization tests in both themes.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-07 - Implement catalogs, categories, inline step menu and help

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Make authoring discoverable without another maze of screens.

**Implementation scope:** Use multi-category workflows, service/API-group operation browsing, rule usage/dependency indicators, intent-first inline plus and contextual detailed pickers.

**Dependencies:** UTY-M1-02, UTY-M3-06

**Acceptance criteria:**
1. No mandatory owning Application/Business Space is required to create a reusable workflow.
2. A routing gateway cannot hide a capability call.
3. Every offered BPMN element has a description and separate modeling/runtime/environment support indicators.

**Required evidence:** Author walkthrough from blank draft to test, catalog filter tests and capability-boundary UI assertions.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-08 - Implement readiness, fixture testing and native artifact import

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Let authors see what is missing and test without confusing fixtures with production.

**Implementation scope:** Build clickable source/model/binding/runtime/release diagnostics, safe native artifact inspection and sample-driven execution through actual test adapters.

**Dependencies:** UTY-M3-03, UTY-M3-06

**Acceptance criteria:**
1. Unresolved input diagnostics identify the exact activity/field and suggested remedy.
2. Native syntax validity is not displayed as evaluator acceptance.
3. Successful local tests do not enable production publishing or mark integration stories accepted.

**Required evidence:** Readiness-negative suite, mock-vs-live labeling tests and source-to-rule outcome trace.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M4 - Business operations, observability and reusable testing

**Objective:** Give users, approvers and operators separate understandable views of durable execution.
**Milestone acceptance:** Business access is scoped server-side; operators can diagnose and safely recover a run using durable evidence beyond broker retention.

### UTY-M4-01 - Implement business portal, work queue and approver views

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Give business users useful status without exposing engineering complexity.

**Implementation scope:** Expose permitted process names, jobs/counts/reports, scoped group views and separate actionable My Approvals.

**Dependencies:** UTY-M2-07, UTY-M2-08

**Acceptance criteria:**
1. Portal queries enforce scope on the server including exports.
2. My Approvals shows pending tasks, not workflow-authoring controls.
3. Stuck/unknown/partial states are distinct from completed success.

**Required evidence:** Portal API/UI tests, approval journey and scoped report evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M4-02 - Implement durable audit and run projections

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep trustworthy evidence independent of Kafka retention.

**Implementation scope:** Write append-only audit through approved owner service with indexed IDs plus redacted JSON details; transactionally record lifecycle/outcomes.

**Dependencies:** UTY-M2-05, UTY-M2-08

**Acceptance criteria:**
1. Audit begins at admission and remains queryable after broker messages expire.
2. Retention is environment policy, not a hardcoded four-day assumption.
3. Secrets, raw credential responses and unapproved sample data are excluded even if a designer selects them.

**Required evidence:** Audit persistence/recovery/redaction tests, retention policy confirmation and projection consistency tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M4-03 - Implement safe operations and failure diagnosis

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Allow support to explain and recover failures without duplicating side effects.

**Implementation scope:** Show activity/attempt/rule/operation identities, timeout/retry status and redacted records; expose only supported recovery commands.

**Dependencies:** UTY-M4-02, UTY-M2-05

**Acceptance criteria:**
1. Restart creates an audited new run with approved inputs; a UI flag alone is insufficient authority.
2. Unknown PATCH/SMTP outcomes cannot be blindly replayed.
3. Kafka retention is shown only from verified configuration, not an invented countdown.

**Required evidence:** Operator command authorization tests, reconciliation demonstration and incident runbook.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M4-04 - Implement API capability workbench and reusable recipes

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Test approved APIs, chains and CSV cases without redeploying for each payload change.

**Implementation scope:** Reuse operation contracts, secure credential references, source mappings and local BOB recipes; capture sanitized request/response/assertions.

**Dependencies:** UTY-M1-03, UTY-M1-05, UTY-M3-02

**Acceptance criteria:**
1. An author changes a permitted payload or chain and retests without compiling a new service.
2. Credential acquisition is reused internally, not pasted into steps or outputs.
3. Promoting a recipe uses the same workflow/mapping model and validates approved operations.

**Required evidence:** Workbench end-to-end fixture, secret-redaction tests and recipe-expansion diff.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M4-05 - Implement comparison/diff, configuration guides and drift foundations

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Make configuration changes understandable and prepare later drift alerts.

**Implementation scope:** Add before/after diff, stable resource digests, links to approval/release, and user guides tied to actual controls.

**Dependencies:** UTY-M4-02, UTY-M3-07

**Acceptance criteria:**
1. A group, rule, capability or published workflow change records actor/scope/versions and reason.
2. Audit baseline events exist without claiming full automated drift detection.
3. Guide screenshots and exact controls match the accepted UI journeys.

**Required evidence:** Change evidence fixture, guide walkthrough and baseline event contract tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M5 - Enterprise integration and controlled promotion

**Objective:** Finish the required enterprise dependencies and DEV -> UAT -> PROD release path.
**Milestone acceptance:** Each integration is verified or explicitly not required for the selected pilot; no unaccepted production blocker remains.

### UTY-M5-01 - INT-CHSEC: integrate Channel Secure SSO and entitlements

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Complete the required enterprise identity boundary before go-live.

**Implementation scope:** Reuse Matthew's current auth while connecting approved SAML/entitlement contracts and verifying environment-specific groups.

**Dependencies:** UTY-M0-04, UTY-M2-08

**Acceptance criteria:**
1. Issued identities/groups resolve through the same authorization service.
2. Production excludes NonProd grants; expiry/revocation behavior is tested.
3. Unknown enterprise details remain blocked dependencies, not guessed code.

**Required evidence:** Owner-approved integration evidence, SSO/session tests and production-group negative tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-02 - INT-APIGEE: onboard gateway and service identities

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Enable approved external API calls through required gateway controls.

**Implementation scope:** Confirm route, token/certificate, policy, rate/timeout and service-account configuration per environment.

**Dependencies:** UTY-M0-04, UTY-M1-03

**Acceptance criteria:**
1. The capability uses the approved service identity and declared operations.
2. No end-user group provisioning is pushed into every department API.
3. Gateway errors retain safe typed classification and correlation.

**Required evidence:** Gateway owner signoff, authorized DEV/UAT calls and deny/rate-limit tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-03 - INT-SPLUNK: connect approved telemetry sinks

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Expose diagnosable, redacted execution evidence to enterprise monitoring.

**Implementation scope:** Confirm log fields, transport, dashboards/alerts, indexing, retention and correlation across central/embedded execution.

**Dependencies:** UTY-M0-04, UTY-M4-02

**Acceptance criteria:**
1. A pilot run can be traced across BOB, capability and outcome without secrets.
2. Logging failure behavior does not silently discard required audit.
3. Alert thresholds and ownership are verified rather than invented.

**Required evidence:** Splunk ingestion/query evidence, redaction tests and support owner approval.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-04 - INT-AUTOSYS: scheduler trigger integration

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use externally owned schedules without turning BOB into the AutoSys scheduler.

**Implementation scope:** Confirm job/box identity, trusted trigger adapter, scheduled occurrence, retry identity and outcome reporting.

**Dependencies:** UTY-M0-04, UTY-M3-04

**Acceptance criteria:**
1. One scheduled occurrence creates one logical run despite redelivery.
2. Run metadata normalizes to the agreed context and feeds ingestion bindings.
3. The original scheduled time survives late arrival/retry; caller identity is verified.

**Required evidence:** Job invocation and duplicate tests plus scheduler ownership signoff.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-05 - INT-CRON: controlled scheduled trigger integration

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Provide cron-trigger behavior without duplicate schedule ownership.

**Implementation scope:** Confirm approved scheduler runtime, timezone/DST, overlap/misfire policy, identity and monitoring.

**Dependencies:** UTY-M0-04, UTY-M3-04

**Acceptance criteria:**
1. Schedule ownership is declared outside the workflow unless explicitly approved otherwise.
2. Duplicate/overlapping executions obey the selected admission policy.
3. Context-only starts introduce no fictitious business payload.

**Required evidence:** Scheduled occurrence fixtures, timezone tests and operational ownership evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-06 - INT-NAS: staged files and owner-mediated data access

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Connect real staging/ingestion without unauthorized file or database access.

**Implementation scope:** Confirm what NAS denotes here, approved roots and owning data APIs; implement file readiness, row identity and result persistence.

**Dependencies:** UTY-M0-04, UTY-M3-04

**Acceptance criteria:**
1. Staged file/row references resolve only through the authorized owner.
2. Incomplete files, duplicate imports and invalid rows have explicit outcomes.
3. No arbitrary SQL/private-table bypass is exposed by a generic dropdown.

**Required evidence:** Owner contract, approved UAT import, file/row dedupe and path traversal tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-07 - Build immutable packages and trusted validation

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Promote the tested definition and dependencies as one controlled unit.

**Implementation scope:** Package BPMN/DI/extensions, native AMIE, pinned operation dependencies, schema manifests and evidence; use approved signing/trust.

**Dependencies:** UTY-M3-01, UTY-M4-02

**Acceptance criteria:**
1. Altered content, unknown signer, missing dependency and unsupported feature are rejected.
2. Private signing keys and execution secrets are not embedded in XML or ZIP.
3. Unverified native AMIE serialization or runtime support blocks activation even when XSD passes.

**Required evidence:** Package integrity/signature tests, official schema evidence and dependency resolution report.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-08 - Import environment group/rule configuration and change references

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Roll out real configuration through approved imports rather than fake seeded privileges.

**Implementation scope:** Use migrations for structure and authorized idempotent packages for group references/grants/environment bindings; require production ServiceNow reference.

**Dependencies:** UTY-M5-07, UTY-M2-08

**Acceptance criteria:**
1. Production rejects NonProd group mappings and unexpected privilege increases.
2. A nonempty ServiceNow ID is recorded but not called external approval validation.
3. Import previews changes and does not activate them automatically.

**Required evidence:** DEV/UAT config round-trip, negative prod mappings and audited import diff.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-09 - Activate, rollback and verify production readiness

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Separate file upload from authorized production activation.

**Implementation scope:** Implement reviewed staged activation, four-eyes/AMIE controls as applicable, environment bindings, rollback and in-flight version handling.

**Dependencies:** UTY-M5-07, UTY-M5-08

**Acceptance criteria:**
1. A user with Create but no release entitlement cannot activate production.
2. Rollback changes future starts while existing instances retain original versions.
3. Unimplemented experimental features and unverified mandatory integrations block go-live.

**Required evidence:** Activation/rollback tests and signed UAT-to-PROD acceptance evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M6 - Integrated acceptance and production readiness

**Objective:** Prove both pilot services and authoring paths, migration parity, and operational controls in UAT.
**Milestone acceptance:** Business, technical, security and operations acceptance evidence is attached; production activation is separately authorized.

### UTY-M6-01 - Prove CMDB custom-field update end-to-end

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prove the principal data-hydration and update scenario.

**Implementation scope:** CSV -> staging -> normalized per-record message -> Get -> AMIE compare -> partial PATCH -> second Get -> typed row outcome.

**Dependencies:** UTY-M1-04, UTY-M2-05, UTY-M3-05, UTY-M5-06

**Acceptance criteria:**
1. Four desired fields plus Account ID suffice for incoming business data.
2. No-change skips write; changed fields only are patched; post-write mismatch is not reported as success.
3. Redelivery, lookup failure and uncertain PATCH have demonstrated safe results.

**Required evidence:** Integrated DEV/UAT trace with sanitized requests, row identities and actual verification evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M6-02 - Prove account onboarding with conditional requirements

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prove more extensive input contracts and approved lookup composition.

**Implementation scope:** Normalize form/API inputs, select/resolve Safe and Platform, resolve conditional fields, evaluate AMIE and approvals, create and verify.

**Dependencies:** UTY-M1-04, UTY-M3-05, UTY-M2-07

**Acceptance criteria:**
1. Unresolved mandatory platform properties block execution.
2. Lookup collection vs chosen single value is explicit.
3. Approvals and authorization cannot be bypassed through source mapping or a naming rule.

**Required evidence:** Create-account UAT cases, denied/ambiguous/missing-data tests and object lineage.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M6-03 - Prove CyberArk plus Email reuse and native configuration change

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prove the platform generalizes beyond one API and avoids recompilation for business changes.

**Implementation scope:** Invoke CyberArk local workflow then Email centrally; reuse each primitive in a second process; publish a changed native rule.

**Dependencies:** UTY-M1-05, UTY-M2-06, UTY-M6-01

**Acceptance criteria:**
1. No operation handler is duplicated for the second workflow.
2. A new rule/workflow version changes behavior without recompiling unchanged services.
3. Old running versions and sanitized notification policy remain intact.

**Required evidence:** Two distinct process traces and native configuration-release comparison.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M6-04 - Run usability, security, scale and recovery acceptance

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Judge the complete journey, not the number of screens or test names.

**Implementation scope:** Observe an author completing requirements-to-release preparation; test operational failures and realistic capacity targets agreed with owners.

**Dependencies:** UTY-M3-08, UTY-M4-03, UTY-M5-09

**Acceptance criteria:**
1. Users can go A-to-Z with contextual help and no hidden configuration detours.
2. Cross-group data isolation, unsafe uploads and secret exfiltration are tested.
3. Performance/availability claims state measured environment/load and recovery evidence.

**Required evidence:** Accepted walkthrough, security test report, load profile and failure-injection results.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M6-05 - Accept handoff, guides and go-live checklist

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Close milestones only on accepted evidence and retain the design rationale.

**Implementation scope:** Update current master/Ask/generated files from one source, attach story evidence, verify integration approvals and operational ownership.

**Dependencies:** UTY-M6-01, UTY-M6-02, UTY-M6-03, UTY-M6-04

**Acceptance criteria:**
1. Each active story has accepted evidence or an explicit approved scope change.
2. No unresolved production blocker is hidden by a green demo result.
3. The final team receives one current package with the same decisions, diagrams, source and guides.

**Required evidence:** Megan milestone signoff, operations/go-live approval and package verification report.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M7 - Next-phase improvements, not initial-release blockers

**Objective:** Track approved future directions without quietly pulling them into the immediate build.
**Milestone acceptance:** Each improvement is separately scoped and admitted after the initial capability/Studio foundation is verified.

### UTY-M7-01 - Refine overlapping AMIE orchestration after initial release

**Owning milestone:** M7. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Correct any confirmed competing durable orchestration without losing working intake decisions.

**Implementation scope:** Use the deferred Matthew review, characterize state ownership and migrate with parity/rollback.

**Dependencies:** UTY-M0-02, UTY-M6-05

**Acceptance criteria:**
1. The change addresses an observed overlap, not speculation.
2. AMIE classification/enrichment remains valid where needed.
3. Regression and rollback protect existing processes.

**Required evidence:** Approved future decision record and source-level migration tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M7-02 - Integrate ServiceNow ticket/approval validation

**Owning milestone:** M7. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Replace reference-only ticket recording with the requested enterprise integration when approved.

**Implementation scope:** Implement a registered capability for ticket status/approval interaction and preserve BOB durable task ownership.

**Dependencies:** UTY-M5-08, UTY-M6-05

**Acceptance criteria:**
1. External status is authenticated and correlated to the exact release/request.
2. Unavailable integration fails according to approved policy.
3. Existing reference-only records retain history and are not retroactively called validated.

**Required evidence:** Approved ServiceNow capability contract and integration test evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M7-03 - Add AI/MCP co-design and approved drift detection

**Owning milestone:** M7. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use governed model-editing tools and baselines without bypassing human control.

**Implementation scope:** Expose versioned read/plan/validate/propose tools; separately implement baseline comparison alerts for configuration and approved identity events.

**Dependencies:** UTY-M6-05

**Acceptance criteria:**
1. AI proposals use the same atomic commands/compiler/grants as the UI.
2. No tool publishes production merely because its output is schema-valid.
3. Drift alerts distinguish approved baseline changes from unauthorized differences.

**Required evidence:** Future security/tool conformance tests and baseline-alert fixtures.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M7-04 - Activate deferred BPMN and richer modeling only on demand

**Owning milestone:** M7. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep the architecture extensible without bloating the first build.

**Implementation scope:** Consider noninterrupting events, inclusive/event-based gateways, parallel multi-instance, compensation and event subprocesses individually.

**Dependencies:** UTY-M2-01, UTY-M6-05

**Acceptance criteria:**
1. Every activated construct gains compiler/runtime/persistence/designer tests.
2. Experimental visibility never implies executable support.
3. Full UML state machines/XMI or a second runtime require a new explicit decision.

**Required evidence:** Feature-by-feature conformance evidence and compatibility review.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

<!-- END SOURCE: planning/milestones-stories.md -->



---

<!-- BEGIN SOURCE: DEMO-RUNBOOK.md -->

# Demo runbook - WF Unity Complete Handoff v4

## Open and reset

Extract the complete ZIP and open root `START.html`. Choose **Open Modeling Studio**. The prototype is a single self-contained `demo/OPEN.html`; no server, internet, installation, production credentials or service account is required. Use a current desktop Chromium-family browser for the tested path. A browser running the file is required; an attachment preview may not execute scripts or resolve neighboring files.

The initial workflow is **CMDB custom-field enrichment**, selected at **Compare custom fields**. There are two ways to see it: guided step/process view, and contextual Data / Rule / Operation / Full lineage depth. The BPMN strip always identifies the selected activity. The blue source objects, purple rules and teal destination inputs use text labels as well as color. Theme changes do not change workflow logic.

The prototype persists local drafts in browser storage. Use **Demo guide -> Reset sample workflow** for a known clean fixture. When a host/browser policy does not permit storage, the current in-memory demo still works but reload may reset it. Export a draft/BPMN before deliberately resetting work you want to retain. Do not paste real secrets or production payloads into the demo.

## Presenter opening

> Unity is a visual programming environment built around existing reusable API operations. CyberArk and Email are our first capabilities. BOB supplies execution structure, AMIE supplies business decisions, and the Studio shows the same workflow at process, object, field and rule levels. What I am showing today is the working offline interaction model. Enterprise integration and production readiness are tracked separately.

Do not call the local fixtures live CyberArk or native AMIE. Do not claim an XSD alone proves process execution. Do not claim the source audit is complete.

## Journey 1 - Preserve the useful editor and show an editable rule in the data flow

1. Open the Studio at **Compare custom fields**. Point to the BPMN context strip and the source/current-account/desired-field objects.
2. Expand **desired** if necessary. On the target **Owner** field choose the three-dot menu, or right-click, then **Insert / replace data rule**.
3. In the larger rule chooser select **Normalize text**, inspect its input/output and description, and choose **Insert and connect rule**.
4. Show that the purple mapping rule also appears as a Business Rule Task in the BPMN strip. It is the same activity, not a second hidden rule engine.
5. Open that rule, change its trimming/case parameters, preview a sample and save the workflow-local draft. This changes the fixture rule occurrence, not an approved shared native rule.
6. Use Undo/Redo. The task insertion, control links and field mapping move together as one operation. Return to the data view or full BPMN without losing the selected workflow.

Explain: the author can map a whole object and override one field; changing Owner does not require reentering all other custom-field mappings. Invalid source/target types are rejected rather than silently coerced.

## Journey 2 - A missing account object is a resolvable dependency

1. In the BPMN context select **Get current account**. Use its step actions to remove the workflow occurrence, confirming the impact. This does not remove the CyberArk capability from the registry.
2. Return to **Compare custom fields**. Current account becomes unresolved because its producing activity disappeared.
3. Use **Add Get Account and Connect** when offered. The prototype inserts the lookup before Compare, maps the known request Account ID and connects the account result.
4. Show the updated BPMN context and mapping source. Use Undo/Redo once to demonstrate it is one edit.

Explain: this button edits the draft; it does not call an API. The full backend resolver must additionally enforce environment, target/vault identity, freshness, authorization and graph scope. In particular, a pre-update GET is not a substitute for the second verification GET.

## Journey 3 - Source setup is distinct from the shared contract

Reset the sample workflow before this journey if prior edits left intentional warnings.

1. Choose **Entry setup** in the canvas toolbar. On **Trigger**, show Kafka topic/group/decoder and the separate gate, correlation and deduplication fields. There is no raw sample box or schema grid cluttering this tab.
2. Choose **+ Add launch binding**. The demo adds a CSV adapter. The same contract fields and their stable identities remain; it does not create a separate copy of the business model.
3. Choose **Data contract**, then **Paste / upload sample**. In the overlay choose **Load example**, then **Infer fields**.
4. Inspect the five columns and suggested targets: Account ID plus Owner, BusinessUnit, CostCenter and Application. Change a target before applying when desired. Inference is a prefill, not a declaration that sample values prove production types or requiredness.
5. Choose **Apply reviewed fields**. The CSV column mappings target the existing nested desired object. Select a field row to show type, required/nullable, validation and source binding in the Field Detail overlay.
6. Lock a reviewed field, paste an updated sample with an additional optional column and apply. The locked definition is preserved; new reviewed columns can be added. A field absent in a new sample is not silently deleted.
7. Use the normalized sample preview to show that a flat CSV becomes the same nested input object consumed by the workflow. Then choose **Use first sample in test**.

Useful supplied samples are in `demo/samples/`. The exact sample parser supports the bounded cases in QA; complicated Avro unions and unconfigured array item models are diagnosed, not invented. The user's Source path, auth and topic values are fixture configuration only.

## Journey 4 - Test both business outcomes and explain operational views

1. In **Test**, choose **Run local fixture**. It reads the current draft and mapped sample, not a fixed success banner.
2. With the untrimmed Owner example, Compare can produce a change. Adding the trim rule can produce **No change** against the sample current-account value. A deliberate different desired field produces a simulated update and second GET.
3. Use the explicit verification-mismatch option to show why a successful update transport result is not sufficient business verification.
4. Open **Business portal**. It shows the recorded local fixture run and business-oriented state without BPMN editing controls.
5. Open **Ops diagnostics**. It shows the same run's step trace and redacted local audit JSON, with live restart/replay disabled.

Explain: real server RBAC, durable SQL projections, Splunk and recovery are separate milestone work. Switching prototype views is not security enforcement. No fake Kafka expiry countdown is displayed.

## Journey 5 - Scheduler context enters before business data

1. Open **Entry setup** and choose **Load scheduled-ingestion example** from the demo guide or scheduler panel.
2. Show the AutoSys adapter and **Run context**: the initial request has scheduled date/run identity, not a fictitious account CSV payload.
3. Return to the process. **Ingest Daily CSV** is an explicit first operation. It introduces a typed business record. Get Account binds `ingest` output Account ID, not an imaginary initial field.
4. Run the scheduled local fixture. Show the trace ordering: ingestion precedes account read and rule evaluation.

Explain: this is a one-record simulation. Production ingestion must handle file readiness, row identity, validation, paging/batch policy and actual approved data-owner access. AutoSys/cron still own their schedule mechanics unless a separate decision changes that.

## Journey 6 - Canonical BPMN and native rules, not JSON-only workflows

1. Open **File** in the canvas toolbar. Choose BPMN export and save the file.
2. Reimport that supported-profile file and confirm preserved activities, mappings, source settings and diagram information. The package also includes actual exported examples for review.
3. Show **Preserve native AMIE artifact (XML or JSON)**. The demo can preserve a supplied artifact without translating its language. Parsing syntax is not AMIE evaluation or approval.
4. Show Release: production activation remains blocked. Explain the real path: validate dependencies, native artifacts and schemas; approve; export a trusted immutable package; import into UAT; authorized production import/activation with ServiceNow reference initially; keep running versions pinned.

Do not present native AMIE JSON as settled. The supplied v4 draft and prior XML discussion conflict; Matthew's current working implementation is authoritative after source verification. The demo does not change it.

## Capability provider part of the demo

Return to root `START.html` and open **Capability Studio**. This retains the prior provider onboarding prototype so the team can discuss Connect -> Expose operations -> Local BOB/AMIE -> Test/review for CyberArk and Email. It is a provider-contract design reference, not a second workflow engine and not evidence that registration is deployed.

Explain that the SDK registers approved descriptors and generated schemas, not arbitrary downloaded code. Registration is separate from approval/maturity/environment activation. Most users consume the operation through a workflow; the external department grants the service identity access, not per-Unity-user permissions to every endpoint.

## Presenter close

> The important result is one coherent authoring model. Existing API calls become reusable instructions, rules and workflows define business behavior, and data requirements are visible and resolvable without forcing all information into the incoming message. We have an executable offline interaction demo and a complete implementation handoff. The outstanding register identifies which real contracts, integrations and safety guarantees still require evidence.

## Recovery during the presentation

If an action is intentionally invalid, leave the diagnostic visible and explain it; do not hide a legitimate blocker. Use Undo for local edits or Reset sample workflow for a clean example. If browser policy prevents neighboring HTML navigation, open the desired extracted file directly. The single-file Studio itself requires no external assets. Screenshots provide a fallback only, not proof that a nonworking action succeeded.

This runbook is a demonstration sequence, not a time estimate or a guarantee of an enterprise rollout schedule.

<!-- END SOURCE: DEMO-RUNBOOK.md -->



---

<!-- BEGIN SOURCE: schemas/README.md -->

# Schemas and interoperability boundary

`unity-modeling-v3.xsd` is the original tested prototype model schema retained for compatible serialization of the existing working demo. `unity-entry-v4.xsd` is a proposed additive entry-configuration schema: shared fields, per-source adapters/extraction mappings, provenance and opaque native artifact preservation. The current demo exports both namespaces without independently maintaining two editable workflow models. The compatibility projection is checked on import; disagreement is not silently accepted.

These files are **reference extension schemas**, not declarations of the enterprise's actual AMIE/BOB contracts. Production integration must follow M0 source reconciliation. The entry schema deliberately does not claim to encode every business validation rule. Adapter-specific configuration, identifier/path uniqueness, reference validity, runtime policy, field types, dataflow guarantees and native artifact validity require additional validators.

Full official BPMN 2.0.2 XSD validation is a separate acceptance gate. The official local bundle was unavailable in this environment. Supply an approved copy of BPMN20.xsd and its local imports to `qa/validate_package_xml.py --omg-xsd /approved/path/BPMN20.xsd`. Do not replace missing official schema files with a hand-written approximation and report conformance.

XSD does not render the UI, register handlers, understand AMIE logic, establish authorization or prove executable semantics. A designer/compiler implementation must implement the corresponding contracts and tests.

`unity-modeling-v4.xsd` is a convenience assembly importing both proposed/preserved extension namespaces. It does not import or substitute for the official BPMN schema.

<!-- END SOURCE: schemas/README.md -->



---

<!-- BEGIN SOURCE: examples/README.md -->

# Executable-artifact examples: explicit evidence levels

The two `baseline-*.bpmn` files are preserved v3 examples. `v4-cmdb-with-source-contract.bpmn` and `v4-scheduled-ingestion.bpmn` are actual exports from the extended demo during the recorded browser tests. They demonstrate the documented prototype serialization profile, typed mappings, native BPMN elements/DI and the proposed entry extension.

None is a deployable bank workflow or proof of native AMIE compatibility. Fixture rule parameters stay labeled fixture-only. An actual native AMIE artifact must come from the verified existing serializer. No fabricated XML/JSON sample is presented as Matthew's native language.

Use the supplied QA scripts to validate extension structure and references. Full official BPMN XSD and production compiler tests remain distinct gates. This example corpus should be extended by Devin with negative branch, timer, human approval, loops, parallelism, unknown extension and native artifact parity fixtures.

<!-- END SOURCE: examples/README.md -->



---

<!-- BEGIN SOURCE: demo/samples/README.md -->

# Synthetic source samples

These contain fictional business records only. No credentials or production data are included. The CSV normalizer maps Account ID and four custom fields to the existing account-update contract. Leading zeros in CostCenter are intentional: a numeric-looking identifier should not be silently converted to an integer.

`cmdb-records-new-column.csv` demonstrates safe merge after locking an existing field. `account-request.json` contains the equivalent nested model. `event-schema.avsc` demonstrates a small supported Avro record/nullable-union schema, not a binary Avro payload. Kafka decoding/schema-registry integration remains separate.

In the actual UI use Paste / upload sample, inspect inferred candidates and target mappings, then apply. Do not treat a sample as proof of requiredness or an approved production schema.

<!-- END SOURCE: demo/samples/README.md -->



---

<!-- BEGIN SOURCE: qa/README.md -->

# Verification instructions

Read QA-REPORT.md for the evidence boundary. Rebuild the single-file demo using tools/build_demo.py, then run baseline_browser_tests.py, v4_browser_tests.py, validate_package_xml.py and smoke.py from the package root. Python dependencies are playwright, lxml and beautifulsoup4; Chromium must be installed or CHROMIUM_PATH supplied. Browser tests use the exact OPEN.html bytes with set_content.

The historical baseline validator is retained only as source evidence; use validate_package_xml.py for the current sample set and optional official BPMN gate. Browser-local tests must never be substituted for the actual BOB/AMIE/runtime integration tests listed in the milestone stories.

Rebuild HTML documentation and consolidated copies with tools/build_handoff.py after changing a normative Markdown document. Re-run tests and packaging checks after code/artifact changes. Do not hand-edit an Ask alias independently.

<!-- END SOURCE: qa/README.md -->



---

<!-- BEGIN SOURCE: qa/QA-REPORT.md -->

# Current verification report

**Date:** 2026-11-20. **Claim:** the supplied offline demo and reference artifacts support the specifically tested interactions. **Not claimed:** enterprise deployment, complete BPMN conformance, native AMIE evaluation, server RBAC, or production readiness.

| Verification | Actual result | Evidence |
|---|---|---|
| Inherited editable-modeling browser regression | 48/48 passed | demo/qa/browser-results.json; qa/baseline-browser-output.txt |
| New entry/schema/demo browser regression | 45/45 passed | qa/v4-browser-results.json; qa/v4-browser-output.txt |
| Unity extension XSD and XML reference checks | 116/116 passed | qa/xml-results.json; qa/xml-output.txt |
| JavaScript syntax | Checked with node --check | qa/smoke.py repeats syntax checks for all current assets |
| Original source preservation | Original archives retained; digests compared in package smoke check | source-reference/source-checkpoint.json |
| Current package/link/story consistency | 53/53 checks passed; 111 local HTML links checked | qa/package-results.json; repeat smoke.py after changes |
| Official full BPMN 2.0.2 XSD | **Not run** | Approved official schema bundle was not available to the local validator |
| Actual BOB / AMIE / SDK / Blazor integration | **Not run** | Enterprise repository and runtime were not supplied |
| CyberArk / SMTP / Kafka / AutoSys / NAS / Channel Secure / Apigee / Splunk | **Not run** | No live calls are performed by the offline demo |
| Production package signing/import/activation | **Not run; UI blocked** | Requires verified native contracts, approval, trust and integration evidence |

## What the browser checks cover

The inherited suite checks contextual BPMN selection, editable nested mappings and object overrides, type/cardinality/optional/future-source rejection, three-dot/right-click/keyboard menus, rule search and replacement, actual local normalization, a real rule task insertion with atomic Undo/Redo, dependency-aware removal/repair, fixture success/no-change/verification-mismatch paths, known-profile XML/DI round-trip, malicious/unsupported input rejection, themes and narrow layout.

The new suite checks separated Trigger/Data Contract panels; independent correlation/dedupe fields; adding a CSV launch binding without cloning the shared contract; pasted and actually uploaded samples; nested normalized record preview; locked-field preservation; leading-zero identifiers; quoted commas/newlines; malformed CSV rejection; nested JSON and supported nullable Avro schema; source-switch compatibility diagnostics; XML persistence of multiple source bindings and field locks; opaque native XML preservation; all four scheduled run-context fields and explicit ingestion-before-read behavior; same local test trace in business/Ops views; guide/reset actions; File menu; themes and small-screen width.

These checks load the exact self-contained HTML in Chromium using Playwright set_content. They are real browser interaction tests, but do not certify every browser, operating system, enterprise file policy, assistive technology or live deployment. The HTML must be extracted and opened in a browser; an attachment preview is not the supported interactive host.

## XML evidence boundary

Both extension schemas compiled in lxml/libxml2. Positive exported examples and negative mutations were tested. IDs, BPMN sequence/data references, diagram references and source-binding field references were checked. Unknown types/attributes, invalid booleans/durations, duplicate IDs, negative column indexes and missing/dangling required bindings were rejected by the relevant validators. Native rule preservation is a text/format test; not an AMIE semantic test.

The convenience unity-modeling-v4.xsd assembles the preserved model extension and additive entry extension. It does not substitute for the official BPMN schemas. The complete workflow graph compiler still needs production parallel/loop/error/freshness/authorization and host-boundary tests. Passing XSD does not establish those guarantees.

## Known limits retained deliberately

The demo's catalogs and fields are fixtures. The custom model UI does not yet implement every array item/union/enum/range/default migration scenario. It simulates one scheduled ingestion row, not real NAS files, batch paging or scheduler ownership. Unsupported models are preserved/quarantined or explicitly rejected, not claimed fully editable. The native AMIE serializer is unverified. The prior Capability Studio remains a provider-onboarding reference rather than actual service registration. Portal/Ops records are in browser memory; restart/replay are intentionally unavailable. Production activation remains disabled.

## Reproduce

From the extracted package root, with Python, lxml, BeautifulSoup, Playwright and Chromium available:

```sh
python tools/build_demo.py
python qa/baseline_browser_tests.py
python qa/v4_browser_tests.py
python qa/validate_package_xml.py
python qa/smoke.py
```

Optional official standard-schema gate, using a trusted local bundle with its imports:

```sh
python qa/validate_package_xml.py --omg-xsd /approved/bpmn/BPMN20.xsd
```

Set CHROMIUM_PATH if Chromium is not on PATH. Do not report a skipped check as passed. Tests regenerate their own evidence; baseline/browser fixture outputs are separate from enterprise test results.

<!-- END SOURCE: qa/QA-REPORT.md -->
