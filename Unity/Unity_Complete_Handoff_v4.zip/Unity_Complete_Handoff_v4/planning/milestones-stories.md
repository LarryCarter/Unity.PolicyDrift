# Milestones and Jira-ready stories

**Package:** WF Unity Complete Handoff v4, 2026-11-20. **Planning identifiers are not Wells Fargo Jira issue keys.** No tickets were created, deleted or queried.

Every story below has one owning milestone. Dependencies may cross milestones, but do not double-count a story. The offline demo is evidence of interface behavior, not completion of enterprise implementation. Existing work must be verified before assigning new build work. All initial repository status values are **Not assessed**; none is labeled Done merely because a prototype test passed.

## Megan reporting view

| Milestone | Story count | Acceptance gate | Current implementation evidence |
|---|---:|---|---|
| M0 - Baseline and contract reconciliation | 5 | A reviewed evidence map identifies existing/extend/adapt/defer for each subsystem; no replacement contracts are assumed. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M1 - Capability foundation: CyberArk and Email | 6 | Both services expose approved typed operations and a second workflow reuses an unchanged implementation. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M2 - BOB, AMIE and execution guarantees | 8 | Shared-host regression, durability, boundary, approval and authorization evidence passes for the pilot scope. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M3 - Studio, source contracts and data intelligence | 8 | An author maps a sample source, inserts a lookup/rule, tests two outcomes and round-trips the same workflow artifact without losing data. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M4 - Business operations, observability and reusable testing | 5 | Business access is scoped server-side; operators can diagnose and safely recover a run using durable evidence beyond broker retention. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M5 - Enterprise integration and controlled promotion | 9 | Each integration is verified or explicitly not required for the selected pilot; no unaccepted production blocker remains. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M6 - Integrated acceptance and production readiness | 5 | Business, technical, security and operations acceptance evidence is attached; production activation is separately authorized. | Not assessed against enterprise repository; prototype evidence in QA is separate |
| M7 - Next-phase improvements, not initial-release blockers | 4 | Each improvement is separately scoped and admitted after the initial capability/Studio foundation is verified. | Not assessed against enterprise repository; prototype evidence in QA is separate |

**Initial scope:** 46 stories across M0-M6. **Next phase:** four M7 stories. This is a dependency plan, not a promise that unknown access, approvals or integration work fits a two-week calendar. Scope sequencing should be adjusted against source audit and external availability, not by silently omitting runtime safety.

For each milestone report: accepted stories / total in-scope stories; remaining stories by Ready/Active/Blocked/Verify-existing; blocking dependency and owner; milestone gate evidence. Counts describe completion, not a reliable effort estimate when stories differ in size. Use estimates only after team review. A closed ticket without accepted evidence does not close the milestone.

## Relationship to the supplied Studio v4 milestone proposal

| Supplied draft milestone | Current platform mapping | Reason |
|---|---|---|
| Draft 1: schema, round-trip, partial readiness | M0-02; M3-01; M3-08; M5-07 | Preserve actual native AMIE and separate import/edit readiness from release |
| Draft 2: resolver and sample import | M3-02 through M3-05 | Shared field model, source bindings and execution-aware provenance |
| Draft 3: Studio UX and catalog | M3-06; M3-07 | Extend existing contextual editor; preserve menus and approved minimal UML scope |
| Draft 4: observability, test and RBAC | M2-08; M3-08; M4-01 through M4-05 | Browser views do not implement server authorization or durable audit |
| Draft 5: Phase 2 AI/MCP | M7-03 | Contract-first future enhancement; not a first-release prerequisite |

Older WF-M0..WF-M6 identifiers remain historical references only. Use the current UTY-M* identifiers when drafting the replacement tickets. Preserve any actual Jira keys the user later provides as external references; this file does not instruct deletion of live tickets.

## M0 - Baseline and contract reconciliation

**Objective:** The actual repositories, approved serializers, existing SDK/auth, and environment dependencies are mapped before changes.
**Milestone acceptance:** A reviewed evidence map identifies existing/extend/adapt/defer for each subsystem; no replacement contracts are assumed.

### UTY-M0-01 - Inventory repositories and preservation boundaries

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Give Devin an evidence-based map of what already works.

**Implementation scope:** Read AGENTS.md and actual BOB, AMIE, BE, SDK, broker, EF, auth and release code; record paths/commits and existing tests.

**Dependencies:** None; first audit activity.

**Acceptance criteria:**
1. Each claimed existing contract cites a concrete source location and revision.
2. Every proposed change is classified retain/extend/adapt/defer, including impacted consumers.
3. No branch, schema migration or replacement evaluator is introduced as part of this audit.

**Required evidence:** Read-only inventory, source-to-spec map, baseline build/test output and gap decisions.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M0-02 - Verify AMIE native format and current intake ownership

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Resolve the XML/JSON conflict without rewriting Matthew's rule system.

**Implementation scope:** Inspect real rule artifacts, serializer, editor/evaluator APIs, local caching and intake-to-BOB behavior; preserve original bytes.

**Dependencies:** UTY-M0-01

**Acceptance criteria:**
1. A real rule is read/written/evaluated through the existing adapter with equivalent results.
2. The verified native format and permitted inline/reference packaging are recorded; fixtures are not treated as native evidence.
3. Any overlapping durable AMIE orchestration is recorded for M7 rather than forced into the first release.

**Required evidence:** Native artifact fixture, serializer/evaluator regression and ownership trace.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M0-03 - Verify capability and identity contracts

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use the existing SDK and Matthew's authentication/groups rather than duplicate them.

**Implementation scope:** Inspect registration, operation IDs, schemas, grant resolution, local host calls, transport envelope and service identity boundaries.

**Dependencies:** UTY-M0-01

**Acceptance criteria:**
1. Existing registration and authentication tests run before extension work.
2. Website human grants are distinguished from external service-account rights.
3. Required extensions identify actual APIs/classes rather than invented prototype names.

**Required evidence:** Contract map, local authorization trace and SDK compatibility checklist.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M0-04 - Inventory integration work and go-live dependencies

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep unknown and already-completed enterprise work visible without assuming either.

**Implementation scope:** Inventory Channel Secure, Apigee, Splunk, AutoSys, NAS, cron and other pilot dependencies; collect optional existing Jira links.

**Dependencies:** UTY-M0-01

**Acceptance criteria:**
1. Each dependency has a named owner or Owner TBD and evidence-based state.
2. DEV/UAT/PROD requirements are separate; no fictitious TEST environment appears.
3. Unverified Kafka retention and ambiguous NAS ownership are explicitly flagged.

**Required evidence:** Integration register accepted by responsible owners; existing ticket mapping when supplied.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M0-05 - Characterize legacy behavior and imported model readiness

**Owning milestone:** M0. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use Devin's existing extraction as input while proving what is executable.

**Implementation scope:** Choose one legacy CyberArk process and Policy Drift email path; inventory rules, side effects, defaults, failures and generated BPMN.

**Dependencies:** UTY-M0-01, UTY-M0-02

**Acceptance criteria:**
1. Source behavior and BPMN/AMIE activities are traceable with documented omissions.
2. Expected success, no-change, reject and uncertain-write cases have fixtures.
3. A percentage of migration completion is not reported without an explicit denominator and evidence.

**Required evidence:** Characterization test suite, rule/process crosswalk and partial-readiness report.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M1 - Capability foundation: CyberArk and Email

**Objective:** One generic SDK/registry contract makes existing technical functions reusable in code, embedded BOB and central workflows.
**Milestone acceptance:** Both services expose approved typed operations and a second workflow reuses an unchanged implementation.

### UTY-M1-01 - Extend the generic operation descriptor and SDK

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Expose existing compiled handlers with minimal Unity-specific boilerplate.

**Implementation scope:** Add only missing typed input/output, semantic identity, side effect, host, error and version metadata; retain existing DI registration.

**Dependencies:** UTY-M0-03

**Acceptance criteria:**
1. Duplicate operation/version registrations fail deterministically.
2. The same descriptor drives discovery, forms, bindings and handler lookup.
3. No arbitrary CLR names, scripts, unrestricted HTTP or SQL are accepted from workflow configuration.

**Required evidence:** SDK unit/component tests, example handler and generated descriptor comparison.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-02 - Implement trusted registration, maturity and activation

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Make discovery automatic without making it authorization.

**Implementation scope:** Persist reviewed manifests, operation versions, Experimental/NonProd/Approved classification, stage and independent environment activation.

**Dependencies:** UTY-M1-01

**Acceptance criteria:**
1. A discovered operation cannot execute merely because it registered.
2. An Approved parent cannot promote an Experimental child operation.
3. A new InDev version does not change the currently active published version.

**Required evidence:** Registry lifecycle/API tests, privilege-negative tests and immutable audit evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-03 - Expose CyberArk Get Account with safe authentication reuse

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prove the first reusable CyberArk operation end-to-end.

**Implementation scope:** Wrap the existing approved client and rotating-credential/session provider; distinguish account lookup from paginated account search.

**Dependencies:** UTY-M1-01, UTY-M0-04

**Acceptance criteria:**
1. A valid authorized account ID resolves to the declared account model.
2. NotFound, denied, transport failure and invalid schema remain distinct outcomes.
3. Credentials and secrets are absent from descriptors, Kafka business payloads, fixture exports and logs.

**Required evidence:** Adapter tests using mocks plus approved DEV connection evidence when available.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-04 - Expose custom-field PATCH and onboarding metadata

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Provide the operations needed for update and create scenarios without scenario-specific handlers.

**Implementation scope:** Bind actual installed CyberArk PATCH contracts, allowed paths, Safe/Platform lookup and platform-dependent account-create requirements.

**Dependencies:** UTY-M1-03

**Acceptance criteria:**
1. Only requested permitted changed properties are written; unspecified properties are not cleared.
2. Blank/null/removal behavior is explicit and technical allowlists cannot be bypassed by AMIE.
3. Create Account shows unmet Safe/Platform and conditional properties; lookup selections are never silently guessed.

**Required evidence:** Payload fixtures, allowed-field negatives, create-contract tests and uncertain-write reconciliation trace.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-05 - Extract the reusable Email operation

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Reuse Policy Drift's email behavior as a second capability.

**Implementation scope:** Extract transport/HTML/attachment functions without importing Policy Drift decisions into the generic email handler.

**Dependencies:** UTY-M1-01, UTY-M0-05

**Acceptance criteria:**
1. Two different workflows send sanitized report content through the same handler.
2. SMTP accepted, delivered if evidenced, failed and unknown remain distinct.
3. A retry cannot silently duplicate an uncertain send; attachment references and recipient policies are authorized.

**Required evidence:** Existing-email parity fixtures, descriptor tests and safe duplicate/timeout tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M1-06 - Support capability-owned workflows and language-neutral onboarding

**Owning milestone:** M1. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep L2 local composition and future enterprise API reuse generic.

**Implementation scope:** Expose service-owned workflow contracts and approved adapter/OpenAPI candidate path; document non-.NET registration without promising every language SDK.

**Dependencies:** UTY-M1-01, UTY-M1-02

**Acceptance criteria:**
1. The local handler and same BOB core can be used without a central call per step.
2. OpenAPI discovery produces reviewable candidates, not inferred retry or authorization policies.
3. Capability -> API group/controller -> operation browsing and L2 ownership are consistent across code and catalog.

**Required evidence:** C# local example, language-neutral contract fixture and second-service descriptor proof.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M2 - BOB, AMIE and execution guarantees

**Objective:** Implement missing approved runtime behavior without replacing working BOB or AMIE.
**Milestone acceptance:** Shared-host regression, durability, boundary, approval and authorization evidence passes for the pilot scope.

### UTY-M2-01 - Reconcile BPMN compiler and shared host execution

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep one interpreter and the expanded approved Phase 1 scope.

**Implementation scope:** Extend typed bindings, operation/rule/subprocess references and host adapters; preserve IDs, scopes and immutable versions.

**Dependencies:** UTY-M0-01, UTY-M1-01

**Acceptance criteria:**
1. Central and embedded conformance fixtures agree on supported semantics.
2. Unsupported executable constructs are diagnosed before execution rather than treated as pass-through.
3. Local compiled handlers stay in their owning service, not copied into central BOB.

**Required evidence:** Compiler fixtures, host conformance report and reference-resolution tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-02 - Implement parallel tokens and durable joins

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Run independent work concurrently and join it once.

**Implementation scope:** Use activation-scoped tokens and transactionally persisted split/join state, with conflict-safe branch outcomes.

**Dependencies:** UTY-M2-01

**Acceptance criteria:**
1. A duplicate branch outcome cannot advance the join twice.
2. Restart after partial completion preserves remaining branch waits.
3. A failed/interrupted branch has an explicit join consequence and cannot leave an unexplained wait.

**Required evidence:** Parallel race, crash/restart, duplicate and nested-scope tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-03 - Implement intermediate and interrupting boundary timers

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Make waiting and deadlines durable, including external uncertainty.

**Implementation scope:** Persist due time, ownership/leases and atomic completion-vs-timeout resolution; retain original activity/correlation identity.

**Dependencies:** UTY-M2-01

**Acceptance criteria:**
1. Restart resumes an overdue timer once.
2. Timeout winning blocks the normal continuation; late external results remain auditable.
3. Interrupting a task is not represented as proof of cancelling an external CyberArk call.

**Required evidence:** Clock-controlled tests, completion/timer race and late-outcome evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-04 - Implement typed error boundaries and propagation

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Route modeled business errors without swallowing technical failures.

**Implementation scope:** Define operation outcome-to-error mapping, scoped matching and propagation across supported calls/subprocesses.

**Dependencies:** UTY-M2-01

**Acceptance criteria:**
1. A matching error takes its handler and does not also continue normally.
2. An unmatched error surfaces a classified incident or parent propagation.
3. Authorization failures cannot be converted into unconditional success by a generic catch.

**Required evidence:** Boundary match/non-match, nested propagation and security-negative fixtures.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-05 - Complete Kafka durability and recovery contracts

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prevent message loss and duplicate logical progression across services.

**Implementation scope:** Use existing outbox/inbox with command, attempt, correlation and idempotency identities; checkpoint waits before publish.

**Dependencies:** UTY-M2-01

**Acceptance criteria:**
1. Crash at each commit/publish boundary recovers without lost pending work.
2. Redelivery reuses a recorded outcome or waits on the original execution.
3. Unknown external write outcomes reconcile before repeat; pause/cancel/restart preserve pinned definitions.

**Required evidence:** Failure injection, dedupe replay, outbox lag and operator lifecycle tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-06 - Bind existing AMIE for local and central decisions

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use AMIE for decisions and mappings without another evaluator.

**Implementation scope:** Add typed fact/result adapter, native artifact reference and local approved definition cache as supported by existing implementation.

**Dependencies:** UTY-M0-02, UTY-M2-01

**Acceptance criteria:**
1. A business-rule task receives the expected snapshot and returns typed results.
2. A rule inserted in a mapping executes exactly once as its visible task.
3. Newly published rules cannot alter an already pinned running instance.

**Required evidence:** Native AMIE adapter tests, task trace and version-coexistence proof.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-07 - Implement durable multilevel approvals and backups

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Execute AMIE-defined approval plans through BOB human tasks.

**Implementation scope:** Use ordered any-one/all-required stages, eligibility and backup groups, reasoned rejection, timeout and concurrent-decision controls.

**Dependencies:** UTY-M2-06, UTY-M2-05

**Acceptance criteria:**
1. Concurrent responses cannot complete a stage twice.
2. Only eligible current principals can decide; a creator cannot self-approve when policy forbids it.
3. Restart preserves pending tasks and backup eligibility without inventing delegation policy.

**Required evidence:** Approval state-machine tests, RBAC negatives and BE decision evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M2-08 - Enforce workflow and capability-administration grants

**Owning milestone:** M2. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep human website access separate from service identities.

**Implementation scope:** Reuse groups/AMIE policies for Read, Execute, Execute-Lead, Create and explicit admin/approval/release permissions.

**Dependencies:** UTY-M0-03, UTY-M1-02

**Acceptance criteria:**
1. Execute-Lead sees only permitted group results; guessed record IDs do not widen access.
2. Create does not grant production activation or capability registration.
3. The capability validates trusted command admission without requiring external departments to manage every Unity user.

**Required evidence:** API/data-filter tests and end-to-end authorization decisions with audit.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M3 - Studio, source contracts and data intelligence

**Objective:** Make the approved authoring journey work end-to-end against actual adapters, not just the offline demo.
**Milestone acceptance:** An author maps a sample source, inserts a lookup/rule, tests two outcomes and round-trips the same workflow artifact without losing data.

### UTY-M3-01 - Implement compatible XML profile and partial-readiness import

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Preserve models while making incomplete imports actionable.

**Implementation scope:** Reconcile proposed extensions against existing serializers, retain standard DI and native AMIE artifacts, and separate editable/quarantined/executable states.

**Dependencies:** UTY-M0-02, UTY-M2-01

**Acceptance criteria:**
1. Supported export/import retains IDs, structure, mappings, categories, launch bindings and rule references.
2. Unknown content is preserved or explicitly quarantined, never silently dropped.
3. An unbound task loads as a draft with a clickable blocker; malicious DTD/external entities are rejected.

**Required evidence:** Official BPMN and Unity XSD results, native serializer proof and positive/negative round-trip corpus.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-02 - Implement universal schema and safe sample importer

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Create contracts from samples without letting inference silently redefine business meaning.

**Implementation scope:** Build one nested field editor shared by entry and ingestion; paste/upload CSV, JSON and supported Avro schema; preview merge/targets and locks.

**Dependencies:** UTY-M3-01

**Acceptance criteria:**
1. Quoted CSV, leading-zero IDs, nullable values and nested objects produce editable candidate fields.
2. Re-import preserves locked IDs/types/validation and appends new fields only after review.
3. Renames retain stable field identity; required/nullable/default are distinct; ambiguous arrays/unions are diagnosed.

**Required evidence:** Parser fixtures, merge diff, field-edit tests and sample data redaction tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-03 - Implement per-source setup and shared contract bindings

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Configure transport once without duplicating field-definition systems.

**Implementation scope:** Implement two tabs and on-demand overlays for all six source types; keep schema shared and extraction bindings adapter-specific.

**Dependencies:** UTY-M3-02

**Acceptance criteria:**
1. Kafka and CSV adapters target the same field IDs with different source paths.
2. Changing transport preserves the shared contract and identifies invalid old bindings.
3. Correlation, dedupe, decoding, gate and subscription each have distinct configuration and validation.

**Required evidence:** Guided source walkthroughs, normalized record fixtures and adapter-negative tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-04 - Implement scheduled context and ingestion task handoff

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Introduce business data only when ingestion produces it.

**Implementation scope:** Use run context/static parameters for AutoSys/cron, typed path/URL bindings and approved file/data/API capabilities with explicit per-row/batch outputs.

**Dependencies:** UTY-M3-03, UTY-M1-01

**Acceptance criteria:**
1. The scheduled start has no invented account payload.
2. A downstream rule cannot reference ingestion output before successful ingestion.
3. No-file, parse-error, partial-row and retry outcomes are distinguishable and visible.

**Required evidence:** Scheduler-context fixtures, row/batch cardinality tests and lineage screenshot/trace.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-05 - Implement typed resolver and one-click producer insertion

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Help users satisfy missing data without guessing execution or identity.

**Implementation scope:** Analyze required fields, guaranteed sources, semantic IDs, nullability, collection cardinality, freshness, scope and allowed hosts.

**Dependencies:** UTY-M3-01, UTY-M1-03, UTY-M2-01

**Acceptance criteria:**
1. Missing currentAccount offers eligible existing data first, then Add Get Account and Connect when unambiguous.
2. Insertion/mappings/control-flow change is atomic and one undo unit; deleting producer invalidates dependents.
3. Stale pre-write data, alternate-branch data and wrong account/vault identities are rejected.

**Required evidence:** One-click positive/negative suite, branch/loop/parallel dataflow analysis and bounded suggestion-cycle tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-06 - Implement editable contextual BPMN/data/rule depth

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep the useful existing builder while making deeper views genuinely editable.

**Implementation scope:** Retain guided/BPMN perspective, highlighted breadcrumb context, object/field selection, whole-object overrides, rule chooser and common history.

**Dependencies:** UTY-M3-05, UTY-M2-06

**Acceptance criteria:**
1. The same mapping changes in Process, Data and Rule perspectives without copying configuration.
2. Three-dot/right-click menus, replacement/removal and Undo/Redo continue working.
3. Inserting a field rule creates one visible BPMN Business Rule Task; shared AMIE rules are not mutated without explicit new drafts.

**Required evidence:** Inherited browser regression plus typed rule-insertion and serialization tests in both themes.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-07 - Implement catalogs, categories, inline step menu and help

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Make authoring discoverable without another maze of screens.

**Implementation scope:** Use multi-category workflows, service/API-group operation browsing, rule usage/dependency indicators, intent-first inline plus and contextual detailed pickers.

**Dependencies:** UTY-M1-02, UTY-M3-06

**Acceptance criteria:**
1. No mandatory owning Application/Business Space is required to create a reusable workflow.
2. A routing gateway cannot hide a capability call.
3. Every offered BPMN element has a description and separate modeling/runtime/environment support indicators.

**Required evidence:** Author walkthrough from blank draft to test, catalog filter tests and capability-boundary UI assertions.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M3-08 - Implement readiness, fixture testing and native artifact import

**Owning milestone:** M3. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Let authors see what is missing and test without confusing fixtures with production.

**Implementation scope:** Build clickable source/model/binding/runtime/release diagnostics, safe native artifact inspection and sample-driven execution through actual test adapters.

**Dependencies:** UTY-M3-03, UTY-M3-06

**Acceptance criteria:**
1. Unresolved input diagnostics identify the exact activity/field and suggested remedy.
2. Native syntax validity is not displayed as evaluator acceptance.
3. Successful local tests do not enable production publishing or mark integration stories accepted.

**Required evidence:** Readiness-negative suite, mock-vs-live labeling tests and source-to-rule outcome trace.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M4 - Business operations, observability and reusable testing

**Objective:** Give users, approvers and operators separate understandable views of durable execution.
**Milestone acceptance:** Business access is scoped server-side; operators can diagnose and safely recover a run using durable evidence beyond broker retention.

### UTY-M4-01 - Implement business portal, work queue and approver views

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Give business users useful status without exposing engineering complexity.

**Implementation scope:** Expose permitted process names, jobs/counts/reports, scoped group views and separate actionable My Approvals.

**Dependencies:** UTY-M2-07, UTY-M2-08

**Acceptance criteria:**
1. Portal queries enforce scope on the server including exports.
2. My Approvals shows pending tasks, not workflow-authoring controls.
3. Stuck/unknown/partial states are distinct from completed success.

**Required evidence:** Portal API/UI tests, approval journey and scoped report evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M4-02 - Implement durable audit and run projections

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep trustworthy evidence independent of Kafka retention.

**Implementation scope:** Write append-only audit through approved owner service with indexed IDs plus redacted JSON details; transactionally record lifecycle/outcomes.

**Dependencies:** UTY-M2-05, UTY-M2-08

**Acceptance criteria:**
1. Audit begins at admission and remains queryable after broker messages expire.
2. Retention is environment policy, not a hardcoded four-day assumption.
3. Secrets, raw credential responses and unapproved sample data are excluded even if a designer selects them.

**Required evidence:** Audit persistence/recovery/redaction tests, retention policy confirmation and projection consistency tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M4-03 - Implement safe operations and failure diagnosis

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Allow support to explain and recover failures without duplicating side effects.

**Implementation scope:** Show activity/attempt/rule/operation identities, timeout/retry status and redacted records; expose only supported recovery commands.

**Dependencies:** UTY-M4-02, UTY-M2-05

**Acceptance criteria:**
1. Restart creates an audited new run with approved inputs; a UI flag alone is insufficient authority.
2. Unknown PATCH/SMTP outcomes cannot be blindly replayed.
3. Kafka retention is shown only from verified configuration, not an invented countdown.

**Required evidence:** Operator command authorization tests, reconciliation demonstration and incident runbook.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M4-04 - Implement API capability workbench and reusable recipes

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Test approved APIs, chains and CSV cases without redeploying for each payload change.

**Implementation scope:** Reuse operation contracts, secure credential references, source mappings and local BOB recipes; capture sanitized request/response/assertions.

**Dependencies:** UTY-M1-03, UTY-M1-05, UTY-M3-02

**Acceptance criteria:**
1. An author changes a permitted payload or chain and retests without compiling a new service.
2. Credential acquisition is reused internally, not pasted into steps or outputs.
3. Promoting a recipe uses the same workflow/mapping model and validates approved operations.

**Required evidence:** Workbench end-to-end fixture, secret-redaction tests and recipe-expansion diff.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M4-05 - Implement comparison/diff, configuration guides and drift foundations

**Owning milestone:** M4. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Make configuration changes understandable and prepare later drift alerts.

**Implementation scope:** Add before/after diff, stable resource digests, links to approval/release, and user guides tied to actual controls.

**Dependencies:** UTY-M4-02, UTY-M3-07

**Acceptance criteria:**
1. A group, rule, capability or published workflow change records actor/scope/versions and reason.
2. Audit baseline events exist without claiming full automated drift detection.
3. Guide screenshots and exact controls match the accepted UI journeys.

**Required evidence:** Change evidence fixture, guide walkthrough and baseline event contract tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M5 - Enterprise integration and controlled promotion

**Objective:** Finish the required enterprise dependencies and DEV -> UAT -> PROD release path.
**Milestone acceptance:** Each integration is verified or explicitly not required for the selected pilot; no unaccepted production blocker remains.

### UTY-M5-01 - INT-CHSEC: integrate Channel Secure SSO and entitlements

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Complete the required enterprise identity boundary before go-live.

**Implementation scope:** Reuse Matthew's current auth while connecting approved SAML/entitlement contracts and verifying environment-specific groups.

**Dependencies:** UTY-M0-04, UTY-M2-08

**Acceptance criteria:**
1. Issued identities/groups resolve through the same authorization service.
2. Production excludes NonProd grants; expiry/revocation behavior is tested.
3. Unknown enterprise details remain blocked dependencies, not guessed code.

**Required evidence:** Owner-approved integration evidence, SSO/session tests and production-group negative tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-02 - INT-APIGEE: onboard gateway and service identities

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Enable approved external API calls through required gateway controls.

**Implementation scope:** Confirm route, token/certificate, policy, rate/timeout and service-account configuration per environment.

**Dependencies:** UTY-M0-04, UTY-M1-03

**Acceptance criteria:**
1. The capability uses the approved service identity and declared operations.
2. No end-user group provisioning is pushed into every department API.
3. Gateway errors retain safe typed classification and correlation.

**Required evidence:** Gateway owner signoff, authorized DEV/UAT calls and deny/rate-limit tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-03 - INT-SPLUNK: connect approved telemetry sinks

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Expose diagnosable, redacted execution evidence to enterprise monitoring.

**Implementation scope:** Confirm log fields, transport, dashboards/alerts, indexing, retention and correlation across central/embedded execution.

**Dependencies:** UTY-M0-04, UTY-M4-02

**Acceptance criteria:**
1. A pilot run can be traced across BOB, capability and outcome without secrets.
2. Logging failure behavior does not silently discard required audit.
3. Alert thresholds and ownership are verified rather than invented.

**Required evidence:** Splunk ingestion/query evidence, redaction tests and support owner approval.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-04 - INT-AUTOSYS: scheduler trigger integration

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use externally owned schedules without turning BOB into the AutoSys scheduler.

**Implementation scope:** Confirm job/box identity, trusted trigger adapter, scheduled occurrence, retry identity and outcome reporting.

**Dependencies:** UTY-M0-04, UTY-M3-04

**Acceptance criteria:**
1. One scheduled occurrence creates one logical run despite redelivery.
2. Run metadata normalizes to the agreed context and feeds ingestion bindings.
3. The original scheduled time survives late arrival/retry; caller identity is verified.

**Required evidence:** Job invocation and duplicate tests plus scheduler ownership signoff.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-05 - INT-CRON: controlled scheduled trigger integration

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Provide cron-trigger behavior without duplicate schedule ownership.

**Implementation scope:** Confirm approved scheduler runtime, timezone/DST, overlap/misfire policy, identity and monitoring.

**Dependencies:** UTY-M0-04, UTY-M3-04

**Acceptance criteria:**
1. Schedule ownership is declared outside the workflow unless explicitly approved otherwise.
2. Duplicate/overlapping executions obey the selected admission policy.
3. Context-only starts introduce no fictitious business payload.

**Required evidence:** Scheduled occurrence fixtures, timezone tests and operational ownership evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-06 - INT-NAS: staged files and owner-mediated data access

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Connect real staging/ingestion without unauthorized file or database access.

**Implementation scope:** Confirm what NAS denotes here, approved roots and owning data APIs; implement file readiness, row identity and result persistence.

**Dependencies:** UTY-M0-04, UTY-M3-04

**Acceptance criteria:**
1. Staged file/row references resolve only through the authorized owner.
2. Incomplete files, duplicate imports and invalid rows have explicit outcomes.
3. No arbitrary SQL/private-table bypass is exposed by a generic dropdown.

**Required evidence:** Owner contract, approved UAT import, file/row dedupe and path traversal tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-07 - Build immutable packages and trusted validation

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Promote the tested definition and dependencies as one controlled unit.

**Implementation scope:** Package BPMN/DI/extensions, native AMIE, pinned operation dependencies, schema manifests and evidence; use approved signing/trust.

**Dependencies:** UTY-M3-01, UTY-M4-02

**Acceptance criteria:**
1. Altered content, unknown signer, missing dependency and unsupported feature are rejected.
2. Private signing keys and execution secrets are not embedded in XML or ZIP.
3. Unverified native AMIE serialization or runtime support blocks activation even when XSD passes.

**Required evidence:** Package integrity/signature tests, official schema evidence and dependency resolution report.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-08 - Import environment group/rule configuration and change references

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Roll out real configuration through approved imports rather than fake seeded privileges.

**Implementation scope:** Use migrations for structure and authorized idempotent packages for group references/grants/environment bindings; require production ServiceNow reference.

**Dependencies:** UTY-M5-07, UTY-M2-08

**Acceptance criteria:**
1. Production rejects NonProd group mappings and unexpected privilege increases.
2. A nonempty ServiceNow ID is recorded but not called external approval validation.
3. Import previews changes and does not activate them automatically.

**Required evidence:** DEV/UAT config round-trip, negative prod mappings and audited import diff.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M5-09 - Activate, rollback and verify production readiness

**Owning milestone:** M5. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Separate file upload from authorized production activation.

**Implementation scope:** Implement reviewed staged activation, four-eyes/AMIE controls as applicable, environment bindings, rollback and in-flight version handling.

**Dependencies:** UTY-M5-07, UTY-M5-08

**Acceptance criteria:**
1. A user with Create but no release entitlement cannot activate production.
2. Rollback changes future starts while existing instances retain original versions.
3. Unimplemented experimental features and unverified mandatory integrations block go-live.

**Required evidence:** Activation/rollback tests and signed UAT-to-PROD acceptance evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M6 - Integrated acceptance and production readiness

**Objective:** Prove both pilot services and authoring paths, migration parity, and operational controls in UAT.
**Milestone acceptance:** Business, technical, security and operations acceptance evidence is attached; production activation is separately authorized.

### UTY-M6-01 - Prove CMDB custom-field update end-to-end

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prove the principal data-hydration and update scenario.

**Implementation scope:** CSV -> staging -> normalized per-record message -> Get -> AMIE compare -> partial PATCH -> second Get -> typed row outcome.

**Dependencies:** UTY-M1-04, UTY-M2-05, UTY-M3-05, UTY-M5-06

**Acceptance criteria:**
1. Four desired fields plus Account ID suffice for incoming business data.
2. No-change skips write; changed fields only are patched; post-write mismatch is not reported as success.
3. Redelivery, lookup failure and uncertain PATCH have demonstrated safe results.

**Required evidence:** Integrated DEV/UAT trace with sanitized requests, row identities and actual verification evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M6-02 - Prove account onboarding with conditional requirements

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prove more extensive input contracts and approved lookup composition.

**Implementation scope:** Normalize form/API inputs, select/resolve Safe and Platform, resolve conditional fields, evaluate AMIE and approvals, create and verify.

**Dependencies:** UTY-M1-04, UTY-M3-05, UTY-M2-07

**Acceptance criteria:**
1. Unresolved mandatory platform properties block execution.
2. Lookup collection vs chosen single value is explicit.
3. Approvals and authorization cannot be bypassed through source mapping or a naming rule.

**Required evidence:** Create-account UAT cases, denied/ambiguous/missing-data tests and object lineage.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M6-03 - Prove CyberArk plus Email reuse and native configuration change

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Prove the platform generalizes beyond one API and avoids recompilation for business changes.

**Implementation scope:** Invoke CyberArk local workflow then Email centrally; reuse each primitive in a second process; publish a changed native rule.

**Dependencies:** UTY-M1-05, UTY-M2-06, UTY-M6-01

**Acceptance criteria:**
1. No operation handler is duplicated for the second workflow.
2. A new rule/workflow version changes behavior without recompiling unchanged services.
3. Old running versions and sanitized notification policy remain intact.

**Required evidence:** Two distinct process traces and native configuration-release comparison.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M6-04 - Run usability, security, scale and recovery acceptance

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Judge the complete journey, not the number of screens or test names.

**Implementation scope:** Observe an author completing requirements-to-release preparation; test operational failures and realistic capacity targets agreed with owners.

**Dependencies:** UTY-M3-08, UTY-M4-03, UTY-M5-09

**Acceptance criteria:**
1. Users can go A-to-Z with contextual help and no hidden configuration detours.
2. Cross-group data isolation, unsafe uploads and secret exfiltration are tested.
3. Performance/availability claims state measured environment/load and recovery evidence.

**Required evidence:** Accepted walkthrough, security test report, load profile and failure-injection results.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M6-05 - Accept handoff, guides and go-live checklist

**Owning milestone:** M6. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Close milestones only on accepted evidence and retain the design rationale.

**Implementation scope:** Update current master/Ask/generated files from one source, attach story evidence, verify integration approvals and operational ownership.

**Dependencies:** UTY-M6-01, UTY-M6-02, UTY-M6-03, UTY-M6-04

**Acceptance criteria:**
1. Each active story has accepted evidence or an explicit approved scope change.
2. No unresolved production blocker is hidden by a green demo result.
3. The final team receives one current package with the same decisions, diagrams, source and guides.

**Required evidence:** Megan milestone signoff, operations/go-live approval and package verification report.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

## M7 - Next-phase improvements, not initial-release blockers

**Objective:** Track approved future directions without quietly pulling them into the immediate build.
**Milestone acceptance:** Each improvement is separately scoped and admitted after the initial capability/Studio foundation is verified.

### UTY-M7-01 - Refine overlapping AMIE orchestration after initial release

**Owning milestone:** M7. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Correct any confirmed competing durable orchestration without losing working intake decisions.

**Implementation scope:** Use the deferred Matthew review, characterize state ownership and migrate with parity/rollback.

**Dependencies:** UTY-M0-02, UTY-M6-05

**Acceptance criteria:**
1. The change addresses an observed overlap, not speculation.
2. AMIE classification/enrichment remains valid where needed.
3. Regression and rollback protect existing processes.

**Required evidence:** Approved future decision record and source-level migration tests.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M7-02 - Integrate ServiceNow ticket/approval validation

**Owning milestone:** M7. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Replace reference-only ticket recording with the requested enterprise integration when approved.

**Implementation scope:** Implement a registered capability for ticket status/approval interaction and preserve BOB durable task ownership.

**Dependencies:** UTY-M5-08, UTY-M6-05

**Acceptance criteria:**
1. External status is authenticated and correlated to the exact release/request.
2. Unavailable integration fails according to approved policy.
3. Existing reference-only records retain history and are not retroactively called validated.

**Required evidence:** Approved ServiceNow capability contract and integration test evidence.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M7-03 - Add AI/MCP co-design and approved drift detection

**Owning milestone:** M7. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Use governed model-editing tools and baselines without bypassing human control.

**Implementation scope:** Expose versioned read/plan/validate/propose tools; separately implement baseline comparison alerts for configuration and approved identity events.

**Dependencies:** UTY-M6-05

**Acceptance criteria:**
1. AI proposals use the same atomic commands/compiler/grants as the UI.
2. No tool publishes production merely because its output is schema-valid.
3. Drift alerts distinguish approved baseline changes from unauthorized differences.

**Required evidence:** Future security/tool conformance tests and baseline-alert fixtures.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.

### UTY-M7-04 - Activate deferred BPMN and richer modeling only on demand

**Owning milestone:** M7. **Suggested Jira type:** Story. **Jira key:** To be assigned. **Status:** Not assessed against enterprise repository.

**Objective:** Keep the architecture extensible without bloating the first build.

**Implementation scope:** Consider noninterrupting events, inclusive/event-based gateways, parallel multi-instance, compensation and event subprocesses individually.

**Dependencies:** UTY-M2-01, UTY-M6-05

**Acceptance criteria:**
1. Every activated construct gains compiler/runtime/persistence/designer tests.
2. Experimental visibility never implies executable support.
3. Full UML state machines/XMI or a second runtime require a new explicit decision.

**Required evidence:** Feature-by-feature conformance evidence and compatibility review.

**Preservation / completion:** Reuse verified existing code. Record actual changed paths, native contracts, negative tests and remaining gaps. No independent claim of production readiness.
