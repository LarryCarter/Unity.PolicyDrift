# Demo runbook - WF Unity Complete Handoff v4

## Open and reset

Extract the complete ZIP and open root `START.html`. Choose **Open Modeling Studio**. The prototype is a single self-contained `demo/OPEN.html`; no server, internet, installation, production credentials or service account is required. Use a current desktop Chromium-family browser for the tested path. A browser running the file is required; an attachment preview may not execute scripts or resolve neighboring files.

The initial workflow is **CMDB custom-field enrichment**, selected at **Compare custom fields**. There are two ways to see it: guided step/process view, and contextual Data / Rule / Operation / Full lineage depth. The BPMN strip always identifies the selected activity. The blue source objects, purple rules and teal destination inputs use text labels as well as color. Theme changes do not change workflow logic.

The prototype persists local drafts in browser storage. Use **Demo guide -> Reset sample workflow** for a known clean fixture. When a host/browser policy does not permit storage, the current in-memory demo still works but reload may reset it. Export a draft/BPMN before deliberately resetting work you want to retain. Do not paste real secrets or production payloads into the demo.

## Presenter opening

> Unity is a visual programming environment built around existing reusable API operations. CyberArk and Email are our first capabilities. BOB supplies execution structure, AMIE supplies business decisions, and the Studio shows the same workflow at process, object, field and rule levels. What I am showing today is the working offline interaction model. Enterprise integration and production readiness are tracked separately.

Do not call the local fixtures live CyberArk or native AMIE. Do not claim an XSD alone proves process execution. Do not claim the source audit is complete.

## Journey 1 - Preserve the useful editor and show an editable rule in the data flow

1. Open the Studio at **Compare custom fields**. Point to the BPMN context strip and the source/current-account/desired-field objects.
2. Expand **desired** if necessary. On the target **Owner** field choose the three-dot menu, or right-click, then **Insert / replace data rule**.
3. In the larger rule chooser select **Normalize text**, inspect its input/output and description, and choose **Insert and connect rule**.
4. Show that the purple mapping rule also appears as a Business Rule Task in the BPMN strip. It is the same activity, not a second hidden rule engine.
5. Open that rule, change its trimming/case parameters, preview a sample and save the workflow-local draft. This changes the fixture rule occurrence, not an approved shared native rule.
6. Use Undo/Redo. The task insertion, control links and field mapping move together as one operation. Return to the data view or full BPMN without losing the selected workflow.

Explain: the author can map a whole object and override one field; changing Owner does not require reentering all other custom-field mappings. Invalid source/target types are rejected rather than silently coerced.

## Journey 2 - A missing account object is a resolvable dependency

1. In the BPMN context select **Get current account**. Use its step actions to remove the workflow occurrence, confirming the impact. This does not remove the CyberArk capability from the registry.
2. Return to **Compare custom fields**. Current account becomes unresolved because its producing activity disappeared.
3. Use **Add Get Account and Connect** when offered. The prototype inserts the lookup before Compare, maps the known request Account ID and connects the account result.
4. Show the updated BPMN context and mapping source. Use Undo/Redo once to demonstrate it is one edit.

Explain: this button edits the draft; it does not call an API. The full backend resolver must additionally enforce environment, target/vault identity, freshness, authorization and graph scope. In particular, a pre-update GET is not a substitute for the second verification GET.

## Journey 3 - Source setup is distinct from the shared contract

Reset the sample workflow before this journey if prior edits left intentional warnings.

1. Choose **Entry setup** in the canvas toolbar. On **Trigger**, show Kafka topic/group/decoder and the separate gate, correlation and deduplication fields. There is no raw sample box or schema grid cluttering this tab.
2. Choose **+ Add launch binding**. The demo adds a CSV adapter. The same contract fields and their stable identities remain; it does not create a separate copy of the business model.
3. Choose **Data contract**, then **Paste / upload sample**. In the overlay choose **Load example**, then **Infer fields**.
4. Inspect the five columns and suggested targets: Account ID plus Owner, BusinessUnit, CostCenter and Application. Change a target before applying when desired. Inference is a prefill, not a declaration that sample values prove production types or requiredness.
5. Choose **Apply reviewed fields**. The CSV column mappings target the existing nested desired object. Select a field row to show type, required/nullable, validation and source binding in the Field Detail overlay.
6. Lock a reviewed field, paste an updated sample with an additional optional column and apply. The locked definition is preserved; new reviewed columns can be added. A field absent in a new sample is not silently deleted.
7. Use the normalized sample preview to show that a flat CSV becomes the same nested input object consumed by the workflow. Then choose **Use first sample in test**.

Useful supplied samples are in `demo/samples/`. The exact sample parser supports the bounded cases in QA; complicated Avro unions and unconfigured array item models are diagnosed, not invented. The user's Source path, auth and topic values are fixture configuration only.

## Journey 4 - Test both business outcomes and explain operational views

1. In **Test**, choose **Run local fixture**. It reads the current draft and mapped sample, not a fixed success banner.
2. With the untrimmed Owner example, Compare can produce a change. Adding the trim rule can produce **No change** against the sample current-account value. A deliberate different desired field produces a simulated update and second GET.
3. Use the explicit verification-mismatch option to show why a successful update transport result is not sufficient business verification.
4. Open **Business portal**. It shows the recorded local fixture run and business-oriented state without BPMN editing controls.
5. Open **Ops diagnostics**. It shows the same run's step trace and redacted local audit JSON, with live restart/replay disabled.

Explain: real server RBAC, durable SQL projections, Splunk and recovery are separate milestone work. Switching prototype views is not security enforcement. No fake Kafka expiry countdown is displayed.

## Journey 5 - Scheduler context enters before business data

1. Open **Entry setup** and choose **Load scheduled-ingestion example** from the demo guide or scheduler panel.
2. Show the AutoSys adapter and **Run context**: the initial request has scheduled date/run identity, not a fictitious account CSV payload.
3. Return to the process. **Ingest Daily CSV** is an explicit first operation. It introduces a typed business record. Get Account binds `ingest` output Account ID, not an imaginary initial field.
4. Run the scheduled local fixture. Show the trace ordering: ingestion precedes account read and rule evaluation.

Explain: this is a one-record simulation. Production ingestion must handle file readiness, row identity, validation, paging/batch policy and actual approved data-owner access. AutoSys/cron still own their schedule mechanics unless a separate decision changes that.

## Journey 6 - Canonical BPMN and native rules, not JSON-only workflows

1. Open **File** in the canvas toolbar. Choose BPMN export and save the file.
2. Reimport that supported-profile file and confirm preserved activities, mappings, source settings and diagram information. The package also includes actual exported examples for review.
3. Show **Preserve native AMIE artifact (XML or JSON)**. The demo can preserve a supplied artifact without translating its language. Parsing syntax is not AMIE evaluation or approval.
4. Show Release: production activation remains blocked. Explain the real path: validate dependencies, native artifacts and schemas; approve; export a trusted immutable package; import into UAT; authorized production import/activation with ServiceNow reference initially; keep running versions pinned.

Do not present native AMIE JSON as settled. The supplied v4 draft and prior XML discussion conflict; Matthew's current working implementation is authoritative after source verification. The demo does not change it.

## Capability provider part of the demo

Return to root `START.html` and open **Capability Studio**. This retains the prior provider onboarding prototype so the team can discuss Connect -> Expose operations -> Local BOB/AMIE -> Test/review for CyberArk and Email. It is a provider-contract design reference, not a second workflow engine and not evidence that registration is deployed.

Explain that the SDK registers approved descriptors and generated schemas, not arbitrary downloaded code. Registration is separate from approval/maturity/environment activation. Most users consume the operation through a workflow; the external department grants the service identity access, not per-Unity-user permissions to every endpoint.

## Presenter close

> The important result is one coherent authoring model. Existing API calls become reusable instructions, rules and workflows define business behavior, and data requirements are visible and resolvable without forcing all information into the incoming message. We have an executable offline interaction demo and a complete implementation handoff. The outstanding register identifies which real contracts, integrations and safety guarantees still require evidence.

## Recovery during the presentation

If an action is intentionally invalid, leave the diagnostic visible and explain it; do not hide a legitimate blocker. Use Undo for local edits or Reset sample workflow for a clean example. If browser policy prevents neighboring HTML navigation, open the desired extracted file directly. The single-file Studio itself requires no external assets. Screenshots provide a fallback only, not proof that a nonworking action succeeded.

This runbook is a demonstration sequence, not a time estimate or a guarantee of an enterprise rollout schedule.
