# Outstanding work and demo-readiness register

**Date:** 2026-11-20. **Scope:** Complete current Unity implementation handoff plus an offline review demo. This register separates demonstrable behavior from enterprise work whose implementation status has not been inspected. An item listed here may already exist in the user's repositories; **verify before rebuilding**.

## The practical answer

The demo can show the central experience: one workflow; contextual BPMN, data and rule editing; source-specific configuration separate from the shared schema; CSV/JSON/Avro schema candidates; locked-field preservation; lookup-assisted hydration; local test traces; and native artifact preservation. It does not call CyberArk, Email, Kafka, AMIE, AutoSys or any bank infrastructure. It does not activate production.

The biggest remaining implementation risks are actual **native AMIE compatibility**, **BOB runtime/compiler integration**, **trusted capability registration and API behavior**, **server authorization**, and **enterprise release/integration controls**. The source audit determines how much of each is already complete. Neither the existence of a polished prototype nor the new story list means those systems must be rebuilt.

## A. Available for the demo

| Area | Evidence delivered | Boundary to say aloud |
|---|---|---|
| Existing editable BPMN/data/rule context | Re-run inherited 48-check browser suite | Structured local fixture profile, not complete BPMN engine conformance |
| Two-tab entry inspector | New source configuration and contract editor | Transport settings are saved locally, not registered on infrastructure |
| Paste/upload sample workflow | CSV/JSON/Avro schema candidate parsing and review | Bounded supported formats; not all schema dialects or production file sizes |
| Locked fields and per-adapter mappings | Shared field IDs survive re-import and source changes | Full schema evolution and registry migration remain production work |
| Scheduler example | Run context -> explicit ingestion -> business record -> Get Account | One row is simulated; no real file watcher or scheduler |
| Data-rule insertion | Visible AMIE task plus mapped field and shared Undo/Redo | Local fixture evaluator only, not Matthew's rule engine |
| Test, business portal and Ops | Same local run trace, counts and redacted audit preview | Persona navigation is not RBAC; no durable SQL/Splunk persistence |
| BPMN export/import | Example XML with native BPMN/DI and tested Unity extension profile | General unknown-content editing, official BPMN validation and native AMIE acceptance are separate gates |
| Capability Studio | Prior onboarding/configuration prototype, connected by navigation | Registry, approvals and service identities are illustrative |

**Use the QA report for exact current counts.** Sample XML and browser tests prove only the layers they actually test.

## B. Source-verification blockers before production implementation

| ID | Outstanding verification | Why it matters | Evidence required | Story / proposed owner |
|---|---|---|---|---|
| O-01 | Existing repository paths, interfaces, versions and regression suite | Prevent a speculative rewrite of working functionality | Source map and baseline build/tests | UTY-M0-01 / platform lead + Devin |
| O-02 | AMIE XML versus JSON, actual native editor/evaluator/serializer | The supplied v4 draft says JSON; earlier discussion says XML. Neither is verified here | Real rule, serializer round-trip and evaluator parity | UTY-M0-02 / Matthew |
| O-03 | Existing BOB compiler, shared runtime, persistence and Phase 1 support | A smaller demo must not shrink the approved runtime scope | Compiler/host behavior and feature evidence | UTY-M0-01, UTY-M2-01 / BOB owner |
| O-04 | Existing SDK, local auth/groups and operation descriptors | Reuse the implemented patterns rather than introduce parallel APIs | Descriptor, admission and auth traces | UTY-M0-03 / SDK and BE owners |
| O-05 | Actual CyberArk installed API, wrapper, authentication and custom fields | Public API research is not an installed contract | Sanitized installed API/schema export and wrapper fixtures | UTY-M1-03, UTY-M1-04 / CyberArk owner |
| O-06 | Actual Policy Drift Email implementation and SMTP outcome semantics | Preserve behavior and avoid duplicate uncertain sends | Source extraction plus existing mail regression | UTY-M1-05 / Email/Policy Drift owner |
| O-07 | Existing generated legacy BPMN and extracted rules | Reuse prior work but establish what can execute | Artifact readiness and behavioral characterization | UTY-M0-05 / application owner |

These are missing evidence, not evidence that the corresponding code is missing. No new production interface should be frozen until these checks are completed.

## C. Production implementation and acceptance still required

| ID | Work remaining to verify/complete | Current demo contribution | Acceptance gate |
|---|---|---|---|
| O-08 | Native BPMN compiler semantics: scopes, parallel joins, loops, timer/error races, durable human tasks | Illustrative supported-profile diagrams and tests | UTY-M2-01 through 07, live crash/race evidence |
| O-09 | Full Data Contract Resolver for arbitrary supported graphs | Structured sequential/branch fixture checks and one-click examples | UTY-M3-05: identity, branch, iteration, nullability and freshness tests |
| O-10 | Production source adapters and ingestion | Configuration and sample normalization UI | UTY-M3-03/04 and integration owner tests |
| O-11 | Comprehensive schema/model editor | Nested field grid, source bindings and safe sample merge | UTY-M3-02: arrays/item models, enum/range/default semantics, format variants and migrations |
| O-12 | General preservation-capable importer | Known-profile round-trip; unsupported input preserved/rejected rather than flattened | UTY-M3-01: supported editing and quarantined unknown data fixtures |
| O-13 | Official BPMN 2.0.2 XSD validation | Unity schemas and reference checks only | Approved official local schema bundle; run the supplied validation option |
| O-14 | Actual Blazor components and backend atomic commands | Working HTML interaction contracts | UTY-M3-06/07/08: native components + optimistic concurrency + API enforcement |
| O-15 | Trusted manifest registration, lifecycle and active environments | Capability registration concept | UTY-M1-01/02/06: source-backed SDK/service tests |
| O-16 | Server-enforced permissions, group result filtering and approval decisions | Persona views and policy design | UTY-M2-07/08, UTY-M4-01: direct API negative tests |
| O-17 | Durable inbox/outbox, external uncertainty and safe interventions | Fixture outcomes, visible blocked restart/replay | UTY-M2-05, UTY-M4-03: failure/reconciliation evidence |
| O-18 | Append-only audit persistence, run projections and telemetry | Redacted local audit preview | UTY-M4-02 and UTY-M5-03: database/monitoring evidence beyond broker retention |
| O-19 | Actual signed release/configuration import, approvals and activation | Blocked production screen and complete contract | UTY-M5-07/08/09: tamper, privilege, dependency and rollback tests |
| O-20 | Generalized deploy-once API workbench | Source/mapping/fixture pieces reusable | UTY-M4-04: live approved payload/chain/credential-reference tests |
| O-21 | Actual usability/accessibility/performance validation | Browser interaction, dark/light and narrow layout checks | UTY-M6-04: observed users, accessibility audit and measured load/recovery |

## D. Enterprise readiness dependencies (required before go-live where in pilot scope)

| Placeholder | Current evidence state | Details still needed / verification | Story |
|---|---|---|---|
| INT-CHSEC | Existing work reported; verify | Channel Secure SAML/entitlements, group mapping, revocation, environment restrictions | UTY-M5-01 |
| INT-APIGEE | Existing/onboarding status unknown | Approved route/security policies and service-account rights | UTY-M5-02 |
| INT-SPLUNK | Existing status unknown | Sink/field/redaction configuration, dashboards and operational owner | UTY-M5-03 |
| INT-AUTOSYS | Existing status unknown | Job/box, trusted trigger adapter, occurrence identity and result reporting | UTY-M5-04 |
| INT-CRON | Existing status unknown | Scheduler ownership, timezone, overlap/misfire and monitoring | UTY-M5-05 |
| INT-NAS | Meaning/owner to verify | File storage, owned data APIs or both; staging/import and permissions | UTY-M5-06 |
| INT-OTHER | To identify | Additional pilot-specific access, deployment, network and operational obligations | UTY-M0-04 |

No separate TEST environment is assumed: current environments are DEV, UAT and PROD. Unknown integration details do not stop local authoring development, but mandatory production dependencies are not waived. Reuse actual existing tickets when the user supplies them; no live Jira change is performed by this package.

## E. Source conflicts and safeguards resolved explicitly in the handoff

The current specification records, rather than hides, these differences from the supplied v4 draft:

- Preserve verified native AMIE; do not declare JSON the replacement for XML or vice versa.
- Retain optional categorization and actual L2 service ownership; do not restore a mandatory Application/Business Space field.
- Keep source extraction paths per adapter, not inside a supposedly transport-independent shared field definition.
- Keep correlation and deduplication separate. A trace ID does not automatically make repeated work safe.
- Do not treat every reachable node as having a producer's output; successful execution and path availability matter.
- Do not default every external write to three retries, compensation or DLQ. Those are distinct policies/semantics.
- Treat the reported four-day Kafka retention as unverified environment information; durable audit is independent from the beginning.
- Keep the agreed small UML/object/logic subset; a general UML state-machine runtime is not included.
- Preserve unknown imported data but distinguish preservation, editability and executability.
- An allowUserRestart flag is not authorization, reconciliation or idempotency.

These are labeled implementation reconciliations in `docs/00-DECISIONS-RATIONALE-AND-PRESERVATION.md`, not claims that the source said something different.

## F. Explicit next phase

UTY-M7-01: refine any confirmed overlapping AMIE durable orchestration after the first compatible release. UTY-M7-02: ServiceNow API integration; initially only a change-reference field is required. UTY-M7-03: AI/MCP co-design and automated policy-drift alerts under normal admission controls. UTY-M7-04: activate deferred BPMN/UML features only with concrete need and complete tests.

## Demo release decision

**Permitted:** demonstrate offline configuration, local draft edits, controlled fixture execution and the documented development plan. **Not demonstrated:** completed enterprise capability integration, native AMIE/BOB execution, real RBAC, official full BPMN conformance, safe live replay, production signing/activation, or verified migration-completion percentage.

The demo is useful precisely because it exposes the intended journey and remaining blockers. Do not hide the distinction to make the presentation sound more finished.
