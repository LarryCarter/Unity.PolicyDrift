# WF Unity - Complete current handoff v4

**Date:** November 20, 2026. **One current package:** complete decisions/specification, an offline demo, outstanding work, linked milestones/stories, reference schemas/examples, source and test evidence. This is not a claim that the enterprise implementation is finished.

## Open first

Extract the ZIP and open **START.html**. It links the current Modeling Studio, Capability Studio, readable handoff, demo runbook, outstanding register and milestone plan. You do not need an older ZIP as a separate handoff.

For the presentation, use **DEMO-RUNBOOK.md** and **demo/OPEN.html**. The demo has no backend connection and needs no credentials. The previous v3 editor is retained as a checkpoint, not a competing design.

For Devin, use **DEVIN-START.md**, then **WF-UNITY-COMPLETE-HANDOFF.md**. The master is self-contained and brings the decisions and rationale to the front. Individual files under docs/ remain available for implementation. ASK-MODE-HANDOFF.md, DEVIN-ASK.md and ASK.md contain identical complete master text. The file is intentionally large; its fit within any particular Devin paste limit has not been verified.

For Megan, use **planning/milestones-stories.md**. All 50 planning stories have an owning milestone: 46 initial-scope stories across M0-M6 and four next-phase stories under M7. No actual Jira issue keys, tickets, completion percentages or estimates are fabricated.

## What changed in this package

The current authoring specification incorporates the full platform direction and recent trigger/schema/data-lineage discussions, rather than appending conflicting notices to old jobs. The actual working v3 contextual editor was extended, not replaced. New demo behavior includes separated entry tabs, shared schema with per-adapter mappings, sample inference/locked merge, scheduled context/ingestion, a unified File entry point, and business/Ops views of local traces.

The explicit reconciliation register prevents source drift: AMIE native XML/JSON is source-verified, not replaced; multiple categories remain; no mandatory Application workspace returns; correlation is separate from dedupe; write retry safety, broker retention assumptions and production trust remain real implementation gates.

## Preservation is non-negotiable

Before production code changes, inspect and reuse working BOB, AMIE, SDK, auth/group, messaging and serializer contracts. Adapt the Studio to verified interfaces, not the other way around. The prototype's names, fixtures and XSD namespaces are proposals, not established enterprise contracts.

## Current versus historical content

- Root master and current docs/planning/QA: current implementation handoff.
- demo/: actual offline interaction/reference code. Fixture behavior is labeled.
- schemas/ and examples/: proposed/reference serialization profile and tests.
- review/MATTHEW-QUESTIONS.md: internal review, excluded from Ask copies.
- source-reference/: exact source proposal and older archives retained for provenance only; no need to reconcile their superseded requirements.

Read OUTSTANDING.md before calling any live integration complete. See qa/QA-REPORT.md for verification that was actually performed.
