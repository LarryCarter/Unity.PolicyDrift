# Current package index

| Need | Open |
|---|---|
| One visual starting point | START.html |
| Interactive current workflow/source designer | demo/OPEN.html |
| Capability developer/provider prototype | demo/CAPABILITY-STUDIO.html |
| Exact presentation steps | DEMO-RUNBOOK.md |
| Remaining work and blockers | OUTSTANDING.md |
| Complete authoritative current handoff | WF-UNITY-COMPLETE-HANDOFF.md |
| Devin execution instructions | DEVIN-START.md |
| Paste-ready identical master | ASK-MODE-HANDOFF.md / DEVIN-ASK.md / ASK.md |
| Milestones and story-level acceptance | planning/milestones-stories.md |
| Machine-readable milestone/story mapping | planning/milestones-stories.json |
| Current architecture and feature documents | docs/00 through docs/16 |
| Current verification evidence | qa/QA-REPORT.md and machine-readable results |
| XML schemas and examples | schemas/ and examples/ |
| Samples for the demonstration | demo/samples/ |
| Separate Matthew review (not in Ask) | review/MATTHEW-QUESTIONS.md |
| Unchanged historical sources | source-reference/ |

Every active specification is consolidated into the master in a stated reading order. Historical archives and Matthew's questionnaire are excluded. Browser-readable versions of the Markdown documents are under read/ and linked from START.html.
