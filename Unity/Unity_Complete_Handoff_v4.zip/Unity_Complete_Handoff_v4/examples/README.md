# Executable-artifact examples: explicit evidence levels

The two `baseline-*.bpmn` files are preserved v3 examples. `v4-cmdb-with-source-contract.bpmn` and `v4-scheduled-ingestion.bpmn` are actual exports from the extended demo during the recorded browser tests. They demonstrate the documented prototype serialization profile, typed mappings, native BPMN elements/DI and the proposed entry extension.

None is a deployable bank workflow or proof of native AMIE compatibility. Fixture rule parameters stay labeled fixture-only. An actual native AMIE artifact must come from the verified existing serializer. No fabricated XML/JSON sample is presented as Matthew's native language.

Use the supplied QA scripts to validate extension structure and references. Full official BPMN XSD and production compiler tests remain distinct gates. This example corpus should be extended by Devin with negative branch, timer, human approval, loops, parallelism, unknown extension and native artifact parity fixtures.
