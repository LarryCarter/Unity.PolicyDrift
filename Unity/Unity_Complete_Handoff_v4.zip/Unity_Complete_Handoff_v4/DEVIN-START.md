# Start Devin here - WF Unity Complete Handoff v4

You are implementing the agreed Unity architecture, not designing an alternative platform. Read `WF-UNITY-COMPLETE-HANDOFF.md` as the current self-contained specification. It incorporates the rationale, current decisions, explicit source conflicts, interfaces, user journeys, test gates and milestone-linked stories. Historical archives under `source-reference/` are provenance only; do not reconcile their superseded instructions as competing requirements.

**First invariant: preserve and extend existing working AMIE, BOB, Capability SDK, auth/groups, broker, EF and serialization contracts.** Begin with M0 read-only source reconciliation. Read repository AGENTS.md. Identify actual paths, interfaces, versions, tests and completed work. Do not implement speculative duplicate services or native schemas from prototype fixture code.

## First deliverable

Provide a source-backed M0 report that maps each current subsystem requirement to retain/extend/adapt/defer. Resolve the native AMIE XML/JSON discrepancy through actual source and artifacts. Record any missing integration requirements without guessing. Existing local auth and groups remain usable while Channel Secure is completed before go-live.

## Build order

Use `planning/milestones-stories.md`. Every story belongs to a milestone. Implement the generic operation contract and CyberArk read operation, existing AMIE integration and shared BOB local host. Extract the Email operation as the second service. Then prove the whole data-hydration/update/no-change/verify path and reuse the same operations in another process. Studio work should bind those contracts, not hardcode CyberArk-specific rule logic into generic controls.

The approved runtime Phase 1 includes parallel gateways, durable intermediate timers, interrupting timer/error boundaries and minimum durable human tasks in addition to the earlier core. Do not reduce it to the demo's export/simulation subset. Defer the explicitly listed advanced constructs until implemented and validated.

## UI baseline

`demo/OPEN.html` is a functional offline interaction reference. Preserve its useful edit/mapping/rule menus and contextual BPMN orientation. The extension adds source-specific setup, universal schema/sample import, shared mappings, native-artifact preservation and example operational views. None is proof of server RBAC, deployed subscriptions, native AMIE compatibility or production readiness. Use `docs/14-ACCEPTANCE-EVIDENCE-AND-IMPLEMENTATION-BOUNDARIES.md` to separate demonstration from required implementation.

## Before claiming a story is complete

Attach actual changed paths and commits, old/new behavior, positive and negative tests, dependency/release impact and remaining limitations. Add compile/type/schema/runtime/integration evidence at the appropriate layer. Run preservation regressions before and after changes. A browser test is not an enterprise API acceptance test.

Do not silently replace BPMN with JSON, AMIE with a fixture evaluator, embedded BOB with another engine, or group policy with client-side hiding. Do not assume a registration activates a capability. Do not retry an uncertain external write blindly. Do not treat a ServiceNow ID as externally validated approval. Do not use a prototype schema as a mandate to overwrite an established production contract.

For necessary deviations, record: reason/source evidence, smallest compatible change, affected decisions and stories, regression/rollback plan and required approval. Then update the current source MD and regenerate the master and Ask copies together.

## Entry files

- `OUTSTANDING.md`: what is demonstrated versus still required/unknown.
- `DEMO-RUNBOOK.md`: exact demonstration path and honest presentation boundaries.
- `planning/milestones-stories.md`: 46 initial-scope stories and four next-phase stories, planning IDs only.
- `qa/QA-REPORT.md`: results actually run, reproduction commands, exclusions.
- `review/MATTHEW-QUESTIONS.md`: internal review questionnaire; excluded from Ask copies.
