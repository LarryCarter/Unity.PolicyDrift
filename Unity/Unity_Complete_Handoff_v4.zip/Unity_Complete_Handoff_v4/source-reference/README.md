# Provenance only - not competing instructions

The current specification is the root `WF-UNITY-COMPLETE-HANDOFF.md`, generated from the current docs, outstanding register, milestone stories and demo/QA material. Do not reconstruct today's architecture by merging these older files.

- `USER-V4-PROPOSAL.txt`: exact latest pasted proposal supplied by the user. Its terminology, proposed scope, XSD and milestone intent are preserved as source. Current decisions and explicit reconciliation differences are documented in docs/00.
- `ORIGINAL-STUDIO-v3.zip`: original editable model prototype and tests, retained unchanged for regression/provenance.
- `HISTORICAL-CANONICAL-v2.2.zip`: earlier complete canonical package, including historical assets from the earlier handoff. Retained unchanged, not reissued as current jobs.
- `CYBERARK-RESEARCH-REFERENCE.zip`: earlier researched operation candidate list. Not proof of installed CyberArk API coverage.
- `source-checkpoint.json`: original archive digests and inspection evidence.

All these files are excluded from the paste-ready Ask documents. They preserve evidence/history, not dependencies a new reader must interpret to understand current requirements.
