# Synthetic source samples

These contain fictional business records only. No credentials or production data are included. The CSV normalizer maps Account ID and four custom fields to the existing account-update contract. Leading zeros in CostCenter are intentional: a numeric-looking identifier should not be silently converted to an integer.

`cmdb-records-new-column.csv` demonstrates safe merge after locking an existing field. `account-request.json` contains the equivalent nested model. `event-schema.avsc` demonstrates a small supported Avro record/nullable-union schema, not a binary Avro payload. Kafka decoding/schema-registry integration remains separate.

In the actual UI use Paste / upload sample, inspect inferred candidates and target mappings, then apply. Do not treat a sample as proof of requiredness or an approved production schema.
