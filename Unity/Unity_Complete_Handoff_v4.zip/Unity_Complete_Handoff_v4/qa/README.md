# Verification instructions

Read QA-REPORT.md for the evidence boundary. Rebuild the single-file demo using tools/build_demo.py, then run baseline_browser_tests.py, v4_browser_tests.py, validate_package_xml.py and smoke.py from the package root. Python dependencies are playwright, lxml and beautifulsoup4; Chromium must be installed or CHROMIUM_PATH supplied. Browser tests use the exact OPEN.html bytes with set_content.

The historical baseline validator is retained only as source evidence; use validate_package_xml.py for the current sample set and optional official BPMN gate. Browser-local tests must never be substituted for the actual BOB/AMIE/runtime integration tests listed in the milestone stories.

Rebuild HTML documentation and consolidated copies with tools/build_handoff.py after changing a normative Markdown document. Re-run tests and packaging checks after code/artifact changes. Do not hand-edit an Ask alias independently.
