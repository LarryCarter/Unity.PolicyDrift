# Current verification report

**Date:** 2026-11-20. **Claim:** the supplied offline demo and reference artifacts support the specifically tested interactions. **Not claimed:** enterprise deployment, complete BPMN conformance, native AMIE evaluation, server RBAC, or production readiness.

| Verification | Actual result | Evidence |
|---|---|---|
| Inherited editable-modeling browser regression | 48/48 passed | demo/qa/browser-results.json; qa/baseline-browser-output.txt |
| New entry/schema/demo browser regression | 45/45 passed | qa/v4-browser-results.json; qa/v4-browser-output.txt |
| Unity extension XSD and XML reference checks | 116/116 passed | qa/xml-results.json; qa/xml-output.txt |
| JavaScript syntax | Checked with node --check | qa/smoke.py repeats syntax checks for all current assets |
| Original source preservation | Original archives retained; digests compared in package smoke check | source-reference/source-checkpoint.json |
| Current package/link/story consistency | 53/53 checks passed; 111 local HTML links checked | qa/package-results.json; repeat smoke.py after changes |
| Official full BPMN 2.0.2 XSD | **Not run** | Approved official schema bundle was not available to the local validator |
| Actual BOB / AMIE / SDK / Blazor integration | **Not run** | Enterprise repository and runtime were not supplied |
| CyberArk / SMTP / Kafka / AutoSys / NAS / Channel Secure / Apigee / Splunk | **Not run** | No live calls are performed by the offline demo |
| Production package signing/import/activation | **Not run; UI blocked** | Requires verified native contracts, approval, trust and integration evidence |

## What the browser checks cover

The inherited suite checks contextual BPMN selection, editable nested mappings and object overrides, type/cardinality/optional/future-source rejection, three-dot/right-click/keyboard menus, rule search and replacement, actual local normalization, a real rule task insertion with atomic Undo/Redo, dependency-aware removal/repair, fixture success/no-change/verification-mismatch paths, known-profile XML/DI round-trip, malicious/unsupported input rejection, themes and narrow layout.

The new suite checks separated Trigger/Data Contract panels; independent correlation/dedupe fields; adding a CSV launch binding without cloning the shared contract; pasted and actually uploaded samples; nested normalized record preview; locked-field preservation; leading-zero identifiers; quoted commas/newlines; malformed CSV rejection; nested JSON and supported nullable Avro schema; source-switch compatibility diagnostics; XML persistence of multiple source bindings and field locks; opaque native XML preservation; all four scheduled run-context fields and explicit ingestion-before-read behavior; same local test trace in business/Ops views; guide/reset actions; File menu; themes and small-screen width.

These checks load the exact self-contained HTML in Chromium using Playwright set_content. They are real browser interaction tests, but do not certify every browser, operating system, enterprise file policy, assistive technology or live deployment. The HTML must be extracted and opened in a browser; an attachment preview is not the supported interactive host.

## XML evidence boundary

Both extension schemas compiled in lxml/libxml2. Positive exported examples and negative mutations were tested. IDs, BPMN sequence/data references, diagram references and source-binding field references were checked. Unknown types/attributes, invalid booleans/durations, duplicate IDs, negative column indexes and missing/dangling required bindings were rejected by the relevant validators. Native rule preservation is a text/format test; not an AMIE semantic test.

The convenience unity-modeling-v4.xsd assembles the preserved model extension and additive entry extension. It does not substitute for the official BPMN schemas. The complete workflow graph compiler still needs production parallel/loop/error/freshness/authorization and host-boundary tests. Passing XSD does not establish those guarantees.

## Known limits retained deliberately

The demo's catalogs and fields are fixtures. The custom model UI does not yet implement every array item/union/enum/range/default migration scenario. It simulates one scheduled ingestion row, not real NAS files, batch paging or scheduler ownership. Unsupported models are preserved/quarantined or explicitly rejected, not claimed fully editable. The native AMIE serializer is unverified. The prior Capability Studio remains a provider-onboarding reference rather than actual service registration. Portal/Ops records are in browser memory; restart/replay are intentionally unavailable. Production activation remains disabled.

## Reproduce

From the extracted package root, with Python, lxml, BeautifulSoup, Playwright and Chromium available:

```sh
python tools/build_demo.py
python qa/baseline_browser_tests.py
python qa/v4_browser_tests.py
python qa/validate_package_xml.py
python qa/smoke.py
```

Optional official standard-schema gate, using a trusted local bundle with its imports:

```sh
python qa/validate_package_xml.py --omg-xsd /approved/bpmn/BPMN20.xsd
```

Set CHROMIUM_PATH if Chromium is not on PATH. Do not report a skipped check as passed. Tests regenerate their own evidence; baseline/browser fixture outputs are separate from enterprise test results.
