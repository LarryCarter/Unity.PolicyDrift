"""Package/document smoke checks. No network access and no live operations."""
from pathlib import Path
from urllib.parse import urlparse, unquote
from bs4 import BeautifulSoup
from lxml import etree as E
import json,hashlib,subprocess,zipfile,sys
R=Path(__file__).resolve().parents[1];tests=[]
def check(name,ok,detail=''):
 tests.append({'name':name,'passed':bool(ok),'detail':detail})
 if not ok:print('FAIL',name,detail)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in (R/'demo/assets').glob('*.js'):
 r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True);check('Syntax '+str(p.relative_to(R)),r.returncode==0,r.stderr)
for p in [R/'schemas/unity-modeling-v3.xsd',R/'schemas/unity-entry-v4.xsd',R/'schemas/unity-modeling-v4.xsd']:
 try:E.XMLSchema(E.parse(str(p),E.XMLParser(no_network=True,resolve_entities=False)));check('Compile '+p.name,True)
 except Exception as e:check('Compile '+p.name,False,str(e))
master=R/'WF-UNITY-COMPLETE-HANDOFF.md';text=master.read_text();s=json.loads((R/'MASTER-SOURCES.json').read_text())
for alias in ['ASK-MODE-HANDOFF.md','DEVIN-ASK.md','ASK.md']:check('Identical '+alias,sha(master)==sha(R/alias))
for src in s['orderedSources']:
 check('Master includes exact source '+src,'<!-- BEGIN SOURCE: '+src+' -->\n\n'+(R/src).read_text() in text)
check('Matthew questionnaire excluded','# Matthew review - AMIE / identity / approval compatibility' not in text)
check('No archive sources in master order',all(not x.startswith(('source-reference/','review/')) for x in s['orderedSources']))
plan=json.loads((R/'planning/milestones-stories.json').read_text());stories=plan['stories'];ids={x['id'] for x in stories}
check('50 distinct planning stories',len(ids)==len(stories)==50)
check('46 initial-scope plus 4 future stories',sum(x['milestone']!='M7' for x in stories)==46 and sum(x['milestone']=='M7' for x in stories)==4)
check('Every story has one defined owning milestone',all(x['milestone'] in plan['milestones'] for x in stories))
check('All story dependencies resolve',all(y in ids for x in stories for y in x['dependencies']))
check('No false Jira keys or completion',all(not x['jiraKey'] and x['status']=='Not assessed against enterprise repository' for x in stories))
# Directed dependency cycle proof.
g={x['id']:x['dependencies'] for x in stories};seen=set();active=set()
def walk(n):
 if n in active:raise ValueError(n)
 if n in seen:return
 active.add(n)
 for d in g[n]:walk(d)
 active.remove(n);seen.add(n)
try:
 for n in g:walk(n)
 check('Story dependency graph acyclic',True)
except ValueError as e:check('Story dependency graph acyclic',False,str(e))
expected={'source-reference/ORIGINAL-STUDIO-v3.zip':'bed230aab81343005461ac4f443be7107d63baac38b24c78f183847e42369a9c','source-reference/HISTORICAL-CANONICAL-v2.2.zip':'1628bfee5072665642d901644b84227e648df90319b01bbcb70d613dbd256253'}
for rel,digest in expected.items():check('Original archive unchanged '+rel,sha(R/rel)==digest)
for p in (R/'source-reference').glob('*.zip'):
 with zipfile.ZipFile(p) as z:check('Historical ZIP intact '+p.name,z.testzip() is None)
# Active local HTML links only; frozen historical baseline remains byte-preserved.
htmls=[p for p in R.rglob('*.html') if p.name!='BASELINE-v3.html' and 'source-reference' not in p.parts]
missing=[];count=0
for p in htmls:
 soup=BeautifulSoup(p.read_text(),'html.parser')
 for el,attr in [(x,'href') for x in soup.select('[href]')]+[(x,'src') for x in soup.select('[src]')]:
  val=el.get(attr,'');u=urlparse(val)
  if not val or val.startswith('#') or u.scheme or u.netloc:continue
  target=(p.parent/unquote(u.path)).resolve();count+=1
  if not target.exists():missing.append(str(p.relative_to(R))+': '+val)
check('Active local HTML file links resolve',not missing, '; '.join(missing))
check('Demo self-contained with no external scripts',not BeautifulSoup((R/'demo/OPEN.html').read_text(),'html.parser').select('script[src],link[rel=stylesheet]'))
check('Every active XML example has matching evidence',all(any(p.name in t['name'] for t in json.loads((R/'qa/xml-results.json').read_text())['checks']) for p in (R/'examples').glob('*.bpmn')))
report={'date':'2026-11-20','tests':tests,'passed':sum(x['passed'] for x in tests),'total':len(tests),'localLinkChecks':count,'historicalBaselineLinkScan':'Excluded unchanged demo/BASELINE-v3.html; not linked as current specification'}
(R/'qa/package-results.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:report[k] for k in ['passed','total','localLinkChecks']},indent=2));sys.exit(0 if all(x['passed'] for x in tests) else 1)
