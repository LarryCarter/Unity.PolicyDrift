"""Validate reference XML with explicit evidence levels. Never fetch external DTDs/schema imports."""
from pathlib import Path
from lxml import etree as E
import argparse, json, copy
R=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--omg-xsd',type=Path);args=a.parse_args()
B='http://www.omg.org/spec/BPMN/20100524/MODEL';U='urn:wf-unity:modeling:prototype:3';V='urn:wf-unity:entry:review:4'
parser=E.XMLParser(resolve_entities=False,no_network=True,load_dtd=False)
schemas={U:E.XMLSchema(E.parse(str(R/'schemas/unity-modeling-v3.xsd'),parser)),V:E.XMLSchema(E.parse(str(R/'schemas/unity-entry-v4.xsd'),parser))}
results=[]
def check(name,ok,detail=''):
 results.append({'name':name,'passed':bool(ok),'detail':detail})
 if not ok: raise AssertionError(name+': '+detail)
def refs_valid(doc):
 ids=set(doc.xpath('//@id'))
 return all(x in ids for x in doc.xpath('//e:bind/@targetFieldRef',namespaces={'e':V}))
for f in sorted((R/'examples').glob('*.bpmn')):
 raw=f.read_bytes();check(f.name+' contains no DTD/entity declaration',b'<!DOCTYPE' not in raw and b'<!ENTITY' not in raw)
 doc=E.fromstring(raw,parser);check(f.name+' is BPMN definitions',doc.tag=='{'+B+'}definitions')
 for ns,schema in schemas.items():
  extensions=doc.xpath('//*[namespace-uri()=$ns and parent::*[namespace-uri()=$b and local-name()="extensionElements"]]',ns=ns,b=B)
  for i,ext in enumerate(extensions):check(f.name+f' {ns} extension {i}',schema.validate(ext),str(schema.error_log))
 ids=doc.xpath('//@id');idset=set(ids);check(f.name+' unique document IDs',len(ids)==len(idset))
 for attr in ['sourceRef','targetRef','bpmnElement','itemSubjectRef']:
  refs=doc.xpath('//*[namespace-uri()!=$u and namespace-uri()!=$v]/@'+attr,u=U,v=V)
  check(f.name+' attribute '+attr+' resolves',all(x in idset for x in refs),str([x for x in refs if x not in idset]))
 for tag in ['sourceRef','targetRef','dataInputRefs','dataOutputRefs']:
  refs=doc.xpath('//b:'+tag+'/text()',namespaces={'b':B});check(f.name+' element '+tag+' resolves',all(x in idset for x in refs))
 check(f.name+' source bindings target existing fields',refs_valid(doc))
 check(f.name+' remains a non-production fixture',all(x.get('isExecutable')=='false' for x in doc.findall('{'+B+'}process')))
 check(f.name+' has BPMN DI',bool(doc.xpath('//*[local-name()="BPMNDiagram"]')))
 check(f.name+' no embedded JSON workflow twin',not doc.xpath('//*[local-name()="editorState" or local-name()="workflowJson"]'))
 if args.omg_xsd:
  omg=E.XMLSchema(E.parse(str(args.omg_xsd),parser));check(f.name+' official BPMN XSD',omg.validate(doc),str(omg.error_log))
# Adversarial negatives demonstrate actual validators, not only well-formed positive files.
doc=E.parse(str(R/'examples/v4-cmdb-with-source-contract.bpmn'),parser)
ent=doc.find('.//{'+V+'}entryConfiguration')
for title,change in [
 ('Unsupported adapter type rejected',lambda x:x.find('.//{'+V+'}adapter').set('type','shell')),
 ('Invalid required Boolean rejected',lambda x:x.find('.//{'+V+'}field').set('required','sometimes')),
 ('Missing field identity rejected',lambda x:x.find('.//{'+V+'}field').attrib.pop('id')),
 ('Unknown source location rejected',lambda x:x.find('.//{'+V+'}bind').set('location','arbitrarySql')),
 ('Negative CSV index rejected',lambda x:x.find('.//{'+V+'}bind').set('columnIndex','-1')),
 ('Unknown entry extension attribute rejected',lambda x:x.set('runCode','true')),
 ('Duplicate xs:ID rejected',lambda x:x.findall('.//{'+V+'}field')[1].set('id',x.findall('.//{'+V+'}field')[0].get('id'))),
]:
 bad=copy.deepcopy(ent);change(bad);check(title,not schemas[V].validate(bad))
bad=copy.deepcopy(doc);bad.find('.//{'+V+'}bind').set('targetFieldRef','missingField');check('Dangling binding rejected by reference validator',not refs_valid(bad))
act=doc.find('.//{'+U+'}activity');bad=copy.deepcopy(act);bad.set('timeout','five minutes');check('Invalid duration rejected by existing schema',not schemas[U].validate(bad))
bad=copy.deepcopy(act);bad.set('runArbitraryCode','true');check('Unknown original activity attribute rejected',not schemas[U].validate(bad))
n=E.fromstring(('<e:entryConfiguration xmlns:e="'+V+'" profile="4-review" isPrototype="true"><e:contract id="c" name="x" rootType="object"/><e:adapters><e:adapter id="a" type="kafka" enabled="true"><e:configuration/><e:sourceBindings/><e:sampleOrigin mode="manual"/></e:adapter></e:adapters><e:nativeArtifact name="rule.xml" mediaType="application/xml" verification="syntax-only">&lt;original/&gt;</e:nativeArtifact></e:entryConfiguration>').encode(),parser)
check('Opaque native XML representation conforms without changing format',schemas[V].validate(n),str(schemas[V].error_log))
n.find('{'+V+'}nativeArtifact').set('verification','production-approved');check('Native fixture cannot claim production verification',not schemas[V].validate(n))
report={'date':'2026-11-20','status':'all listed checks passed','passed':sum(x['passed'] for x in results),'total':len(results),'checks':results,'officialBPMNXSD':'RUN using supplied local bundle' if args.omg_xsd else 'NOT RUN: approved official BPMN XSD bundle unavailable; extension validation is not full BPMN conformance.','nativeAMIE':'NOT RUN: actual serializer/evaluator not supplied','liveRuntime':'NOT RUN'}
(R/'qa/xml-results.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:report[k] for k in ['passed','total','officialBPMNXSD']},indent=2))
