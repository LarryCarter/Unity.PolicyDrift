# Matthew review - AMIE / identity / approval compatibility

**Internal review document. Excluded from the master Ask-mode consolidation.** The normative handoff contains the requirement to verify these contracts, but not this separate reviewer questionnaire. These questions are not permission to replace existing working code.

1. What is the actual native rule format and version: XML, JSON, both, or a persisted object serialized through an existing service? Please identify one real sanitized artifact and its serializer/evaluator tests. The supplied v4 proposal calls JSON native; earlier discussion calls XML native. We will preserve the verified implementation.
2. What editor APIs and fact/result descriptors already exist? How are rule precedence, defaults, error outcomes, local drafts, referenced rules and version pinning represented? Which rule visualizations can reuse the existing editor rather than implement another evaluator?
3. How does current AMIE intake validate, enrich, select a workflow and publish to BOB? Which parts are stateless decisions and which own durable waiting/recovery? The current first-release behavior stands; any confirmed competing orchestration is a separately planned next-phase correction.
4. What local AMIE adapter and cached approved-definition support can capability services already use? What happens when configuration services are unavailable? Are approval rules and multilevel/backup-approver plans already modeled?
5. What authentication/group/entitlement code is already implemented in BE? How should the new controls bind groups and rules without a separate membership system? What is the current Channel Secure integration request/status?
6. How are rule collections organized today? Proposed categories, multi-category usage and capability/context filters are review candidates; a new mandatory Business Space should not be assumed.
7. What needs to accompany native rules in a release for DEV/UAT/PROD? How are signatures, dependencies and migrations handled today? Can the same native bytes be promoted and verified independently of the authoring database?
8. Which proposed Studio screens should be retained, modified or rejected? In particular: contextual large rule chooser, input/output facts, where-used, parameter draft editing, conditional outcomes and field-rule insertion as a real BPMN task.

Record responses against source files/commits and focused fixtures. Any contract change needs an explicit compatibility decision, not a prototype-derived rewrite.
