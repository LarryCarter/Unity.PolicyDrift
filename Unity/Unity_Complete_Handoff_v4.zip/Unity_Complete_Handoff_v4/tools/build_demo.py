from pathlib import Path
root=Path(__file__).resolve().parents[1]
a=root/'demo/assets'
css='\n'.join((a/n).read_text() for n in ['builder-base.css','modeling.css','entry-v4.css'])
scripts=''.join('<script>\n'+(a/n).read_text()+'\n</script>' for n in ['builder-base.js','modeling.js','entry-v4.js'])
html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WF Unity | Complete v4 Review Demo</title><style>'+css+'</style></head><body><div id="app"></div><input id="importDraft" type="file" accept=".json" hidden>'+scripts+'</body></html>'
(root/'demo/OPEN.html').write_text(html)
print('Built demo/OPEN.html',len(html),'characters')
