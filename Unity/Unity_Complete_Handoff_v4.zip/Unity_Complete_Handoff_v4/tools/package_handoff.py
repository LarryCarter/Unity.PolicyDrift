"""Build one local ZIP with deterministic path ordering and verify its bytes."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
excluded={'FILE-MANIFEST.json','SHA256SUMS.txt'}
items=[p for p in sorted(R.rglob('*')) if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts]
manifest={'package':'WF Unity Complete Handoff v4','date':'2026-11-20','status':'Complete current implementation specification and tested offline demo; not production implementation','primary':'START.html','master':'WF-UNITY-COMPLETE-HANDOFF.md','normativeSources':'MASTER-SOURCES.json','outstanding':'OUTSTANDING.md','reviewExclusion':'review/MATTHEW-QUESTIONS.md excluded from master/Ask','files':[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in items]}
(R/'FILE-MANIFEST.json').write_text(json.dumps(manifest,indent=2))
allfiles=[p for p in sorted(R.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt' and '__pycache__' not in p.parts]
(R/'SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+str(p.relative_to(R)) for p in allfiles)+'\n')
zip_path=R.parent/'Unity_Complete_Handoff_v4.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(R.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(z.namelist()))
 for p in sorted(R.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:assert z.read(str(Path(R.name)/p.relative_to(R)))==p.read_bytes()
info={'path':str(zip_path),'bytes':zip_path.stat().st_size,'megabytesDecimal':round(zip_path.stat().st_size/1e6,2),'sha256':sha(zip_path),'files':len(z.namelist()),'zipIntegrity':'passed','zipMembersMatchSource':'all files byte-verified'}
(R.parent/'Unity_Complete_Handoff_v4_VERIFICATION.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2))
