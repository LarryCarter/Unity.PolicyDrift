from pathlib import Path
import json, hashlib, html, re, shutil
import mistune
from bs4 import BeautifulSoup
R=Path(__file__).resolve().parents[1]
def put(p,t):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t.strip()+'\n')
base=json.loads((R/'demo/qa/browser-results.json').read_text());v4=json.loads((R/'qa/v4-browser-results.json').read_text());xml=json.loads((R/'qa/xml-results.json').read_text())
# Current QA summaries are taken from actual output files, not earlier claims.
pack=json.loads((R/'qa/package-results.json').read_text()) if (R/'qa/package-results.json').exists() else {'passed':'not run','total':'not run','localLinkChecks':'not run'}
def tests(d):return d.get('tests',d.get('checks',[]))
bn=sum(x['passed'] for x in tests(base));vn=sum(x['passed'] for x in tests(v4));xn=xml['passed']
put('qa/QA-REPORT.md',f'''
# Current verification report

**Date:** 2026-11-20. **Claim:** the supplied offline demo and reference artifacts support the specifically tested interactions. **Not claimed:** enterprise deployment, complete BPMN conformance, native AMIE evaluation, server RBAC, or production readiness.

| Verification | Actual result | Evidence |
|---|---|---|
| Inherited editable-modeling browser regression | {bn}/{len(tests(base))} passed | demo/qa/browser-results.json; qa/baseline-browser-output.txt |
| New entry/schema/demo browser regression | {vn}/{len(tests(v4))} passed | qa/v4-browser-results.json; qa/v4-browser-output.txt |
| Unity extension XSD and XML reference checks | {xn}/{xml['total']} passed | qa/xml-results.json; qa/xml-output.txt |
| JavaScript syntax | Checked with node --check | qa/smoke.py repeats syntax checks for all current assets |
| Original source preservation | Original archives retained; digests compared in package smoke check | source-reference/source-checkpoint.json |
| Current package/link/story consistency | {pack['passed']}/{pack['total']} checks passed; {pack['localLinkChecks']} local HTML links checked | qa/package-results.json; repeat smoke.py after changes |
| Official full BPMN 2.0.2 XSD | **Not run** | Approved official schema bundle was not available to the local validator |
| Actual BOB / AMIE / SDK / Blazor integration | **Not run** | Enterprise repository and runtime were not supplied |
| CyberArk / SMTP / Kafka / AutoSys / NAS / Channel Secure / Apigee / Splunk | **Not run** | No live calls are performed by the offline demo |
| Production package signing/import/activation | **Not run; UI blocked** | Requires verified native contracts, approval, trust and integration evidence |

## What the browser checks cover

The inherited suite checks contextual BPMN selection, editable nested mappings and object overrides, type/cardinality/optional/future-source rejection, three-dot/right-click/keyboard menus, rule search and replacement, actual local normalization, a real rule task insertion with atomic Undo/Redo, dependency-aware removal/repair, fixture success/no-change/verification-mismatch paths, known-profile XML/DI round-trip, malicious/unsupported input rejection, themes and narrow layout.

The new suite checks separated Trigger/Data Contract panels; independent correlation/dedupe fields; adding a CSV launch binding without cloning the shared contract; pasted and actually uploaded samples; nested normalized record preview; locked-field preservation; leading-zero identifiers; quoted commas/newlines; malformed CSV rejection; nested JSON and supported nullable Avro schema; source-switch compatibility diagnostics; XML persistence of multiple source bindings and field locks; opaque native XML preservation; all four scheduled run-context fields and explicit ingestion-before-read behavior; same local test trace in business/Ops views; guide/reset actions; File menu; themes and small-screen width.

These checks load the exact self-contained HTML in Chromium using Playwright set_content. They are real browser interaction tests, but do not certify every browser, operating system, enterprise file policy, assistive technology or live deployment. The HTML must be extracted and opened in a browser; an attachment preview is not the supported interactive host.

## XML evidence boundary

Both extension schemas compiled in lxml/libxml2. Positive exported examples and negative mutations were tested. IDs, BPMN sequence/data references, diagram references and source-binding field references were checked. Unknown types/attributes, invalid booleans/durations, duplicate IDs, negative column indexes and missing/dangling required bindings were rejected by the relevant validators. Native rule preservation is a text/format test; not an AMIE semantic test.

The convenience unity-modeling-v4.xsd assembles the preserved model extension and additive entry extension. It does not substitute for the official BPMN schemas. The complete workflow graph compiler still needs production parallel/loop/error/freshness/authorization and host-boundary tests. Passing XSD does not establish those guarantees.

## Known limits retained deliberately

The demo's catalogs and fields are fixtures. The custom model UI does not yet implement every array item/union/enum/range/default migration scenario. It simulates one scheduled ingestion row, not real NAS files, batch paging or scheduler ownership. Unsupported models are preserved/quarantined or explicitly rejected, not claimed fully editable. The native AMIE serializer is unverified. The prior Capability Studio remains a provider-onboarding reference rather than actual service registration. Portal/Ops records are in browser memory; restart/replay are intentionally unavailable. Production activation remains disabled.

## Reproduce

From the extracted package root, with Python, lxml, BeautifulSoup, Playwright and Chromium available:

```sh
python tools/build_demo.py
python qa/baseline_browser_tests.py
python qa/v4_browser_tests.py
python qa/validate_package_xml.py
python qa/smoke.py
```

Optional official standard-schema gate, using a trusted local bundle with its imports:

```sh
python qa/validate_package_xml.py --omg-xsd /approved/bpmn/BPMN20.xsd
```

Set CHROMIUM_PATH if Chromium is not on PATH. Do not report a skipped check as passed. Tests regenerate their own evidence; baseline/browser fixture outputs are separate from enterprise test results.
''')
put('README-START-HERE.md',r'''
# WF Unity - Complete current handoff v4

**Date:** November 20, 2026. **One current package:** complete decisions/specification, an offline demo, outstanding work, linked milestones/stories, reference schemas/examples, source and test evidence. This is not a claim that the enterprise implementation is finished.

## Open first

Extract the ZIP and open **START.html**. It links the current Modeling Studio, Capability Studio, readable handoff, demo runbook, outstanding register and milestone plan. You do not need an older ZIP as a separate handoff.

For the presentation, use **DEMO-RUNBOOK.md** and **demo/OPEN.html**. The demo has no backend connection and needs no credentials. The previous v3 editor is retained as a checkpoint, not a competing design.

For Devin, use **DEVIN-START.md**, then **WF-UNITY-COMPLETE-HANDOFF.md**. The master is self-contained and brings the decisions and rationale to the front. Individual files under docs/ remain available for implementation. ASK-MODE-HANDOFF.md, DEVIN-ASK.md and ASK.md contain identical complete master text. The file is intentionally large; its fit within any particular Devin paste limit has not been verified.

For Megan, use **planning/milestones-stories.md**. All 50 planning stories have an owning milestone: 46 initial-scope stories across M0-M6 and four next-phase stories under M7. No actual Jira issue keys, tickets, completion percentages or estimates are fabricated.

## What changed in this package

The current authoring specification incorporates the full platform direction and recent trigger/schema/data-lineage discussions, rather than appending conflicting notices to old jobs. The actual working v3 contextual editor was extended, not replaced. New demo behavior includes separated entry tabs, shared schema with per-adapter mappings, sample inference/locked merge, scheduled context/ingestion, a unified File entry point, and business/Ops views of local traces.

The explicit reconciliation register prevents source drift: AMIE native XML/JSON is source-verified, not replaced; multiple categories remain; no mandatory Application workspace returns; correlation is separate from dedupe; write retry safety, broker retention assumptions and production trust remain real implementation gates.

## Preservation is non-negotiable

Before production code changes, inspect and reuse working BOB, AMIE, SDK, auth/group, messaging and serializer contracts. Adapt the Studio to verified interfaces, not the other way around. The prototype's names, fixtures and XSD namespaces are proposals, not established enterprise contracts.

## Current versus historical content

- Root master and current docs/planning/QA: current implementation handoff.
- demo/: actual offline interaction/reference code. Fixture behavior is labeled.
- schemas/ and examples/: proposed/reference serialization profile and tests.
- review/MATTHEW-QUESTIONS.md: internal review, excluded from Ask copies.
- source-reference/: exact source proposal and older archives retained for provenance only; no need to reconcile their superseded requirements.

Read OUTSTANDING.md before calling any live integration complete. See qa/QA-REPORT.md for verification that was actually performed.
''')
put('INDEX.md',r'''
# Current package index

| Need | Open |
|---|---|
| One visual starting point | START.html |
| Interactive current workflow/source designer | demo/OPEN.html |
| Capability developer/provider prototype | demo/CAPABILITY-STUDIO.html |
| Exact presentation steps | DEMO-RUNBOOK.md |
| Remaining work and blockers | OUTSTANDING.md |
| Complete authoritative current handoff | WF-UNITY-COMPLETE-HANDOFF.md |
| Devin execution instructions | DEVIN-START.md |
| Paste-ready identical master | ASK-MODE-HANDOFF.md / DEVIN-ASK.md / ASK.md |
| Milestones and story-level acceptance | planning/milestones-stories.md |
| Machine-readable milestone/story mapping | planning/milestones-stories.json |
| Current architecture and feature documents | docs/00 through docs/16 |
| Current verification evidence | qa/QA-REPORT.md and machine-readable results |
| XML schemas and examples | schemas/ and examples/ |
| Samples for the demonstration | demo/samples/ |
| Separate Matthew review (not in Ask) | review/MATTHEW-QUESTIONS.md |
| Unchanged historical sources | source-reference/ |

Every active specification is consolidated into the master in a stated reading order. Historical archives and Matthew's questionnaire are excluded. Browser-readable versions of the Markdown documents are under read/ and linked from START.html.
''')
put('qa/README.md',r'''
# Verification instructions

Read QA-REPORT.md for the evidence boundary. Rebuild the single-file demo using tools/build_demo.py, then run baseline_browser_tests.py, v4_browser_tests.py, validate_package_xml.py and smoke.py from the package root. Python dependencies are playwright, lxml and beautifulsoup4; Chromium must be installed or CHROMIUM_PATH supplied. Browser tests use the exact OPEN.html bytes with set_content.

The historical baseline validator is retained only as source evidence; use validate_package_xml.py for the current sample set and optional official BPMN gate. Browser-local tests must never be substituted for the actual BOB/AMIE/runtime integration tests listed in the milestone stories.

Rebuild HTML documentation and consolidated copies with tools/build_handoff.py after changing a normative Markdown document. Re-run tests and packaging checks after code/artifact changes. Do not hand-edit an Ask alias independently.
''')
# Generate the single normative master from separate current sources.
sources=['README-START-HERE.md','INDEX.md','DEVIN-START.md','OUTSTANDING.md']+[str(p.relative_to(R)) for p in sorted((R/'docs').glob('*.md'))]+['planning/milestones-stories.md','DEMO-RUNBOOK.md','schemas/README.md','examples/README.md','demo/samples/README.md','qa/README.md','qa/QA-REPORT.md']
header='''# WF Unity - Complete Current Architecture, Demo and Devin Handoff\n\n**Version:** 4.0-review. **Date:** November 20, 2026.\n\nThis is the self-contained current implementation specification. It combines the agreed rationale, requirements, explicit source conflicts, UX/serialization/runtime contracts, outstanding register, milestone-linked stories, user guides and actual verification results. No older handoff needs to be reconciled to understand the requested direction.\n\n**Preserve and extend existing working contracts.** The delivered HTML is a functional offline prototype, not the enterprise implementation. Source verification and required integration/production gates remain explicit.\n\n## Complete reading order\n\n'''
header+='\n'.join(f'{i}. `{p}`' for i,p in enumerate(sources,1))
header+='\n\nThe following sections contain the complete text of those source documents. Matthew\'s separate review questions and historical archives are excluded. Generated aliases have identical bytes.\n'
master=header+'\n'.join('\n\n---\n\n<!-- BEGIN SOURCE: '+p+' -->\n\n'+(R/p).read_text()+'\n<!-- END SOURCE: '+p+' -->\n' for p in sources)
for n in ['WF-UNITY-COMPLETE-HANDOFF.md','ASK-MODE-HANDOFF.md','DEVIN-ASK.md','ASK.md']:(R/n).write_text(master)
(R/'MASTER-SOURCES.json').write_text(json.dumps({'orderedSources':sources,'excluded':['review/MATTHEW-QUESTIONS.md','source-reference/**','demo/BASELINE-v3.html'],'masterWordCount':len(master.split()),'masterCharacters':len(master),'identicalAliases':['ASK-MODE-HANDOFF.md','DEVIN-ASK.md','ASK.md']},indent=2))
# Render portable readable copies; no JS, web fonts or remote assets.
renderer=mistune.create_markdown(plugins=['table','strikethrough','url'])
css='''body{margin:0;background:#f2f6fa;color:#193047;font:16px/1.65 system-ui,Segoe UI,Arial}header{position:sticky;top:0;background:#143044;color:white;padding:14px 5%;z-index:2}header a{color:#d6f7f4;margin-right:20px}main{max-width:1120px;margin:28px auto;padding:36px;background:white;border:1px solid #d7e1eb;border-radius:14px}h1,h2,h3{line-height:1.25;scroll-margin-top:80px}h1{font-size:32px}h2{border-top:1px solid #d8e2eb;padding-top:25px;color:#116b73}h3{color:#254b68}table{width:100%;border-collapse:collapse;font-size:14px;display:block;overflow-x:auto}td,th{border:1px solid #dbe4ed;padding:10px;vertical-align:top}th{background:#eaf3f7}code{background:#edf2f6;padding:2px 5px;border-radius:4px}pre{background:#102738;color:#e6f3fb;padding:20px;overflow-x:auto}pre code{background:none;padding:0}a{color:#08757c}blockquote{margin:18px 0;border-left:4px solid #1e928f;padding:10px 20px;background:#f0faf8}details{padding:15px;background:#eef5f8;border-radius:8px}img{max-width:100%}.meta{color:#5a6d7e;font-size:13px}@media(max-width:700px){main{padding:18px;margin:12px}h1{font-size:26px}header{font-size:13px}}@media print{header{position:static}body{background:white}main{border:0;margin:0;padding:0}}'''
mdfiles=[p for p in R.rglob('*.md') if not any(x in p.parts for x in ['read','source-reference']) and p.name not in ['ASK-MODE-HANDOFF.md','DEVIN-ASK.md','ASK.md']]
for p in mdfiles:
 rel=p.relative_to(R);out=R/'read'/rel.with_suffix('.html');out.parent.mkdir(parents=True,exist_ok=True)
 depth=len(out.parent.relative_to(R).parts);prefix='../'*depth
 body=renderer(p.read_text());soup=BeautifulSoup(body,'html.parser');toc=[];seen={}
 for h in soup.find_all(['h1','h2','h3']):
  slug=re.sub(r'[^a-z0-9]+','-',h.get_text().lower()).strip('-');n=seen.get(slug,0);seen[slug]=n+1;slug+=('-'+str(n)) if n else '';h['id']=slug
  if h.name=='h2':toc.append(f'<li><a href="#{slug}">{html.escape(h.get_text())}</a></li>')
 title=soup.h1.get_text() if soup.h1 else p.stem
 out.write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+html.escape(title)+'</title><style>'+css+'</style><header><a href="'+prefix+'START.html">Unity handoff home</a><a href="'+prefix+'demo/OPEN.html">Open Studio</a><a href="'+prefix+str(rel)+'">Markdown source</a></header><main><p class="meta">Current handoff / 2026-11-20 / Prototype and production evidence are separate</p>'+('<details><summary>Sections</summary><ul>'+''.join(toc)+'</ul></details>' if len(toc)>5 else '')+str(soup)+'</main></html>')
# A clear single package launcher.
put('START.html','''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WF Unity | Complete v4 handoff</title><style>
:root{--bg:#edf3f7;--ink:#173246;--muted:#5e7181;--line:#d3e0e9;--teal:#087f83}*{box-sizing:border-box}body{margin:0;font:16px/1.55 system-ui,Segoe UI,Arial;background:var(--bg);color:var(--ink)}main{max-width:1180px;margin:auto;padding:42px 28px}.eyebrow{color:#087c80;font-size:13px;font-weight:800;letter-spacing:1.6px}h1{font-size:42px;line-height:1.1;margin:14px 0}h2{font-size:23px;margin:5px 0 12px}p{color:var(--muted)}.hero{display:grid;grid-template-columns:1.2fr 1fr;gap:25px;align-items:center}.hero img{width:100%;border:1px solid var(--line);border-radius:14px}.notice{margin:28px 0;background:#fff4df;border:1px solid #e9d6aa;border-radius:12px;padding:16px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.card{background:white;border:1px solid var(--line);border-radius:14px;padding:24px;box-shadow:0 4px 18px #16394a08}.card a{color:#096e76;font-weight:650}.primary{display:inline-block;background:#087f83;color:white!important;text-decoration:none;border-radius:8px;padding:12px 18px;margin:8px 8px 8px 0}.links{display:flex;gap:12px;flex-wrap:wrap;margin-top:12px}.tag{display:inline-block;border-radius:15px;background:#e5f2f3;padding:3px 10px;font-size:12px;color:#17696e;font-weight:700}.wide{grid-column:1/-1}.foot{font-size:13px;margin-top:25px}.steps{display:flex;flex-wrap:wrap;gap:9px;margin:16px 0}.steps span{padding:8px 12px;background:#edf4f8;border-radius:7px}a:focus-visible{outline:3px solid #555bc0;outline-offset:3px}@media(max-width:750px){.hero,.grid{grid-template-columns:1fr}h1{font-size:32px}main{padding:24px 15px}}
</style></head><body><main><div class="hero"><section><div class="eyebrow">WF UNITY / COMPLETE HANDOFF / 20 NOV 2026</div><h1>One workflow.<br>Clearer ways to build it.</h1><p>Capability APIs, BPMN execution, AMIE decisions and typed data flow - preserved in one governed model. This package connects the demo, the implementation decisions and the outstanding work.</p><a class="primary" href="demo/OPEN.html">Open Modeling Studio</a><a href="read/DEMO-RUNBOOK.html">Read the demo walkthrough</a></section><img src="demo/previews/03-sample-import.png" alt="Actual sample-to-schema importer in the supplied demo"></div><div class="notice"><strong>Offline interaction demo, not a live deployment.</strong> No CyberArk, Email, Kafka, native AMIE or production calls are made. Required enterprise verification and implementation work is visible in the outstanding register.</div><div class="grid"><section class="card"><span class="tag">PRESENT</span><h2>Demonstrate the journey</h2><div class="steps"><span>Define source</span><span>Build & map</span><span>Test</span><span>Review release gates</span></div><p>Keep the editable BPMN context, three-dot menus, rule popovers and Undo/Redo. Add CSV source mappings, locked contracts and scheduled ingestion without a second configuration system.</p><div class="links"><a href="demo/OPEN.html">Workflow Studio</a><a href="demo/CAPABILITY-STUDIO.html">Capability Studio</a><a href="read/DEMO-RUNBOOK.html">Presenter runbook</a></div></section><section class="card"><span class="tag">PLAN</span><h2>Know what remains</h2><p>Source-verification blockers, integration owners, demonstrated versus specified features and production acceptance gates. Story status is not invented from prototype results.</p><div class="links"><a href="read/OUTSTANDING.html">Outstanding register</a><a href="read/planning/milestones-stories.html">Megan's milestones & stories</a><a href="read/qa/QA-REPORT.html">Actual QA evidence</a></div></section><section class="card"><span class="tag">IMPLEMENT</span><h2>Give Devin the whole design</h2><p>One self-contained specification brings rationale, decisions, contracts, UI behavior, XML/XSD mapping, runtime boundaries, guides and acceptance criteria to the front.</p><div class="links"><a href="read/DEVIN-START.html">Devin start</a><a href="read/WF-UNITY-COMPLETE-HANDOFF.html">Complete readable handoff</a><a href="WF-UNITY-COMPLETE-HANDOFF.md">Master Markdown</a><a href="ASK-MODE-HANDOFF.md">Ask Mode text</a></div></section><section class="card"><span class="tag">PRESERVE</span><h2>Extend working contracts</h2><p>Existing BOB, AMIE, SDK, authentication/groups and serializers are the baseline. AMIE XML versus JSON must be resolved from Matthew's actual implementation, not this fixture.</p><div class="links"><a href="read/docs/00-DECISIONS-RATIONALE-AND-PRESERVATION.html">Decisions and explicit conflicts</a><a href="read/review/MATTHEW-QUESTIONS.html">Matthew review (excluded from Ask)</a><a href="read/schemas/README.html">Schema evidence boundaries</a></div></section></div><p class="foot">All 50 story identifiers are planning references, not live Jira records. 46 initial-scope stories + 4 next-phase stories. Historical archives are retained under source-reference for provenance only. Start here rather than assembling earlier ZIPs.</p></main></body></html>''')
put('OPEN.html','<!doctype html><html lang="en"><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=demo/OPEN.html"><title>Open Unity Studio</title><a href="demo/OPEN.html">Open Unity Modeling Studio</a></html>')
# Add a clearly stated entry back from capability prototype.
print(json.dumps({'masterWords':len(master.split()),'masterCharacters':len(master),'normativeSourceCount':len(sources),'renderedDocuments':len(mdfiles),'browserPassed':bn+vn,'xmlPassed':xn},indent=2))
