# 09. Groups, entitlements, maturity and security

## Reuse current identity and group implementation

Matthew already has authentication/group behavior. Inspect and reuse it. Standalone development continues through that setup while Channel Secure SAML/entitlement integration is completed before go-live. No requirement to connect directly to AD now or build another identity store. Later enterprise group mapping must preserve current resource grants and stable identity references.

Production allows only approved production entitlement mappings. Existing naming patterns help recognize Prod versus Non-Prod; persist/validate an explicit environment classification as well. Workflow configuration stores references, not proof that a group exists or that the current user belongs to it. Registration of a directory name alone grants no access.

## Resource-specific roles

| Role | Intended rights | Limit |
|---|---|---|
| Read | View authorized workflow information/results/reports | Scope must be explicit; never assume enterprise-wide visibility |
| Execute | Launch permitted workflow and view own/authorized results | No capability registration or production activation implied |
| Execute-Lead | Execute plus authorized group-run/report view | Filter by configured group scope, not every departmental run |
| Create | Create/edit permitted drafts, Execute and Read | No implicit approval, grants administration or production activation |
| Approver | Decide eligible human/release tasks | Existing AMIE and separation policy still applies |
| Capability Register/Configure | Onboard/configure approved service operations | Separate from consumer workflow rights |
| Release Operator | Import/activate authorized artifact | Requires all release gates; not merely a job title |
| Administrator | Scoped catalog/grant/environment maintenance | Cannot bypass approval/audit policy |

AMIE configures applicable group/rule restrictions; the backend enforces them. The website may hide controls for clarity, but BE APIs, BOB admission and privileged capability dispatch independently enforce their own boundaries. The external department sees the approved service identity. Do not force it to provision per-human Unity groups for every API call.

## Maturity, stage and activation

Store classification separately from stage: Experimental, NonProd, Approved; InDev, Testing, Verified, ReleaseReady. Display combined values. The confirmed normal progression is Experimental-InDev -> Experimental-Testing -> Experimental-Verified -> NonProd-Testing -> NonProd-Verified -> NonProd-ReleaseReady -> Approved-Verified -> Approved-ReleaseReady. Evidence and authority govern transitions; never infer deployment from the label.

These attach to a specific version. Capability v1 may be active Approved-ReleaseReady while v2 is NonProd-InDev. Operations can have different status from their parent service. A stable service does not make its new destructive operation stable. Experimental-ReleaseReady means ready for an explicitly permitted experimental environment, not production.

Separate visible modeling, implemented handler support, authorized execution, and environment activation. Unsupported experimental constructs can be saved/preserved, but no flag creates a missing runtime handler. Production rejects unapproved experimental dependencies. Catalog UI includes approval/status, experimental controls, per-environment activation, versions and audit, kept within the service context.

## Sensitive data boundaries

Use approved connection and credential references. Never place rotating passwords, SMTP credentials, API tokens, cookies or private signing keys in manifests, BPMN, samples, trace output or downloadable reports. Data classification follows mappings and transformations. A rule cannot downgrade sensitivity just by renaming a field. Redaction is enforced centrally; optional developer logging cannot disable mandatory security audit.

Use constrained paths/selectors, strict decoder limits, no arbitrary SQL/URL/class name execution from configuration. Native artifacts and imported XML are untrusted until validated. A schema declaring authMode=bearer is a design setting, not authentication evidence. For test modes, show Mock clearly and disallow a one-click switch to production connections.

## Governance without overcomplicating Jira

Jira/story references are planning traceability, not runtime authorization. Keep owner, milestone, remaining work and evidence understandable. Every story has one milestone; do not require a new tracking subsystem for every small mapping. Group/import configuration changes use the same governed artifact process as workflow/rule changes, with environment diff and reviewed privilege impact.
