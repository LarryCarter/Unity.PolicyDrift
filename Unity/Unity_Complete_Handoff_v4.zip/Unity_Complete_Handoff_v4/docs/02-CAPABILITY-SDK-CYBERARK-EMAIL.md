# 02. Capability SDK and the first two services

## Developer experience

A developer implements or adapts a typed business primitive, registers it through trusted startup/DI, and supplies the small amount of semantics that cannot be inferred from code. The SDK should supply standard admission, correlation, schema publication, transport adapters, tracing and outcome wiring. The desired experience does not require hand-writing a Kafka consumer, registry JSON, and BE form for each new operation.

Do not implement hypothetical interfaces in parallel to the actual SDK. In M0 find the closest existing handler and registration pattern. The proposed names below describe the required contract only.

| Descriptor member | Required meaning |
|---|---|
| serviceId, operationKey, contractVersion | Stable provider/operation identity; display names may change without breaking references. |
| group/controller/category | Browsing under Service -> API group -> Operation; not a runtime permission grant. |
| inputSchema/outputSchema | Types, nested fields, cardinality, nullable versus missing, constraints, semantics and security classification. |
| effect | Read, pure transform, owned-state write, external write, destructive or secret-returning. |
| outcomes | Success output guarantees, business rejection, not found, retryable failure, permanent failure, unknown external effect. |
| host eligibility | Local embedded, remote capability dispatch, or a defined supported combination. |
| producer relationships | Which semantic values can be supplied; required lookup key, target/service scope, cardinality, freshness, no inferred identity aliasing. |
| retry/reconciliation | What is demonstrably safe; no generic automatic retry for uncertain writes. |
| availability | Approved immutable descriptor version, installed handler compatibility, enabled environments and operating status. |
| auth references | Logical service identity/connection/policy reference; no credentials in manifest. |

Registration validates duplicate keys, schema compatibility, handler existence, supported host and trusted deploy identity. It publishes a candidate only from an approved service release path. Approval and activation are independent. A newer version does not modify existing runs. The same handler must be reusable directly and through an L2 workflow; do not duplicate it for each application.

## CyberArk scope and sample vocabulary

The source research inventory is preserved under source-reference. It is a candidate catalog, not proof of the installed API version. Reconcile against the actual deployed API/Swagger, approved existing client and platform definitions. Distinguish GetAccount (one identified account) from listing/searching accounts (collection, pagination and ambiguous matches). A String is not automatically a valid Account ID.

Initial categories: Accounts (read/search/create/patch/verify), Platforms (read definitions/conditional fields), Safes (read/validate), and additional operations already approved in the existing inventory. Secret retrieval, password actions, account deletion and Safe administration remain separately governed. Do not expose all vendor endpoints merely because they were discovered.

Account models returned to BOB should contain only needed non-secret properties. The underlying connection, rotation-password retrieval and session authentication remain capability internals. Reuse the existing approved authentication sequence. Cache/refetch only according to its policy, redact credentials, and distinguish API login/session failures from a business rule rejecting an account.

## Reference case A: update four custom account fields

Business inputs are Account ID plus four desired values; the names Owner, BusinessUnit, CostCenter, Application are illustrative labels, not assertions about the deployed platform. The CSV is staged under its owning service and mapped to one typed row request. Kafka can carry that normalized row or an authorized stable reference. Keep batchId, rowId, messageId, correlationId and dedupe key distinct.

The local flow is Get current account -> AMIE compare permitted fields -> Changes? -> PATCH approved differences -> Get account again -> Verify expected changes -> typed outcome. NoChange skips the write. Rejected inputs retain a reason. A timeout after a write creates an unknown-effect state and reconciliation, not automatic failure/retry.

The CyberArk-maintained adapter example uses PATCH for account changes [EXT-CYBERARK]. The installed endpoint's exact payload, per-property add/replace/remove semantics and permissions are source-verification items. Do not turn an update into a full-object replacement. A first GET provides comparison context; it does not prove concurrency safety or force every current field to be sent back. A second GET must be a post-write observation for the same account/target, not reuse of the pre-write snapshot.

The compare rule decides whether and which approved business fields should change. A typed change set carries op/path/value under an adapter-enforced allowlist. Missing, null, blank and explicit remove are distinct. Default policy for omitted updates is preserve; clearing must be deliberate, supported and authorized. Concurrent modification protection uses only mechanisms actually available in the installed API; where conditional write support is absent, document residual race and reconciliation rather than imply atomicity.

## Reference case B: account onboarding

AddAccount may need many values supplied by the request, plus Safe, Platform, and platform-dependent properties. Selecting the operation exposes those requirements dynamically. Safe/Platform lookups may supply or validate them, but selecting a Safe or target is a policy decision, not a fuzzy name match. If several safe candidates or account identities match, require explicit author or runtime decision logic. If platform is runtime-selected, validate all constrained variants or add a runtime typed validation gate before the write. No silent claim that a design-time sample covers every platform.

A lookup result is usable only if its contract is compatible, the target/service scope is correct, it executes on the current path, its result cardinality is appropriate, and its freshness meets the consuming operation's need. A collection of accounts cannot satisfy a single Account input without explicit selection or For Each.

## Email extraction

Reuse the existing Policy Drift code responsible for SMTP transport, HTML report formatting where already implemented, attachments and send results. Extract the reusable primitive without moving Policy Drift-specific decisions into the generic Email handler. The service can expose SendReport/SendMessage according to existing interfaces; the final operation names come from source.

Inputs include approved recipients or recipient-policy reference, subject/template, body or report reference, attachment references, and a logical notification identity. Report/attachment ownership and access are checked server-side; do not allow arbitrary file paths, URLs or credentials from the browser. Sending is an external side effect. SMTP acceptance does not prove recipient delivery. An uncertain send requires a dedupe/reconciliation policy; an attempt counter alone does not provide exactly-once email. Do not resend the CyberArk change because its notification failed.

The first Email operation may remain a single compiled handler. Embedded BOB is available for genuine multi-step Email behavior, not mandatory ceremony for every send.

## API-first and multilingual onboarding

Code-first registration and approved API-definition import converge on the same operation descriptor. OpenAPI supplies useful shape information, but not complete business authorization, idempotency, freshness, or custom-platform rules. An imported route is a candidate until those semantics are reviewed. Restrict origins and methods; no unrestricted URL/method/header proxy controlled by an author.

Other languages use language-neutral registration and invocation contracts. Prioritize the two concrete services; do not build full SDKs for every language before proving them. Publish a conformance example so a Java/Python service can onboard later without changing BOB's business model. Existing Apigee onboarding remains a pre-go-live dependency for required service paths.

## Capability Studio user journey

Connect/reuse approved service -> inspect discovered groups and operations -> review one operation's inputs, outputs, effects and availability -> test with fixtures or authorized DEV data -> submit candidate -> authorized review/activation -> see the same operation in the workflow picker. Keep this within the service detail context. Tabs may be Operations, Local workflows, Rules, Configuration, and Review; do not create a separate page per metadata field.

A service-local workflow library defaults to that capability's L2 definitions and associated rules. Enterprise workflows remain searchable by multiple categories. The capability owner can expose an approved L2 workflow as a callable operation with its own typed input/output contract, without shipping internal function names to authors.

## Acceptance evidence

Prove that two different processes reuse the same account handler; Email uses the same registration mechanism; registration alone cannot execute; invalid manifest/schema/host is rejected; external credentials never appear in UI/XML/audit; new versions coexist with pinned old runs; compatible rule/flow changes require no capability binary rebuild; a new unsupported vendor function still requires a reviewed implementation. Show the actual files changed and before/after API behavior.
