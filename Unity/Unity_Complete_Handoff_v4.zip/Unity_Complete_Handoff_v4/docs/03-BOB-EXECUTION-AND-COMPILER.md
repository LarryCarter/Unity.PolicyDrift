# 03. BOB execution profile and compiler contract

## Current scope, not merely the browser's subset

Retain start/end events, service tasks, AMIE Business Rule Tasks, exclusive gateways and sequence flows, call activities and subprocesses, sequential multi-instance, and durable Kafka outcome waits. Add parallel split/join gateways, intermediate timer catches, interrupting timer boundaries, interrupting error boundaries, and minimum durable human tasks. Provide equivalent supported semantics in central and embedded hosts where host capabilities allow them. A local in-memory host cannot pretend to support a durable wait.

Defer non-interrupting boundary execution, inclusive/event-based gateways, parallel multi-instance, compensation and event subprocesses unless separate implementation evidence changes their status. Pools, lanes, annotations and data modeling need authoring/preservation support, not an invented execution effect. Unsupported draft features must remain identifiable and block execution; never silently become no-op tasks. The full modeling catalog is broader than the runtime profile.

## Compiler stages

1. Parse securely: reject DTD/external entities, enforce size/depth limits, validate XML and namespace/version policy without fetching arbitrary schema URLs.
2. Preserve original document and opaque extensions. Identify known BPMN, Unity extension and native AMIE references. Editing support is not inferred from successful parsing.
3. Resolve stable IDs, scope, sequence flows, data associations, input/output definitions, operation descriptors, rule artifacts and mapping references.
4. Normalize into the existing BOB execution representation or a compatible extension. No new interpreter merely because an example has a different DTO.
5. Validate node support, host eligibility, version dependencies, allowed operations, typed bindings, branch availability, wait correlation, safe failure paths and permissions.
6. Produce a deterministic dependency snapshot, diagnostic list and compiled plan. The diagnostic links to the original BPMN node/field/edge.
7. At activation, recheck deployed versions, environment policies and trust. At runtime, validate actual payloads and authority; design-time checks are not sufficient.

Errors are stable codes with severity, node/field identity, explanation and remedy. Examples: UNBOUND_OPERATION, RULE_ARTIFACT_UNRESOLVED, DATA_SOURCE_UNAVAILABLE, TYPE_MISMATCH, CONDITIONAL_FIELD_UNRESOLVED, UNSUPPORTED_EXECUTION, WRITE_RECONCILIATION_REQUIRED. Draft save/export may remain available while publish/run is blocked. Do not equate zero UI warnings with production acceptance.

## Token/scope model

A run is identified independently of a definition version. Tokens reference execution scope, activity occurrence and branch activation. Parallel joins count the required incoming tokens for the correct activation, not just the first result or a globally shared counter. Nested calls, loop iterations and repeat visits to a gateway must not mix their join state. Commit state transitions with optimistic concurrency and deterministic terminal outcomes. Concurrent responses can advance an activity logically once.

At an exclusive decision, AMIE evaluation occurs as a Business Rule Task; the gateway routes on its typed outcome. It never performs a hidden capability action. Conditions and default paths must be explicit. An enum decision cannot silently become a Boolean Yes/No gate. An error boundary catches a declared BPMN error outcome; not every exception should be mapped to an anticipated business error.

## Timers and interruption

Persist timer due time, timezone normalization and ownership/cancellation state. A timer callback and a successful task outcome may race; one wins the scoped transition atomically. Interrupting a task's workflow path does not prove the external API call stopped. Late outcomes are recorded, correlated and reconciled without reopening a completed scope by accident. Intermediate timers resume after restart using durable state, not a sleeping HTTP request or UI timer.

Duration UI uses amount plus unit and translates to the supported representation. Timeout means a maximum permitted wait; retry delay and scheduled due date are different concepts. Do not offer free text that looks like a working error branch when no BPMN edge/event exists.

## Loops and collections

For Each maps to supported sequential multi-instance for the initial profile. Declare collection type, item variable, item identity, output aggregation and ordering. A zero-element collection may skip the activity; outputs must not be assumed present afterward. A body-produced value cannot satisfy the first iteration's required input without an initializer. Parallel iteration is not implied by showing a collection card. Arbitrary cycles, Repeat Until and advanced loop syntax require verified compiler semantics and bounded-run policy before activation.

## Durable messaging

Persist admission/inbox dedupe and the workflow's initial state before committing the corresponding consumer progress according to the existing broker integration. For remote dispatch, commit pending command + correlation + outbox consistently, then publish. Receiving capabilities validate trusted producer, operation/version/host, request schema and dedupe identity. Duplicate commands replay known outcomes rather than replaying arbitrary writes. The outcome consumer deduplicates before advancing the BOB token.

Keep messageId (delivery identity), businessCorrelationId (business conversation), executionId, activityInstanceId, commandId, attemptId, idempotencyKey and batch/row identity distinct. Correlation groups related events; it is not automatically a uniqueness constraint. A restart is a new run linked to the old one. A retry is a new attempt under a defined logical operation policy. A broker redelivery is neither by itself.

## Operations: pause, resume, cancel, restart

Pause cooperatively at safe checkpoints. Resume the admitted version/continuation after rechecking policy. Cancel prevents further work but cannot erase an external side effect. Restart creates a distinct run and records what is reprocessed. Replay-from-step requires proof that preceding outputs remain available and trustworthy and that target effects can safely be repeated or reconciled. A friendly BE restart button is policy-controlled; it is not an unrestricted instruction to resubmit a destructive request.

## Required regression cases

Parallel branch race and restart; timer-completion race; boundary-error propagation from a nested subprocess; duplicate/lost/out-of-order outcomes; timeout after successful vendor write; cancellation with late result; first/zero/multiple loop iterations; old instance after a new definition activates; lower-host durability rejection; unapproved operation dispatch; missing mapping on one branch; failure outcome with no success object; rule success followed by external write failure. Report the exact supported subset and failing cases. No blanket BPMN-conformance claim follows from an XSD check.
