# 04. AMIE integration, rules and approvals

## Existing AMIE is the authority

The conversation initially described native AMIE XML, while the submitted v4 draft describes native AMIE JSON. Neither establishes the actual serializer without source evidence. Preserve whichever format(s) Matthew's implementation supports; do not translate native logic into invented XML attributes or a new JSON rule language. The handoff's native-artifact reference includes format, engine/schema version, immutable rule identity/version, digest, and artifact location. Format is verified by an adapter, not guessed from a filename.

The offline prototype's comparison/normalization functions and any JSON shown in its preview are fixtures. They demonstrate UI behavior, not the production AMIE evaluator. This is an explicit outstanding blocker for real import/activation, not a reason to halt UI and contract development.

## AMIE catalog and authoring

Rules can be grouped by service/capability, multiple business categories, and rule family: eligibility, classification, validation, mapping, routing, approval policy and notification policy. Avoid a mandatory application/workspace gate. Display description, input facts, output outcomes, approved version, maturity, consumers, and review history. A larger searchable popover is appropriate for inspecting a rule; a small dropdown cannot adequately describe complex logic.

Selecting a Business Rule Task in BPMN opens the same rule in context. Facts map through the same binding graph used by Data view. Changing a rule version preserves the task ID and compatible mappings, flags incompatible ports and invalidates prior test evidence. Editing a shared approved rule starts a draft; it does not mutate all consuming workflows. A workflow-local edit needs its own release-supported native rule artifact or an existing AMIE local-parameter mechanism, not an untracked hidden script.

The visual editor may use decision tables, conditions and expression forms supported by the real engine. It must preserve precedence, defaults, missing/null behavior and output types. Raw native content is an optional advanced view; syntax validity alone is not semantic validation. Do not force general UML state diagrams or DMN conformance into AMIE.

## Rules between mapped fields

For a pure compatible rule, the author selects a connection or target field, opens its three-dot menu, chooses Insert rule, examines required facts, and confirms. The command inserts an explicit BPMN Business Rule Task, connects source -> rule input -> rule output -> original target, and rewires control flow on a valid path. One Undo reverses all changes. The original parent-object mapping remains; the selected child becomes an override. Removing the rule can restore the source after type/availability checks.

A multi-fact, multi-output or side-effecting rule does not fit a compact single-value slot. Open a normal Business Rule Task fact mapper instead. The UI must show when required additional inputs are missing. Never execute the rule both as a data transformation and as a BPMN task.

## Initial intake and future ownership correction

Retain the current AMIE intake behavior for the first delivery: inspect/classify/enrich the request, select an approved workflow, and send it to BOB's intake. BOB independently admits the selected workflow/version and owns execution, waits and recovery. If source review finds AMIE maintaining overlapping durable orchestration, record it and implement a compatible correction in the next phase. Do not force a broad rewrite of functioning intake as a prerequisite to the first CyberArk/Email increment.

Use a typed decision envelope carrying workflow selection, rule/version evidence, normalized facts or approved reference, reason codes, original identity and correlation. A decision may reject, route, enrich, or request more data; it cannot bypass a production entitlement or activate an unapproved operation.

## Approval policy and execution

AMIE determines whether approval is needed and emits a typed approval plan. BOB creates and persists human tasks and stages. BE displays only tasks the user is eligible to act on. The authorization boundary validates every decision independently of a visible button. Multilevel stages are ordered; initial stage semantics are AnyOne and AllRequired with multiple eligible approvers and approved backup groups. Backups do not double-count an individual, override rejection policy or silently expand privileges.

Persist task identity, stage revision, eligible groups/policy snapshot, claimant where applicable, decision, reason, actor, timestamp and completion evidence. Concurrent approvals must not advance the stage twice. Define rejection, expiry, cancelled request, late response and changed entitlement behavior. Four-eyes/separation policy comes from existing governance and AMIE, not a hardcoded UI job title. Self-approval must be checked where policy forbids it.

Future ServiceNow approval integration is a capability/adaptor, not replacement of BOB's task state. Initial production changes require a nonempty ServiceNow reference, without external ticket-status validation. The reference is traceability, not independent approval proof.

## Rule tests and user explanation

Each published rule needs fixtures for matched, unmatched, boundary, missing/null and invalid-type inputs. The trace identifies rule/version and facts used, not only a Boolean result. Mask sensitive values and show business reason codes. The user should be able to inspect why an account was skipped without reading C# or knowing Kafka. Preserve available existing AMIE traces rather than build a competing trace format.
