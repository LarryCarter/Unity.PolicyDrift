# 07. XML, XSD, native artifacts and preservation

## Format authority

BPMN 2.0.2 XML stores process semantics and standard DI. Use native data objects, item definitions, input/output specification and data associations where appropriate. Unity extensions express typed operation bindings, fine-grained field paths, shared-contract metadata, source adapters, mapping semantics and contextual-view layout not covered by native elements. AMIE rule logic remains in its verified native artifact; BPMN stores rule location/reference/version and fact/result binding.

BPMN provides sanctioned extension locations [EXT-BPMN]. An XSD validates allowed structure; it does not teach a renderer which object card to draw, enforce workflow authorization or define all execution semantics. Each extension must have a schema rule, semantic validation rule, UI command and runtime owner. No imported schema URI is automatically fetched/executed.

## Storage and versioning

Drafts may use an in-memory graph/JSON projection for editing, but BPMN XML plus its native dependencies is the portable source artifact. Ordinary workflow mappings are serialized with the workflow and versioned as part of it. A read-only compiled cache may have its own digest/compatibility marker without becoming a competing editable source. Mapping recipes expand into explicit workflow content unless a deliberately pinned shared dependency is chosen.

Schema namespace version identifies tooling grammar, not a new independent business approval for every field. Old workflow versions remain immutable; a compatible edit creates a draft/new release. Existing source contracts take precedence over the proposed prototype namespace after documented reconciliation.

## Proposed extension surface

The runnable demo retains its tested v3 activity/type/field mapping profile and adds a clearly named v4 entry-configuration extension. The extension is a review profile, not the enterprise contract. A generated v3 request summary is a compatibility projection of the one v4 shared contract; import rejects disagreement. Production should converge on one verified schema model rather than maintain independently editable duplicate declarations.

| Concept | Native BPMN | Unity/native addition |
|---|---|---|
| Process order | sequenceFlow, events, activities, gateways | No hidden order inside a data wire |
| Operation call | serviceTask and input/output definitions | Approved operation/version/host reference |
| Business evaluation | businessRuleTask | Native AMIE rule reference/digest, fact/result binding |
| Whole object availability | dataObject/itemDefinition/dataAssociation | Schema/semantic identity, outcome guarantee, field projection |
| Field override | Relevant native association retained | Source/target stable field refs and explicit override/transform policy |
| Entry launch | Supported start event/admission path | Independent trigger bindings, source schema and normalization mappings |
| Data-context layout | BPMN DI for BPMN geometry | Object-card expansion, positions and selected context; presentation only |
| Workflow classification | Optional standard documentation/grouping | Multiple business-category references, no implicit access grant |
| Observability | Process/activity identities | Approved logging/audit policy references, no arbitrary table destination |

`schemas/unity-entry-v4.xsd` describes the demo entry configuration. `schemas/unity-modeling-v3.xsd` is preserved to validate the inherited modeling layer. These schemas do not replace native AMIE, the BOB compiler or the future production extension contract. Examples under examples/ are flagged non-executable review artifacts.

## Native AMIE preservation

A release dependency record describes ruleId/version, media type (`application/xml` or `application/json` as actually supported), engine/schema version, content digest and immutable location. Preserve bytes for opaque native artifacts until the real adapter can parse/serialize them. CDATA is a storage convenience, not a JSON validator, executable trust or a promise of original bytes. External artifact files with digests are preferable for clear integrity and reuse. Do not author a fake AMIE rules file and call it native.

An imported native rule that cannot be interpreted remains retained with a blocker. No activation until the verified adapter validates both syntax and semantics. User editing in raw mode affects a draft and invalidates prior evidence; it never mutates a shared approved artifact in place.

## Lossless has three separate meanings

**Byte preservation:** retain the original upload unchanged for evidence/rollback. **Model preservation:** save/export retains known executable meaning, IDs, references, layout and unknown content without dropping it. **Editable support:** the UI can safely change a declared subset. These are not equivalent to universal execution support.

An incomplete but supported document loads with an actionable checklist: unbound capability, missing form mapping, unresolved native rule or unsupported host. Unknown extensions and unsupported topology must be preserved in a restricted/read-only envelope if safe editing cannot be guaranteed. Export original remains available; execution stays blocked. Never flatten unknown content into the nearest supported task.

The demo demonstrates editable round-trip only for its documented structured profile. It also provides an explicit preserved-original path for other safe XML. That path does not claim editable or executable semantic support. Production needs an AST/DOM preservation layer, migration registry, namespace handling and fixture suite before claiming general lossless editing.

## Mapping source of truth and consistency

Changes from Process, Data or Rule view enter the same command store and update one binding graph. Native associations and extension field mappings are generated together. Validate they reference real ports and do not disagree. A hand-edited XML file that changes a native flow but leaves a contradictory extension must be diagnosed, not resolved by secretly preferring whichever representation is convenient.

When native BPMN or DI cannot represent the richer visual details, store presentation metadata under a distinct extension. Changing theme or zoom does not alter execution semantics. Stable element and field IDs survive rename, movement, rule rebinding and view switches. Graph layout is not the control-flow ordering algorithm.

## XML security and validation levels

Reject DTD/entities and externally resolved resource references; use local allowlisted schemas. Apply archive traversal, compressed-size and expansion limits to packages. Check XML parse, Unity XSD, official BPMN XSD, native cross-references, typed semantic compilation, host/security admission and actual runtime execution independently. A green extension-schema result does not prove the full BPMN file validates or executes.

The supplied QA scripts distinguish these results. Official OMG XSD validation requires an approved local complete bundle including BPMN20.xsd, Semantic.xsd, BPMNDI.xsd, DC.xsd and DI.xsd. External retrieval was unavailable in this build environment; no full-standard validation result is asserted. The exact command and failing/skipped status are documented instead of substituting a homemade BPMN schema.
