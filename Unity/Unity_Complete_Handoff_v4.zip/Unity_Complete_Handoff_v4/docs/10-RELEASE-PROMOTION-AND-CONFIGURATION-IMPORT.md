# 10. Release, promotion and configuration import

## Three environments, one tested content set

DEV authors and tests. UAT imports and validates pre-production behavior. PROD imports and activates through authorized groups. There is no separate TEST environment in the current plan. Environment connection references may resolve differently, but approved workflow/rule/mapping content remains immutable. Avoid editing the production BPMN to change a host URL; use reviewed environment bindings outside business logic.

A release package contains BPMN XML + DI + workflow-owned Unity mappings/entry declarations; native AMIE artifacts or immutable verified references; operation/contract dependency lock; test evidence references; approved environment-binding/configuration references; manifest and integrity/trust material. Actual package extension/naming follows enterprise tooling. The offline demo export is unsigned and marked non-executable; it is not that release.

## Promotion sequence

Save draft -> validate full compiler profile -> run fixture and authorized integration tests -> submit review -> produce immutable candidate with content digest -> import into UAT -> record acceptance evidence -> authorize production change -> PROD import/preflight -> separately activate -> monitor. Do not make Import itself execute a workflow or change active definitions.

Production requires trusted artifact origin/integrity, compatible deployed handlers/rules, validated BPMN and Unity semantics, no unauthorized experimental features, approved environment/group bindings, required review policy, and a nonempty ServiceNow ID. Initial implementation stores the ID and optionally a safe ticket link; it does not call ServiceNow or imply status is approved. The production authorization is from platform controls and AMIE policy, not the presence of the ticket string alone.

## Cryptographic trust and the requested key

The user asked for an approved key/protection mechanism so arbitrary XML cannot go live accidentally. Implement trusted signing/verification or an already-approved enterprise equivalent. A reusable secret inside the uploaded file is not that protection: it can be copied with the artifact. Keep signing private keys in approved infrastructure. Production trust is configured independently; an attacker-supplied public key in the archive cannot authorize itself.

If the required production trust mechanism is unavailable on day one, keep production activation blocked or use the explicitly approved existing release path. This must not block building/import-testing in DEV/UAT. Record the missing mechanism as a pre-go-live story, not a hidden future enhancement.

## Group and environment configuration imports

Use the same preflight/approval/activation pattern for group references, resource entitlements, rules and connection bindings. Preview additions/removals/privilege increases; reject incompatible environment roles; preserve stable IDs and descriptions. EF migrations create owned schema structure; environment configuration imports populate real approved references. Do not seed fake AD memberships or execute privilege changes from a sample file. Names containing Prod/Non-Prod help human review but do not replace verified scope.

## Rollback and in-flight instances

Reactivation of an older approved release controls new starts. Existing runs retain pinned definitions and rule/operation versions unless a separately reviewed migration explicitly moves them. Availability of old handler versions must be checked before rollback. Rollback of configuration does not undo a CyberArk write or delivered email. Such external effects require reconciliation or an explicitly supported authorized reverse operation; generic compensation remains deferred.

## Release UX

Display package identity/digest, native rule format status, required dependencies, environment diff, experimental flags, evidence and required change reference. Distinguish Parse OK, Schema OK, Executable OK, Approved and Active. Each failed gate links to a specific node/configuration or owner. The operator can import a quarantined/review-only package without activation where policy permits. Unsafe/unknown content is not silently normalized into an executable approximation.

## Negative tests

Changed byte after approval; wrong signing identity; missing trust chain; missing ServiceNow ID; unauthorized actor; non-production group mapping in PROD; missing operation version; unknown required extension; unresolved rule format; unsigned fixture; environment URL substitution outside approved binding; zip-slip/path traversal; duplicate manifest members; missing artifact hash; package exceeding limits; rollback missing old handler; in-flight version changes. Record exactly which gates were exercised in DEV/UAT and which depend on enterprise integration.
