# 15. Configuration and user guides

## G01 - Capability owner: expose and review an operation

Open Capability Studio for the service, not a generic global workflow list. Reuse the approved connection/code registration. Review discovered service/group/operation descriptors. Choose one operation, inspect its typed input/output/effect/host, and identify any missing business semantics. Run an authorized fixture/DEV test. Submit for review. An authorized reviewer approves the specific version and permitted environment; activation remains separate. Confirm the same descriptor now appears in the workflow picker. A missing handler/version is an integration blocker, not a UI permission fix.

## G02 - Author: create an entry contract from a CSV

Create/select workflow -> Define -> add CSV launch binding -> select approved landing/staging source and parser settings -> Data Contract -> Paste / Upload Sample -> inspect columns/types -> choose normalized field targets or add business inputs -> protect deliberate edits with locks -> Apply -> preview normalized records and fix errors. Confirm that mapped source columns satisfy required fields. Save the source configuration with the workflow revision. Missing data produced later by an activity is not added to the incoming CSV contract just to make a warning disappear.

## G03 - Add Kafka or API as another launch method

Keep the shared normalized contract. Add another binding, configure approved transport and authentication, and map body/key/header/path/query fields to the existing stable field IDs. Configure dedupe and business correlation independently. Test a representative message/request. An incompatible source mapping is flagged; changing source type does not erase the schema. Confirm that the same business process receives equivalent normalized data.

## G04 - Scheduler-driven ingestion

Choose existing AutoSys/Cron binding and timezone. Inspect run context. Add an ingestion activity using an approved file/data/API source. Bind the intended scheduled date or other context value through a constrained parameter. Configure no-source and failure behavior. Use the same Sample Importer on the ingestion output contract. If results are a collection, configure supported iteration and item scope before consuming a single record. Verify lineage shows business data beginning at ingestion, not at the schedule start.

## G05 - Build the CyberArk custom-field update

Use an account-row request. Add/choose Get current account. Bind its Account ID from the normalized request. Select the existing AMIE compare rule and bind current account plus desired fields. On a changed outcome, invoke the approved patch operation with the allowed change set. Add a fresh Get Account and verification rule. NoChange ends without write; mismatch/not-found/unknown outcomes are explicit. Add Email at the appropriate enterprise process boundary using sanitized result/report data. Reuse the same primitive in another workflow to prove the abstraction.

## G06 - Repair a missing model in one click

Select Compare and inspect Missing current account. Review the proposed Get Account and incoming ID. If the action is unambiguous, click Add Get Account and Connect. Observe the inserted BPMN task and resolved object mapping without leaving the activity. Undo/Redo restores all graph and mapping changes together. Multiple identities, wrong host or an existing eligible producer change the offered action; the UI never guesses a privileged target.

## G07 - Insert a rule into a mapping

Expand target desired.Owner, open its three-dot/right-click menu and choose Insert rule. Inspect its facts/results. Choose a compatible pure rule and insert. Observe the rule card and matching BPMN Business Rule Task. Edit its draft parameters through the verified AMIE editor in production (fixture editor in the demo), preview, then test. Retain other inherited object fields. Removing the rule and reconnecting must revalidate the original source.

## G08 - Configure onboarding

Select Add Account from CyberArk/Accounts. Supply request fields and inspect unmet requirements. Resolve Safe and Platform through authorized request/configuration/lookup sources. Apply selected-platform requirements; if selected at runtime, constrain possible platforms or validate dynamically before creation. Configure business rules, approval need and error behavior. Do not pretend an account's full current object exists before it has been created.

## G09 - Approval user

Open My approvals in the authorized BE view. Inspect business request, relevant redacted data, current stage and requested decision. Approve/reject with required reason; the backend rechecks eligibility and stage revision. A backup acts only under configured policy. A stale or already-decided task is explained rather than silently accepted. View resulting status/history without acquiring designer or capability-admin rights.

## G10 - Operator and release user

For a failed run, inspect the technical outcome and uncertainty before replaying anything. Pause/cancel/restart only through approved commands. For release, import the reviewed package, inspect digest/dependencies/environment diff, provide the required change reference and complete approvals. Activate separately. Verify new starts use the activated version and existing runs remain pinned. Retain rollback evidence and never mistake a configuration rollback for reversal of vendor effects.

## G11 - Administrator

Maintain real group references/descriptions and scoped resource-role mappings through existing mechanisms. Review effective access, production/non-production scope and AMIE restrictions. Manage approved connection references and capability statuses. Import environment configuration through the same controlled mechanism; avoid fictional seed memberships. Categories are searchable classification, not security. Record every privilege-changing action with its authority and before/after evidence.
