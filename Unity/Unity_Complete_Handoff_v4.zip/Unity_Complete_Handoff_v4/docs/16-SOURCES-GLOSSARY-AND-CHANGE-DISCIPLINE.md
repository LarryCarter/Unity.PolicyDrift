# 16. Sources, glossary and change discipline

## Source basis and precedence

The current user conversation is the approval record for product decisions. The exact supplied v4 draft is retained verbatim as `source-reference/USER-V4-PROPOSAL.txt`. The earlier canonical v2.2 archive contains the prior platform handoff and historical assets; the v3 archive contains the actual editable modeling prototype. The new current specification integrates the decisions rather than asking Devin to read conflicting historical jobs. Source hashes are recorded in `source-reference/source-checkpoint.json`.

Earlier generated specifications are not evidence that code exists. The user-described existing AMIE, auth/groups and services must be verified in the repository. Readiness and implementation status remain explicit. The complete original archives are retained for traceability, not as a second implementation instruction set. Matthew's separate questions are deliberately excluded from consolidated Ask content; the relevant integration constraints are fully stated in the current normative sections.

## Public references used only to verify narrow technical distinctions

- **EXT-BPMN:** OMG, BPMN 2.0.2 machine-readable file index: https://www.omg.org/spec/BPMN/machine-readable and https://www.omg.org/spec/BPMN/2.0.2 . This establishes the official schema bundle location; it does not prove Unity's conformance. Access checked November 20, 2026.
- **EXT-KAFKA:** Apache Kafka consumer configuration, `auto.offset.reset`: https://kafka.apache.org/40/configuration/consumer-configs/ . Used to distinguish initial/out-of-range offset behavior from an explicit replay command. The deployed broker/client version remains unverified.
- **EXT-CYBERARK:** CyberArk-maintained account adapter source: https://github.com/cyberark/ansible-security-automation-collection/blob/master/plugins/modules/cyberark_account.py . Used as a primary implementation example of account PATCH construction, not as a substitute for the deployed CyberArk API contract. The prior supplied research inventory remains a reference only.

No outside source changes user-approved architecture automatically. Public technical facts and proposed safety clarifications are separated from source-derived requirements in the reconciliation table. Official XSD download was not available to the local validator in this environment; that gate is explicitly not run.

## Glossary

Capability service: registered provider/ownership boundary. Operation: typed reusable callable primitive. L1: enterprise process. L2: capability-owned local process on the same BOB core. L3: compiled/adapted operation. Trigger: how a start signal is admitted. Source schema: raw input shape. Shared contract: normalized field model consumed by the process. Binding: source-to-target data relationship. Hydration: acquisition of required context during execution. Lineage: identity/provenance/transform/consumer path. Recipe: reusable authoring template, not a new runtime language. Business Rule Task: explicit BPMN activity invoking AMIE. Contextual zoom: deeper editing while the BPMN selection/scope stays visible. Readiness: scoped validation status, not production approval. ReleaseReady: development stage, not activation. Unknown effect: an external write may have happened and must be reconciled.

## Change discipline

A change to a material decision updates rationale, model contract, screen command, serializer/XSD mapping, runtime owner, test and milestone story together. Do not hide the change in a new ZIP or a precedence sentence. Use an explicit supersession record stating what changed, why, user authorization, compatibility, migration and evidence. Actual source incompatibilities are proposals until reviewed. Maintain a small field/schema migration registry rather than rewriting every previous artifact.

The master and Ask aliases are generated from the same ordered current Markdown sources. Never hand-edit one alias. The manifest records included/excluded files and SHA-256 digests. Content changes invalidate the old manifest and QA report. A package is complete as a handoff when its current requirements, source assumptions, demo scope, unresolved work and acceptance evidence are all present; that is not a claim of completed production implementation.
