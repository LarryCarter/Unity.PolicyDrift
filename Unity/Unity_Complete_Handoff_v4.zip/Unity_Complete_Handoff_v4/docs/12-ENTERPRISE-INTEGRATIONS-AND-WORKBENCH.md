# 12. Enterprise integration readiness and API workbench

## Required work is tracked now, not invented or postponed indefinitely

The user clarified that enterprise integration is needed before go-live, even while developers use existing local mechanisms. Some integration work may already be complete. Every entry starts Existing - Verify, Partially Implemented, Awaiting Requirements, Ready for Integration or Verified only when evidence supports it. Do not create duplicate stories or replace existing components merely because their details are absent from this conversation.

| Integration | Facts/decisions retained | Required evidence before production |
|---|---|---|
| Channel Secure | Handles SAML SSO and entitlements; requested in parallel; reuse Matthew's current setup during development | Claims/group mapping, session lifecycle, environment grants, unauthorized tests and regression evidence |
| Apigee | Department APIs may require service onboarding and declared service-account access | Approved route/policy, request limits, credential integration and correlation/error behavior |
| Splunk | Structured logging/trace/audit visibility is required | Forwarding path, indexes, redaction, search by run/step and operational alerts |
| AutoSys | External scheduler can launch through an approved adapter | Job/box ownership, execution-context payload, overlap/misfire handling and status feedback |
| Cron | Supported scheduling source, not a second implicit workflow runtime | Scheduler owner, timezone/DST/misfire/overlap policy, durable trigger admission |
| NAS / owned Data capability | User describes CSV landing/staging and data access | Exact meaning and existing owner/API, permissions, completeness, row identity, paging and read results |
| Other enterprise dependencies | Keep explicit placeholder, owner and decision date | Go-live relevance, contracts/access and acceptance test |

NAS has been used ambiguously in earlier drafts as both file storage and a named data capability. Preserve the user's file/staging scenario without assuming a new external API. Confirm what the actual system provides and keep file access behind its owning adapter.

## Dependency tracking fields

Integration ID; milestone/story; business outcome; existing ticket reference if supplied; technical/business owner (unconfirmed when unknown); existing implementation path; missing requirements/access; target environment; test fixtures; go-live blocking status; evidence and last verified time. No invented Jira keys or completion percentage. A requirements gap remains visible even if a demo uses mocks successfully.

## API capability workbench

The original requirement remains: deploy the service once, then test different approved API payloads, expressions and call chains without repeatedly redeploying for each request edit. Reuse the existing rotating credential/session sequence securely. The author can choose an approved operation, supply a typed sample/model/CSV mapping, run an authorized DEV test, inspect redacted output, bind that output to another call, and compare assertions/results. An arbitrary Internet HTTP proxy is not the workbench.

Use the same registry descriptors, schema controls, AMIE adapter, BOB local composition and trace vocabulary as production workflows. The workbench is a sandboxed authoring/test surface. When a useful chain is saved for reuse, expand it into a supported L2 workflow with typed contract, dependencies and tests; do not introduce another proprietary recipe execution language.

Examples: Get Account -> compare four fields -> patch approved differences -> verify; authenticate internally -> get accounts -> inspect typed response; CSV row -> account lookup -> rule -> report notification. Report/CSV export must mask sensitive fields. A fake success result or sampled response is labeled Mock. Running a real operation requires explicit environment and scope; potentially destructive requests need the relevant approval/safe test target.

## Workbench acceptance

Change a sample request without redeploying code; reuse approved authentication without copying credentials into the UI; chain output into the next operation; show type mismatch before run; distinguish mock and real DEV call; persist a reusable test definition without secrets; correlate failures; prevent arbitrary URLs/SQL/class names; prevent inadvertent PROD usage; reuse the successful flow in BOB with equivalent outcomes. Existing services and external permissions still need their ordinary onboarding/deployment processes.
