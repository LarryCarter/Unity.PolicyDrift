# 11. Observability, audit and operational views

## Three different consumers

The BE business portal answers: What did I request? What is running? What succeeded, failed or needs attention? Can I see my group's results? Modeling Studio answers: What is the program? What data/rules does it use? Can I test and publish a changed definition? Ops Diagnostics answers: Which attempt failed? What is its technical cause? What can safely be retried, reconciled, paused or cancelled? Do not put BPMN/UML editing controls in every business user's job list.

These are entitlement-filtered views over common identities and projections, not new independent workflow databases. The offline persona switch only demonstrates navigation; it is never evidence of RBAC enforcement. Server APIs must recheck identity, environment, resource and effective policy for every operation, query and streamed event.

## Business portal

Show friendly process name, execution reference, submitted time, requester, approved group scope, state, progress/counts with definitions, recent activity, outcome and report links. Distinguish Queued, Running, Waiting for approval, Waiting for outcome, Paused, Completed, Failed, Cancelled and Needs reconciliation. A batch's total, processed, skipped, rejected and failed counts must reconcile under a declared counting policy. A workflow waiting normally on a timer is not necessarily stuck.

Execute-Lead can see only the configured group's runs/results. Department is a label, not a blanket access rule. Read scope must be explicit for reports; exports and attachments receive the same server filtering as the grid. On reconnect, fetch an authoritative projection snapshot and resume event updates by sequence; do not trust only a browser's missed stream history.

## Ops diagnostics

Provide the execution, scope, task occurrence, attempt, correlation, operation/rule versions, message/command identity, last checkpoint, timer, retry schedule, typed error/outcome and redacted input/output evidence. Clicking a failed step navigates to the same BPMN activity; it does not mutate the definition used by that run.

Safe controls include requested pause/resume/cancel and reviewed restart/reconciliation. Replay-from-step is not enabled solely because the UI has a button. The backend must verify previous data availability, external side-effect status, environment grants and idempotency/reconciliation policy. A new run links to the old one; the old audit is retained. DLQ management requires authority and a specific replay reason, not a generic resend-all command.

## Durable audit design

Write audit/evidence from admission onward, independently of Kafka retention. The submitted draft's four-day broker retention is an unverified environment value; never wait until four days expire before persisting evidence. Broker retention/compaction/configuration and data arrival times do not guarantee an exact per-record countdown. UI may show configured policy and uncertainty, not fabricated expiry precision.

Minimum event attributes: immutable event ID; UTC observed time; environment; workflow/version/digest; execution and parent execution; scope/activity/attempt; initiator identity reference; service execution identity reference; event kind; business outcome/reason; correlation/message/command/idempotency references; artifact/approval/change references; redaction/classification; integrity metadata where required. Store searchable indexed envelope columns plus governed JSON details through the audit owner. Actual table names and EF mappings must be reconciled with existing `uty_audit` objects.

Diagnostic logging is configurable within policy; mandatory security/release events cannot be disabled by a workflow flag. Authors select an approved audit profile/sink, never arbitrary database/table/SQL. Do not retain raw passwords or secret-bearing API responses. Sensitive sample data has its own access/retention policy. Redaction must apply in traces, exports, exceptions, logs and support tools.

Define retention, purge/legal-hold requirements, volume, backpressure and failure mode with the bank's owners. Durable audit failure may block sensitive actions under policy; never silently drop mandatory evidence. Projection rebuilding and long-term report generation must not rely on messages that may already have left Kafka.

## Test-stage audit preview

The local fixture runner shows events at the same activity IDs as the designer. It can preview a redacted audit record and feed the demo business/Ops views. That record is explicitly local browser evidence, not a write to the enterprise audit database or Splunk. Acceptance of real telemetry requires an integrated run and persistence/query verification.
