# 06. Triggers, shared contracts, samples and two-stage ingestion

## The separation that fixes the clutter

A Trigger Adapter determines how a process wakes up. A Shared Schema Contract describes the information the workflow consumes. Sample provenance records what was inferred, from which authoring source, and which fields the user subsequently locked. Source-to-contract bindings connect the adapter's raw message/columns to normalized fields. The UI has two tabs, not four permanent editors: Trigger and Data Contract. Sample Importer and Field Detail open only on demand.

Multiple configured launch methods can target the same workflow. Each validates its own extraction against the admitted contract. Switching adapter type does not erase the schema, silently remap sources, or create another business process. Configuration can reference a centrally governed connection, endpoint or scheduler; an author is not necessarily authorized to provision it.

## Kafka: mechanics, gate, extraction and admission

Trigger tab: approved connection reference; topic/subscription identity; consumer group/ownership; initial offset-reset policy; payload decoder/schema reference; message gate; business correlation extraction; dedupe extraction and scope. Passwords/certificates are managed through approved connections, not pasted into the inspector.

Gate input may come from a decoded payload field, header or verified schema identity. A Schema Registry subject/version is not interchangeable with a numeric wire schema ID. A topic is transport, not a business type. A malformed decoder/schema mismatch must fail or quarantine under explicit policy before the business gate is evaluated. An unmatched gate is a recorded non-start, not necessarily an error or a new run.

Correlation describes a business conversation. Idempotency identifies a logical admission/write. They may coincide only under a declared producer contract. Persist dedupe state before advancing consumer progress. Two workflows using the same consumer group may compete for deliveries; the subscription owner must choose shared-dispatch versus independent subscriptions deliberately. Do not create consumer groups casually from each UI tab.

Offset reset applies when a valid committed position is absent/out of range, not a command to replay every existing message each time [EXT-KAFKA]. Expose replay as a distinct governed operation. Confirm topic retention and compaction policies; a displayed four-day example is not a guaranteed message expiry timestamp.

## CSV/file input

Trigger tab: authorized connection/directory/bucket reference, file mask, delimiter, header mode, encoding and completion detection. A file-created event is not proof the file is completely written. Ownership must define atomic landing/rename, marker or another reliable completeness mechanism. Define no-file, malformed-file, duplicate-file, duplicate-row and partial-row policies separately.

Data Contract tab: shared fields and bindings to source column name/index. Paste/upload sample supports quoted delimiters, escaped quotes, CRLF, BOM, empty cells, duplicate headers and uneven rows. Preview representative records and inference warnings. Leading-zero identifiers must not become integers silently. A headerless sample requires explicitly named source columns. A changed column order is detected by stable name where available; ordinal fallback is explicit.

The intake flow can stage a file on NAS, persist rows under its data-owner service, and emit one normalized record/request or stable row reference. It may also use a batch request with declared page/iteration semantics. A CSV file is not automatically one account. Preserve file/batch/row IDs and mapping version so the result can be traced back to the source row. A bad row is handled according to chosen policy; do not silently discard it or stop all rows without explaining the configured behavior.

## API and BE forms

API/webhook transport includes approved route/method/auth mode/content type and request size policy. Source bindings distinguish body, path, query and headers. Authentication/authorization remain server-side. An OpenAPI snippet can seed a candidate schema, not grant an endpoint or connection.

BE forms use the existing form/auth stack. Form fields can be generated from or mapped to a shared contract, with constraints and friendly labels. Persist the submitted request under the owning service and publish a durable start command according to the platform path. A form's convenience client validation does not replace server validation. Inferred fields from example JSON or an existing DTO must be reviewed. HTML/DTO parsing is a proposed extended importer, not arbitrary code execution.

## AutoSys and Cron: two-stage data introduction

The initial output is RunContext: runId, jobName, scheduledUtc, scheduledDate, timezone, and approved static parameters as applicable. The scheduled date is calculated using the declared business timezone; retain UTC timestamp separately. Actual start/late execution time must not silently replace intended scheduled time. DST and misfires need an explicit scheduler policy.

AutoSys identifies an existing job/box/invocation configuration. Cron identifies a schedule and timezone owned by the chosen scheduler integration. Do not run the same schedule in both without deliberate dedupe ownership. The UI configures a binding; it does not claim to deploy AutoSys jobs.

The next activity, such as Ingest CSV or Read Data API, consumes run context and emits a new Business Data Contract. Example: run.scheduledDate fills an approved path parameter, then ingestion outputs ingest.records or an item-scoped ingest.record. The universal field grid and Sample Importer are reused for this output contract. Data becomes available after that producer succeeds; run.* and ingest.* must not be collapsed into a fictitious incoming payload.

A dynamic path/URL uses constrained typed bindings through an approved source, not arbitrary String concatenation. Prevent traversal and unauthorized destinations. A SQL-related option means a parameterized owner-managed query capability, never arbitrary SQL entered into BOB/BE. Missing file options are fail, explicit skip outcome or bounded retry; do not invent success data after a skip.

## Sample-to-Schema interaction

1. Open Paste / Upload Sample; choose format or inspect detection. No raw sample box stays on the main inspector.
2. Parse within size/depth/row limits. Produce candidates, sample values, detected nulls, warnings and proposed types. JSON recursive objects/arrays and Avro schema input are different parsing modes; an Avro schema is not a runtime record example.
3. Review each candidate. Select additions/updates, rename normalized fields, choose conversions, and inspect source bindings. Inferring all rows have a value does not prove `required=true`; absence in a sample does not prove an optional contract never includes it.
4. Apply a previewed merge atomically. Preserve stable IDs and locked manual changes, add approved new fields, retain omitted existing fields until explicitly removed, flag type conflicts rather than widen destructively. No re-inference deletes downstream mappings by accident.
5. Validate examples against the accepted contract, save and expose the resulting fields to lineage. Sensitive raw samples are not required production artifacts; apply redaction and retention controls.

Field Detail edits type, semantic identity, required/nullable, default policy, enum/pattern/range, sample and per-adapter source binding. Default values must be typed and validate; a blank default field means no default unless explicitly selected. Locked protects against automatic sample merge, not authorized manual editing. Root array shape and item type must be explicit; an empty array cannot identify the element model.

## Required acceptance fixtures

CSV with quoted comma and newline; leading-zero account ID; header rename/reorder; duplicate headers; non-UTF8 encoding declaration; all-empty column; mixed type column; nested JSON and array of objects; empty array; JSON null versus missing; Avro nullable union and logical type; forbidden recursive/unsupported schema; locked field changed by a sample; sample omitting an existing field; Kafka body/key/header mapping; API path plus body; scheduler context followed by ingestion; no-file retry exhaustion; run.* cannot be mistaken for account data.
