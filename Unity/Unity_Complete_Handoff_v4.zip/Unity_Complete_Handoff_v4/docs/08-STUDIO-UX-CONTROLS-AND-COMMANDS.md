# 08. Studio UX and command contract

## One journey, progressively deeper layers

Define -> Build -> Test -> Release remains the primary workflow journey. Do not implement the older 55 screen sketches as 55 mandatory authoring routes. They are historical coverage evidence; their useful functions are consolidated here. Keep task-focused business views and privileged administration separate from routine authoring.

Define names the workflow, description, multiple categories, owner/contact metadata where applicable, contract and independently configured entry adapters. No required Application workspace. Build combines guided steps/BPMN with contextual Data and Rule detail. Test uses supplied fixtures or separately authorized DEV integration tests. Release reports evidence and produces a governed artifact; exporting is not activation.

## Entry inspector contract

The selected Start/entry binding opens two tabs: Trigger and Data Contract (Run Context for a scheduler). Trigger shows only source-specific mechanics and gates. Data Contract shows a compact field grid with Add Field and Paste / Upload Sample. Clicking a field or Edit opens a detail slide-over; closing returns to the same field row and scroll position. Sample Importer is an on-demand overlay with detection, preview, locked merge and Apply/Cancel. Existing context is not destroyed.

For scheduled ingestion, reuse the same grid/importer under the ingestion activity's Output Data Contract. Source Config contains bound path/API arguments and no-file/failure handling. A schedule is not silently converted into a CSV transport by selecting a sample.

## Contextual modeling

Select a BPMN activity -> inspect its inputs -> zoom into objects/fields -> inspect or insert a rule. The enclosing BPMN strip highlights the current activity and displays branches. Breadcrumbs identify workflow / subprocess / activity / field. Clicking a rail node moves context; Back returns without duplicating state. Advanced whole-workflow lineage opens on demand; it is another projection of the same mappings, not another application.

Use blue for available data, violet for AMIE/transformation, teal for target input; amber for conditional/review and red for blockers. Labels/icons accompany color. Light/dark switches are preferences and do not bump workflow revision. A small-screen layout preserves keyboard access and avoids inaccessible offscreen dialogs; full graph authoring may require a larger viewport but must say so honestly.

## Basic editing must not regress

Every step has a real three-dot menu, right-click equivalent and keyboard path. Menus contain only actions applicable to the current object: configure, change binding, insert before/after, duplicate, move, remove, unbind, inspect inputs/outputs/lineage, and context-specific rule/mapping actions. Disabled actions explain why. Escape closes the topmost menu/dialog and returns focus; opening a rule chooser retains selected target and pending source.

Remove step removes its occurrence and revalidates dependents, never the catalog operation. Remove + reconnect is offered only for a safe topology (simple one-in/one-out without hidden boundaries, branches or loops). Unbind preserves the BPMN task and ID. Duplicate rewrites internal occurrence IDs and internal references while retaining allowed external sources; it does not accidentally point to the original rule's local draft. Move revalidates availability. One-click insertion and rule insertion are atomic Undo/Redo units.

Inline + at a connector offers intent categories: Capability action, Rule/Mapping, Route/Loop/Wait, and supported recovery patterns. The small intent menu can open a larger contextual resource picker when detail is necessary. This reconciles the v4 desire for inline insertion with the user's explicit need for larger rule popovers; the design does not ban all dialogs.

## Capability and rule discovery

Capability picker groups Service -> API group/controller -> Operation, with search across name/description and a detail preview. It shows inputs/outputs, effect, version, maturity and availability. A long undifferentiated list is not acceptable. An L2 context defaults to local compatible operations and exposes cross-service boundaries explicitly.

Rule picker is a larger popover/slide-over with category filters, description, facts, outcomes, native format status, version and In Use/consumer references. No hidden capability invocation inside a gateway. An authoring shortcut may add an AMIE task plus gateway together, but both appear in the BPMN model and are explained as two nodes.

Patterns contain a small business example, what it creates, required data and limitations. Use Pattern expands into reviewable activities/mappings under the workflow revision; it does not create a mutable hidden reference. Full advanced BPMN palette groups events, tasks, gateways, subprocesses, data and collaboration with recognizable symbols, explanations and independent modeling/execution status.

## Shared components, not a framework explosion

Reuse existing Blazor controls first. Logical shared components are EntryInspector, UniversalSchemaGrid, SampleImporter, FieldDetail, SourceBindingPicker, OperationPicker, RulePicker, ContextMenu, BPMNContextRail, ObjectCard, MappingConnection, ReadinessPanel, DurationPicker, TracePanel and ArtifactImportReview. A logical component does not mandate a new assembly or standalone route. Page-specific orchestration remains in a cohesive editor state/service.

## Command model

Every command supplies draft identity/revision, actor, selected object IDs, intent and proposed patch. Validate preconditions; snapshot/commit graph+bindings+presentation together; invalidate stale test/release evidence; emit audit; update all views. On server conflict, retain the user's unsaved intent and display reload/compare options; do not overwrite someone else's work.

Examples: AddEntryBinding, ChangeTransport, AcceptInferredFields, EditContractField, RemoveFieldWithImpact, ConnectMapping, UseInheritedMapping, InsertProducerAndConnect, InsertRuleBetweenFields, ReplaceOperation, ConfigureBoundary, RemoveStep, ImportSupportedModel, PreserveUnsupportedImport and CreateReleaseCandidate. An action that only changes view, theme, filters or zoom does not mutate the workflow.

## Feature-to-serialization matrix

| UI feature | Authoritative model effect | Validation / runtime owner |
|---|---|---|
| Category multiselect | Workflow category references | Catalog; no permission inference |
| Add adapter | TriggerBinding + shared contract reference | Intake owner; no live subscription until authorized |
| Change Kafka gate | Adapter gate expression | Decoder/gate admission before start |
| Paste CSV | Proposed source schema + merge plan | Parser; no mutation before Apply |
| Add/edit field | Shared field identity/type/constraints | Resolver + runtime schema validation |
| Map source column | Per-adapter binding to field ID | Intake normalizer |
| Add Get Account | ServiceTask + sequence rewiring + typed associations | BOB compiler and operation adapter |
| Connect object | Whole-object association/projection | Typed mapping layer |
| Override field | Explicit child binding over parent projection | Mapping semantics, no source mutation |
| Insert AMIE data rule | BusinessRuleTask + fact/result associations | Existing AMIE adapter |
| Change rule | Native artifact/version reference | Existing AMIE draft/serializer |
| Timeout | Supported duration/boundary configuration | BOB timer/attempt policy |
| Retry | Operation-specific permitted retry policy | Capability/BOB reconciliation |
| View lineage | No new data definition | Resolver projection |
| Save recipe | Approved authoring template | Enrichment/catalog governance |
| Native import | Preserved XML/artifacts + known parsed model | Importer, XSD, compiler |
| Export | BPMN XML + native dependencies | Serializer, not approval |
| Restart job | New authorized linked execution request | BOB and policy, not UI flag alone |

## User-understandable diagnostics

Say `Current account is missing. Get Account can supply it using Request.Account ID` rather than `unsatisfied model edge`. Say `This value is only available on the Yes branch` rather than `dominance failure`. Advanced details may include stable codes, schema versions and compiler traces. The simple message and technical diagnosis must refer to the same issue.
