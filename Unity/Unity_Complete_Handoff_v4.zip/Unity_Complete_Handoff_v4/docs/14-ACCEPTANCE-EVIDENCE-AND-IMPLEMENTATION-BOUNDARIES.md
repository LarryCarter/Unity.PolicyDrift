# 14. Acceptance evidence and implementation boundaries

## Four evidence layers

1. Browser interaction: controls change a local draft and show the expected state.
2. Structural artifact validation: XML parses, Unity XSD validates, IDs and references are coherent; official BPMN XSD is a distinct gate.
3. Production compiler semantics: graph execution, types/availability, policies, host boundaries and dependency locks are implemented in actual BOB/SDK/AMIE adapters.
4. Enterprise observation: deployed services and infrastructure execute the expected operation with security, durability and operational evidence.

The included prototype proves selected cases in layers 1 and 2. It does not prove layers 3 or 4. The QA report records exact test results and omissions; previous run results are not blindly copied as current evidence.

## Feature matrix for the delivered demo

| Feature | Demonstrated here | Still required for enterprise implementation |
|---|---|---|
| Existing contextual BPMN/Data/Rule editing | Preserved local model, menus, nested fields, rule insertion, Undo/Redo | Bind to repository components and native contracts |
| Multiple launch bindings | Editable source-specific settings and shared field definition | Real subscription/route/scheduler registration and server validation |
| CSV/JSON/Avro sample import | Local candidates, target mapping, locked merge, normalized first-row preview | Full schema variants, production-scale limits, approved parsers, schema registry and charset handling |
| Custom field editing | Types/required/null/lock/pattern/default/source bindings | Full model registry, enum/range/array item UI and compatibility migrations |
| Scheduler example | Execution context -> explicit one-row ingestion fixture -> account lookup | AutoSys/Cron/NAS scheduling, file completion, batch paging and retry policies |
| Data resolver | Existing fixture types/path checks, one-click account producer | Full arbitrary BPMN parallel/loop/error/freshness/security analysis |
| Native AMIE | Opaque XML/JSON preservation path; local fixture rules | Matthew's real format, editor, evaluator and serializer integration |
| XML export/import | Documented structured profile with entry extensions and DI | General preservation-capable editing, official XSD, migration contracts |
| Partial/unrecognized import | Original preserved with unsupported-profile explanation | Editable unknown-content retention and complete actionable analyzer |
| Business portal/Ops | Local traces feed separate example views; audit JSON preview | Authenticated server filtering, durable projections, real broker state, safe intervention |
| Capability Studio | Prior provider onboarding prototype connected to current builder | Trusted SDK registration, contracts, deployed endpoints, activation enforcement |
| Production release | Explicitly blocked and documented | Full trust, approvals, dependencies, changes, UAT and activation |

No simulated catalog record proves that an approved operation, schema, service account or permission exists in the actual enterprise. The sample API properties and namespace names are illustrative. The current UI makes that boundary visible.

## Production regression suite

**REG-01 Preserve existing contracts:** run old API/rule/workflow fixtures unchanged through the adapted path; demonstrate no duplicate evaluators/consumers/stores. **REG-02 Same operation reused:** two independent workflows and an L2 process use one registered handler. **REG-03 No-recompile change:** approved AMIE/BPMN definition changes affect new runs without changing the capability binary, while old runs remain pinned.

**DATA-01 Source mapping:** CSV/form/API/Kafka variants normalize to equivalent typed requests. **DATA-02 Locks:** updated sample never overwrites locked field definition/binding without explicit action. **DATA-03 Availability:** missing producer, later producer, sibling branch, zero-loop and failed lookup are diagnosed. **DATA-04 Identity:** account/target/iteration mismatch is blocked. **DATA-05 Freshness:** pre-write object cannot verify post-write state. **DATA-06 Shapes:** nested object, array, required/null/default conflicts and semantic conversion are tested.

**BOB-01 Concurrency:** parallel activations/joins race without double advancement. **BOB-02 Timers:** durable restart and boundary race. **BOB-03 Errors:** scoped error propagation and not-found/business-reject/unknown-write distinction. **BOB-04 Messaging:** outbox/inbox crash tests, duplicate/out-of-order outcomes and idempotency scope. **BOB-05 Human tasks:** stages, backups, concurrent decisions and authorization changes.

**SEC-01 Access:** Read/Execute/Create/Execute-Lead scope, including exports and push updates. **SEC-02 Service boundary:** no per-human vendor group requirement; trusted command and approved operation still enforced. **SEC-03 Data protection:** secrets redacted everywhere, sample retention and arbitrary input destinations blocked. **SEC-04 Production:** wrong groups, unsigned/tampered package, missing ticket/native artifact/handler and experimental execution fail closed.

**UX-01 A-to-Z:** non-programmer configures source, binds operations/rule, resolves missing data, tests both branches and prepares release without unrelated admin detours. **UX-02 Context:** UML/Data view retains BPMN orientation and shared history. **UX-03 Basic edits:** insert/delete/replace/unbind/move/duplicate/connect/undo/redo work, including impact messages. **UX-04 Accessibility:** keyboard alternatives, labels, focus, contrasts, light/dark, screen widths and error explanation. These require actual usability/accessibility validation, not only absence of JS errors.

**IMPORT-01 Round-trip:** known semantics, native rule bytes, IDs, DI and extensions preserved. **IMPORT-02 Partial model:** unbound artifacts remain visible and non-executable. **IMPORT-03 Unknown extension:** preserve/restrict or explicitly reject without data loss. **IMPORT-04 XML trust:** DTD/entities, archive traversal and oversized inputs blocked.

## Completion record per story

Record source commit/build, test command/output, fixture identity, environment, expected versus actual behavior, reviewer, defects and remaining limitations. A closed Jira item is not sufficient if its milestone gate is still failing. Do not label a production story Done merely because its browser prototype is demonstrated.
