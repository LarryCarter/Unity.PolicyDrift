# 13. Legacy-to-Unity extraction and later AI assistance

## Existing legacy analysis is an input, not work to redo

The user has already used Devin to inspect legacy applications, extract business rules and generate BPMN XML. Treat those artifacts as valuable evidence. Inspect them first; do not re-discover every process just because this handoff is newer. They may represent much of the modeling work. Their existence does not quantify runtime migration completion without checking bindings, native rules, error paths, data semantics and parity tests.

## Repeatable extraction package

For each application produce: source location and revision; operation inventory linked to existing registered primitives; rule inventory with source conditions/precedence/defaults; process/control-flow model including loops/errors/waits; typed data and source/consumer bindings; native AMIE artifacts using the verified serializer; mapping from source behavior to BPMN node/rule ID; regression fixtures; known ambiguity and intentional deviations. Keep security/technical invariants in the execution boundary even if a legacy conditional contains them.

Classify a code block as technical operation, business decision or business sequence. Reuse the technical API client; express decisions in AMIE; express sequence/control in supported BOB BPMN. Avoid wrapping an entire legacy hardcoded program in a handler and calling it configurable. Conversely, do not split every simple function into a workflow for appearances.

## Preserve behavior before refactoring it

Use characterization fixtures for normal, edge, missing/null, error, timeout and duplicate cases. Compare observable outputs and intended external effects, not just similar diagrams. Match original precedence, data normalization, locale/time assumptions, implicit defaults, transaction boundaries, exception handling and authorization. Record surprising legacy behavior for review rather than silently fixing it in the migration. Safe mock/dry-run comparison precedes real writes.

Pilot order: CyberArk custom-field update; Email extraction; central orchestration across the two; account onboarding with conditional Safe/Platform requirements. Retain separate playbooks for DCMS/CMDB, Policy Drift ZIP/INI comparison, guarded deletion and Hygiene/Safe-move. Do not conflate Policy Drift with account hygiene or invent vendor operations from examples.

## Partial-readiness import

An unbound service task, unresolved native rule, incomplete BE form binding or missing source mapping should be a visible readiness item. Supported structure loads editably; unsupported content is retained with clear limitations. Each item links to the task/schema/adapter and a specific remedy. Draft review/export is allowed; unvalidated execution is not. The handoff requires a robust preservation-capable production importer even where the demo provides only a supported subset plus preserved-original fallback.

## Future MCP and AI co-design

AI should use the same schemas, catalogs, validation and commands as a person. Potential tools: list authorized operations/rules; inspect contract; propose a bounded edit; validate draft; apply a reviewed command with revision; export a draft; inspect redacted trace. No AI tool receives raw service credentials or bypasses approval. Production activation remains a separately authorized action. MCP is an interface to existing platform services, not a new orchestrator.

The specifically named future AI product remains unverified; do not create an integration dependency around guessed branding. The extension schema, semantics and examples make the design AI-ready without making routine authoring AI-dependent.

## Rationale to give the next developer

BPMN is the common executable/process language. The UML-inspired view helps humans understand objects and mappings; it is not a second model to reconcile. AMIE is retained because its rules already exist. SDK descriptors connect reusable code to both the compiler and UI. The value is changing business behavior through governed configuration after release, not merely generating diagrams from source code.
