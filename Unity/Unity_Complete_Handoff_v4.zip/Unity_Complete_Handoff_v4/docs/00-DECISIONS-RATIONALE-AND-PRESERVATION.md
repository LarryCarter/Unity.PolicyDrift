# 00. Product intent, decisions, rationale, and preservation contract

Status: current engineering handoff, 4.0.0-review, November 20, 2026. This is a specification and offline demonstration, not a claim that the enterprise platform is implemented. The user's latest authorization permits this complete package. Earlier instructions to listen prevented changes at that time; they are not development requirements.

## The product, in one paragraph

WF Unity lets an authorized person construct business behavior from reusable, SDK-registered capability operations, AMIE decisions, and BOB workflows. Developers implement or adapt the technical primitives once. Authors subsequently change supported business conditions, mappings, sequences, branches, and local service processes through the BE designers, without recompiling those primitives. CyberArk is the primary capability and reference case; Email, extracted from Policy Drift's existing send-results implementation, is the second. A COTS API is wrapped by an approved capability service where necessary. The same contract model is intended for other departments and languages; it is not a CyberArk-only platform.

## The rule that comes before every implementation job

**Inspect and extend working AMIE, BOB, SDK, authentication, group, messaging, persistence, and serialization implementations. Never replace or duplicate them simply to fit a new UI, example, schema, or handoff.**

Devin must first locate actual repository paths, AGENTS.md, existing tests, registrations, native AMIE reader/writer, BOB persistence and host adapters, and the deployed capability clients. Proposed names in this packet are logical responsibilities, not evidence that matching classes exist. For each change produce: existing behavior and evidence; necessary extension; compatibility mechanism; regression tests; changed files. A genuine incompatibility is a decision request with alternatives and impact, not permission for a silent rewrite. Preserve the old path behind an adapter until its replacement, if explicitly authorized, proves parity.

## What the repeated wireframe iterations taught us

The original collection of many similar screens fragmented a single authoring task. A subsequent minimal prototype removed useful editing and lost the BPMN context. The accepted solution is neither extreme: retain the useful builder and add progressively deeper editable perspectives. The process remains visible while a user examines an activity, an object, a field, or an AMIE rule. Context menus, larger selection popovers, readable explanations, and one history stack make these perspectives a single tool.

Screen count, component count, file count, and ZIP integrity do not prove functional completeness. Completion is demonstrated by an end-to-end user journey and executable acceptance evidence. The original archives remain provenance only. Current requirements are stated here rather than delegated to a historical precedence notice.

## Ratified decision register

| ID | Decision | Why / constraint |
|---|---|---|
| D01 | One BOB core, central and embedded hosts | Do not create departmental orchestration engines. Local service operations and AMIE evaluations need not round-trip to central BOB. |
| D02 | BPMN 2.0.2 XML is authoritative for process and workflow-owned mappings | JSON editor state is not the only interchange format. Use native BPMN data and DI structures plus documented Unity extensions. |
| D03 | Keep native AMIE semantics and serialization | Neither this document nor an offline fixture is authority to invent a replacement rules engine. |
| D04 | Process, Rule, and Data are synchronized perspectives | No separately editable duplicate process or mapping graph. Selection, validation, history, IDs, and revision are shared. |
| D05 | Adopt only the UML concepts solving current problems | Typed objects, nested properties, multiplicity, relationships, and field connections; not a general UML/XMI/state-machine implementation. |
| D06 | Data/rule detail is a contextual zoom under BPMN | Keep enclosing process, branch, and selected activity visible. L2 authors may spend most time in this view. |
| D07 | Capabilities expose operations with typed contracts | An operation is the callable primitive; a service is its owner and execution boundary. Registration must describe inputs, outputs, versions, effects, and host eligibility. |
| D08 | Registration, approval, and environment activation are separate | Discovery is not permission to execute. Sensitive operations remain governed. |
| D09 | Human access and service-account access are separate | Departments authorize service identities, not every Unity website user. Unity controls human workflow rights and approved bindings. |
| D10 | Reuse Matthew's current authentication and groups | Do not build another local identity/group system. Channel Secure integration is pre-go-live, not an indefinite future enhancement. |
| D11 | Multiple business categories; no mandatory owning Application workspace | Classification is many-to-many and does not change access. Capability ownership of an L2 workflow remains real. |
| D12 | DEV, UAT, PROD only for current deployment | Do not invent a separate TEST environment. Testing is an activity within DEV/UAT. |
| D13 | Three maturity classes and four development stages | Experimental / NonProd / Approved, independently InDev / Testing / Verified / ReleaseReady, per resource version. |
| D14 | Experimental modeling and execution are different | Save unsupported drafts; block unsupported execution. Implemented experimental handlers may run in authorized lower environments, never because a visibility toggle bypasses checks. |
| D15 | Expanded Phase 1 BPMN remains committed | Parallel gateways, durable intermediate timers, interrupting timer/error boundaries and minimum durable human tasks are not removed by a smaller demo profile. |
| D16 | AMIE owns decisions; BOB owns durable control flow | Keep existing AMIE intake/routing for the initial delivery; assess overlapping orchestration and correct in a subsequent planned phase. |
| D17 | Approvals are BOB workflows with AMIE policies | Multilevel stages, multiple approvers, backups, and durable decision state; BE is the human interaction surface. |
| D18 | API workbench remains in scope | Reuse authentication, chain calls, use sample/CSV data, change payloads, inspect outcomes without redeploying for each experiment. |
| D19 | Business logic migrates from legacy applications into rules and BPMN | Devin accelerates extraction. Behavioral parity and side-effect safety still require proof; do not assert 90-99% readiness without inspecting artifacts. |
| D20 | Runtime requirements are not all external input requirements | Requests, previous operation outputs, rule outputs, safe defaults, and approved lookup calls all supply data. |
| D21 | Data mappings require control-flow availability | A compatible field on a later or sibling path does not satisfy a required input now. |
| D22 | One-click producer insertion is an atomic draft edit | No live API call. Reuse an eligible existing producer first; insert only when input, placement, identity, host, and type are unambiguous. |
| D23 | A rule inserted between data fields is a BPMN rule task | Never hide a second AMIE execution inside the mapper. The data card and BPMN task are one activity. |
| D24 | Enrichment owns reusable transformation expertise, not orchestration | Local pure mappings need not make a network hop. External retrieval remains an explicitly authorized capability operation executed by BOB. |
| D25 | Ordinary mappings version with their workflow | Recipes initially expand as templates into explicit tasks/mappings. No independent release lifecycle for every wire. |
| D26 | Transport is separate from shared schema | Trigger-specific mechanics, universal field definitions, and inference provenance are distinct. Source extraction binds into the shared contract. |
| D27 | Two tabs and two on-demand overlays | Trigger / Data Contract; Sample Importer; Field Detail. No permanent stack of transport, raw samples, fields, and validation. |
| D28 | Schedulers introduce run context, ingestion introduces business data | run.* is not the CSV row. Business data becomes available only after the ingestion activity succeeds. |
| D29 | Sample inference proposes, author accepts | Manual locks survive re-import. Examples are not proof of requiredness or universal types. |
| D30 | BPMN and AMIE export support normal post-release authoring | New supported business behavior should not require a return to Devin. New technical primitives can still require code. |
| D31 | Production release uses governed artifact import | Trusted origin/integrity, approved versions, groups, dependency checks, and a mandatory nonempty ServiceNow change reference. Ticket API validation is later. |
| D32 | A secret in the uploaded file is not release authorization | Signing keys stay outside packages. Import and activation are different operations. An unsigned demo is never production-ready. |
| D33 | Lower environments exercise production-style import controls | Test tampering, missing references, wrong environment, wrong entitlements, and rollback. |
| D34 | Use lowercase uty_ database schemas | Reconcile with existing EF ownership/migrations; do not force destructive renaming. |
| D35 | Enterprise dependencies have milestone/story placeholders | Channel Secure, Apigee, Splunk, AutoSys, NAS, Cron and further required integrations; existing work is verified before duplicated. |
| D36 | Each Jira story has one owning milestone | Megan can see accepted work, remaining work, blockers, and milestone gates. Placeholder IDs are not actual Jira issues. |
| D37 | Preserve full current content in one master and Ask copies | Separate documents remain available; Matthew's internal review stays outside Ask content. |
| D38 | Operational views follow the user's task and entitlements | Business portal for jobs/results, designer for authoring, Ops for diagnostics; visual personas are not security enforcement. |
| D39 | Durable audit outlives broker retention | Store mandatory evidence independently of Kafka; redacted payloads, controlled retention and access, no arbitrary table write instruction in a workflow. |
| D40 | AI-ready, not AI-dependent | Document grammar, semantics, examples and validation. Future MCP authoring is scoped, authorized, reviewable and cannot bypass release gates. |

## Decisions requiring explicit reconciliation, not silent substitution

The submitted v4 proposal is retained verbatim as `source-reference/USER-V4-PROPOSAL.txt`. It is input to this handoff, not a declaration of existing code. These resolutions preserve the agreed design while making uncertainty visible.

| Proposal or earlier assumption | Current treatment | Evidence needed |
|---|---|---|
| AMIE is native JSON, versus earlier native XML understanding | Use a format-preserving native AMIE adapter. Do not convert or assume either. Demo JSON is labeled fixture-only. | Matthew's actual serializer, schema, rule example and round-trip test. |
| Mandatory businessSpace/ownerDepartment | Optional classification/administrative metadata; no mandatory authoring workspace. Multiple categories persist. | Existing ownership fields and policy requirements. |
| SourceLocation/path embedded in universal fields | Shared field identity/type stays transport-independent; bindings carry per-adapter source location/path. Grid projects both. | Existing intake schema to adapt without breakage. |
| correlationKeyPath supplies idempotency | Separate business correlation and dedupe identity. They may use the same field only by an explicit ingress policy. | Existing consumer/inbox keys and replay policy. |
| Every reachable node gets a producer's output | Only paths where the producer is guaranteed successful have that value. Unknown/not-found/failure outcomes do not hydrate it. | Compiler control/data-flow implementation. |
| Three retries and DLQ/compensate defaults | No generic write retries or compensation assumption. Operation-specific safety and supported BPMN profile govern. | CyberArk adapter outcome/reconciliation behavior. |
| Kafka always retains exactly four days | Treat four days as a reported environment assumption; configuration is not inspected. Audit starts at admission, not after four days. | Broker/topic policy and operational owner. |
| General UML Activity/State drill-down | Keep the approved small object/logic subset. No second state-machine interpreter in Phase 1. | New requirement and design approval before expanding. |
| Lossless import means all BPMN can execute | Preserve import bytes/unknown content; mark unsupported semantics. Lossless storage, editable support, and executable support are separate. | Independent fixtures and actual compiler evidence. |
| AllowUserRestart=true means safe restart | Flag is a policy input, not authorization or proof of side-effect safety. | Entitlements, prior outcomes, reconciliation and distinct run ID. |
| targetTable chosen in workflow | Bind an approved audit sink identifier owned by the platform, not arbitrary SQL/table names. | Existing audit service and uty_audit mapping. |
| Registration automatically exposes everything | Approved compiled/adapter operation allowlist; candidate registration does not activate runtime routes. | SDK trust and deployment identity checks. |

## What may be adapted without changing the decisions

Repository paths, existing interface names, serialization plumbing, approved UI component library, database migration shape, topic names, service identities, and enterprise gateway routing must follow source evidence. The capabilities, responsibilities, preserve-existing rule, approval boundaries, and required user outcomes are not optional. An adaptation record connects the semantic requirement to its actual implementation.

## Definition of completion

An author can configure a source from sample data, bind an existing operation, supply a missing model through a lookup, place a rule in context, test all selected branches, preserve everything through export/import, and submit a governed release. Developers can expose the two first capabilities without duplicating transport or business orchestration. Operations can diagnose failures without trusting broker retention as an audit database. Each claim needs its own evidence; the offline demonstration covers only its explicitly tested subset.
