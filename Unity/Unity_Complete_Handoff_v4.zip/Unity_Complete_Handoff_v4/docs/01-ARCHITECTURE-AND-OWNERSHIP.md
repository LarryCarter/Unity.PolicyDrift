# 01. Architecture and ownership

## One platform, three levels of composition

L1 is an enterprise BOB process coordinating capabilities, waits, human tasks, outcomes and release-governed definitions. L2 is a capability-owned BPMN process using the same BOB interpreter with local operation dispatch and the existing AMIE adapter. L3 is a typed compiled operation or an approved typed API adapter. L3 is not another workflow engine. A single SMTP send need not become its own elaborate BPMN process.

Logical path: BE or approved external producer -> intake/authentication -> durable admission -> BOB -> approved capability operation or L2 workflow -> outcome -> BOB -> result projection. Existing AMIE intake may classify, enrich and select a workflow before admission; retain it until the planned ownership refinement has been reviewed. In-workflow rule tasks also use AMIE. There is no requirement for an embedded CyberArk step to call central BOB and AMIE once per local function.

## Control plane versus execution plane

The control plane governs operation descriptors, definitions, native rule artifacts, mappings, approval evidence and environment activation. Published definitions are immutable. The execution plane uses an admitted immutable dependency snapshot, evaluates local rules through supported adapters, invokes approved handlers, and checkpoints state. Cached definitions do not authorize stale permissions indefinitely: permission and revocation policy must be explicit. A central outage may permit already-approved bounded local work only under the verified cache/authorization policy; it does not mean uncontrolled offline execution.

## Components and data ownership

| Owner | Owns | Does not own |
|---|---|---|
| BE / Modeling Studio | Human authoring, contextual views, typed forms, test UI, portals | Browser-side external API credentials, Kafka producers, policy authority |
| Registry / SDK | Trusted operation descriptors, compiled handler wiring, model metadata, compatibility | Arbitrary class instantiation from XML or arbitrary API proxy URLs |
| BOB | Tokens, scopes, scheduling, waits, activity lifecycle, replay-safe coordination | Vendor authentication implementation; another rule language |
| AMIE | Existing decision evaluation, validation/mapping rules, approval plans | A new competing durable orchestrator introduced by this handoff |
| CyberArk capability | Credential/session lifecycle, vendor calls, typed result translation, guarded writes | Ownership of all Unity users, unrelated Email orchestration |
| Email capability | Existing SMTP/report-send implementation, attachment handling, send outcomes | Re-running the source business process when delivery is uncertain |
| Data/NAS owner | File staging, row identities, schema-normalized data access, data permissions | Arbitrary cross-service database access by BOB or BE |
| Enrichment capability | Approved reusable converters and mapping recipes | Implicit fetching, unbounded recursive API calls, another interpreter |
| Audit/operations | Durable evidence, projections, intervention policy, retention | Treating mutable log text as execution state |

## SQL and EF ownership

The agreed logical schemas are `uty_catalog`, `uty_security`, `uty_capability`, `uty_bob`, `uty_amie`, `uty_be`, `uty_release`, and `uty_audit`. They can share the governed SQL Server database for an environment, but ownership is not shared write access. The actual repository may already have schemas or contexts; propose a compatible migration plan rather than renaming production tables to match this document. BOB persistence is MSSQL; do not add alternative workflow persistence providers without a decision.

Minimum logical objects: WorkflowDefinition (stable identity); WorkflowRevision (draft snapshot/ETag); PublishedWorkflowVersion (immutable XML/digest); WorkflowCategoryLink (many-to-many); OperationDescriptorVersion; CapabilityService; NativeRuleArtifactReference; Activation; TriggerBinding; SchemaContract; HumanTask; WorkflowInstance; ExecutionScope; Token; ActivityAttempt; Timer; Inbox; Outbox; AuditEvent; RunProjection; ReleaseArtifact. These are responsibilities, not prescribed duplicate tables. Use existing equivalents first.

A schema contract or mapping owned only by a workflow is revisioned with that workflow. A shared service operation and native AMIE rule retain their independent approved version identities. Category labels are not execution routing, security scopes or schema identity. A folder move cannot change references.

## Identity continuity

Preserve original initiator identity, current execution identity, workflow version, correlation ID, source record ID and service-account reference through commands and audit. Do not put passwords, tokens or real secret values into those records. Inbound caller claims are verified at admission; a message field asserting `Approved=true` is not approval. The capability service validates that the command comes through the approved execution boundary and targets an activated operation; it need not resolve each human's AD membership in the external vendor API.

## What gets reused

The same descriptor drives code admission, registry discovery, operation selection, generated input controls, compiler binding and runtime dispatch. There should not be six manually maintained definitions of an operation. The model includes parameter constraints and output presence guarantees; platform-specific metadata may add conditional requirements through an approved resolver. Designer discovery does not execute those operations.

## The first coherent increment

Start with the existing CyberArk client and Email send-results code. Expose one read-only account operation with typed data. Use it inside a local BOB process with an existing AMIE rule. Change a rule/flow through supported definitions, not recompilation. Then have central BOB invoke the local process and Email. Controlled writes follow with explicit idempotency, uncertainty and verification. This is a proof sequence, not removal of the expanded Phase 1 requirements.
