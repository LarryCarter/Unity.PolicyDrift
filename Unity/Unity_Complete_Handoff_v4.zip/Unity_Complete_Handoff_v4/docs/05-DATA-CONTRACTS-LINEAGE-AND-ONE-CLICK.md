# 05. Data contracts, progressive hydration, and one-click connection

## Four related contracts, one authoring model

A source schema describes what arrives: CSV columns, message body/key/headers, form values, API body/path/query, or scheduler context. A workflow input contract describes normalized values admitted into a process. Each activity has an authoritative provider-owned input/output contract. The working data graph records values acquired and produced along each execution path. These are related models, not four independent copies of the workflow.

An operation's requirement is not automatically a required external input. Account ID plus four desired fields can satisfy a workflow that retrieves current account data itself. Onboarding can require many incoming fields plus lookup-derived Safe/Platform information. Resolve the full flow before proposing the external contract. Authors can also add business fields such as justification and business reference, even when no capability currently consumes them. Removing a step removes its outputs and revalidates consumers; it must not automatically delete author-declared request fields.

## Canonical field metadata

Stable field ID; display name/path; type or registered model reference; semantic identity; requiredness; nullability; scalar/collection cardinality; constraints; sensitivity; default policy; provenance. Nested object and array-item definitions are explicit. Required means the property must be present; nullable means a present value may be null. Empty String is not missing, null, or permission to remove a remote value. Defaults are applied by a declared stage, not assumed by a schema validator. A sample value is test data, not a default.

Source extraction is an adapter-specific binding: adapter ID + source location + path/column identity -> stable normalized field ID + optional approved conversion. Shared field schemas do not store a single Kafka path that becomes meaningless when a CSV adapter is added. The grid can display Type and Source together, but their persistence is separate. Changing the adapter preserves field IDs and exposes incompatible bindings for repair.

## Runtime value identity

A value's type alone does not identify the entity it describes. Lineage must carry producing activity occurrence, input identity, service/target scope, iteration/record identity, schema/version, outcome presence, and observation point where relevant. A CyberArk account read for account A cannot satisfy a request about B. A pre-write snapshot cannot verify a post-write change. A collection cannot silently become its first element. A value inside one loop iteration does not populate all other iterations.

Keep producer outputs immutable from the consumer's perspective. Whole-object mappings copy/project into a target object; field overrides change that target, not the upstream snapshot or another consumer. Detect conflicting whole-object/field writes and define override order explicitly. Mark whether a child mapping is inherited, explicit, intentionally unmapped, defaulted, computed, or conditionally available.

## Resolver result states

| State | Meaning | UI action |
|---|---|---|
| Connected | Existing binding meets type and availability checks | Inspect source or change mapping |
| Ready to connect | One compatible available source exists but no binding yet | Connect existing data |
| Needs mapping | Compatible information requires an explicit conversion/projection | Choose mapping/recipe |
| Can be obtained | An approved producer can provide the model and has satisfiable inputs | Add producer and connect, or review options |
| Conditional | Data is present only for certain outcomes/branches | Add guard/default or move the consumer |
| Missing | No acceptable binding plan exists | Explain missing field and offer external input/lookup choices |
| Invalid | Existing binding references a removed step, wrong type/entity/host | Highlight exact source/target and remedy |

Suggestions are metadata analysis, never live API calls. Registry search is scoped by service, environment, maturity, authoring permission, host and semantic contract. Semantic compatibility is declared by the provider or an approved mapping; fuzzy field-name similarity is a recommendation requiring review, not runtime proof.

## Exact Add Get Account and Connect interaction

Precondition: selected AMIE comparison needs currentAccount. The request supplies one semantically valid Account ID and desired fields. No suitable current account object is available. The compact inspector shows: `Current account - Missing` and `Get Account can provide this using Request.Account ID`. Primary action: **Add Get Account and Connect**. Secondary link: **Choose another source**. Full lineage stays closed.

On click, compute an insertion plan against the current draft revision. Confirm operation/version/activation eligibility, host adapter, account identity/target, required inputs, source uniqueness, success-only output guarantee, acceptable insertion scope and no circular dependency. First search for an existing eligible Get Account producer. Reuse it only if entity, target, freshness and path are correct. Multiple candidates require the larger source popover.

For a new producer, insert one Service Task immediately before the consumer on its valid control path. Bind request.accountRef -> GetAccount.accountRef. Bind its successful account output -> Compare.currentAccount. Preserve the desired-fields mapping. Add native input/output associations and corresponding fine-grained Unity binding records. Recalculate downstream availability. Show `Connected - supplied by Get current account` and a short success message with Undo. Keep the comparison selected and highlight the inserted task in the BPMN context strip.

This is one command/history unit, one draft revision and, in production, one atomic backend mutation. It must be conditional on an ETag/revision, with command ID for safe reapplication. Validation failure, stale revision or cancelled choice leaves the draft unchanged. Browser Undo/Redo preserves stable IDs. Runtime credentials and external calls are never touched by this authoring command.

If the consumer can be reached without the producer, no safe single insertion is possible until topology is resolved. A parallel sibling's output is not available merely because both branches are visible. A producer on an error path cannot supply success data. No recursive suggestion may introduce a write as an implicit lookup.

## Compiler data-flow analysis

For ordinary sequence, propagate only guaranteed outputs after successful completion. For XOR merges, compute availability across feasible incoming paths; fields missing on one path require an explicit optional/guarded contract. For parallel joins, combine guaranteed completed branch outputs with unique identities and collision handling, not the same rule used for XOR. Non-joined concurrent branches cannot assume each other's values. Nested subprocesses export only declared outputs. Iteration scopes and zero-iteration paths need explicit aggregation. Error, timeout, cancellation and unknown-effect paths have their own outcome contracts.

A production resolver needs graph-aware analysis over the actual BOB IR, with termination bounds and diagnostics. The demo's structured list traversal is not that full analysis. Do not infer completeness from a happy-path fixture. Registry producer search should have a configured depth/cost limit, cycle detection, deterministic ranking and an explanation of each proposed plan. Human choice is required when safe alternatives remain ambiguous.

## Enrichment and mapping recipes

Reuse the proposed Enrichment capability for approved transformations, normalization, projection and object composition. Pure local conversions can run locally through the shared adapter; do not force a network service hop for every String conversion. Lookup calls remain explicit operations. AMIE owns business-dependent comparison, permission and policy logic; do not split the same decision between a mapping language and a new rules engine.

Recipes initially act as authoring templates: choose, preview, expand into explicit mappings/tasks, review, save in the BPMN workflow. The workflow revision owns the generated content. A later live reusable transformation dependency must be pinned and approved; it is not required for every ordinary wire. No arbitrary JavaScript, C#, SQL, file access or HTTP calls embedded in a mapping expression.

## Data view behavior

Blue available sources -> violet rules/conversions -> teal selected target. Whole objects display as one connection until expanded. Selecting an object, field or connector opens its own three-dot/right-click menu. Actions include change source, use parent mapping, leave unmapped, insert compatible rule, inspect lineage and remove connection. Explain why incompatible sources are disabled. Context persists through popovers. Keyboard selection and Connect are alternatives to dragging; color never carries meaning alone.

Full lineage is on demand and shows source adapter, normalized field, producing step/outcome, transformations, consumers, type and any conditional availability. It edits the same mappings. A data connection does not silently reorder BPMN: any required topology change is a named atomic command with a before/after explanation.
