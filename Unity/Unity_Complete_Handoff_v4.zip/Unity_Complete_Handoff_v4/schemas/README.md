# Schemas and interoperability boundary

`unity-modeling-v3.xsd` is the original tested prototype model schema retained for compatible serialization of the existing working demo. `unity-entry-v4.xsd` is a proposed additive entry-configuration schema: shared fields, per-source adapters/extraction mappings, provenance and opaque native artifact preservation. The current demo exports both namespaces without independently maintaining two editable workflow models. The compatibility projection is checked on import; disagreement is not silently accepted.

These files are **reference extension schemas**, not declarations of the enterprise's actual AMIE/BOB contracts. Production integration must follow M0 source reconciliation. The entry schema deliberately does not claim to encode every business validation rule. Adapter-specific configuration, identifier/path uniqueness, reference validity, runtime policy, field types, dataflow guarantees and native artifact validity require additional validators.

Full official BPMN 2.0.2 XSD validation is a separate acceptance gate. The official local bundle was unavailable in this environment. Supply an approved copy of BPMN20.xsd and its local imports to `qa/validate_package_xml.py --omg-xsd /approved/path/BPMN20.xsd`. Do not replace missing official schema files with a hand-written approximation and report conformance.

XSD does not render the UI, register handlers, understand AMIE logic, establish authorization or prove executable semantics. A designer/compiler implementation must implement the corresponding contracts and tests.

`unity-modeling-v4.xsd` is a convenience assembly importing both proposed/preserved extension namespaces. It does not import or substitute for the official BPMN schema.
