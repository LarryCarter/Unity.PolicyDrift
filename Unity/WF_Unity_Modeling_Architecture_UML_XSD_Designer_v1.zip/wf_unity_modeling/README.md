# WF Unity Modeling Design Packet

1. `WF_UNITY_MODELING_ARCHITECTURE_AND_DEVIN_HANDOFF_v1.md`: architectural rationale, approved direction, proposed contracts, gates, acceptance criteria.
2. `unity-modeling-prototype.xsd`: **prototype** Unity extension schema, not approved production namespace.
3. `example-workflow.bpmn`: **non-executable** illustrative BPMN XML with extensionElements; not a complete production export or BPMN-DI diagram.
4. `Unity_Data_Flow_Designer_Prototype.html`: standalone browser mockup for Process/Rules/Data perspectives, clickable mapping and XML preview. Does not call services or persist changes.

Validation performed: Unity extension subtrees validated with lxml XMLSchema. Full OMG BPMN XSD validation, AMIE round-trip, real BOB import and UI browser regression are not yet performed.
