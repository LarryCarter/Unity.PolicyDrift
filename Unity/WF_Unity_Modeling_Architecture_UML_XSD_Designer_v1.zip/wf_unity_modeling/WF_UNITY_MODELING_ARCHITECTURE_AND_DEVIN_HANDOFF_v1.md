# WF Unity — Integrated Modeling Architecture and Devin Handoff
**Status:** Proposed technical contract implementing agreed architectural direction; NOT a claim of existing implementation. **Date:** 2026-11-19.

## 0. Non-negotiable preservation gate
Do not replace, fork, or silently change existing AMIE XML/serializer/evaluator, BOB compiler/runtime/state machine, SDK/registry, Kafka envelopes, or approved operation contracts. First read repo `AGENTS.md`, `docs/00-START-HERE.md`, `docs/architecture/03-BOB-BPMN-RUNTIME.md`, `docs/architecture/02-CAPABILITY-SDK-REGISTRY.md`, `docs/contracts/BPMN-WORKFLOW-BINDING.md`, `docs/contracts/OPERATION-CONTRACT.md`, and current source/tests. Produce an **as-built inventory and delta** before coding. Source wins over speculative examples; conflicting changes require explicit review. Mark each claim VERIFIED EXISTING / APPROVED DESIGN / PROPOSED CONTRACT / REQUIRES VERIFICATION. This packet contains no verified repository source audit.

## 1. Why this design exists
Business authors must create workflows faster than hand programming and understand them at multiple levels. BPMN is the common executable language for flow, gateways, events, loops, subprocesses, and orchestration; its standard diagram is inadequate for dense AMIE rules and field-level data mapping. A second independently executable UML workflow or mapping engine would create drift. Instead, use one authoritative BPMN 2.0.2 workflow document plus narrowly scoped Unity XML extensions; retain native AMIE XML as the rule authority. Present three synchronized task-oriented perspectives: **Process** (BPMN), **Rules** (AMIE), **Data** (UML-inspired object/property flow). L1 enterprise workflows favor Process; L2 capability workflows often favor Data/Rules; simple capability handlers need not be BPMN processes. A person who knows BPMN can navigate the process immediately, while non-programmers can configure mappings and rules visually. Standard interoperability is desirable but not allowed to block useful Unity-specific authoring.

## 2. Binding decisions and exclusions
1. BPMN 2.0.2 XML and BPMN DI remain the authoritative process/interchange format. BOB is the only workflow token interpreter, centrally or embedded.
2. Selectively adopt UML **typed object, property, nested object, association, multiplicity, object flow** concepts, not a full UML metamodel or UML runtime. Use plain authoring labels (Objects, Fields, Connect).
3. Preserve AMIE's rule language, serializer, evaluator, and business semantics. BPMN businessRuleTask stores a stable rule reference and typed bindings, not a copied rule evaluator.
4. Ordinary field-level mappings are embedded in BPMN extensionElements, anchored to native BPMN data inputs/outputs/associations where applicable. Reusable mapping recipes are templates, not automatically a separate runtime model.
5. Process/Rules/Data views edit a shared semantic model. Views may have separate layouts but never independent authoritative copies of mapping or flow.
6. Capability operations are approved, version-pinned, typed, authorized; discoverability does not imply execution permission. L1 cross-service uses central orchestration/Kafka; L2 local embedded host runs approved local handlers/AMIE without central per-step calls.
7. Source/trigger adapters normalize BE form, API, CSV, scheduler, Kafka, or workflow launches into typed requests; multiple launch methods may target one workflow. Business categories are many-to-many, not mandatory owning applications.
8. No arbitrary CLR execution, user-authored unrestricted REST/SQL, auto-binding of every activity input as external input, or invisible cross-host data movement.
9. Unsupported BPMN executable constructs may be preserved visually in drafts but must fail publish. No blanket claim of full BPMN conformance.
10. Legacy Devin-generated BPMN and extracted rules are valuable migration inputs; executable readiness is unverified until source, binding, behavior, and test comparisons pass.

## 3. Visual design and interactions
**Process tab:** standard BPMN shapes, swimlanes/pools where supported by designer, task selection, operation/rule inspector, sequence connections, gateways, timers, boundary errors, loop/multi-instance markers, and accessible grouped palette. Node ellipsis and context menu provide edit, replace, duplicate, unbind, remove. No inert controls. `+ Add Step` groups Perform Action / Make Decision / Request Approval / Run Workflow / Control Flow / Work With Data. Loop authoring offers `For Each`, `Repeat Until`, and condition controls, translating only into supported BPMN constructs.

**Rules tab:** selected businessRuleTask opens the existing AMIE rule through its existing editor/adapter or a compatible view; show facts, conditions, comparisons, outputs, and decision paths; never invent or overwrite AMIE serialization. Clicking an input opens its Data lineage. Rule version pinned in release binding.

**Data tab:** UML-inspired source and target object cards with collapsible nested properties, typed fields, multiplicity and nullability; connect fields by drag/click; select source and destination; offer matching suggestions and conversions; display current source, transformation, target, and validation. Scope toggle `This Step` (default) / `Entire Workflow`, same model. Clicking an object or field highlights BPMN producer/consumer and AMIE usage. Display unresolved required inputs with `Use existing producer`, `Add approved producer`, `Map field`, `Use recipe`, or `Mark unresolved`. `Add Get Account and Connect` inserts actual serviceTask and bindings atomically with undo; no authoring-time CyberArk call.

**Visualization example:** Request.accountId → CyberArk.GetAccount(accountId) → CurrentAccount; Request.desiredCustomFields + CurrentAccount → AMIE.Compare → changedFields → CyberArk.UpdateAccount(PATCH) → CyberArk.GetAccount verify. The Data tab shows property connections and provenance; the Process tab shows execution order and no-op branch; Rules tab shows AMIE comparison. Do not patch unspecified fields or retry uncertain writes blindly.

## 4. Minimal UML-inspired extension vocabulary (PROPOSED)
- `unity:dataModel`: contains `unity:objectType` with stable `id`, `name`, optional `contractRef`, `version`; `unity:field` with stable `id`, `name`, `typeRef`, `minOccurs`, `maxOccurs`, `classification`; `unity:relationship` with source/target type and cardinality. These describe types, not executable instructions.
- `unity:bindings`: scoped to an activity, references approved operation/rule key + pinned version and named inputs/outputs; adapt to existing binding contract, do not overwrite it.
- `unity:mappings`: per activity with `unity:map` from **stable typed endpoint reference** to target endpoint, optional approved transformation reference; preserve display path as human-readable metadata, not authoritative identity. Avoid arbitrary expression evaluation.
- `unity:dataView`: stores card IDs, positions, collapse state and connection presentation separately from mapping semantics; standard BPMN DI remains responsible for BPMN process shapes.
- `unity:recipeRef`: optional authoring provenance; applied mappings materialize in workflow XML. If runtime recipe dependency is ever needed, pin its immutable version explicitly.
- `unity:semanticVersion`: extension contract version. Define strict namespace and backwards-compatible migrations; unknown extensions preserved when possible, unsupported execution extensions block publish.

### XSD nuance
BPMN's `extensionElements` admits vendor extension content. A Unity XSD validates **structure**, not visual rendering, expression safety, runtime semantics, or automatic preservation by third-party tools. A designer needs a registered model adapter, renderer, serializer, and inspector. A DTD is not required; prefer XSD with namespace-aware parsing. Validate with both BPMN schema (where available) and Unity schema; run semantic compiler checks separately. A sample Unity XSD and illustrative BPMN document accompany this handoff; these are prototypes, not adopted production contracts.

## 5. Typed mapping/compiler semantics
A mapping edge identifies (source node/port/field ID, destination node/port/field ID), expected type and version. Resolver checks producer dominance and branch availability, host boundary, cardinality, nullability, classification/permissions, semantic identity, type compatibility, and output availability after activity completion. BPMN data association does **not** imply execution ordering; sequence flow must make producers available. Conditional branches require explicit merge or optional types. Collections require explicit item scope; `For Each` maps current item fields, not a whole collection to a scalar. Enforce immutable field IDs across display renames. Avoid silently coercing accountId to safeId because both are strings. Prevent secret values in XML, layout, manifests, logs. Mapping recipes are suggested/previewed before application and can be undone atomically.

## 6. BPMN constructs and loop authoring
`If/Else` → exclusive gateway; `For Each` → BPMN multi-instance task/subprocess with typed collection binding; `Repeat Until` → validated loop construct or gateway cycle, with termination guard; `Parallel For Each` → parallel multi-instance only after runtime support proven; `Wait` → durable event/timer; `Retry` → explicit approved retry policy and side-effect safety. UI may advertise planned constructs as disabled with reason; never serialize an unsupported executable node as publishable. Preserve BPMN XML IDs, namespaces, BPMN DI coordinates, extension content, and equivalent semantics on round trip.

## 7. Import/export and AI pipeline
Import legacy BPMN → parse → schema validate → preserve supported DI/extensions → inspect AMIE XML via actual serializer → bind typed approved operations → resolve data lineage → mark unresolved nodes → simulate/test → approve → immutable release. AI/Devin may propose BPMN and mapping edits but cannot grant permissions, invent handlers, bypass compile checks, or release. Provide AI the BPMN standard, Unity XSD, semantic contract, operation catalog, AMIE contract, and validation diagnostics. Every AI change is a diffable draft. Existing legacy BPMN completeness is not assumed: compare against real app behavior, exception paths, stateful side effects, and regression fixtures.

## 8. UX and runtime acceptance tests
A. Process edit remains reflected in Data and Rule views; IDs stable; undo/redo atomic.
B. Nested object mapping and collection mapping round-trip XML without losing types, mappings, layout or DI.
C. Invalid type, nullability, missing producer, wrong branch, cross-host data access, unauthorized operation, ambiguous identifier and unsafe transformation block publish with actionable diagnostics.
D. AMIE rule opens/edits/exports through existing serializer with unchanged semantics and backward compatibility.
E. Generated BPMN parses with BPMN schema; Unity extension validates with Unity XSD; parser rejects malformed extension; unknown extension handling documented.
F. Loop/multi-instance, gateway, timer, boundary error, wait and retry tested only where runtime explicitly supports them; unsupported constructs fail publish.
G. L2 embedded and L1 central use same BOB token semantics; durable Kafka/outbox/inbox idempotence, pause/resume/cancel/restart and crash recovery remain unchanged.
H. CyberArk GET → AMIE compare → PATCH only changed authorized fields → GET verify; no-op and uncertain outcome tests.
I. Import Devin legacy BPMN and compare expected behavior with real application fixtures before declaring migration ready.
J. Usability: non-developer maps a nested object, resolves missing account object via approved GetAccount producer, configures a decision and exports/reimports without code; keyboard access and screen-reader labels included.

## 9. Devin execution sequence and gates
**Gate 0 Source audit:** inventory exact AMIE schema/serializer, BOB compiler, existing BPMN extension conventions, UI framework, operation SDK, and regression tests. Deliver contract-diff table. STOP on incompatible assumptions.
**Gate 1 XML contract:** reconcile proposed extension with existing bindings, namespace, schema versions, IDs, data model. Test valid/invalid XML and semantic round-trip.
**Gate 2 Read-only visualizer:** load real BPMN + actual AMIE rule + typed operation manifests; render Process/Rules/Data views without editing.
**Gate 3 Mapping editor:** field connectors, suggestions, transformations, data lineage, missing-data resolution, atomic undo, XSD serialization.
**Gate 4 Logic UX:** AMIE editor adapter, conditions, loop/collection UI gated by actual BOB support.
**Gate 5 End-to-end proof:** existing Devin legacy workflow + CyberArk/Email reference workflow, compiler, DEV execution, security, failures, regression.
**Gate 6 Release:** immutable signed DEV→UAT→PROD artifact with approvals and ServiceNow reference when required; no TEST environment invented.

Every PR must report files changed, before/after behavior, schema changes, backwards-compatibility evidence, tests, screenshots, unsupported features, and unresolved approvals. No silent schema migration. Keep previous work packets as references, not competing specs.

## 10. Source reconciliation and open decisions
The existing staged `INDEX.md` enumerates BE-23 BPMN canvas, BE-25 schema-driven data binding/AMIE editor, BOB-37 compiler and BOB-38 AMIE adapter, with JOB-00/01 source-audit gates. This packet adds the integrated UML-inspired Data perspective, schema and semantic tests; it does not supersede verified source. Open: actual AMIE serializer contract; actual BPMN binding namespace; actual SDK operation field identity and type schemas; whether data-view metadata belongs on process or activity extension; exact existing UI component framework; which loop variants BOB already executes. Resolve from source, not speculation.

## 11. Developer implementation definition of done
A developer unfamiliar with prior conversations can explain WHY BPMN+selective UML was chosen, load existing AMIE and BOB without replacing them, inspect a workflow through all three views, author/validate a typed field mapping, export/reimport BPMN+Unity XML, diagnose invalid producer and branch, execute supported constructs using approved operations, and demonstrate no regression in existing runtime tests.
