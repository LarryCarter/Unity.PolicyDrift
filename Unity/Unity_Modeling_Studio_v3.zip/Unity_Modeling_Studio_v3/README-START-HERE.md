# WF Unity - Editable Contextual Modeling Studio v3

**Review date: November 19, 2026.**

## Open this, not an older reference screen

Extract the entire ZIP and open **OPEN.html** in a current desktop browser. It is a self-contained HTML application; no install, web server, CDN or network connection is needed for the design demonstration. **START.html** is an optional navigation page linking the designer, guide, schema and previews.

The initial view is **CMDB custom-field enrichment -> Compare custom fields -> Data mapping**. The BPMN context rail stays above the editor and highlights the activity you are editing. This extends the supplied rich v2 builder; it does not replace it with a disconnected object-diagram demo.

## What to try first

1. Expand **desired** on the source and destination cards. Select **Incoming request / desired / Owner**, then **Compare custom fields / desired / Owner**, then **Connect selected**. Drag-and-drop or **Change** on the connection is also supported.
2. Open the destination field's **three-dot menu**, or right-click the field. Choose **Insert / replace data rule**, inspect **Normalize text**, and select **Insert and connect rule**.
3. See the purple rule card between the fields and the corresponding rule task before Compare in the BPMN rail. Click the purple card, change its parameters, preview a sample, and save the workflow-local fixture draft.
4. Try **Undo** and **Redo**. Task insertion and mapping changes undo together. Remove the rule and reconnect its input without deleting the library rule.
5. Open **Business rule -> Choose another rule** on Compare. Search the catalog and inspect facts, results, categories and version before choosing a compatible rule.
6. Open **Full lineage** only when needed. Return to Data or to **Guided steps / Full BPMN** without losing the selected workflow.
7. Switch **Light mode / Dark mode** in the header. The preference is not a workflow change.
8. Open **Test -> Run local fixture**. With the supplied padded Owner value, the default comparison proposes an update. Adding a trim rule can instead produce **No change**. Setting `simulateWriteMismatch` to true in the fixture produces the explicit verification-mismatch branch.
9. Use **Export BPMN XML**, then **Import BPMN XML** to reload this prototype's supported profile. **Inspect XML** shows the same mappings and real rule tasks, not a hidden JSON workflow.

See [the detailed user guide](docs/01-USER-JOURNEYS.md) for exact controls, errors and examples.

## The document to give Devin

**[EDITABLE-MODELING-HANDOFF.md](EDITABLE-MODELING-HANDOFF.md)** is the complete current feature specification: rationale, decisions, screen behavior, atomic commands, XML/XSD mapping, compiler/runtime boundaries, milestones, acceptance criteria and limitations. It includes all eight current documents under docs/, plus the QA summary. The separate documents are retained for targeted implementation.

**ASK-MODE-HANDOFF.md** and **DEVIN-ASK.md** are byte-identical copies of that master. Their paste-size compatibility with Devin has not been tested. The separate native AMIE/Matthew questions document from the wider project is not included.

Start an implementation session with **[DEVIN-START.md](DEVIN-START.md)**. Keep the broader approved Unity handoff for platform requirements; this package is the current detailed specification for the editable contextual modeling feature, not a replacement for every platform subsystem.

## Package map

| Path | Purpose |
|---|---|
| OPEN.html | Current self-contained interactive designer |
| START.html | Human-readable entry point |
| assets/ | Inspectable base-builder and new modeling source |
| docs/ | Eight current detailed specifications |
| schemas/unity-modeling-v3.xsd | Proposed Unity extension schema, not an AMIE replacement |
| examples/ | Two actual exported BPMN examples, with and without a data rule |
| previews/ | Actual browser screenshots, light/dark and small-screen |
| qa/ | Reproducible build, browser checks, XML checks and their evidence |
| reference/ | Unmodified prior v2 prototype/specification; historical reference only |
| FILE-MANIFEST.json | Current file hashes and sizes, excluding the manifest itself |

## What is real and what is simulated

**Real local interactions:** selection, nested field mapping, source chooser, typed connection checks, rule chooser, fixture-rule parameter editing and preview, BPMN rule insertion, Undo/Redo, menus, light/dark theme, lineage, fixture execution and supported-profile XML round-trips.

**Not connected:** CyberArk, Email, Kafka, the live capability registry, AMIE, BOB, identity, the database or production release services. Nothing in this prototype sends an email, changes an account or grants production authority. Sample schemas/statuses are illustrative.

AMIE remains the existing engine and native XML serializer. Demo rule parameters are explicitly `fixture-only`. Do not turn this JavaScript evaluator into a production AMIE implementation.

The proposed Unity XSD was validated against the actual extension subtrees. **Full official OMG BPMN 2.0.2 XSD validation was not run in this environment.** The QA report explains the separate schema, reference, semantic and UI checks. This prototype supports its own emitted structured v3 XML profile, not arbitrary BPMN imports.

## Preservation and safe review

This is a new folder and storage key; previous delivered files are not overwritten. Browser Save depends on local storage policy. Export XML for a portable draft; sensitive data must not be entered into the demonstration. Preserve the authoritative native AMIE and BOB implementations during the source-audit phase. A new UI specification is not permission to replace working contracts.
