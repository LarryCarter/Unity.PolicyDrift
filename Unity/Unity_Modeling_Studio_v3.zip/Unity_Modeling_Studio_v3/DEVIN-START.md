# Devin start - editable contextual BPMN / Data / AMIE modeling

Read EDITABLE-MODELING-HANDOFF.md as the current feature specification. Open OPEN.html and complete the user journeys. The prototype's fixture engine and contract namespace are design demonstrations, not pre-approved production code or AMIE formats.

## Non-negotiable first gate

Inspect the actual repository AGENTS.md, existing BOB interpreter/compiler, central and embedded hosts, AMIE XML serializer/evaluator, operation registry/SDK, editor draft state, revision service, permissions and current Blazor components. Record verified file paths, interfaces, regression fixtures and incompatibilities. Do not invent repository paths or claim source verification from this design ZIP.

Keep working AMIE, BOB, SDK and authentication/group contracts. Reuse existing implementations; extend through compatible adapters. Request an explicit architecture decision for any unavoidable breaking change. Never replace the native AMIE engine with the demo rule evaluator.

## Implement this product behavior

One workflow with contextual depth: **BPMN process -> selected activity -> object -> field -> rule**. Keep the selected process node and branches visible. Preserve the established guided builder, capability/AMIE catalogs, three-dot and right-click menus, popovers, Undo/Redo, testing and release journey.

Make mappings and rule bindings editable at their point of use. Data connections are not sequence flows. Inserting an AMIE data rule materializes one visible Business Rule Task plus explicit inputs/outputs and sequence connections in the same draft. No hidden second execution engine or duplicate mapping graph.

## Dependency-ordered work

Use the local story definitions CZ-301 through CZ-307 in docs/05-DEVIN-MILESTONES-ACCEPTANCE.md. Each has one owning milestone and distinct acceptance evidence. These are not Wells Fargo Jira issue keys and do not imply all work is currently missing.

1. Preserve and reconcile the existing model and contracts.
2. Implement shared draft commands and contextual controls using existing Blazor components.
3. Implement typed mapping analysis and atomic producer/rule insertion through the BOB compiler.
4. Host the real AMIE chooser/editor/evaluator through its existing interface.
5. Reconcile the proposed extension schema and native BPMN import/export with the actual serializer.
6. Validate journeys, negative cases, accessibility and light/dark themes.
7. Complete the integration/readiness gates; do not infer production readiness from a local prototype.

## Deliver evidence

For each focused PR provide actual changed paths, behavior before/after, tests, XML round-trip examples, native AMIE compatibility evidence, negative authorization/value/path tests, and unresolved dependencies. The first acceptance story is the CMDB custom-field enrichment example; the second is account onboarding with actual Safe/platform requirements. Do not hardcode those business rules into the generic engine.

The wider Phase 1 commitments remain parallel gateways, durable timers, interrupting timer/error boundaries and minimum durable human tasks, in addition to established core features. The small local fixture runner is not a reduction of that scope.

## Document status

Approved architecture is identified in the decisions document. Specific prototype component/API/XML names are proposed and must be reconciled. The supplied browser and extension-XSD checks are evidence of design behavior only. No live API, AMIE, BOB or production deployment was performed.
