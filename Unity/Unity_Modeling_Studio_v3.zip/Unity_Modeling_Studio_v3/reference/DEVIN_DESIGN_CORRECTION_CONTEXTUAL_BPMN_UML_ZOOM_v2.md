# WF Unity — Contextual BPMN → UML Drill-Down: Design Correction & Devin Handoff v2

**Decision status:** User-approved direction for the designer; interactive v2 is an offline illustration. The underlying production implementation, actual AMIE serializer, BOB contracts, capability manifests, and Unity extension XSD remain subject to source reconciliation.  
**Precedence:** This addendum corrects the **presentation/interaction model** of the prior UML Data Flow Designer v1. It does **not** supersede the previously ratified BOB/AMIE/capability architecture or authorize changes to existing contracts.

## 0. Why this correction exists

The standalone three-tab UML/BPMN prototype from the initial modeling package was too small and discarded too much work done in earlier WF Unity wireframes and the richer Visual Business Builder. It showed a handful of activities and two flat objects rather than the actual product: a capable, standards-rooted workflow authoring tool with a complete BPMN representation, AMIE binding, approved capability browsing, dynamic facts, typed mapping, branches, testing and release.

**Corrected product statement:** BPMN is the authoritative process and execution model. UML-inspired elements are a **contextual zoom level** for expressing what happens *inside or around a selected BPMN activity*, especially object structures, data flows, field mappings, and rule inputs. Users stay oriented to their exact location in the BPMN graph while they drill down. The designer does not split into unrelated BPMN, Rules, Data and Capability applications.

The user particularly values that developers from outside the project can understand BPMN, analysts can understand rules/data views, and AI assistants can consume the documented standards/Unity extensions. This is an educational and documentation advantage as well as an authoring advantage. Do not optimize external BPMN-vendor portability at the expense of Unity's useful authoring features, but retain standard BPMN process semantics and OMG XML/DI compatibility where supported.

## 1. Existing work that must be preserved

**Actual files inspected in the staged project handoff:**

- `Unity_Visual_Programming_Redesign_2026-11-17/OPEN.html` — richer, self-contained prior visual Business Builder; this v2 prototype **uses its code as its base**, instead of rebuilding it from scratch.
- `Unity_Visual_Programming_Redesign_2026-11-17/docs/01-UX-RESET-AND-NON-NEGOTIABLES.md` — unified user journey and preserving powerful semantics behind progressive disclosure.
- `Unity_Visual_Programming_Redesign_2026-11-17/docs/02-ONE-JOURNEY-A-TO-Z.md` — account onboarding author journey.
- `Unity_Visual_Programming_Redesign_2026-11-17/docs/06-BPMN-PRESERVATION-AND-EXPERT-VIEW.md` — guided concepts mapped to BPMN and deferred behavior rules.
- `Unity_Wireframes_Fixed/screens/wf-19-bpmn-2-0-designer.html`, `wf-21-bpmn-element-properties-inspector.html`, `wf-23-variables-data-typed-mapping.html`, `wf-24-bpmn-xml-diagram-interchange.html` — prior full designer and mapping coverage.
- `Unity_Wireframes_Fixed/screens/wf-27-amie-rule-library-matthew-review.html`, `wf-28-amie-rule-editor-fixture-candidate.html`, `wf-51-api-capability-workbench.html`, `wf-52-bounded-recipe-builder.html` — relevant AMIE, capability and recipe designs.
- `wf_unity_modeling/WF_UNITY_MODELING_ARCHITECTURE_AND_DEVIN_HANDOFF_v1.md`, `unity-modeling-prototype.xsd`, `example-workflow.bpmn` — prior modeling rationale and **PROPOSED prototype-only** schema.

**Preserve the established features, not merely their screenshots:** Workflows home; one Builder with Define → Build → Test → Release; guided Simple Steps and advanced BPMN view; full palette/phase gating; add-before/after/in-branch; replace, unbind, remove, duplicate, move, undo/redo; multi-route triggers and data-source adaptation; typed operation inspector and Service → API group/controller → Operation browsing; in-context AMIE discovery/authoring; approval policies; loop and timer/error modeling according to supported BOB subset; data-binding validation; context-linked Test diagnostics; source/lineage assistance; governance and release; signed versioned BPMN XML/DI with pinned dependencies and AMIE XML; DEV/UAT/PROD only. **Do not regress these while adding contextual UML views.**

The older self-contained builder uses one `application` and one `category` field in its mock UI. That is a **historical demo limitation, not a newly ratified requirement**: the approved direction is to avoid forcing workflow ownership under a mandatory application and to allow multiple business categories/tags. Preserve categories and scoped permissions without reintroducing mandatory application/workspace semantics.

## 2. Levels of modeling (one workflow and one source of truth)

| Zoom level | Primary question | User interface | Canonical ownership |
|---|---|---|---|
| Workflow index | Which process should I work on? | Workflow list, categories, permissions, drafts | Unity workflow registry |
| **Level 1 — BPMN process** | What happens, in what order, and where are branches/waits? | Full supported BPMN canvas; guided steps where preferred | BPMN 2.0.2 process graph and DI |
| **Level 2 — Activity detail** | What is this selected activity doing? | Contextual tabs: UML-style Data / AMIE Rule / Capability / Lineage | Same BPMN activity ID and pinned contracts |
| **Level 3 — Field detail** | Where does this nested value originate, where does it go, and how is it transformed? | Expanded object, nested property, collection/item scope, field-level mapping and provenance | Typed endpoint IDs and per-activity mapping metadata, serialized in BPMN extensions |

There is no independent data-flow runtime, no standalone UML process engine, and no duplicate workflow execution graph. BPMN controls sequence and tokens. AMIE controls rule evaluation. Capability handlers perform approved operations. Shared Data Contract Resolver/BOB compiler proves types, paths, policy and host compatibility. A field mapping does *not* create a BPMN sequence dependency.

## 3. Mandatory continuity of BPMN context during drill-down

1. The user selects a BPMN activity in the full canvas or guided builder. The activity ID, task type and branch/parent path are stable.
2. A **Zoom into activity** action opens detail *within the same Builder*, not another standalone destination. It can also be reached from the existing right inspector, context-menu `⋯`, and keyboard selection.
3. The activity remains highlighted in a **persistent BPMN context strip or pinned miniature graph**. A visible breadcrumb shows Workflow → parent subprocess/call activity → branch → selected activity. The context strip must render **actual branches as separate paths**, not flatten a Yes/Otherwise fork into misleading execution order.
4. The user can click another BPMN node in the context strip; the detail content updates to that node while selection remains synchronized. A “Full BPMN diagram” action returns to the full canvas with the same node selected, focus/scroll restored, and the inspector still accurate.
5. The detail workspace can show Data, Rule, Capability or Lineage according to the node. A Business Rule Task may default to AMIE Rule; a Service Task may default to UML-style Data; a gateway may default to conditions; a CallActivity opens or exposes its referenced L2 workflow in a nested breadcrumb.
6. Any change uses the **same draft graph and mutation/undo mechanism**. On returning to BPMN, edited mappings, rule bindings and validation badges must be reflected. Removing a producer must result in downstream invalidation, not silent field replacement or deletion.
7. Expert imported BPMN elements that the guided view cannot model must remain preserved/inspectable; they must not be converted to generic tasks or silently dropped.

**Avoid screen proliferation:** Detail modes are *perspectives of the selected BPMN node*, not independently saved executable artifacts.

## 4. UML-inspired data modeling: small scope, full usefulness

Adopt only these concepts for now:

- **Object types and instances** with stable IDs, versioned contract/source refs and readable names.
- **Typed properties** (including nested objects, optional and required fields, nullability, primitive/enum/object types and sensitive classifications).
- **Associations and multiplicity** (1, 0..1, 0..*, 1..*), collection/item context for For Each, and explicit join/lookup provenance when applicable.
- **Object flows, ports and field mapping edges** between request, AMIE, capability inputs/outputs, earlier task outputs, approved config and approved producers.
- **Rules, decision and loop notation** borrowed from standard business logic, while BPMN gateways/loop constructs and AMIE remain the execution authorities.
- **Visual placement** for object cards and field connection routing, separate from BPMN DI for the process diagram.

Do not adopt UML state machines, UML deployment diagrams, UML executable activity semantics, or a full UML XMI stack without an identified use case. The user must not have to study UML terminology to connect data: display “Object”, “Field”, “Map”, “List of items”, “Where from?” and “Used by”.

### Node-specific behavior

| Selected BPMN node | What is zoomed into | What stays visible |
|---|---|---|
| Service Task | Approved operation typed contract, source facts → input ports, output object, failure behavior, side effects | Selected BPMN serviceTask and upstream/downstream nodes |
| Business Rule Task | Existing AMIE rule/facts/conditions/outcomes, inputs and downstream gateway | BPMN businessRuleTask, gateway, Yes/Otherwise paths |
| XOR gateway | Choice condition and data/branch availability | Branch destinations, join/terminate context |
| CallActivity / Subprocess | Nested workflow/subprocess BPMN with parent breadcrumb; cross-host boundary | Enclosing L1/L2 call node highlighted |
| For Each / Multi-instance | Collection input, `item` object scope, cardinality, outputs, order/concurrency setting | Underlying BPMN multi-instance semantics |
| Timer/Error boundary | Trigger/handler configuration, resume/error path, outcomes | Attached activity, boundary symbol, outgoing path |
| Data enrichment | Field-level transforms and approved mapping recipe preview | BPMN execution position and producer/consumer graph |

**Important:** Do not turn every capability handler into a workflow. Simple typed handlers are operations; embedded BOB L2 processes are used only where multi-step orchestration is needed.

## 5. Mapping interaction contract

The Data detail tab displays source objects on the left and target input object/ports on the right; expanding nested fields shows the same schema at greater detail. Connections are created by selecting source and destination, optionally drag-and-drop; both mouse and keyboard must work. Every field edge should show source, typed destination, semantic identity, mapping transformation (if any), cardinality/item scope and a validation state. A right-side inspector explains errors without forcing the author to leave the process.

**Resolver checks before accepting or publishing mappings:**

1. Stable source field ID and destination field/port ID resolve to the intended pinned contract versions; readable names alone are not identity.
2. Producer exists in the active host and is on all paths reaching the consumer (dominance / conditional availability). BPMN data association does not order work.
3. Types, nullability, shape, multiplicity, list-item scope and units or identifiers are compatible. Two `String` fields need not be interchangeable (e.g. `platformId` ≠ `safeId`).
4. Security classification, operation permission, source visibility and service identity are allowed; secrets/values are not baked into XML or logs.
5. Any conversion is an approved deterministic transform or recipe, not arbitrary user-supplied C#/JS/SQL/REST.
6. When an input is missing: first offer reuse of an existing upstream producer, then relevant approved operation such as CyberArk.GetAccount, then a recipe or explicit external input *only when appropriate*. Never expose every internal operation input as a new form field.
7. `Add Get Account and Connect` is **one atomic undoable draft change**: validate/insert actual BPMN serviceTask, wire request/account ID to its approved input, wire output account object to AMIE or consumer, re-run path/type/security checks. No CyberArk execution during design.
8. Bad mappings are visible with diagnostics, blocked from publish, and do not falsely pass because basic XML schema validation succeeded.

**Scope selector:** This activity (default) or Whole workflow lineage. Both are projections over the same data graph; no redundant mapping files created for ordinary workflow wiring.

## 6. XML, XSD and diagram schema contract (proposed, not final)

- **Canonical executable graph:** OMG BPMN 2.0.2 XML, semantic IDs and standard BPMN DI geometry.
- **Native BPMN where meaningful:** `dataObject`, `dataInput`, `dataOutput`, `dataAssociation`, `itemDefinition`, activity input/output specifications and task/event/gateway structures. Use standard elements to the degree the actual BOB compiler supports and preserve unknown elements carefully.
- **Unity namespace extensions:** `dataModel`, object/property definitions and relationships; activity-scoped `mappings` referencing stable typed endpoints; `dataView` visualization metadata; contract/recipe references where needed; semantic schema version. Design these extensions to fit BPMN `extensionElements`. Version/migrate deliberately; use a separate Unity XSD for shape validation.
- **AMIE:** Existing Matthew-owned AMIE XML, serializer, evaluator, and rule contracts remain authoritative. BPMN references the proper rule/version/binding. A visual decision table is a *projection* of actual AMIE logic, never a made-up alternative serializer.
- **Capabilities:** Existing SDK and approved registry supply operation IDs, input/output shapes, host, side effects, permissions and pinned versions. The designer only binds to those; registration and authorization are distinct.
- **Rule/process visualization:** BPMN DI models BPMN diagrams. Unity diagram metadata can store UML object-card positions, field routing, collapsed state and zoom; it must not change BPMN execution semantics.
- **XSD nuance:** Unity XSD validation proves XML shape only. It does not cause a generic BPMN editor to draw UML objects or execute mappings. Unity needs its own model adapter, renderer, serializer and compiler; third-party editors may discard unknown extensions. This is acceptable if intentional, documented, and tested for our supported import/export behavior.
- **Round trip:** Source BPMN XML/DI + Unity extension preservation + AMIE contract references survive save/export/reimport with equivalent semantics and stable IDs. Validate XML with **actual OMG BPMN 2.0.2 schema**, Unity XSD, and **separate executable semantic/compiler tests**. Unsupported executable constructs may remain draft-only and must be publish-blocked.

The v1 sample XSD is **not production-ready**. It lacks nested object semantics, relationships, collection scope, stability rules for typed endpoint identity and robust data-view shapes; the v1 generated fragment uses display paths as references, not immutable canonical IDs. Do not put that prototype schema into production unchanged. First inspect actual BOB binding conventions and SDK manifests, then finalize the schema and fixtures without overwriting existing contracts.

## 7. Preserving the original author journey and enabling enterprise modeling

**Business author:** Define trigger → Add approved capability → Pick AMIE rule → Map simple facts with suggestions → Add approval/branches → Test → Request release; no need to use UML jargon.

**Process analyst:** Switch to full BPMN → select rule task → zoom to AMIE condition/decision representation → navigate lineage of each input → return to the highlighted gateway and business process.

**Capability engineer:** Enter capability-owned L2 orchestration → click local operation task → zoom typed input/output and internal transformation/mapping model → inspect host/side-effect contract → return to embedded BOB diagram; no second microservice orchestrator.

**AI/Devin:** Read BPMN model + documented Unity extension schema + AMIE contract/manifest + registered operation types → propose a *draft diff* with stable node/field IDs → compiler diagnostics → supervised approval; no invented handlers, permissions, credentials or automatic PROD release. Existing Devin-generated legacy BPMN/rules may be major reusable inputs, but their execution completeness must be measured against actual app behavior and regression fixtures.

## 8. Implementation stages and evidence gates for Devin

**Gate 0 — Source inventory, REQUIRED:** Read repository AGENTS, BOB parser/compiler/hosting, existing AMIE serializer/editor/permissions, SDK manifests, existing web designer, XML conventions and tests. List working screens/interactions and contracts **before making changes**. Give a before/after contract diff; STOP on incompatible assumptions.

**Gate 1 — UX preservation regression:** Confirm baseline operations (insert/replace/unbind/remove/undo/redo, pickers, guided/expert BPMN, AMIE editor, triggers, Test/Release) still work in production UI. Keep single draft ID and consistent change history.

**Gate 2 — Navigation and read-only zoom:** Selected activity highlight; parent/branch breadcrumbs; source/target object visualizer; nested data and AMIE projections; context-driven selection. No writes to AMIE or BOB yet.

**Gate 3 — Typed mapping editor:** Actual SDK/AMIE schema adapters; field connector UX; semantic mapping, branch analysis, missing producer suggestions, undo; Unity extension round-trip with production XSD.

**Gate 4 — Rich logic:** AMIE native editing adapter; branch/loop/multi-instance views; error/timeout details; no unsupported BPMN execution claim.

**Gate 5 — Source-based end-to-end proof:** Reopen Devin legacy BPMN + real AMIE rules + CyberArk GET → compare → PATCH changed authorized fields only → GET verify; test missing-data resolution and crash/error paths. Prove BOB runtime has one interpreter shared across central/embedded hosts. No arbitrary microservice orchestration.

**Gate 6 — Release:** Signed immutable DEV→UAT→PROD artifact, version pins, appropriate approvals and ServiceNow change reference for PROD, environment binding checks, audit and no silent contract rewrites.

## 9. Acceptance criteria

- [ ] Selecting a node in Simple Steps or full BPMN opens detailed modeling without leaving the Builder.
- [ ] The selected BPMN node is highlighted in a process context and its parent/branch path is unambiguous; navigation never flattens conditional branches into false serial execution.
- [ ] Data, Rule, Capability and Lineage tabs derive from the same step ID/version, typed contracts and AMIE rule.
- [ ] A mapping edit in zoom immediately appears in the original inspector; undo/redo works across both surfaces; reload/save/reimport preserves it.
- [ ] Full BPMN view, operation and rule pickers, step ellipsis actions, guided mode, Test and Release all retain previous behavior.
- [ ] Nested objects, nullability and collection scopes are representable without treating strings as interchangeable identifiers.
- [ ] The approved CyberArk producer-add shortcut is one atomic BOB graph-and-binding edit, with end-to-end validation and undo.
- [ ] A rule visualization opens the *existing* AMIE rule through an approved adapter; no invented XML/rule semantics.
- [ ] Object/field layout survives Unity extension export/import, BPMN DI stays valid, unknown extensions are handled explicitly.
- [ ] All write side effects require approved operations/permissions, safe retry/reconciliation, and release governance; UI-only configuration does not authorize execution.
- [ ] The developer can show source-based contract comparisons, semantic tests, browser regression, and screenshots with no regressions in the existing runtime or authoring UX.

## 10. What this v2 offline prototype actually demonstrates

**Working in the local HTML:** The original rich Business Builder remains present. Zoom into a selected activity; maintain a BPMN context strip with branch grouping and highlighted activity; click other nodes; inspect object fields and typed source-to-input mappings; select a source and target, block demonstrable type/semantic mismatches in the example, update the **original draft** and inspector, undo/redo; show AMIE decision/fact context without modifying AMIE; inspect capability metadata; view source/lineage and an illustrative XML fragment; insert a preceding step using the original approved-resource picker; return to the original guided/BPMN editor; continue to Test and Release stages. This is a browser-only demo.

**Still illustrative / unimplemented:** The mini context strip is *not* a conformant BPMN-DI renderer; the nested `CyberArkAccount.customFields` object is a design sketch, not an operation schema; nested mapping and recipes are not executable; AMIE UI is a read-only illustrative projection, not a real editor; `unity:mappings` preview uses draft paths, not canonical contract IDs; no actual production BPMN/XML import/export, no complete extension XSD, no backend, permission checks, BOB, AMIE, SDK, Kafka, CyberArk calls or release signing. The original demo `CATALOG` declares example statuses only. Do not claim any of these features are production-implemented.

**Browser verification in this packet:** Playwright/Chromium passed scripted interaction tests for opening the original workflow, zoom context highlight, UML fields and drawn mapping edges, improper semantic field rejection, updating the shared original draft, original undo/redo, switching to AMIE Rule and Capability, showing the illustrative XML, returning to the original BPMN/Guided views, entering the Test stage and opening the existing operation picker. No page-level JavaScript errors were observed in those checks.

## Decision guardrail for future specifications

> **Do not replace existing working interfaces, AMIE contracts, BOB runtime behavior, capability interfaces or approval/security controls to implement UML zoom. UML is a selectively adopted visual-and-metadata layer surrounding the selected BPMN activity; existing systems remain authoritative. Every deviation must be justified through a source-based incompatibility report and approved explicitly before code changes.**
