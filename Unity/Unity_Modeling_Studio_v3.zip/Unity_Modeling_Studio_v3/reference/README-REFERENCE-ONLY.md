# Historical reference only

These are unmodified source copies of the supplied contextual zoom v2 prototype and correction document. They establish what was extended and support regression comparison.

Do not implement this older view as the current design. Open ../OPEN.html and read ../EDITABLE-MODELING-HANDOFF.md instead. Hashes recorded in ../qa/source-checkpoint.json identify the original baseline. New work leaves the original files untouched.
