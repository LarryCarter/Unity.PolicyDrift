# 3. Exact UI-to-XML/XSD contract and existing AMIE boundary

## 3.1 Three independent responsibilities

The XML schema defines valid structure. The compiler defines valid meaning. The renderer defines how people see and edit it. Loading an XSD does not teach a generic BPMN tool to draw a Unity object card or evaluate an AMIE rule. A renderer adapter, command layer and serializer are required.

This packet supplies a **proposed prototype XSD**, examples exported by the actual browser, and an extension-validation runner. It does not certify a production BPMN profile or replace an existing BOB binding schema.

## 3.2 Authoritative storage

The workflow artifact is BPMN XML with native process elements, data objects, input/output specifications, data associations and diagram interchange. Unity-specific field selection and typed bindings are carried in namespace-qualified extensions. AMIE's actual rule logic remains in its own existing native XML, referenced by the workflow. Workflow-local AMIE changes must be serialized into the actual AMIE draft/release artifact by the existing adapter.

No second editable JSON graph is embedded in the exported BPMN. The browser may keep a convenient JavaScript object in memory and a debug JSON snapshot, just as an XML editor may use an object model internally. The XML is the interchange artifact. A workflow-specific mapping is versioned with the workflow, not in a separate live mapping service.

## 3.3 Prototype namespace and concrete elements

Namespace: `urn:wf-unity:modeling:prototype:3`.

The prototype puts `unity:workflow` and `unity:types` in the BPMN process's extensionElements and `unity:activity` in each actual BPMN activity's extensionElements.

| UI/model item | Exact XML representation | XSD owner | Meaning |
|---|---|---|---|
| Workflow title/revision | `unity:workflow/@name`, `@revision` | WorkflowType | Draft metadata, not production approval |
| Multiple business categories | Repeated `unity:category/@name` | WorkflowType sequence | Classification; no permission inheritance |
| Multiple launch configurations | Repeated `unity:launcher/@kind` | WorkflowType sequence | Fixture references to input adapters, not extra BPMN control tokens |
| Declared request input | `unity:request/unity:field` | FieldType | Key, typeRef, label and required flag |
| Object structure | `unity:types/unity:object/unity:field` | TypesType, FieldType | Sample registry snapshot; labels do not change keys |
| Process instruction | Native `bpmn:serviceTask`, `businessRuleTask`, `userTask`, etc. | OMG schema | Control-flow semantics remain BPMN |
| Registered operation/rule | `unity:activity/@resourceRef`, `@version` | ActivityType | Pinned fixture registry identity; runtime must resolve trusted registry |
| Input mapping | `unity:activity/unity:map` | MappingType | One canonical source endpoint and destination key |
| Data-rule grouping in a wire | `unity:activity/@consumerRef`, `@targetRef` | ActivityType | Presentation relationship pointing at a real rule task |
| Rule's incoming/outgoing information | Native ioSpecification/dataInput/dataOutput and data associations | OMG schema | Contract-level item flow; detailed field selection remains explicit in Unity mappings |
| Decision output | `unity:activity/@decisionOutput`; native exclusive gateway and conditional sequence flows | ActivityType + OMG schema | Selected Boolean outcome drives Yes; default flow is Otherwise |
| Operation deadline | `unity:activity/@timeout` as xs:duration | ActivityType | Deadline setting; it is not itself a BPMN boundary event |
| Fixture-only local rule edit | `unity:ruleDraft adapter="fixture-only"` with param entries | RuleDraftType | Demonstration input to a local fixture, explicitly not native AMIE XML |
| Process layout | `bpmndi:BPMNShape`, `BPMNEdge`, DC bounds and DI waypoints | BPMN DI/DC/DI | Native process geometry |
| Theme / open menu / search | Browser UI state only | None | Not workflow behavior |

`typeRef` and mapping endpoint locators resolve against pinned contracts. In the fixtures, immutable contract keys and node IDs form locators such as `steps.get1.account.properties.Owner`. They are not user-entered display labels. The production adapter must preserve any stronger field IDs already in the SDK and map them consistently to the serializer. A label rename cannot invalidate a mapping; a contract-key/type change is a compatibility event.

## 3.4 A rule on a mapping is not hidden inside the mapping evaluator

Before:

`request.desired.Owner -> compare1.desired.Owner`

After:

`request.desired.Owner -> Normalize.value -> compare1.desired.Owner`

The after state contains a real `bpmn:businessRuleTask` and a source/input mapping on that task. Its output is made available to the consumer through the ordinary successful-output data contract. A native sequence flow places the rule before the consumer. `consumerRef` and `targetRef` only help the UI draw that task as a purple rule card in the wire.

Illustrative extension fragment (the complete generated examples are under examples/):

```xml
<bpmn:businessRuleTask id="Rule_NormalizeOwner"
                       name="Normalize owner"
                       implementation="urn:unity:amie:adapter">
  <bpmn:extensionElements>
    <unity:activity kind="ruleTransform"
                    resourceRef="amie.normalizeOwner" version="1"
                    consumerRef="compare1" targetRef="desired.Owner">
      <unity:map id="Map_NormalizeOwner_Input"
                 fromRef="request.desired.Owner" toRef="value"/>
    </unity:activity>
  </bpmn:extensionElements>
  <!-- Native ioSpecification and data associations are also emitted. -->
</bpmn:businessRuleTask>
```

The consumer's mapping points to `steps.Rule_NormalizeOwner.value`. The native process graph, not the data canvas, controls when that rule runs. BOB invokes the existing AMIE adapter at the Business Rule Task. It does not run it again while assigning the result to the consumer.

This design deliberately favors explicit BPMN materialization over inventing an inline AMIE expression interpreter inside a mapping engine. If the existing BOB implementation already has a verified pure rule-transform primitive with equivalent semantics, reconcile the representation through a documented adapter; do not introduce a competing evaluator.

## 3.5 Object mapping and overrides

A mapping to `desired` supplies the whole object. A more specific mapping to `desired.Owner` supplies an explicit override. Resolution is deterministic: copy the source object into a new destination instance, then apply valid specific overrides. Duplicate explicit destinations are rejected. Sibling properties and upstream objects remain unchanged.

Native data associations describe the participating data items, while Unity field mappings define the detailed field-level projection. An external BPMN processor that ignores required Unity semantics is not a supported runtime. Do not claim that standard data associations alone execute Unity's object-overlay policy.

The sample type system includes object references and collection suffixes. It is not a complete UML metamodel. Production contract metadata must carry independent requiredness, nullability, cardinality, units, identifiers, security classification, read/write shape and schema revisions. Do not infer all of those from a property name or a C# display type. This prototype intentionally exercises a small subset.

## 3.6 Validation layers

1. **Secure parse:** reject DTD/entity expansion and unapproved external schema resolution; enforce size/depth limits. Parse without executing anything.
2. **BPMN XML schema:** validate native structure against the approved OMG 2.0.2 schema bundle. Do not rely on XML well-formedness alone.
3. **Unity extension XSD:** validate all required extension subtrees. Because extension wildcards can be lax, explicitly validate recognized Unity content instead of assuming the core schema checked it.
4. **Semantic compiler:** resolve contracts, types, semantic IDs, activity/field references, effect/host permissions, path availability, loop scope, freshness and branch outcomes.
5. **Release checks:** verify immutable dependency set, environment activation, review, integrity/signature and required change reference.
6. **Runtime checks:** enforce actual values, service identity, authorization, side effects and durable state rules.

The supplied `qa/validate_xml.py` performs Unity-XSD, reference and ID checks plus negative extension fixtures. Full official OMG schema validation was not run here because schema download was unavailable. Passing this script without `--omg-xsd` must not be reported as full BPMN XSD conformance. Supply the approved local schema bundle using `--omg-xsd /path/BPMN20.xsd` to add that gate.

## 3.7 Import/export scope and anti-loss behavior

The browser exporter handles the structured sample tree: ordinary service and business-rule tasks, data-rule tasks, exclusive decisions, explicit end outcomes, simple timers and the listed structural task kinds. Advanced imported semantics, unrestricted cycles, complex multi-instance scopes and arbitrary external extensions require the real compiler/importer. The prototype rejects unsupported forms instead of converting them to inert rectangles.

The browser importer supports only the emitted v3 profile. It preserves step IDs, mappings, rule references and fixture draft parameters, categories, launch-kind references, and native shape/edge geometry. It rejects an unavailable resource version, DTD content, unknown extension namespace, changed unsupported branch expression or an unreachable activity that would otherwise be dropped. It does not establish general round-trip compatibility with third-party BPMN editors.

The production importer must preserve recognized and opaque optional metadata when safe; any required executable extension it cannot interpret blocks execution. If lossless editing is impossible, it must keep the original file and explain the limitation, not save a silently reduced workflow.

## 3.8 AMIE adapter contract to reconcile, not replace

Devin should locate existing equivalents for these semantic operations:

| Need | Expected behavior |
|---|---|
| Discover rules | Retrieve published identity, version, category, description, required facts and outputs |
| Open rule for editing | Return an authorized draft/editor model derived from AMIE's actual schema |
| Validate a change | Use the existing AMIE validator and report conditions/outcomes/fact errors |
| Preview a rule | Evaluate explicit sample facts through the actual evaluator in an authorized test context |
| Save a rule draft | Create/update the authorized draft; do not mutate an approved version in place |
| Serialize/deserialize | Round-trip AMIE's existing XML without inventing alternative rule semantics |
| Bind in BOB | Resolve exact rule version and typed mappings through the existing local/central host adapter |

These are not mandates to create seven new APIs. Adapt whatever already exists. The local demo parameter editor and JavaScript evaluator must never be copied into production as a replacement rule engine. The fixture-only XSD marker is intentionally not a path to production activation.

## 3.9 Storage and versioning

Use the existing `uty_` schema ownership and draft/publish model. The workflow owns ordinary mappings. Rules retain their own existing AMIE identity/version. Capability contracts retain their existing registered identity/version. A published process pins its references; running instances do not silently change when a new draft is edited.

UI details such as collapsed object cards can be serialized into an approved presentation-only extension after actual source reconciliation. The prototype keeps those UI details in local view state and does not claim to persist a second UML layout file. Native BPMN DI is preserved for the emitted profile.
