# 4. Data resolver, compiler behavior and execution boundaries

## 4.1 A green connection has a precise meaning

A green connection means the designer has resolved a declared source and destination under the current validation scope. It does not mean that an external API call has succeeded, that the source value will never be null, or that the workflow is approved for production. The UI must distinguish `connected`, `valid for test`, `verified execution evidence` and `approved/activated`.

The browser prototype verifies matching nominal fixture types, source presence on a conservative structured path, required versus optional source availability, collection/scalar distinction, selected domain identifiers, known binding references and a small rule-slot contract. The production compiler must add the complete existing engine semantics. Do not copy these small JavaScript checks and call them the BOB compiler.

## 4.2 Required production analysis

| Concern | Required check | UI result |
|---|---|---|
| Binding identity | Producer, port, property and consumer exist in pinned schemas | Missing/removed field diagnostic |
| Data type | Assignability, enum/domain values, precision and structural compatibility | Explain mismatch; offer only approved conversion |
| Requiredness | A required input is supplied on every executing path | Unresolved or guard/default suggestion |
| Nullability | Optional absence, explicit null and empty string are different | Explicit policy/guard, not silent coercion |
| Cardinality | Scalar, optional object and collection agree | Choose item/For Each/aggregate explicitly |
| Semantic identity | AccountId, SafeId, PlatformId, units and entity keys mean the intended thing | Block unsafe identifier substitutions |
| Execution path | Producer successfully executes before consumer in the same applicable scope | Future/sibling-path source blocked |
| Outcome paths | Failure, timeout and cancellation do not yield success-only outputs | Handler-specific facts or missing-data error |
| Freshness | Pre-write snapshots cannot satisfy a post-write verification requirement | Suggest a new read after the write |
| Security | Author can bind/use resource in workflow scope; service operation remains approved | Backend deny; no UI-only enforcement |
| Information classification | Sensitive values cannot be routed to an unauthorized sink | Block mapping/export/log display |
| Host | L2 local operation is available in the capability host; remote operations have approved dispatch adapters | Explicit call/adapter, not a hidden network hop |
| Rule purity | A compact data-rule slot has no hidden I/O or durable wait | Use an ordinary BPMN activity when necessary |
| Version | Workflow pins operation/rule schemas and execution requirements | Version mismatch / migration review |

A GetAccount operation's success output is available only on the successful path. An error boundary leading elsewhere does not implicitly carry that account object. A retry of an uncertain write cannot be justified by a successful type check. Operational outcomes and business-rule decisions remain different facts.

## 4.3 Analysis order

Read the canonical BPMN model and required Unity extensions. Resolve registry and AMIE contract identities. Build the control-flow graph and execution scopes. Compute data availability on successful, error and timeout paths. Apply explicit mappings and approved rule/transform semantics. Check consumer requirements and produce diagnostics with activity IDs and property references. Compile the unchanged BOB execution representation through the existing pipeline.

In a sequential path, successful outputs become available to later tasks. At an exclusive merge, only values guaranteed on all reaching paths are automatically available, unless a declared guarded union/merge provides a typed alternative. At a parallel join, completion of the needed branches must be proven; conflicting writes to the same logical destination require an explicit merge policy. In a For Each scope, values are item-scoped; another iteration's account object cannot be reused accidentally. Shared-memory aliasing is not a mapping contract.

These are semantic checks. The XSD cannot prove dominance, path availability, read-after-write freshness, or authority. XML parsing cannot prove them either.

## 4.4 Atomic proposal/commit shape

The real application should use the existing draft command API with equivalent semantics to:

```text
Propose(connection or insertion, draftRevision, consumerId, targetPort)
  -> resolved source, candidate rule/operation, proposed structural diff,
     affected mappings, warnings, plan fingerprint

Apply(approvedPlan, expectedRevision, commandId)
  -> newRevision, persisted diff, diagnostics, stable created IDs
```

These are conceptual operation names, not a requirement to add a second command service. The backend rechecks current authority, catalog versions and revision when applying. Duplicate command IDs return the previous result rather than duplicate a lookup or rule. Failed checks leave the draft unchanged. Undo/redo must restore all related graph and mapping mutations, while recorded audit history remains append-only.

The browser demonstrates a single local history transaction. It does not implement concurrent editors, backend ETags, leases or distributed rollback. Those belong in the existing infrastructure and must be tested separately.

## 4.5 Runtime materialization of data rules

An inserted NormalizeOwner task is an ordinary BOB Business Rule Task bound to the existing AMIE adapter. BOB maps facts, invokes AMIE once, persists/propagates its typed result according to the current host contract and advances its token. The consumer receives that output using the same mapping mechanism as any other activity output.

Do not implement a second recursion-based interpreter just for purple data-flow wires. The diagram might visually compress the rule task into a mapping, but native BPMN order remains authoritative and inspection/export must reveal it.

A shared Enrichment capability may provide reusable pure conversion operations and authoring recipes. External retrieval stays with the owning capability; cross-service sequencing stays with BOB. Simple field projection should not require a network call to an enrichment service. Complex lookups appear as explicit operations, and business decisions remain AMIE rules.

## 4.6 CyberArk reference case

The incoming message represents one staged row: Account ID plus four desired custom-field values. Source adapters handle BE forms, CSV columns, API payloads and Kafka messages separately from the workflow's normalized request. The exact source adapter definition should reference the owning data service; BOB should not query another component's private database.

The workflow obtains current account data, compares permitted fields through AMIE, avoids unnecessary writes, applies only authorized changes, retrieves the account again and verifies the change set. The mock deliberately normalizes the account into `account.properties`; do not mistake that sample DTO for the actual CyberArk response schema. The installed API/SDK contract remains authoritative.

For real partial-update APIs, the adapter translates the allowed change set into the documented request. For full replacement APIs, the adapter/workflow must explicitly preserve untouched data and address concurrency. This packet does not alter the previously discussed distinction. Do not add an invented AddOrUpdate behavior to a vendor endpoint merely because the visual flow is convenient.

Kafka redelivery, idempotency, uncertain writes, stale snapshots, retries, cancellation and reconciliation remain existing capability/BOB concerns. A diagram edit has no such side effect. The service identity used for the API is independent of the user's BE group membership; Unity controls the user's workflow actions, and the receiving service verifies approved command/binding authority.

## 4.7 Diagnostics and repair actions

Every diagnostic needs a stable code, severity, node ID, destination/source reference, plain-language explanation and safe repair action. Examples in the prototype include INPUT_UNRESOLVED, SOURCE_UNAVAILABLE, TYPE_MISMATCH, OPTIONAL_SOURCE, SEMANTIC_ID_MISMATCH, OBSOLETE_MAPPING, DECISION_OUTPUT and ERROR_PATH_REQUIRED.

A field should say **Account data is missing. Get Account can supply it using the incoming Account ID**, not merely `null reference`. A future producer should say **This value is produced after this activity**. A stale verification source should say **This account was read before the update; choose the later Get Account result**. A collection error should explain whether an item, a list or an explicit aggregation is needed.

Saving a draft with diagnostics is allowed. Testing a structurally invalid input path is blocked in the fixture. Production validation/publish/activation applies the complete governance policy, not only the green badges in this browser.

## 4.8 Production security checks are not postponed by the prototype

No arbitrary JavaScript/C#/SQL, URL selection or credentials may be imported through a mapping. Only registered operations, approved rules and constrained conversions may execute. Treat XML and imported packages as untrusted input. Apply parser depth/size/entity controls, dependency allowlists and signature validation at the appropriate release boundary. Do not fetch remote XSDs named by an untrusted file during import.

The production ServiceNow field is initially a mandatory change reference, not proof of ticket approval and not live ServiceNow validation. Production authorization uses approved entitlements and release policy. Experimental visualization does not bypass missing runtime handlers or production eligibility rules.
