# 5. Devin execution instructions, milestone-linked stories and acceptance

## 5.1 Start instruction

Read the master document in order, then inspect the current repositories. Preserve existing BOB, AMIE, capability SDK, group/identity and serializer behavior. The JavaScript is an interaction reference and local fixture, not production domain logic to transplant. Reuse existing Blazor components and draft commands where they satisfy this contract. Do not add a separate UML engine, AMIE engine, mapping service or rule serialization format.

Keep the currently approved expanded BOB Phase 1 features; do not mistake this browser's limited execution fixture for a reduced runtime scope. Record existing versus missing behavior with source locations and tests. Do not silently turn an unknown into an architectural decision.

## 5.2 Milestone ownership

The planning IDs below are local handoff identifiers, not actual Jira records. Each story has one owning milestone in the previously agreed structure. Existing Jira creation/mapping is handled on the Wells Fargo side. Completion should be reported by accepted stories and their evidence, not screenshot counts or arbitrary percentages.

| Story | Owning milestone | Outcome | Depends on |
|---|---|---|---|
| CZ-301 | M0 - Architecture reconciliation | Existing-model and AMIE adapter compatibility assessment | None |
| CZ-302 | M4 - Blazor interfaces | Context-preserving editable object/field controls and shared menus | CZ-301 |
| CZ-303 | M3 - BPMN Phase 1 execution | Typed mapping resolver and atomic draft commands | CZ-301 |
| CZ-304 | M2 - BOB/AMIE integration | In-context rule catalog/editor and materialized data rules | CZ-301, CZ-303 |
| CZ-305 | M3 - BPMN Phase 1 execution | Canonical XML/DI extension adapter and round-trip validation | CZ-303, CZ-304 |
| CZ-306 | M4 - Blazor interfaces | Themes, guided navigation, contextual help and accessibility | CZ-302 |
| CZ-307 | M6 - UAT / readiness | Two complete authoring journeys with regression evidence | CZ-302 through CZ-306 |

These stories extend the relevant milestones; they do not replace the unrelated capabilities, enterprise integrations or production-readiness work already agreed.

## CZ-301 - Reconcile the existing draft and rule contracts

**Scope:** Locate actual BPMN storage/compiler/host code, the current draft mutation/undo APIs, SDK input/output metadata, native AMIE rule XML serializer, rule editor model, permissions and versioning mechanisms. Identify the minimum adapters required for this UX.

**Deliverable:** Source-backed compatibility matrix with real repository paths; existing vs adapted vs missing; regression fixtures; proposed namespace/schema changes; rejected duplicate implementations.

**Acceptance:** No existing contract is replaced merely because a mock uses different names. At least one real stored BPMN and one actual AMIE XML rule are imported, reserialized and regression-tested through existing code. Every proposed breaking change is explicitly identified and not implemented without approval.

**Evidence:** Tests and source references, not a generic architecture statement.

## CZ-302 - Build the contextual editable surface

**Scope:** Persistent BPMN highlight/breadcrumb; expandable typed objects; root/field selection; change-source dialog; click-and-connect and keyboard alternative; field overrides; selectable rule cards; three-dot/right-click menus; same draft store and undo.

**Acceptance:** An author can map a whole object, override one nested field, remove that mapping, undo it, switch to the process view and return without a duplicate configuration. Selecting another BPMN activity updates the available data and the highlighted context. Removing a producer displays dependent failures. The kebab opens actual actions on both guided and zoomed elements.

**Evidence:** Blazor component tests plus browser journeys using declared contracts, not hardcoded labels. Negative paths must prove wrong types and unavailable data do not create accepted mappings.

## CZ-303 - Resolve typed data and apply atomic commands

**Scope:** Endpoint identity, versions, type/cardinality/nullability, semantic IDs, path/branch/loop availability, purity/host constraints, missing-data suggestions, producer reuse and freshness. Use the existing compiler. Add plan/apply support to the existing draft command layer if needed.

**Acceptance:** One-click Get Account produces one command, one task and correct bindings. Double-click/retry cannot duplicate it. A stale draft revision rejects without partial changes. An unrelated or stale account result is not silently reused. Future/sibling-branch outputs cannot satisfy required inputs. User confirmation cannot override a security or identifier-domain mismatch.

**Evidence:** Compiler fixtures, concurrent mutation tests, command idempotency tests, invalid import cases and successful valid cases.

## CZ-304 - Make rule selection and rule-on-mapping genuinely editable

**Scope:** Existing AMIE library adapter; search/category/detail; actual rule editor schema; preview/test; create draft without changing approved shared rule; compatible rebind; explicit businessRuleTask insertion on a mapping; remove/reconnect semantics.

**Acceptance:** A selected rule's actual required facts and outputs populate the designer. Changing a rule preserves activity ID and branches but invalidates incompatible bindings. Inserting a pure rule creates a native BPMN task and two bindings; BOB evaluates it exactly once through the existing AMIE adapter. Rule errors do not become empty strings or automatic approvals. Multi-fact rules cannot be squeezed into an incompatible scalar slot.

**Evidence:** Native AMIE serialization tests, evaluator tests, invocation-count test, schema-version compatibility tests, whole-transaction undo and real renderer projection tests.

## CZ-305 - Persist the actual model, not a hidden JSON twin

**Scope:** Standard BPMN structure/DI; approved Unity namespace fields; actual AMIE references; deterministic endpoint locators; mapping semantics; import preservation and validation. Adopt existing extension fields where possible rather than introducing another parallel schema.

**Acceptance:** Export -> import restores node and mapping identities, rule references, branch paths and required layout. Required unknown execution extensions block activation; editing must not discard them. Validate with the OMG schema bundle, the approved Unity XSD and separate semantic tests. Demonstrate failures for each layer. A visually correct diagram cannot pass merely because XML parses.

**Evidence:** Before/after semantic comparison, XML fixtures, XSD negative tests, unsupported-element preservation/rejection tests and snapshot round-trips. Native AMIE XML comes from the actual serializer, not the fixture-only format here.

## CZ-306 - Consistent themes, menus, descriptions and help

**Scope:** Shared semantic color tokens; text equivalents; menu keyboard behavior; focus management; narrow-layout support; meaningful descriptions; operation/rule category browsing; precise simulation/production wording.

**Acceptance:** Both themes retain readable selected/disabled/error states. Keyboard users can choose a rule, change a mapping, undo and return to the enclosing activity. No page-wide horizontal overflow at the tested narrow width; internal diagram scrolling remains available. Cancellation leaves state unchanged. Existing menus and pickers continue to work.

**Evidence:** Browser tests, keyboard walkthrough, contrast checks, screen-reader review and signed visual review. The supplied Chromium checks are not a complete accessibility certification.

## CZ-307 - Prove the complete journeys

**Journey A:** One staged record -> Get Account -> AMIE comparison -> patch changed fields -> Get Account again -> explicit verification result. Insert/edit a normalization rule on one custom field; demonstrate changed and no-change paths. Demonstrate mismatched verification and unavailable data.

**Journey B:** Account onboarding from a larger input contract with authorized Safe/Platform lookup outputs. Compose a typed account request, inspect a nested mapping, select a rule in context and preserve unresolved platform-specific requirements until supplied. This second journey uses real registry schemas; the browser's retained onboarding sample is not sufficient evidence.

**Acceptance:** A non-programmer completes the common edits without a separate mapping application. XML and AMIE artifacts load through approved DEV/UAT processes. Existing SDK and service handlers do not need recompilation for changes expressible through their existing approved operations. Production activation remains governed.

**Evidence:** Recorded author walkthroughs, exact input fixtures, native runtime results, source regression tests and milestone acceptance decisions.

## 5.3 Change discipline

For any adaptation, the PR must say: original decision; observed implementation fact; proposed change; reason; affected contracts; compatibility impact; tests; what remains unverified. Preserve the user's rationale for contextual depth and simplicity. Do not reopen settled questions about multiple categories, no mandatory owning application, service-account boundaries, one BOB core, existing AMIE or the DEV/UAT/PROD scope without explicit evidence and approval.
