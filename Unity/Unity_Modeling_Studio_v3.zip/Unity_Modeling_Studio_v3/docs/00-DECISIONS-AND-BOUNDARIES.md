# 0. Purpose, decisions, rationale and preservation boundary

**Scope:** Editable contextual data/rule modeling inside the existing WF Unity Business Builder. This is a complete handoff for this feature, not a claim to replace the whole Unity platform specification or to deploy BOB/AMIE. Dated November 19, 2026. Prototype profile: `urn:wf-unity:modeling:prototype:3`.

## 0.1 The problem this solves

The initial wireframes fragmented one programming task across many similar pages. A later three-tab proof of concept became simpler by removing useful capabilities. Neither approach met the user's objective. Unity is a visual programming environment: capability operations are reusable instructions, AMIE expresses business decisions, and BOB composes those instructions into a process. Users need to see and change the information flowing through that process, not merely inspect a diagram.

The prior contextual-zoom v2 recovered the richer Business Builder and kept BPMN context visible. It could map a few flat fields, but nested object examples and AMIE detail were largely illustrative. This revision extends that actual baseline. It does not start a separate designer or introduce a second execution model.

The requested experience is: select a BPMN activity; zoom into its data; select an object or property; choose a source or a compatible rule; see the connection change; inspect the effect in BPMN; test it; save/export the same definition. The author does not need to know Kafka topic names, C# class names, an XML path expression language, or UML theory.

## 0.2 Non-negotiable preservation rule

**Inspect and extend working implementations. Do not overwrite, duplicate or redesign established AMIE, BOB, SDK, authentication, group, messaging or serializer contracts merely to fit this prototype.**

Before production work, Devin must inspect the repository's AGENTS.md and actual BOB, AMIE and capability interfaces. The names in this packet are semantic contracts and sample identifiers, not evidence that classes, endpoints or modules with those names already exist. Match adapters to existing contracts. If a necessary behavior is genuinely absent, document the smallest compatible extension and regression tests. A breaking change requires a visible decision, compatibility plan and approval; a polished prototype is not permission for one.

The previous artifacts are copied under `reference/` only to establish provenance and allow comparison. They are not a second set of implementation instructions. The source checkpoint records their SHA-256 hashes. No original file or enterprise repository was modified.

## 0.3 Ratified direction carried forward

| Decision | Rationale | Implementation consequence |
|---|---|---|
| BPMN 2.0.2 is the process foundation | Familiar process semantics and machine-readable interchange | Preserve activity IDs, sequence flows, events, gateways and standard diagram interchange; avoid a JSON-only authoritative workflow |
| UML concepts are a contextual depth, not another product | Objects and properties are easier to map at a closer level | Use typed object cards, nested properties, collection markers and mapping connections under a persistent BPMN context rail |
| Process, Rule and Data perspectives share one draft | Avoid drift and duplicated configuration | Every edit uses the same command/history store; other perspectives are projections |
| Existing AMIE remains authoritative | Matthew's rule engine and format already exist | Discover, bind, edit, validate and serialize through its verified adapter; do not invent a production rule language |
| Ordinary mappings belong to the workflow | Users should not version every connection separately | Persist mappings in BPMN Unity extensions under the workflow revision |
| Reuse recipes are initially templates | Reuse without hidden mutable dependencies | Expand approved recipes into explicit mappings/tasks; no live recipe mutation changes published instances |
| Operation contracts come from the capability registry | A user cannot change what an API accepts | Expose declared input/output models and supported versions; editable bindings do not edit vendor contracts |
| Data can be acquired during execution | A message need not contain every field used later | Resolve prior outputs, rules and approved configuration before requiring an extra external input |
| Data and control edges are different | A data wire does not order execution | An inserted rule or lookup is an explicit BPMN task with explicit control-flow changes |
| Registration is not activation | Service discovery cannot grant privileges | Keep approved/non-prod/experimental classification, development stage and environment activation separate |
| Human workflow access is separate from service-account access | Departments authorize service identities, not each Unity user | Reuse Unity groups/AMIE entitlement policy; do not add a separate human grant for every external API call |
| DEV, UAT and PROD are the current environments | Avoid phantom TEST deployments | Preserve the agreed promotion path and production controls |
| Multiple categories, no mandatory owning application | Workflows cross business domains | Keep categories many-to-many; L2 capability ownership still has real meaning |

The expanded Phase 1 BOB scope remains the agreed scope: core tasks and decisions, shared central/embedded interpretation, sequential multi-instance, parallel gateways, intermediate timers, interrupting timer/error boundaries and minimum durable human tasks. This browser fixture does not prove all those constructs execute. Its smaller simulation/export profile must never be used to narrow the platform commitment.

## 0.4 What is newly specified here

1. A business-rule library and editable rule configuration are available from the selected activity's contextual detail.
2. Object roots and nested fields are selectable; whole-object mapping can be supplemented with explicit field overrides.
3. The three-dot menu is a real context menu, also available by right-click and keyboard. It exists on process nodes, fields and connections.
4. A rule placed between a source and destination is materialized as a real BPMN Business Rule Task. It is not an invisible callback owned by a data canvas.
5. The default compact rule slot handles a pure, single-input/single-output contract. More complex rules use normal Business Rule Tasks and fact mapping, not magical coercion.
6. Light and dark themes share the same controls, draft and semantic color vocabulary. Theme preference is not workflow logic.
7. Export/import in the prototype demonstrates an explicit XML subset. Unknown or unsupported input is rejected rather than silently flattened or discarded.

These are implementation proposals consistent with the approved architectural direction. Exact production extension names and adapters remain subject to source reconciliation.

## 0.5 The four layers of evidence

The packet distinguishes **UI behavior demonstrated**, **sample XML/Unity-XSD validation**, **required production compiler semantics**, and **actual enterprise runtime proof**. They are not interchangeable. Chromium interaction tests prove browser behavior. An XSD proves XML structure. Semantic validation checks meaning and path availability. A live BOB/CyberArk test proves an actual execution path. Only the first two and local fixture tests have been performed here.
