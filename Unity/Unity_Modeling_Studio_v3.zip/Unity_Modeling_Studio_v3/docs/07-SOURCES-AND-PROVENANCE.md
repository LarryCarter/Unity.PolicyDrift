# 7. Sources and provenance

## User-supplied baseline directly inspected

- `wf_unity_contextual_zoom_v2/WF_Unity_Contextual_BPMN_UML_Zoom_Designer_v2.html`: original richer builder script plus contextual zoom extension. Actual source was read and copied before changes.
- `wf_unity_contextual_zoom_v2/DEVIN_DESIGN_CORRECTION_CONTEXTUAL_BPMN_UML_ZOOM_v2.md`: preservation list, activity depth, mapping contract and source-reconciliation boundary.
- `wf_unity_modeling/unity-modeling-prototype.xsd`: earlier draft schema; explicitly not treated as production-ready.
- This conversation's approved decisions: preserve existing AMIE/BOB; contextual editable UML depth; real rule selection and rule insertion; multiple categories; existing group authority; native BPMN interchange; no separate data-flow engine; light/dark contrast and functional menus.

Original baseline copies are under reference/. Their hashes are recorded in qa/source-checkpoint.json. Current docs are in docs/ and the generated master. The old references do not need to be reconciled by the implementation team to understand this feature.

## External standards references consulted

1. OMG BPMN 2.0.2 specification landing page and machine-readable schema index:
   https://www.omg.org/spec/BPMN/2.0.2
   https://www.omg.org/spec/BPMN/machine-readable
   Used to identify the native schema/DI boundary and official schema bundle, not as evidence of Unity runtime implementation.
2. W3C XML Schema Part 1: Structures, Second Edition:
   https://www.w3.org/TR/xmlschema-1/
   Used for the distinction between extension/schema validation and application semantics. The included XSD is a proposed Unity design schema, not the OMG schema.
3. W3C WAI-ARIA Authoring Practices, Menu Button Pattern:
   https://www.w3.org/WAI/ARIA/apg/patterns/menu-button/
   Used for menu roles, Enter/Space behavior, expanded state and keyboard interaction requirements. A full accessibility audit remains separate.

Schema downloads from OMG were unavailable to the container. The validation report explicitly distinguishes Unity extension validation and native reference checks from full official BPMN XSD validation. No unsuccessful fetch has been represented as a passed validation.

## Authorship status

The proposed interaction contracts, fixture schemas and example registry values in this revision are new design work based on the supplied direction. They are not asserted to be copied from production AMIE, BOB or CyberArk code. The labels 'Approved-ReleaseReady' in the demo catalog are illustrative UI fixtures, not actual bank approval records.
