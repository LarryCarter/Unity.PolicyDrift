# 2. Component ownership, commands, state and accessibility

## 2.1 Shared state, not synchronized copies

The prototype extends the existing `model`, `mutate`, `snapshot`, `undo`, `redo`, `render`, `CATALOG` and step-tree functions. A connection is held once in `step.mappings[targetKey] = sourceEndpoint`. The process, activity inspector, rule-fact panel and lineage view read this record. `mappingPlacement` merely lets the renderer group a real rule task on a mapping; it does not store another executable connection.

Production should adapt this contract to the existing draft store. There must not be a ProcessDraft, RuleDataDraft and UMLDraft with competing authoritative edges. Separate view state is legitimate: selected activity, expansion, pan/zoom, search filter, focus and theme. These are not business behavior. Saving layout may be an explicit presentation edit; changing theme is never a workflow revision.

## 2.2 Component-to-behavior contract

Names below are proposed responsibility names, not required new project/class names. Prefer existing shared controls before adding another component.

| ID | Responsibility | Input / event contract | No guessing allowed |
|---|---|---|---|
| CZ-01 Context rail | Show actual location and branch grouping | Workflow projection; SelectedActivityId; SelectActivity(id) | Must not flatten branches into a false sequence or imply a join that does not exist |
| CZ-02 Activity detail host | Keep Data / Rule / Settings / Lineage in one context | ActivityId, view kind, ReturnToProcess | Switching perspective must not clone the draft |
| DM-01 Object card | Display a registered input/output/request model | Contract reference, ports, labels, expansion state | Editing a label is not editing schema identity |
| DM-02 Typed field port | Select source/target; show type/required/optional/list | Stable endpoint, metadata, selection, validation | A collection must not be styled as a scalar |
| DM-03 Mapping connection | Show source, target, rule and status | Binding ID, endpoint refs, diagnostics; Change/Unmap | Connect a data dependency only; never silently reorder BPMN |
| DM-04 Source chooser | Search available facts in a large popover/dialog | Consumer + input port; compatible candidate list | Explain disabled candidates and branch/freshness problems |
| DM-05 Rule-on-connection card | Visualize a real BPMN businessRuleTask | RuleTaskId, source/consumer refs; Edit/Replace/Remove | Renderer must not evaluate a second copy of the rule |
| AM-01 Rule catalog chooser | Category, search, description, facts, results, version | Supported-context filter; PreviewRule; BindRule | Registry selection alone is not approval |
| AM-02 Native rule editor host | Use the existing AMIE editor/serializer adapter | Verified rule draft; validate/save/cancel/preview | Do not make a new AMIE language or mutate an approved shared rule |
| UX-01 Context menu | Same actions from ellipsis/right-click/keyboard | Selection identity, action availability, anchor, focus return | Kebab must open a menu, not merely select the step |
| UX-02 Feedback | Explain commits, errors and blocked actions | Severity, reason code, field/activity focus target | Success must distinguish draft editing from actual execution |
| UX-03 Theme | Light/dark tokens, contrast and consistent roles | Preference only | Theme changes do not change model revision or XML semantics |
| XML-01 XML inspector | Show current XML and validation limits | Same draft serialization | No embedded JSON workflow masquerading as BPMN |

## 2.3 Commands and atomicity

Every command has a stable request ID, expected draft revision, actor context, target scope and before/after plan in production. The browser uses local history; it does not prove distributed atomicity.

### MapInput

Inputs: selected activity ID, destination port key, source endpoint, optional explicit semantic-meaning acknowledgement. Resolve pinned contracts and availability first. Type, domain-identifier, cardinality and authorization failures reject the command. A meaning acknowledgement is not a type/security override. Replace only the selected mapping; all other bindings remain unchanged. Invalidate relevant diagnostics/test evidence. Record one undo unit.

### InsertRuleOnMapping

Preconditions: consumer exists; selected mapping resolves; one compatible approved pure data rule has been explicitly selected; all rule facts are available; valid insertion point is known; source and destination types satisfy the rule input/output contract.

Atomic plan:

1. Allocate a new BPMN Business Rule Task ID using the current ID allocator.
2. Splice the task immediately before the consumer in the same execution scope. Preserve sequence-flow conditions and branch identity. Do not move it across a loop or interrupting boundary.
3. Bind the rule's input to the previously selected source.
4. Bind the consumer field to the rule's output.
5. Record a visual grouping hint linking the rule task to the consumer field. This is not a second executable graph.
6. Pin the actual rule definition/version and runtime host eligibility.
7. Recompute compiler diagnostics and dependent mappings.
8. Commit all changes together, or commit none.

If the rule has side effects, multiple ambiguous outputs, a needed lookup, or additional missing facts, the compact slot is inappropriate. Offer a normal Business Rule Task with its full fact editor. The user can still work contextually, but the system cannot hide extra behavior inside a line.

### ReplaceRuleBinding

Keep the activity ID and branch graph. Preview input/output differences. Preserve compatible mappings. Keep incompatible/obsolete mappings visible as repair tasks until the author accepts changes. Do not default a missing Boolean output to false. Do not erase an error path when changing a rule.

### RemoveRuleAndReconnect

Preview every consumer and any child paths. In the small one-input/one-output case, restore the original source to direct consumers, remove the task and its grouping hint, then validate. A reused rule with other consumers or a rule with multiple inputs may require explicit repair rather than automatic bypass. Never delete the catalog rule. The prototype supports direct value consumers and revalidates the resulting mappings.

### AddProducerAndConnect

For Get Account, the plan contains the exact operation and version, approved host, Account ID source, entity/vault scope, success-output binding and proposed insertion point. Reuse an existing compatible producer only if it is sufficiently fresh and refers to the same entity. An already-present but unrelated `CyberArkAccount` is not a safe default.

One click is enabled only for an unambiguous plan. Repeated clicks must not duplicate work. In production, the backend recomputes preconditions against the expected revision; a concurrent edit rejects the stale plan and offers a refreshed preview. The UI cannot declare success before the mutation has been accepted.

### Delete, duplicate, move and unbind

Delete a task occurrence, not the underlying API operation. Duplicate creates new IDs and retargets references internal to the copied subtree; external sources remain references and are revalidated. Move is a control-flow edit: available data must be recomputed. Unbind keeps task and graph identity but leaves a publish-blocking implementation gap. Removing a producer leaves visible broken dependencies rather than a stale green connection.

## 2.4 Context menu definitions

**Step menu:** Open data mapping; Choose/change binding; Insert before; Insert after; Duplicate; Move up; Move down; Remove binding only; Remove step. A data rule offers removal/reconnection semantics through its confirmation. Items that cannot apply must be disabled with a reason or omitted deliberately, not silently do nothing.

**Target/connection menu:** Choose/change source; Insert/replace data rule; Inspect field/type; View lineage; Remove mapping. **Source menu:** Select as source; Inspect field/type; View lineage. The same command executes whether invoked by mouse, ellipsis or keyboard.

A menu is anchored to the invoking control and clamped to the viewport. Enter/Space opens; Up/Down/Home/End navigate; Escape closes and returns focus. Right-click must not prevent ordinary browser context menus outside actual design elements. A dialog retains focus until dismissed, supports Tab/Shift+Tab, and returns focus to a useful invoking control. Cancellation does not create an undo entry or modify a binding.

The prototype implements these behaviors for the new contextual controls. The inherited administration samples are not evidence of a complete accessibility audit of every older screen.

## 2.5 Selection and dirty-state matrix

| Action | Selection | Business draft revision | Undo |
|---|---|---|---|
| Expand object / open details / change theme | Keep BPMN node | Unchanged | Not needed |
| Select another activity | Change node, clear pending endpoints | Unchanged | Not a business edit |
| Connect/replace/unmap | Keep consumer | Increment | One transaction |
| Insert rule or Get Account | Keep consumer; highlight new connection | Increment | All structural/binding edits together |
| Edit rule parameters | Keep rule task or its consumer context | Increment only on Save | Restore local rule draft |
| Cancel chooser/editor | Restore focus | Unchanged | No entry |
| Duplicate/remove/move | Select new/remaining valid node | Increment | Whole structural change |
| Import supported XML | Select an imported activity | Import transaction | Restore previous draft |
| Export | No change | Unchanged | No entry |

## 2.6 Visual design and responsive behavior

Light mode uses a pale neutral canvas and white panels. Dark mode uses a dark slate canvas and lighter slate panels. Source objects are blue, AMIE/data-rule elements violet, destination contracts teal, unresolved data amber and errors red. Text and state labels communicate the same information without color.

On a wide screen, source/connection/destination lanes sit side by side. On a narrow screen they stack; connections remain comprehensible as labeled cards even where decorative SVG wires are hidden. The BPMN rail can scroll within itself instead of forcing page-wide overflow. A source chooser is a large contextual dialog when the content requires room, not a tiny dropdown containing long rule descriptions.

Do not use full UML notation as mandatory user vocabulary. Familiar labels are Object, Field, Rule, List, Source, Destination, Connected and Needs data. Advanced metadata and XML remain available on demand.
