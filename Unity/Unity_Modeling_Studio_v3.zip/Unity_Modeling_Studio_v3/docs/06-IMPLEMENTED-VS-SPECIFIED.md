# 6. What actually works here, what is a contract, and what is still unverified

## 6.1 Demonstrated in the HTML

The actual original builder is retained as the base. The new layer is executable JavaScript over its shared draft, not a set of disconnected pictures.

- Select a BPMN activity and keep it highlighted while opening Data, Business rule, Settings and Lineage.
- Expand sample nested source/target objects; select source and destination; connect or change a mapping using click, drag/drop or a popover.
- Whole-object mapping and explicit child override in the same mapping records.
- Three-dot and right-click step/field/connection menus with keyboard navigation.
- Search and select an AMIE fixture rule inside the selected activity; inspect facts, outputs and a pinned fixture version.
- Insert a supported pure data rule on a String mapping as a real BPMN task; replace it; edit its local fixture parameters; preview a result; remove and reconnect.
- Shared Undo/Redo for connected edits, basic duplicate/move/delete/unbind behavior, original guided picker and authoring stages.
- Conservative data readiness and diagnostics; one-click Get Account repair/reuse in the sample.
- Actual local sample comparison, normalization, patch simulation, read-back and verification branching; no network or privileged operation.
- Light/dark theme, contextual guide and responsive layout.
- Export/import of the documented v3 BPMN profile, Unity mapping extension content and native DI geometry; explicit rejection of unsupported imports.
- Debug JSON retained under an explicit debug label, not as the BPMN exchange format.

The files under assets/ are inspectable source. OPEN.html embeds them so the interactive artifact does not depend on external assets, internet or a CDN. The QA build script regenerates it from the preserved baseline and current extension files.

## 6.2 Deliberately constrained in the prototype

| Area | Demonstration boundary |
|---|---|
| Registry | Fixed typed fixtures, not live SDK discovery or CyberArk schemas |
| Rule authoring | A few real local operators and editable fixture policies, not the entire AMIE editor |
| Inline rule slot | One String input and output; multi-input rules use the normal activity path |
| Type system | Known nominal objects/scalars/collections and limited semantic domains; no claim of complete structural subtyping |
| Availability | Conservative structured-sequence and nested-branch analysis; no full arbitrary CFG proof |
| Parallel and multi-instance runtime | Architectural requirement remains; local fixture does not execute parallel or general loop semantics |
| BPMN import | Only this emitted v3 structured subset; unknown content rejected rather than silently transformed |
| Layout | Standard process DI preserved in emitted subset; object-card placement/expansion is not a separately persisted full UML layout editor |
| Save | Browser storage when permitted; file export for durable transfer; no backend drafts, locks or revisions |
| Security | Demonstration shape/path checks only; no real identity, entitlement or service-account enforcement |
| Release | Explicitly blocked; no signing, ticket lookup or production activation |
| AMIE XML | Native format and serializer not available here; fixture-only edits cannot be called native AMIE XML |

## 6.3 Required before production claims

Source reconciliation, real AMIE rule-schema adapter, official full BPMN XSD validation, existing BOB semantic compiler integration, dynamic registry binding, full host/effect/authority checks, concurrent draft commands, real durable execution and recovery, and release/promotion security remain required. The source audit must determine which already exist; this list does not imply all are missing.

The prototype's literal `properties`, `Owner`, `BusinessUnit`, `CostCenter` and `Application` are illustrative normalized field keys. They are not a verified contract for the bank's installed CyberArk platform. Wire them to the real operations after inspecting their schema and policy.

## 6.4 No silent migration of old drafts

This package uses a new local storage key so it does not overwrite the original prototype's saved drafts. Original files are preserved untouched. The reference folder is for provenance, not an alternative current UI. There is no claim that arbitrary old JSON states can be upgraded without an explicit converter and regression test.

A complete supported import/export adapter must account for constraints, nullability, collection/item scope, semantic identifiers, unknown extension preservation and existing native contract conventions. Those are specified in this handoff, not inferred from a successful browser demo.
