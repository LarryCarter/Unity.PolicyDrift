# 1. Exact authoring journeys and observable behavior

## 1.1 First open

Extract the ZIP, open `OPEN.html`, and work in the CMDB custom-field enrichment example. No web server or external library is required by the HTML. The initial selected activity is **Compare custom fields** in the **Data mapping** view. The BPMN navigation strip remains above it and highlights the selected activity. The workflow has Hygiene and Governance categories.

The upper navigation retains Workflows, My work & runs, Manage, and Define / Build / Test / Release. Those are the original builder's authoring stages, not separate data models. `Full BPMN` returns to the process perspective. `Guided steps` returns to the step-card view. Returning to activity detail preserves its stable node ID and mappings. Opening another rail node changes the selected activity, not the workflow.

A permanent banner states that operations, rules and tests are local fixtures. This is necessary because the prototype is deliberately functional; a simulated successful PATCH must not be mistaken for a CyberArk change.

## 1.2 Understand a connection without studying lineage

The data view has three lanes:

| Lane | Meaning | Usual action |
|---|---|---|
| Blue: available data | Request fields and successful earlier activity outputs on this path | Expand an object or select a source |
| Purple/neutral: connections and rules | The current mapping for each input; an optional rule card is part of that mapping journey | Change a source, insert a rule, or inspect it |
| Teal: selected activity input | The contract required by the selected operation or rule | Select a destination; inspect why it is required |

A whole `CyberArkAccount` can feed `currentAccount` through one object-level connection. A whole `DesiredFields` object can feed `desired`. The author is not required to repeat the four fields manually. Expanding `desired` reveals Owner, BusinessUnit, CostCenter and Application. A child field initially displays **Inherited: Request / desired.Owner** rather than presenting a duplicate independent assignment.

Colors supplement text, labels, borders and icons. Blue is not a permission level; purple is not an approval state. An error must have a reason, not just a red connector.

## 1.3 Change the data supplied to one field

**Precondition:** Compare custom fields is selected, and the desired object is expanded.

1. Select a source property in the blue lane. A selected state and the field identity appear.
2. Select a destination property in the teal lane. The selection panel states `Source -> Destination` and explains compatibility.
3. Choose **Connect selected**. Alternatively drag a source field onto a destination, or use **Change** on a connection and select a source from the larger popover.
4. If the types or execution path are incompatible, the mapping does not change. The message names the mismatch and the remedy.
5. If ordinary business semantics differ despite matching types, the author must explicitly confirm the intentional mapping. CyberArk identifier-domain mismatches are blocked; an Account ID cannot become a Platform ID by acknowledging a warning.
6. The mapping updates in one history transaction. The destination label, connection card, lineage and XML all change together.

An explicit field override is applied to a fresh destination object after its whole-object mapping. It never mutates the producer's object or changes another consumer's input. Clearing a child override should be distinguished from explicitly leaving a field unmapped. In this prototype **Remove mapping** stores an unresolved override; Undo restores inheritance. The production UI should offer both **Use parent-object mapping** and **Leave unmapped**, with separate command intent.

When a required field is missing, the draft remains editable but execution/release readiness is blocked. A user may still export a draft for review. Export is not publish approval.

## 1.4 Put a rule between a source and destination

This is the primary new interaction.

1. In the target `desired.Owner` row, click the three dots or right-click the row.
2. Select **Insert / replace data rule**. A large rule chooser opens within the current designer. It shows categories, search, description, input/output types, version and default behavior.
3. Select **Normalize text** and choose **Insert and connect rule**.
4. The connection becomes `Request.desired.Owner -> Normalize text.value -> Compare.desired.Owner`.
5. The BPMN strip also gains a purple Business Rule Task immediately before Compare. The consumer remains selected.
6. Clicking the purple rule card opens its rule editor. It does not navigate away to an unrelated management page.
7. One Undo removes the task insertion, both bindings and the dependency change. Redo restores the same IDs.

The original `desired` object mapping stays intact. Only Owner is overridden. This is important: adding a rule for one field must not force a user to remap BusinessUnit, CostCenter and Application.

**No silent execution:** This button edits the draft. It does not run AMIE or CyberArk. The before/after plan is part of the command. A rule cannot be inserted automatically if its required facts are missing, the source is ambiguous, or the placement would cross an unsupported scope.

## 1.5 Configure that rule

The example Normalize text rule supports trimming and letter-case selection. The dialog includes a sample input and **Preview result**. It performs the actual small local fixture transformation, so `"  jsmith  "` with trim and uppercase becomes `"JSMITH"`.

**Save workflow-local draft** changes the local rule configuration associated with this workflow occurrence. It does not modify the shared catalog's approved rule. **Cancel** changes nothing. The original pinned rule identity is retained as provenance.

For Compare custom fields, the rule editor exposes blank policy: preserve, reject or clear. Omitted fields are not implicitly deletion requests. This demo's normalized `DesiredFields` input contract expects four String fields; supporting a different partial-update contract requires the actual declared optional/nullable metadata and corresponding adapter mapping. The policy does not make the capability's field allowlist optional.

These controls are a functional fixture of the intended adapter-driven editor. They do not define Matthew's AMIE XML. Production editing must open a verified AMIE draft through the existing rule editor contract and serialize it through his existing serializer.

## 1.6 Choose the main business rule inside an activity

Open **Business rule** for Compare. Choose **Choose another rule**. Inspect **Compare custom fields (reject blanks)**. The chooser displays its required facts and outputs before the user commits.

**Use selected rule** keeps the BPMN activity ID, branch contents and current mappings. Compatible facts stay connected. Removed or incompatible facts are flagged, not silently deleted. The boolean output used for the Yes/Otherwise decision is explicit and editable. A rule returning an enum or multiple outcomes needs a correspondingly configured gateway; it must not be assumed to be a Boolean.

The business-rule view also lets the author open the input mapping for each fact. Changes use the same binding records as the Data mapping view.

## 1.7 Remove a rule, mapping, task or binding

| Action | Meaning | What must survive |
|---|---|---|
| Remove mapping | Disconnect one destination; diagnose required data | Producer, other mappings and catalog definitions |
| Remove data rule and reconnect | Remove this rule task; reconnect its original value to direct consumers, then validate | Shared rule, other process steps and unrelated fields |
| Remove step | Delete this workflow occurrence and its child branches if explicitly confirmed | Capability or rule in the registry |
| Remove binding only | Keep a BPMN task but clear its implementation binding | Task ID and process connections |
| Replace operation/rule | Bind another resource and revalidate | Task identity and branch structure unless an explicit migration requires change |

Three-dot menus expose these actions; right-click exposes the same commands. Destructive confirmation explains impact. Removing Get Account leaves the comparison's dependency visibly invalid; it does not pretend that currentAccount is still available.

## 1.8 Add Get Account and Connect

When the current account input is unresolved, the resolver can offer one click if it knows exactly one appropriate producer and Account ID source. It first checks for an eligible existing Get Account output for the same input. Otherwise it inserts a Get Account Service Task before the consumer, binds the incoming Account ID, binds the output to the consumer, and revalidates.

The fixture checks the declared sample Account ID and available path. Production must also check target environment, vault/service identity, record identity, schema version, freshness and allowed execution host. An old pre-write account snapshot must not satisfy a post-write verification requirement merely because its type matches.

If choices are ambiguous, use the data-source popover. Do not turn a guess into a one-click green checkmark. A mapping cannot satisfy a dependency using a future step or an unrelated branch.

## 1.9 Inspect more detail only when needed

**Field details** shows type, requiredness, collection status, semantic meaning and classification. **Full lineage** lists the actual source and any inserted rule at the selected BPMN activity ID. The data view is editable; lineage is an explanation of the same graph, not another saved flow.

Nested objects expand in place. A collection is visibly a collection; the prototype blocks collection-to-scalar coercion. The production collection editor must expose For Each item scope and aggregation through supported BPMN multi-instance behavior, not invent an implicit loop in a connector.

## 1.10 Test and return to the exact step

Choose Test. Edit the request/account fixture and choose **Run local fixture**. The trace shows actual local inputs and outputs for supported sample steps. **Open this step** returns to that activity in contextual data mode.

The reference flow is Get -> Compare -> changed? -> Patch -> Get again -> Verify -> verified?/review, or No change. `simulateWriteMismatch: true` deliberately simulates an accepted write that did not apply the values; the result must follow the verification-mismatch branch, not claim success.

After inserting the trim rule on Owner, the default fixture follows No change and does not perform even a mock PATCH. This proves that the editable rule affects behavior rather than merely changing a diagram label.

## 1.11 Export, import, release and theme

Use **Export BPMN XML** for the authoritative sample artifact. **Inspect XML** displays it without leaving context. **Import BPMN XML** restores the documented v3 subset. Unsupported namespaces, changed branch expressions and unavailable pinned versions are rejected with the current draft untouched. The production importer has the broader preservation requirements in the compiler specification.

Debug JSON import/export remains labeled **debug** for compatibility with the original prototype. It is not the production workflow interchange format.

Release shows the pending production gates and never activates anything. Light/dark switching changes only presentation; it does not dirty the workflow. Theme preference uses browser storage where allowed. If browser storage is unavailable, the active document still works in memory; export is the durable handoff.
