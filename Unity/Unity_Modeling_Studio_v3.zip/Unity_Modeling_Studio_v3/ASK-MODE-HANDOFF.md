# WF Unity - Editable Contextual Modeling: Complete Feature Handoff

**Version:** 3. **Review date:** November 19, 2026.

## How to use this specification

This is the complete current specification for extending the supplied contextual BPMN/UML designer into an editable modeling experience. It is not a new competing platform architecture. It preserves the already-agreed Unity foundation and explicitly protects existing native AMIE, BOB and capability contracts.

The feature is **one workflow, progressively deeper editable perspectives**: process, activity, object, field, rule. The user remains oriented in BPMN while editing data and rule relationships. The underlying draft and Undo/Redo history are shared. A rule inserted between fields becomes a visible BPMN Business Rule Task; the mapper does not become a hidden orchestration or rule engine.

This master contains the complete eight current specification documents plus the current QA report. The individual Markdown files remain available for implementation. ASK-MODE-HANDOFF.md and DEVIN-ASK.md contain identical text. Historical reference files are not competing instructions and need not be reconciled to understand the requested feature.

## Reading order

1. Decisions, rationale and preservation boundaries.
2. Exact author journeys and controls.
3. Components, atomic commands, state and accessibility.
4. BPMN/XML/XSD mapping and native AMIE integration.
5. Validation, data availability and runtime boundaries.
6. Milestone-linked Devin jobs and acceptance evidence.
7. Implemented behavior versus specified/unverified behavior.
8. Sources and provenance.
9. Verification report.

## Before implementation

Audit the actual repository and reuse working contracts. Treat prototype namespace, API/component names and fixture schemas as proposed design artifacts. Never implement a replacement AMIE evaluator merely because the offline demo includes one. Do not reduce the broader agreed BPMN Phase 1 scope to the sample export/fixture subset.

---

# 0. Purpose, decisions, rationale and preservation boundary

**Scope:** Editable contextual data/rule modeling inside the existing WF Unity Business Builder. This is a complete handoff for this feature, not a claim to replace the whole Unity platform specification or to deploy BOB/AMIE. Dated November 19, 2026. Prototype profile: `urn:wf-unity:modeling:prototype:3`.

## 0.1 The problem this solves

The initial wireframes fragmented one programming task across many similar pages. A later three-tab proof of concept became simpler by removing useful capabilities. Neither approach met the user's objective. Unity is a visual programming environment: capability operations are reusable instructions, AMIE expresses business decisions, and BOB composes those instructions into a process. Users need to see and change the information flowing through that process, not merely inspect a diagram.

The prior contextual-zoom v2 recovered the richer Business Builder and kept BPMN context visible. It could map a few flat fields, but nested object examples and AMIE detail were largely illustrative. This revision extends that actual baseline. It does not start a separate designer or introduce a second execution model.

The requested experience is: select a BPMN activity; zoom into its data; select an object or property; choose a source or a compatible rule; see the connection change; inspect the effect in BPMN; test it; save/export the same definition. The author does not need to know Kafka topic names, C# class names, an XML path expression language, or UML theory.

## 0.2 Non-negotiable preservation rule

**Inspect and extend working implementations. Do not overwrite, duplicate or redesign established AMIE, BOB, SDK, authentication, group, messaging or serializer contracts merely to fit this prototype.**

Before production work, Devin must inspect the repository's AGENTS.md and actual BOB, AMIE and capability interfaces. The names in this packet are semantic contracts and sample identifiers, not evidence that classes, endpoints or modules with those names already exist. Match adapters to existing contracts. If a necessary behavior is genuinely absent, document the smallest compatible extension and regression tests. A breaking change requires a visible decision, compatibility plan and approval; a polished prototype is not permission for one.

The previous artifacts are copied under `reference/` only to establish provenance and allow comparison. They are not a second set of implementation instructions. The source checkpoint records their SHA-256 hashes. No original file or enterprise repository was modified.

## 0.3 Ratified direction carried forward

| Decision | Rationale | Implementation consequence |
|---|---|---|
| BPMN 2.0.2 is the process foundation | Familiar process semantics and machine-readable interchange | Preserve activity IDs, sequence flows, events, gateways and standard diagram interchange; avoid a JSON-only authoritative workflow |
| UML concepts are a contextual depth, not another product | Objects and properties are easier to map at a closer level | Use typed object cards, nested properties, collection markers and mapping connections under a persistent BPMN context rail |
| Process, Rule and Data perspectives share one draft | Avoid drift and duplicated configuration | Every edit uses the same command/history store; other perspectives are projections |
| Existing AMIE remains authoritative | Matthew's rule engine and format already exist | Discover, bind, edit, validate and serialize through its verified adapter; do not invent a production rule language |
| Ordinary mappings belong to the workflow | Users should not version every connection separately | Persist mappings in BPMN Unity extensions under the workflow revision |
| Reuse recipes are initially templates | Reuse without hidden mutable dependencies | Expand approved recipes into explicit mappings/tasks; no live recipe mutation changes published instances |
| Operation contracts come from the capability registry | A user cannot change what an API accepts | Expose declared input/output models and supported versions; editable bindings do not edit vendor contracts |
| Data can be acquired during execution | A message need not contain every field used later | Resolve prior outputs, rules and approved configuration before requiring an extra external input |
| Data and control edges are different | A data wire does not order execution | An inserted rule or lookup is an explicit BPMN task with explicit control-flow changes |
| Registration is not activation | Service discovery cannot grant privileges | Keep approved/non-prod/experimental classification, development stage and environment activation separate |
| Human workflow access is separate from service-account access | Departments authorize service identities, not each Unity user | Reuse Unity groups/AMIE entitlement policy; do not add a separate human grant for every external API call |
| DEV, UAT and PROD are the current environments | Avoid phantom TEST deployments | Preserve the agreed promotion path and production controls |
| Multiple categories, no mandatory owning application | Workflows cross business domains | Keep categories many-to-many; L2 capability ownership still has real meaning |

The expanded Phase 1 BOB scope remains the agreed scope: core tasks and decisions, shared central/embedded interpretation, sequential multi-instance, parallel gateways, intermediate timers, interrupting timer/error boundaries and minimum durable human tasks. This browser fixture does not prove all those constructs execute. Its smaller simulation/export profile must never be used to narrow the platform commitment.

## 0.4 What is newly specified here

1. A business-rule library and editable rule configuration are available from the selected activity's contextual detail.
2. Object roots and nested fields are selectable; whole-object mapping can be supplemented with explicit field overrides.
3. The three-dot menu is a real context menu, also available by right-click and keyboard. It exists on process nodes, fields and connections.
4. A rule placed between a source and destination is materialized as a real BPMN Business Rule Task. It is not an invisible callback owned by a data canvas.
5. The default compact rule slot handles a pure, single-input/single-output contract. More complex rules use normal Business Rule Tasks and fact mapping, not magical coercion.
6. Light and dark themes share the same controls, draft and semantic color vocabulary. Theme preference is not workflow logic.
7. Export/import in the prototype demonstrates an explicit XML subset. Unknown or unsupported input is rejected rather than silently flattened or discarded.

These are implementation proposals consistent with the approved architectural direction. Exact production extension names and adapters remain subject to source reconciliation.

## 0.5 The four layers of evidence

The packet distinguishes **UI behavior demonstrated**, **sample XML/Unity-XSD validation**, **required production compiler semantics**, and **actual enterprise runtime proof**. They are not interchangeable. Chromium interaction tests prove browser behavior. An XSD proves XML structure. Semantic validation checks meaning and path availability. A live BOB/CyberArk test proves an actual execution path. Only the first two and local fixture tests have been performed here.


---

# 1. Exact authoring journeys and observable behavior

## 1.1 First open

Extract the ZIP, open `OPEN.html`, and work in the CMDB custom-field enrichment example. No web server or external library is required by the HTML. The initial selected activity is **Compare custom fields** in the **Data mapping** view. The BPMN navigation strip remains above it and highlights the selected activity. The workflow has Hygiene and Governance categories.

The upper navigation retains Workflows, My work & runs, Manage, and Define / Build / Test / Release. Those are the original builder's authoring stages, not separate data models. `Full BPMN` returns to the process perspective. `Guided steps` returns to the step-card view. Returning to activity detail preserves its stable node ID and mappings. Opening another rail node changes the selected activity, not the workflow.

A permanent banner states that operations, rules and tests are local fixtures. This is necessary because the prototype is deliberately functional; a simulated successful PATCH must not be mistaken for a CyberArk change.

## 1.2 Understand a connection without studying lineage

The data view has three lanes:

| Lane | Meaning | Usual action |
|---|---|---|
| Blue: available data | Request fields and successful earlier activity outputs on this path | Expand an object or select a source |
| Purple/neutral: connections and rules | The current mapping for each input; an optional rule card is part of that mapping journey | Change a source, insert a rule, or inspect it |
| Teal: selected activity input | The contract required by the selected operation or rule | Select a destination; inspect why it is required |

A whole `CyberArkAccount` can feed `currentAccount` through one object-level connection. A whole `DesiredFields` object can feed `desired`. The author is not required to repeat the four fields manually. Expanding `desired` reveals Owner, BusinessUnit, CostCenter and Application. A child field initially displays **Inherited: Request / desired.Owner** rather than presenting a duplicate independent assignment.

Colors supplement text, labels, borders and icons. Blue is not a permission level; purple is not an approval state. An error must have a reason, not just a red connector.

## 1.3 Change the data supplied to one field

**Precondition:** Compare custom fields is selected, and the desired object is expanded.

1. Select a source property in the blue lane. A selected state and the field identity appear.
2. Select a destination property in the teal lane. The selection panel states `Source -> Destination` and explains compatibility.
3. Choose **Connect selected**. Alternatively drag a source field onto a destination, or use **Change** on a connection and select a source from the larger popover.
4. If the types or execution path are incompatible, the mapping does not change. The message names the mismatch and the remedy.
5. If ordinary business semantics differ despite matching types, the author must explicitly confirm the intentional mapping. CyberArk identifier-domain mismatches are blocked; an Account ID cannot become a Platform ID by acknowledging a warning.
6. The mapping updates in one history transaction. The destination label, connection card, lineage and XML all change together.

An explicit field override is applied to a fresh destination object after its whole-object mapping. It never mutates the producer's object or changes another consumer's input. Clearing a child override should be distinguished from explicitly leaving a field unmapped. In this prototype **Remove mapping** stores an unresolved override; Undo restores inheritance. The production UI should offer both **Use parent-object mapping** and **Leave unmapped**, with separate command intent.

When a required field is missing, the draft remains editable but execution/release readiness is blocked. A user may still export a draft for review. Export is not publish approval.

## 1.4 Put a rule between a source and destination

This is the primary new interaction.

1. In the target `desired.Owner` row, click the three dots or right-click the row.
2. Select **Insert / replace data rule**. A large rule chooser opens within the current designer. It shows categories, search, description, input/output types, version and default behavior.
3. Select **Normalize text** and choose **Insert and connect rule**.
4. The connection becomes `Request.desired.Owner -> Normalize text.value -> Compare.desired.Owner`.
5. The BPMN strip also gains a purple Business Rule Task immediately before Compare. The consumer remains selected.
6. Clicking the purple rule card opens its rule editor. It does not navigate away to an unrelated management page.
7. One Undo removes the task insertion, both bindings and the dependency change. Redo restores the same IDs.

The original `desired` object mapping stays intact. Only Owner is overridden. This is important: adding a rule for one field must not force a user to remap BusinessUnit, CostCenter and Application.

**No silent execution:** This button edits the draft. It does not run AMIE or CyberArk. The before/after plan is part of the command. A rule cannot be inserted automatically if its required facts are missing, the source is ambiguous, or the placement would cross an unsupported scope.

## 1.5 Configure that rule

The example Normalize text rule supports trimming and letter-case selection. The dialog includes a sample input and **Preview result**. It performs the actual small local fixture transformation, so `"  jsmith  "` with trim and uppercase becomes `"JSMITH"`.

**Save workflow-local draft** changes the local rule configuration associated with this workflow occurrence. It does not modify the shared catalog's approved rule. **Cancel** changes nothing. The original pinned rule identity is retained as provenance.

For Compare custom fields, the rule editor exposes blank policy: preserve, reject or clear. Omitted fields are not implicitly deletion requests. This demo's normalized `DesiredFields` input contract expects four String fields; supporting a different partial-update contract requires the actual declared optional/nullable metadata and corresponding adapter mapping. The policy does not make the capability's field allowlist optional.

These controls are a functional fixture of the intended adapter-driven editor. They do not define Matthew's AMIE XML. Production editing must open a verified AMIE draft through the existing rule editor contract and serialize it through his existing serializer.

## 1.6 Choose the main business rule inside an activity

Open **Business rule** for Compare. Choose **Choose another rule**. Inspect **Compare custom fields (reject blanks)**. The chooser displays its required facts and outputs before the user commits.

**Use selected rule** keeps the BPMN activity ID, branch contents and current mappings. Compatible facts stay connected. Removed or incompatible facts are flagged, not silently deleted. The boolean output used for the Yes/Otherwise decision is explicit and editable. A rule returning an enum or multiple outcomes needs a correspondingly configured gateway; it must not be assumed to be a Boolean.

The business-rule view also lets the author open the input mapping for each fact. Changes use the same binding records as the Data mapping view.

## 1.7 Remove a rule, mapping, task or binding

| Action | Meaning | What must survive |
|---|---|---|
| Remove mapping | Disconnect one destination; diagnose required data | Producer, other mappings and catalog definitions |
| Remove data rule and reconnect | Remove this rule task; reconnect its original value to direct consumers, then validate | Shared rule, other process steps and unrelated fields |
| Remove step | Delete this workflow occurrence and its child branches if explicitly confirmed | Capability or rule in the registry |
| Remove binding only | Keep a BPMN task but clear its implementation binding | Task ID and process connections |
| Replace operation/rule | Bind another resource and revalidate | Task identity and branch structure unless an explicit migration requires change |

Three-dot menus expose these actions; right-click exposes the same commands. Destructive confirmation explains impact. Removing Get Account leaves the comparison's dependency visibly invalid; it does not pretend that currentAccount is still available.

## 1.8 Add Get Account and Connect

When the current account input is unresolved, the resolver can offer one click if it knows exactly one appropriate producer and Account ID source. It first checks for an eligible existing Get Account output for the same input. Otherwise it inserts a Get Account Service Task before the consumer, binds the incoming Account ID, binds the output to the consumer, and revalidates.

The fixture checks the declared sample Account ID and available path. Production must also check target environment, vault/service identity, record identity, schema version, freshness and allowed execution host. An old pre-write account snapshot must not satisfy a post-write verification requirement merely because its type matches.

If choices are ambiguous, use the data-source popover. Do not turn a guess into a one-click green checkmark. A mapping cannot satisfy a dependency using a future step or an unrelated branch.

## 1.9 Inspect more detail only when needed

**Field details** shows type, requiredness, collection status, semantic meaning and classification. **Full lineage** lists the actual source and any inserted rule at the selected BPMN activity ID. The data view is editable; lineage is an explanation of the same graph, not another saved flow.

Nested objects expand in place. A collection is visibly a collection; the prototype blocks collection-to-scalar coercion. The production collection editor must expose For Each item scope and aggregation through supported BPMN multi-instance behavior, not invent an implicit loop in a connector.

## 1.10 Test and return to the exact step

Choose Test. Edit the request/account fixture and choose **Run local fixture**. The trace shows actual local inputs and outputs for supported sample steps. **Open this step** returns to that activity in contextual data mode.

The reference flow is Get -> Compare -> changed? -> Patch -> Get again -> Verify -> verified?/review, or No change. `simulateWriteMismatch: true` deliberately simulates an accepted write that did not apply the values; the result must follow the verification-mismatch branch, not claim success.

After inserting the trim rule on Owner, the default fixture follows No change and does not perform even a mock PATCH. This proves that the editable rule affects behavior rather than merely changing a diagram label.

## 1.11 Export, import, release and theme

Use **Export BPMN XML** for the authoritative sample artifact. **Inspect XML** displays it without leaving context. **Import BPMN XML** restores the documented v3 subset. Unsupported namespaces, changed branch expressions and unavailable pinned versions are rejected with the current draft untouched. The production importer has the broader preservation requirements in the compiler specification.

Debug JSON import/export remains labeled **debug** for compatibility with the original prototype. It is not the production workflow interchange format.

Release shows the pending production gates and never activates anything. Light/dark switching changes only presentation; it does not dirty the workflow. Theme preference uses browser storage where allowed. If browser storage is unavailable, the active document still works in memory; export is the durable handoff.


---

# 2. Component ownership, commands, state and accessibility

## 2.1 Shared state, not synchronized copies

The prototype extends the existing `model`, `mutate`, `snapshot`, `undo`, `redo`, `render`, `CATALOG` and step-tree functions. A connection is held once in `step.mappings[targetKey] = sourceEndpoint`. The process, activity inspector, rule-fact panel and lineage view read this record. `mappingPlacement` merely lets the renderer group a real rule task on a mapping; it does not store another executable connection.

Production should adapt this contract to the existing draft store. There must not be a ProcessDraft, RuleDataDraft and UMLDraft with competing authoritative edges. Separate view state is legitimate: selected activity, expansion, pan/zoom, search filter, focus and theme. These are not business behavior. Saving layout may be an explicit presentation edit; changing theme is never a workflow revision.

## 2.2 Component-to-behavior contract

Names below are proposed responsibility names, not required new project/class names. Prefer existing shared controls before adding another component.

| ID | Responsibility | Input / event contract | No guessing allowed |
|---|---|---|---|
| CZ-01 Context rail | Show actual location and branch grouping | Workflow projection; SelectedActivityId; SelectActivity(id) | Must not flatten branches into a false sequence or imply a join that does not exist |
| CZ-02 Activity detail host | Keep Data / Rule / Settings / Lineage in one context | ActivityId, view kind, ReturnToProcess | Switching perspective must not clone the draft |
| DM-01 Object card | Display a registered input/output/request model | Contract reference, ports, labels, expansion state | Editing a label is not editing schema identity |
| DM-02 Typed field port | Select source/target; show type/required/optional/list | Stable endpoint, metadata, selection, validation | A collection must not be styled as a scalar |
| DM-03 Mapping connection | Show source, target, rule and status | Binding ID, endpoint refs, diagnostics; Change/Unmap | Connect a data dependency only; never silently reorder BPMN |
| DM-04 Source chooser | Search available facts in a large popover/dialog | Consumer + input port; compatible candidate list | Explain disabled candidates and branch/freshness problems |
| DM-05 Rule-on-connection card | Visualize a real BPMN businessRuleTask | RuleTaskId, source/consumer refs; Edit/Replace/Remove | Renderer must not evaluate a second copy of the rule |
| AM-01 Rule catalog chooser | Category, search, description, facts, results, version | Supported-context filter; PreviewRule; BindRule | Registry selection alone is not approval |
| AM-02 Native rule editor host | Use the existing AMIE editor/serializer adapter | Verified rule draft; validate/save/cancel/preview | Do not make a new AMIE language or mutate an approved shared rule |
| UX-01 Context menu | Same actions from ellipsis/right-click/keyboard | Selection identity, action availability, anchor, focus return | Kebab must open a menu, not merely select the step |
| UX-02 Feedback | Explain commits, errors and blocked actions | Severity, reason code, field/activity focus target | Success must distinguish draft editing from actual execution |
| UX-03 Theme | Light/dark tokens, contrast and consistent roles | Preference only | Theme changes do not change model revision or XML semantics |
| XML-01 XML inspector | Show current XML and validation limits | Same draft serialization | No embedded JSON workflow masquerading as BPMN |

## 2.3 Commands and atomicity

Every command has a stable request ID, expected draft revision, actor context, target scope and before/after plan in production. The browser uses local history; it does not prove distributed atomicity.

### MapInput

Inputs: selected activity ID, destination port key, source endpoint, optional explicit semantic-meaning acknowledgement. Resolve pinned contracts and availability first. Type, domain-identifier, cardinality and authorization failures reject the command. A meaning acknowledgement is not a type/security override. Replace only the selected mapping; all other bindings remain unchanged. Invalidate relevant diagnostics/test evidence. Record one undo unit.

### InsertRuleOnMapping

Preconditions: consumer exists; selected mapping resolves; one compatible approved pure data rule has been explicitly selected; all rule facts are available; valid insertion point is known; source and destination types satisfy the rule input/output contract.

Atomic plan:

1. Allocate a new BPMN Business Rule Task ID using the current ID allocator.
2. Splice the task immediately before the consumer in the same execution scope. Preserve sequence-flow conditions and branch identity. Do not move it across a loop or interrupting boundary.
3. Bind the rule's input to the previously selected source.
4. Bind the consumer field to the rule's output.
5. Record a visual grouping hint linking the rule task to the consumer field. This is not a second executable graph.
6. Pin the actual rule definition/version and runtime host eligibility.
7. Recompute compiler diagnostics and dependent mappings.
8. Commit all changes together, or commit none.

If the rule has side effects, multiple ambiguous outputs, a needed lookup, or additional missing facts, the compact slot is inappropriate. Offer a normal Business Rule Task with its full fact editor. The user can still work contextually, but the system cannot hide extra behavior inside a line.

### ReplaceRuleBinding

Keep the activity ID and branch graph. Preview input/output differences. Preserve compatible mappings. Keep incompatible/obsolete mappings visible as repair tasks until the author accepts changes. Do not default a missing Boolean output to false. Do not erase an error path when changing a rule.

### RemoveRuleAndReconnect

Preview every consumer and any child paths. In the small one-input/one-output case, restore the original source to direct consumers, remove the task and its grouping hint, then validate. A reused rule with other consumers or a rule with multiple inputs may require explicit repair rather than automatic bypass. Never delete the catalog rule. The prototype supports direct value consumers and revalidates the resulting mappings.

### AddProducerAndConnect

For Get Account, the plan contains the exact operation and version, approved host, Account ID source, entity/vault scope, success-output binding and proposed insertion point. Reuse an existing compatible producer only if it is sufficiently fresh and refers to the same entity. An already-present but unrelated `CyberArkAccount` is not a safe default.

One click is enabled only for an unambiguous plan. Repeated clicks must not duplicate work. In production, the backend recomputes preconditions against the expected revision; a concurrent edit rejects the stale plan and offers a refreshed preview. The UI cannot declare success before the mutation has been accepted.

### Delete, duplicate, move and unbind

Delete a task occurrence, not the underlying API operation. Duplicate creates new IDs and retargets references internal to the copied subtree; external sources remain references and are revalidated. Move is a control-flow edit: available data must be recomputed. Unbind keeps task and graph identity but leaves a publish-blocking implementation gap. Removing a producer leaves visible broken dependencies rather than a stale green connection.

## 2.4 Context menu definitions

**Step menu:** Open data mapping; Choose/change binding; Insert before; Insert after; Duplicate; Move up; Move down; Remove binding only; Remove step. A data rule offers removal/reconnection semantics through its confirmation. Items that cannot apply must be disabled with a reason or omitted deliberately, not silently do nothing.

**Target/connection menu:** Choose/change source; Insert/replace data rule; Inspect field/type; View lineage; Remove mapping. **Source menu:** Select as source; Inspect field/type; View lineage. The same command executes whether invoked by mouse, ellipsis or keyboard.

A menu is anchored to the invoking control and clamped to the viewport. Enter/Space opens; Up/Down/Home/End navigate; Escape closes and returns focus. Right-click must not prevent ordinary browser context menus outside actual design elements. A dialog retains focus until dismissed, supports Tab/Shift+Tab, and returns focus to a useful invoking control. Cancellation does not create an undo entry or modify a binding.

The prototype implements these behaviors for the new contextual controls. The inherited administration samples are not evidence of a complete accessibility audit of every older screen.

## 2.5 Selection and dirty-state matrix

| Action | Selection | Business draft revision | Undo |
|---|---|---|---|
| Expand object / open details / change theme | Keep BPMN node | Unchanged | Not needed |
| Select another activity | Change node, clear pending endpoints | Unchanged | Not a business edit |
| Connect/replace/unmap | Keep consumer | Increment | One transaction |
| Insert rule or Get Account | Keep consumer; highlight new connection | Increment | All structural/binding edits together |
| Edit rule parameters | Keep rule task or its consumer context | Increment only on Save | Restore local rule draft |
| Cancel chooser/editor | Restore focus | Unchanged | No entry |
| Duplicate/remove/move | Select new/remaining valid node | Increment | Whole structural change |
| Import supported XML | Select an imported activity | Import transaction | Restore previous draft |
| Export | No change | Unchanged | No entry |

## 2.6 Visual design and responsive behavior

Light mode uses a pale neutral canvas and white panels. Dark mode uses a dark slate canvas and lighter slate panels. Source objects are blue, AMIE/data-rule elements violet, destination contracts teal, unresolved data amber and errors red. Text and state labels communicate the same information without color.

On a wide screen, source/connection/destination lanes sit side by side. On a narrow screen they stack; connections remain comprehensible as labeled cards even where decorative SVG wires are hidden. The BPMN rail can scroll within itself instead of forcing page-wide overflow. A source chooser is a large contextual dialog when the content requires room, not a tiny dropdown containing long rule descriptions.

Do not use full UML notation as mandatory user vocabulary. Familiar labels are Object, Field, Rule, List, Source, Destination, Connected and Needs data. Advanced metadata and XML remain available on demand.


---

# 3. Exact UI-to-XML/XSD contract and existing AMIE boundary

## 3.1 Three independent responsibilities

The XML schema defines valid structure. The compiler defines valid meaning. The renderer defines how people see and edit it. Loading an XSD does not teach a generic BPMN tool to draw a Unity object card or evaluate an AMIE rule. A renderer adapter, command layer and serializer are required.

This packet supplies a **proposed prototype XSD**, examples exported by the actual browser, and an extension-validation runner. It does not certify a production BPMN profile or replace an existing BOB binding schema.

## 3.2 Authoritative storage

The workflow artifact is BPMN XML with native process elements, data objects, input/output specifications, data associations and diagram interchange. Unity-specific field selection and typed bindings are carried in namespace-qualified extensions. AMIE's actual rule logic remains in its own existing native XML, referenced by the workflow. Workflow-local AMIE changes must be serialized into the actual AMIE draft/release artifact by the existing adapter.

No second editable JSON graph is embedded in the exported BPMN. The browser may keep a convenient JavaScript object in memory and a debug JSON snapshot, just as an XML editor may use an object model internally. The XML is the interchange artifact. A workflow-specific mapping is versioned with the workflow, not in a separate live mapping service.

## 3.3 Prototype namespace and concrete elements

Namespace: `urn:wf-unity:modeling:prototype:3`.

The prototype puts `unity:workflow` and `unity:types` in the BPMN process's extensionElements and `unity:activity` in each actual BPMN activity's extensionElements.

| UI/model item | Exact XML representation | XSD owner | Meaning |
|---|---|---|---|
| Workflow title/revision | `unity:workflow/@name`, `@revision` | WorkflowType | Draft metadata, not production approval |
| Multiple business categories | Repeated `unity:category/@name` | WorkflowType sequence | Classification; no permission inheritance |
| Multiple launch configurations | Repeated `unity:launcher/@kind` | WorkflowType sequence | Fixture references to input adapters, not extra BPMN control tokens |
| Declared request input | `unity:request/unity:field` | FieldType | Key, typeRef, label and required flag |
| Object structure | `unity:types/unity:object/unity:field` | TypesType, FieldType | Sample registry snapshot; labels do not change keys |
| Process instruction | Native `bpmn:serviceTask`, `businessRuleTask`, `userTask`, etc. | OMG schema | Control-flow semantics remain BPMN |
| Registered operation/rule | `unity:activity/@resourceRef`, `@version` | ActivityType | Pinned fixture registry identity; runtime must resolve trusted registry |
| Input mapping | `unity:activity/unity:map` | MappingType | One canonical source endpoint and destination key |
| Data-rule grouping in a wire | `unity:activity/@consumerRef`, `@targetRef` | ActivityType | Presentation relationship pointing at a real rule task |
| Rule's incoming/outgoing information | Native ioSpecification/dataInput/dataOutput and data associations | OMG schema | Contract-level item flow; detailed field selection remains explicit in Unity mappings |
| Decision output | `unity:activity/@decisionOutput`; native exclusive gateway and conditional sequence flows | ActivityType + OMG schema | Selected Boolean outcome drives Yes; default flow is Otherwise |
| Operation deadline | `unity:activity/@timeout` as xs:duration | ActivityType | Deadline setting; it is not itself a BPMN boundary event |
| Fixture-only local rule edit | `unity:ruleDraft adapter="fixture-only"` with param entries | RuleDraftType | Demonstration input to a local fixture, explicitly not native AMIE XML |
| Process layout | `bpmndi:BPMNShape`, `BPMNEdge`, DC bounds and DI waypoints | BPMN DI/DC/DI | Native process geometry |
| Theme / open menu / search | Browser UI state only | None | Not workflow behavior |

`typeRef` and mapping endpoint locators resolve against pinned contracts. In the fixtures, immutable contract keys and node IDs form locators such as `steps.get1.account.properties.Owner`. They are not user-entered display labels. The production adapter must preserve any stronger field IDs already in the SDK and map them consistently to the serializer. A label rename cannot invalidate a mapping; a contract-key/type change is a compatibility event.

## 3.4 A rule on a mapping is not hidden inside the mapping evaluator

Before:

`request.desired.Owner -> compare1.desired.Owner`

After:

`request.desired.Owner -> Normalize.value -> compare1.desired.Owner`

The after state contains a real `bpmn:businessRuleTask` and a source/input mapping on that task. Its output is made available to the consumer through the ordinary successful-output data contract. A native sequence flow places the rule before the consumer. `consumerRef` and `targetRef` only help the UI draw that task as a purple rule card in the wire.

Illustrative extension fragment (the complete generated examples are under examples/):

```xml
<bpmn:businessRuleTask id="Rule_NormalizeOwner"
                       name="Normalize owner"
                       implementation="urn:unity:amie:adapter">
  <bpmn:extensionElements>
    <unity:activity kind="ruleTransform"
                    resourceRef="amie.normalizeOwner" version="1"
                    consumerRef="compare1" targetRef="desired.Owner">
      <unity:map id="Map_NormalizeOwner_Input"
                 fromRef="request.desired.Owner" toRef="value"/>
    </unity:activity>
  </bpmn:extensionElements>
  <!-- Native ioSpecification and data associations are also emitted. -->
</bpmn:businessRuleTask>
```

The consumer's mapping points to `steps.Rule_NormalizeOwner.value`. The native process graph, not the data canvas, controls when that rule runs. BOB invokes the existing AMIE adapter at the Business Rule Task. It does not run it again while assigning the result to the consumer.

This design deliberately favors explicit BPMN materialization over inventing an inline AMIE expression interpreter inside a mapping engine. If the existing BOB implementation already has a verified pure rule-transform primitive with equivalent semantics, reconcile the representation through a documented adapter; do not introduce a competing evaluator.

## 3.5 Object mapping and overrides

A mapping to `desired` supplies the whole object. A more specific mapping to `desired.Owner` supplies an explicit override. Resolution is deterministic: copy the source object into a new destination instance, then apply valid specific overrides. Duplicate explicit destinations are rejected. Sibling properties and upstream objects remain unchanged.

Native data associations describe the participating data items, while Unity field mappings define the detailed field-level projection. An external BPMN processor that ignores required Unity semantics is not a supported runtime. Do not claim that standard data associations alone execute Unity's object-overlay policy.

The sample type system includes object references and collection suffixes. It is not a complete UML metamodel. Production contract metadata must carry independent requiredness, nullability, cardinality, units, identifiers, security classification, read/write shape and schema revisions. Do not infer all of those from a property name or a C# display type. This prototype intentionally exercises a small subset.

## 3.6 Validation layers

1. **Secure parse:** reject DTD/entity expansion and unapproved external schema resolution; enforce size/depth limits. Parse without executing anything.
2. **BPMN XML schema:** validate native structure against the approved OMG 2.0.2 schema bundle. Do not rely on XML well-formedness alone.
3. **Unity extension XSD:** validate all required extension subtrees. Because extension wildcards can be lax, explicitly validate recognized Unity content instead of assuming the core schema checked it.
4. **Semantic compiler:** resolve contracts, types, semantic IDs, activity/field references, effect/host permissions, path availability, loop scope, freshness and branch outcomes.
5. **Release checks:** verify immutable dependency set, environment activation, review, integrity/signature and required change reference.
6. **Runtime checks:** enforce actual values, service identity, authorization, side effects and durable state rules.

The supplied `qa/validate_xml.py` performs Unity-XSD, reference and ID checks plus negative extension fixtures. Full official OMG schema validation was not run here because schema download was unavailable. Passing this script without `--omg-xsd` must not be reported as full BPMN XSD conformance. Supply the approved local schema bundle using `--omg-xsd /path/BPMN20.xsd` to add that gate.

## 3.7 Import/export scope and anti-loss behavior

The browser exporter handles the structured sample tree: ordinary service and business-rule tasks, data-rule tasks, exclusive decisions, explicit end outcomes, simple timers and the listed structural task kinds. Advanced imported semantics, unrestricted cycles, complex multi-instance scopes and arbitrary external extensions require the real compiler/importer. The prototype rejects unsupported forms instead of converting them to inert rectangles.

The browser importer supports only the emitted v3 profile. It preserves step IDs, mappings, rule references and fixture draft parameters, categories, launch-kind references, and native shape/edge geometry. It rejects an unavailable resource version, DTD content, unknown extension namespace, changed unsupported branch expression or an unreachable activity that would otherwise be dropped. It does not establish general round-trip compatibility with third-party BPMN editors.

The production importer must preserve recognized and opaque optional metadata when safe; any required executable extension it cannot interpret blocks execution. If lossless editing is impossible, it must keep the original file and explain the limitation, not save a silently reduced workflow.

## 3.8 AMIE adapter contract to reconcile, not replace

Devin should locate existing equivalents for these semantic operations:

| Need | Expected behavior |
|---|---|
| Discover rules | Retrieve published identity, version, category, description, required facts and outputs |
| Open rule for editing | Return an authorized draft/editor model derived from AMIE's actual schema |
| Validate a change | Use the existing AMIE validator and report conditions/outcomes/fact errors |
| Preview a rule | Evaluate explicit sample facts through the actual evaluator in an authorized test context |
| Save a rule draft | Create/update the authorized draft; do not mutate an approved version in place |
| Serialize/deserialize | Round-trip AMIE's existing XML without inventing alternative rule semantics |
| Bind in BOB | Resolve exact rule version and typed mappings through the existing local/central host adapter |

These are not mandates to create seven new APIs. Adapt whatever already exists. The local demo parameter editor and JavaScript evaluator must never be copied into production as a replacement rule engine. The fixture-only XSD marker is intentionally not a path to production activation.

## 3.9 Storage and versioning

Use the existing `uty_` schema ownership and draft/publish model. The workflow owns ordinary mappings. Rules retain their own existing AMIE identity/version. Capability contracts retain their existing registered identity/version. A published process pins its references; running instances do not silently change when a new draft is edited.

UI details such as collapsed object cards can be serialized into an approved presentation-only extension after actual source reconciliation. The prototype keeps those UI details in local view state and does not claim to persist a second UML layout file. Native BPMN DI is preserved for the emitted profile.


---

# 4. Data resolver, compiler behavior and execution boundaries

## 4.1 A green connection has a precise meaning

A green connection means the designer has resolved a declared source and destination under the current validation scope. It does not mean that an external API call has succeeded, that the source value will never be null, or that the workflow is approved for production. The UI must distinguish `connected`, `valid for test`, `verified execution evidence` and `approved/activated`.

The browser prototype verifies matching nominal fixture types, source presence on a conservative structured path, required versus optional source availability, collection/scalar distinction, selected domain identifiers, known binding references and a small rule-slot contract. The production compiler must add the complete existing engine semantics. Do not copy these small JavaScript checks and call them the BOB compiler.

## 4.2 Required production analysis

| Concern | Required check | UI result |
|---|---|---|
| Binding identity | Producer, port, property and consumer exist in pinned schemas | Missing/removed field diagnostic |
| Data type | Assignability, enum/domain values, precision and structural compatibility | Explain mismatch; offer only approved conversion |
| Requiredness | A required input is supplied on every executing path | Unresolved or guard/default suggestion |
| Nullability | Optional absence, explicit null and empty string are different | Explicit policy/guard, not silent coercion |
| Cardinality | Scalar, optional object and collection agree | Choose item/For Each/aggregate explicitly |
| Semantic identity | AccountId, SafeId, PlatformId, units and entity keys mean the intended thing | Block unsafe identifier substitutions |
| Execution path | Producer successfully executes before consumer in the same applicable scope | Future/sibling-path source blocked |
| Outcome paths | Failure, timeout and cancellation do not yield success-only outputs | Handler-specific facts or missing-data error |
| Freshness | Pre-write snapshots cannot satisfy a post-write verification requirement | Suggest a new read after the write |
| Security | Author can bind/use resource in workflow scope; service operation remains approved | Backend deny; no UI-only enforcement |
| Information classification | Sensitive values cannot be routed to an unauthorized sink | Block mapping/export/log display |
| Host | L2 local operation is available in the capability host; remote operations have approved dispatch adapters | Explicit call/adapter, not a hidden network hop |
| Rule purity | A compact data-rule slot has no hidden I/O or durable wait | Use an ordinary BPMN activity when necessary |
| Version | Workflow pins operation/rule schemas and execution requirements | Version mismatch / migration review |

A GetAccount operation's success output is available only on the successful path. An error boundary leading elsewhere does not implicitly carry that account object. A retry of an uncertain write cannot be justified by a successful type check. Operational outcomes and business-rule decisions remain different facts.

## 4.3 Analysis order

Read the canonical BPMN model and required Unity extensions. Resolve registry and AMIE contract identities. Build the control-flow graph and execution scopes. Compute data availability on successful, error and timeout paths. Apply explicit mappings and approved rule/transform semantics. Check consumer requirements and produce diagnostics with activity IDs and property references. Compile the unchanged BOB execution representation through the existing pipeline.

In a sequential path, successful outputs become available to later tasks. At an exclusive merge, only values guaranteed on all reaching paths are automatically available, unless a declared guarded union/merge provides a typed alternative. At a parallel join, completion of the needed branches must be proven; conflicting writes to the same logical destination require an explicit merge policy. In a For Each scope, values are item-scoped; another iteration's account object cannot be reused accidentally. Shared-memory aliasing is not a mapping contract.

These are semantic checks. The XSD cannot prove dominance, path availability, read-after-write freshness, or authority. XML parsing cannot prove them either.

## 4.4 Atomic proposal/commit shape

The real application should use the existing draft command API with equivalent semantics to:

```text
Propose(connection or insertion, draftRevision, consumerId, targetPort)
  -> resolved source, candidate rule/operation, proposed structural diff,
     affected mappings, warnings, plan fingerprint

Apply(approvedPlan, expectedRevision, commandId)
  -> newRevision, persisted diff, diagnostics, stable created IDs
```

These are conceptual operation names, not a requirement to add a second command service. The backend rechecks current authority, catalog versions and revision when applying. Duplicate command IDs return the previous result rather than duplicate a lookup or rule. Failed checks leave the draft unchanged. Undo/redo must restore all related graph and mapping mutations, while recorded audit history remains append-only.

The browser demonstrates a single local history transaction. It does not implement concurrent editors, backend ETags, leases or distributed rollback. Those belong in the existing infrastructure and must be tested separately.

## 4.5 Runtime materialization of data rules

An inserted NormalizeOwner task is an ordinary BOB Business Rule Task bound to the existing AMIE adapter. BOB maps facts, invokes AMIE once, persists/propagates its typed result according to the current host contract and advances its token. The consumer receives that output using the same mapping mechanism as any other activity output.

Do not implement a second recursion-based interpreter just for purple data-flow wires. The diagram might visually compress the rule task into a mapping, but native BPMN order remains authoritative and inspection/export must reveal it.

A shared Enrichment capability may provide reusable pure conversion operations and authoring recipes. External retrieval stays with the owning capability; cross-service sequencing stays with BOB. Simple field projection should not require a network call to an enrichment service. Complex lookups appear as explicit operations, and business decisions remain AMIE rules.

## 4.6 CyberArk reference case

The incoming message represents one staged row: Account ID plus four desired custom-field values. Source adapters handle BE forms, CSV columns, API payloads and Kafka messages separately from the workflow's normalized request. The exact source adapter definition should reference the owning data service; BOB should not query another component's private database.

The workflow obtains current account data, compares permitted fields through AMIE, avoids unnecessary writes, applies only authorized changes, retrieves the account again and verifies the change set. The mock deliberately normalizes the account into `account.properties`; do not mistake that sample DTO for the actual CyberArk response schema. The installed API/SDK contract remains authoritative.

For real partial-update APIs, the adapter translates the allowed change set into the documented request. For full replacement APIs, the adapter/workflow must explicitly preserve untouched data and address concurrency. This packet does not alter the previously discussed distinction. Do not add an invented AddOrUpdate behavior to a vendor endpoint merely because the visual flow is convenient.

Kafka redelivery, idempotency, uncertain writes, stale snapshots, retries, cancellation and reconciliation remain existing capability/BOB concerns. A diagram edit has no such side effect. The service identity used for the API is independent of the user's BE group membership; Unity controls the user's workflow actions, and the receiving service verifies approved command/binding authority.

## 4.7 Diagnostics and repair actions

Every diagnostic needs a stable code, severity, node ID, destination/source reference, plain-language explanation and safe repair action. Examples in the prototype include INPUT_UNRESOLVED, SOURCE_UNAVAILABLE, TYPE_MISMATCH, OPTIONAL_SOURCE, SEMANTIC_ID_MISMATCH, OBSOLETE_MAPPING, DECISION_OUTPUT and ERROR_PATH_REQUIRED.

A field should say **Account data is missing. Get Account can supply it using the incoming Account ID**, not merely `null reference`. A future producer should say **This value is produced after this activity**. A stale verification source should say **This account was read before the update; choose the later Get Account result**. A collection error should explain whether an item, a list or an explicit aggregation is needed.

Saving a draft with diagnostics is allowed. Testing a structurally invalid input path is blocked in the fixture. Production validation/publish/activation applies the complete governance policy, not only the green badges in this browser.

## 4.8 Production security checks are not postponed by the prototype

No arbitrary JavaScript/C#/SQL, URL selection or credentials may be imported through a mapping. Only registered operations, approved rules and constrained conversions may execute. Treat XML and imported packages as untrusted input. Apply parser depth/size/entity controls, dependency allowlists and signature validation at the appropriate release boundary. Do not fetch remote XSDs named by an untrusted file during import.

The production ServiceNow field is initially a mandatory change reference, not proof of ticket approval and not live ServiceNow validation. Production authorization uses approved entitlements and release policy. Experimental visualization does not bypass missing runtime handlers or production eligibility rules.


---

# 5. Devin execution instructions, milestone-linked stories and acceptance

## 5.1 Start instruction

Read the master document in order, then inspect the current repositories. Preserve existing BOB, AMIE, capability SDK, group/identity and serializer behavior. The JavaScript is an interaction reference and local fixture, not production domain logic to transplant. Reuse existing Blazor components and draft commands where they satisfy this contract. Do not add a separate UML engine, AMIE engine, mapping service or rule serialization format.

Keep the currently approved expanded BOB Phase 1 features; do not mistake this browser's limited execution fixture for a reduced runtime scope. Record existing versus missing behavior with source locations and tests. Do not silently turn an unknown into an architectural decision.

## 5.2 Milestone ownership

The planning IDs below are local handoff identifiers, not actual Jira records. Each story has one owning milestone in the previously agreed structure. Existing Jira creation/mapping is handled on the Wells Fargo side. Completion should be reported by accepted stories and their evidence, not screenshot counts or arbitrary percentages.

| Story | Owning milestone | Outcome | Depends on |
|---|---|---|---|
| CZ-301 | M0 - Architecture reconciliation | Existing-model and AMIE adapter compatibility assessment | None |
| CZ-302 | M4 - Blazor interfaces | Context-preserving editable object/field controls and shared menus | CZ-301 |
| CZ-303 | M3 - BPMN Phase 1 execution | Typed mapping resolver and atomic draft commands | CZ-301 |
| CZ-304 | M2 - BOB/AMIE integration | In-context rule catalog/editor and materialized data rules | CZ-301, CZ-303 |
| CZ-305 | M3 - BPMN Phase 1 execution | Canonical XML/DI extension adapter and round-trip validation | CZ-303, CZ-304 |
| CZ-306 | M4 - Blazor interfaces | Themes, guided navigation, contextual help and accessibility | CZ-302 |
| CZ-307 | M6 - UAT / readiness | Two complete authoring journeys with regression evidence | CZ-302 through CZ-306 |

These stories extend the relevant milestones; they do not replace the unrelated capabilities, enterprise integrations or production-readiness work already agreed.

## CZ-301 - Reconcile the existing draft and rule contracts

**Scope:** Locate actual BPMN storage/compiler/host code, the current draft mutation/undo APIs, SDK input/output metadata, native AMIE rule XML serializer, rule editor model, permissions and versioning mechanisms. Identify the minimum adapters required for this UX.

**Deliverable:** Source-backed compatibility matrix with real repository paths; existing vs adapted vs missing; regression fixtures; proposed namespace/schema changes; rejected duplicate implementations.

**Acceptance:** No existing contract is replaced merely because a mock uses different names. At least one real stored BPMN and one actual AMIE XML rule are imported, reserialized and regression-tested through existing code. Every proposed breaking change is explicitly identified and not implemented without approval.

**Evidence:** Tests and source references, not a generic architecture statement.

## CZ-302 - Build the contextual editable surface

**Scope:** Persistent BPMN highlight/breadcrumb; expandable typed objects; root/field selection; change-source dialog; click-and-connect and keyboard alternative; field overrides; selectable rule cards; three-dot/right-click menus; same draft store and undo.

**Acceptance:** An author can map a whole object, override one nested field, remove that mapping, undo it, switch to the process view and return without a duplicate configuration. Selecting another BPMN activity updates the available data and the highlighted context. Removing a producer displays dependent failures. The kebab opens actual actions on both guided and zoomed elements.

**Evidence:** Blazor component tests plus browser journeys using declared contracts, not hardcoded labels. Negative paths must prove wrong types and unavailable data do not create accepted mappings.

## CZ-303 - Resolve typed data and apply atomic commands

**Scope:** Endpoint identity, versions, type/cardinality/nullability, semantic IDs, path/branch/loop availability, purity/host constraints, missing-data suggestions, producer reuse and freshness. Use the existing compiler. Add plan/apply support to the existing draft command layer if needed.

**Acceptance:** One-click Get Account produces one command, one task and correct bindings. Double-click/retry cannot duplicate it. A stale draft revision rejects without partial changes. An unrelated or stale account result is not silently reused. Future/sibling-branch outputs cannot satisfy required inputs. User confirmation cannot override a security or identifier-domain mismatch.

**Evidence:** Compiler fixtures, concurrent mutation tests, command idempotency tests, invalid import cases and successful valid cases.

## CZ-304 - Make rule selection and rule-on-mapping genuinely editable

**Scope:** Existing AMIE library adapter; search/category/detail; actual rule editor schema; preview/test; create draft without changing approved shared rule; compatible rebind; explicit businessRuleTask insertion on a mapping; remove/reconnect semantics.

**Acceptance:** A selected rule's actual required facts and outputs populate the designer. Changing a rule preserves activity ID and branches but invalidates incompatible bindings. Inserting a pure rule creates a native BPMN task and two bindings; BOB evaluates it exactly once through the existing AMIE adapter. Rule errors do not become empty strings or automatic approvals. Multi-fact rules cannot be squeezed into an incompatible scalar slot.

**Evidence:** Native AMIE serialization tests, evaluator tests, invocation-count test, schema-version compatibility tests, whole-transaction undo and real renderer projection tests.

## CZ-305 - Persist the actual model, not a hidden JSON twin

**Scope:** Standard BPMN structure/DI; approved Unity namespace fields; actual AMIE references; deterministic endpoint locators; mapping semantics; import preservation and validation. Adopt existing extension fields where possible rather than introducing another parallel schema.

**Acceptance:** Export -> import restores node and mapping identities, rule references, branch paths and required layout. Required unknown execution extensions block activation; editing must not discard them. Validate with the OMG schema bundle, the approved Unity XSD and separate semantic tests. Demonstrate failures for each layer. A visually correct diagram cannot pass merely because XML parses.

**Evidence:** Before/after semantic comparison, XML fixtures, XSD negative tests, unsupported-element preservation/rejection tests and snapshot round-trips. Native AMIE XML comes from the actual serializer, not the fixture-only format here.

## CZ-306 - Consistent themes, menus, descriptions and help

**Scope:** Shared semantic color tokens; text equivalents; menu keyboard behavior; focus management; narrow-layout support; meaningful descriptions; operation/rule category browsing; precise simulation/production wording.

**Acceptance:** Both themes retain readable selected/disabled/error states. Keyboard users can choose a rule, change a mapping, undo and return to the enclosing activity. No page-wide horizontal overflow at the tested narrow width; internal diagram scrolling remains available. Cancellation leaves state unchanged. Existing menus and pickers continue to work.

**Evidence:** Browser tests, keyboard walkthrough, contrast checks, screen-reader review and signed visual review. The supplied Chromium checks are not a complete accessibility certification.

## CZ-307 - Prove the complete journeys

**Journey A:** One staged record -> Get Account -> AMIE comparison -> patch changed fields -> Get Account again -> explicit verification result. Insert/edit a normalization rule on one custom field; demonstrate changed and no-change paths. Demonstrate mismatched verification and unavailable data.

**Journey B:** Account onboarding from a larger input contract with authorized Safe/Platform lookup outputs. Compose a typed account request, inspect a nested mapping, select a rule in context and preserve unresolved platform-specific requirements until supplied. This second journey uses real registry schemas; the browser's retained onboarding sample is not sufficient evidence.

**Acceptance:** A non-programmer completes the common edits without a separate mapping application. XML and AMIE artifacts load through approved DEV/UAT processes. Existing SDK and service handlers do not need recompilation for changes expressible through their existing approved operations. Production activation remains governed.

**Evidence:** Recorded author walkthroughs, exact input fixtures, native runtime results, source regression tests and milestone acceptance decisions.

## 5.3 Change discipline

For any adaptation, the PR must say: original decision; observed implementation fact; proposed change; reason; affected contracts; compatibility impact; tests; what remains unverified. Preserve the user's rationale for contextual depth and simplicity. Do not reopen settled questions about multiple categories, no mandatory owning application, service-account boundaries, one BOB core, existing AMIE or the DEV/UAT/PROD scope without explicit evidence and approval.


---

# 6. What actually works here, what is a contract, and what is still unverified

## 6.1 Demonstrated in the HTML

The actual original builder is retained as the base. The new layer is executable JavaScript over its shared draft, not a set of disconnected pictures.

- Select a BPMN activity and keep it highlighted while opening Data, Business rule, Settings and Lineage.
- Expand sample nested source/target objects; select source and destination; connect or change a mapping using click, drag/drop or a popover.
- Whole-object mapping and explicit child override in the same mapping records.
- Three-dot and right-click step/field/connection menus with keyboard navigation.
- Search and select an AMIE fixture rule inside the selected activity; inspect facts, outputs and a pinned fixture version.
- Insert a supported pure data rule on a String mapping as a real BPMN task; replace it; edit its local fixture parameters; preview a result; remove and reconnect.
- Shared Undo/Redo for connected edits, basic duplicate/move/delete/unbind behavior, original guided picker and authoring stages.
- Conservative data readiness and diagnostics; one-click Get Account repair/reuse in the sample.
- Actual local sample comparison, normalization, patch simulation, read-back and verification branching; no network or privileged operation.
- Light/dark theme, contextual guide and responsive layout.
- Export/import of the documented v3 BPMN profile, Unity mapping extension content and native DI geometry; explicit rejection of unsupported imports.
- Debug JSON retained under an explicit debug label, not as the BPMN exchange format.

The files under assets/ are inspectable source. OPEN.html embeds them so the interactive artifact does not depend on external assets, internet or a CDN. The QA build script regenerates it from the preserved baseline and current extension files.

## 6.2 Deliberately constrained in the prototype

| Area | Demonstration boundary |
|---|---|
| Registry | Fixed typed fixtures, not live SDK discovery or CyberArk schemas |
| Rule authoring | A few real local operators and editable fixture policies, not the entire AMIE editor |
| Inline rule slot | One String input and output; multi-input rules use the normal activity path |
| Type system | Known nominal objects/scalars/collections and limited semantic domains; no claim of complete structural subtyping |
| Availability | Conservative structured-sequence and nested-branch analysis; no full arbitrary CFG proof |
| Parallel and multi-instance runtime | Architectural requirement remains; local fixture does not execute parallel or general loop semantics |
| BPMN import | Only this emitted v3 structured subset; unknown content rejected rather than silently transformed |
| Layout | Standard process DI preserved in emitted subset; object-card placement/expansion is not a separately persisted full UML layout editor |
| Save | Browser storage when permitted; file export for durable transfer; no backend drafts, locks or revisions |
| Security | Demonstration shape/path checks only; no real identity, entitlement or service-account enforcement |
| Release | Explicitly blocked; no signing, ticket lookup or production activation |
| AMIE XML | Native format and serializer not available here; fixture-only edits cannot be called native AMIE XML |

## 6.3 Required before production claims

Source reconciliation, real AMIE rule-schema adapter, official full BPMN XSD validation, existing BOB semantic compiler integration, dynamic registry binding, full host/effect/authority checks, concurrent draft commands, real durable execution and recovery, and release/promotion security remain required. The source audit must determine which already exist; this list does not imply all are missing.

The prototype's literal `properties`, `Owner`, `BusinessUnit`, `CostCenter` and `Application` are illustrative normalized field keys. They are not a verified contract for the bank's installed CyberArk platform. Wire them to the real operations after inspecting their schema and policy.

## 6.4 No silent migration of old drafts

This package uses a new local storage key so it does not overwrite the original prototype's saved drafts. Original files are preserved untouched. The reference folder is for provenance, not an alternative current UI. There is no claim that arbitrary old JSON states can be upgraded without an explicit converter and regression test.

A complete supported import/export adapter must account for constraints, nullability, collection/item scope, semantic identifiers, unknown extension preservation and existing native contract conventions. Those are specified in this handoff, not inferred from a successful browser demo.


---

# 7. Sources and provenance

## User-supplied baseline directly inspected

- `wf_unity_contextual_zoom_v2/WF_Unity_Contextual_BPMN_UML_Zoom_Designer_v2.html`: original richer builder script plus contextual zoom extension. Actual source was read and copied before changes.
- `wf_unity_contextual_zoom_v2/DEVIN_DESIGN_CORRECTION_CONTEXTUAL_BPMN_UML_ZOOM_v2.md`: preservation list, activity depth, mapping contract and source-reconciliation boundary.
- `wf_unity_modeling/unity-modeling-prototype.xsd`: earlier draft schema; explicitly not treated as production-ready.
- This conversation's approved decisions: preserve existing AMIE/BOB; contextual editable UML depth; real rule selection and rule insertion; multiple categories; existing group authority; native BPMN interchange; no separate data-flow engine; light/dark contrast and functional menus.

Original baseline copies are under reference/. Their hashes are recorded in qa/source-checkpoint.json. Current docs are in docs/ and the generated master. The old references do not need to be reconciled by the implementation team to understand this feature.

## External standards references consulted

1. OMG BPMN 2.0.2 specification landing page and machine-readable schema index:
   https://www.omg.org/spec/BPMN/2.0.2
   https://www.omg.org/spec/BPMN/machine-readable
   Used to identify the native schema/DI boundary and official schema bundle, not as evidence of Unity runtime implementation.
2. W3C XML Schema Part 1: Structures, Second Edition:
   https://www.w3.org/TR/xmlschema-1/
   Used for the distinction between extension/schema validation and application semantics. The included XSD is a proposed Unity design schema, not the OMG schema.
3. W3C WAI-ARIA Authoring Practices, Menu Button Pattern:
   https://www.w3.org/WAI/ARIA/apg/patterns/menu-button/
   Used for menu roles, Enter/Space behavior, expanded state and keyboard interaction requirements. A full accessibility audit remains separate.

Schema downloads from OMG were unavailable to the container. The validation report explicitly distinguishes Unity extension validation and native reference checks from full official BPMN XSD validation. No unsuccessful fetch has been represented as a passed validation.

## Authorship status

The proposed interaction contracts, fixture schemas and example registry values in this revision are new design work based on the supplied direction. They are not asserted to be copied from production AMIE, BOB or CyberArk code. The labels 'Approved-ReleaseReady' in the demo catalog are illustrative UI fixtures, not actual bank approval records.


---

# QA report - Editable Contextual Modeling Studio v3

**Review date:** November 19, 2026. These are local design verification results, not live integration or production acceptance.

## Results actually obtained

| Check | Result | Evidence / boundary |
|---|---|---|
| Browser behavior | 48/48 checks passed; zero captured JavaScript page exceptions | browser-results.json; actual Chromium/Playwright interactions |
| Unity extension XSD + native XML reference checks | 47/47 checks passed | xml-results.json; both actual exported sample files |
| JavaScript syntax | Passed for builder-base.js and modeling.js | Node --check |
| Baseline copies | 2 original copies match recorded SHA-256 values | source-checkpoint.json |
| Full official OMG BPMN 2.0.2 XSD | **Not run** | Official schema bundle download unavailable; use validate_xml.py --omg-xsd with approved local bundle |
| Native AMIE / BOB / SDK integration | **Not run** | No enterprise repository/runtime or actual AMIE serializer was available |
| Live CyberArk, Kafka, Email and production release | **Not run / intentionally absent** | No network operations; local fixtures only |

Browser loading used the exact self-contained OPEN.html bytes through Playwright `set_content`: managed navigation policy in this environment blocked file:// and localhost navigation. The interaction tests are real browser events, but do not prove compatibility with enterprise browser policy or a live Blazor deployment.

## Browser coverage

Selection and BPMN context; nested field connection; right-click and three-dot menus; keyboard navigation and dismissal; field override and Undo; incompatible scalar/object, list/single, optional/required and later-source rejection; rule search and selection; visible BPMN rule insertion with atomic Undo/Redo; actual rule preview and local draft save; lineage; light/dark preference independent of revision; compatible rule replacement preserving branches; supported XML round-trip and DI; rejected unknown extension/native content, mismatched native kind, DTD, changed branch conditions and unavailable versions; removal/reconnection; successful, no-change and verification-mismatch fixture paths; producer deletion/repair/deduplication; retained guided menu; Test trace; production block; small-screen overflow check.

This is not a blanket accessibility, full graph-theory, complete BPMN conformance, arbitrary XML round-trip or browser-compatibility certification. The target native implementation needs the additional acceptance cases in the handoff.

## XML coverage

The proposed Unity schema compiled with lxml/libxml2. Every Unity extension subtree in both examples validated. Native XML IDs/references, data-association targets, process sequence references and DI targets were checked. Negative fixtures rejected invalid durations, unknown extension attributes, a missing mapping destination and a fixture draft falsely labeled as a native AMIE adapter.

The distinction matters: XML parsing, extension XSD validation, standard BPMN schema validation, compiler semantics, designer behavior and actual runtime behavior are separate claims. Only the checks listed as passed above were performed.

## How to reproduce

See qa/README.md. All build/test sources and machine-readable results are included. The portable standalone designer is OPEN.html. The current master and Ask copies are generated from the eight current docs, not historical screenshots or superseded specifications.

## Limits to preserve in every handoff

The registry and account fields are illustrative. The data-rule slot demonstrates a pure String-to-String rule; wider multi-fact rules stay explicit tasks. Scope analysis is a conservative structured sample, not full parallel/loop analysis. Native AMIE XML is not fabricated. Actual release activation remains blocked. No approved existing BOB/AMIE/SDK contract is replaced by this prototype.
