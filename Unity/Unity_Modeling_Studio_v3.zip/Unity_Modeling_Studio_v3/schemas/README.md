# Unity modeling extension schema - proposed design profile v3

`unity-modeling-v3.xsd` describes the extension namespace `urn:wf-unity:modeling:prototype:3`. It is not an existing bank deployment contract and does not replace AMIE's native XSD.

The schema validates workflow metadata, typed object fields, activity references, field mappings and explicitly fixture-only rule parameters. It cannot by itself prove execution order, field availability, registry authorization, type compatibility with a live API, or diagram editing behavior. Those are compiler/runtime/designer responsibilities documented in the master.

The extension subtrees in both generated samples pass this XSD. XML IDs, BPMN references and DI references are checked separately by qa/validate_xml.py. Full official OMG schema validation was not run because the official schema files could not be downloaded in this environment; no fabricated replacement schema is supplied.

For the official validation gate, obtain the approved OMG BPMN 2.0.2 machine-readable bundle (BPMN20.xsd with Semantic.xsd, BPMNDI.xsd, DC.xsd and DI.xsd using their correct relative paths), then run:

```sh
python qa/validate_xml.py --omg-xsd /approved/path/BPMN20.xsd
```

Use a local trusted schema resolver. Do not allow an uploaded XML file to choose arbitrary remote XSDs, DTDs or entity targets. See docs/03-XSD-BPMN-AMIE-MAPPING.md for the exact UI-to-schema crosswalk and validation layers.
