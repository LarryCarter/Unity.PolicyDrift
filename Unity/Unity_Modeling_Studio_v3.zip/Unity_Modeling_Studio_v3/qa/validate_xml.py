"""Validate actual sample artifacts. Does not equate XSD success with executable BPMN."""
from pathlib import Path
from lxml import etree as E
import argparse,json,copy
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--omg-xsd',type=Path);args=parser.parse_args()
safe=E.XMLParser(resolve_entities=False,no_network=True,load_dtd=False)
schema=E.XMLSchema(E.parse(str(root/'schemas/unity-modeling-v3.xsd'),safe))
B='http://www.omg.org/spec/BPMN/20100524/MODEL';U='urn:wf-unity:modeling:prototype:3'
checks=[]
def check(name,ok,detail=''):
 checks.append({'name':name,'passed':bool(ok),'detail':detail})
 if not ok:raise AssertionError(name+' '+detail)
for f in sorted((root/'examples').glob('*.bpmn')):
 doc=E.parse(str(f),safe);els=doc.xpath('//*[namespace-uri()=$u and parent::*[namespace-uri()=$b and local-name()="extensionElements"]]',u=U,b=B)
 for i,el in enumerate(els):check(f.name+' extension '+str(i)+' conforms to Unity XSD',schema.validate(el),str(schema.error_log) if not schema.validate(el) else '')
 ids=[x for x in doc.xpath('//@id')];check(f.name+' IDs globally unique',len(ids)==len(set(ids)))
 idset=set(ids)
 for attr in ['sourceRef','targetRef','bpmnElement','itemSubjectRef']:
  refs=doc.xpath('//*[namespace-uri()!=$u]/@'+attr,u=U);check(f.name+' '+attr+' references resolve',all(x in idset for x in refs),str([x for x in refs if x not in idset]))
 for tag in ['sourceRef','targetRef','dataInputRefs','dataOutputRefs']:
  refs=doc.xpath('//b:'+tag+'/text()',namespaces={'b':B});check(f.name+' '+tag+' element references resolve',all(x in idset for x in refs))
 check(f.name+' explicitly not marked production executable',doc.find('.//{'+B+'}process').get('isExecutable')=='false')
 check(f.name+' no embedded JSON workflow twin',not doc.xpath('//*[local-name()="json" or local-name()="editorState"]'))
 if args.omg_xsd:
  omg=E.XMLSchema(E.parse(str(args.omg_xsd),safe));check(f.name+' OMG schema',omg.validate(doc),str(omg.error_log))
# Prove the extension validator actually rejects malformed declarations.
doc=E.parse(str(root/'examples/with-data-rule.bpmn'),safe)
act=doc.find('.//{'+U+'}activity')
bad=copy.deepcopy(act);bad.set('timeout','five minutes');check('Invalid duration rejected',not schema.validate(bad))
bad=copy.deepcopy(act);bad.set('runArbitraryCode','true');check('Unknown extension attribute rejected',not schema.validate(bad))
mapped=doc.find('.//{'+U+'}activity/{'+U+'}map');parent=copy.deepcopy(mapped.getparent());parent.find('{'+U+'}map').attrib.pop('toRef');check('Mapping without destination rejected',not schema.validate(parent))
draft=doc.find('.//{'+U+'}ruleDraft');parent=copy.deepcopy(draft.getparent());parent.find('{'+U+'}ruleDraft').set('adapter','production-amie');check('Fixture cannot claim real AMIE adapter',not schema.validate(parent))
report={'xmlParser':'lxml/libxml2; DTD and network resolution disabled','unityXSD':'Validated extension subtrees','omgSchemaValidation':'RUN' if args.omg_xsd else 'NOT RUN: official OMG XSD downloads unavailable in this environment; native reference/ID/shape checks are not a substitute','tests':checks}
(root/'qa/xml-results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':len(checks),'failed':0,'omg':report['omgSchemaValidation']},indent=2))
