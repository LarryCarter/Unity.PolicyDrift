# Reproduce this package's checks

Viewing OPEN.html requires only a modern browser. Rebuilding and automation require Python 3, BeautifulSoup4, lxml, Playwright, and Chromium. JavaScript syntax checks below use Node.js. Dependency versions should follow the enterprise-approved development environment; this package does not change repository dependencies.

From the extracted package root:

```sh
python qa/build.py
node --check assets/builder-base.js
node --check assets/modeling.js
python qa/browser_tests.py
python qa/smoke.py
python qa/validate_xml.py
```

`CHROMIUM_PATH` can select a browser executable. Otherwise the browser scripts search for chromium or google-chrome on PATH. Browser tests use Playwright set_content to load the exact self-contained HTML bytes because this testing environment's managed navigation policy blocked file:// and localhost browsing. This is not a test of bank browser policy or a claim that a deployed Blazor app was exercised.

Browser results are written to browser-results.json; XML results to xml-results.json. The optional official schema gate is `python qa/validate_xml.py --omg-xsd /approved/path/BPMN20.xsd` with the full official local schema bundle. Read QA-REPORT.md for exactly what was run.

The build copies the original base script/style from the recorded v2 reference and appends the new contextual layer. assets/modeling.js and assets/modeling.css are the editable extension sources. This is a prototype build mechanism, not a prescribed production Blazor architecture.
