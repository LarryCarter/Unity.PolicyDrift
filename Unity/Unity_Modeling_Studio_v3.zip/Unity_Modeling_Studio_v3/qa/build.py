from pathlib import Path
from bs4 import BeautifulSoup
root=Path(__file__).resolve().parents[1]
src=root/'reference/WF_Unity_Contextual_BPMN_UML_Zoom_Designer_v2.html'
s=BeautifulSoup(src.read_text(),'html.parser')
base=s.find_all('script')[0].get_text().replace("const STORE_KEY='wf_unity_simple_authoring_v1'","const STORE_KEY='wf_unity_contextual_editable_v3'")
base=base.replace("action:'Service Task',data:'Service Task',decision:","action:'Service Task',data:'Service Task',ruleTransform:'Business Rule Task',decision:")
css=s.find_all('style')[0].get_text()
(root/'assets/builder-base.js').write_text(base)
(root/'assets/builder-base.css').write_text(css)
html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WF Unity | Editable BPMN + Data + AMIE</title><meta name="description" content="Offline interactive design prototype - v3"></head><body><div id="app"></div><input id="importDraft" type="file" accept=".json" hidden>'''
html+='<style>'+css+'\n'+(root/'assets/modeling.css').read_text()+'</style>'
html+='<script>'+base+'</script><script>'+(root/'assets/modeling.js').read_text()+'</script></body></html>'
(root/'OPEN.html').write_text(html)
print('Built',len(html),'characters')
