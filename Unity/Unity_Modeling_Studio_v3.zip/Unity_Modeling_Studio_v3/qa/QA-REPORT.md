# QA report - Editable Contextual Modeling Studio v3

**Review date:** November 19, 2026. These are local design verification results, not live integration or production acceptance.

## Results actually obtained

| Check | Result | Evidence / boundary |
|---|---|---|
| Browser behavior | 48/48 checks passed; zero captured JavaScript page exceptions | browser-results.json; actual Chromium/Playwright interactions |
| Unity extension XSD + native XML reference checks | 47/47 checks passed | xml-results.json; both actual exported sample files |
| JavaScript syntax | Passed for builder-base.js and modeling.js | Node --check |
| Baseline copies | 2 original copies match recorded SHA-256 values | source-checkpoint.json |
| Full official OMG BPMN 2.0.2 XSD | **Not run** | Official schema bundle download unavailable; use validate_xml.py --omg-xsd with approved local bundle |
| Native AMIE / BOB / SDK integration | **Not run** | No enterprise repository/runtime or actual AMIE serializer was available |
| Live CyberArk, Kafka, Email and production release | **Not run / intentionally absent** | No network operations; local fixtures only |

Browser loading used the exact self-contained OPEN.html bytes through Playwright `set_content`: managed navigation policy in this environment blocked file:// and localhost navigation. The interaction tests are real browser events, but do not prove compatibility with enterprise browser policy or a live Blazor deployment.

## Browser coverage

Selection and BPMN context; nested field connection; right-click and three-dot menus; keyboard navigation and dismissal; field override and Undo; incompatible scalar/object, list/single, optional/required and later-source rejection; rule search and selection; visible BPMN rule insertion with atomic Undo/Redo; actual rule preview and local draft save; lineage; light/dark preference independent of revision; compatible rule replacement preserving branches; supported XML round-trip and DI; rejected unknown extension/native content, mismatched native kind, DTD, changed branch conditions and unavailable versions; removal/reconnection; successful, no-change and verification-mismatch fixture paths; producer deletion/repair/deduplication; retained guided menu; Test trace; production block; small-screen overflow check.

This is not a blanket accessibility, full graph-theory, complete BPMN conformance, arbitrary XML round-trip or browser-compatibility certification. The target native implementation needs the additional acceptance cases in the handoff.

## XML coverage

The proposed Unity schema compiled with lxml/libxml2. Every Unity extension subtree in both examples validated. Native XML IDs/references, data-association targets, process sequence references and DI targets were checked. Negative fixtures rejected invalid durations, unknown extension attributes, a missing mapping destination and a fixture draft falsely labeled as a native AMIE adapter.

The distinction matters: XML parsing, extension XSD validation, standard BPMN schema validation, compiler semantics, designer behavior and actual runtime behavior are separate claims. Only the checks listed as passed above were performed.

## How to reproduce

See qa/README.md. All build/test sources and machine-readable results are included. The portable standalone designer is OPEN.html. The current master and Ask copies are generated from the eight current docs, not historical screenshots or superseded specifications.

## Limits to preserve in every handoff

The registry and account fields are illustrative. The data-rule slot demonstrates a pure String-to-String rule; wider multi-fact rules stay explicit tasks. Scope analysis is a conservative structured sample, not full parallel/loop analysis. Native AMIE XML is not fabricated. Actual release activation remains blocked. No approved existing BOB/AMIE/SDK contract is replaced by this prototype.
