import os, shutil
from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('google-chrome'),headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1550,'height':1040},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((root/'OPEN.html').read_text(), wait_until='load');page.wait_for_timeout(400)
 print('ERRORS',errors)
 print('VALIDATION',page.evaluate('UnityStudio.validate()'))
 print('SIZE',page.evaluate('({scroll:document.documentElement.scrollWidth,width:innerWidth})'))
 page.screenshot(path=str(root/'previews/01-editable-data-light.png'),full_page=True)
 (root/'examples/cyberark-custom-field-enrichment.bpmn').write_text(page.evaluate('UnityStudio.exportXML()'))
 print('IMPORT',page.evaluate('(()=>{try{return UnityStudio.importXML(UnityStudio.exportXML())}catch(e){return {error:e.message,stack:e.stack}}})()'))
 b.close()
