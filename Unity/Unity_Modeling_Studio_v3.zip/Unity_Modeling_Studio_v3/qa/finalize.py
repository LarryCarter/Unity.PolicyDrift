from pathlib import Path
import json, hashlib, re, zipfile
from bs4 import BeautifulSoup
from urllib.parse import urlsplit, unquote
root=Path(__file__).resolve().parents[1]
browser=json.loads((root/'qa/browser-results.json').read_text())
xml=json.loads((root/'qa/xml-results.json').read_text())
bpass=sum(t['passed'] for t in browser['tests']); xpass=sum(t['passed'] for t in xml['tests'])
assert bpass==len(browser['tests']) and not browser['pageErrors']
assert xpass==len(xml['tests'])
source=json.loads((root/'qa/source-checkpoint.json').read_text())
source_checks=[]
for record in source['sourceFiles']:
 p=root/'reference'/Path(record['file']).name
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 assert actual==record['sha256'],str(p)
 source_checks.append(p.name)
qa=f'''# QA report - Editable Contextual Modeling Studio v3

**Review date:** November 19, 2026. These are local design verification results, not live integration or production acceptance.

## Results actually obtained

| Check | Result | Evidence / boundary |
|---|---|---|
| Browser behavior | {bpass}/{len(browser['tests'])} checks passed; zero captured JavaScript page exceptions | browser-results.json; actual Chromium/Playwright interactions |
| Unity extension XSD + native XML reference checks | {xpass}/{len(xml['tests'])} checks passed | xml-results.json; both actual exported sample files |
| JavaScript syntax | Passed for builder-base.js and modeling.js | Node --check |
| Baseline copies | {len(source_checks)} original copies match recorded SHA-256 values | source-checkpoint.json |
| Full official OMG BPMN 2.0.2 XSD | **Not run** | Official schema bundle download unavailable; use validate_xml.py --omg-xsd with approved local bundle |
| Native AMIE / BOB / SDK integration | **Not run** | No enterprise repository/runtime or actual AMIE serializer was available |
| Live CyberArk, Kafka, Email and production release | **Not run / intentionally absent** | No network operations; local fixtures only |

Browser loading used the exact self-contained OPEN.html bytes through Playwright `set_content`: managed navigation policy in this environment blocked file:// and localhost navigation. The interaction tests are real browser events, but do not prove compatibility with enterprise browser policy or a live Blazor deployment.

## Browser coverage

Selection and BPMN context; nested field connection; right-click and three-dot menus; keyboard navigation and dismissal; field override and Undo; incompatible scalar/object, list/single, optional/required and later-source rejection; rule search and selection; visible BPMN rule insertion with atomic Undo/Redo; actual rule preview and local draft save; lineage; light/dark preference independent of revision; compatible rule replacement preserving branches; supported XML round-trip and DI; rejected unknown extension/native content, mismatched native kind, DTD, changed branch conditions and unavailable versions; removal/reconnection; successful, no-change and verification-mismatch fixture paths; producer deletion/repair/deduplication; retained guided menu; Test trace; production block; small-screen overflow check.

This is not a blanket accessibility, full graph-theory, complete BPMN conformance, arbitrary XML round-trip or browser-compatibility certification. The target native implementation needs the additional acceptance cases in the handoff.

## XML coverage

The proposed Unity schema compiled with lxml/libxml2. Every Unity extension subtree in both examples validated. Native XML IDs/references, data-association targets, process sequence references and DI targets were checked. Negative fixtures rejected invalid durations, unknown extension attributes, a missing mapping destination and a fixture draft falsely labeled as a native AMIE adapter.

The distinction matters: XML parsing, extension XSD validation, standard BPMN schema validation, compiler semantics, designer behavior and actual runtime behavior are separate claims. Only the checks listed as passed above were performed.

## How to reproduce

See qa/README.md. All build/test sources and machine-readable results are included. The portable standalone designer is OPEN.html. The current master and Ask copies are generated from the eight current docs, not historical screenshots or superseded specifications.

## Limits to preserve in every handoff

The registry and account fields are illustrative. The data-rule slot demonstrates a pure String-to-String rule; wider multi-fact rules stay explicit tasks. Scope analysis is a conservative structured sample, not full parallel/loop analysis. Native AMIE XML is not fabricated. Actual release activation remains blocked. No approved existing BOB/AMIE/SDK contract is replaced by this prototype.
'''
(root/'qa/QA-REPORT.md').write_text(qa)
chapters=sorted((root/'docs').glob('*.md'))
intro='''# WF Unity - Editable Contextual Modeling: Complete Feature Handoff

**Version:** 3. **Review date:** November 19, 2026.

## How to use this specification

This is the complete current specification for extending the supplied contextual BPMN/UML designer into an editable modeling experience. It is not a new competing platform architecture. It preserves the already-agreed Unity foundation and explicitly protects existing native AMIE, BOB and capability contracts.

The feature is **one workflow, progressively deeper editable perspectives**: process, activity, object, field, rule. The user remains oriented in BPMN while editing data and rule relationships. The underlying draft and Undo/Redo history are shared. A rule inserted between fields becomes a visible BPMN Business Rule Task; the mapper does not become a hidden orchestration or rule engine.

This master contains the complete eight current specification documents plus the current QA report. The individual Markdown files remain available for implementation. ASK-MODE-HANDOFF.md and DEVIN-ASK.md contain identical text. Historical reference files are not competing instructions and need not be reconciled to understand the requested feature.

## Reading order

1. Decisions, rationale and preservation boundaries.
2. Exact author journeys and controls.
3. Components, atomic commands, state and accessibility.
4. BPMN/XML/XSD mapping and native AMIE integration.
5. Validation, data availability and runtime boundaries.
6. Milestone-linked Devin jobs and acceptance evidence.
7. Implemented behavior versus specified/unverified behavior.
8. Sources and provenance.
9. Verification report.

## Before implementation

Audit the actual repository and reuse working contracts. Treat prototype namespace, API/component names and fixture schemas as proposed design artifacts. Never implement a replacement AMIE evaluator merely because the offline demo includes one. Do not reduce the broader agreed BPMN Phase 1 scope to the sample export/fixture subset.

---

'''
master=intro+'\n\n---\n\n'.join(p.read_text() for p in chapters)+'\n\n---\n\n'+qa
for name in ['EDITABLE-MODELING-HANDOFF.md','ASK-MODE-HANDOFF.md','DEVIN-ASK.md']:(root/name).write_text(master)
# Internal file-link check for active html/docs. Ignore references, XML namespace links, and fragments.
errors=[];checked=0
for p in root.rglob('*'):
 if not p.is_file() or 'reference' in p.relative_to(root).parts or p.suffix not in ['.html','.md']:continue
 text=p.read_text()
 if p.suffix=='.html':
  soup=BeautifulSoup(text,'html.parser');links=[e.get(a) for a in ['href','src'] for e in soup.find_all(attrs={a:True})]
 else:links=re.findall(r'\[[^\]]*\]\(([^)]+)\)',text)
 for link in links:
  if not link or link.startswith(('#','http:','https:','data:','javascript:','mailto:')):continue
  path=unquote(urlsplit(link).path)
  if not path:continue
  checked+=1
  if not (p.parent/path).exists():errors.append({'file':str(p.relative_to(root)),'target':link})
assert not errors,errors
(root/'qa/package-results.json').write_text(json.dumps({'currentFileLinksChecked':checked,'missingTargets':errors,'identicalMasterAskCopies':len({hashlib.sha256((root/x).read_bytes()).hexdigest() for x in ['EDITABLE-MODELING-HANDOFF.md','ASK-MODE-HANDOFF.md','DEVIN-ASK.md']})==1,'baselineHashesMatch':source_checks},indent=2))
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='FILE-MANIFEST.json')
manifest={'package':'WF Unity Editable Contextual Modeling v3','scope':'Feature-specific current designer + contracts; no live integration','files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(root/'FILE-MANIFEST.json').write_text(json.dumps(manifest,indent=2))
zip_path=root.parent/'Unity_Modeling_Studio_v3.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,root.name+'/'+str(p.relative_to(root)))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 count=len(z.infolist())
print(json.dumps({'zip':str(zip_path),'files':count,'bytes':zip_path.stat().st_size,'masterWords':len(master.split()),'browserChecks':bpass,'xmlChecks':xpass,'links':checked,'zipIntegrity':'passed'},indent=2))
